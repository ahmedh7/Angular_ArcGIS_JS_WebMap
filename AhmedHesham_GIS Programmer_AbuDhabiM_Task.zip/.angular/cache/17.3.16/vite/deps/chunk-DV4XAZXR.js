import {
  n
} from "./chunk-DWCD4SQQ.js";
import {
  has
} from "./chunk-D5RIMQ7U.js";

// node_modules/@arcgis/core/views/2d/navigation/duration.js
function r() {
  const r2 = has("mapview-essential-goto-duration");
  return null == r2 ? r2 : n(r2);
}

export {
  r
};
//# sourceMappingURL=chunk-DV4XAZXR.js.map
