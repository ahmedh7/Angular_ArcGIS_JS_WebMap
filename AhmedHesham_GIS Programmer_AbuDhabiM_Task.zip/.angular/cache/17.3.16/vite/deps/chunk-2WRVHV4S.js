import {
  F
} from "./chunk-KPO5JCMG.js";
import {
  o as o2
} from "./chunk-TSP7HBRK.js";
import {
  f
} from "./chunk-ZFPFQ4J4.js";
import {
  p as p2
} from "./chunk-VY7ME65R.js";
import {
  c as c4
} from "./chunk-ZL7AFA5U.js";
import {
  c as c5
} from "./chunk-DWHZIVJ2.js";
import {
  p
} from "./chunk-NNQGBMH4.js";
import {
  i
} from "./chunk-EYGV7DRM.js";
import {
  a as a3
} from "./chunk-KJXL4KHH.js";
import {
  C as C2,
  a2 as a4
} from "./chunk-B4CSKOTH.js";
import {
  l,
  u
} from "./chunk-AOJUXBCS.js";
import {
  S
} from "./chunk-PEKG77YQ.js";
import {
  c
} from "./chunk-M43HSGJE.js";
import {
  p as p3
} from "./chunk-7T32KOGA.js";
import {
  c as c3,
  oe
} from "./chunk-XAJHU5YA.js";
import {
  m as m3,
  u as u2
} from "./chunk-6JLNBB4A.js";
import {
  Z
} from "./chunk-HCOIDKPJ.js";
import {
  r as r5
} from "./chunk-JHB4QD5T.js";
import {
  q
} from "./chunk-RQIC5Q3A.js";
import {
  S as S2
} from "./chunk-RWBMMFSQ.js";
import {
  g as g2
} from "./chunk-3SPX7DOW.js";
import {
  r as r4
} from "./chunk-7F6XPLMG.js";
import {
  b
} from "./chunk-7OZN72PM.js";
import {
  R,
  c as c2
} from "./chunk-WOVS7CNY.js";
import {
  y as y2
} from "./chunk-4VQUNH2Z.js";
import {
  y
} from "./chunk-P6BYIY4S.js";
import {
  n as n3
} from "./chunk-52K7EZBS.js";
import {
  m as m2
} from "./chunk-DZ57YO2M.js";
import {
  n as n4
} from "./chunk-PLXIETOO.js";
import {
  C,
  d as d2
} from "./chunk-VYI6FOKY.js";
import {
  V as V2
} from "./chunk-EC2O3UFA.js";
import {
  w as w2
} from "./chunk-FMVDY4TM.js";
import {
  o
} from "./chunk-4JUCUHPE.js";
import {
  g,
  r as r3
} from "./chunk-P5ELECBN.js";
import {
  s as s4
} from "./chunk-REZDV4AU.js";
import {
  P2 as P,
  d
} from "./chunk-ADRG7ORV.js";
import {
  V,
  v
} from "./chunk-4LJTFP6V.js";
import {
  e,
  m,
  n2,
  t2
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2,
  h,
  r as r2,
  s,
  w,
  x
} from "./chunk-QYUZVPLR.js";
import {
  t
} from "./chunk-ZBG4VLBC.js";
import {
  s as s3
} from "./chunk-VT56RVNM.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a,
  n2 as n,
  s2
} from "./chunk-JB56QM27.js";
import {
  has
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/mixins/ArcGISMapService.js
var f2 = (f4) => {
  let b2 = class extends f4 {
    constructor() {
      super(...arguments), this.capabilities = void 0, this.copyright = null, this.fullExtent = null, this.legendEnabled = true, this.spatialReference = null, this.version = void 0, this._allLayersAndTablesMap = null;
    }
    readCapabilities(e2, r6) {
      const t3 = r6.capabilities && r6.capabilities.split(",").map((e3) => e3.toLowerCase().trim());
      if (!t3) return { operations: { supportsExportMap: false, supportsExportTiles: false, supportsIdentify: false, supportsQuery: false, supportsTileMap: false }, exportMap: null, exportTiles: null };
      const s5 = this.type, o3 = "tile" !== s5 && !!r6.supportsDynamicLayers, a5 = t3.includes("query"), p4 = t3.includes("map"), l2 = !!r6.exportTilesAllowed, n5 = t3.includes("tilemap"), c6 = t3.includes("data"), u3 = "tile" !== s5 && (!r6.tileInfo || o3), y3 = "tile" !== s5 && (!r6.tileInfo || o3), m5 = "tile" !== s5, d3 = "tile" !== s5 && o3 && r6.currentVersion >= 11.1, h3 = r6.cimVersion ? r5.parse(r6.cimVersion) : null, f5 = h3?.greaterEqual(1, 4) ?? false, b3 = h3?.greaterEqual(2, 0) ?? false;
      return { operations: { supportsExportMap: p4, supportsExportTiles: l2, supportsIdentify: a5, supportsQuery: c6, supportsTileMap: n5 }, exportMap: p4 ? { supportsArcadeExpressionForLabeling: f5, supportsCIMSymbols: b3, supportsDynamicLayers: o3, supportsSublayerOrderBy: d3, supportsSublayerDefinitionExpression: y3, supportsSublayerVisibility: u3, supportsSublayersChanges: m5 } : null, exportTiles: l2 ? { maxExportTilesCount: +r6.maxExportTilesCount } : null };
    }
    readVersion(e2, r6) {
      let t3 = r6.currentVersion;
      return t3 || (t3 = r6.hasOwnProperty("capabilities") || r6.hasOwnProperty("tables") ? 10 : r6.hasOwnProperty("supportedImageFormatTypes") ? 9.31 : 9.3), t3;
    }
    fetchRelatedService(e2) {
      return __async(this, null, function* () {
        const r6 = this.portalItem;
        if (!r6 || !c(r6)) return null;
        this._relatedFeatureServicePromise || (this._relatedFeatureServicePromise = r6.fetchRelatedItems({ relationshipType: "Service2Service", direction: "reverse" }, e2).then((e3) => e3.find((e4) => "Feature Service" === e4.type) ?? null, () => null));
        const t3 = yield this._relatedFeatureServicePromise;
        return s3(e2), t3 ? { itemId: t3.id, url: t3.url } : null;
      });
    }
    fetchSublayerInfo(e2, t3) {
      return __async(this, null, function* () {
        const { source: s5 } = e2;
        if (this?.portalItem && "tile" === this.type && "map-layer" === s5?.type && c(this.portalItem) && e2.originIdOf("url") < e.SERVICE) {
          const r6 = yield this.fetchRelatedService(t3);
          r6 && (e2.url = V(r6.url, s5.mapLayerId.toString()), e2.layerItemId = r6.itemId);
        }
        const { url: i2 } = e2;
        let a5;
        if ("data-layer" === s5.type) {
          a5 = (yield P(i2, __spreadValues({ responseType: "json", query: __spreadProps(__spreadValues({ f: "json" }, this.customParameters), { token: this.apiKey }) }, t3))).data;
        } else if (i2 && e2.originIdOf("url") > e.SERVICE) try {
          const e3 = yield this._fetchAllLayersAndTablesFromService(i2), r6 = d(i2)?.sublayer ?? s5.mapLayerId;
          a5 = e3.get(r6);
        } catch {
        }
        else {
          let r6 = e2.id;
          "map-layer" === s5?.type && (r6 = s5.mapLayerId);
          try {
            a5 = (yield this.fetchAllLayersAndTables(t3)).get(r6);
          } catch {
          }
        }
        return a5;
      });
    }
    fetchAllLayersAndTables(e2) {
      return __async(this, null, function* () {
        return this._fetchAllLayersAndTablesFromService(this.parsedUrl?.path, e2);
      });
    }
    _fetchAllLayersAndTablesFromService(e2, i2) {
      return __async(this, null, function* () {
        yield this.load(i2), this._allLayersAndTablesMap ||= /* @__PURE__ */ new Map();
        const a5 = d(e2), p4 = r2(this._allLayersAndTablesMap, a5?.url.path, () => P(V(a5?.url.path, "/layers"), { responseType: "json", query: __spreadProps(__spreadValues({ f: "json" }, this.customParameters), { token: this.apiKey }) }).then((e3) => {
          const r6 = /* @__PURE__ */ new Map(), { layers: t3, tables: s5 } = e3.data, o3 = [...t3 ?? [], ...s5 ?? []];
          for (const i3 of o3) r6.set(i3.id, i3);
          return { result: r6 };
        }, (e3) => ({ error: e3 }))), l2 = yield p4;
        if (s3(i2), "result" in l2) return l2.result;
        throw l2.error;
      });
    }
  };
  return r([m({ readOnly: true })], b2.prototype, "capabilities", void 0), r([o("service", "capabilities", ["capabilities", "exportTilesAllowed", "maxExportTilesCount", "supportsDynamicLayers", "tileInfo"])], b2.prototype, "readCapabilities", null), r([m({ json: { read: { source: "copyrightText" } } })], b2.prototype, "copyright", void 0), r([m({ type: w2 })], b2.prototype, "fullExtent", void 0), r([m(u)], b2.prototype, "id", void 0), r([m({ type: Boolean, json: { origins: { service: { read: { enabled: false } } }, read: { source: "showLegend" }, write: { target: "showLegend" } } })], b2.prototype, "legendEnabled", void 0), r([m(l)], b2.prototype, "popupEnabled", void 0), r([m({ type: g })], b2.prototype, "spatialReference", void 0), r([m({ readOnly: true })], b2.prototype, "version", void 0), r([o("service", "version", ["currentVersion", "capabilities", "tables", "supportedImageFormatTypes"])], b2.prototype, "readVersion", null), b2 = r([a2("esri.layers.mixins.ArcGISMapService")], b2), b2;
};

// node_modules/@arcgis/core/layers/support/Sublayer.js
var H;
function W(e2) {
  return "esriSMS" === e2?.type;
}
function X(e2, r6, t3) {
  const i2 = this.originIdOf(r6) >= n2(t3.origin);
  return { ignoreOrigin: true, allowNull: i2, enabled: !!t3 && ("map-image" === t3.layer?.type && (t3.writeSublayerStructure || i2)) };
}
function Y(e2, r6, t3) {
  return { enabled: !!t3 && ("tile" === t3.layer?.type && (t3.origin && this.originIdOf(r6) >= n2(t3.origin) || this._isOverridden(r6))) };
}
function Z2(e2, r6, t3) {
  return { ignoreOrigin: true, enabled: t3 && t3.writeSublayerStructure || false };
}
function ee(e2, r6, t3) {
  return { ignoreOrigin: true, enabled: !!t3?.writeSublayerStructure && this.originIdOf(r6) > e.SERVICE };
}
function re(e2, r6, t3) {
  return { ignoreOrigin: true, enabled: !!t3 && (t3.writeSublayerStructure || this.originIdOf(r6) >= n2(t3.origin)) };
}
var te = 0;
var ie = /* @__PURE__ */ new Set(["layer", "parent", "loaded", "loadStatus", "loadError", "loadWarnings"]);
var oe2 = H = class extends S(n4.IdentifiableMixin(m2)) {
  constructor(e2) {
    super(e2), this.capabilities = void 0, this.maxScaleRange = { minScale: 0, maxScale: 0 }, this.fields = null, this.fullExtent = null, this.geometryType = null, this.globalIdField = null, this.isTable = false, this.legendEnabled = true, this.objectIdField = null, this.parent = null, this.popupEnabled = true, this.popupTemplate = null, this.relationships = null, this.sourceJSON = null, this.spatialReference = null, this.title = null, this.typeIdField = null, this.type = "sublayer", this.types = null, this._lastParsedUrl = null;
  }
  load(e2) {
    return __async(this, null, function* () {
      return this.addResolvingPromise((() => __async(this, null, function* () {
        const { layer: r6, url: i2 } = this;
        if (!r6 && !i2) throw new s2("sublayer:missing-layer", "Sublayer can't be loaded without being part of a layer", { sublayer: this });
        const s5 = r6 ? yield r6.fetchSublayerInfo(this, e2) : (yield P(i2, __spreadValues({ responseType: "json", query: { f: "json" } }, e2))).data;
        s5 && (this.sourceJSON = s5, this.read({ layerDefinition: s5 }, { origin: "service", layer: r6, url: f(i2) }));
      }))()), this;
    });
  }
  readCapabilities(e2, r6) {
    r6 = r6.layerDefinition || r6;
    const { attachment: t3, operations: { supportsQuery: i2, supportsQueryAttachments: o3 }, query: { supportsFormatPBF: s5, supportsOrderBy: a5, supportsPagination: l2 }, data: { supportsAttachment: n5 }, queryRelated: p4 } = c4(r6, this.url);
    return { attachment: { supportsOrderByFields: t3?.supportsOrderByFields ?? false, supportsResize: t3?.supportsResize ?? false }, exportMap: { supportsModification: !!r6.canModifyLayer }, operations: { supportsQuery: i2, supportsQueryAttachments: o3 }, data: { supportsAttachment: n5 }, query: { supportsFormatPBF: s5, supportsOrderBy: a5, supportsPagination: l2 }, queryRelated: p4 };
  }
  get defaultPopupTemplate() {
    return this.createPopupTemplate();
  }
  set definitionExpression(e2) {
    this._setAndNotifyLayer("definitionExpression", e2);
  }
  get effectiveScaleRange() {
    const { minScale: e2, maxScale: r6 } = this;
    return { minScale: e2, maxScale: r6 };
  }
  readMaxScaleRange(e2, r6) {
    return { minScale: (r6 = r6.layerDefinition || r6).minScale ?? 0, maxScale: r6.maxScale ?? 0 };
  }
  get fieldsIndex() {
    return new Z(this.fields || []);
  }
  set floorInfo(e2) {
    this._setAndNotifyLayer("floorInfo", e2);
  }
  readGlobalIdFieldFromService(e2, r6) {
    if ((r6 = r6.layerDefinition || r6).globalIdField) return r6.globalIdField;
    if (r6.fields) {
      for (const t3 of r6.fields) if ("esriFieldTypeGlobalID" === t3.type) return t3.name;
    }
  }
  get id() {
    const e2 = this._get("id");
    return e2 ?? te++;
  }
  set id(e2) {
    this._get("id") !== e2 && (false !== this.layer?.capabilities?.exportMap?.supportsDynamicLayers ? this._set("id", e2) : this._logLockedError("id", "capability not available 'layer.capabilities.exportMap.supportsDynamicLayers'"));
  }
  readIsTable(e2, r6) {
    return "Table" === r6.type;
  }
  set labelingInfo(e2) {
    this._setAndNotifyLayer("labelingInfo", e2);
  }
  writeLabelingInfo(e2, r6, t3, i2) {
    e2 && e2.length && (r6.layerDefinition = { drawingInfo: { labelingInfo: e2.map((e3) => e3.write({}, i2)) } });
  }
  set labelsVisible(e2) {
    this._setAndNotifyLayer("labelsVisible", e2);
  }
  set layer(e2) {
    this._set("layer", e2), this.sublayers?.forEach((r6) => r6.layer = e2);
  }
  set listMode(e2) {
    this._set("listMode", e2);
  }
  set minScale(e2) {
    this._setAndNotifyLayer("minScale", e2);
  }
  readMinScale(e2, r6) {
    return r6.minScale || r6.layerDefinition?.minScale || 0;
  }
  set maxScale(e2) {
    this._setAndNotifyLayer("maxScale", e2);
  }
  readMaxScale(e2, r6) {
    return r6.maxScale || r6.layerDefinition?.maxScale || 0;
  }
  readObjectIdFieldFromService(e2, r6) {
    if ((r6 = r6.layerDefinition || r6).objectIdField) return r6.objectIdField;
    const t3 = r6.fields?.find((e3) => "esriFieldTypeOID" === e3.type);
    return t3?.name;
  }
  set opacity(e2) {
    this._setAndNotifyLayer("opacity", e2);
  }
  readOpacity(e2, r6) {
    const { layerDefinition: t3 } = r6;
    return 1 - 0.01 * (t3?.transparency ?? t3?.drawingInfo?.transparency ?? 0);
  }
  writeOpacity(e2, r6, t3, i2) {
    r6.layerDefinition = { drawingInfo: { transparency: 100 - 100 * e2 } };
  }
  set orderBy(e2) {
    this._setAndNotifyLayer("orderBy", e2);
  }
  writeParent(e2, r6) {
    this.parent && this.parent !== this.layer ? r6.parentLayerId = s(this.parent.id) : r6.parentLayerId = -1;
  }
  get queryTask() {
    if (!this.layer) return null;
    const { capabilities: e2, fieldsIndex: r6, layer: t3, url: i2 } = this, { spatialReference: o3 } = t3, s5 = "gdbVersion" in t3 ? t3.gdbVersion : void 0, a5 = has("featurelayer-pbf") && e2?.query.supportsFormatPBF;
    return new F({ fieldsIndex: r6, gdbVersion: s5, pbfSupported: a5, queryAttachmentsSupported: e2?.operations?.supportsQueryAttachments ?? false, sourceSpatialReference: o3, url: i2 });
  }
  set renderer(e2) {
    if (g2(e2, this.fieldsIndex), e2) {
      for (const r6 of e2.symbols) if (S2(r6)) {
        n.getLogger(this).warn("Sublayer renderer should use 2D symbols");
        break;
      }
    }
    this._setAndNotifyLayer("renderer", e2);
  }
  get source() {
    return this._get("source") || new c2({ mapLayerId: this.id });
  }
  set source(e2) {
    this._setAndNotifyLayer("source", e2);
  }
  set sublayers(e2) {
    this._handleSublayersChange(e2, this._get("sublayers")), this._set("sublayers", e2);
  }
  castSublayers(e2) {
    return w(V2.ofType(H), e2);
  }
  writeSublayers(e2, r6, t3) {
    this.sublayers?.length && (r6[t3] = this.sublayers.map((e3) => e3.id).toArray().reverse());
  }
  readTitle(e2, r6) {
    return r6.layerDefinition?.name ?? r6.name;
  }
  readTypeIdField(e2, r6) {
    let t3 = (r6 = r6.layerDefinition || r6).typeIdField;
    if (t3 && r6.fields) {
      t3 = t3.toLowerCase();
      const e3 = r6.fields.find((e4) => e4.name.toLowerCase() === t3);
      e3 && (t3 = e3.name);
    }
    return t3;
  }
  get url() {
    const e2 = this.layer?.parsedUrl ?? this._lastParsedUrl, r6 = this.source;
    if (!e2) return null;
    if (this._lastParsedUrl = e2, "map-layer" === r6?.type) return `${e2.path}/${r6.mapLayerId}`;
    const t3 = { layer: JSON.stringify({ source: this.source }) };
    return `${e2.path}/dynamicLayer?${v(t3)}`;
  }
  set url(e2) {
    this._overrideIfSome("url", e2);
  }
  set visible(e2) {
    this._setAndNotifyLayer("visible", e2);
  }
  writeVisible(e2, r6, t3, i2) {
    r6[t3] = this.getAtOrigin("defaultVisibility", "service") || e2;
  }
  clone() {
    const { store: e2 } = t(this), r6 = new H();
    return t(r6).store = e2.clone(ie), this.commitProperty("url"), r6._lastParsedUrl = this._lastParsedUrl, r6;
  }
  createPopupTemplate(e2) {
    return p3(this, e2);
  }
  createQuery() {
    return new b({ returnGeometry: true, where: this.definitionExpression || "1=1" });
  }
  createFeatureLayer() {
    return __async(this, null, function* () {
      if (this.hasOwnProperty("sublayers")) return null;
      const e2 = (yield import("./@arcgis_core_layers_FeatureLayer.js")).default, { layer: r6, url: t3 } = this;
      let i2;
      if (t3 && this.originIdOf("url") > e.SERVICE) i2 = new e2({ url: t3 });
      else {
        if (!r6?.parsedUrl) throw new s2("createFeatureLayer:missing-information", "Cannot create a FeatureLayer without a url or a parent layer");
        {
          const t4 = r6.parsedUrl;
          i2 = new e2({ url: t4.path }), t4 && this.source && ("map-layer" === this.source.type ? i2.layerId = this.source.mapLayerId : i2.dynamicDataSource = this.source);
        }
      }
      return null != r6?.refreshInterval && (i2.refreshInterval = r6.refreshInterval), this.definitionExpression && (i2.definitionExpression = this.definitionExpression), this.floorInfo && (i2.floorInfo = a(this.floorInfo)), this.originIdOf("labelingInfo") > e.SERVICE && (i2.labelingInfo = a(this.labelingInfo)), this.originIdOf("labelsVisible") > e.DEFAULTS && (i2.labelsVisible = this.labelsVisible), this.originIdOf("legendEnabled") > e.DEFAULTS && (i2.legendEnabled = this.legendEnabled), this.originIdOf("visible") > e.DEFAULTS && (i2.visible = this.visible), this.originIdOf("minScale") > e.DEFAULTS && (i2.minScale = this.minScale), this.originIdOf("maxScale") > e.DEFAULTS && (i2.maxScale = this.maxScale), this.originIdOf("opacity") > e.DEFAULTS && (i2.opacity = this.opacity), this.originIdOf("popupTemplate") > e.DEFAULTS && (i2.popupTemplate = a(this.popupTemplate)), this.originIdOf("renderer") > e.SERVICE && (i2.renderer = a(this.renderer)), "data-layer" === this.source?.type && (i2.dynamicDataSource = this.source.clone()), this.originIdOf("title") > e.DEFAULTS && (i2.title = this.title), "map-image" === r6?.type && r6.originIdOf("customParameters") > e.DEFAULTS && (i2.customParameters = r6.customParameters), "tile" === r6?.type && r6.originIdOf("customParameters") > e.DEFAULTS && (i2.customParameters = r6.customParameters), i2;
    });
  }
  getField(e2) {
    return this.fieldsIndex.get(e2);
  }
  getFeatureType(e2) {
    return oe(this.types, this.typeIdField, e2);
  }
  getFieldDomain(e2, r6) {
    const t3 = r6?.feature, i2 = this.getFeatureType(t3);
    if (i2) {
      const r7 = i2.domains && i2.domains[e2];
      if (r7 && "inherited" !== r7.type) return r7;
    }
    return this._getLayerDomain(e2);
  }
  queryAttachments(e2, r6) {
    return __async(this, null, function* () {
      yield this.load(), e2 = c3.from(e2);
      const t3 = this.capabilities;
      if (!t3?.data?.supportsAttachment) throw new s2("queryAttachments:not-supported", "this layer doesn't support attachments");
      const { attachmentTypes: i2, objectIds: s5, globalIds: a5, num: l2, size: n5, start: p4, where: u3 } = e2;
      if (!t3?.operations?.supportsQueryAttachments) {
        if (i2?.length > 0 || a5?.length > 0 || n5?.length > 0 || l2 || p4 || u3) throw new s2("queryAttachments:option-not-supported", "when 'capabilities.operations.supportsQueryAttachments' is false, only objectIds is supported", e2);
      }
      if (!(s5?.length || a5?.length || u3)) throw new s2("queryAttachments:invalid-query", "'objectIds', 'globalIds', or 'where' are required to perform attachment query", e2);
      return !t3?.attachment?.supportsOrderByFields && e2.orderByFields?.length && ((e2 = e2.clone()).orderByFields = null), this.queryTask.executeAttachmentQuery(e2, r6);
    });
  }
  queryFeatureCount() {
    return __async(this, arguments, function* (e2 = this.createQuery(), r6) {
      if (yield this.load(), !this.capabilities.operations.supportsQuery) throw new s2("queryFeatureCount:not-supported", "this layer doesn't support queries.");
      if (!this.url) throw new s2("queryFeatureCount:not-supported", "this layer has no url.");
      const t3 = this.layer?.apiKey;
      return yield this.queryTask.executeForCount(e2, __spreadProps(__spreadValues({}, r6), { query: __spreadProps(__spreadValues({}, this.layer?.customParameters), { token: t3 }) }));
    });
  }
  queryFeatures() {
    return __async(this, arguments, function* (e2 = this.createQuery(), r6) {
      if (yield this.load(), !this.capabilities.operations.supportsQuery) throw new s2("queryFeatures:not-supported", "this layer doesn't support queries.");
      if (!this.url) throw new s2("queryFeatures:not-supported", "this layer has no url.");
      const t3 = yield this.queryTask.execute(e2, __spreadProps(__spreadValues({}, r6), { query: __spreadProps(__spreadValues({}, this.layer?.customParameters), { token: this.layer?.apiKey }) }));
      if (t3?.features) for (const i2 of t3.features) i2.sourceLayer = this;
      return t3;
    });
  }
  queryObjectIds() {
    return __async(this, arguments, function* (e2 = this.createQuery(), r6) {
      if (yield this.load(), !this.capabilities.operations.supportsQuery) throw new s2("queryObjectIds:not-supported", "this layer doesn't support queries.");
      if (!this.url) throw new s2("queryObjectIds:not-supported", "this layer has no url.");
      const t3 = this.layer?.apiKey;
      return yield this.queryTask.executeForIds(e2, __spreadProps(__spreadValues({}, r6), { query: __spreadProps(__spreadValues({}, this.layer?.customParameters), { token: t3 }) }));
    });
  }
  queryRelatedFeatures(e2, r6) {
    return __async(this, null, function* () {
      if (yield this.load(), !this.capabilities.operations.supportsQuery) throw new s2("queryRelatedFeatures:not-supported", "this layer doesn't support queries.");
      if (!this.url) throw new s2("queryRelatedFeatures:not-supported", "this layer has no url.");
      const t3 = this.layer?.apiKey;
      return yield this.queryTask.executeRelationshipQuery(e2, __spreadProps(__spreadValues({}, r6), { query: __spreadProps(__spreadValues({}, this.layer?.customParameters), { token: t3 }) }));
    });
  }
  queryRelatedFeaturesCount(e2, r6) {
    return __async(this, null, function* () {
      if (yield this.load(), !this.capabilities.operations.supportsQuery) throw new s2("queryRelatedFeaturesCount:not-supported", "this layer doesn't support queries.");
      if (!this.capabilities.queryRelated.supportsCount) throw new s2("queryRelatedFeaturesCount:not-supported", "this layer doesn't support query related counts.");
      if (!this.url) throw new s2("queryRelatedFeaturesCount:not-supported", "this layer has no url.");
      const t3 = this.layer?.apiKey;
      return yield this.queryTask.executeRelationshipQueryForCount(e2, __spreadProps(__spreadValues({}, r6), { query: __spreadProps(__spreadValues({}, this.layer?.customParameters), { token: t3 }) }));
    });
  }
  toExportImageJSON(e2) {
    const r6 = { id: this.id, source: this.source?.toJSON() || { mapLayerId: this.id, type: "mapLayer" } }, t3 = r4(e2, this.definitionExpression);
    null != t3 && (r6.definitionExpression = t3);
    const i2 = ["renderer", "labelingInfo", "opacity", "labelsVisible"].reduce((e3, r7) => (e3[r7] = this.originIdOf(r7), e3), {}), o3 = Object.keys(i2).some((e3) => i2[e3] > e.SERVICE);
    if (o3) {
      const e3 = r6.drawingInfo = {};
      if (i2.renderer > e.SERVICE && (e3.renderer = this.renderer ? this.renderer.toJSON() : null), i2.labelsVisible > e.SERVICE && (e3.showLabels = this.labelsVisible), this.labelsVisible && i2.labelingInfo > e.SERVICE) if (this.labelingInfo) {
        !this.loaded && this.labelingInfo?.some((e4) => !e4.labelPlacement) && n.getLogger(this).warnOnce(`A Sublayer (title: ${this.title}, id: ${this.id}) has an undefined 'labelPlacement' and so labels cannot be displayed. Either define a valid 'labelPlacement' or call Sublayer.load() to use a default value based on geometry type.`, { sublayer: this });
        let r7 = this.labelingInfo;
        null != this.geometryType && (r7 = a4(this.labelingInfo, y.toJSON(this.geometryType))), e3.showLabels = true, e3.labelingInfo = r7.filter((e4) => e4.labelPlacement).map((e4) => e4.toJSON({ origin: "service", layer: this.layer }));
      } else e3.showLabels = false;
      i2.opacity > e.SERVICE && (e3.transparency = 100 - 100 * this.opacity), this._assignDefaultSymbolColors(e3.renderer);
    }
    return (this.layer?.capabilities?.exportMap?.supportsSublayerOrderBy ?? false) && this.originIdOf("orderBy") > e.SERVICE && (r6.orderBy = this.orderBy?.map((e3) => e3.toJSON()) ?? null), r6;
  }
  _assignDefaultSymbolColors(e2) {
    this._forEachSimpleMarkerSymbols(e2, (e3) => {
      e3.color || "esriSMSX" !== e3.style && "esriSMSCross" !== e3.style || (e3.outline?.color ? e3.color = e3.outline.color : e3.color = [0, 0, 0, 0]);
    });
  }
  _forEachSimpleMarkerSymbols(e2, r6) {
    if (e2) {
      const t3 = ("uniqueValueInfos" in e2 ? e2.uniqueValueInfos : "classBreakInfos" in e2 ? e2.classBreakInfos : null) ?? [];
      for (const e3 of t3) W(e3.symbol) && r6(e3.symbol);
      "symbol" in e2 && W(e2.symbol) && r6(e2.symbol), "defaultSymbol" in e2 && W(e2.defaultSymbol) && r6(e2.defaultSymbol);
    }
  }
  _setAndNotifyLayer(e2, r6) {
    const t3 = this.layer, i2 = this._get(e2);
    let o3, s5;
    switch (e2) {
      case "definitionExpression":
      case "floorInfo":
        o3 = "supportsSublayerDefinitionExpression";
        break;
      case "minScale":
      case "maxScale":
      case "visible":
        o3 = "supportsSublayerVisibility";
        break;
      case "labelingInfo":
      case "labelsVisible":
      case "opacity":
      case "renderer":
      case "source":
        o3 = "supportsDynamicLayers", s5 = "supportsModification";
        break;
      case "orderBy":
        o3 = "supportsSublayerOrderBy", s5 = "supportsModification";
    }
    const a5 = t(this).getDefaultOrigin();
    if ("service" !== a5) {
      if (o3 && false === this.layer?.capabilities?.exportMap?.[o3]) return void this._logLockedError(e2, `capability not available 'layer.capabilities.exportMap.${o3}'`);
      if (s5 && false === this.capabilities?.exportMap[s5]) return void this._logLockedError(e2, `capability not available 'capabilities.exportMap.${s5}'`);
    }
    "source" !== e2 || "not-loaded" === this.loadStatus ? (this._set(e2, r6), "service" !== a5 && i2 !== r6 && t3 && t3.emit && t3.emit("sublayer-update", { propertyName: e2, target: this })) : this._logLockedError(e2, "'source' can't be changed after calling sublayer.load()");
  }
  _handleSublayersChange(e2, r6) {
    r6 && (r6.forEach((e3) => {
      e3.parent = null, e3.layer = null;
    }), this.removeAllHandles()), e2 && (e2.forEach((e3) => {
      e3.parent = this, e3.layer = this.layer;
    }), this.addHandles([e2.on("after-add", ({ item: e3 }) => {
      e3.parent = this, e3.layer = this.layer;
    }), e2.on("after-remove", ({ item: e3 }) => {
      e3.parent = null, e3.layer = null;
    }), e2.on("before-changes", (e3) => {
      (this.layer?.capabilities?.exportMap?.supportsSublayersChanges ?? 1) || (n.getLogger(this).error(new s2("sublayer:sublayers-non-modifiable", "Sublayer can't be added, moved, or removed from the layer's sublayers", { sublayer: this, layer: this.layer })), e3.preventDefault());
    })]));
  }
  _logLockedError(e2, r6) {
    const { layer: t3, declaredClass: i2 } = this;
    n.getLogger(i2).error(new s2("sublayer:locked", `Property '${String(e2)}' can't be changed on Sublayer from the layer '${t3?.id}'`, { reason: r6, sublayer: this, layer: t3 }));
  }
  _getLayerDomain(e2) {
    return this.fieldsIndex.get(e2)?.domain ?? null;
  }
};
oe2.test = { isMapImageLayerOverridePolicy: (e2) => e2 === ee || e2 === Z2 || e2 === X, isTileImageLayerOverridePolicy: (e2) => e2 === Y }, r([m({ readOnly: true })], oe2.prototype, "capabilities", void 0), r([o("service", "capabilities", ["layerDefinition.canModifyLayer", "layerDefinition.capabilities"])], oe2.prototype, "readCapabilities", null), r([m()], oe2.prototype, "defaultPopupTemplate", null), r([m({ type: String, value: null, json: { name: "layerDefinition.definitionExpression", write: { allowNull: true, overridePolicy: X } } })], oe2.prototype, "definitionExpression", null), r([m({ readOnly: true })], oe2.prototype, "effectiveScaleRange", null), r([o("service", "maxScaleRange", ["minScale", "maxScale"])], oe2.prototype, "readMaxScaleRange", null), r([m({ type: [y2], json: { origins: { service: { read: { source: "layerDefinition.fields" } } } } })], oe2.prototype, "fields", void 0), r([m({ readOnly: true })], oe2.prototype, "fieldsIndex", null), r([m({ type: p, value: null, json: { name: "layerDefinition.floorInfo", read: { source: "layerDefinition.floorInfo" }, write: { target: "layerDefinition.floorInfo", overridePolicy: X }, origins: { "web-scene": { read: false, write: false } } } })], oe2.prototype, "floorInfo", null), r([m({ type: w2, json: { read: { source: "layerDefinition.extent" } } })], oe2.prototype, "fullExtent", void 0), r([m({ type: y.apiValues, json: { origins: { service: { name: "layerDefinition.geometryType", read: { reader: y.read } } } } })], oe2.prototype, "geometryType", void 0), r([m({ type: String })], oe2.prototype, "globalIdField", void 0), r([o("service", "globalIdField", ["layerDefinition.globalIdField", "layerDefinition.fields"])], oe2.prototype, "readGlobalIdFieldFromService", null), r([m({ type: x, json: { write: { ignoreOrigin: true } } })], oe2.prototype, "id", null), r([m({ readOnly: true })], oe2.prototype, "isTable", void 0), r([o("service", "isTable", ["type"])], oe2.prototype, "readIsTable", null), r([m({ value: null, type: [C2], json: { read: { source: "layerDefinition.drawingInfo.labelingInfo" }, write: { target: "layerDefinition.drawingInfo.labelingInfo", overridePolicy: ee } } })], oe2.prototype, "labelingInfo", null), r([r3("labelingInfo")], oe2.prototype, "writeLabelingInfo", null), r([m({ type: Boolean, value: true, json: { read: { source: "layerDefinition.drawingInfo.showLabels" }, write: { target: "layerDefinition.drawingInfo.showLabels", overridePolicy: Z2 } } })], oe2.prototype, "labelsVisible", null), r([m({ value: null })], oe2.prototype, "layer", null), r([m({ type: String, json: { write: { overridePolicy: Y } } })], oe2.prototype, "layerItemId", void 0), r([m({ type: Boolean, value: true, json: { origins: { service: { read: { enabled: false } } }, read: { source: "showLegend" }, write: { target: "showLegend", overridePolicy: re } } })], oe2.prototype, "legendEnabled", void 0), r([m({ type: ["show", "hide", "hide-children"], value: "show", json: { read: false, write: false, origins: { "web-scene": { read: true, write: true } } } })], oe2.prototype, "listMode", null), r([m({ type: Number, value: 0, json: { write: { overridePolicy: Z2 } } })], oe2.prototype, "minScale", null), r([o("minScale", ["minScale", "layerDefinition.minScale"])], oe2.prototype, "readMinScale", null), r([m({ type: Number, value: 0, json: { write: { overridePolicy: Z2 } } })], oe2.prototype, "maxScale", null), r([o("maxScale", ["maxScale", "layerDefinition.maxScale"])], oe2.prototype, "readMaxScale", null), r([m()], oe2.prototype, "objectIdField", void 0), r([o("service", "objectIdField", ["layerDefinition.objectIdField", "layerDefinition.fields"])], oe2.prototype, "readObjectIdFieldFromService", null), r([m({ type: Number, value: 1, json: { write: { target: "layerDefinition.drawingInfo.transparency", overridePolicy: Z2 } } })], oe2.prototype, "opacity", null), r([o("opacity", ["layerDefinition.drawingInfo.transparency", "layerDefinition.transparency"])], oe2.prototype, "readOpacity", null), r([r3("opacity")], oe2.prototype, "writeOpacity", null), r([m({ value: null, type: [a3], json: { name: "layerDefinition.orderBy", read: { reader: i } } })], oe2.prototype, "orderBy", null), r([m({ json: { type: x, write: { target: "parentLayerId", writerEnsuresNonNull: true, overridePolicy: Z2 } } })], oe2.prototype, "parent", void 0), r([r3("parent")], oe2.prototype, "writeParent", null), r([m({ type: Boolean, value: true, json: { read: { source: "disablePopup", reader: (e2, r6) => !r6.disablePopup }, write: { target: "disablePopup", overridePolicy: re, writer(e2, r6, t3) {
  r6[t3] = !e2;
} } } })], oe2.prototype, "popupEnabled", void 0), r([m({ type: q, json: { read: { source: "popupInfo" }, write: { target: "popupInfo", overridePolicy: re } } })], oe2.prototype, "popupTemplate", void 0), r([m({ readOnly: true })], oe2.prototype, "queryTask", null), r([m({ type: [p2], readOnly: true, json: { origins: { service: { read: { source: "layerDefinition.relationships" } } } } })], oe2.prototype, "relationships", void 0), r([m({ types: m3, value: null, json: { name: "layerDefinition.drawingInfo.renderer", write: { overridePolicy: ee }, origins: { "web-scene": { types: u2, name: "layerDefinition.drawingInfo.renderer", write: { overridePolicy: ee } } } } })], oe2.prototype, "renderer", null), r([m({ types: { key: "type", base: null, typeMap: { "data-layer": R, "map-layer": c2 } }, cast(e2) {
  if (e2) {
    if ("mapLayerId" in e2) return h(c2, e2);
    if ("dataSource" in e2) return h(R, e2);
  }
  return e2;
}, json: { name: "layerDefinition.source", write: { overridePolicy: Z2 } } })], oe2.prototype, "source", null), r([m()], oe2.prototype, "sourceJSON", void 0), r([m({ type: g, json: { origins: { service: { read: { source: "layerDefinition.extent.spatialReference" } } } } })], oe2.prototype, "spatialReference", void 0), r([m({ value: null, json: { type: [x], write: { target: "subLayerIds", allowNull: true, overridePolicy: Z2 } } })], oe2.prototype, "sublayers", null), r([s4("sublayers")], oe2.prototype, "castSublayers", null), r([r3("sublayers")], oe2.prototype, "writeSublayers", null), r([m({ type: String, json: { name: "name", write: { overridePolicy: re } } })], oe2.prototype, "title", void 0), r([o("service", "title", ["name", "layerDefinition.name"])], oe2.prototype, "readTitle", null), r([m({ type: String })], oe2.prototype, "typeIdField", void 0), r([m({ json: { read: false }, readOnly: true, value: "sublayer" })], oe2.prototype, "type", void 0), r([o("typeIdField", ["layerDefinition.typeIdField"])], oe2.prototype, "readTypeIdField", null), r([m({ type: [c5], json: { origins: { service: { read: { source: "layerDefinition.types" } } } } })], oe2.prototype, "types", void 0), r([m({ type: String, json: { name: "layerUrl", write: { overridePolicy: Y } } })], oe2.prototype, "url", null), r([m({ type: Boolean, value: true, json: { read: { source: "defaultVisibility" }, write: { target: "defaultVisibility", overridePolicy: Z2 } } })], oe2.prototype, "visible", null), r([r3("visible")], oe2.prototype, "writeVisible", null), oe2 = H = r([a2("esri.layers.support.Sublayer")], oe2);
var se = oe2;

// node_modules/@arcgis/core/layers/mixins/SublayersOwner.js
function h2(e2, r6) {
  const s5 = [], t3 = {};
  return e2 ? (e2.forEach((e3) => {
    const o3 = new se();
    if (o3.read(e3, r6), t3[o3.id] = o3, null != e3.parentLayerId && -1 !== e3.parentLayerId) {
      const r7 = t3[e3.parentLayerId];
      r7.sublayers || (r7.sublayers = []), r7.sublayers.unshift(o3);
    } else s5.unshift(o3);
  }), s5) : s5;
}
var f3 = V2.ofType(se);
function S3(e2, r6) {
  e2 && e2.forEach((e3) => {
    r6(e3), e3.sublayers && e3.sublayers.length && S3(e3.sublayers, r6);
  });
}
var m4 = (m5) => {
  let E = class extends m5 {
    constructor(...e2) {
      super(...e2), this.allSublayers = new n3({ getCollections: () => [this.sublayers], getChildrenFunction: (e3) => e3.sublayers }), this.sublayersSourceJSON = { [e.SERVICE]: {}, [e.PORTAL_ITEM]: {}, [e.WEB_SCENE]: {}, [e.WEB_MAP]: {}, [e.LINK_CHART]: {} }, this.subtables = null, this.addHandles([d2(() => this.sublayers, (e3, r6) => this._handleSublayersChange(e3, r6), C), d2(() => this.subtables, (e3, r6) => this._handleSublayersChange(e3, r6), C)]);
    }
    destroy() {
      this.allSublayers.destroy();
    }
    readSublayers(e2, r6) {
      if (!r6 || !e2) return;
      const { sublayersSourceJSON: s5 } = this, t3 = n2(r6.origin);
      if (t3 < e.SERVICE) return;
      if (s5[t3] = { context: r6, visibleLayers: e2.visibleLayers || s5[t3].visibleLayers, layers: e2.layers || s5[t3].layers }, t3 > e.SERVICE) return;
      this._set("serviceSublayers", this.createSublayersForOrigin("service").sublayers);
      const { sublayers: o3, origin: a5 } = this.createSublayersForOrigin("web-document"), l2 = t(this);
      l2.setDefaultOrigin(a5), this._set("sublayers", new f3(o3)), l2.setDefaultOrigin("user");
    }
    findSublayerById(e2) {
      return this.allSublayers.find((r6) => r6.id === e2);
    }
    createServiceSublayers() {
      return this.createSublayersForOrigin("service").sublayers;
    }
    createSublayersForOrigin(e2) {
      const r6 = n2("web-document" === e2 ? "web-map" : e2);
      let s5 = e.SERVICE, t3 = this.sublayersSourceJSON[e.SERVICE].layers, o3 = this.sublayersSourceJSON[e.SERVICE].context, a5 = null;
      const l2 = [e.PORTAL_ITEM, e.WEB_SCENE, e.WEB_MAP].filter((e3) => e3 <= r6);
      for (const y3 of l2) {
        const e3 = this.sublayersSourceJSON[y3];
        o2(e3.layers) && (s5 = y3, t3 = e3.layers, o3 = e3.context, e3.visibleLayers && (a5 = { visibleLayers: e3.visibleLayers, context: e3.context }));
      }
      const i2 = [e.PORTAL_ITEM, e.WEB_SCENE, e.WEB_MAP].filter((e3) => e3 > s5 && e3 <= r6);
      let n5 = null;
      for (const y3 of i2) {
        const { layers: e3, visibleLayers: r7, context: s6 } = this.sublayersSourceJSON[y3];
        e3 && (n5 = { layers: e3, context: s6 }), r7 && (a5 = { visibleLayers: r7, context: s6 });
      }
      const u3 = h2(t3, o3), d3 = /* @__PURE__ */ new Map(), m6 = /* @__PURE__ */ new Set();
      if (n5) for (const y3 of n5.layers) d3.set(y3.id, y3);
      if (a5?.visibleLayers) for (const y3 of a5.visibleLayers) m6.add(y3);
      return S3(u3, (e3) => {
        n5 && e3.read(d3.get(e3.id), n5.context), a5 && e3.read({ defaultVisibility: m6.has(e3.id) }, a5.context);
      }), { origin: t2(s5), sublayers: new f3({ items: u3 }) };
    }
    read(e2, r6) {
      super.read(e2, r6), this.readSublayers(e2, r6);
    }
    _handleSublayersChange(e2, r6) {
      r6 && (r6.forEach((e3) => {
        e3.parent = null, e3.layer = null;
      }), this.removeHandles("sublayers-owner")), e2 && (e2.forEach((e3) => {
        e3.parent = this, e3.layer = this;
      }), this.addHandles([e2.on("after-add", ({ item: e3 }) => {
        e3.parent = this, e3.layer = this;
      }), e2.on("after-remove", ({ item: e3 }) => {
        e3.parent = null, e3.layer = null;
      })], "sublayers-owner"), "tile" === this.type && this.addHandles(e2.on("before-changes", (e3) => {
        n.getLogger("esri.layers.TileLayer").error(new s2("tilelayer:sublayers-non-modifiable", "ISublayer can't be added, moved, or removed from the layer's sublayers", { layer: this })), e3.preventDefault();
      }), "sublayers-owner"));
    }
  };
  return r([m({ readOnly: true })], E.prototype, "allSublayers", void 0), r([m({ readOnly: true, type: V2.ofType(se) })], E.prototype, "serviceSublayers", void 0), r([m({ value: null, type: f3, json: { read: false, write: { allowNull: true, ignoreOrigin: true } } })], E.prototype, "sublayers", void 0), r([m({ readOnly: true })], E.prototype, "sublayersSourceJSON", void 0), r([m({ type: f3, json: { read: { source: "tables" } } })], E.prototype, "subtables", void 0), E = r([a2("esri.layers.mixins.SublayersOwner")], E), E;
};

export {
  f2 as f,
  se,
  m4 as m
};
//# sourceMappingURL=chunk-2WRVHV4S.js.map
