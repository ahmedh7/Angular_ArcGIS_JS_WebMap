import {
  E,
  I,
  S as S2,
  _,
  o,
  t as t3
} from "./chunk-MAGZONKR.js";
import {
  f as f6
} from "./chunk-SYC7UJSM.js";
import {
  L
} from "./chunk-NSQN45KU.js";
import {
  p as p8
} from "./chunk-GR6GUEVE.js";
import {
  F,
  W,
  i as i2,
  r as r4,
  r2 as r5
} from "./chunk-64OHD5NP.js";
import {
  st
} from "./chunk-4G6QLHLE.js";
import {
  s as s2
} from "./chunk-6BUGRELN.js";
import {
  e as e3
} from "./chunk-KATWIIRQ.js";
import {
  u as u2,
  y as y3
} from "./chunk-QC47YGD2.js";
import {
  g2 as g3
} from "./chunk-AXAMTBE6.js";
import {
  d as d4,
  p as p5
} from "./chunk-RF3IXNCL.js";
import {
  c,
  p as p3
} from "./chunk-OR23LWBA.js";
import {
  a as a3,
  l as l3,
  p as p2
} from "./chunk-O27NRO2R.js";
import {
  s as s3
} from "./chunk-ZFKMGP62.js";
import {
  c as c2,
  p as p6
} from "./chunk-EYGV7DRM.js";
import {
  C,
  a as a4,
  n as n4
} from "./chunk-B4CSKOTH.js";
import {
  f as f5,
  l as l4
} from "./chunk-DGGGA4EB.js";
import {
  d as d5
} from "./chunk-VOLYE23O.js";
import {
  d as d3
} from "./chunk-XHRVMHQV.js";
import {
  f as f4
} from "./chunk-5I7JTSAL.js";
import {
  l,
  n as n3,
  p
} from "./chunk-SWTEWHKX.js";
import {
  t
} from "./chunk-CLCRCQS5.js";
import {
  d,
  f as f2,
  j as j3,
  l as l2,
  v
} from "./chunk-AOJUXBCS.js";
import {
  S
} from "./chunk-PEKG77YQ.js";
import {
  p as p7
} from "./chunk-7T32KOGA.js";
import {
  t as t2
} from "./chunk-SHZ6V3A6.js";
import {
  m as m3
} from "./chunk-6JLNBB4A.js";
import {
  p as p4
} from "./chunk-G4JWBWXC.js";
import {
  E as E2
} from "./chunk-ELAKODAU.js";
import {
  q
} from "./chunk-RQIC5Q3A.js";
import {
  d as d2
} from "./chunk-RWBMMFSQ.js";
import {
  m3 as m2
} from "./chunk-Y37JFXZA.js";
import {
  I as I2,
  g as g4
} from "./chunk-3SPX7DOW.js";
import {
  e as e2
} from "./chunk-7F6XPLMG.js";
import {
  b
} from "./chunk-7OZN72PM.js";
import {
  y as y2
} from "./chunk-4VQUNH2Z.js";
import {
  y
} from "./chunk-P6BYIY4S.js";
import {
  f
} from "./chunk-EXKRZGS6.js";
import {
  O,
  Q
} from "./chunk-WJEG23O3.js";
import {
  f as f3
} from "./chunk-GYDLT2MD.js";
import {
  h
} from "./chunk-4LHIE7NG.js";
import {
  P as P2,
  j as j2
} from "./chunk-GMDCM6PU.js";
import {
  w
} from "./chunk-FMVDY4TM.js";
import {
  j2 as j
} from "./chunk-K2TU6MD2.js";
import {
  g as g2,
  r as r3
} from "./chunk-P5ELECBN.js";
import {
  U
} from "./chunk-HPCWTJIY.js";
import {
  i
} from "./chunk-TAT7XC7M.js";
import {
  n as n2
} from "./chunk-3T5L5WXD.js";
import {
  P2 as P
} from "./chunk-ADRG7ORV.js";
import {
  e,
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2,
  r as r2
} from "./chunk-QYUZVPLR.js";
import {
  u3 as u
} from "./chunk-VT56RVNM.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a,
  n2 as n,
  s2 as s
} from "./chunk-JB56QM27.js";
import {
  __async,
  __objRest,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/rest/knowledgeGraph/ProtoFeatureCollection.js
var t4 = class {
  constructor() {
    this.version = "", this.queryResult = new e4();
  }
};
var e4 = class {
  constructor() {
    this.featureResult = new i3();
  }
};
var i3 = class {
  constructor() {
    this.objectIdFieldName = "", this.uniqueIdField = new r6(), this.globalIdFieldName = "", this.geohashFieldName = "", this.geometryProperties = new a5(), this.geometryType = null, this.spatialReference = new g2(), this.exceededTransferLimit = false, this.hasZ = false, this.hasM = false, this.transform = new h2(), this.fields = [], this.fieldNameToAttributeIndexMap = {}, this.values = [], this.features = [], this.geometryFields = [];
  }
};
var r6 = class {
  constructor() {
    this.name = "", this.isSystemMaintained = false;
  }
};
var a5 = class {
  constructor() {
    this.shapeAreaFieldName = "", this.shapeLengthFieldName = "", this.units = "";
  }
};
var h2 = class {
  constructor() {
    this.quantizeOriginPosition = "upperLeft", this.scale = new n5(), this.translate = new o2();
  }
};
var n5 = class {
  constructor() {
    this.xScale = 0, this.yScale = 0, this.mScale = 0, this.zScale = 0;
  }
};
var o2 = class {
  constructor() {
    this.xTranslate = 0, this.yTranslate = 0, this.mTranslate = 0, this.zTranslate = 0;
  }
};
var c3 = class {
  constructor() {
    this.name = "", this.fieldType = "esriFieldTypeString", this.alias = "", this.sqlType = "sqlTypeVarchar", this.domain = "", this.defaultValue = "";
  }
};
var l5 = class {
  constructor() {
    this.attributes = [], this.compressedGeometry = new E3(), this.centroid = new E3(), this.aggregateGeometries = [];
  }
};
var E3 = class {
  constructor() {
    this.geometryType = null, this.lengths = [], this.coords = [];
  }
};
var T;
!function(s7) {
  s7.ELEMENTUID = "ELEMENTUID", s7.TYPENAME = "TYPENAME";
}(T || (T = {}));
var m4 = [T.ELEMENTUID, T.TYPENAME];
var d6;
var N;
!function(s7) {
  s7[s7.ELEMENTUID = 0] = "ELEMENTUID", s7[s7.TYPENAME = 1] = "TYPENAME";
}(d6 || (d6 = {})), function(s7) {
  s7[s7.ELEMENTUID = 0] = "ELEMENTUID", s7[s7.TYPENAME = 1] = "TYPENAME", s7[s7.FROMUID = 2] = "FROMUID", s7[s7.TOUID = 3] = "TOUID";
}(N || (N = {}));

// node_modules/@arcgis/core/rest/knowledgeGraph/wasmInterface/WasmSerializedLayerData.js
var e5;
var l6;
var s4;
var T2;
!function(e6) {
  e6[e6.featureResult = 0] = "featureResult", e6[e6.countResult = 1] = "countResult", e6[e6.idsResult = 2] = "idsResult";
}(e5 || (e5 = {})), function(e6) {
  e6[e6.upperLeft = 0] = "upperLeft", e6[e6.lowerLeft = 1] = "lowerLeft";
}(l6 || (l6 = {})), function(e6) {
  e6[e6.sqlTypeBigInt = 0] = "sqlTypeBigInt", e6[e6.sqlTypeBinary = 1] = "sqlTypeBinary", e6[e6.sqlTypeBit = 2] = "sqlTypeBit", e6[e6.sqlTypeChar = 3] = "sqlTypeChar", e6[e6.sqlTypeDate = 4] = "sqlTypeDate", e6[e6.sqlTypeDecimal = 5] = "sqlTypeDecimal", e6[e6.sqlTypeDouble = 6] = "sqlTypeDouble", e6[e6.sqlTypeFloat = 7] = "sqlTypeFloat", e6[e6.sqlTypeGeometry = 8] = "sqlTypeGeometry", e6[e6.sqlTypeGUID = 9] = "sqlTypeGUID", e6[e6.sqlTypeInteger = 10] = "sqlTypeInteger", e6[e6.sqlTypeLongNVarchar = 11] = "sqlTypeLongNVarchar", e6[e6.sqlTypeLongVarbinary = 12] = "sqlTypeLongVarbinary", e6[e6.sqlTypeLongVarchar = 13] = "sqlTypeLongVarchar", e6[e6.sqlTypeNChar = 14] = "sqlTypeNChar", e6[e6.sqlTypeNVarChar = 15] = "sqlTypeNVarChar", e6[e6.sqlTypeOther = 16] = "sqlTypeOther", e6[e6.sqlTypeReal = 17] = "sqlTypeReal", e6[e6.sqlTypeSmallInt = 18] = "sqlTypeSmallInt", e6[e6.sqlTypeSqlXml = 19] = "sqlTypeSqlXml", e6[e6.sqlTypeTime = 20] = "sqlTypeTime", e6[e6.sqlTypeTimestamp = 21] = "sqlTypeTimestamp", e6[e6.sqlTypeTimestamp2 = 22] = "sqlTypeTimestamp2", e6[e6.sqlTypeTinyInt = 23] = "sqlTypeTinyInt", e6[e6.sqlTypeVarbinary = 24] = "sqlTypeVarbinary", e6[e6.sqlTypeVarchar = 25] = "sqlTypeVarchar";
}(s4 || (s4 = {})), function(e6) {
  e6[e6.OID_ARRAY = 0] = "OID_ARRAY", e6[e6.GLOBALID_ARRAY = 1] = "GLOBALID_ARRAY", e6[e6.STRING_ARRAY = 2] = "STRING_ARRAY", e6[e6.IDENTIFIER_ARRAY = 3] = "IDENTIFIER_ARRAY";
}(T2 || (T2 = {}));

// node_modules/@arcgis/core/rest/knowledgeGraph/wasmInterface/wasmToFeatureFactories.js
function d7(s7) {
  const r9 = new t4();
  r9.version = s7.version;
  const n6 = s7.get_query_result();
  if (0 !== n6.results_type.value) throw new Error("Got a non-feature collection type");
  const l8 = n6.get_feature_result(), i6 = r9.queryResult.featureResult;
  i6.objectIdFieldName = l8.objectid_field_name, i6.exceededTransferLimit = l8.exceeded_transfer_limit, i6.hasM = l8.has_m, i6.hasZ = l8.has_z, i6.geometryType = i2[l8.geometry_type.value], i6.globalIdFieldName = l8.globalid_field_name, i6.geohashFieldName = l8.geohash_field_name;
  const c6 = i6.uniqueIdField, d10 = l8.unique_id_field;
  c6.name = d10.name, c6.isSystemMaintained = d10.isSystemMaintained;
  const p13 = i6.geometryProperties, _3 = l8.geometry_properties;
  p13.shapeAreaFieldName = _3.shapeAreaFieldName, p13.shapeLengthFieldName = _3.shapeLengthFieldName, p13.units = _3.units;
  const y6 = i6.spatialReference, h6 = l8.spatial_reference;
  y6.wkid = h6.wkid, y6.latestWkid = h6.latestWkid, y6.vcsWkid = h6.vcsWkid, y6.latestVcsWkid = h6.latestVcsWkid, y6.wkt = h6.wkt, i6.transform = g5(l8.transform);
  const v3 = i6.fields, T3 = i6.fieldNameToAttributeIndexMap, w3 = l8.fields, z = w3.size();
  for (let e6 = 0; e6 < z; e6++) {
    const t8 = w3.get(e6), a8 = m5(t8);
    v3.push(a8), T3[a8.name] = e6, t8.delete();
  }
  w3.delete();
  const F3 = i6.values, S5 = l8.values_count();
  for (let e6 = 0; e6 < S5; e6++) F3.push(l8.get_value_at(e6));
  const k2 = i6.features, b6 = l8.features, q2 = b6.size();
  if (q2 > 0) {
    for (const e6 of m4) if (void 0 === T3[e6]) throw new Error(`Feature collection missing required attribute: ${e6}`);
  }
  for (let e6 = 0; e6 < q2; e6++) {
    const t8 = new l5(), s8 = b6.get(e6), r10 = t8.attributes, n7 = s8.attributes_count();
    for (let e7 = 0; e7 < n7; e7++) r10.push(s8.get_attribute_at(e7));
    const o6 = s8.get_compressed_geometry();
    o6 && (t8.compressedGeometry = u3(o6), t8.centroid = u3(s8.get_centroid()));
    const l9 = t8.aggregateGeometries, i7 = s8.aggregate_geometries, c7 = i7.size();
    for (let e7 = 0; e7 < c7; e7++) {
      const t9 = i7.get(e7), a8 = u3(t9);
      l9.push(a8), t9.delete();
    }
    i7.delete(), k2.push(t8), s8.delete();
  }
  b6.delete();
  const W2 = i6.geometryFields, x = l8.geometry_fields, N2 = x.size();
  for (let e6 = 0; e6 < N2; e6++) {
    const t8 = x.get(e6), a8 = f7(t8);
    W2.push(a8), t8.delete();
  }
  return x.delete(), r9;
}
function u3(e6) {
  const t8 = new E3();
  t8.geometryType = i2[e6.geometry_type.value];
  const a8 = [], r9 = [];
  for (let s7 = 0; s7 < e6.lengths.length; s7++) a8.push(e6.lengths[s7]);
  for (let s7 = 0; s7 < e6.coords.length; s7++) r9.push(e6.coords[s7]);
  return t8.lengths = a8, t8.coords = r9, t8;
}
function m5(e6) {
  const t8 = new c3();
  return t8.name = e6.name, t8.alias = e6.alias, t8.fieldType = r5[e6.field_type.value], t8.sqlType = s4[e6.sql_type.value], t8.domain = e6.domain, t8.defaultValue = e6.default_value, t8;
}
function f7(e6) {
  const t8 = m5(e6);
  return t8.geometryType = i2[e6.geometry_type.value], t8;
}
function g5(e6) {
  const t8 = new h2();
  t8.quantizeOriginPosition = l6[e6.quantizeOriginPosition.value];
  const a8 = t8.scale, s7 = e6.scale;
  a8.xScale = s7.xScale, a8.yScale = s7.yScale, a8.mScale = s7.mScale, a8.zScale = s7.zScale;
  const r9 = t8.translate, o6 = e6.translate;
  return r9.xTranslate = o6.xTranslate, r9.yTranslate = o6.yTranslate, r9.mTranslate = o6.mTranslate, r9.zTranslate = o6.zTranslate, t8;
}

// node_modules/@arcgis/core/applications/KnowledgeStudio/resourceSerializationUtils.js
function p9(e6) {
  return __async(this, null, function* () {
    const t8 = [], r9 = { generateAllSublayers: false, namedTypeDefinitions: /* @__PURE__ */ new Map() };
    return e6.entitiesUrl && t8.push(E4(e6.entitiesUrl).then((e7) => {
      I3(e7, r9);
    })), e6.relationshipsUrl && t8.push(E4(e6.relationshipsUrl).then((e7) => {
      I3(e7, r9);
    })), yield Promise.all(t8), r9;
  });
}
function m6(e6, t8) {
  return __async(this, null, function* () {
    t8 ??= false;
    const r9 = { generateAllSublayers: t8, namedTypeDefinitions: /* @__PURE__ */ new Map() };
    return yield k(e6).then((e7) => {
      M(e7, r9);
    }), r9;
  });
}
function h3(e6) {
  return __async(this, null, function* () {
    const r9 = yield r4(), i6 = new r9.MapOfObjectIdentifierSets();
    b2(i6, r9, e6);
    const n6 = new r9.MapOfObjectIdentifierSetsEncoder();
    try {
      n6.set_map_of_identifier_sets(i6), n6.encode();
      const e7 = n6.get_encoding_result();
      if (0 !== e7.error.error_code) throw new s("knowledge-graph:layer-support-utils", e7.error.error_message);
      const r10 = structuredClone(e7.get_byte_buffer());
      return n6.delete(), r10;
    } finally {
      i6.delete();
    }
  });
}
function b2(e6, t8, r9) {
  for (const [i6, n6] of r9.namedTypeDefinitions) {
    if (!n6.members || n6.useAllData) continue;
    const r10 = n6.members.keys();
    let s7 = false, a8 = true;
    const o6 = new t8.ObjectIdArray(), l8 = new t8.StringArray(), c6 = new t8.GlobalIdArray(), d10 = new t8.IdentifierArray(), u5 = new t8.ObjectIdentifierSet();
    for (const e7 of r10) a8 && (s7 = !isNaN(Number(e7)), a8 = false), s7 ? o6.add_objectid(Number(e7)) : (l8.add_string(e7), c6.add_globalid(e7)), d10.add_identifier(e7);
    u5.set_oid_array(o6), u5.set_string_array(l8), u5.set_globalid_array(c6), u5.set_identifier_array(d10), o6.delete(), l8.delete(), c6.delete(), d10.delete(), e6.put_identifier_set(i6, u5), u5.delete();
  }
  return e6;
}
function E4(t8) {
  return __async(this, null, function* () {
    const r9 = yield P(t8, { responseType: "array-buffer" });
    return F2(yield r9.data);
  });
}
function F2(e6) {
  return __async(this, null, function* () {
    const r9 = new (yield r4()).FeatureCollectionDecoder(), i6 = r9.decode(new Uint8Array(e6));
    if (0 !== i6.error_code) throw new s("knowledge-graph:layer-support-utils", i6.error_message);
    const n6 = r9.get_feature_collection(), s7 = d7(n6);
    return r9.delete(), s7;
  });
}
function k(t8) {
  return __async(this, null, function* () {
    const r9 = yield P(t8, { responseType: "array-buffer" }), i6 = yield r9.data;
    return A(new Uint8Array(i6));
  });
}
function A(e6) {
  return __async(this, null, function* () {
    const r9 = new (yield r4()).MapOfObjectIdentifierSetsDecoder(), i6 = r9.decode(new Uint8Array(e6)), n6 = /* @__PURE__ */ new Map();
    if (0 !== i6.error_code) throw new s("knowledge-graph:layer-support-utils", i6.error_message);
    const s7 = r9.get_map_of_identifier_sets(), a8 = s7.keys, o6 = a8.size();
    for (let l8 = 0; l8 < o6; l8++) {
      const e7 = a8.get(l8), r10 = s7.query_identifier_set(e7), i7 = [];
      if (r10.id_array_type.value === T2.GLOBALID_ARRAY) {
        const e8 = r10.get_globalid_array(), t8 = e8.count();
        for (let r11 = 0; r11 < t8; r11++) i7.push(e8.get_globalid_at(r11));
      } else if (r10.id_array_type.value === T2.IDENTIFIER_ARRAY) {
        const e8 = r10.get_identifier_array(), t8 = e8.count();
        for (let r11 = 0; r11 < t8; r11++) i7.push(e8.get_identifier_at(r11).toString());
      } else if (r10.id_array_type.value === T2.STRING_ARRAY) {
        const e8 = r10.get_string_array(), t8 = e8.count();
        for (let r11 = 0; r11 < t8; r11++) i7.push(e8.get_string_at(r11));
      } else {
        if (r10.id_array_type.value !== T2.OID_ARRAY) throw new s("knowledge-graph:layer-support-utils", "Tried to encode an unexpected ID Array type.");
        {
          const e8 = r10.get_oid_array(), t8 = e8.count();
          for (let r11 = 0; r11 < t8; r11++) i7.push(e8.get_objectid_at(r11).toString());
        }
      }
      n6.set(e7, i7);
    }
    return r9.delete(), n6;
  });
}
function I3(e6, t8) {
  if (!e6?.queryResult?.featureResult) return t8;
  const i6 = e6.queryResult.featureResult.fieldNameToAttributeIndexMap;
  for (const s7 of e6.queryResult.featureResult.features) {
    const e7 = s7.attributes[i6[T.TYPENAME]], o6 = r2(t8.namedTypeDefinitions, e7, () => ({ useAllData: false, members: /* @__PURE__ */ new Map() })), l8 = s7.attributes[i6[T.ELEMENTUID]];
    if (s7.compressedGeometry?.coords?.length > 0) {
      let e8 = s7.compressedGeometry.lengths;
      "esriGeometryPoint" === s7.compressedGeometry.geometryType && (e8 = []), o6.members.set(l8, { id: l8, linkChartLocation: new e3(e8, s7.compressedGeometry.coords) });
    } else o6.members.set(l8, { id: l8 });
  }
  return t8;
}
function M(e6, t8) {
  for (const [i6, n6] of e6) {
    const e7 = r2(t8.namedTypeDefinitions, i6, () => ({ useAllData: false, members: /* @__PURE__ */ new Map() }));
    for (const t9 of n6) e7.members.has(t9) || e7.members.set(t9, { id: t9 });
  }
  return t8;
}
var D = { fetchAndConvertSerializedLinkChart: (e6) => p9(e6) };

// node_modules/@arcgis/core/layers/knowledgeGraph/SessionMemoryStorage.js
var o3 = class _o {
  constructor() {
    this._featureLookup = /* @__PURE__ */ new Map();
  }
  static getInstance() {
    return _o.instance || (_o.instance = new _o()), _o.instance;
  }
  static resetInstance() {
    _o.instance && (_o.instance = null);
  }
  deleteFromStore(e6) {
    e6.forEach((e7) => {
      this._featureLookup.delete(e7);
    });
  }
  readFromStoreByList(e6) {
    const t8 = [];
    return e6.forEach((e7) => {
      const r9 = this.readFromStoreById(e7);
      r9 && t8.push(r9);
    }), t8;
  }
  readFromStoreById(e6) {
    return this._featureLookup.get(e6) ?? null;
  }
  writeToStore(o6, n6, p13) {
    const a8 = [];
    return o6.forEach((o7) => {
      if (!o7?.id) return;
      o7.properties || (o7.properties = []);
      let u5, c6 = null;
      if (p13 && o7.properties[p13] && (c6 = st(o7.properties[p13])), "originId" in o7 && "destinationId" in o7 && (o7.properties[I] = o7.originId, o7.properties[t3] = o7.destinationId), o7.properties[n6] = o7.id, o7.id && this._featureLookup.has(o7.id) && this._featureLookup.get(o7.id).attributes) {
        const t8 = this._featureLookup.get(o7.id), i6 = JSON.parse(JSON.stringify(Object.assign(t8.attributes, o7.properties)));
        p13 && o7.properties[p13] && (i6[p13] = f(o7.properties[p13])), u5 = new s2(c6 ? JSON.parse(JSON.stringify(c6)) : t8?.geometry ? JSON.parse(JSON.stringify(t8.geometry)) : null, i6, null, o7.properties[n6]);
      } else u5 = new s2(c6 ? JSON.parse(JSON.stringify(c6)) : null, o7.properties, null, o7.properties[n6]);
      this._featureLookup.set(`${o7.typeName ? `${o7.typeName}__${o7.id}` : o7.id}`, u5), a8.push(u5);
    }), a8;
  }
};

// node_modules/@arcgis/core/libs/linkchartlayout/LinkChartLayout.js
var t5;
var r7 = null;
function a6() {
  return t5 || (t5 = import("./lclayout-TNUCHM6X.js").then((e6) => e6.l).then(({ default: t8 }) => t8({ locateFile: (t9) => n2(`esri/libs/linkchartlayout/${t9}`) })).then((e6) => {
    s5(e6);
  }), t5);
}
function s5(e6) {
  r7 = e6;
}
var i4;
var o4;
var u4;
var l7;
!function(e6) {
  e6[e6.None = 0] = "None", e6[e6.IsMovable = 1] = "IsMovable", e6[e6.IsGeographic = 2] = "IsGeographic", e6[e6.IsRoot = 4] = "IsRoot", e6[e6.IsOld = 8] = "IsOld";
}(i4 || (i4 = {})), function(e6) {
  e6[e6.Success = 0] = "Success", e6[e6.Error = 1] = "Error", e6[e6.Canceled = 2] = "Canceled";
}(o4 || (o4 = {})), function(e6) {
  e6[e6.Regular = 0] = "Regular", e6[e6.Curved = 1] = "Curved", e6[e6.Recursive = 2] = "Recursive";
}(u4 || (u4 = {})), function(e6) {
  e6[e6.right = 0] = "right", e6[e6.left = 1] = "left", e6[e6.top = 2] = "top", e6[e6.bottom = 3] = "bottom";
}(l7 || (l7 = {}));
var c4 = { none: 0, "start-only": 1, "start-and-end": 2 };
function y4(e6) {
  const t8 = __spreadProps(__spreadValues(__spreadValues({}, { timeDirection: "right", timeBannerUTCOffsetInMinutes: 0, eventsTicksVisualization: "start-and-end", showDurationLineForNonZeroDurationEntityEvents: true, durationLineWidth: 5, entityPositionAtDurationRatio: 1, showNonZeroDurationIntervalBounds: false, separateTimeOverlaps: true, separateTimelineOverlaps: true, moveFirstBends: true, secondBendRatio: 0.3, lineSeparationMultiplier: 1, spaceSeparatedLinesEvenly: false, useBezierCurves: false, separatedLineShapeRatio: 0 }), e6?.toJSON() ?? {}), { eventsTicksVisualization: e6?.eventsTicksVisualization ?? "start-and-end" });
  return __spreadProps(__spreadValues({}, t8), { timeDirection: { value: l7[t8.timeDirection] ?? l7.right }, eventsTicksVisualization: { value: c4[t8.eventsTicksVisualization] ?? c4["start-and-end"] } });
}
function E5(e6, t8, n6, a8, s7, i6) {
  const u5 = n6.length, l8 = s7.length, c6 = Float64Array.BYTES_PER_ELEMENT, y6 = Uint32Array.BYTES_PER_ELEMENT, E7 = Uint8Array.BYTES_PER_ELEMENT, p13 = 16, f10 = p13 + u5 * (E7 + 2 * c6) + l8 * (2 * y6), d10 = r7._malloc(f10);
  try {
    const E8 = d10 + p13 - d10 % p13, f11 = E8 + u5 * c6, v3 = f11 + u5 * c6, A3 = v3 + l8 * y6, b6 = A3 + l8 * y6, P4 = () => [r7.HEAPF64.subarray(E8 >> 3, (E8 >> 3) + u5), r7.HEAPF64.subarray(f11 >> 3, (f11 >> 3) + u5), r7.HEAPU32.subarray(v3 >> 2, (v3 >> 2) + l8), r7.HEAPU32.subarray(A3 >> 2, (A3 >> 2) + l8), r7.HEAPU8.subarray(b6, b6 + u5)], [_3, h6, m9, L3, g8] = P4();
    _3.set(n6), h6.set(a8), m9.set(s7), L3.set(i6), g8.set(t8);
    const C3 = e6(u5, b6, E8, f11, l8, v3, A3);
    let H = null, F3 = null;
    if (C3.value === o4.Success) {
      const e7 = r7.getLayoutLinksTypes(), t9 = r7.getLayoutLinksVerticesEndIndices(), n7 = r7.getLayoutLinksVertices(), a9 = r7.countLayoutLinksVertices();
      !l8 || e7 && t9 ? a9 && !n7 ? C3.value = o4.Error : (H = { types: new Uint8Array(r7.HEAPU8.subarray(e7, e7 + l8)), vertexEndIndex: new Uint32Array(r7.HEAPU32.subarray(t9 >> 2, (t9 >> 2) + l8)), vertices: new Float64Array(r7.HEAPF64.subarray(n7 >> 3, (n7 >> 3) + 2 * a9)) }, F3 = r7.getAuxiliaryGraphicElements()) : C3.value = o4.Error;
    }
    const [T3, R, B, U2, N2] = P4();
    return n6.set(T3), a8.set(R), s7.set(B), i6.set(U2), t8.set(N2), { status: C3.value, links: H, graphics: F3 };
  } finally {
    r7._free(d10), r7.cleanupLayout();
  }
}
var p10 = 2;
var f8 = 1;
var d8 = -1;
var v2;
var A2;
var b3;
var P3;
var _2;
var h4;
var m7;
var L2;
var g6;
!function(e6) {
  function t8() {
    return r7.getMinIdealEdgeLength();
  }
  function n6(e7, t9, n7, a8, s7, i6, o6 = p10, u5 = f8, l8 = d8) {
    return E5((t10, n8, a9, s8, i7, c6, y6) => r7.applyForceDirectedLayout(e7, t10, n8, a9, s8, i7, c6, y6, o6, u5, l8), t9, n7, a8, s7, i6);
  }
  e6.getMinIdealEdgeLength = t8, e6.apply = n6;
}(v2 || (v2 = {})), function(e6) {
  function t8(e7, t9, n6, a8, s7, i6, o6 = p10, u5 = f8, l8 = d8) {
    return E5((t10, n7, a9, s8, i7, c6, y6) => r7.applyCommunityLayout(e7, t10, n7, a9, s8, i7, c6, y6, o6, u5, l8), t9, n6, a8, s7, i6);
  }
  e6.apply = t8;
}(A2 || (A2 = {})), function(e6) {
  function t8(e7, t9, n6, a8, s7, i6) {
    return E5((t10, n7, a9, s8, i7, o6, u5) => r7.applySimpleLayout(e7, t10, n7, a9, s8, i7, o6, u5), t9, n6, a8, s7, i6);
  }
  e6.apply = t8;
}(b3 || (b3 = {})), function(e6) {
  function t8(e7, t9, n6, a8, s7, i6) {
    return E5((t10, n7, a9, s8, i7, o6, u5) => r7.applyHierarchicalLayout(e7, t10, n7, a9, s8, i7, o6, u5), t9, n6, a8, s7, i6);
  }
  e6.apply = t8;
}(P3 || (P3 = {})), function(e6) {
  function t8(e7, t9, n6, a8, s7, i6) {
    return E5((t10, n7, a9, s8, i7, o6, u5) => r7.applyRadialTreeLayout(e7, t10, n7, a9, s8, i7, o6, u5), t9, n6, a8, s7, i6);
  }
  e6.apply = t8;
}(_2 || (_2 = {})), function(e6) {
  function t8(e7, t9, n6, a8, s7, i6) {
    return E5((t10, n7, a9, s8, i7, o6, u5) => r7.applySmartTreeLayout(e7, t10, n7, a9, s8, i7, o6, u5), t9, n6, a8, s7, i6);
  }
  e6.apply = t8;
}(h4 || (h4 = {})), function(e6) {
  function t8(e7, t9, n6, a8, s7, i6, u5, l8, c6, p13, f10, d10) {
    return E5((t10, n7, a9, u6, l9, E7, v3) => {
      if (s7.length !== t10) return { value: o4.Error };
      if (i6.length !== t10) return { value: o4.Error };
      if (c6.length !== l9) return { value: o4.Error };
      if (p13.length !== l9) return { value: o4.Error };
      const A3 = Float64Array.BYTES_PER_ELEMENT, b6 = 16, P4 = r7._malloc(b6 + t10 * A3), _3 = r7._malloc(b6 + t10 * A3), h6 = r7._malloc(b6 + l9 * A3), m9 = r7._malloc(b6 + l9 * A3), L3 = P4 + b6 - P4 % b6, g8 = _3 + b6 - _3 % b6, C3 = h6 + b6 - h6 % b6, H = m9 + b6 - m9 % b6;
      try {
        return r7.HEAPF64.subarray(L3 >> 3, (L3 >> 3) + t10).set(s7), r7.HEAPF64.subarray(g8 >> 3, (g8 >> 3) + t10).set(i6), r7.HEAPF64.subarray(C3 >> 3, (C3 >> 3) + l9).set(c6), r7.HEAPF64.subarray(H >> 3, (H >> 3) + l9).set(p13), r7.applyChronologicalLayout(e7, t10, n7, a9, u6, L3, g8, l9, E7, v3, C3, H, f10, y4(d10));
      } finally {
        r7._free(P4), r7._free(_3), r7._free(h6), r7._free(m9);
      }
    }, t9, n6, a8, u5, l8);
  }
  e6.apply = t8;
}(m7 || (m7 = {})), function(e6) {
  e6[e6.Undirected = 0] = "Undirected", e6[e6.Directed = 1] = "Directed", e6[e6.Reversed = 2] = "Reversed";
}(L2 || (L2 = {})), function(e6) {
  e6[e6.ByCC_Raw = 0] = "ByCC_Raw", e6[e6.ByCC_NormalizeGlobally = 1] = "ByCC_NormalizeGlobally", e6[e6.ByCC_NormalizeByCC = 2] = "ByCC_NormalizeByCC";
}(g6 || (g6 = {}));

// node_modules/@arcgis/core/linkChart/enums.js
var o5 = i()({ none: "none", startAndEnd: "start-and-end", startOnly: "start-only" });
var r8 = i()({ absoluteValue: "absolute-value", multiplier: "multiplier" });
var a7 = /* @__PURE__ */ new Map([["basic-grid", "basic-grid"], ["geographic-organic-standard", "geographic-organic-standard"], ["hierarchical-bottom-to-top", "hierarchical-bottom-to-top"], ["hierarchical-top-to-bottom", "hierarchical-bottom-to-top"], ["organic-community", "organic-community"], ["organic-fusiform", "organic-standard"], ["organic-leaf-circle", "organic-standard"], ["organic-standard", "organic-standard"], ["radial-node-centric", "radial-root-centric"], ["radial-root-centric", "radial-root-centric"], ["tree-bottom-to-top", "tree-left-to-right"], ["tree-left-to-right", "tree-left-to-right"], ["tree-right-to-left", "tree-left-to-right"], ["tree-top-to-bottom", "tree-left-to-right"], ["chronological-mono-timeline", "chronological-mono-timeline"], ["chronological-multi-timeline", "chronological-multi-timeline"]]);

// node_modules/@arcgis/core/layers/knowledgeGraph/supportUtils.js
function d9(o6, e6) {
  const t8 = /* @__PURE__ */ new Map();
  if (e6.dataModel?.relationshipTypes) for (const r9 of e6.dataModel.relationshipTypes) r9.name && t8.set(r9.name, []);
  for (const r9 of o6) t8.has(r9.typeName) && t8.get(r9.typeName)?.push(r9.id);
  return t8;
}
function g7(o6, e6, t8) {
  return __async(this, null, function* () {
    const r9 = [], n6 = d9(o6, e6), i6 = {}, s7 = [];
    for (const [c6, y6] of n6) {
      if (y6.length < 1) continue;
      const o7 = `${c6}_ids`;
      i6[o7] = y6, s7.push(`MATCH (n)-[r:${c6}]->(m) WHERE id(r) in $${o7} RETURN id(n), labels(n)[0], id(m), labels(m)[0]`);
    }
    if (0 === s7.length) return [];
    const a8 = s7.join(" UNION "), l8 = new p8({ openCypherQuery: a8, bindParameters: i6 }), m9 = (yield F(e6, l8, t8?.requestOptions)).resultRowsStream.getReader();
    for (; ; ) {
      const { done: o7, value: e7 } = yield m9.read();
      if (o7) break;
      for (const t9 of e7) r9.push({ id: t9[0], typeName: t9[1] }), r9.push({ id: t9[2], typeName: t9[3] });
    }
    return r9;
  });
}
var C2 = (o6) => a7.get(o6) ?? "radial-root-centric";
function S4(o6) {
  if (!o6.spatialReference.isWGS84) throw new s("knowledge-graph:layer-support-utils", "The utilsExtentToInBoundsRings function only supports WGS84 spatial references.");
  return o6.clone().normalize().map((o7) => [[o7.xmin, o7.ymin], [o7.xmin, o7.ymax], [o7.xmax, o7.ymax], [o7.xmax, o7.ymin], [o7.xmin, o7.ymin]]);
}

// node_modules/@arcgis/core/layers/knowledgeGraph/KnowledgeGraphLayerDataManager.js
var E6 = class extends g {
  constructor(e6) {
    super(e6), this._processingCacheUpdatesLookup = /* @__PURE__ */ new Map(), this.knowledgeGraph = null, this.inclusionModeDefinition = { generateAllSublayers: true, namedTypeDefinitions: /* @__PURE__ */ new Map() }, this.entityTypeNames = /* @__PURE__ */ new Set(), this.relationshipTypeNames = /* @__PURE__ */ new Set(), this.geographicLookup = /* @__PURE__ */ new Map(), this.sublayerCaches = /* @__PURE__ */ new Map(), this.nodeConnectionsLookup = /* @__PURE__ */ new Map(), this.relationshipConnectionsLookup = /* @__PURE__ */ new Map(), this.memberIdTypeLookup = /* @__PURE__ */ new Map();
    const t8 = /* @__PURE__ */ new Map();
    e6.knowledgeGraph.dataModel.entityTypes?.forEach((i6) => {
      i6.name && (t8.set(i6.name, "entity"), this._processingCacheUpdatesLookup.set(i6.name, []), e6.inclusionModeDefinition && !e6.inclusionModeDefinition?.generateAllSublayers || this.entityTypeNames.add(i6.name), i6.properties?.forEach((e7) => {
        e7.geometryType && "esriGeometryNull" !== e7.geometryType && this.geographicLookup.set(i6.name, { name: e7.name ?? "", geometryType: e7.geometryType });
      }));
    }), e6.knowledgeGraph.dataModel.relationshipTypes?.forEach((i6) => {
      i6.name && (t8.set(i6.name, "relationship"), this._processingCacheUpdatesLookup.set(i6.name, []), e6.inclusionModeDefinition && !e6.inclusionModeDefinition?.generateAllSublayers || this.relationshipTypeNames.add(i6.name), i6.properties?.forEach((e7) => {
        e7.geometryType && "esriGeometryNull" !== e7.geometryType && this.geographicLookup.set(i6.name, { name: e7.name ?? "", geometryType: e7.geometryType });
      }));
    }), e6.inclusionModeDefinition?.namedTypeDefinitions.forEach((i6, s7) => {
      if ("entity" === t8.get(s7)) this.entityTypeNames.add(s7);
      else {
        if ("relationship" !== t8.get(s7)) return n.getLogger(this).warn(`A named type, ${s7}, was in the inclusion list that wasn't in the data model and will be removed`), void e6.inclusionModeDefinition?.namedTypeDefinitions.delete(s7);
        this.relationshipTypeNames.add(s7);
      }
      const a8 = /* @__PURE__ */ new Map();
      i6.members?.forEach((e7) => {
        r2(this.memberIdTypeLookup, e7.id, () => /* @__PURE__ */ new Set()).add(s7);
        const t9 = this.getById(e7.id);
        t9 && a8.set(e7.id, t9);
      }), this.sublayerCaches.set(s7, a8);
    });
  }
  addToLayer(e6) {
    e6.forEach(({ typeName: e7, id: t8 }) => {
      if (!this.inclusionModeDefinition) throw new s("knowledge-graph:layer-data-manager", "You cannot add to a layer's exclusion list if it was not created with an exclusion list originally");
      if (this.inclusionModeDefinition.namedTypeDefinitions.has(e7)) {
        if (this.inclusionModeDefinition.namedTypeDefinitions.has(e7)) {
          const i6 = this.inclusionModeDefinition.namedTypeDefinitions.get(e7);
          i6.members || (i6.members = /* @__PURE__ */ new Map()), i6.members.set(t8, { id: t8 }), r2(this.memberIdTypeLookup, t8, () => /* @__PURE__ */ new Set()).add(e7);
        }
      } else {
        const i6 = /* @__PURE__ */ new Map();
        i6.set(t8, { id: t8 }), this.inclusionModeDefinition.namedTypeDefinitions.set(e7, { useAllData: false, members: i6 }), r2(this.memberIdTypeLookup, t8, () => /* @__PURE__ */ new Set()).add(e7);
      }
    });
  }
  getById(e6) {
    return o3.getInstance().readFromStoreById(e6);
  }
  getData(e6, t8, i6) {
    return __async(this, null, function* () {
      if (t8.objectType.name && this.inclusionModeDefinition?.namedTypeDefinitions && this.inclusionModeDefinition.namedTypeDefinitions.size > 0 && !this.inclusionModeDefinition.namedTypeDefinitions.has(t8.objectType.name)) return [];
      let n6;
      if (n6 = e6 || new b({ where: "1=1", outFields: ["*"] }), "link-chart" === t8.parentCompositeLayer.type) {
        const e7 = t8.parentCompositeLayer, i7 = this._processingCacheUpdatesLookup.get(t8.objectType.name ?? ""), o6 = n6.outFields;
        o6 && 1 === o6.length && o6[0] === _ && "1=1" === n6.where || (yield Promise.all(i7 ?? []));
        const s7 = this.sublayerCaches.has(t8.objectType.name ?? "") ? Array.from(this.sublayerCaches.get(t8.objectType.name)?.values()) : [], a8 = [];
        return s7.forEach((i8) => {
          if (this.relationshipTypeNames.has(t8.objectType.name)) {
            i8.geometry = e7.relationshipLinkChartDiagramLookup.get(i8.attributes[t8.objectIdField]);
            const n7 = this.memberIdTypeLookup.get(i8.attributes[I]), o7 = this.memberIdTypeLookup.get(i8.attributes[t3]), s8 = this._isEndEntitySpatial(n7, i8, I), a9 = this._isEndEntitySpatial(o7, i8, t3);
            i8.attributes[E] = Number(s8 && a9);
          } else {
            i8.geometry = e7.entityLinkChartDiagramLookup.get(i8.attributes[t8.objectIdField]);
            const n7 = this.geographicLookup.get(t8.objectType.name);
            n7 && i8.attributes[n7.name] ? i8.attributes[E] = 1 : i8.attributes[E] = 0;
          }
          i8.attributes[S2] = i8.geometry, a8.push(i8);
        }), a8;
      }
      return this.retrieveDataFromService(n6, t8, i6);
    });
  }
  getConnectedRecordIds(e6, t8, i6) {
    return __async(this, null, function* () {
      const n6 = [];
      let o6 = "";
      const s7 = this._getNamedTypeIdMapFromNodeIds(e6);
      if (t8 && 0 !== t8?.length) {
        for (const e7 of t8) o6 = o6 + e7 + "|";
        o6 = o6.slice(0, -1);
      }
      const a8 = {}, r9 = [];
      for (const [l8, m9] of s7) {
        const e7 = `${l8}_ids`;
        a8[e7] = m9, t8 && 0 !== t8?.length ? r9.push(`MATCH (n:${l8}) WHERE id(n) IN $${e7} WITH n MATCH (n)-[r:${o6}]-(m) RETURN id(r), type(r), id(m), labels(m)[0]`) : r9.push(`MATCH (n:${l8}) WHERE id(n) IN $${e7} WITH n MATCH (n)-[r]-(m) RETURN id(r), type(r), id(m), labels(m)[0]`);
      }
      if (!r9.length) return n6;
      const p13 = r9.join(" UNION "), d10 = (yield F(this.knowledgeGraph, new p8({ openCypherQuery: p13, bindParameters: a8 }), { signal: i6?.signal })).resultRowsStream.getReader();
      for (; ; ) {
        const { done: e7, value: t9 } = yield d10.read();
        if (e7) break;
        for (let i7 = 0; i7 < t9.length; i7++) {
          const e8 = t9[i7];
          n6.push({ id: e8[0], typeName: e8[1] }), n6.push({ id: e8[2], typeName: e8[3] });
        }
      }
      return n6;
    });
  }
  getRelationshipsBetweenNodes(e6, t8, i6) {
    return __async(this, null, function* () {
      const n6 = this._getNamedTypeIdMapFromNodeIds(e6);
      if (0 === n6.size) return [];
      const o6 = { relationshipExclusionIds: t8, possibleConnectionEntityIds: e6 }, s7 = [];
      for (const [d10, l8] of n6.entries()) {
        const e7 = `${d10}_ids`;
        o6[e7] = l8, s7.push(`MATCH (n:${d10}) WHERE id(n) IN $${e7} WITH n MATCH (n)-[r]->(m) WHERE id(m) IN $possibleConnectionEntityIds AND NOT id(r) IN $relationshipExclusionIds RETURN id(r), type(r)`);
      }
      const a8 = s7.join(" UNION "), r9 = [], p13 = (yield F(this.knowledgeGraph, new p8({ openCypherQuery: a8, bindParameters: o6 }), { signal: i6?.signal })).resultRowsStream.getReader();
      for (; ; ) {
        const { done: e7, value: t9 } = yield p13.read();
        if (e7) break;
        for (let i7 = 0; i7 < t9.length; i7++) {
          const e8 = t9[i7];
          r9.push({ id: e8[0], typeName: e8[1] });
        }
      }
      return r9;
    });
  }
  getRelationshipsFromNodes(e6, t8, i6, n6) {
    return __async(this, null, function* () {
      const o6 = this._getNamedTypeIdMapFromNodeIds(e6);
      if (0 === o6.size || 0 === t8.length) return [];
      const s7 = { relationshipExclusionIds: i6, possibleConnectionEntityIds: t8 }, a8 = [];
      for (const [m9, h6] of o6.entries()) {
        const e7 = `${m9}_ids`;
        s7[e7] = h6, a8.push(`MATCH (n:${m9}) WHERE id(n) IN $${e7} WITH n MATCH (n)-[r]-(m) WHERE id(m) IN $possibleConnectionEntityIds AND NOT id(r) IN $relationshipExclusionIds RETURN id(r), type(r)`);
      }
      const r9 = a8.join(" UNION "), p13 = /* @__PURE__ */ new Map(), d10 = (yield F(this.knowledgeGraph, new p8({ openCypherQuery: r9, bindParameters: s7 }), { signal: n6?.signal })).resultRowsStream.getReader();
      for (; ; ) {
        const { done: e7, value: t9 } = yield d10.read();
        if (e7) break;
        for (let i7 = 0; i7 < t9.length; i7++) {
          const e8 = t9[i7];
          let n7 = p13.get(e8[1]);
          n7 || (n7 = /* @__PURE__ */ new Set(), p13.set(e8[1], n7)), n7.add(e8[0]);
        }
      }
      const l8 = [];
      for (const [m9, h6] of p13) for (const e7 of h6) l8.push({ id: e7, typeName: m9 });
      return l8;
    });
  }
  refreshCacheContent(e6, t8, n6, a8 = true, r9) {
    return __async(this, null, function* () {
      const p13 = o3.getInstance(), d10 = [], l8 = /* @__PURE__ */ new Map(), m9 = /* @__PURE__ */ new Map();
      this.knowledgeGraph.dataModel.entityTypes?.forEach((e7) => {
        e7.name && m9.set(e7.name, e7);
      }), this.knowledgeGraph.dataModel.relationshipTypes?.forEach((e7) => {
        e7.name && m9.set(e7.name, e7);
      }), e6 || this.inclusionModeDefinition ? e6 ? e6.forEach((e7) => {
        if (this.memberIdTypeLookup.has(e7)) for (const t9 of this.memberIdTypeLookup.get(e7)) l8.has(t9) ? l8.get(t9)?.push(e7) : l8.set(t9, [e7]);
      }) : this.inclusionModeDefinition?.namedTypeDefinitions?.forEach((e7, t9) => {
        e7.useAllData ? l8.set(t9, null) : e7.members && e7.members.forEach((e8) => {
          l8.has(t9) && null !== l8.get(t9) ? l8.get(t9)?.push(e8.id) : l8.set(t9, [e8.id]);
        });
      }) : (this.knowledgeGraph.dataModel.entityTypes?.forEach((e7) => {
        e7.name && l8.set(e7.name, null);
      }), this.knowledgeGraph.dataModel.entityTypes?.forEach((e7) => {
        e7.name && l8.set(e7.name, null);
      }));
      for (const [s7, h6] of l8) {
        const e7 = new Set(h6), l9 = new Promise((d11, l10) => {
          const c6 = () => __async(this, null, function* () {
            const d12 = /* @__PURE__ */ new Set(), l11 = [];
            let c7, u5 = "", f10 = false;
            if (t8 || m9.get(s7)?.properties?.forEach((e8) => {
              e8.name && d12.add(e8.name);
            }), n6 && this.geographicLookup.has(s7)) {
              const e8 = this.geographicLookup.get(s7)?.name;
              e8 && d12.add(e8);
            }
            if (this.entityTypeNames.has(s7)) u5 = `MATCH (n:${s7}) ${h6 ? "WHERE id(n) IN $ids " : ""}return ID(n)`, d12.forEach((e8) => {
              u5 += `, n.${e8}`, l11.push(e8);
            });
            else {
              if (!this.relationshipTypeNames.has(s7)) throw new s("knowledge-graph:layer-data-manager", `The graph type of ${s7} could not be determined. Was this type set in the KG data model and inclusion definition?`);
              f10 = true, u5 = `MATCH ()-[n:${s7}]->() ${h6 ? "WHERE id(n) IN $ids " : ""}return ID(n), id(startNode(n)), id(endNode(n))`, d12.forEach((e8) => {
                u5 += `, n.${e8}`, l11.push(e8);
              });
            }
            c7 = new p8(h6 ? { openCypherQuery: u5, bindParameters: { ids: h6 } } : { openCypherQuery: u5 });
            const g8 = (yield F(this.knowledgeGraph, c7, { signal: r9?.signal })).resultRowsStream.getReader();
            for (; ; ) {
              const { done: t9, value: i6 } = yield g8.read();
              if (t9) break;
              const n7 = [];
              for (let s8 = 0; s8 < i6.length; s8++) {
                const t10 = i6[s8];
                let a9 = 0, r11 = 0;
                const p14 = { properties: {} };
                for (p14.id = t10[a9], a9++, r11++, f10 && (p14.originId = t10[a9], a9++, r11++, p14.destinationId = t10[a9], a9++, r11++, r2(this.nodeConnectionsLookup, p14.originId, () => /* @__PURE__ */ new Set()).add(p14.id), r2(this.nodeConnectionsLookup, p14.destinationId, () => /* @__PURE__ */ new Set()).add(p14.id), r2(this.relationshipConnectionsLookup, p14.id, () => [p14.originId, p14.destinationId])); a9 < t10.length; a9++) p14.properties[l11[a9 - r11]] = t10[a9];
                e7.delete(p14.id), n7.push(p14);
              }
              const r10 = p13.writeToStore(n7, _, this.geographicLookup.get(s7)?.name);
              this.sublayerCaches.has(s7) || this.sublayerCaches.set(s7, /* @__PURE__ */ new Map()), a8 && !this.inclusionModeDefinition?.namedTypeDefinitions.has(s7) && this.inclusionModeDefinition?.namedTypeDefinitions.set(s7, { useAllData: false, members: /* @__PURE__ */ new Map() }), a8 && !this.inclusionModeDefinition?.namedTypeDefinitions.get(s7).members && (this.inclusionModeDefinition.namedTypeDefinitions.get(s7).members = /* @__PURE__ */ new Map());
              const d13 = this.sublayerCaches.get(s7);
              r10.forEach((e8) => {
                d13?.set(e8.attributes[_], e8), a8 && !this.inclusionModeDefinition?.namedTypeDefinitions.get(s7).members.has(e8.attributes[_]) && (this.inclusionModeDefinition?.namedTypeDefinitions.get(s7).members.set(e8.attributes[_], { id: e8.attributes[_] }), r2(this.memberIdTypeLookup, e8.attributes[_], () => /* @__PURE__ */ new Set()).add(s7));
              });
            }
            const b6 = this.inclusionModeDefinition?.namedTypeDefinitions.get(s7);
            if (b6) for (const t9 of e7) b6.members?.delete(t9);
          });
          c6().then(() => {
            d11(null);
          }).catch((e8) => {
            "AbortError" === e8.name ? d11(null) : l10(e8);
          });
        });
        d10.push(l9), this._processingCacheUpdatesLookup.get(s7)?.push(l9);
      }
      if (yield Promise.all(d10), r9?.signal?.aborted) throw u();
    });
  }
  removeFromLayer(e6) {
    const t8 = /* @__PURE__ */ new Set(), i6 = new Set(e6.map((e7) => e7.id));
    for (const n6 of e6) t8.add(n6.typeName), 1 === this.memberIdTypeLookup.get(n6.id)?.size ? this.memberIdTypeLookup.delete(n6.id) : this.memberIdTypeLookup.get(n6.id)?.delete(n6.typeName), this.inclusionModeDefinition?.namedTypeDefinitions.forEach((e7, t9) => {
      t9 === n6.typeName && e7.members?.has(n6.id) && e7.members.delete(n6.id);
    });
    t8.forEach((e7) => {
      this.sublayerCaches.get(e7)?.forEach((t9, n6) => {
        i6.has(n6) && this.sublayerCaches.get(e7)?.delete(n6);
      });
    });
  }
  retrieveDataFromService(e6, t8, n6) {
    return __async(this, null, function* () {
      const o6 = o3.getInstance(), s7 = /* @__PURE__ */ new Set(), r9 = [];
      let p13, u5 = "", f10 = [];
      const g8 = "relationship" === t8.graphType, b6 = this.inclusionModeDefinition?.namedTypeDefinitions?.get(t8.objectType.name)?.useAllData, D2 = t8.parentCompositeLayer.sublayerIdsCache.get(t8.objectType.name);
      let E7 = !b6 && D2 ? Array.from(D2).sort() : null;
      if (this.inclusionModeDefinition?.namedTypeDefinitions?.get(t8.objectType.name)?.useAllData) this.inclusionModeDefinition?.namedTypeDefinitions?.get(t8.objectType.name)?.useAllData && null != e6.objectIds && (E7 = e6.objectIds);
      else if (null != e6.objectIds && E7 && E7.length > 0) {
        const t9 = e6.objectIds;
        e6.objectIds = E7.filter((e7) => t9.includes(e7));
      } else if (null != e6.objectIds) E7 = e6.objectIds;
      else {
        if (this.inclusionModeDefinition?.namedTypeDefinitions.has(t8.objectType.name) && (!this.inclusionModeDefinition.namedTypeDefinitions.get(t8.objectType.name)?.members || this.inclusionModeDefinition.namedTypeDefinitions.get(t8.objectType.name)?.members?.size < 1)) return e6.objectIds = [], [];
        e6.objectIds = E7;
      }
      if (null != e6.outFields) {
        const i6 = e6.outFields;
        i6.includes("*") ? t8.fields.forEach((e7) => {
          s7.add(e7.name);
        }) : i6.forEach((e7) => {
          e7 !== _ && e7 !== t8.geometryFieldName && s7.add(e7);
        });
      }
      if (null != e6.geometry) {
        const n7 = e6.geometry;
        let o7;
        const y6 = t8.parentCompositeLayer.dataManager.knowledgeGraph.serviceDefinition, f11 = y6?.spatialReference, b7 = y6?.serviceCapabilities?.geometryCapabilities;
        let w3 = b7?.geometryMaxBoundingRectangleSizeX, I4 = b7?.geometryMaxBoundingRectangleSizeY;
        if ("point" === n7.type) {
          let e7 = n7;
          e7.spatialReference?.isWGS84 || (yield Q(e7.spatialReference, U), e7 = O(e7, U)), o7 = new w({ spatialReference: U, xmin: e7.x - 1e-4, ymin: e7.y - 1e-4, xmax: e7.x + 1e-4, ymax: e7.y + 1e-4 });
        } else n7?.extent?.spatialReference && !n7.spatialReference?.isWGS84 ? (yield Q(n7.extent.spatialReference, U), o7 = O(n7.extent, U)) : o7 = n7.extent;
        if (w3 && I4 && f11) {
          if (4326 !== f11.wkid) {
            const e7 = new w({ spatialReference: f11, xmax: w3, ymax: I4 }), t9 = O(e7, U);
            w3 = t9.xmax, I4 = t9.ymax;
          }
          if (o7.xmax - o7.xmin > w3) throw new s("knowledge-graph:layer-data-manager", `Extent x bounds should be within ${w3}° latitude, limit exceeded`);
          if (o7.ymax - o7.ymin > I4) throw new s("knowledge-graph:layer-data-manager", `Extent y bounds should be within ${I4}° longitude, limit exceeded`);
        }
        if (null != e6.where && "1=1" !== e6.where) {
          const i6 = yield e2(e6.where.toUpperCase(), t8.fieldsIndex);
          t8.fields.forEach((e7) => {
            i6.fieldNames.includes(e7.name) && s7.add(e7.name);
          });
        }
        u5 = g8 ? `Match ()-[n:${t8.objectType.name}]->() WHERE esri.graph.ST_Intersects($param_filter_geom, n.${t8.geometryFieldName}) return ID(n), id(startNode(r)), id(endNode(r))` : `Match (n:${t8.objectType.name}) WHERE esri.graph.ST_Intersects($param_filter_geom, n.${t8.geometryFieldName}) return ID(n)`, t8.geometryFieldName && s7.add(t8.geometryFieldName), s7.forEach((e7) => {
          u5 += `, n.${e7}`, r9.push(e7);
        }), p13 = new p8({ openCypherQuery: u5, bindParameters: { param_filter_geom: new j2({ rings: S4(o7) }) } });
      } else {
        let i6 = "";
        if (null != e6.where && "1=1" !== e6.where) {
          const n8 = yield e2(e6.where, t8.fieldsIndex);
          t8.fields.forEach((e7) => {
            n8.fieldNames.includes(e7.name) && s7.add(e7.name);
          });
          const o8 = /* @__PURE__ */ new Set(["column-reference", "string", "number", "binary-expression"]), r10 = /* @__PURE__ */ new Set(["=", "<", "<=", "<>", ">", ">=", "AND", "OR", "LIKE"]);
          let p14 = false;
          const d10 = (e7) => {
            if ("column-reference" === e7.type) return `n.${e7.column}`;
            if ("string" === e7.type) return `'${e7.value}'`;
            if ("number" === e7.type) return `${e7.value}`;
            if ("binary-expression" === e7.type && o8.has(e7.left.type) && o8.has(e7.right.type) && r10.has(e7.operator)) return `${d10(e7.left)} ${e7.operator} ${d10(e7.right)}`;
            if ("binary-expression" === e7.type && "LIKE" === e7.operator) {
              let t9 = "";
              if ("function" === e7.left.type && "column-reference" === e7.left.args.value[0].type) t9 += `lower(n.${e7.left.args.value[0].column})`;
              else {
                if ("column-reference" !== e7.left.type) return p14 = true, "";
                t9 += `lower(n.${e7.left.column})`;
              }
              if (t9 += " CONTAINS (", "string" !== e7.right.type) return p14 = true, "";
              {
                let i7 = e7.right.value;
                "%" === i7.charAt(0) && (i7 = i7.slice(1)), "%" === i7.charAt(i7.length - 1) && (i7 = i7.slice(0, -1)), t9 += `'${i7.toLowerCase()}')`;
              }
              return t9;
            }
            return p14 = true, "";
          };
          i6 = d10(n8.parseTree), p14 && (i6 = "");
        }
        let n7 = "";
        n7 = g8 ? `Match ()-[n:${t8.objectType.name}]->()` : `Match (n:${t8.objectType.name})`;
        let o7 = false;
        E7 && (o7 = true, n7 += " WHERE ID(n) IN $ids"), i6 && (n7 += o7 ? " AND" : " WHERE", n7 += ` ${i6}`), n7 += " return ID(n)", g8 && (n7 += ", id(startNode(n)), id(endNode(n))"), e6.returnGeometry && t8.geometryFieldName && s7.add(t8.geometryFieldName), s7.forEach((e7) => {
          n7 += `, n.${e7}`, r9.push(e7);
        }), p13 = new p8(E7 ? { openCypherQuery: n7, bindParameters: { ids: E7 } } : { openCypherQuery: n7 });
      }
      const N2 = (yield F(t8.parentCompositeLayer.dataManager.knowledgeGraph, p13, n6)).resultRowsStream.getReader();
      for (; ; ) {
        const { done: e7, value: i6 } = yield N2.read();
        if (e7) break;
        const n7 = [];
        for (let t9 = 0; t9 < i6.length; t9++) {
          const e8 = i6[t9];
          let o7 = 0, s8 = 0;
          const a8 = { properties: {} };
          for (a8.id = e8[o7], o7++, s8++, g8 && (a8.originId = e8[o7], o7++, s8++, a8.destinationId = e8[o7], o7++, s8++); o7 < e8.length; o7++) a8.properties[r9[o7 - s8]] = e8[o7];
          n7.push(a8);
        }
        f10 = f10.concat(o6.writeToStore(n7, _, t8.parentCompositeLayer.dataManager.geographicLookup.get(t8.objectType.name)?.name));
      }
      return f10;
    });
  }
  _isEndEntitySpatial(e6, t8, i6) {
    for (const n6 of e6 ?? []) if (this.entityTypeNames.has(n6)) {
      const e7 = this.geographicLookup.get(n6), o6 = e7 && this.sublayerCaches.get(n6)?.get(t8.attributes[i6]);
      if (e7 && o6?.attributes[e7.name]) return true;
    }
    return false;
  }
  _getNamedTypeIdMapFromNodeIds(e6) {
    const t8 = /* @__PURE__ */ new Map();
    return e6.forEach((e7) => {
      if (this.memberIdTypeLookup.has(e7)) for (const i6 of this.memberIdTypeLookup.get(e7)) {
        if (!this.entityTypeNames.has(i6)) return;
        t8.has(i6) ? t8.get(i6)?.push(e7) : t8.set(i6, [e7]);
      }
    }), t8;
  }
};
r([m()], E6.prototype, "knowledgeGraph", void 0), r([m()], E6.prototype, "inclusionModeDefinition", void 0), r([m()], E6.prototype, "entityTypeNames", void 0), r([m()], E6.prototype, "relationshipTypeNames", void 0), r([m()], E6.prototype, "geographicLookup", void 0), r([m()], E6.prototype, "sublayerCaches", void 0), r([m()], E6.prototype, "nodeConnectionsLookup", void 0), r([m()], E6.prototype, "relationshipConnectionsLookup", void 0), r([m()], E6.prototype, "memberIdTypeLookup", void 0), E6 = r([a2("esri.layers.knowledgeGraph.KnowledgeGraphLayerDataManager")], E6);

// node_modules/@arcgis/core/layers/knowledgeGraph/layerUtils.js
var t6 = { initializeLayersFromClientData: (e6, n6, o6) => __async(void 0, null, function* () {
  if (n6 || (n6 = [...e6.layers, ...e6.tables].map((e7) => e7.graphTypeName)), 0 === n6?.length) return;
  const r9 = /* @__PURE__ */ new Map();
  for (const a8 of n6) r9.set(a8, s6(e6, a8));
  const l8 = yield W(e6.dataManager.knowledgeGraph, Array.from(r9.values()), { requestOptions: { signal: o6?.signal } });
  for (const a8 of [...e6.layers, ...e6.tables]) {
    const n7 = a8.objectType.name;
    if (null == n7) continue;
    const o7 = l8.get(s6(e6, n7));
    if (o7) {
      const e7 = JSON.parse(o7);
      null === e7 || "object" != typeof e7 || e7.hasOwnProperty("showLabels") || (e7.showLabels = false), a8.read(e7, { origin: "service" });
    }
  }
}) };
var s6 = (e6, n6) => "knowledge-graph" === e6.type ? `${n6}/Map` : `${n6}/LinkChart/LinkChartSubLayer`;
function i5(e6, n6, o6) {
  return __async(this, null, function* () {
    return t6.initializeLayersFromClientData(e6, n6, o6);
  });
}
var b5 = ["#4a0932", "#b31515", "#18382e", "#a64f1b", "#102432", "#8c213f", "#ed9310", "#2c6954", "#144d59", "#ffc730", "#75351e", "#454f4b", "#78b1c2", "#191921", "#8f8f82", "#9be0c0", "#dbb658", "#87b051", "#11495c", "#c43541", "#9c5596", "#44498b", "#ad9d63", "#86afb3", "#5c98ca", "#b0bfa2", "#73241f", "#b86b53", "#d9d78c", "#3e756d", "#f260a1", "#a0d17d", "#c27c30", "#eb82eb", "#ffdf3c", "#ffb259", "#ab52b3", "#3cccb4", "#0095ba", "#d92b30"];
var c5 = "#8f8f82";
function f9(n6) {
  return n6 < 0 || n6 >= b5.length ? new h(c5) : new h(b5[n6]);
}
function m8(e6) {
  const n6 = e6.toArray();
  return new d2({ data: { type: "CIMSymbolReference", symbol: { type: "CIMLineSymbol", symbolLayers: [{ type: "CIMSolidStroke", enable: true, style: "solid", width: 0.75, color: n6 }, { type: "CIMVectorMarker", enable: true, size: 6, markerPlacement: { type: "CIMMarkerPlacementOnLine", angleToLine: true, relativeTo: "LineMiddle" }, frame: { xmin: -10, ymin: -5, xmax: 0, ymax: 5 }, markerGraphics: [{ type: "CIMMarkerGraphic", geometry: { rings: [[[-12, -3.47], [-12, 3.6], [1.96, -0.03], [-12, -3.47]]] }, symbol: { type: "CIMPolygonSymbol", symbolLayers: [{ type: "CIMSolidFill", enable: true, color: n6 }] } }] }] } } });
}
function p11(e6) {
  let n6 = "ESRI__ID", o6 = 4;
  for (const a8 of e6) if (a8.name) {
    if ("name" === a8.name.toLowerCase()) {
      n6 = a8.name;
      break;
    }
    a8.name.toLowerCase().includes("name") ? (n6 = a8.name, o6 = 2) : "esriFieldTypeString" === a8.fieldType && o6 > 3 && (n6 = a8.name, o6 = 3);
  }
  return n6;
}
function y5(e6, a8, r9) {
  const t8 = { color: [80, 80, 80], haloColor: [255, 255, 255], haloSize: 0.7, font: { size: 10, weight: "normal" } }, s7 = new C({ labelExpressionInfo: new a4({ expression: "ESRI__ID" === r9 ? `${a8}` : `$feature.${r9}` }), labelPlacement: "above-center", symbol: new m2(t8) }), i6 = new C({ labelExpressionInfo: new a4({ expression: `'${a8}' + IIf($feature.ESRI__AggregationCount>1, ' (' + $feature.ESRI__AggregationCount + ')', '')` }), labelPlacement: "center-along", labelPosition: "parallel", repeatLabel: false, symbol: new m2(__spreadProps(__spreadValues({}, t8), { yoffset: "12px" })) });
  return "entity" === e6 ? [s7] : [i6];
}
function w2(e6, a8, r9) {
  const t8 = { color: [255, 255, 255], haloColor: [0, 0, 0], haloSize: 0.7, font: { size: 10, weight: "bold" } }, s7 = "ESRI__ID" === r9 ? `${e6}` : `$feature.${r9}`;
  return "point" === a8 ? [new C({ labelExpressionInfo: new a4({ expression: s7 }), labelPlacement: "above-center", symbol: new m2(t8) })] : "polyline" === a8 ? [new C({ labelExpressionInfo: new a4({ expression: s7 }), labelPlacement: "center-along", repeatLabel: true, symbol: new m2(t8) })] : "polygon" === a8 ? [new C({ labelExpressionInfo: new a4({ expression: s7 }), labelPlacement: "always-horizontal", symbol: new m2(t8) })] : null;
}

// node_modules/@arcgis/core/layers/knowledgeGraph/KnowledgeGraphSublayerBase.js
var t7 = s3();
var p12 = (s7) => {
  let p13 = class extends s7 {
    constructor() {
      super(...arguments), this.fields = [], this.fieldsIndex = null;
    }
  };
  return r([m(t7.fields)], p13.prototype, "fields", void 0), r([m(t7.fieldsIndex)], p13.prototype, "fieldsIndex", void 0), p13 = r([a2("esri.layers.knowledgeGraph.KnowledgeGraphSublayerBase")], p13), p13;
};

// node_modules/@arcgis/core/layers/knowledgeGraph/KnowledgeGraphSublayer.js
function fe(e6) {
  if (!e6.json) return e6;
  e6.json.write = ge(e6.json.write);
  const t8 = e6.json.origins;
  if (!t8) return e6;
  let r9;
  for (r9 in t8) {
    const e7 = t8[r9];
    e7 && (e7.write = ge(e7.write));
  }
  return e6;
}
function ge(e6) {
  return "object" == typeof e6 && e6 ? (false !== e6.enabled && (e6.overridePolicy = je(e6)), e6) : true === e6 ? be() : e6;
}
function je(e6) {
  const _a = e6, { target: t8, writer: r9, overridePolicy: o6 } = _a, i6 = __objRest(_a, ["target", "writer", "overridePolicy"]);
  return function(e7, t9) {
    const r10 = we.call(this, e7, t9);
    return r10.enabled ? __spreadValues(__spreadValues({}, i6), r10) : r10;
  };
}
function be() {
  return { overridePolicy: we };
}
function we(e6, t8) {
  const r9 = !!this.geometryType;
  let o6 = { enabled: r9 };
  return r9 && (o6 = __spreadValues(__spreadValues({}, o6), Te.call(this, e6, t8))), o6;
}
function Te(e6, t8) {
  return { ignoreOrigin: this.originIdOf(t8) > e.DEFAULTS };
}
var Ie = class extends p12(a3(d4(c(p(p6(l4(t(f4(S(f3)))))))))) {
  constructor(e6) {
    super(e6), this.blendMode = "normal", this.capabilities = y3(false, false), this.charts = null, this.definitionExpression = null, this.displayField = "", this.displayFilterEnabled = true, this.displayFilterInfo = null, this.effect = null, this.elevationInfo = null, this.featureEffect = null, this.graphType = null, this.labelsVisible = true, this.layerType = null, this.legendEnabled = true, this.maxScale = 0, this.minScale = 0, this.objectIdField = _, this.objectType = null, this.opacity = 1, this.orderBy = null, this.parent = null, this.parentCompositeLayer = null, this.persistenceEnabled = true, this.popupEnabled = true, this.popupTemplate = null, this.refreshInterval = 0, this.source = { openPorts: () => this.load().then(() => {
      const e7 = new MessageChannel();
      return new E2(e7.port1, { channel: e7, client: { queryFeatures: (e8, t8 = {}) => {
        const r9 = b.fromJSON(e8);
        return this.queryFeaturesJSON(r9, t8);
      } } }), [e7.port2];
    }) }, this.type = "knowledge-graph-sublayer", this.useViewTime = true, this.visible = true;
  }
  get defaultPopupTemplate() {
    return this.createPopupTemplate();
  }
  set featureReduction(e6) {
    const t8 = this._normalizeFeatureReduction(e6);
    this._set("featureReduction", t8);
  }
  get fields() {
    const e6 = [];
    return this.objectType?.properties?.forEach((t8) => {
      const r9 = "esriFieldTypeOID" === t8.fieldType ? "esriFieldTypeInteger" : t8.fieldType;
      e6.push(y2.fromJSON({ name: t8.name, type: r9, alias: t8.alias, defaultValue: t8.defaultValue, editable: t8.editable, nullable: t8.nullable }));
    }), e6.push(y2.fromJSON({ name: this.objectIdField, type: "esriFieldTypeString", alias: this.objectIdField, editable: false }), y2.fromJSON({ name: o, type: "esriFieldTypeInteger", alias: o, editable: false }), y2.fromJSON({ name: E, type: "esriFieldTypeInteger", alias: E, editable: false })), e6;
  }
  get geometryType() {
    if ("link-chart" === this.parentCompositeLayer?.type) return "relationship" === this.graphType ? "polyline" : "point";
    const e6 = this.parentCompositeLayer?.dataManager.geographicLookup.get(this.objectType?.name), t8 = e6?.geometryType;
    return t8 && "esriGeometryNull" !== t8 ? y.fromJSON(t8) : null;
  }
  get geometryFieldName() {
    if ("link-chart" === this.parentCompositeLayer?.type) return S2;
    const e6 = this.parentCompositeLayer?.dataManager.geographicLookup.get(this.objectType?.name);
    return e6?.name ?? null;
  }
  get graphTypeName() {
    return this.objectType?.name;
  }
  get hasM() {
    const e6 = this.parentCompositeLayer?.dataManager.geographicLookup.get(this.objectType?.name), t8 = e6?.name, r9 = t8 ? this.objectType?.properties?.[t8] : null;
    return r9?.hasM ?? false;
  }
  get hasZ() {
    const e6 = this.parentCompositeLayer?.dataManager.geographicLookup.get(this.objectType?.name), t8 = e6?.name, r9 = t8 ? this.objectType?.properties?.[t8] : null;
    return r9?.hasZ ?? false;
  }
  set labelingInfo(e6) {
    this._set("labelingInfo", e6);
  }
  get labelingInfo() {
    if (this._isOverridden("labelingInfo")) return this._get("labelingInfo");
    const e6 = this.objectType.properties ? p11(this.objectType.properties) : "ESRI__ID";
    return "link-chart" === this.parentCompositeLayer.type ? y5(this.graphType, this.graphTypeName, e6) : w2(this.graphTypeName, this.geometryType, e6);
  }
  set renderer(e6) {
    g4(e6, this.fieldsIndex), this._set("renderer", e6);
  }
  get renderer() {
    if (this._isOverridden("renderer")) return this._get("renderer");
    const e6 = this.parentCompositeLayer?.dataManager?.knowledgeGraph?.dataModel, t8 = [...e6?.entityTypes ?? [], ...e6?.relationshipTypes ?? []].map((e7) => e7.name).indexOf(this.graphTypeName), r9 = f9(t8);
    if ("link-chart" === this.parentCompositeLayer?.type) {
      if ("relationship" === this.graphType) return new p4({ type: "simple", symbol: m8(r9) });
      const e7 = t2(u2(y.toJSON("point")).renderer);
      return g3(e7.symbol, r9), e7;
    }
    const o6 = t2(u2(y.toJSON(this.geometryType)).renderer);
    return g3(o6.symbol, r9), o6;
  }
  get spatialReference() {
    return this.parentCompositeLayer?.dataManager?.knowledgeGraph?.dataModel?.spatialReference ?? g2.WGS84;
  }
  set timeInfo(e6) {
    this._set("timeInfo", e6);
  }
  get title() {
    return this._isOverridden("title") ? this._get("title") : this.graphTypeName;
  }
  set title(e6) {
    this._set("title", e6);
  }
  writeTitle(e6, t8) {
    t8.title = e6 ?? "Layer";
  }
  createPopupTemplate(e6) {
    return p7(this, e6);
  }
  createQuery() {
    return new b({ where: "1=1", outFields: ["*"] });
  }
  getField(e6) {
    return this.fieldsIndex.get(e6);
  }
  getFieldDomain(e6, t8) {
    return null;
  }
  queryFeatures(e6, t8) {
    return __async(this, null, function* () {
      yield this.load();
      const { resolvedQuery: r9, queryEngine: o6 } = yield this._setupQueryObjects(e6), i6 = d3.fromJSON(yield o6.executeQuery(r9.toJSON(), t8?.signal));
      return i6.features.forEach((e7) => {
        e7.sourceLayer = this;
      }), i6;
    });
  }
  queryFeaturesJSON(e6, t8) {
    return __async(this, null, function* () {
      yield this.load();
      const { resolvedQuery: r9, queryEngine: o6 } = yield this._setupQueryObjects(e6);
      return yield o6.executeQuery(r9.toJSON(), t8?.signal);
    });
  }
  queryFeatureCount(e6, t8) {
    return __async(this, null, function* () {
      yield this.load();
      const { resolvedQuery: r9, queryEngine: o6 } = yield this._setupQueryObjects(e6);
      return o6.executeQueryForCount(r9.toJSON(), t8?.signal);
    });
  }
  queryExtent() {
    return __async(this, arguments, function* (e6 = {}, t8) {
      yield this.load();
      const r9 = __spreadProps(__spreadValues({}, e6), { returnGeometry: true }), { resolvedQuery: o6, queryEngine: i6 } = yield this._setupQueryObjects(r9), n6 = yield i6.executeQueryForExtent(o6.toJSON(), t8?.signal);
      let s7;
      return s7 = null != n6.extent?.xmin && null != n6.extent?.xmax && null != n6.extent?.ymin && null != n6.extent?.ymax ? new w(n6.extent) : new w(), { count: n6.count, extent: s7 };
    });
  }
  queryObjectIds(e6, t8) {
    return __async(this, null, function* () {
      yield this.load();
      const r9 = b.from(e6);
      let o6;
      if ("link-chart" === this.parentCompositeLayer.type && this._cachedQueryEngine) o6 = this._cachedQueryEngine;
      else {
        const e7 = yield this.parentCompositeLayer.dataManager.getData(r9, this, t8);
        o6 = this.loadQueryEngine(e7);
      }
      return yield o6.executeQueryForIds(r9.toJSON(), t8?.signal);
    });
  }
  loadQueryEngine(e6) {
    const t8 = new f6({ geometryType: y.toJSON(this.geometryType), hasM: this.hasM, hasZ: this.hasZ }), r9 = new L({ fieldsIndex: this.fieldsIndex.toJSON(), geometryType: y.toJSON(this.geometryType), hasM: this.hasM, hasZ: this.hasZ, objectIdField: this.objectIdField, spatialReference: this.spatialReference.toJSON(), timeInfo: this.timeInfo?.toJSON(), featureStore: t8 });
    return r9.featureStore.addMany(e6), r9;
  }
  refreshCachedQueryEngine() {
    return __async(this, null, function* () {
      const e6 = yield this.parentCompositeLayer.dataManager.getData(new b({ where: "1=1", outFields: [_] }), this);
      this._cachedQueryEngine = this.loadQueryEngine(e6);
    });
  }
  load(e6) {
    return this.addResolvingPromise(this.parent.load(e6).then(() => I2(this.timeInfo, this.fieldsIndex))), Promise.resolve(this);
  }
  _setupQueryObjects(e6, t8) {
    return __async(this, null, function* () {
      const r9 = b.from(e6), o6 = r9.geometry;
      if (o6 && !o6.spatialReference?.isWGS84 && (yield Q(o6.spatialReference, U), r9.geometry = O(o6 instanceof j2 || o6 instanceof P2 || o6 instanceof j ? o6 : o6.extent, U)), "link-chart" === this.parentCompositeLayer.type && this._cachedQueryEngine) return { resolvedQuery: r9, queryEngine: this._cachedQueryEngine };
      const i6 = yield this.parentCompositeLayer.dataManager.getData(r9, this, t8);
      return { resolvedQuery: r9, queryEngine: this.loadQueryEngine(i6) };
    });
  }
};
r([m(fe(a(n3)))], Ie.prototype, "blendMode", void 0), r([m()], Ie.prototype, "capabilities", void 0), r([m({ json: { origins: { "web-scene": { write: false } }, write: be() } })], Ie.prototype, "charts", void 0), r([m({ readOnly: true })], Ie.prototype, "defaultPopupTemplate", null), r([m({ type: String, json: { origins: { service: { read: false } }, name: "layerDefinition.definitionExpression", write: { ignoreOrigin: true } } })], Ie.prototype, "definitionExpression", void 0), r([m()], Ie.prototype, "displayField", void 0), r([m(fe(a(p2)))], Ie.prototype, "displayFilterEnabled", void 0), r([m(fe(a(l3)))], Ie.prototype, "displayFilterInfo", void 0), r([m(fe(a(l)))], Ie.prototype, "effect", void 0), r([m()], Ie.prototype, "elevationInfo", void 0), r([m(fe(a(p3)))], Ie.prototype, "featureEffect", void 0), r([m(fe(a(p5)))], Ie.prototype, "featureReduction", null), r([m()], Ie.prototype, "fields", null), r([m()], Ie.prototype, "geometryType", null), r([m()], Ie.prototype, "geometryFieldName", null), r([m({ type: ["entity", "relationship"], nonNullable: true, json: { write: { isRequired: true, ignoreOrigin: true } } })], Ie.prototype, "graphType", void 0), r([m({ type: String, nonNullable: true, json: { write: { isRequired: true, ignoreOrigin: true } } })], Ie.prototype, "graphTypeName", null), r([m()], Ie.prototype, "hasM", null), r([m()], Ie.prototype, "hasZ", null), r([m({ type: String, json: { origins: { service: { read: false }, "portal-item": { read: false } }, write: { ignoreOrigin: true } } })], Ie.prototype, "id", void 0), r([m({ type: Boolean, value: true, nonNullable: true, json: { name: "showLabels", default: false, write: { overridePolicy() {
  return { enabled: !!this.geometryType, alwaysWriteDefaults: true, ignoreOrigin: true };
} } } })], Ie.prototype, "labelsVisible", void 0), r([m({ type: [C], json: { name: "layerDefinition.drawingInfo.labelingInfo", read: ve, write: be() } })], Ie.prototype, "labelingInfo", null), r([m({ readOnly: true, json: { read: false, write: { writer(e6, t8) {
  switch (this.parentCompositeLayer?.type) {
    case "link-chart":
      t8.layerType = "LinkChartSubLayer";
      break;
    case "knowledge-graph":
      t8.layerType = this.geometryType ? "KnowledgeGraphSubLayer" : "KnowledgeGraphSubTable";
  }
}, isRequired: true, ignoreOrigin: true, writerEnsuresNonNull: true } } })], Ie.prototype, "layerType", void 0), r([m(fe(a(d)))], Ie.prototype, "legendEnabled", void 0), r([m(fe(a(v)))], Ie.prototype, "maxScale", void 0), r([m(fe(a(j3)))], Ie.prototype, "minScale", void 0), r([m()], Ie.prototype, "objectIdField", void 0), r([m()], Ie.prototype, "objectType", void 0), r([m(fe(a(f2)))], Ie.prototype, "opacity", void 0), r([m(fe(a(c2)))], Ie.prototype, "orderBy", void 0), r([m({ clonable: false })], Ie.prototype, "parent", void 0), r([m()], Ie.prototype, "parentCompositeLayer", void 0), r([m(fe(a(l2)))], Ie.prototype, "popupEnabled", void 0), r([m({ type: q, json: { name: "popupInfo", write: { ignoreOrigin: true } } })], Ie.prototype, "popupTemplate", void 0), r([m({ type: Number, json: { write: { overridePolicy: Te } } })], Ie.prototype, "refreshInterval", void 0), r([m({ types: m3, json: { name: "layerDefinition.drawingInfo.renderer", write: be() } })], Ie.prototype, "renderer", null), r([m()], Ie.prototype, "source", void 0), r([m()], Ie.prototype, "spatialReference", null), r([m({ type: d5, json: { name: "layerDefinition.timeInfo", write: true, origins: { "web-document": { name: "layerDefinition.timeInfo", read: true, write: true }, "portal-item": { name: "layerDefinition.timeInfo", read: true, write: true } } } })], Ie.prototype, "timeInfo", null), r([m({ type: String, json: { write: { isRequired: true, ignoreOrigin: true, writerEnsuresNonNull: true } } })], Ie.prototype, "title", null), r([r3("title")], Ie.prototype, "writeTitle", null), r([m({ json: { read: false } })], Ie.prototype, "type", void 0), r([m(fe(a(f5)))], Ie.prototype, "useViewTime", void 0), r([m({ type: Boolean, json: { name: "visibility", write: be() } })], Ie.prototype, "visible", void 0), Ie = r([a2("esri.layers.knowledgeGraph.KnowledgeGraphSublayer")], Ie);
var Se = Ie;
function ve(e6, t8, r9) {
  const i6 = [["ESRI__AGGREGATION_COUNT", o], ["ESRI__ORIGIN_ID", I], ["ESRI__DESTINATION_ID", t3], ["ESRI__LAYOUT_GEOMETRY", S2]];
  try {
    for (const t9 of e6) for (const [e7, r10] of i6) t9.labelExpression = t9.labelExpression?.replaceAll(e7, r10), t9.labelExpressionInfo?.expression && (t9.labelExpressionInfo.expression = t9.labelExpressionInfo.expression.replaceAll(e7, r10));
  } catch (n6) {
    n.getLogger(this).warn("Error updating labelingInfo", n6);
  }
  return n4(e6, t8, r9);
}

export {
  m6 as m,
  h3 as h,
  D,
  o3 as o,
  a6 as a,
  i4 as i,
  o4 as o2,
  u4 as u,
  v2 as v,
  A2 as A,
  b3 as b,
  P3 as P,
  _2 as _,
  h4 as h2,
  m7 as m2,
  g7 as g,
  C2 as C,
  E6 as E,
  i5 as i2,
  Se
};
//# sourceMappingURL=chunk-65CWIB5P.js.map
