// node_modules/@arcgis/core/core/time.js
function n(n2) {
  return n2;
}
function r(r2) {
  return n(1e3 * r2);
}
function t(n2) {
  return n2;
}
function u(n2) {
  return t(1e-3 * n2);
}

export {
  n,
  r,
  t,
  u
};
//# sourceMappingURL=chunk-DWCD4SQQ.js.map
