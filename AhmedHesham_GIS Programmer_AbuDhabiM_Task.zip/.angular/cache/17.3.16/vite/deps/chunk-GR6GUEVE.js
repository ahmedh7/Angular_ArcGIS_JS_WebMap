import {
  g as g2
} from "./chunk-P5ELECBN.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";

// node_modules/@arcgis/core/rest/knowledgeGraph/GraphQuery.js
var t = class extends g {
  constructor(r2) {
    super(r2), this.openCypherQuery = "";
  }
};
r([m()], t.prototype, "openCypherQuery", void 0), t = r([a("esri.rest.knowledgeGraph.GraphQuery")], t);
var p = t;

// node_modules/@arcgis/core/rest/knowledgeGraph/GraphQueryStreaming.js
var s = class extends p {
  constructor(r2) {
    super(r2), this.bindParameters = null, this.bindGeometryQuantizationParameters = null, this.outputQuantizationParameters = null, this.outputSpatialReference = null, this.provenanceBehavior = null;
  }
};
r([m()], s.prototype, "bindParameters", void 0), r([m()], s.prototype, "bindGeometryQuantizationParameters", void 0), r([m()], s.prototype, "outputQuantizationParameters", void 0), r([m({ type: g2 })], s.prototype, "outputSpatialReference", void 0), r([m()], s.prototype, "provenanceBehavior", void 0), s = r([a("esri.rest.knowledgeGraph.GraphQueryStreaming")], s);
var p2 = s;

export {
  p2 as p
};
//# sourceMappingURL=chunk-GR6GUEVE.js.map
