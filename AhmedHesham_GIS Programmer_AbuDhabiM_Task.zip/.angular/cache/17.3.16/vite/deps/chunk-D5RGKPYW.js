import {
  Bm,
  Vr
} from "./chunk-RPGOD7HK.js";

// node_modules/@arcgis/core/chunks/OperatorCrosses.js
var t = class extends Bm {
  getOperatorType() {
    return 6;
  }
  execute(r, t2, o, s) {
    return Vr(r, t2, o, 16, s);
  }
};

export {
  t
};
//# sourceMappingURL=chunk-D5RGKPYW.js.map
