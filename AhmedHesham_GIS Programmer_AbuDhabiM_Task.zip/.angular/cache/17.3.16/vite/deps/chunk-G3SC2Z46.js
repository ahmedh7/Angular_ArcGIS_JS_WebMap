import {
  x
} from "./chunk-2CGNNVDA.js";
import {
  s as s2
} from "./chunk-SZIT3IYE.js";
import {
  s
} from "./chunk-XOZHLW5F.js";
import {
  n
} from "./chunk-UJIBBVDV.js";

// node_modules/@arcgis/core/views/3d/interactive/support/viewUtils.js
function i(r, o, e2, n2, i2 = n()) {
  const p2 = s2(m, r);
  return p2[2] = x(n2, p2, o, e2) || 0, n2.renderCoordsHelper.toRenderCoords(p2, o, i2), i2;
}
var m = n();
var p = s();
var f = s();

export {
  i
};
//# sourceMappingURL=chunk-G3SC2Z46.js.map
