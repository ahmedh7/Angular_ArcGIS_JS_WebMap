import {
  Bm,
  Vr
} from "./chunk-RPGOD7HK.js";

// node_modules/@arcgis/core/chunks/OperatorTouches.js
var t = class extends Bm {
  getOperatorType() {
    return 5;
  }
  execute(r, t2, o, s) {
    return Vr(r, t2, o, 8, s);
  }
};

export {
  t
};
//# sourceMappingURL=chunk-HKETVDPI.js.map
