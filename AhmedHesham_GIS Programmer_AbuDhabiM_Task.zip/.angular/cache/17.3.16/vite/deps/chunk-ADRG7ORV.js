import {
  $t,
  A,
  At,
  C,
  D,
  Et,
  F,
  G,
  H,
  Ht,
  I,
  K,
  M,
  Pt,
  S,
  V,
  X,
  Y,
  Z,
  _,
  a as a2,
  bt,
  kt,
  r as r2,
  tt,
  v,
  z
} from "./chunk-4LJTFP6V.js";
import {
  r
} from "./chunk-QYUZVPLR.js";
import {
  b,
  c2 as c,
  m,
  u3 as u
} from "./chunk-VT56RVNM.js";
import {
  a,
  s,
  s2
} from "./chunk-JB56QM27.js";
import {
  has
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/support/revision.js
var a3 = "20250407";
var e = "04d2b42da93678ca718b23aaf7e216985f10fa8e";

// node_modules/@arcgis/core/kernel.js
Symbol.dispose ??= Symbol("Symbol.dispose"), Symbol.asyncDispose ??= Symbol("Symbol.asyncDispose");
var e2 = "4.32";
var s3;
var r3 = e2;
r3 = "4.32.10";
function i(o2) {
  s3 = o2;
}
function t(e3) {
  const r4 = s3?.findCredential(e3);
  return r4?.token ? kt(e3, "token", r4.token) : e3;
}
has("host-webworker") || globalThis.$arcgis || Object.defineProperty(globalThis, "$arcgis", { configurable: false, enumerable: true, writable: false, value: {} }), has("host-webworker");

// node_modules/@arcgis/core/chunks/persistableUrlUtils.js
function p(e3, s5) {
  const o2 = s5?.url?.path;
  if (e3 && o2 && (e3 = _(e3, o2, { preserveProtocolRelative: true }), s5.portalItem && s5.readResourcePaths)) {
    const t2 = G(e3, s5.portalItem.itemUrl);
    null != t2 && v2.test(t2) && s5.readResourcePaths.push(s5.portalItem.resourceFromPath(t2).path);
  }
  return (e3 = I2(e3, s5?.portal)) && d.test(e3) ? R(e3) : e3;
}
function m2(e3, l2, a6 = y.YES) {
  if (null == (e3 = e3 && d.test(e3) ? w(e3) : e3)) return e3;
  !Y(e3) && l2?.blockedRelativeUrls && l2.blockedRelativeUrls.push(e3);
  let c4 = _(e3);
  if (l2) {
    const t2 = l2.verifyItemRelativeUrls?.rootPath || l2.url?.path;
    if (t2) {
      const s5 = I2(t2, l2.portal), o2 = I2(c4, l2.portal);
      c4 = G(o2, s5, s5);
      null != c4 && c4 !== o2 && c4 !== e3 && l2.verifyItemRelativeUrls && l2.verifyItemRelativeUrls.writtenUrls.push(c4);
    }
  }
  return c4 = x(c4, l2?.portal), Y(c4) && (c4 = K(c4)), l2?.resources && l2?.portalItem && !Y(c4) && !tt(c4) && a6 === y.YES && l2.resources.toKeep.push({ resource: l2.portalItem.resourceFromPath(c4), compress: false }), c4;
}
function f(e3, t2, r4) {
  return p(e3, r4);
}
function h(e3, t2, r4, s5) {
  const o2 = m2(e3, s5);
  void 0 !== o2 && (t2[r4] = o2);
}
var d = /\/items\/([^/]+)\/resources\/(.*)/;
var v2 = /^\.\/resources\//;
function U(e3) {
  const t2 = e3?.match(d) ?? null;
  return t2?.[1] ?? null;
}
function g(e3) {
  const t2 = e3?.match(d) ?? null;
  if (null == t2) return null;
  const r4 = t2[2], s5 = r4.lastIndexOf("/");
  if (-1 === s5) {
    const { path: e4, extension: t3 } = Ht(r4);
    return { prefix: null, filename: e4, extension: t3 };
  }
  const { path: o2, extension: n2 } = Ht(r4.slice(s5 + 1));
  return { prefix: r4.slice(0, s5), filename: o2, extension: n2 };
}
function x(e3, t2) {
  return t2 && !t2.isPortal && t2.urlKey && t2.customBaseUrl ? At(e3, `${t2.urlKey}.${t2.customBaseUrl}`, t2.portalHostname) : e3;
}
function I2(e3, t2) {
  if (!t2 || t2.isPortal || !t2.urlKey || !t2.customBaseUrl) return e3;
  const r4 = `${t2.urlKey}.${t2.customBaseUrl}`, s5 = C();
  return F(s5, `${s5.scheme}://${r4}`) ? At(e3, t2.portalHostname, r4) : At(e3, r4, t2.portalHostname);
}
function R(t2) {
  if (!t2) return t2 || null;
  let r4 = t2;
  return r4 && s3 && !s3.findCredential(r4) && (r4 = r2(r4), r4 = r4.replace(/^https?:\/\/www\.arcgis\.com/, "https://cdn.arcgis.com"), r4 = r4.replace(/^https?:\/\/devext\.arcgis\.com/, "https://cdndev.arcgis.com"), r4 = r4.replace(/^https?:\/\/qaext\.arcgis\.com/, "https://cdnqa.arcgis.com")), r4;
}
function w(t2) {
  if (!t2) return t2 || null;
  let r4 = t2;
  return r4 = r4.replace(/^https?:\/\/cdn\.arcgis\.com/, "https://www.arcgis.com"), r4 = r4.replace(/^https?:\/\/cdndev\.arcgis\.com/, "https://devext.arcgis.com"), r4 = r4.replace(/^https?:\/\/cdnqa\.arcgis\.com/, "https://qaext.arcgis.com"), r4 && s3 && !s3.findCredential(r4) && (r4 = r2(r4)), r4;
}
var y;
!function(e3) {
  e3[e3.YES = 0] = "YES", e3[e3.NO = 1] = "NO";
}(y || (y = {}));
var P = Object.freeze(Object.defineProperty({ __proto__: null, get MarkKeep() {
  return y;
}, ensureMainOnlineDomain: x, fromCDNUrl: w, fromJSON: p, itemIdFromResourceUrl: U, prefixAndFilenameFromResourceUrl: g, read: f, toCDNUrl: R, toJSON: m2, write: h }, Symbol.toStringTag, { value: "Module" }));

// node_modules/@arcgis/core/layers/support/arcgisLayerUrl.js
var o = { mapserver: "MapServer", imageserver: "ImageServer", featureserver: "FeatureServer", knowledgegraphserver: "KnowledgeGraphServer", sceneserver: "SceneServer", streamserver: "StreamServer", vectortileserver: "VectorTileServer", "3dtilesserver": "3DTilesServer", videoserver: "VideoServer" };
var a4 = Object.values(o);
var c2 = new RegExp(`^((?:https?:)?\\/\\/\\S+?\\/rest\\/services\\/(.+?)\\/(${a4.join("|")}))(?:\\/(?:layers\\/)?(\\d+))?`, "i");
var v3 = new RegExp(`^((?:https?:)?\\/\\/\\S+?\\/([^/\\n]+)\\/(${a4.join("|")}))(?:\\/(?:layers\\/)?(\\d+))?`, "i");
var f2 = /(.*?)\/(?:layers\/)?(\d+)\/?$/i;
function p2(e3) {
  return c2.test(e3);
}
function d2(r4) {
  if (null == r4) return null;
  const t2 = I(r4), s5 = t2?.path.match(c2) || t2?.path.match(v3);
  if (!s5) return null;
  const [, n2, l2, i4, u3] = s5, a6 = l2.indexOf("/");
  return { title: m3(-1 !== a6 ? l2.slice(a6 + 1) : l2), serverType: o[i4.toLowerCase()], sublayer: null != u3 && "" !== u3 ? parseInt(u3, 10) : null, url: { path: n2 } };
}
function h2(r4) {
  const t2 = I(r4).path.match(f2);
  return t2 ? { serviceUrl: t2[1], sublayerId: Number(t2[2]) } : null;
}
function m3(e3) {
  return (e3 = e3.replaceAll(/\s*[/_]+\s*/g, " "))[0].toUpperCase() + e3.slice(1);
}
function w2(e3, r4) {
  const t2 = [];
  if (e3) {
    const r5 = d2(e3);
    null != r5 && r5.title && t2.push(r5.title);
  }
  if (r4) {
    const e4 = m3(r4);
    t2.push(e4);
  }
  if (2 === t2.length) {
    if (t2[0].toLowerCase().includes(t2[1].toLowerCase())) return t2[0];
    if (t2[1].toLowerCase().includes(t2[0].toLowerCase())) return t2[1];
  }
  return t2.join(" - ");
}
function g2(e3) {
  let t2 = X(e3, true);
  return !!t2 && (t2 = t2.toLowerCase(), t2.endsWith(".arcgis.com") && (t2.startsWith("services") || t2.startsWith("tiles") || t2.startsWith("features")));
}
function y2(e3, r4) {
  return e3 ? bt(Pt(e3, r4)) : e3;
}
function S2(r4) {
  let { url: n2 } = r4;
  if (!n2) return { url: n2 };
  n2 = Pt(n2, r4.logger);
  const l2 = I(n2), i4 = d2(l2.path);
  let u3;
  if (null != i4) null != i4.sublayer && null == r4.layer.layerId && (u3 = i4.sublayer), n2 = i4.url.path;
  else if (r4.nonStandardUrlAllowed) {
    const e3 = h2(l2.path);
    null != e3 && (n2 = e3.serviceUrl, u3 = e3.sublayerId);
  }
  return { url: bt(n2), layerId: u3 };
}
function C2(e3, r4, t2, s5, l2) {
  h(r4, s5, "url", l2), s5.url && null != e3.layerId && (s5.url = V(s5.url, t2, e3.layerId.toString()));
}
function b2(e3) {
  if (!e3) return false;
  const r4 = e3.toLowerCase(), t2 = r4.includes("/services/"), s5 = r4.includes("/mapserver/wmsserver"), n2 = r4.includes("/imageserver/wmsserver"), l2 = r4.includes("/wmsserver");
  return t2 && (s5 || n2 || l2);
}

// node_modules/@arcgis/core/support/apiKeyUtils.js
var s4 = /* @__PURE__ */ new Set(["elevation3d.arcgis.com", "js.arcgis.com", "jsdev.arcgis.com", "jsqa.arcgis.com", "static.arcgis.com"]);
function i2(t2) {
  const c4 = X(t2, true);
  return !!c4 && (c4.endsWith(".arcgis.com") && !s4.has(c4) && !t2.endsWith("/sharing/rest/generateToken"));
}
function n(r4, s5) {
  return !(!s5 && !s.apiKey || !i2(r4));
}

// node_modules/@arcgis/core/support/requestUtils.js
function i3(e3, o2, t2 = false, n2) {
  return new Promise((s5, i4) => {
    if (c(n2)) return void i4(c3());
    let a6 = () => {
      l2(), i4(new Error(`Unable to load ${o2}`));
    }, u3 = () => {
      const r4 = e3;
      l2(), s5(r4);
    }, m5 = () => {
      if (!e3) return;
      const r4 = e3;
      l2(), r4.src = "", i4(c3());
    };
    const l2 = () => {
      has("esri-image-decode") || (e3.removeEventListener("error", a6), e3.removeEventListener("load", u3)), a6 = null, u3 = null, e3 = null, null != n2 && n2.removeEventListener("abort", m5), m5 = null, t2 && URL.revokeObjectURL(o2);
    };
    null != n2 && n2.addEventListener("abort", m5), has("esri-image-decode") ? e3.decode().then(u3, a6) : (e3.addEventListener("error", a6), e3.addEventListener("load", u3));
  });
}
function c3() {
  try {
    return new DOMException("Aborted", "AbortError");
  } catch {
    const e3 = new Error();
    return e3.name = "AbortError", e3;
  }
}
var a5 = "Timeout exceeded";
function u2() {
  return new Error(a5);
}
function m4(e3) {
  return "object" == typeof e3 && !!e3 && "message" in e3 && e3.message === a5;
}
function l(r4) {
  s.request.crossOriginNoCorsDomains || (s.request.crossOriginNoCorsDomains = {});
  const t2 = s.request.crossOriginNoCorsDomains;
  for (let e3 of r4) e3 = e3.toLowerCase(), /^https?:\/\//.test(e3) ? t2[X(e3) ?? ""] = 0 : (t2[X("http://" + e3) ?? ""] = 0, t2[X("https://" + e3) ?? ""] = 0);
}
function d3(r4) {
  const s5 = s.request.crossOriginNoCorsDomains;
  if (s5) {
    let e3 = X(r4);
    if (e3) return e3 = e3.toLowerCase(), !F(e3, C()) && s5[e3] < Date.now() - 36e5;
  }
  return false;
}
function f3(r4) {
  return __async(this, null, function* () {
    const t2 = I(r4);
    r4 = t2.path, "json" === t2.query?.f && (r4 += "?f=json");
    try {
      yield fetch(r4, { mode: "no-cors", credentials: "include" });
    } catch {
    }
    const n2 = s.request.crossOriginNoCorsDomains, i4 = X(r4);
    n2 && i4 && (n2[i4.toLowerCase()] = Date.now());
  });
}

// node_modules/@arcgis/core/request.js
function P2(e3, r4) {
  return __async(this, null, function* () {
    e3 instanceof URL && (e3 = e3.toString()), r4?.query instanceof URLSearchParams && (r4.query = A(r4.query.toString().replaceAll("+", " ")));
    const t2 = tt(e3), s5 = Z(e3);
    s5 || t2 || (e3 = K(e3));
    const o2 = { url: e3, requestOptions: __spreadValues({}, r4) }, a6 = (e4) => ({ data: e4, getAllHeaders: I3, getHeader: I3, httpStatus: 200, requestOptions: o2.requestOptions, url: o2.url }), i4 = D(e3, H2.internalInterceptors);
    if (i4) {
      const e4 = yield K2(i4, o2);
      if (null != e4) return a6(e4);
    }
    let l2 = D(e3);
    if (l2) {
      const e4 = yield K2(l2, o2);
      if (null != e4) return a6(e4);
      l2.after || l2.error || (l2 = null);
    }
    if (e3 = o2.url, "image" === (r4 = o2.requestOptions).responseType && (has("host-webworker") || has("host-node"))) throw $("request:invalid-parameters", new Error("responseType 'image' is not supported in Web Workers or Node environment"), o2);
    if ("head" === r4.method) {
      if (r4.body) throw $("request:invalid-parameters", new Error("body parameter cannot be set when method is 'head'"), o2);
      if (t2 || s5) throw $("request:invalid-parameters", new Error("data and blob URLs are not supported for method 'head'"), o2);
    }
    if (yield z2(), A2) return A2.execute(e3, r4);
    const h3 = new AbortController(), f4 = m(r4, () => h3.abort()), y3 = { controller: h3, credential: void 0, credentialToken: void 0, fetchOptions: void 0, hasToken: false, interceptor: l2, params: o2, redoRequest: false, useIdentity: H2.useIdentity, useProxy: false, useSSL: false, withCredentials: false }, w3 = r4.useRequestQueue ? Z2(y3) : ee(y3), g3 = yield w3.finally(() => f4?.remove());
    return l2?.after?.(g3), g3;
  });
}
var A2;
var H2 = s.request;
var R2 = "FormData" in globalThis;
var _2 = /* @__PURE__ */ new Set([499, 498, 403, 401]);
var D2 = /* @__PURE__ */ new Set(["COM_0056", "COM_0057", "SB_0008"]);
var F2 = [/\/arcgis\/tokens/i, /\/sharing(\/rest)?\/generatetoken/i, /\/rest\/info/i];
var I3 = () => null;
var M2 = Symbol();
function N(e3) {
  const r4 = X(e3);
  r4 && !P2._corsServers.includes(r4) && P2._corsServers.push(r4);
}
function B(e3) {
  const r4 = X(e3);
  return !r4 || r4.endsWith(".arcgis.com") || P2._corsServers.includes(r4) || M(r4);
}
function $(e3, r4, o2, n2) {
  let l2 = "Error";
  const u3 = { url: o2.url, requestOptions: o2.requestOptions, getAllHeaders: I3, getHeader: I3, ssl: false };
  if (r4 instanceof s2) return r4.details ? (r4.details = a(r4.details), r4.details.url = o2.url, r4.details.requestOptions = o2.requestOptions) : r4.details = u3, r4;
  if (r4) {
    const e4 = n2 && (() => Array.from(n2.headers)), t2 = n2 && ((e5) => n2.headers.get(e5)), s5 = n2?.status, o3 = r4.message;
    o3 && (l2 = o3), e4 && t2 && (u3.getAllHeaders = e4, u3.getHeader = t2), u3.httpStatus = (null != r4.httpCode ? r4.httpCode : r4.code) || s5 || 0, u3.subCode = r4.subcode, u3.messageCode = r4.messageCode, "string" == typeof r4.details ? u3.messages = [r4.details] : u3.messages = r4.details, u3.raw = M2 in r4 ? r4[M2] : r4;
  }
  return b(r4) ? u() : new s2(e3, l2, u3);
}
function z2() {
  return __async(this, null, function* () {
    has("host-webworker") && !A2 && (A2 = yield import("./request-QNNG7P4V.js"));
  });
}
function Q() {
  return __async(this, null, function* () {
    s3 || (yield import("./IdentityManager-H4CJMOEZ.js"));
  });
}
function W(t2) {
  return __async(this, null, function* () {
    const s5 = t2.params.url, o2 = t2.params.requestOptions, n2 = t2.controller.signal, a6 = o2.body;
    let i4 = null, u3 = null;
    if (R2 && "HTMLFormElement" in globalThis && (a6 instanceof FormData ? i4 = a6 : a6 instanceof HTMLFormElement && (i4 = new FormData(a6))), "string" == typeof a6 && (u3 = a6), t2.fetchOptions = { cache: o2.cacheBust ? "no-cache" : "default", credentials: "same-origin", headers: o2.headers || {}, method: "head" === o2.method ? "HEAD" : "GET", mode: "cors", priority: H2.priority, redirect: "follow", signal: n2 }, (i4 || u3) && (t2.fetchOptions.body = i4 || u3), "anonymous" === o2.authMode && (t2.useIdentity = false), t2.hasToken = !!(/token=/i.test(s5) || o2.query?.token || i4?.get("token")), !t2.hasToken && n(s5) && (o2.query || (o2.query = {}), o2.query.token = s.apiKey, t2.hasToken = true), t2.useIdentity && !t2.hasToken && !t2.credentialToken && !G2(s5) && !c(n2)) {
      let e3;
      "immediate" === o2.authMode ? (yield Q(), e3 = yield s3.getCredential(s5, { signal: n2 }), t2.credential = e3) : "no-prompt" === o2.authMode ? (yield Q(), e3 = yield s3.getCredential(s5, { prompt: false, signal: n2 }).catch(() => {
      }), t2.credential = e3) : s3 && (e3 = s3.findCredential(s5)), e3 && (t2.credentialToken = e3.token, t2.useSSL = !!e3.ssl);
    }
  });
}
function G2(e3) {
  return F2.some((r4) => r4.test(e3));
}
function J(e3) {
  return __async(this, null, function* () {
    let t2 = e3.params.url;
    const s5 = e3.params.requestOptions, o2 = e3.fetchOptions ?? {}, n2 = Z(t2) || tt(t2), a6 = s5.responseType || "json", l2 = n2 ? 0 : null != s5.timeout ? s5.timeout : H2.timeout;
    let u3 = false;
    if (!n2) {
      e3.useSSL && (t2 = $t(t2));
      let n3 = __spreadValues({}, s5.query);
      e3.credentialToken && (n3.token = e3.credentialToken);
      let a7 = v(n3);
      has("esri-url-encodes-apostrophe") && (a7 = a7.replaceAll("'", "%27"));
      const i4 = t2.length + 1 + a7.length;
      let l3;
      u3 = "delete" === s5.method || "post" === s5.method || "put" === s5.method || !!s5.body || i4 > H2.maxUrlLength;
      const c4 = s5.useProxy || !!H(t2);
      if (c4) {
        const e4 = S(t2);
        l3 = e4.path, !u3 && l3.length + 1 + i4 > H2.maxUrlLength && (u3 = true), e4.query && (n3 = __spreadValues(__spreadValues({}, e4.query), n3));
      }
      if ("HEAD" === o2.method && (u3 || c4)) {
        if (u3) {
          if (i4 > H2.maxUrlLength) throw $("request:invalid-parameters", new Error("URL exceeds maximum length"), e3.params);
          throw $("request:invalid-parameters", new Error("cannot use POST request when method is 'head'"), e3.params);
        }
        if (c4) throw $("request:invalid-parameters", new Error("cannot use proxy when method is 'head'"), e3.params);
      }
      if (u3 ? (o2.method = "delete" === s5.method ? "DELETE" : "put" === s5.method ? "PUT" : "POST", s5.body ? t2 = Et(t2, n3) : (o2.body = v(n3), o2.headers || (o2.headers = {}), o2.headers["Content-Type"] = "application/x-www-form-urlencoded")) : t2 = Et(t2, n3), c4 && (e3.useProxy = true, t2 = `${l3}?${t2}`), n3.token && R2 && o2.body instanceof FormData && !a2(t2) && o2.body.set("token", n3.token), s5.hasOwnProperty("withCredentials")) e3.withCredentials = s5.withCredentials;
      else if (!F(t2, C())) {
        if (M(t2)) e3.withCredentials = true;
        else if (s3) {
          const s6 = s3.findServerInfo(t2);
          s6?.webTierAuth && (e3.withCredentials = true);
        }
      }
      e3.withCredentials && (o2.credentials = "include", d3(t2) && (yield f3(u3 ? Et(t2, n3) : t2)));
    }
    let p3, m5, O = 0, C3 = false;
    l2 > 0 && (O = setTimeout(() => {
      C3 = true, e3.controller.abort();
    }, l2));
    try {
      if ("native-request-init" === s5.responseType) m5 = o2, m5.url = t2, s5.signal ? m5.signal = s5.signal : delete m5.signal;
      else if ("image" !== s5.responseType || "default" !== o2.cache || "GET" !== o2.method || u3 || X2(s5.headers) || !n2 && !e3.useProxy && H2.proxyUrl && !B(t2)) {
        if (P2._beforeFetch && (yield P2._beforeFetch(t2, o2)), p3 = yield fetch(t2, o2), P2._afterFetch && (yield P2._afterFetch(p3)), e3.useProxy || N(t2), "native" === s5.responseType) m5 = p3;
        else if ("HEAD" !== o2.method) if (p3.ok) {
          switch (a6) {
            case "array-buffer":
              m5 = yield p3.arrayBuffer();
              break;
            case "blob":
            case "image":
              m5 = yield p3.blob();
              break;
            default:
              m5 = yield p3.text();
          }
          if (O && (clearTimeout(O), O = 0), "json" === a6 || "xml" === a6 || "document" === a6) if (m5) switch (a6) {
            case "json":
              m5 = JSON.parse(m5);
              break;
            case "xml":
              m5 = V2(m5, "application/xml");
              break;
            case "document":
              m5 = V2(m5, "text/html");
          }
          else m5 = null;
          if (m5) {
            if ("array-buffer" === a6 || "blob" === a6) {
              const e4 = p3.headers.get("Content-Type");
              if (e4 && /application\/json|text\/plain/i.test(e4) && m5["blob" === a6 ? "size" : "byteLength"] <= 750) try {
                const e5 = yield new Response(m5).json();
                e5.error && (m5 = e5);
              } catch {
              }
            }
            "image" === a6 && m5 instanceof Blob && (m5 = yield te(URL.createObjectURL(m5), e3, true));
          }
        } else {
          m5 = yield p3.text();
          try {
            m5 = JSON.parse(m5);
          } catch {
          }
        }
      } else m5 = yield te(t2, e3);
    } catch (x3) {
      if ("AbortError" === x3.name) {
        if (C3) throw u2();
        throw u("Request canceled");
      }
      if (!(!p3 && x3 instanceof TypeError && H2.proxyUrl) || s5.body || "delete" === s5.method || "head" === s5.method || "post" === s5.method || "put" === s5.method || e3.useProxy || B(t2)) throw x3;
      e3.redoRequest = true, z({ proxyUrl: H2.proxyUrl, urlPrefix: X(t2) ?? "" });
    } finally {
      O && clearTimeout(O);
    }
    return [p3, m5];
  });
}
function K2(e3, r4) {
  return __async(this, null, function* () {
    if (null != e3.responseData) return e3.responseData;
    if (e3.headers && (r4.requestOptions.headers = __spreadValues(__spreadValues({}, r4.requestOptions.headers), e3.headers)), e3.query && (r4.requestOptions.query = __spreadValues(__spreadValues({}, r4.requestOptions.query), e3.query)), e3.before) {
      let o2, n2;
      try {
        n2 = yield e3.before(r4);
      } catch (s5) {
        o2 = $("request:interceptor", s5, r4);
      }
      if ((n2 instanceof Error || n2 instanceof s2) && (o2 = $("request:interceptor", n2, r4)), o2) throw e3.error && e3.error(o2), o2;
      return n2;
    }
  });
}
function X2(e3) {
  if (e3) {
    for (const r4 of Object.getOwnPropertyNames(e3)) if (e3[r4]) return true;
  }
  return false;
}
function V2(e3, r4) {
  let t2;
  try {
    t2 = new DOMParser().parseFromString(e3, r4);
  } catch {
  }
  if (!t2 || t2.getElementsByTagName("parsererror").length) throw new SyntaxError("XML Parse error");
  return t2;
}
P2._corsServers = ["https://server.arcgisonline.com", "https://services.arcgisonline.com"], P2._beforeFetch = void 0, P2._afterFetch = void 0;
var Y2 = /* @__PURE__ */ new Map();
function Z2(e3) {
  return __async(this, null, function* () {
    const r4 = se(e3.params.url);
    if (!r4) return ee(e3);
    const { QueueProcessor: t2 } = yield import("./QueueProcessor-MSC674QM.js"), s5 = r(Y2, r4.origin, () => {
      const e4 = r4.isHosted ? has("request-queue-concurrency-hosted") : has("request-queue-concurrency-non-hosted");
      return new t2({ concurrency: e4, process: (e5) => {
        if (c(e5.params.requestOptions)) throw $("", u("Request canceled"), e5.params);
        return ee(e5);
      } });
    });
    return s5.push(e3);
  });
}
function ee(e3) {
  return __async(this, null, function* () {
    let t2, s5;
    yield W(e3);
    try {
      do {
        [t2, s5] = yield J(e3);
      } while (!(yield re(e3, t2, s5)));
    } catch (a6) {
      const r4 = $("request:server", a6, e3.params, t2);
      throw r4.details.ssl = e3.useSSL, e3.interceptor?.error && e3.interceptor.error(r4), r4;
    }
    const o2 = e3.params.url;
    if (s5 && /\/sharing\/rest\/(accounts|portals)\/self/i.test(o2)) {
      if (!e3.hasToken && !e3.credentialToken && s5.user?.username && !M(o2)) {
        const e4 = X(o2, true);
        e4 && H2.trustedServers.push(e4);
      }
      Array.isArray(s5.authorizedCrossOriginNoCorsDomains) && l(s5.authorizedCrossOriginNoCorsDomains);
    }
    const n2 = e3.credential;
    if (n2 && s3) {
      const e4 = s3.findServerInfo(n2.server);
      let t3 = e4?.owningSystemUrl;
      if (t3) {
        t3 = t3.replace(/\/?$/, "/sharing");
        const e5 = s3.findCredential(t3, n2.userId);
        e5 && -1 === s3._getIdenticalSvcIdx(t3, e5) && e5.resources.unshift(t3);
      }
    }
    return { data: s5, getAllHeaders: t2 ? () => Array.from(t2.headers) : I3, getHeader: t2 ? (e4) => t2.headers.get(e4) : I3, httpStatus: t2?.status ?? 200, requestOptions: e3.params.requestOptions, ssl: e3.useSSL, url: e3.params.url };
  });
}
function re(e3, t2, s5) {
  return __async(this, null, function* () {
    if (e3.redoRequest) return e3.redoRequest = false, false;
    const o2 = e3.params.requestOptions;
    if (!t2 || "native" === o2.responseType || "native-request-init" === o2.responseType) return true;
    let n2, a6;
    if (s5 && (s5.error && "object" == typeof s5.error ? n2 = s5.error : "error" === s5.status && Array.isArray(s5.messages) && (n2 = __spreadValues({}, s5), n2[M2] = s5, n2.details = s5.messages)), !n2 && !t2.ok) throw n2 = new Error(`Unable to load ${t2.url} status: ${t2.status}`), n2[M2] = s5, n2;
    let i4, l2 = null;
    n2 && (a6 = Number(n2.code), l2 = n2.hasOwnProperty("subcode") ? Number(n2.subcode) : null, i4 = n2.messageCode, i4 = i4?.toUpperCase());
    const u3 = o2.authMode;
    if (403 === a6 && (4 === l2 || n2.message?.toLowerCase().includes("ssl") && !n2.message.toLowerCase().includes("permission"))) {
      if (!e3.useSSL) return e3.useSSL = true, false;
    } else if (!e3.hasToken && e3.useIdentity && ("no-prompt" !== u3 || 498 === a6) && void 0 !== a6 && _2.has(a6) && !G2(e3.params.url) && (403 !== a6 || (!i4 || !D2.has(i4)) && (null == l2 || 2 === l2 && e3.credentialToken))) {
      yield Q();
      try {
        const t3 = yield s3.getCredential(e3.params.url, { error: $("request:server", n2, e3.params), prompt: "no-prompt" !== u3, signal: e3.controller.signal, token: e3.credentialToken });
        return e3.credential = t3, e3.credentialToken = t3.token, e3.useSSL = e3.useSSL || t3.ssl, false;
      } catch (c4) {
        if ("no-prompt" === u3) return e3.credential = void 0, e3.credentialToken = void 0, false;
        n2 = c4;
      }
    }
    if (n2) throw n2;
    return true;
  });
}
function te(e3, r4, t2 = false) {
  const s5 = r4.controller.signal, o2 = new Image();
  return r4.withCredentials ? o2.crossOrigin = "use-credentials" : o2.crossOrigin = "anonymous", o2.alt = "", o2.fetchPriority = H2.priority, o2.src = e3, i3(o2, e3, t2, s5);
}
function se(e3) {
  let r4, t2;
  return "string" == typeof e3 ? (r4 = X(e3, true), t2 = g2(e3)) : (r4 = e3.origin, t2 = g2(e3.toString())), null == r4 ? null : { origin: r4, isHosted: t2 };
}

export {
  a3 as a,
  e,
  e2,
  s3 as s,
  r3 as r,
  i,
  t,
  p,
  m2 as m,
  f,
  h,
  U,
  g,
  x,
  R,
  y,
  P,
  p2,
  d2 as d,
  h2,
  m3 as m2,
  w2 as w,
  g2,
  y2,
  S2 as S,
  C2 as C,
  b2 as b,
  n,
  i3 as i2,
  m4 as m3,
  P2
};
//# sourceMappingURL=chunk-ADRG7ORV.js.map
