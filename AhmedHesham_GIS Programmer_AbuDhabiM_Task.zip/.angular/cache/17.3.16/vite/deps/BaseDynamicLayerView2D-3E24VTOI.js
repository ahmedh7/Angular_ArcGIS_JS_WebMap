import {
  _
} from "./chunk-RSIT7P2Q.js";
import {
  r as r2
} from "./chunk-GV6HQUWZ.js";
import "./chunk-FFDJVTNW.js";
import {
  i
} from "./chunk-7U65WB7R.js";
import "./chunk-VGYZO5HJ.js";
import "./chunk-O4NL4QZF.js";
import {
  S
} from "./chunk-TDZIOYA4.js";
import {
  y
} from "./chunk-YPRFDORJ.js";
import "./chunk-YDLYZSD6.js";
import "./chunk-KEKYRYUA.js";
import "./chunk-533JJUXT.js";
import "./chunk-ZCMIPKW3.js";
import "./chunk-X6T5VEW7.js";
import "./chunk-E4HJHXVP.js";
import "./chunk-RQ6IQ4BT.js";
import "./chunk-3KYOSJE7.js";
import "./chunk-56WSBGZV.js";
import "./chunk-QMWFG3RP.js";
import "./chunk-OJJ7RDNK.js";
import "./chunk-J27IB6CR.js";
import "./chunk-4G6QLHLE.js";
import "./chunk-HK6ZY4DB.js";
import "./chunk-6BUGRELN.js";
import "./chunk-KATWIIRQ.js";
import "./chunk-OQS7WWFI.js";
import "./chunk-P7U5GMBX.js";
import "./chunk-5JVPNPMF.js";
import "./chunk-CEREZWZ6.js";
import "./chunk-5BGQWKMP.js";
import "./chunk-SQ26WZ7J.js";
import "./chunk-PAXNBAQG.js";
import "./chunk-LYJYKR5U.js";
import "./chunk-UF7FRKBZ.js";
import "./chunk-N3UNX5HB.js";
import "./chunk-UQISDG6Y.js";
import "./chunk-VACYGDXY.js";
import "./chunk-77RFUTEK.js";
import "./chunk-L3LR7QC5.js";
import "./chunk-MKDJERJR.js";
import "./chunk-O3P5XPEU.js";
import "./chunk-UPSWNHFU.js";
import "./chunk-EDBHW3EG.js";
import "./chunk-3RDPSSYB.js";
import "./chunk-SZIT3IYE.js";
import "./chunk-P5BI27MR.js";
import "./chunk-DTRN4OOH.js";
import "./chunk-3P3SZYCX.js";
import "./chunk-4VNKTESB.js";
import "./chunk-KVZR5ILN.js";
import "./chunk-HLUCHGW6.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-ACRU4UL2.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-DSFF7UA2.js";
import "./chunk-MMJWRZE3.js";
import "./chunk-WSZKFRXT.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-XYTETMU6.js";
import "./chunk-VYI6FOKY.js";
import "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  b
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  n2 as n
} from "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/2d/layers/BaseDynamicLayerView2D.js
var m2 = class extends i(S(y)) {
  update(t) {
    this._strategy.update(t).catch((t2) => {
      b(t2) || n.getLogger(this).error(t2);
    }), this.notifyChange("updating");
  }
  attach() {
    this._bitmapContainer = new r2(), this.container.addChild(this._bitmapContainer), this._strategy = new _({ container: this._bitmapContainer, fetchSource: this.fetchBitmapData.bind(this), requestUpdate: this.requestUpdate.bind(this) });
  }
  detach() {
    this._strategy.destroy(), this._strategy = null, this.container.removeChild(this._bitmapContainer), this._bitmapContainer.removeAllChildren();
  }
  viewChange() {
  }
  moveEnd() {
    this.requestUpdate();
  }
  fetchBitmapData(t, e, r3) {
    return this.layer.fetchImageBitmap(t, e, r3);
  }
  doRefresh() {
    return __async(this, null, function* () {
      this.requestUpdate();
    });
  }
  isUpdating() {
    return this._strategy.updating || this.updateRequested;
  }
};
r([m()], m2.prototype, "_strategy", void 0), r([m()], m2.prototype, "updating", void 0), m2 = r([a("esri.views.2d.layers.BaseDynamicLayerView2D")], m2);
var d = m2;
export {
  d as default
};
//# sourceMappingURL=BaseDynamicLayerView2D-3E24VTOI.js.map
