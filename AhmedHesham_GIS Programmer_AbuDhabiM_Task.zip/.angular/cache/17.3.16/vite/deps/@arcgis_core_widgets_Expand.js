import {
  e as e3,
  t
} from "./chunk-JYALIYUG.js";
import "./chunk-HL6SQA2H.js";
import "./chunk-ECG7JDDX.js";
import "./chunk-NE6ESLWJ.js";
import {
  e as e2
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c,
  e
} from "./chunk-PPAPRIQT.js";
import {
  n2 as n
} from "./chunk-L7IGKLK6.js";
import "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import {
  P,
  U,
  d,
  p,
  v
} from "./chunk-VYI6FOKY.js";
import "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/Expand/ExpandViewModel.js
var p2 = class extends g {
  constructor(e4) {
    super(e4), this._viewpointHandle = null, this.group = null;
  }
  initialize() {
    this.addHandles(v(() => this.view?.ui, "expand", (e4) => {
      const { target: t2 } = e4;
      t2 && t2 !== this && t2.expanded && t2.group && t2.group === this.group && this._collapse();
    }));
  }
  destroy() {
    this._viewpointHandle = null, this.view = null;
  }
  set autoCollapse(e4) {
    this._set("autoCollapse", e4), this._watchViewpoint();
  }
  set expanded(e4) {
    const t2 = !!e4;
    this._set("expanded", t2);
    const i = this.view?.ui;
    i && i.emit("expand", { target: this }), this._viewpointHandleChange(t2);
  }
  get state() {
    return this.view?.ready ? "ready" : "disabled";
  }
  set view(e4) {
    this._get("view") !== e4 && (this._set("view", e4), e4 && p(() => e4.ready, () => {
      this.view === e4 && this._watchViewpoint();
    }, { once: true, initial: true }));
  }
  _viewpointHandleChange(e4) {
    this._viewpointHandle && (e4 ? p(() => this.view?.stationary, () => this._viewpointHandle?.resume(), { once: true, initial: true }) : this._viewpointHandle.pause());
  }
  _watchViewpoint() {
    const e4 = "viewpoint";
    this.removeHandles(e4), this._viewpointHandle = null;
    const { autoCollapse: t2, view: i } = this;
    if (!i || !t2) return;
    const s = U(() => "3d" === i.type ? i.camera : i.viewpoint, () => this._collapse());
    this.addHandles(s, e4), this._viewpointHandle = s;
  }
  _collapse() {
    this.expanded = false;
  }
};
r([m({ value: false })], p2.prototype, "autoCollapse", null), r([m({ value: false })], p2.prototype, "expanded", null), r([m()], p2.prototype, "group", void 0), r([m({ readOnly: true })], p2.prototype, "state", null), r([m({ value: null })], p2.prototype, "view", null), p2 = r([a("esri.widgets.Expand.ExpandViewModel")], p2);
var r2 = p2;

// node_modules/@arcgis/core/widgets/Expand.js
var u = "esri-expand";
var m2 = { base: u, toggle: `${u}__toggle`, popoverContent: `${u}__popover-content`, panel: `${u}__panel`, panelContent: `${u}__panel-content`, sheet: `${u}__sheet`, panelIconNumber: `${u}__panel-icon-number`, contentContainer: `${u}__content-container`, icon: "esri-collapse__icon", iconFlip: "esri-collapse__icon-flip", iconExpanded: `${u}__icon--expanded`, iconNumber: `${u}__icon-number`, content: `${u}__content`, contentExpanded: `${u}__content--expanded` };
var _ = "chevrons-left";
var g2 = "chevrons-right";
var v2 = class extends O {
  constructor(e4, t2) {
    super(e4, t2), this.closeOnEsc = true, this.collapseTooltip = "", this.content = "", this.expandTooltip = "", this.focusTrapDisabled = false, this.iconNumber = 0, this.messages = null, this.messagesCommon = null, this.mode = "auto", this.placement = null, this.viewModel = new r2(), this.toggle = () => {
      this.viewModel.expanded = !this.viewModel.expanded;
    }, this._handlePopoverClose = (e5) => {
      e5.target === this._popoverEl && (this.viewModel.expanded = e5.currentTarget.open);
    }, this._handleSheetClose = (e5) => {
      this.viewModel.expanded = e5.currentTarget.open;
    }, this._handlePanelClose = (e5) => {
      this.viewModel.expanded = !e5.currentTarget.closed;
    }, this._handleKeyDown = (e5) => {
      this.viewModel.expanded && "Escape" === e5.key && !this._willCloseOnEsc(e5) && e5.preventDefault();
    }, this._storeToggleActionEl = (e5) => {
      this._toggleActionEl = e5;
    }, this._storePopoverEl = (e5) => {
      this._popoverEl = e5;
    };
  }
  initialize() {
    this.addHandles(d(() => this.viewModel?.view?.size, () => this._popoverEl?.reposition(), P));
  }
  loadDependencies() {
    return c({ action: () => import("./calcite-action-QPIDLQ7A.js"), icon: () => import("./calcite-icon-TH7JL242.js"), panel: () => import("./calcite-panel-BL4CNSS2.js"), popover: () => import("./calcite-popover-62MC4LJC.js"), sheet: () => import("./calcite-sheet-KTZ5DXNT.js") });
  }
  get expandTitle() {
    const { expanded: e4, messagesCommon: t2, collapseTooltip: o, expandTooltip: n2 } = this;
    return (e4 ? o || t2?.collapse : n2 || t2?.expand) ?? "";
  }
  get _displaySheet() {
    switch (this.mode) {
      case "drawer":
        return true;
      case "auto":
        return "xsmall" === this.viewModel.view?.widthBreakpoint;
      default:
        return false;
    }
  }
  get autoCollapse() {
    return this.viewModel.autoCollapse;
  }
  set autoCollapse(e4) {
    this.viewModel.autoCollapse = e4;
  }
  get collapseIcon() {
    return g2;
  }
  set collapseIcon(e4) {
    this._overrideIfSome("collapseIcon", e4);
  }
  get expanded() {
    return this.viewModel.expanded;
  }
  set expanded(e4) {
    this.viewModel.expanded = e4;
  }
  get expandIcon() {
    return e3(this.content) ? this.content.icon : _;
  }
  set expandIcon(e4) {
    this._overrideIfSome("expandIcon", e4);
  }
  get group() {
    return this.viewModel.group;
  }
  set group(e4) {
    this.viewModel.group = e4;
  }
  get icon() {
    return null;
  }
  get label() {
    return (e3(this.content) ? this.content.label : null) ?? this.messages?.widgetLabel ?? "";
  }
  set label(e4) {
    this._overrideIfSome("label", e4);
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e4) {
    this.viewModel.view = e4;
  }
  expand() {
    this.viewModel.expanded = true;
  }
  collapse() {
    this.viewModel.expanded = false;
  }
  render() {
    const { _displaySheet: e4, _toggleActionEl: t2, viewModel: { expanded: o }, label: n2, placement: s } = this;
    return n("div", { class: this.classes(m2.base, e2.widget) }, this._renderToggle(), e4 ? n("calcite-sheet", { class: m2.sheet, heightScale: "l", label: n2, onkeydown: this._handleKeyDown, open: o, position: "block-end", onCalciteSheetClose: this._handleSheetClose }, n("calcite-panel", { class: m2.panel, closable: true, closed: !o, heading: n2, onkeydown: this._handleKeyDown, onCalcitePanelClose: this._handlePanelClose }, n("div", { class: m2.panelContent }, this._renderContent()))) : t2 ? n("calcite-popover", { afterCreate: this._storePopoverEl, afterUpdate: this._storePopoverEl, focusTrapDisabled: this.focusTrapDisabled, label: n2, onkeydown: this._handleKeyDown, open: o, overlayPositioning: "fixed", placement: s ?? this._getPlacement(), referenceElement: t2, onCalcitePopoverClose: this._handlePopoverClose }, n("div", { class: m2.popoverContent }, this._renderContent())) : null);
  }
  _getPlacement() {
    const { container: e4, view: t2 } = this, o = e4 && t2 ? t2.ui.getPosition(e4) : null;
    if (!o || "manual" === o) return "auto";
    const [n2, s] = o.split("-");
    return `${"right" === s ? "left" : "right"}-${"bottom" === n2 ? "end" : "start"}`;
  }
  _willCloseOnEsc(e4) {
    const { closeOnEsc: t2 } = this;
    return "function" == typeof t2 ? t2(e4) : t2;
  }
  _renderBadgeNumber() {
    const { expanded: e4, iconNumber: t2 } = this;
    return t2 && !e4 ? n("span", { class: m2.iconNumber, key: "expand__icon-number" }, t2) : null;
  }
  _renderToggleButton() {
    const { expanded: e4, expandTitle: t2, expandIcon: o, collapseIcon: n2 } = this, s = e4 ? n2 : o, i = s === _ || s === g2;
    return n("calcite-action", { afterCreate: this._storeToggleActionEl, afterUpdate: this._storeToggleActionEl, class: e2.widgetButton, onclick: this.toggle, scale: "s", text: t2, title: t2 }, s ? n("calcite-icon", { class: this.classes(m2.icon, i && m2.iconFlip), icon: s, scale: "s" }) : null);
  }
  _renderToggle() {
    return n("div", { class: m2.toggle }, this._renderToggleButton(), this._renderBadgeNumber());
  }
  _renderContent() {
    const { content: e4 } = this;
    return "string" == typeof e4 ? n("div", { class: m2.contentContainer, innerHTML: e4, key: "content__string" }) : e3(e4) ? n("div", { class: m2.contentContainer, key: "content__widget" }, e4.render()) : e4 instanceof HTMLElement ? n("div", { afterCreate: this._attachToNode, bind: e4, class: m2.contentContainer, key: "content__html-element" }) : t(e4) ? n("div", { afterCreate: this._attachToNode, bind: e4.domNode, class: m2.contentContainer, key: "content__node" }) : null;
  }
  _attachToNode(e4) {
    const t2 = this;
    e4.appendChild(t2);
  }
};
r([m({ readOnly: true })], v2.prototype, "expandTitle", null), r([m()], v2.prototype, "_toggleActionEl", void 0), r([m()], v2.prototype, "_displaySheet", null), r([m()], v2.prototype, "autoCollapse", null), r([m()], v2.prototype, "closeOnEsc", void 0), r([m()], v2.prototype, "collapseIcon", null), r([m()], v2.prototype, "collapseTooltip", void 0), r([m()], v2.prototype, "content", void 0), r([m()], v2.prototype, "expanded", null), r([m()], v2.prototype, "expandIcon", null), r([m()], v2.prototype, "expandTooltip", void 0), r([m()], v2.prototype, "focusTrapDisabled", void 0), r([m()], v2.prototype, "group", null), r([m()], v2.prototype, "icon", null), r([m()], v2.prototype, "iconNumber", void 0), r([m()], v2.prototype, "label", null), r([m(), e("esri/widgets/Expand/t9n/Expand")], v2.prototype, "messages", void 0), r([m(), e("esri/t9n/common")], v2.prototype, "messagesCommon", void 0), r([m()], v2.prototype, "mode", void 0), r([m()], v2.prototype, "placement", void 0), r([m()], v2.prototype, "view", null), r([m({ type: r2 })], v2.prototype, "viewModel", void 0), v2 = r([a("esri.widgets.Expand")], v2);
var w = v2;
export {
  w as default
};
//# sourceMappingURL=@arcgis_core_widgets_Expand.js.map
