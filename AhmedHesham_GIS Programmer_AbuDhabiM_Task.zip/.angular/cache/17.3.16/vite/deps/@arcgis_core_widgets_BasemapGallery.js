import {
  e as e4
} from "./chunk-DSFF7UA2.js";
import {
  e as e3
} from "./chunk-OWFGHE2Q.js";
import {
  a as a2,
  l
} from "./chunk-GW436Z36.js";
import {
  p as p3,
  z
} from "./chunk-MMJWRZE3.js";
import "./chunk-WSZKFRXT.js";
import {
  K,
  L,
  k
} from "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import {
  t
} from "./chunk-NE6ESLWJ.js";
import {
  e as e2
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c,
  e
} from "./chunk-PPAPRIQT.js";
import {
  n2
} from "./chunk-L7IGKLK6.js";
import "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import {
  m as m4
} from "./chunk-KW4QKNM6.js";
import {
  F
} from "./chunk-LYIAE2PQ.js";
import "./chunk-C6UECS42.js";
import "./chunk-B6U4AYDJ.js";
import {
  d as d2,
  j as j2,
  s as s6,
  u as u2,
  y as y2
} from "./chunk-JCECTBEZ.js";
import "./chunk-YFQQ5MRE.js";
import "./chunk-CYXXOYR3.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import {
  M,
  f,
  n as n4,
  y
} from "./chunk-2K433C2G.js";
import {
  C as C2
} from "./chunk-EOJGN7NW.js";
import {
  m as m3
} from "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import {
  n as n5
} from "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import {
  p
} from "./chunk-XYTETMU6.js";
import {
  P,
  d,
  p as p2,
  v,
  w
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import {
  o,
  u
} from "./chunk-3X4RHLTI.js";
import {
  w as w3
} from "./chunk-FMVDY4TM.js";
import {
  c as c2,
  h,
  j2 as j
} from "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import {
  g as g2
} from "./chunk-P5ELECBN.js";
import {
  A,
  S as S2,
  m as m2,
  q,
  s as s5
} from "./chunk-HJWYGMG7.js";
import {
  C,
  D,
  P2,
  Q,
  S,
  W,
  s2 as s4,
  w as w2
} from "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import {
  s as s3
} from "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import {
  n as n3
} from "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  g,
  m,
  r as r2
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  b,
  s as s2
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  n2 as n,
  s2 as s
} from "./chunk-JB56QM27.js";
import {
  G
} from "./chunk-D5RIMQ7U.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/3d/terrain/NeighborIndex.js
var T;
!function(T2) {
  T2[T2.NORTH = 0] = "NORTH", T2[T2.NORTH_EAST = 1] = "NORTH_EAST", T2[T2.EAST = 2] = "EAST", T2[T2.SOUTH_EAST = 3] = "SOUTH_EAST", T2[T2.SOUTH = 4] = "SOUTH", T2[T2.SOUTH_WEST = 5] = "SOUTH_WEST", T2[T2.WEST = 6] = "WEST", T2[T2.NORTH_WEST = 7] = "NORTH_WEST";
}(T || (T = {}));

// node_modules/@arcgis/core/views/3d/support/supportedSpatialReference.js
function o2(e7) {
  return i(e7) || D(e7) || W(e7);
}
function i(r6) {
  return C(r6) || w2(r6);
}

// node_modules/@arcgis/core/views/3d/terrain/TilingScheme.js
var g3 = 12;
var f2 = class _f {
  constructor(e7) {
    const t4 = _f.checkUnsupported(e7);
    if (null != t4) throw t4;
    const i2 = e7;
    this.spatialReference = i2.spatialReference, this._isWebMercator = this.spatialReference.isWebMercator, this._isGCS = P2(this.spatialReference), this.origin = [i2.origin.x, i2.origin.y], this.pixelSize = i2.size[0], this.dpi = i2.dpi;
    const s10 = i2.lods.reduce((e8, t5) => (t5.level < e8.minLod.level && (e8.minLod = t5), e8.max = Math.max(e8.max, t5.level), e8), { minLod: i2.lods[0], max: -1 / 0 }), r6 = s10.minLod, l3 = 2 ** r6.level;
    let n8 = r6.resolution * l3, o3 = r6.scale * l3;
    this.levels = new Array(s10.max + 1);
    for (let a5 = 0; a5 < this.levels.length; a5++) this.levels[a5] = { resolution: n8, scale: o3, tileSize: [n8 * i2.size[0], n8 * i2.size[1]] }, n8 /= 2, o3 /= 2;
  }
  clone() {
    return new _f(this.toTileInfo());
  }
  toTileInfo() {
    return new z({ dpi: this.dpi, origin: new j({ x: this.origin[0], y: this.origin[1], spatialReference: this.spatialReference }), size: [this.pixelSize, this.pixelSize], spatialReference: this.spatialReference, lods: this.levels.map((e7, t4) => new p3({ level: t4, scale: e7.scale, resolution: e7.resolution })) });
  }
  getExtent(e7, t4, i2, s10) {
    const r6 = this.levels[e7], l3 = r6.tileSize[0], n8 = r6.tileSize[1];
    s10[0] = this.origin[0] + i2 * l3, s10[2] = this.origin[0] + (i2 + 1) * l3, s10[3] = this.origin[1] - t4 * n8, s10[1] = this.origin[1] - (t4 + 1) * n8;
  }
  convertExtentToRadians(e7, i2) {
    this._isWebMercator ? (i2[0] = c2(e7[0]), i2[1] = h(e7[1]), i2[2] = c2(e7[2]), i2[3] = h(e7[3])) : this._isGCS && (i2[0] = s5(e7[0]), i2[1] = s5(e7[1]), i2[2] = s5(e7[2]), i2[3] = s5(e7[3]));
  }
  getExtentGeometry(e7, t4, i2, s10 = new w3()) {
    return this.getExtent(e7, t4, i2, v2), s10.spatialReference = this.spatialReference, s10.xmin = v2[0], s10.ymin = v2[1], s10.xmax = v2[2], s10.ymax = v2[3], s10.zmin = void 0, s10.zmax = void 0, s10;
  }
  ensureMaxLod(e7) {
    if (null == e7) return false;
    let t4 = false;
    for (; this.levels.length <= e7; ) {
      const { resolution: e8, scale: i2 } = this.levels[this.levels.length - 1], s10 = e8 / 2 * this.pixelSize;
      this.levels.push({ resolution: e8 / 2, scale: i2 / 2, tileSize: [s10, s10] }), t4 = true;
    }
    return t4;
  }
  capMaxLod(e7) {
    this.levels.length > e7 + 1 && (this.levels.length = e7 + 1);
  }
  getMaxLod() {
    return this.levels.length - 1;
  }
  scaleAtLevel(e7) {
    return this.levels[0].scale / 2 ** e7;
  }
  levelAtScale(e7) {
    const t4 = this.levels[0].scale;
    return e7 >= t4 ? 0 : Math.log(t4 / e7) * Math.LOG2E;
  }
  resolutionAtLevel(e7) {
    return this.levels[0].resolution / 2 ** e7;
  }
  compatibleWith(e7, t4 = 1 / 0) {
    if (_f.checkUnsupported(e7)) return false;
    const s10 = new _f(e7);
    if (!s10.spatialReference.equals(this.spatialReference)) return false;
    if (s10.pixelSize !== this.pixelSize) return false;
    const r6 = Math.min(this.levels.length - 1, s10.levels.length - 1, t4), l3 = this.levels[r6].resolution;
    let n8 = 0.5 * l3;
    if (!m2(s10.origin[0], this.origin[0], n8) || !m2(s10.origin[1], this.origin[1], n8)) return false;
    return n8 = 0.5 * l3 / 2 ** r6 / this.pixelSize * g3, m2(l3, s10.levels[r6].resolution, n8);
  }
  rootTilesInExtent(e7, t4 = null, i2 = 1 / 0) {
    const s10 = new Array(), r6 = this.levels[0].tileSize;
    if (null == e7 || 0 === r6[0] || 0 === r6[1]) return s10;
    _f.computeRowColExtent(e7, r6, this.origin, v2);
    let l3 = v2[1], n8 = v2[3], o3 = v2[0], a5 = v2[2];
    const h4 = a5 - o3, c6 = n8 - l3;
    if (h4 * c6 > i2) {
      const e8 = Math.floor(Math.sqrt(i2));
      c6 > e8 && (l3 = l3 + Math.floor(0.5 * c6) - Math.floor(0.5 * e8), n8 = l3 + e8), h4 > e8 && (o3 = o3 + Math.floor(0.5 * h4) - Math.floor(0.5 * e8), a5 = o3 + e8);
    }
    for (let m7 = l3; m7 < n8; m7++) for (let e8 = o3; e8 < a5; e8++) s10.push([0, m7, e8]);
    return null != t4 && (t4[0] = this.origin[0] + o3 * r6[0], t4[1] = this.origin[1] - n8 * r6[1], t4[2] = this.origin[0] + a5 * r6[0], t4[3] = this.origin[1] - l3 * r6[1]), s10;
  }
  static computeRowColExtent(e7, t4, i2, s10) {
    const r6 = 1e-3 * (e7[2] - e7[0] + (e7[3] - e7[1]));
    s10[0] = Math.max(0, Math.floor((e7[0] + r6 - i2[0]) / t4[0])), s10[2] = Math.max(0, Math.ceil((e7[2] - r6 - i2[0]) / t4[0])), s10[1] = Math.max(0, Math.floor((i2[1] - e7[3] + r6) / t4[1])), s10[3] = Math.max(0, Math.ceil((i2[1] - e7[1] - r6) / t4[1]));
  }
  static isPowerOfTwo(e7) {
    const t4 = e7.lods, i2 = t4[0].resolution * 2 ** t4[0].level;
    return !t4.some((e8) => !A(e8.resolution, i2 / 2 ** e8.level));
  }
  static hasGapInLevels(e7) {
    const t4 = e7.lods.map((e8) => e8.level);
    t4.sort((e8, t5) => e8 - t5);
    for (let i2 = 1; i2 < t4.length; i2++) if (t4[i2] !== t4[0] + i2) return true;
    return false;
  }
  static tileSizeSupported(e7) {
    const t4 = e7.size[1];
    return t4 === e7.size[0] && !(t4 & t4 - 1) && t4 >= 128 && t4 <= 512;
  }
  static hasOriginPerLODs(e7) {
    const t4 = e7.origin;
    return e7.lods.some((e8) => null != e8.origin && (e8.origin[0] !== t4.x || e8.origin[1] !== t4.y));
  }
  static getMissingTileInfoError() {
    return new s("tilingscheme:tile-info-missing", "Tiling scheme must have tiling information");
  }
  static checkUnsupported(t4) {
    return null == t4 ? x() : t4.lods.length < 1 ? new s("tilingscheme:generic", "Tiling scheme must have at least one level") : _f.isPowerOfTwo(t4) ? _f.hasGapInLevels(t4) ? new s("tilingscheme:gaps", "Tiling scheme levels must not have gaps between min and max level") : _f.tileSizeSupported(t4) ? _f.hasOriginPerLODs(t4) ? new s("tilingscheme:multiple-origin", "Tiling scheme levels must not have their own origin") : null : new s("tilingscheme:tile-size", "Tiles must be square and size must be one of [128, 256, 512]") : new s("tilingscheme:power-of-two", "Tiling scheme must be power of two");
  }
  static fromExtent(e7, t4) {
    const i2 = e7[2] - e7[0], s10 = e7[3] - e7[1], l3 = Q(t4), o3 = 1.2 * Math.max(i2, s10), a5 = 256, h4 = o3 / a5, c6 = h4 * l3 * (96 / 0.0254), m7 = new _f(new z({ size: [a5, a5], origin: new j({ x: e7[0] - 0.5 * (o3 - i2), y: e7[3] + 0.5 * (o3 - s10) }), lods: [new p3({ level: 0, resolution: h4, scale: c6 })], spatialReference: t4 }));
    return m7.ensureMaxLod(20), m7;
  }
  static makeWebMercatorAuxiliarySphere(e7) {
    const t4 = new _f(_f.WebMercatorAuxiliarySphereTileInfo);
    return t4.ensureMaxLod(e7), t4;
  }
  static makeGCSWithTileSize(e7, t4 = 256, i2 = 16) {
    const s10 = 256 / t4, r6 = new _f(new z({ size: [t4, t4], origin: new j({ x: -180, y: 90, spatialReference: e7 }), spatialReference: e7, lods: [new p3({ level: 0, resolution: 0.703125 * s10, scale: 295497598570834e-6 * s10 })] }));
    return r6.ensureMaxLod(i2), r6;
  }
  get test() {
  }
};
function x() {
  return new s("tilingscheme:tile-info-missing", "Tiling scheme must have tiling information");
}
f2.WebMercatorAuxiliarySphereTileInfo = new z({ size: [256, 256], origin: new j({ x: -20037508342787e-6, y: 20037508342787e-6, spatialReference: g2.WebMercator }), spatialReference: g2.WebMercator, lods: [new p3({ level: 0, resolution: 156543.03392800014, scale: 591657527591555e-6 })] }), f2.WebMercatorAuxiliarySphere = f2.makeWebMercatorAuxiliarySphere(19);
var v2 = u();

// node_modules/@arcgis/core/views/3d/terrain/TerrainConst.js
var s7 = 64;
var l2 = S2(q / 10);
var m5 = u();
f2.WebMercatorAuxiliarySphere.getExtent(0, 0, 0, m5);
var c3 = u([-180, -90, 180, 90]);

// node_modules/@arcgis/core/chunks/terrainUtilsPlanar.js
function s8(t4, o3, l3, s10) {
  if (null == t4) return x();
  const a5 = t4.spatialReference;
  if (a5.isGeographic && !i(a5)) return new s("tilingscheme:local-unsupported-spatial-reference", "The tiling scheme spatial reference is not supported in local scenes");
  const u4 = f2.checkUnsupported(t4);
  if (null != u4) return u4;
  if (null == l3) return new s("tilingscheme:extent-not-exist", "The layer does not provide a layer extent.");
  const p5 = c4(t4, l3);
  return p5 || (null == o3 || a5.equals(o3) || o3.isWGS84 && a5.isWebMercator ? null : new s("tilingscheme:spatial-reference-mismatch", "The tiling scheme does not match the spatial reference of the local scene"));
}
function c4(r6, n8) {
  const s10 = r6.lods, c6 = s10[0].resolution * 2 ** s10[0].level, a5 = [c6 * r6.size[0], c6 * r6.size[1]], u4 = [r6.origin.x, r6.origin.y], p5 = o(n8), f6 = u();
  f2.computeRowColExtent(p5, a5, u4, f6);
  const m7 = (f6[2] - f6[0]) * (f6[3] - f6[1]);
  if (m7 > s7) {
    const t4 = s10[0].scale * 2 ** s10[0].level;
    let o3 = Math.max((p5[3] - p5[1]) / r6.size[1], (p5[2] - p5[0]) / r6.size[0]) * t4 / c6;
    const n9 = Math.floor(Math.log(o3) / Math.log(10));
    return o3 = Math.ceil(o3 / 10 ** n9) * 10 ** n9, new s("tilingscheme:too-many-root-tiles", "Scale of level 0 of the tiling scheme (1:" + Math.floor(t4).toLocaleString() + ") is too large for the layer's extent. Suggested scale: 1:" + o3.toLocaleString() + ".", { level0Scale: t4, suggestedLevel0Scale: o3, requiredNumRootTiles: m7, allowedNumRootTiles: s7 });
  }
  return null;
}
var a3 = Object.freeze(Object.defineProperty({ __proto__: null, checkIfTileInfoSupportedForViewSR: s8 }, Symbol.toStringTag, { value: "Module" }));

// node_modules/@arcgis/core/chunks/terrainUtilsSpherical.js
function n6(n8, r6, c6, o3) {
  if (null == n8) return x();
  const s10 = n8?.lods.length - 1, a5 = n8.spatialReference;
  if (a5.isWebMercator) {
    if (!f2.makeWebMercatorAuxiliarySphere(s10).compatibleWith(n8, o3)) return new s("tilingscheme:incompatible-global-web-mercator", "The tiling scheme is not compatible with the ArcGIS Online Web Mercator tiling scheme");
  } else {
    if (!o2(a5)) return new s("tilingscheme:global-unsupported-spatial-reference", "The tiling scheme spatial reference is not supported in global scenes");
    if (!f2.makeGCSWithTileSize(n8.spatialReference, n8.size[0], s10).compatibleWith(n8, o3)) return n8.spatialReference.isWGS84 ? new s("tilingscheme:incompatible-global-wgs84", "The tiling scheme is not compatible with the ArcGIS Online WGS84 tiling scheme") : new s("tilingscheme:incompatible-global", "The tiling scheme is not compatible with the ArcGIS Online tiling scheme");
  }
  return null == r6 || n8.spatialReference.equals(r6) ? null : new s("tilingscheme:spatial-reference-mismatch", "The tiling scheme does not match the spatial reference of the global scene");
}
var r3 = Object.freeze(Object.defineProperty({ __proto__: null, checkIfTileInfoSupportedForViewSR: n6 }, Symbol.toStringTag, { value: "Module" }));

// node_modules/@arcgis/core/views/3d/terrain/terrainUtils.js
var s9 = { [l.Global]: r3, [l.Local]: a3 };
function M2(n8, t4, e7, r6, o3) {
  return s9[r6].checkIfTileInfoSupportedForViewSR(n8, e7, t4, o3);
}
function k2(t4, e7, o3) {
  const i2 = M(t4);
  if (null != i2) {
    if (!V.isCollection(i2)) return { tileInfo: i2.tileInfo, fullExtent: i2.fullExtent };
    {
      const n8 = i2.find((n9) => null == M2(n9.tileInfo, n9.fullExtent, e7, o3));
      if (n8) return { tileInfo: n8.tileInfo, fullExtent: n8.fullExtent };
    }
  }
  return { tileInfo: null, fullExtent: null };
}
var $ = [T.NORTH, T.EAST, T.SOUTH, T.WEST];
var nn = [T.NORTH_EAST, T.SOUTH_EAST, T.SOUTH_WEST, T.NORTH_WEST];

// node_modules/@arcgis/core/views/support/spatialReferenceSupport.js
function r5(r6, S4) {
  return null != r6 && (null == S4 || (S4 === l.Local ? !r6.isGeographic || (r6.isWGS84 || r6.wkid === S.CGCS2000) : r6.isWebMercator || r6.isWGS84 || r6.wkid === S.CGCS2000 || r6.wkid === S.GCSMARS2000 || r6.wkid === S.GCSMARS2000_SPHERE || r6.wkid === S.GCSMOON2000));
}

// node_modules/@arcgis/core/widgets/BasemapGallery/support/basemapCompatibilityUtils.js
function f3(_0) {
  return __async(this, arguments, function* (e7, t4 = {}) {
    const { basemap: i2, view: r6 } = e7;
    yield i2.load(t4), y3(i2), yield h2(i2, r6, t4), s2(t4);
  });
}
function u3(_0) {
  return __async(this, arguments, function* (t4, r6 = {}) {
    const { basemap: n8, view: s10 } = t4;
    s2(r6);
    const l3 = n8.baseLayers.find((e7) => "unknown" === e7.type)?.loadError;
    if (null != l3) throw l3;
    if (!s10 || "spatialReferenceLocked" in s10 && !s10.spatialReferenceLocked) return;
    if (yield n8.load(r6), s2(r6), 0 === n8.baseLayers.length) return;
    const o3 = n8.baseLayers.at(0);
    if (!y(o3)) return;
    if (n8.spatialReference) {
      if (s10.spatialReference.equals(n8.spatialReference)) return;
      w4();
    }
    yield o3.load(r6), s2(r6);
    const p5 = (("supportedSpatialReferences" in o3 ? o3.supportedSpatialReferences : null) || ["tileInfo" in o3 ? o3.tileInfo?.spatialReference : null]).filter(G);
    0 !== p5.length && p5.every((e7) => !s10.spatialReference.equals(e7)) && w4();
  });
}
function w4() {
  throw new s("basemap-compatibility:incompatible-spatial-reference", "Basemap spatial reference is not compatible with the view");
}
function y3(e7) {
  if (0 === e7.baseLayers.length && 0 === e7.referenceLayers.length) return;
  const t4 = e7.baseLayers.concat(e7.referenceLayers).toArray().filter((e8) => !n4(e8)).map((e8) => b2(e8));
  if (t4.length) throw t4[0];
}
function b2(e7) {
  return new s("basemap-compatibility:unsupported-basemap-layer-type", "Unsupported basemap layer type ${operationalLayerType}", { layer: e7, operationalLayerType: e7.operationalLayerType || "unknown" });
}
function h2(e7, a5, i2) {
  return __async(this, null, function* () {
    if (0 === e7.baseLayers.length) return;
    const r6 = e7.baseLayers.at(0);
    if (f(r6)) {
      try {
        yield r6.load(i2);
      } catch (s10) {
        const e8 = "basemap-compatibility:unknown-error", a6 = "Unknown basemap compatibility error", { name: i3 = e8, message: r7 = a6, details: n8 } = s10;
        throw new s(i3, r7, n8);
      }
      g4(r6, a5);
    }
  });
}
function g4(e7, a5) {
  const i2 = a5.state.viewingMode;
  if (!i2) return;
  let r6, n8;
  if ("wmts" === e7?.type) {
    const s10 = k2(e7, a5.spatialReference, i2);
    if (null == s10.tileInfo) throw new s("basemapgalleryitem:tiling-scheme-incompatible", "Basemap tiling scheme is incompatible with the view");
    r6 = s10.tileInfo, n8 = s10.fullExtent;
  } else r6 = e7.tileInfo, n8 = e7.fullExtent;
  if (null == r6) return;
  if (!r5(r6.spatialReference, i2)) throw new s(`basemapgalleryitem:spatial-reference-unsupported-${a2(i2)}`, `Basemap spatial reference is unsupported in ${a2(i2)} mode`);
  const f6 = "vector-tile" === e7?.type ? r6.getCompatibleForVTL(256) : null;
  if (i2 === l.Global) {
    let a6 = M2(r6, n8, null, i2);
    if (a6 && "vector-tile" === e7?.type && null != n8 && f6 && !M2(f6, n8, null, i2) && (a6 = null), a6) {
      const e8 = r6.spatialReference.isWebMercator ? "web-mercator" : "wgs84";
      throw new s(`basemapgalleryitem:tiling-scheme-unsupported-${e8}-global`, "Basemap tiling scheme is unsupported in global mode", { error: a6 });
    }
  } else if (f2.checkUnsupported(r6)) throw new s("basemapgalleryitem:tiling-scheme-unsupported-local", "Basemap tiling scheme is unsupported in local mode");
  const u4 = a5.basemapTerrain?.tilingScheme;
  if (u4 && !u4.compatibleWith(r6) && ("vector-tile" !== e7?.type || !f6 || !u4.compatibleWith(f6))) throw new s("basemapgalleryitem:tiling-scheme-incompatible", "Basemap tiling scheme is incompatible with the view");
}

// node_modules/@arcgis/core/widgets/BasemapGallery/support/BasemapGalleryItem.js
var p4 = class extends n5.IdentifiableMixin(g) {
  constructor(e7) {
    super(e7), this.compatibilityFunction = null, this.error = null, this.state = "loading", this.view = null;
  }
  initialize() {
    const e7 = () => this.refresh();
    this.addHandles([d(() => this.basemap?.loadStatus, e7), d(() => this.compatibilityFunction, e7), d(() => this.view && "basemapTerrain" in this.view && this.view.basemapTerrain?.tilingScheme, e7), d(() => this.view?.ready, e7), d(() => this.view?.spatialReference, e7)]), this.refresh();
  }
  destroy() {
    this._cancelRefresh(), this.basemap = null, this.compatibilityFunction = null, this.view = null;
  }
  get _spatialReferenceTask() {
    return d2(this.view, this.basemap);
  }
  set basemap(e7) {
    e7 && e7.load().catch(() => {
    }), this._set("basemap", e7);
  }
  get spatialReference() {
    return this._spatialReferenceTask.spatialReference;
  }
  refresh() {
    this._cancelRefresh(), this._set("state", "loading");
    const e7 = this.basemap?.loadStatus;
    if ("loaded" !== e7 && "failed" !== e7) return;
    if (!this.compatibilityFunction) return void ("loaded" === e7 ? (this._set("state", "ready"), this._set("error", null)) : (this._set("state", "error"), this._set("error", this.basemap.loadError)));
    const t4 = new AbortController(), { signal: s10 } = t4;
    this.compatibilityFunction(this, { signal: s10 }).then(() => w(() => !this._spatialReferenceTask.updating, s10)).then(() => {
      this._set("state", "ready"), this._set("error", null);
    }).catch((e8) => {
      b(e8) || (this._set("state", "error"), this._set("error", e8));
    }), this._refreshController = t4;
  }
  _cancelRefresh() {
    this._refreshController && (this._refreshController.abort(), this._refreshController = null);
  }
};
r([m({ readOnly: true })], p4.prototype, "_spatialReferenceTask", null), r([m()], p4.prototype, "basemap", null), r([m()], p4.prototype, "compatibilityFunction", void 0), r([m({ readOnly: true })], p4.prototype, "error", void 0), r([m({ readOnly: true })], p4.prototype, "spatialReference", null), r([m({ readOnly: true })], p4.prototype, "state", void 0), r([m()], p4.prototype, "view", void 0), p4 = r([a("esri.widgets.BasemapGallery.support.BasemapGalleryItem")], p4);
var h3 = p4;

// node_modules/@arcgis/core/widgets/BasemapGallery/support/LocalBasemapsSource.js
var a4 = V.ofType(F);
var c5 = class extends g {
  constructor(o3) {
    super(o3), this.basemaps = new a4();
  }
  destroy() {
    this.basemaps.forEach((o3) => o3.destroy());
  }
  get state() {
    return "ready";
  }
  refresh() {
  }
};
r([m({ type: a4 })], c5.prototype, "basemaps", void 0), r([m({ readOnly: true })], c5.prototype, "state", null), c5 = r([a("esri.widgets.BasemapGallery.support.LocalBasemapsSource")], c5);
var m6 = c5;

// node_modules/@arcgis/core/widgets/BasemapGallery/support/PortalBasemapsSource.js
var d3 = V.ofType(F);
var y4 = class extends m3.LoadableMixin(p.EsriPromiseMixin(m6)) {
  constructor(t4) {
    super(t4), this._lastPortalBasemapFetchController = null, this.basemaps = new d3(), this.filterFunction = null, this.portal = C2.getDefault(), this.query = null, this.updateBasemapsCallback = null, this.viewType = null;
  }
  initialize() {
    this.addHandles(d(() => [this.filterFunction, this.loadStatus, this.portal?.basemapGalleryGroupQuery, this.portal?.basemapGalleryGroupQuery3D, this.portal?.user, this.query, this.updateBasemapsCallback], () => this.refresh(), P));
  }
  destroy() {
    this.filterFunction = null, this.portal = null, this.basemaps.forEach((t4) => t4.destroy());
  }
  get state() {
    return "not-loaded" === this.loadStatus ? "not-loaded" : "loading" === this.loadStatus || this._lastPortalBasemapFetchController ? "loading" : "ready";
  }
  load(t4) {
    return this.addResolvingPromise(this.portal.load(t4)), Promise.resolve(this);
  }
  refresh() {
    return __async(this, null, function* () {
      if ("loaded" !== this.loadStatus) return;
      this._lastPortalBasemapFetchController && (this._lastPortalBasemapFetchController.abort(), this._lastPortalBasemapFetchController = null);
      const t4 = this.portal, a5 = new AbortController();
      this._lastPortalBasemapFetchController = a5, this.notifyChange("state");
      try {
        const s10 = yield t4.fetchBasemaps(this._toQueryString(this.query), { signal: a5.signal, include3d: "3d" === this.viewType || void 0 });
        yield this._updateBasemaps(s10);
      } catch (s10) {
        if (b(s10)) throw s10;
        n.getLogger(this).warn(new s("basemap-source:fetch-basemaps-error", "Could not fetch basemaps from portal.", { error: s10 })), yield this._updateBasemaps();
      }
      this._lastPortalBasemapFetchController = null, this.notifyChange("state");
    });
  }
  _toQueryString(t4) {
    return t4 && "string" != typeof t4 ? Object.keys(t4).map((a5) => `${a5}:${t4[a5]}`).join(" AND ") : t4;
  }
  _updateBasemaps() {
    return __async(this, arguments, function* (t4 = []) {
      let a5 = yield this._filterBasemaps(t4);
      a5 = this.updateBasemapsCallback ? yield this.updateBasemapsCallback(a5) : a5, this.basemaps.removeAll(), this.basemaps.addMany(a5);
    });
  }
  _filterBasemaps(t4) {
    return __async(this, null, function* () {
      if (!this.filterFunction) return t4;
      const a5 = t4.map(this.filterFunction), s10 = yield Promise.all(a5);
      return t4.filter((t5, a6) => s10[a6]);
    });
  }
};
r([m({ readOnly: true, type: d3 })], y4.prototype, "basemaps", void 0), r([m()], y4.prototype, "filterFunction", void 0), r([m({ type: C2 })], y4.prototype, "portal", void 0), r([m()], y4.prototype, "query", void 0), r([m({ readOnly: true })], y4.prototype, "state", null), r([m()], y4.prototype, "updateBasemapsCallback", void 0), r([m()], y4.prototype, "viewType", void 0), y4 = r([a("esri.widgets.BasemapGallery.support.PortalBasemapsSource")], y4);
var f4 = y4;

// node_modules/@arcgis/core/widgets/BasemapGallery/BasemapGalleryViewModel.js
var g5 = V.ofType(h3);
function _(e7) {
  return e7 && "esri.portal.Portal" === e7.declaredClass;
}
function I(e7) {
  return e7 && !(e7 instanceof f4) && (!!e7.portal || !!e7.query);
}
function R(e7) {
  return e7 && "basemaps" in e7 && "state" in e7 && "refresh" in e7;
}
var E = class extends m3 {
  constructor(e7) {
    super(e7), this._loadingProjectionEngine = false, this.items = new g5(), this.source = new f4(), this.view = null;
  }
  initialize() {
    const e7 = () => this._recreateItems();
    this.addHandles([d(() => "ready" === this.state ? this.compatibilityFunction : null, () => this._updateItems()), v(() => this.source?.basemaps, "change", e7, { onListenerAdd: e7 }), p2(() => this.view, () => {
      this.source instanceof f4 && (this.source.viewType = this.view?.type);
    }, { once: true })]);
  }
  destroy() {
    const e7 = this.source.basemaps.find((e8) => e8 === this.activeBasemap);
    e7 && this.source.basemaps.remove(e7), this.source?.destroy();
  }
  get activeBasemap() {
    return this.view?.map?.basemap ?? null;
  }
  set activeBasemap(e7) {
    const t4 = this.view;
    if (!t4?.map) return;
    if (!e7 || !t4.ready) return t4.map.basemap = e7, void this._clearOverride("activeBasemap");
    const s10 = e7.spatialReference || this.items?.find((t5) => this.basemapEquals(e7, t5.basemap))?.spatialReference;
    if (s10 && "spatialReferenceLocked" in t4 && !t4.spatialReferenceLocked) {
      const i2 = t4.spatialReference;
      if (null != s10 && !s4(i2, s10) && !L(t4.spatialReference, s10) && !k()) return this._override("activeBasemap", e7), this._loadingProjectionEngine = true, void K().then(() => {
        this._get("activeBasemap") === e7 && (t4.map.basemap = e7, t4.spatialReference = s10, this._clearOverride("activeBasemap"));
      }, () => {
      }).then(() => {
        this._loadingProjectionEngine = false;
      });
      t4.map.basemap = e7, this._clearOverride("activeBasemap"), null == s10 || s4(t4.spatialReference, s10) || (t4.spatialReference = s10);
    } else t4.map.basemap = e7, this._clearOverride("activeBasemap");
  }
  castActiveBasemap(e7) {
    return m4(e7);
  }
  get activeBasemapIndex() {
    const { state: e7, activeBasemap: t4 } = this;
    return "ready" !== e7 ? -1 : this._findBasemapIndex(t4);
  }
  get compatibilityFunction() {
    return "3d" === this.view?.type ? f3 : u3;
  }
  set compatibilityFunction(e7) {
    this._overrideIfSome("compatibilityFunction", e7);
  }
  castSource(e7) {
    return Array.isArray(e7) || V.isCollection(e7) ? new m6({ basemaps: Array.isArray(e7) ? new V(e7) : e7 }) : _(e7) ? new f4({ portal: e7 }) : I(e7) ? new f4(e7) : R(e7) ? e7 : null;
  }
  get state() {
    return this.view?.ready && this.source ? e4(this.view) && !this.view.inGeographicLayout ? "unsupported" : this._loadingProjectionEngine ? "loading" : "ready" : "disabled";
  }
  basemapEquals(e7, t4) {
    return y2(e7, t4);
  }
  refresh() {
    this._recreateItems();
  }
  load() {
    return this.loadSource();
  }
  loadSource(e7) {
    return this.addResolvingPromise(m3.isLoadable(this.source) ? this.source.load(e7) : null), Promise.resolve(this);
  }
  _findBasemapIndex(e7) {
    const { items: t4 } = this, s10 = t4.findIndex((t5) => t5.basemap === e7);
    return -1 === s10 ? t4.findIndex((t5) => this.basemapEquals(t5.basemap, e7)) : s10;
  }
  _recreateItems() {
    const e7 = this.source?.basemaps ?? [], { view: t4, compatibilityFunction: s10 } = this, i2 = new Map(this.items.map((e8) => [e8.basemap, e8])), a5 = e7.map((e8) => {
      const a6 = i2.get(e8);
      return a6 ? (i2.delete(e8), a6) : new h3({ basemap: e8, compatibilityFunction: s10, view: t4 });
    });
    this.items.removeAll(), this.items.addMany(a5), i2.forEach((e8) => e8.destroy());
  }
  _updateItems() {
    for (const e7 of this.items) e7.compatibilityFunction = this.compatibilityFunction, e7.view = this.view;
  }
};
r([m()], E.prototype, "_loadingProjectionEngine", void 0), r([m({ type: F })], E.prototype, "activeBasemap", null), r([s3("activeBasemap")], E.prototype, "castActiveBasemap", null), r([m({ readOnly: true })], E.prototype, "activeBasemapIndex", null), r([m()], E.prototype, "compatibilityFunction", null), r([m({ readOnly: true, type: g5 })], E.prototype, "items", void 0), r([m()], E.prototype, "source", void 0), r([s3("source")], E.prototype, "castSource", null), r([m({ readOnly: true })], E.prototype, "state", null), r([m()], E.prototype, "view", void 0), E = r([a("esri.widgets.BasemapGallery.BasemapGalleryViewModel")], E);
var S3 = E;

// node_modules/@arcgis/core/widgets/BasemapGallery/css.js
var e6 = "esri-basemap-gallery";
var t3 = { base: e6, sourceLoading: `${e6}--source-loading`, loader: `${e6}__loader`, item: `${e6}__item`, itemContainer: `${e6}__item-container`, itemContent: `${e6}__item-content`, itemTitle: `${e6}__item-title`, itemTagsContainer: `${e6}__item-tags-container`, itemThumbnail: `${e6}__item-thumbnail`, selectedItem: `${e6}__item--selected`, itemError: `${e6}__item--error` };

// node_modules/@arcgis/core/widgets/BasemapGallery.js
var w5 = class extends O {
  constructor(e7, s10) {
    super(e7, s10), this.disabled = false, this.headingLevel = 2, this.messages = null, this.viewModel = new S3(), this._focusBasemapItemEnabled = false, r2(n.getLogger(this), "Basemap Gallery", "arcgis-basemap-gallery", { version: "4.32" });
  }
  initialize() {
    this.addHandles(p2(() => this.source, () => this.viewModel.loadSource(), { sync: true, initial: true }));
  }
  loadDependencies() {
    return c({ scrim: () => import("./calcite-scrim-BY7HE4HI.js"), chip: () => import("./calcite-chip-ECXAKG34.js") });
  }
  get activeBasemap() {
    return this.viewModel.activeBasemap;
  }
  set activeBasemap(e7) {
    this.viewModel.activeBasemap = e7;
  }
  get icon() {
    return "basemap";
  }
  set icon(e7) {
    this._overrideIfSome("icon", e7);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e7) {
    this._overrideIfSome("label", e7);
  }
  get source() {
    return this.viewModel.source;
  }
  set source(e7) {
    this.viewModel.source = e7;
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e7) {
    this.viewModel.view = e7;
  }
  render() {
    const e7 = "loading" === this.source.state, s10 = this.disabled || "disabled" === this.viewModel.state, t4 = { [t3.sourceLoading]: e7, [e2.disabled]: s10 };
    return n2("div", { class: this.classes(t3.base, e2.widget, e2.panel, t4), key: "container" }, this._getContext());
  }
  _getContext() {
    if ("unsupported" === this.viewModel.state) return n2("div", { class: e2.empty, key: "empty-message" }, n2(e3, { level: this.headingLevel }, this.messages.unsupported));
    if ("loading" === this.source.state) return n2("div", { class: t3.loader, key: "loader" });
    const e7 = this.viewModel.items;
    return e7.length > 0 ? n2("ul", { "aria-disabled": this.disabled, "aria-label": this.label, bind: this, class: t3.itemContainer, key: "item-container", onkeydown: this._handleKeyDown, role: "radiogroup" }, e7.map((e8, s10) => this._renderBasemapGalleryItem(e8, s10)).toArray()) : n2("div", { class: e2.empty, key: "empty-message" }, n2(e3, { level: this.headingLevel }, this.messages.noBasemaps));
  }
  _getRoundRobinIndex(e7, s10) {
    return (e7 + s10) % s10;
  }
  _handleKeyDown(e7) {
    const { key: s10 } = e7;
    if (!["ArrowUp", "ArrowDown", "ArrowRight", "ArrowLeft"].includes(s10)) return;
    e7.preventDefault();
    const { items: t4, activeBasemapIndex: a5 } = this.viewModel, i2 = "ArrowUp" === s10 || "ArrowLeft" === s10 ? this._getRoundRobinIndex(Math.max(a5 - 1, -1), t4.length) : this._getRoundRobinIndex(a5 + 1, t4.length), r6 = t4.at(i2);
    "ready" === r6?.state && (this.viewModel.activeBasemap = r6.basemap), this._focusBasemapItemEnabled = true;
  }
  _focusBasemapItem(e7) {
    this._focusBasemapItemEnabled && 0 === e7.tabIndex && (e7.focus(), this._focusBasemapItemEnabled = false);
  }
  _handleClick(e7) {
    const s10 = e7.currentTarget["data-item"];
    "ready" === s10.state && (this.viewModel.activeBasemap = s10.basemap);
  }
  _renderBasemapGalleryItem(e7, t4) {
    const a5 = j2(e7.basemap) || n3("esri/themes/base/images/basemap-toggle-64.svg"), i2 = e7.basemap.title, r6 = e7.basemap.portalItem?.snippet, o3 = e7.error?.message || r6 || i2, { viewModel: { state: d4, activeBasemapIndex: p5 } } = this, m7 = this.disabled || "disabled" === d4, h4 = p5 === t4, g6 = h4 || -1 === p5 && 0 === t4 ? 0 : -1, v3 = "loading" === d4, b3 = { [t3.selectedItem]: h4, [t3.itemError]: "error" === e7.state }, w6 = `basemapgallery-item-${e7.uid}`;
    return n2("li", { afterUpdate: this._focusBasemapItem, "aria-checked": h4.toString(), "aria-disabled": m7.toString(), "aria-labelledby": w6, bind: this, class: this.classes(t3.item, b3), "data-item": e7, key: e7.uid, onclick: this._handleClick, onkeydown: this._handleClick, role: "radio", tabIndex: g6, title: o3 }, n2("img", { alt: "", class: t3.itemThumbnail, src: a5 }), n2("div", { class: t3.itemContent, key: "content" }, n2("div", { class: t3.itemTitle, key: "title" }, n2("span", { id: w6 }, i2)), s6(e7.basemap) ? this._renderTags(e7.basemap) : null), "loading" === e7.state || h4 && v3 ? n2("calcite-scrim", null, n2("span", { "aria-hidden": "true", class: e2.loaderAnimation, key: "loader", role: "presentation" })) : null);
  }
  _renderTags(e7) {
    return n2("div", { class: t3.itemTagsContainer, key: "tag" }, this._render3DTag(), u2(e7) ? this._renderBetaTag() : null);
  }
  _render3DTag() {
    const { messages: e7 } = this;
    return n2("calcite-chip", { key: "tag-3d", label: e7.tag3D, scale: "s" }, this.messages.tag3D);
  }
  _renderBetaTag() {
    const { messages: e7 } = this;
    return n2("calcite-chip", { appearance: "outline-fill", key: "tag-beta", label: e7.tagBeta, scale: "s" }, this.messages.tagBeta);
  }
};
r([m()], w5.prototype, "activeBasemap", null), r([m()], w5.prototype, "disabled", void 0), r([m()], w5.prototype, "headingLevel", void 0), r([m()], w5.prototype, "icon", null), r([m()], w5.prototype, "label", null), r([m(), e("esri/widgets/BasemapGallery/t9n/BasemapGallery")], w5.prototype, "messages", void 0), r([m()], w5.prototype, "source", null), r([m()], w5.prototype, "view", null), r([m()], w5.prototype, "viewModel", void 0), r([m()], w5.prototype, "_focusBasemapItemEnabled", void 0), r([t()], w5.prototype, "_handleClick", null), w5 = r([a("esri.widgets.BasemapGallery")], w5);
var f5 = w5;
export {
  f5 as default
};
//# sourceMappingURL=@arcgis_core_widgets_BasemapGallery.js.map
