import {
  n as n6,
  p as p4
} from "./chunk-CLYBQCLI.js";
import {
  V as V3
} from "./chunk-DOATTHTT.js";
import "./chunk-NQU5ABWF.js";
import "./chunk-66HQ5M7W.js";
import "./chunk-CISWKCW5.js";
import "./chunk-JW65AMUB.js";
import "./chunk-5QICDKN4.js";
import "./chunk-5W6AKKT7.js";
import "./chunk-2YKANBUU.js";
import {
  t as t4
} from "./chunk-5EUGJQVC.js";
import {
  a as a5,
  m as m5,
  p as p3,
  y
} from "./chunk-B2WS5HSF.js";
import {
  R,
  V as V4,
  r as r3
} from "./chunk-KA3YNY22.js";
import {
  $,
  Z as Z2,
  w as w2
} from "./chunk-2CGNNVDA.js";
import "./chunk-DJYXUXWN.js";
import "./chunk-NU5VHNXS.js";
import "./chunk-H3YNKKSH.js";
import "./chunk-QZW7XP43.js";
import "./chunk-5LQB4GO6.js";
import "./chunk-6US6IJQH.js";
import "./chunk-KOISNHUT.js";
import "./chunk-4WQG2466.js";
import "./chunk-4PVFG5T2.js";
import "./chunk-TV65FM5X.js";
import "./chunk-SGG5K3GV.js";
import "./chunk-M4WZN4EH.js";
import "./chunk-R3GS33FH.js";
import "./chunk-P7U5GMBX.js";
import "./chunk-7G5T4GB6.js";
import "./chunk-DMYKDIFT.js";
import "./chunk-BLUYYJD4.js";
import "./chunk-YBPYGATC.js";
import "./chunk-O4YMLXAZ.js";
import "./chunk-TZC4SNZT.js";
import "./chunk-KCIVZXDK.js";
import "./chunk-MILHALWW.js";
import "./chunk-54GNLAEA.js";
import "./chunk-GOBEC4AQ.js";
import "./chunk-M7VXG3HK.js";
import "./chunk-LZHATA56.js";
import "./chunk-7AXSNDJS.js";
import "./chunk-WJKOARCV.js";
import "./chunk-II7IT7GE.js";
import {
  s as s3
} from "./chunk-LAT3FERZ.js";
import "./chunk-CEREZWZ6.js";
import "./chunk-UPSWNHFU.js";
import "./chunk-EDBHW3EG.js";
import "./chunk-SZIT3IYE.js";
import {
  Ye
} from "./chunk-TBHNOGW4.js";
import "./chunk-3YJA3KQW.js";
import "./chunk-NUQRT7CB.js";
import "./chunk-RF3IXNCL.js";
import "./chunk-XKCP3CZJ.js";
import "./chunk-6DIVLKMU.js";
import "./chunk-TVC5ICZ6.js";
import "./chunk-VY7ME65R.js";
import "./chunk-ZL7AFA5U.js";
import "./chunk-DWHZIVJ2.js";
import "./chunk-NNQGBMH4.js";
import {
  i
} from "./chunk-KZONSPL6.js";
import "./chunk-TATHLUT3.js";
import {
  l as l2
} from "./chunk-Y5JUDCDZ.js";
import "./chunk-OR23LWBA.js";
import "./chunk-BOHQCAJM.js";
import "./chunk-KK6BHWJD.js";
import "./chunk-O27NRO2R.js";
import {
  s as s4
} from "./chunk-ZFKMGP62.js";
import "./chunk-IHXPJZKB.js";
import "./chunk-EYGV7DRM.js";
import "./chunk-KJXL4KHH.js";
import "./chunk-B4CSKOTH.js";
import "./chunk-37VXXTCK.js";
import "./chunk-DGGGA4EB.js";
import "./chunk-VOLYE23O.js";
import {
  e
} from "./chunk-M56COCZM.js";
import "./chunk-H3Z5HDTB.js";
import "./chunk-YJNQBYCY.js";
import "./chunk-XHRVMHQV.js";
import "./chunk-6KBNYSOO.js";
import "./chunk-YVZV2JQ2.js";
import "./chunk-WIUOZ2QR.js";
import {
  j
} from "./chunk-SMUEPEJK.js";
import "./chunk-WKCMSQJ3.js";
import "./chunk-5I7JTSAL.js";
import "./chunk-SWTEWHKX.js";
import {
  t as t2
} from "./chunk-CLCRCQS5.js";
import {
  b
} from "./chunk-YLFWLXHD.js";
import {
  c,
  d,
  g as g2,
  l,
  m as m4
} from "./chunk-AOJUXBCS.js";
import "./chunk-HZVZN4QC.js";
import {
  h
} from "./chunk-ARKMS27Q.js";
import "./chunk-DEBJAVLQ.js";
import {
  S as S2,
  m as m3
} from "./chunk-PEKG77YQ.js";
import "./chunk-M43HSGJE.js";
import "./chunk-2MPRPDUR.js";
import {
  p as p2
} from "./chunk-7T32KOGA.js";
import {
  N
} from "./chunk-XAJHU5YA.js";
import "./chunk-6AFIGCYY.js";
import "./chunk-OPMACZPA.js";
import "./chunk-7C4YASO2.js";
import "./chunk-SHZ6V3A6.js";
import "./chunk-G72JIG3C.js";
import "./chunk-QUH6IF3C.js";
import {
  u
} from "./chunk-6JLNBB4A.js";
import "./chunk-B6TLVNFQ.js";
import {
  Z
} from "./chunk-HCOIDKPJ.js";
import "./chunk-RI3APACQ.js";
import "./chunk-DNKL4VLK.js";
import "./chunk-JA6WVUX5.js";
import "./chunk-HLUCHGW6.js";
import "./chunk-5ZLWOYXQ.js";
import "./chunk-LMKW53EF.js";
import "./chunk-245OSL56.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-WJF6G6DB.js";
import "./chunk-VDBD7USS.js";
import "./chunk-G4JWBWXC.js";
import "./chunk-TX7HQE3N.js";
import "./chunk-O4PT2W5W.js";
import "./chunk-VDUPOWSD.js";
import "./chunk-PCY7U2ND.js";
import "./chunk-WFMHAEPG.js";
import "./chunk-JTVRCNJE.js";
import "./chunk-KD5GWDMJ.js";
import "./chunk-AV2MJVRY.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-5MM6JTK5.js";
import "./chunk-EMGBZTFR.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import "./chunk-NEOVY6GP.js";
import "./chunk-ELAKODAU.js";
import "./chunk-RY6EUXME.js";
import "./chunk-CMPLJJCX.js";
import "./chunk-JHB4QD5T.js";
import {
  b as b2
} from "./chunk-XWFSWJ3K.js";
import {
  q
} from "./chunk-RQIC5Q3A.js";
import {
  t as t3
} from "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import {
  h as h2
} from "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import {
  n as n4
} from "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import {
  b as b3
} from "./chunk-7OZN72PM.js";
import "./chunk-Z4ITP2HY.js";
import "./chunk-WOVS7CNY.js";
import "./chunk-4VQUNH2Z.js";
import "./chunk-7SLET7NM.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import "./chunk-GW436Z36.js";
import "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import {
  n as n2
} from "./chunk-S4BA7TJA.js";
import {
  n as n3
} from "./chunk-52K7EZBS.js";
import {
  f
} from "./chunk-GYDLT2MD.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import {
  r as r2
} from "./chunk-Y4JUMKSA.js";
import {
  a as a4,
  t
} from "./chunk-B6U4AYDJ.js";
import "./chunk-CYXXOYR3.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-2K433C2G.js";
import "./chunk-EOJGN7NW.js";
import {
  m as m2
} from "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import {
  n as n5
} from "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import {
  p
} from "./chunk-XYTETMU6.js";
import "./chunk-VYI6FOKY.js";
import {
  V as V2
} from "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import {
  w
} from "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import {
  o
} from "./chunk-4JUCUHPE.js";
import {
  g
} from "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import {
  o as o2
} from "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import {
  P2 as P
} from "./chunk-ADRG7ORV.js";
import {
  V
} from "./chunk-4LJTFP6V.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2,
  s2,
  x
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  a as a3
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a,
  n2 as n,
  s2 as s
} from "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/buildingSublayers/BuildingSublayer.js
var l3 = class extends n5.IdentifiableMixin(m3) {
  constructor(e3) {
    super(e3), this.title = "", this.id = -1, this.modelName = null, this.isEmpty = null, this.legendEnabled = true, this.visible = true, this.opacity = 1;
  }
  readTitle(e3, o3) {
    return "string" == typeof o3.alias ? o3.alias : "string" == typeof o3.name ? o3.name : "";
  }
  readIdOnlyOnce(e3) {
    return -1 !== this.id ? this.id : "number" == typeof e3 ? e3 : -1;
  }
};
r([m({ type: String, json: { origins: { "web-scene": { write: true }, "portal-item": { write: true } } } })], l3.prototype, "title", void 0), r([o("service", "title", ["alias", "name"])], l3.prototype, "readTitle", null), r([m()], l3.prototype, "layer", void 0), r([m({ type: x, readOnly: true, json: { read: false, write: { ignoreOrigin: true, isRequired: true } } })], l3.prototype, "id", void 0), r([o("service", "id")], l3.prototype, "readIdOnlyOnce", null), r([m(m4(String))], l3.prototype, "modelName", void 0), r([m(m4(Boolean))], l3.prototype, "isEmpty", void 0), r([m({ type: Boolean, nonNullable: true })], l3.prototype, "legendEnabled", void 0), r([m({ type: Boolean, json: { name: "visibility", write: true } })], l3.prototype, "visible", void 0), r([m({ type: Number, json: { write: true } })], l3.prototype, "opacity", void 0), l3 = r([a2("esri.layers.buildingSublayers.BuildingSublayer")], l3);
var a6 = l3;

// node_modules/@arcgis/core/layers/buildingSublayers/BuildingComponentSublayer.js
var A = s4();
var _ = class extends m2.LoadableMixin(p.EsriPromiseMixin(a6)) {
  constructor(e3) {
    super(e3), this.type = "building-component", this.nodePages = null, this.materialDefinitions = [], this.textureSetDefinitions = [], this.geometryDefinitions = [], this.indexInfo = null, this.serviceUpdateTimeStamp = null, this.store = null, this.attributeStorageInfo = [], this.fields = [], this.associatedLayer = null, this.outFields = null, this.listMode = "show", this.renderer = null, this.definitionExpression = null, this.popupEnabled = true, this.popupTemplate = null, this.layerType = "3d-object";
  }
  get parsedUrl() {
    return this.layer ? { path: `${this.layer.parsedUrl?.path}/sublayers/${this.id}`, query: this.layer.parsedUrl?.query } : { path: "" };
  }
  get fieldsIndex() {
    return new Z(this.fields);
  }
  readAssociatedLayer(e3, t8) {
    const r4 = this.layer.associatedFeatureServiceItem, o3 = t8.associatedLayerID;
    return null != r4 && "number" == typeof o3 ? new Ye({ portalItem: r4, customParameters: this.customParameters, layerId: o3 }) : null;
  }
  get objectIdField() {
    if (null != this.fields) {
      for (const e3 of this.fields) if ("oid" === e3.type) return e3.name;
    }
    return null;
  }
  get displayField() {
    return null != this.associatedLayer ? this.associatedLayer.displayField : void 0;
  }
  get apiKey() {
    return this.layer.apiKey;
  }
  get customParameters() {
    return this.layer.customParameters;
  }
  get fullExtent() {
    return this.layer.fullExtent;
  }
  get spatialReference() {
    return this.layer.spatialReference;
  }
  get version() {
    return this.layer.version;
  }
  get elevationInfo() {
    return this.layer.elevationInfo;
  }
  get minScale() {
    return this.layer.minScale;
  }
  get maxScale() {
    return this.layer.maxScale;
  }
  get effectiveScaleRange() {
    return this.layer.effectiveScaleRange;
  }
  get defaultPopupTemplate() {
    return this.createPopupTemplate();
  }
  load(e3) {
    const t8 = null != e3 ? e3.signal : null, r4 = this._fetchService(t8).then(() => {
      this.indexInfo = r3(this.parsedUrl.path, this.rootNode, this.nodePages, this.customParameters, this.apiKey, n.getLogger(this), t8);
    });
    return this.addResolvingPromise(r4), Promise.resolve(this);
  }
  createPopupTemplate(e3) {
    return p2(this, e3);
  }
  _fetchService(e3) {
    return __async(this, null, function* () {
      const t8 = (yield P(this.parsedUrl.path, { query: __spreadProps(__spreadValues({ f: "json" }, this.customParameters), { token: this.apiKey }), responseType: "json", signal: e3 })).data;
      this.read(t8, { origin: "service", url: this.parsedUrl });
    });
  }
  getField(e3) {
    return this.fieldsIndex.get(e3);
  }
  getFieldDomain(e3, t8) {
    const r4 = this.getField(e3)?.domain ?? null;
    return this.associatedLayer ? N(this.associatedLayer, e3, t8, r4) : r4;
  }
  getFeatureType(e3) {
    return e3 && null != this.associatedLayer ? this.associatedLayer.getFeatureType(e3) : null;
  }
  get types() {
    return null != this.associatedLayer ? this.associatedLayer.types ?? [] : [];
  }
  get typeIdField() {
    return null != this.associatedLayer ? this.associatedLayer.typeIdField : null;
  }
  get geometryType() {
    return "3d-object" === this.layerType ? "mesh" : "point";
  }
  get profile() {
    return "3d-object" === this.layerType ? "mesh-pyramids" : "points";
  }
  get capabilities() {
    const e3 = null != this.associatedLayer && this.associatedLayer.capabilities ? this.associatedLayer.capabilities : t4, { query: t8, data: { supportsZ: r4, supportsM: o3, isVersioned: s5 } } = e3;
    return { query: t8, data: { supportsZ: r4, supportsM: o3, isVersioned: s5 } };
  }
  createQuery() {
    const e3 = new b3();
    return "mesh" !== this.geometryType && (e3.returnGeometry = true, e3.returnZ = true), e3.where = this.definitionExpression || "1=1", e3.sqlFormat = "standard", e3;
  }
  queryExtent(e3, t8) {
    return this._getAssociatedLayerForQuery().then((r4) => r4.queryExtent(e3 || this.createQuery(), t8));
  }
  queryFeatureCount(e3, t8) {
    return this._getAssociatedLayerForQuery().then((r4) => r4.queryFeatureCount(e3 || this.createQuery(), t8));
  }
  queryFeatures(e3, t8) {
    return this._getAssociatedLayerForQuery().then((r4) => r4.queryFeatures(e3 || this.createQuery(), t8)).then((e4) => {
      if (e4?.features) for (const t9 of e4.features) t9.layer = this.layer, t9.sourceLayer = this;
      return e4;
    });
  }
  queryObjectIds(e3, t8) {
    return __async(this, null, function* () {
      const r4 = yield this._getAssociatedLayerForQuery();
      return (yield r4.queryObjectIds(e3 || this.createQuery(), t8)).filter(n4);
    });
  }
  queryCachedAttributes(e3, t8) {
    return __async(this, null, function* () {
      const r4 = h2(this.fieldsIndex, yield n6(this, p4(this)));
      return V3(this.parsedUrl.path, this.attributeStorageInfo, e3, t8, r4, this.apiKey, this.customParameters);
    });
  }
  queryCachedFeature(e3, r4) {
    return __async(this, null, function* () {
      const o3 = yield this.queryCachedAttributes(e3, [r4]);
      if (!o3 || 0 === o3.length) throw new s("scenelayer:feature-not-in-cached-data", "Feature not found in cached data");
      return new b2({ attributes: o3[0], layer: this, sourceLayer: this });
    });
  }
  getFieldUsageInfo(e3) {
    return this.fieldsIndex.has(e3) ? { supportsLabelingInfo: false, supportsRenderer: false, supportsPopupTemplate: false, supportsLayerQuery: false } : { supportsLabelingInfo: false, supportsRenderer: true, supportsPopupTemplate: true, supportsLayerQuery: null != this.associatedLayer };
  }
  _getAssociatedLayerForQuery() {
    const e3 = this.associatedLayer;
    return null != e3 && e3.loaded ? Promise.resolve(e3) : this._loadAssociatedLayerForQuery();
  }
  _loadAssociatedLayerForQuery() {
    return __async(this, null, function* () {
      if (yield this.load(), null == this.associatedLayer) throw new s("buildingscenelayer:query-not-available", "BuildingSceneLayer component layer queries are not available without an associated feature layer", { layer: this });
      try {
        yield this.associatedLayer.load();
      } catch (e3) {
        throw new s("buildingscenelayer:query-not-available", "BuildingSceneLayer associated feature layer could not be loaded", { layer: this, error: e3 });
      }
      return this.associatedLayer;
    });
  }
};
r([m({ readOnly: true })], _.prototype, "parsedUrl", null), r([m({ type: p3, readOnly: true })], _.prototype, "nodePages", void 0), r([m({ type: [a5], readOnly: true })], _.prototype, "materialDefinitions", void 0), r([m({ type: [y], readOnly: true })], _.prototype, "textureSetDefinitions", void 0), r([m({ type: [m5], readOnly: true })], _.prototype, "geometryDefinitions", void 0), r([m({ readOnly: true })], _.prototype, "serviceUpdateTimeStamp", void 0), r([m({ readOnly: true })], _.prototype, "store", void 0), r([m({ type: String, readOnly: true, json: { read: { source: "store.rootNode" } } })], _.prototype, "rootNode", void 0), r([m({ readOnly: true })], _.prototype, "attributeStorageInfo", void 0), r([m(A.fields)], _.prototype, "fields", void 0), r([m({ readOnly: true })], _.prototype, "fieldsIndex", null), r([m({ readOnly: true, type: Ye })], _.prototype, "associatedLayer", void 0), r([o("service", "associatedLayer", ["associatedLayerID"])], _.prototype, "readAssociatedLayer", null), r([m(A.outFields)], _.prototype, "outFields", void 0), r([m({ type: String, readOnly: true })], _.prototype, "objectIdField", null), r([m({ readOnly: true, type: String, json: { read: false } })], _.prototype, "displayField", null), r([m({ readOnly: true, type: String })], _.prototype, "apiKey", null), r([m({ readOnly: true, type: String })], _.prototype, "customParameters", null), r([m({ readOnly: true, type: w })], _.prototype, "fullExtent", null), r([m({ readOnly: true, type: g })], _.prototype, "spatialReference", null), r([m({ readOnly: true })], _.prototype, "version", null), r([m({ readOnly: true, type: h })], _.prototype, "elevationInfo", null), r([m({ readOnly: true, type: Number })], _.prototype, "minScale", null), r([m({ readOnly: true, type: Number })], _.prototype, "maxScale", null), r([m({ readOnly: true, type: Number })], _.prototype, "effectiveScaleRange", null), r([m({ type: ["hide", "show"], json: { write: true } })], _.prototype, "listMode", void 0), r([m({ types: u, json: { origins: { service: { read: { source: "drawingInfo.renderer" } } }, name: "layerDefinition.drawingInfo.renderer", write: true }, value: null })], _.prototype, "renderer", void 0), r([m({ type: String, json: { origins: { service: { read: false, write: false } }, name: "layerDefinition.definitionExpression", write: { enabled: true, allowNull: true } } })], _.prototype, "definitionExpression", void 0), r([m(l)], _.prototype, "popupEnabled", void 0), r([m({ type: q, json: { read: { source: "popupInfo" }, write: { target: "popupInfo" } } })], _.prototype, "popupTemplate", void 0), r([m({ readOnly: true, type: String, json: { origins: { service: { read: { source: "store.normalReferenceFrame" } } }, read: false } })], _.prototype, "normalReferenceFrame", void 0), r([m({ readOnly: true, json: { read: false } })], _.prototype, "defaultPopupTemplate", null), r([m()], _.prototype, "types", null), r([m()], _.prototype, "typeIdField", null), r([m({ json: { write: false } }), r2(new o2({ "3DObject": "3d-object", Point: "point" }))], _.prototype, "layerType", void 0), r([m()], _.prototype, "geometryType", null), r([m()], _.prototype, "profile", null), r([m({ readOnly: true, json: { read: false } })], _.prototype, "capabilities", null), r([m({ readOnly: true })], _.prototype, "statisticsInfo", void 0), _ = r([a2("esri.layers.buildingSublayers.BuildingComponentSublayer")], _);
var C = _;

// node_modules/@arcgis/core/layers/buildingSublayers/BuildingGroupSublayer.js
var a7;
var l4 = { type: V2, readOnly: true, json: { origins: { service: { read: { source: "sublayers", reader: p5 } } }, read: false } };
function p5(r4, o3, t8) {
  if (r4 && Array.isArray(r4)) return new V2(r4.map((r5) => {
    const e3 = y2(r5);
    if (e3) {
      const o4 = new e3();
      return o4.read(r5, t8), o4;
    }
    return t8?.messages && r5 && t8.messages.push(new s2("building-scene-layer:unsupported-sublayer-type", "Building scene sublayer of type '" + (r5.type || "unknown") + "' are not supported", { definition: r5, context: t8 })), null;
  }));
}
var c2 = a7 = class extends a6 {
  constructor(r4) {
    super(r4), this.type = "building-group", this.listMode = "show", this.sublayers = null;
  }
  loadAll() {
    return a4(this, (r4) => a7.forEachSublayer(this.sublayers, (e3) => {
      "building-group" !== e3.type && r4(e3);
    }));
  }
};
function y2(r4) {
  return "group" === r4.layerType ? c2 : C;
}
r([m({ type: ["hide", "show", "hide-children"], json: { write: true } })], c2.prototype, "listMode", void 0), r([m(l4)], c2.prototype, "sublayers", void 0), c2 = a7 = r([a2("esri.layers.buildingSublayers.BuildingGroupSublayer")], c2), function(r4) {
  function e3(r5, o3) {
    r5.forEach((r6) => {
      o3(r6), "building-group" === r6.type && e3(r6.sublayers, o3);
    });
  }
  r4.sublayersProperty = l4, r4.readSublayers = p5, r4.forEachSublayer = e3;
}(c2 || (c2 = {}));
var d2 = c2;

// node_modules/@arcgis/core/layers/support/BuildingFilterAuthoringInfo.js
var e2 = class extends S {
  constructor() {
    super(...arguments), this.type = null;
  }
};
r([m({ type: String, readOnly: true, json: { write: { isRequired: true } } })], e2.prototype, "type", void 0), e2 = r([a2("esri.layers.support.BuildingFilterAuthoringInfo")], e2);
var p6 = e2;

// node_modules/@arcgis/core/layers/support/BuildingFilterAuthoringInfoType.js
var i2;
var p7 = i2 = class extends S {
  constructor() {
    super(...arguments), this.filterType = null, this.filterValues = null;
  }
  clone() {
    return new i2({ filterType: this.filterType, filterValues: a(this.filterValues) });
  }
};
r([m({ type: String, json: { write: { isRequired: true } } })], p7.prototype, "filterType", void 0), r([m({ type: [String], json: { write: { isRequired: true } } })], p7.prototype, "filterValues", void 0), p7 = i2 = r([a2("esri.layers.support.BuildingFilterAuthoringInfoType")], p7);
var l5 = p7;

// node_modules/@arcgis/core/layers/support/BuildingFilterAuthoringInfoBlock.js
var c3;
var l6 = V2.ofType(l5);
var m6 = c3 = class extends S {
  clone() {
    return new c3({ filterTypes: a(this.filterTypes) });
  }
};
r([m({ type: l6, json: { write: { isRequired: true } } })], m6.prototype, "filterTypes", void 0), m6 = c3 = r([a2("esri.layers.support.BuildingFilterAuthoringInfoBlock")], m6);
var n7 = m6;

// node_modules/@arcgis/core/layers/support/BuildingFilterAuthoringInfoCheckbox.js
var p8;
var l7 = V2.ofType(n7);
var n8 = p8 = class extends p6 {
  constructor() {
    super(...arguments), this.type = "checkbox";
  }
  clone() {
    return new p8({ filterBlocks: a(this.filterBlocks) });
  }
};
r([m({ type: ["checkbox"] })], n8.prototype, "type", void 0), r([m({ type: l7, json: { write: { isRequired: true } } })], n8.prototype, "filterBlocks", void 0), n8 = p8 = r([a2("esri.layers.support.BuildingFilterAuthoringInfoCheckbox")], n8);
var m7 = n8;

// node_modules/@arcgis/core/layers/support/BuildingFilterMode.js
var t5 = class extends S {
};
r([m({ readOnly: true, json: { read: false, write: { isRequired: true } } })], t5.prototype, "type", void 0), t5 = r([a2("esri.layers.support.BuildingFilterMode")], t5);
var p9 = t5;

// node_modules/@arcgis/core/layers/support/BuildingFilterModeSolid.js
var t6;
var i3 = t6 = class extends p9 {
  constructor() {
    super(...arguments), this.type = "solid";
  }
  clone() {
    return new t6();
  }
};
r([m({ type: ["solid"], readOnly: true, json: { write: { isRequired: true } } })], i3.prototype, "type", void 0), i3 = t6 = r([a2("esri.layers.support.BuildingFilterModeSolid")], i3);
var p10 = i3;

// node_modules/@arcgis/core/layers/support/BuildingFilterModeWireFrame.js
var c4;
var m8 = c4 = class extends p9 {
  constructor() {
    super(...arguments), this.type = "wire-frame", this.edges = null;
  }
  clone() {
    return new c4({ edges: a(this.edges) });
  }
};
r([r2({ wireFrame: "wire-frame" })], m8.prototype, "type", void 0), r([m(t3)], m8.prototype, "edges", void 0), m8 = c4 = r([a2("esri.layers.support.BuildingFilterModeWireFrame")], m8);
var a8 = m8;

// node_modules/@arcgis/core/layers/support/BuildingFilterModeXRay.js
var t7;
var p11 = t7 = class extends p9 {
  constructor() {
    super(...arguments), this.type = "x-ray";
  }
  clone() {
    return new t7();
  }
};
r([m({ type: ["x-ray"], readOnly: true, json: { write: { isRequired: true } } })], p11.prototype, "type", void 0), p11 = t7 = r([a2("esri.layers.support.BuildingFilterModeXRay")], p11);
var i4 = p11;

// node_modules/@arcgis/core/layers/support/BuildingFilterBlock.js
var d3;
var a9 = { nonNullable: true, types: { key: "type", base: p9, typeMap: { solid: p10, "wire-frame": a8, "x-ray": i4 } }, json: { read: (e3) => {
  switch (e3?.type) {
    case "solid":
      return p10.fromJSON(e3);
    case "wireFrame":
      return a8.fromJSON(e3);
    case "x-ray":
      return i4.fromJSON(e3);
    default:
      return;
  }
}, write: { enabled: true, isRequired: true } } };
var m9 = d3 = class extends S {
  constructor() {
    super(...arguments), this.filterExpression = null, this.filterMode = new p10(), this.title = "";
  }
  clone() {
    return new d3({ filterExpression: this.filterExpression, filterMode: a(this.filterMode), title: this.title });
  }
};
r([m({ type: String, json: { write: { enabled: true, isRequired: true } } })], m9.prototype, "filterExpression", void 0), r([m(a9)], m9.prototype, "filterMode", void 0), r([m({ type: String, json: { write: { enabled: true, isRequired: true } } })], m9.prototype, "title", void 0), m9 = d3 = r([a2("esri.layers.support.BuildingFilterBlock")], m9);
var c5 = m9;

// node_modules/@arcgis/core/layers/support/BuildingFilter.js
var d4;
var u2 = V2.ofType(c5);
var m10 = d4 = class extends S {
  constructor() {
    super(...arguments), this.description = null, this.filterBlocks = null, this.id = n2(), this.name = null;
  }
  clone() {
    return new d4({ description: this.description, filterBlocks: a(this.filterBlocks), id: this.id, name: this.name, filterAuthoringInfo: a(this.filterAuthoringInfo) });
  }
};
r([m({ type: String, json: { write: true } })], m10.prototype, "description", void 0), r([m({ type: u2, json: { write: { enabled: true, isRequired: true } } })], m10.prototype, "filterBlocks", void 0), r([m({ types: { key: "type", base: p6, typeMap: { checkbox: m7 } }, json: { read: (o3) => "checkbox" === o3?.type ? m7.fromJSON(o3) : null, write: true } })], m10.prototype, "filterAuthoringInfo", void 0), r([m({ type: String, constructOnly: true, json: { write: { enabled: true, isRequired: true } } })], m10.prototype, "id", void 0), r([m({ type: String, json: { write: { enabled: true, isRequired: true } } })], m10.prototype, "name", void 0), m10 = d4 = r([a2("esri.layers.support.BuildingFilter")], m10);
var f2 = m10;

// node_modules/@arcgis/core/layers/support/BuildingSummaryStatistics.js
var n9 = class extends S {
  constructor() {
    super(...arguments), this.fieldName = null, this.modelName = null, this.label = null, this.min = null, this.max = null, this.mostFrequentValues = null, this.subLayerIds = null;
  }
};
r([m({ type: String })], n9.prototype, "fieldName", void 0), r([m({ type: String })], n9.prototype, "modelName", void 0), r([m({ type: String })], n9.prototype, "label", void 0), r([m({ type: Number })], n9.prototype, "min", void 0), r([m({ type: Number })], n9.prototype, "max", void 0), r([m({ json: { read: (e3) => Array.isArray(e3) && (e3.every((e4) => "string" == typeof e4) || e3.every((e4) => "number" == typeof e4)) ? e3.slice() : null } })], n9.prototype, "mostFrequentValues", void 0), r([m({ type: [Number] })], n9.prototype, "subLayerIds", void 0), n9 = r([a2("esri.layers.support.BuildingSummaryStatistics.BuildingFieldStatistics")], n9);
var p12 = class extends m2.LoadableMixin(p.EsriPromiseMixin(S)) {
  constructor() {
    super(...arguments), this.url = null;
  }
  get fields() {
    return this.loaded || "loading" === this.loadStatus ? this._get("fields") : (n.getLogger(this).error("building summary statistics are not loaded"), null);
  }
  load(e3) {
    const r4 = null != e3 ? e3.signal : null;
    return this.addResolvingPromise(this._fetchService(r4)), Promise.resolve(this);
  }
  _fetchService(e3) {
    return __async(this, null, function* () {
      const t8 = (yield P(this.url, { query: { f: "json" }, responseType: "json", signal: e3 })).data;
      this.read(t8, { origin: "service" });
    });
  }
};
r([m({ constructOnly: true, type: String })], p12.prototype, "url", void 0), r([m({ readOnly: true, type: [n9], json: { read: { source: "summary" } } })], p12.prototype, "fields", null), p12 = r([a2("esri.layers.support.BuildingSummaryStatistics")], p12);
var u3 = p12;

// node_modules/@arcgis/core/layers/BuildingSceneLayer.js
var C2 = V2.ofType(f2);
var R2 = a(d2.sublayersProperty);
var M = R2.json?.origins;
M && (M["web-scene"] = { type: [C], write: { enabled: true, overridePolicy: () => ({ enabled: false }) } }, M["portal-item"] = { type: [C], write: { enabled: true, overridePolicy: () => ({ enabled: false }) } });
var U = class extends R(l2(b(j(t2(S2(e(i(f)))))))) {
  constructor(e3) {
    super(e3), this.operationalLayerType = "BuildingSceneLayer", this.allSublayers = new n3({ getCollections: () => [this.sublayers], getChildrenFunction: (e4) => "building-group" === e4.type ? e4.sublayers : null }), this.sublayers = null, this._allSublayerOverrides = null, this.filters = new C2(), this.activeFilterId = null, this.summaryStatistics = null, this.outFields = null, this.legendEnabled = true, this.type = "building-scene";
  }
  normalizeCtorArgs(e3) {
    return "string" == typeof e3 ? { url: e3 } : e3 ?? {};
  }
  destroy() {
    this.allSublayers.destroy();
  }
  readSublayers(e3, r4, t8) {
    const s5 = d2.readSublayers(e3, r4, t8);
    return d2.forEachSublayer(s5, (e4) => e4.layer = this), this._allSublayerOverrides && (H(s5, this._allSublayerOverrides), this._allSublayerOverrides = null), s5;
  }
  write(e3, r4) {
    return e3 = super.write(e3, r4), !r4 || "web-scene" !== r4.origin && "portal-item" !== r4.origin || (this.sublayers ? G(this.sublayers, e3, r4) : this._allSublayerOverrides && V5(this._allSublayerOverrides, e3, r4)), e3;
  }
  read(e3, r4) {
    if (super.read(e3, r4), ("web-scene" === r4?.origin || "portal-item" === r4?.origin) && Array.isArray(e3?.sublayers)) {
      const t8 = k(e3.sublayers, r4);
      this.sublayers ? N2(this.sublayers, t8) : (this._allSublayerOverrides ??= /* @__PURE__ */ new Map(), this._allSublayerOverrides.set(r4.origin, t8));
    }
  }
  readSummaryStatistics(e3, r4) {
    if ("string" == typeof r4.statisticsHRef) {
      const e4 = V(this.parsedUrl?.path, r4.statisticsHRef);
      return new u3({ url: e4 });
    }
    return null;
  }
  set elevationInfo(e3) {
    null != e3 && "absolute-height" !== e3.mode || this._set("elevationInfo", e3), this._validateElevationInfo(e3);
  }
  load(e3) {
    const r4 = null != e3 ? e3.signal : null, t8 = this.loadFromPortal({ supportedTypes: ["Scene Service"] }, e3).catch(a3).then(() => this._fetchService(r4)).then(() => this._fetchAssociatedFeatureService(r4));
    return this.addResolvingPromise(t8), Promise.resolve(this);
  }
  loadAll() {
    return t(this, (e3) => {
      d2.forEachSublayer(this.sublayers, (r4) => {
        "building-group" !== r4.type && e3(r4);
      }), this.summaryStatistics && e3(this.summaryStatistics);
    });
  }
  saveAs(e3, r4) {
    return __async(this, null, function* () {
      return this._debouncedSaveOperations(V4.SAVE_AS, __spreadProps(__spreadValues({}, r4), { getTypeKeywords: () => this._getTypeKeywords(), portalItemLayerType: "building-scene" }), e3);
    });
  }
  save() {
    return __async(this, null, function* () {
      const e3 = { getTypeKeywords: () => this._getTypeKeywords(), portalItemLayerType: "building-scene" };
      return this._debouncedSaveOperations(V4.SAVE, e3);
    });
  }
  validateLayer(e3) {
    if (!e3.layerType || "Building" !== e3.layerType) throw new s("buildingscenelayer:layer-type-not-supported", "BuildingSceneLayer does not support this layer type", { layerType: e3.layerType });
  }
  _getTypeKeywords() {
    return ["Building"];
  }
  _fetchAssociatedFeatureService(e3) {
    return __async(this, null, function* () {
      try {
        const { portalItem: r4 } = yield s3(`${this.url}/layers/${this.layerId}`, { sceneLayerItem: this.portalItem, customParameters: this.customParameters, apiKey: this.apiKey, signal: e3 });
        this.associatedFeatureServiceItem = r4;
      } catch (r4) {
        n.getLogger(this).warn("Associated feature service item could not be loaded", r4);
      }
    });
  }
  _validateElevationInfo(e3) {
    const r4 = "Building scene layers";
    $(n.getLogger(this), Z2(r4, "absolute-height", e3)), $(n.getLogger(this), w2(r4, e3));
  }
};
function H(e3, r4) {
  r4.forEach((r5) => N2(e3, r5));
}
function N2(e3, r4) {
  const { overrides: t8, context: s5 } = r4;
  d2.forEachSublayer(e3, (e4) => e4.read(t8.get(e4.id), s5));
}
function k(e3, r4) {
  const t8 = /* @__PURE__ */ new Map();
  for (const i5 of e3) null != i5 && "object" == typeof i5 && "number" == typeof i5.id ? t8.set(i5.id, i5) : r4.messages?.push(new s("building-scene-layer:invalid-sublayer-override", "Invalid value for sublayer override. Not an object or no id specified.", { value: i5 }));
  return { overrides: t8, context: r4 };
}
function G(e3, r4, t8) {
  const s5 = [];
  d2.forEachSublayer(e3, (e4) => {
    const r5 = e4.write({}, t8);
    Object.keys(r5).length > 1 && s5.push(r5);
  }), s5.length > 0 && (r4.sublayers = s5);
}
function V5(e3, r4, t8) {
  const s5 = t8?.origin && e3.get(t8.origin);
  s5 && (r4.sublayers = [], s5.overrides.forEach((e4) => {
    r4.sublayers.push(a(e4));
  }));
}
r([m({ type: ["BuildingSceneLayer"] })], U.prototype, "operationalLayerType", void 0), r([m({ readOnly: true })], U.prototype, "allSublayers", void 0), r([m(R2)], U.prototype, "sublayers", void 0), r([o("service", "sublayers")], U.prototype, "readSublayers", null), r([m({ type: C2, nonNullable: true, json: { write: true } })], U.prototype, "filters", void 0), r([m({ type: String, json: { write: true } })], U.prototype, "activeFilterId", void 0), r([m({ readOnly: true, type: u3 })], U.prototype, "summaryStatistics", void 0), r([o("summaryStatistics", ["statisticsHRef"])], U.prototype, "readSummaryStatistics", null), r([m({ type: [String], json: { read: false } })], U.prototype, "outFields", void 0), r([m(g2)], U.prototype, "fullExtent", void 0), r([m(d)], U.prototype, "legendEnabled", void 0), r([m({ type: ["show", "hide", "hide-children"] })], U.prototype, "listMode", void 0), r([m(m4(g))], U.prototype, "spatialReference", void 0), r([m(c)], U.prototype, "elevationInfo", null), r([m({ json: { read: false }, readOnly: true })], U.prototype, "type", void 0), r([m()], U.prototype, "associatedFeatureServiceItem", void 0), U = r([a2("esri.layers.BuildingSceneLayer")], U);
var $2 = U;
export {
  $2 as default
};
//# sourceMappingURL=BuildingSceneLayer-TMGDSOAI.js.map
