// node_modules/@arcgis/core/views/ViewingMode.js
var l;
function a(o) {
  return o === l.Global ? "global" : "local";
}
!function(l2) {
  l2[l2.Global = 1] = "Global", l2[l2.Local = 2] = "Local";
}(l || (l = {}));

export {
  l,
  a
};
//# sourceMappingURL=chunk-GW436Z36.js.map
