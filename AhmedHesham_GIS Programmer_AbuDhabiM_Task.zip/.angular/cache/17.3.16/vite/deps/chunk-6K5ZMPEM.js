import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/FloatBindUniform.js
var e = class extends i {
  constructor(r, e2) {
    super(r, "float", a.Bind, (o, s) => o.setUniform1f(r, e2(s)));
  }
};

export {
  e
};
//# sourceMappingURL=chunk-6K5ZMPEM.js.map
