import {
  a as a3,
  b,
  d as d2,
  p as p2,
  u as u2,
  x
} from "./chunk-GTVPP55O.js";
import {
  a as a2,
  c,
  p
} from "./chunk-YHKJPCKF.js";
import {
  e
} from "./chunk-JYALIYUG.js";
import {
  O
} from "./chunk-PPAPRIQT.js";
import {
  n2 as n
} from "./chunk-L7IGKLK6.js";
import {
  n as n2
} from "./chunk-PLXIETOO.js";
import {
  P,
  d
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  s
} from "./chunk-REZDV4AU.js";
import {
  g,
  m,
  o
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  u2 as u
} from "./chunk-VT56RVNM.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  G
} from "./chunk-D5RIMQ7U.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/LayerList/ListItemPanel.js
var g2 = class extends n2.IdentifiableMixin(O) {
  constructor(e2, t) {
    super(e2, t), this._legend = null, this.className = null, this.content = null, this.flowEnabled = false, this.image = null, this.listItem = null, this.open = false, this.visible = true;
  }
  initialize() {
    this.addHandles([d(() => this._canCreateLegend, () => this._createLegend(), P), d(() => [this._legend, this._legendOptions], () => this._updateLegend(), P)]);
  }
  destroy() {
    this._legend = u(this._legend);
  }
  get _canCreateLegend() {
    const { content: e2, listItem: t } = this;
    if (!t) return false;
    const i = "legend";
    return e2 === i || null != e2 && !!Array.isArray(e2) && e2.includes(i);
  }
  get _legendOptions() {
    const { listItem: e2, _legendLayerInfo: t } = this, i = e2?.view;
    return t && i ? { view: i, layerInfos: [t] } : {};
  }
  get _legendLayerInfo() {
    const e2 = this.listItem?.layer;
    if (!e2 || "subtype-sublayer" === e2.type) return null;
    const t = x(e2) ? e2 : null, i = e2?.parent, n3 = null != i && "type" in i && "map-image" === i.type ? t?.source : null, r2 = "";
    return n3 && i ? { layer: i, title: r2, sublayerIds: [n3.mapLayerId] } : { layer: e2, title: r2 };
  }
  get disabled() {
    const { listItem: e2, _legend: t, content: i } = this;
    return !e2 || !(Array.isArray(i) && i.length > 1) && (!!t && (!t.activeLayerInfos?.length || !e2.visibleAtCurrentScale || !e2.visible));
  }
  set disabled(e2) {
    this._overrideIfSome("disabled", e2);
  }
  get icon() {
    const { image: e2 } = this, t = this._getFirstWidget();
    return this._get("icon") ?? (!e2 && t ? t.icon : null);
  }
  set icon(e2) {
    this._overrideIfSome("icon", e2);
  }
  get title() {
    return this._get("title") || (this._getFirstWidget()?.label ?? "");
  }
  set title(e2) {
    this._override("title", e2);
  }
  render() {
    return n("div", { class: "esri-list-item-panel" }, this._renderContents());
  }
  _renderContent(e2) {
    const { _legend: t, disabled: i, open: n3 } = this;
    return e2 && !i && n3 ? "legend" === e2 && t ? n("div", { key: "legend-widget" }, t.render()) : "string" == typeof e2 ? n("div", { innerHTML: e2, key: e2 }) : e(e2) ? n("div", { key: "content-widget" }, e2.render()) : e2 instanceof HTMLElement ? n("div", { afterCreate: this._attachToNode, bind: e2, key: "content-element" }) : null : null;
  }
  _renderContents() {
    const { content: e2, open: t } = this;
    return t ? Array.isArray(e2) ? e2.map((e3) => this._renderContent(e3)) : this._renderContent(e2) : null;
  }
  _createLegend() {
    return __async(this, null, function* () {
      if (u(this._legend), this._legend = null, !this._canCreateLegend) return;
      const { default: e2 } = yield import("./@arcgis_core_widgets_Legend.js"), t = new e2(this._legendOptions);
      this._legend = t;
    });
  }
  _attachToNode(e2) {
    e2.appendChild(this);
  }
  _updateLegend() {
    const e2 = this._legend;
    e2 && e2.set(this._legendOptions);
  }
  _getWidget(e2) {
    return "legend" === e2 ? this._legend : e(e2) ? e2 : null;
  }
  _getFirstWidget() {
    const { content: e2 } = this;
    return Array.isArray(e2) ? e2.map((e3) => this._getWidget(e3)).find((e3) => e3) : this._getWidget(e2);
  }
};
r([m()], g2.prototype, "_legend", void 0), r([m()], g2.prototype, "_canCreateLegend", null), r([m()], g2.prototype, "_legendOptions", null), r([m()], g2.prototype, "_legendLayerInfo", null), r([m()], g2.prototype, "className", void 0), r([m()], g2.prototype, "content", void 0), r([m()], g2.prototype, "disabled", null), r([m()], g2.prototype, "flowEnabled", void 0), r([m()], g2.prototype, "icon", null), r([m()], g2.prototype, "image", void 0), r([m()], g2.prototype, "listItem", void 0), r([m()], g2.prototype, "open", void 0), r([m()], g2.prototype, "title", null), r([m()], g2.prototype, "visible", void 0), g2 = r([a("esri.widgets.LayerList.ListItemPanel")], g2);
var c2 = g2;

// node_modules/@arcgis/core/widgets/LayerList/ListItem.js
var g3;
var w = V.ofType({ key: "type", defaultKeyValue: "button", base: p, typeMap: { button: c, toggle: a2 } });
var S = V.ofType(w);
var _ = "layer";
var M = "child-list-mode";
var P2 = "hide";
var I = g3 = class extends n2.IdentifiableMixin(g) {
  constructor(e2) {
    super(e2), this.actionsSections = new S(), this.actionsOpen = false, this.checkPublishStatusEnabled = false, this.children = new (V.ofType(g3))(), this.childrenSortable = true, this.hidden = false, this.layer = null, this.listItemCreatedFunction = null, this.listModeDisabled = false, this.open = false, this.panel = null, this.parent = null, this.view = null;
  }
  initialize() {
    if (this.addHandles([d(() => [this.layer, this.layer?.listMode, this.listModeDisabled], () => this._watchLayerProperties(this.layer), P), d(() => this.checkPublishStatusEnabled, (e2) => this._updateChildrenPublishing(e2), P), d(() => this.view, (e2) => this._updateChildrenView(e2), P), d(() => this.panel, (e2) => this._setListItemOnPanel(e2), P)]), "function" == typeof this.listItemCreatedFunction) {
      const e2 = { item: this };
      this.listItemCreatedFunction.call(null, e2);
    }
  }
  destroy() {
    this.panel?.destroy(), this.children.destroyAll(), this.view = null;
  }
  get connectionStatus() {
    const { layerView: e2, publishing: t } = this;
    if (!t && e2 && "connectionStatus" in e2) return e2.connectionStatus;
  }
  get error() {
    return this.layer?.loadError;
  }
  get incompatible() {
    const { layerView: e2 } = this;
    return !(!e2 || !("spatialReferenceSupported" in e2)) && !e2.spatialReferenceSupported;
  }
  get layerView() {
    const { layer: e2, view: t } = this;
    if (!e2 || !t || "sublayer" === e2.type) return null;
    const i = "subtype-sublayer" === e2.type ? e2.parent : e2;
    return t.allLayerViews.find((e3) => e3.layer === i) ?? null;
  }
  castPanel(e2) {
    return this.panel?.open && !e2.hasOwnProperty("open") && (e2.open = true), e2 ? new c2(e2) : null;
  }
  get sortable() {
    return "knowledge-graph-sublayer" !== this.layer?.type && this._get("sortable");
  }
  set sortable(e2) {
    this._set("sortable", e2);
  }
  get title() {
    const e2 = o(this, "layer.layer");
    return (!e2 || e2 && o(this, "layer.layer.loaded")) && o(this, "layer.title") || o(this, "layer.attributes.title") || "";
  }
  set title(e2) {
    this._override("title", e2);
  }
  get publishing() {
    const { layer: e2, checkPublishStatusEnabled: t } = this;
    return !!(t && e2 && "publishingInfo" in e2 && "publishing" === e2.publishingInfo?.status);
  }
  get updating() {
    const { layerView: e2, connectionStatus: t, layer: i, publishing: s2 } = this;
    return !s2 && !t && (e2 ? e2.updating : "loading" === i?.loadStatus || false);
  }
  get visible() {
    return !!this.layer?.visible;
  }
  set visible(e2) {
    const t = this.layer;
    t && (t.visible = e2);
  }
  get visibleAtCurrentScale() {
    return this.layerView?.visibleAtCurrentScale ?? !b(this.layer, this.view?.scale);
  }
  get visibleAtCurrentTimeExtent() {
    return this.layerView?.visibleAtCurrentTimeExtent ?? true;
  }
  get visibilityMode() {
    return a3(this.layer);
  }
  clone() {
    return new g3({ actionsSections: this.actionsSections.clone(), actionsOpen: this.actionsOpen, checkPublishStatusEnabled: this.checkPublishStatusEnabled, children: this.children.clone(), childrenSortable: this.childrenSortable, hidden: this.hidden, layer: this.layer, listItemCreatedFunction: this.listItemCreatedFunction, listModeDisabled: this.listModeDisabled, open: this.open, panel: this.panel, parent: this.parent, sortable: this.sortable, title: this.title, view: this.view, visible: this.visible });
  }
  _setListItemOnPanel(e2) {
    e2 && (e2.listItem = this);
  }
  _updateChildrenPublishing(e2) {
    this.children?.forEach((t) => t.checkPublishStatusEnabled = e2);
  }
  _updateChildrenView(e2) {
    const t = this.children;
    t && t.forEach((t2) => t2.view = e2);
  }
  _createChildren(e2) {
    const { listModeDisabled: t, children: i } = this, s2 = e2.filter((e3) => !i.some((t2) => t2.layer === e3));
    i.addMany(this._createChildItems(s2, t));
  }
  _destroyChildren(e2) {
    const { children: t } = this, i = t.filter((t2) => !!t2.layer && !e2.includes(t2.layer));
    t.destroyMany(i);
  }
  _sortChildren(e2) {
    this.children.sort((t, i) => e2.indexOf(i.layer) - e2.indexOf(t.layer));
  }
  _destroyAllChildren() {
    this.removeHandles(M), this.children.destroyAll();
  }
  _watchChildLayerListMode(e2) {
    this.removeHandles(M), this.listModeDisabled || this.addHandles(e2.toArray().map((t) => d(() => t.listMode, () => this._compileChildren(e2))), M);
  }
  _compileChildren(e2) {
    const t = this.listModeDisabled ? e2 : e2?.filter((e3) => u2(e3) !== P2);
    e2?.length ? (this._createChildren(t), this._destroyChildren(t), this._sortChildren(t), this._watchChildLayerListMode(e2)) : this._destroyAllChildren();
  }
  _watchSublayerChanges(e2) {
    e2 && this.addHandles(e2.on("change", () => this._compileChildren(e2)), _);
  }
  _initializeChildLayers(e2) {
    this._compileChildren(e2), this._watchSublayerChanges(e2);
  }
  _createChildItems(e2, t) {
    return e2.reverse().map((e3) => t || p2(e3) ? new g3({ layer: e3, checkPublishStatusEnabled: this.checkPublishStatusEnabled, listItemCreatedFunction: this.listItemCreatedFunction, listModeDisabled: this.listModeDisabled, parent: this, view: this.view }) : null).filter(G);
  }
  _watchLayerProperties(e2) {
    if (this.removeHandles(_), this.removeHandles(M), !e2) return;
    if ("hide-children" === (!this.listModeDisabled && u2(e2))) return void this.children.destroyAll();
    const t = d2(e2);
    t && this.addHandles(d(() => e2[t], (i) => {
      e2.hasOwnProperty(t) && this._initializeChildLayers(i);
    }, P), _);
  }
};
r([m({ type: S })], I.prototype, "actionsSections", void 0), r([m()], I.prototype, "actionsOpen", void 0), r([m()], I.prototype, "checkPublishStatusEnabled", void 0), r([m({ type: V.ofType(I) })], I.prototype, "children", void 0), r([m()], I.prototype, "childrenSortable", void 0), r([m({ readOnly: true })], I.prototype, "connectionStatus", null), r([m({ readOnly: true })], I.prototype, "error", null), r([m()], I.prototype, "hidden", void 0), r([m({ readOnly: true })], I.prototype, "incompatible", null), r([m()], I.prototype, "layer", void 0), r([m({ readOnly: true })], I.prototype, "layerView", null), r([m()], I.prototype, "listItemCreatedFunction", void 0), r([m({ nonNullable: true })], I.prototype, "listModeDisabled", void 0), r([m()], I.prototype, "open", void 0), r([m({ type: c2 })], I.prototype, "panel", void 0), r([s("panel")], I.prototype, "castPanel", null), r([m()], I.prototype, "parent", void 0), r([m({ value: true })], I.prototype, "sortable", null), r([m()], I.prototype, "title", null), r([m({ readOnly: true })], I.prototype, "publishing", null), r([m({ readOnly: true })], I.prototype, "updating", null), r([m()], I.prototype, "view", void 0), r([m()], I.prototype, "visible", null), r([m({ readOnly: true })], I.prototype, "visibleAtCurrentScale", null), r([m({ readOnly: true })], I.prototype, "visibleAtCurrentTimeExtent", null), r([m({ readOnly: true })], I.prototype, "visibilityMode", null), I = g3 = r([a("esri.widgets.LayerList.ListItem")], I);
var O2 = I;

export {
  O2 as O
};
//# sourceMappingURL=chunk-4JZKYSSB.js.map
