import {
  h
} from "./chunk-4LHIE7NG.js";

// node_modules/@arcgis/core/views/support/HighlightDefaults.js
var e = new h("cyan");
var r = 1;
var l = 0.25;
var n = new h("black");
var t = 0.4;
var a = 0.2;
var w = 0.25;
var c = "default";
var m = "temporary";
var p = new h("yellow");

export {
  e,
  r,
  l,
  n,
  t,
  a,
  w,
  c,
  m,
  p
};
//# sourceMappingURL=chunk-DTRN4OOH.js.map
