import {
  g
} from "./chunk-ZEIUTG2D.js";
import "./chunk-ZRRD4CIZ.js";
import {
  B as B2
} from "./chunk-OMWXG65I.js";
import "./chunk-KPO5JCMG.js";
import "./chunk-JSUJK3TM.js";
import "./chunk-4G6QLHLE.js";
import "./chunk-GMBFT2HF.js";
import "./chunk-NCDGRISH.js";
import "./chunk-NMN6LZDW.js";
import "./chunk-F63YZ7TU.js";
import "./chunk-4SVSN5H5.js";
import "./chunk-HK6ZY4DB.js";
import "./chunk-6BUGRELN.js";
import "./chunk-KATWIIRQ.js";
import "./chunk-OQS7WWFI.js";
import "./chunk-QC47YGD2.js";
import "./chunk-MRUBK6JE.js";
import "./chunk-FQHSOO34.js";
import "./chunk-ECGH6E32.js";
import "./chunk-VIMZSBVM.js";
import "./chunk-RMXLL62T.js";
import "./chunk-I55BQRXQ.js";
import "./chunk-TZC4SNZT.js";
import "./chunk-KCIVZXDK.js";
import "./chunk-MILHALWW.js";
import "./chunk-54GNLAEA.js";
import "./chunk-HDVLTFYY.js";
import "./chunk-AI26OWA4.js";
import "./chunk-SZIT3IYE.js";
import "./chunk-CVMQJ2BZ.js";
import "./chunk-UX6MBXX3.js";
import "./chunk-BF5XGRKQ.js";
import "./chunk-ZFPFQ4J4.js";
import {
  r as r4
} from "./chunk-P5BI27MR.js";
import {
  s as s2
} from "./chunk-3P3SZYCX.js";
import {
  R,
  V as V3
} from "./chunk-TVC5ICZ6.js";
import "./chunk-VY7ME65R.js";
import "./chunk-ZL7AFA5U.js";
import {
  c as c3
} from "./chunk-DWHZIVJ2.js";
import "./chunk-NNQGBMH4.js";
import {
  i
} from "./chunk-KZONSPL6.js";
import {
  t as t2
} from "./chunk-TATHLUT3.js";
import {
  l as l2
} from "./chunk-Y5JUDCDZ.js";
import {
  c as c2
} from "./chunk-OR23LWBA.js";
import "./chunk-BOHQCAJM.js";
import "./chunk-KK6BHWJD.js";
import {
  a as a4
} from "./chunk-O27NRO2R.js";
import {
  s as s3
} from "./chunk-ZFKMGP62.js";
import "./chunk-IHXPJZKB.js";
import {
  p as p4
} from "./chunk-EYGV7DRM.js";
import {
  a as a5
} from "./chunk-KJXL4KHH.js";
import {
  C,
  n as n2
} from "./chunk-B4CSKOTH.js";
import "./chunk-37VXXTCK.js";
import {
  l as l3
} from "./chunk-DGGGA4EB.js";
import "./chunk-VOLYE23O.js";
import {
  e as e4
} from "./chunk-M56COCZM.js";
import "./chunk-H3Z5HDTB.js";
import "./chunk-YJNQBYCY.js";
import "./chunk-XHRVMHQV.js";
import {
  F
} from "./chunk-6KBNYSOO.js";
import "./chunk-YVZV2JQ2.js";
import {
  j as j2
} from "./chunk-SMUEPEJK.js";
import {
  f as f3
} from "./chunk-5I7JTSAL.js";
import {
  p
} from "./chunk-SWTEWHKX.js";
import {
  t
} from "./chunk-CLCRCQS5.js";
import {
  b
} from "./chunk-YLFWLXHD.js";
import {
  I as I2,
  c,
  d as d2,
  f,
  j,
  l,
  p as p2,
  u,
  v
} from "./chunk-AOJUXBCS.js";
import "./chunk-HZVZN4QC.js";
import "./chunk-ARKMS27Q.js";
import "./chunk-DEBJAVLQ.js";
import {
  S as S2
} from "./chunk-PEKG77YQ.js";
import "./chunk-M43HSGJE.js";
import "./chunk-2MPRPDUR.js";
import {
  p as p5
} from "./chunk-7T32KOGA.js";
import {
  B,
  H,
  oe,
  q as q2
} from "./chunk-XAJHU5YA.js";
import "./chunk-6AFIGCYY.js";
import "./chunk-OPMACZPA.js";
import "./chunk-7C4YASO2.js";
import "./chunk-G72JIG3C.js";
import "./chunk-QUH6IF3C.js";
import {
  m as m2,
  u as u2
} from "./chunk-6JLNBB4A.js";
import "./chunk-B6TLVNFQ.js";
import "./chunk-HCOIDKPJ.js";
import "./chunk-RI3APACQ.js";
import "./chunk-DNKL4VLK.js";
import "./chunk-JA6WVUX5.js";
import "./chunk-HLUCHGW6.js";
import "./chunk-5ZLWOYXQ.js";
import "./chunk-LMKW53EF.js";
import "./chunk-245OSL56.js";
import "./chunk-V6AHEXFE.js";
import {
  e as e3
} from "./chunk-WJF6G6DB.js";
import "./chunk-VDBD7USS.js";
import {
  p as p3
} from "./chunk-G4JWBWXC.js";
import "./chunk-TX7HQE3N.js";
import "./chunk-O4PT2W5W.js";
import "./chunk-VDUPOWSD.js";
import "./chunk-PCY7U2ND.js";
import "./chunk-WFMHAEPG.js";
import "./chunk-JTVRCNJE.js";
import "./chunk-KD5GWDMJ.js";
import "./chunk-AV2MJVRY.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-5MM6JTK5.js";
import "./chunk-EMGBZTFR.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import "./chunk-RY6EUXME.js";
import "./chunk-JHB4QD5T.js";
import "./chunk-XWFSWJ3K.js";
import {
  q
} from "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import {
  S as S3
} from "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import {
  g as g2
} from "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import {
  b as b2
} from "./chunk-7OZN72PM.js";
import "./chunk-Z4ITP2HY.js";
import "./chunk-WOVS7CNY.js";
import "./chunk-4VQUNH2Z.js";
import "./chunk-7SLET7NM.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import "./chunk-S4BA7TJA.js";
import {
  f as f2
} from "./chunk-GYDLT2MD.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import {
  S
} from "./chunk-CYXXOYR3.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-2K433C2G.js";
import {
  C as C2
} from "./chunk-EOJGN7NW.js";
import "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-XYTETMU6.js";
import {
  d
} from "./chunk-VYI6FOKY.js";
import {
  V as V2
} from "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import {
  P2 as P
} from "./chunk-ADRG7ORV.js";
import {
  I,
  J,
  V,
  r as r3
} from "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  e as e2,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2,
  n,
  r as r2,
  x
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  a as a3,
  e
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a,
  s2 as s
} from "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/catalog/CatalogDynamicGroupLayer.js
var v2 = class extends t(p(S2(f2))) {
  constructor(e5) {
    super(e5), this._layerCache = new e3(20, (e6) => e6.destroy()), this._oidToReference = new s2(), this._layerToReference = /* @__PURE__ */ new Map(), this.legendEnabled = true, this.layers = new V2(), this.maximumVisibleSublayers = 10, this.opacity = 1, this.parent = null, this.persistenceEnabled = true, this.title = "Layers in view", this.type = "catalog-dynamic-group", this.visible = true;
  }
  initialize() {
    this.addHandles([this.layers.on("after-add", ({ item: e5 }) => {
      e5.parent = this;
    }), this.layers.on("after-remove", ({ item: e5 }) => {
      e5.parent = null;
    }), d(() => this._orderBy, () => {
      this._updateLayerSortValues(), this._sortAllLayers();
    })]);
  }
  load(e5) {
    return this.addResolvingPromise(this.parent.load()), Promise.resolve(this);
  }
  destroy() {
    this._layerCache.destroy(), this._oidToReference.clear(), this._layerToReference.clear();
  }
  get _orderBy() {
    return this.parent ? this.parent.orderBy?.find((e5) => !e5.valueExpression && e5.field) ?? new a5({ field: this.parent.objectIdField }) : null;
  }
  get _referenceComparator() {
    const e5 = this._orderBy;
    if (!this.parent || !e5) return () => 0;
    const t3 = this.parent.fieldsIndex.get(e5.field), r5 = g(t3?.toJSON().type, "descending" === e5.order), o = g("esriFieldTypeOID", "descending" === e5.order);
    return (e6, t4) => r5(t4.sortValue, e6.sortValue) || o(t4.objectId, e6.objectId);
  }
  get fullExtent() {
    return this.parent?.fullExtent ?? null;
  }
  get updating() {
    return n(this._oidToReference, ({ pending: e5 }) => null != e5);
  }
  acquireLayer(e5) {
    if (this.destroyed) return e();
    const t3 = this._getLayerReference(e5);
    return t3.count++, e(() => {
      t3.count--, t3.count || this._destroyLayerReference(t3);
    });
  }
  _getLayerReference(e5) {
    const t3 = e5.getObjectId();
    return r2(this._oidToReference, t3, () => {
      const t4 = e5.getObjectId(), r5 = `${t4}`, o = e5.getAttribute(this.parent.itemSourceField), i2 = new L(e5, t4, o), s4 = this._layerCache.pop(r5);
      return s4 ? (this._addLayer(i2, s4), i2) : (i2.pending = this.parent.createLayerFromFootprint(e5).then((e6) => {
        i2.count ? this._addLayer(i2, e6) : (this.destroyed || this._layerCache.get(r5) || this._layerCache.put(r5, e6), i2.layer = null);
      }).catch(() => {
      }).finally(() => {
        i2.pending = null;
      }), i2);
    });
  }
  _destroyLayerReference(e5) {
    e5.layer && (this._layerToReference.delete(e5.layer), this.layers.remove(e5.layer), this.destroyed ? e5.layer.destroy() : this._layerCache.put(`${e5.objectId}`, e5.layer), e5.layer = null), this._oidToReference.delete(e5.objectId);
  }
  _addLayer(e5, t3) {
    e5.layer = t3, t3.persistenceEnabled = false, this._layerToReference.set(t3, e5), this._updateLayerSortValue(e5), this.layers.add(t3), this._sortAllLayers();
  }
  _updateLayerSortValues() {
    for (const e5 of this._layerToReference.values()) this._updateLayerSortValue(e5);
  }
  _updateLayerSortValue(e5) {
    this._orderBy && (e5.sortValue = e5.footprint.getAttribute(this._orderBy.field));
  }
  _sortAllLayers() {
    this.layers.sort((e5, t3) => this._referenceComparator(this._layerToReference.get(e5), this._layerToReference.get(t3)));
  }
};
r([m()], v2.prototype, "_orderBy", null), r([m({ readOnly: true })], v2.prototype, "_referenceComparator", null), r([m(d2)], v2.prototype, "legendEnabled", void 0), r([m({ type: ["show", "hide", "hide-children"], json: { write: true } })], v2.prototype, "listMode", void 0), r([m({ readOnly: true })], v2.prototype, "fullExtent", null), r([m({ type: String, json: { origins: { service: { read: false }, "portal-item": { read: false } }, write: { ignoreOrigin: true, isRequired: true } } })], v2.prototype, "id", void 0), r([m({ readOnly: true })], v2.prototype, "layers", void 0), r([m({ type: x, range: { min: 0, max: 50 }, json: { write: true, default: 10 } })], v2.prototype, "maximumVisibleSublayers", void 0), r([m(f)], v2.prototype, "opacity", void 0), r([m({ clonable: false })], v2.prototype, "parent", void 0), r([m({ type: String, nonNullable: true, json: { write: { ignoreOrigin: true, isRequired: true } } })], v2.prototype, "title", void 0), r([m({ json: { read: false } })], v2.prototype, "type", void 0), r([m({ readOnly: true })], v2.prototype, "updating", null), r([m({ type: Boolean, json: { name: "visibility", write: true } })], v2.prototype, "visible", void 0), v2 = r([a2("esri.layers.catalog.CatalogDynamicGroupLayer")], v2);
var b3 = v2;
var L = class {
  constructor(e5, t3, r5) {
    this.footprint = e5, this.objectId = t3, this.itemSource = r5, this.count = 0, this.layer = null, this.sortValue = void 0, this._pending = r4(null);
  }
  get pending() {
    return this._pending.value;
  }
  set pending(e5) {
    this._pending.value = e5;
  }
};

// node_modules/@arcgis/core/layers/catalog/CatalogFootprintLayer.js
function S4() {
  const e5 = new S3({ style: "solid", color: [0, 0, 0, 0], outline: { style: "solid", color: [96, 96, 96, 0.75], width: 0.75 } });
  return new p3({ symbol: e5 });
}
var P2 = class extends t(c2(p(S2(f2)))) {
  constructor(e5) {
    super(e5), this.attributeTableTemplate = null, this.charts = null, this.editingEnabled = true, this.elevationInfo = null, this.formTemplate = null, this.labelingInfo = null, this.labelsVisible = true, this.legendEnabled = true, this.maxScale = 0, this.minScale = 0, this.opacity = 1, this.parent = null, this.persistenceEnabled = true, this.popupEnabled = true, this.popupTemplate = null, this.title = "Footprints", this.type = "catalog-footprint", this.visible = true;
  }
  load(e5) {
    return this.addResolvingPromise(this._doLoad(e5)), Promise.resolve(this);
  }
  _doLoad(e5) {
    return __async(this, null, function* () {
      yield this.parent.load(e5), g2(this.renderer, this.fieldsIndex), this.addHandles([this.parent.on("apply-edits", (e6) => this.emit("apply-edits", e6)), this.parent.on("edits", (e6) => this.emit("edits", e6)), this.parent.on("refresh", (e6) => this.emit("refresh", e6))]);
    });
  }
  get apiKey() {
    return this.parent?.apiKey;
  }
  get capabilities() {
    return this.parent?.capabilities;
  }
  get customParameters() {
    return this.parent?.customParameters;
  }
  get dateFieldsTimeZone() {
    return this.parent?.dateFieldsTimeZone ?? null;
  }
  get datesInUnknownTimezone() {
    return this.parent?.datesInUnknownTimezone ?? false;
  }
  get definitionExpression() {
    return this.parent?.definitionExpression;
  }
  get editingInfo() {
    return this.parent?.editingInfo;
  }
  get effectiveCapabilities() {
    return this.parent?.effectiveCapabilities;
  }
  get createQueryVersion() {
    return this.parent?.createQueryVersion;
  }
  get defaultPopupTemplate() {
    return this.createPopupTemplate();
  }
  get displayField() {
    return this.parent?.displayField;
  }
  get displayFilterEnabled() {
    return this.parent?.displayFilterEnabled ?? true;
  }
  get displayFilterInfo() {
    return this.parent?.displayFilterInfo ?? null;
  }
  get effectiveEditingEnabled() {
    return false;
  }
  get fields() {
    return this.parent?.fields;
  }
  get fieldsIndex() {
    return this.parent?.fieldsIndex;
  }
  get fullExtent() {
    return this.parent?.fullExtent;
  }
  get geometryFieldsInfo() {
    return this.parent?.geometryFieldsInfo;
  }
  get geometryType() {
    return this.parent?.geometryType;
  }
  get globalIdField() {
    return this.parent?.globalIdField;
  }
  get hasM() {
    return this.parent?.hasM ?? false;
  }
  get hasZ() {
    return this.parent?.hasZ ?? false;
  }
  get objectIdField() {
    return this.parent?.objectIdField;
  }
  get orderBy() {
    return this.parent?.orderBy ?? null;
  }
  get outFields() {
    return this.parent?.outFields;
  }
  get parsedUrl() {
    return this.parent?.parsedUrl ?? null;
  }
  get preferredTimeZone() {
    return this.parent?.preferredTimeZone ?? null;
  }
  set renderer(e5) {
    g2(e5, this.fieldsIndex), this._set("renderer", e5);
  }
  get renderer() {
    return this._isOverridden("renderer") ? this._get("renderer") : S4();
  }
  get returnM() {
    return this.parent?.returnM;
  }
  get returnZ() {
    return this.parent?.returnZ;
  }
  get source() {
    return this.parent?.source;
  }
  get timeExtent() {
    return this.parent?.timeExtent;
  }
  get timeInfo() {
    return this.parent?.timeInfo;
  }
  get timeOffset() {
    return this.parent?.timeOffset;
  }
  get typeIdField() {
    return this.parent?.typeIdField;
  }
  get types() {
    return this.parent?.types;
  }
  get useViewTime() {
    return this.parent?.useViewTime ?? true;
  }
  get version() {
    return this.parent?.version;
  }
  applyEdits(e5, t3) {
    return __async(this, null, function* () {
      return yield this.load(), this.parent.applyEdits(e5, t3);
    });
  }
  createPopupTemplate(e5) {
    const t3 = { fields: this.fields, objectIdField: this.objectIdField, title: this.title };
    return p5(t3, e5);
  }
  createQuery() {
    return this.parent?.createQuery();
  }
  getField(e5) {
    return this.parent?.getField(e5);
  }
  getFieldDomain(e5, t3) {
    return this.parent?.getFieldDomain(e5, t3);
  }
  queryExtent(e5, t3) {
    return __async(this, null, function* () {
      return yield this.load(), this.parent.queryExtent(e5, t3);
    });
  }
  queryFeatures(e5, t3) {
    return __async(this, null, function* () {
      return yield this.load(), this.parent.queryFeatures(e5, t3);
    });
  }
  queryFeatureCount(e5, t3) {
    return __async(this, null, function* () {
      return yield this.load(), this.parent.queryFeatureCount(e5, t3);
    });
  }
  queryObjectIds(e5, t3) {
    return __async(this, null, function* () {
      return yield this.load(), this.parent.queryObjectIds(e5, t3);
    });
  }
};
r([m(I2)], P2.prototype, "attributeTableTemplate", void 0), r([m({ readOnly: true })], P2.prototype, "apiKey", null), r([m({ readOnly: true })], P2.prototype, "capabilities", null), r([m({ readOnly: true })], P2.prototype, "customParameters", null), r([m()], P2.prototype, "dateFieldsTimeZone", null), r([m({ readOnly: true })], P2.prototype, "datesInUnknownTimezone", null), r([m({ readOnly: true })], P2.prototype, "definitionExpression", null), r([m({ readOnly: true })], P2.prototype, "editingInfo", null), r([m({ readOnly: true })], P2.prototype, "effectiveCapabilities", null), r([m({ json: { origins: { "web-scene": { write: false } }, write: true } })], P2.prototype, "charts", void 0), r([m({ readOnly: true })], P2.prototype, "createQueryVersion", null), r([m({ readOnly: true })], P2.prototype, "defaultPopupTemplate", null), r([m({ readOnly: true })], P2.prototype, "displayField", null), r([m({ type: Boolean, nonNullable: true, json: { name: "enableEditing", write: true, origins: { "web-scene": { read: false, write: false } } } })], P2.prototype, "editingEnabled", void 0), r([m({ readOnly: true })], P2.prototype, "effectiveEditingEnabled", null), r([m((() => {
  const e5 = a(c);
  return e5.json.origins["web-map"] = { read: false, write: false }, e5;
})())], P2.prototype, "elevationInfo", void 0), r([m({ readOnly: true })], P2.prototype, "fields", null), r([m({ readOnly: true })], P2.prototype, "fieldsIndex", null), r([m({ type: V3, json: { name: "formInfo", write: true, origins: { "web-scene": { read: false, write: false } } } })], P2.prototype, "formTemplate", void 0), r([m({ readOnly: true })], P2.prototype, "fullExtent", null), r([m({ readOnly: true })], P2.prototype, "geometryFieldsInfo", null), r([m({ readOnly: true })], P2.prototype, "geometryType", null), r([m({ readOnly: true })], P2.prototype, "globalIdField", null), r([m({ readOnly: true })], P2.prototype, "hasM", null), r([m({ readOnly: true })], P2.prototype, "hasZ", null), r([m({ type: String, json: { origins: { service: { read: false }, "portal-item": { read: false } }, write: { ignoreOrigin: true, isRequired: true } } })], P2.prototype, "id", void 0), r([m({ type: [C], json: { name: "layerDefinition.drawingInfo.labelingInfo", read: n2, write: true } })], P2.prototype, "labelingInfo", void 0), r([m(p2)], P2.prototype, "labelsVisible", void 0), r([m(d2)], P2.prototype, "legendEnabled", void 0), r([m({ type: ["show", "hide"], json: { write: true } })], P2.prototype, "listMode", void 0), r([m((() => {
  const e5 = a(v);
  return e5.json.origins.service.read = false, e5;
})())], P2.prototype, "maxScale", void 0), r([m((() => {
  const e5 = a(j);
  return e5.json.origins.service.read = false, e5;
})())], P2.prototype, "minScale", void 0), r([m({ readOnly: true })], P2.prototype, "objectIdField", null), r([m(f)], P2.prototype, "opacity", void 0), r([m({ readOnly: true })], P2.prototype, "orderBy", null), r([m({ readOnly: true })], P2.prototype, "outFields", null), r([m({ clonable: false })], P2.prototype, "parent", void 0), r([m({ readOnly: true })], P2.prototype, "parsedUrl", null), r([m(l)], P2.prototype, "popupEnabled", void 0), r([m({ type: q, json: { name: "popupInfo", write: true } })], P2.prototype, "popupTemplate", void 0), r([m({ readOnly: true })], P2.prototype, "preferredTimeZone", null), r([m({ types: m2, json: { origins: { "web-scene": { types: u2 } }, name: "layerDefinition.drawingInfo.renderer", write: { overridePolicy(e5, t3) {
  return { ignoreOrigin: this.originIdOf(t3) < e2.PORTAL_ITEM };
} } } })], P2.prototype, "renderer", null), r([m({ readOnly: true })], P2.prototype, "returnM", null), r([m({ readOnly: true })], P2.prototype, "returnZ", null), r([m({ readOnly: true })], P2.prototype, "source", null), r([m({ readOnly: true })], P2.prototype, "timeExtent", null), r([m({ readOnly: true })], P2.prototype, "timeInfo", null), r([m({ readOnly: true })], P2.prototype, "timeOffset", null), r([m({ type: String, nonNullable: true, json: { write: { ignoreOrigin: true, isRequired: true } } })], P2.prototype, "title", void 0), r([m({ json: { read: false } })], P2.prototype, "type", void 0), r([m({ readOnly: true })], P2.prototype, "typeIdField", null), r([m({ readOnly: true })], P2.prototype, "types", null), r([m({ readOnly: true })], P2.prototype, "useViewTime", null), r([m({ type: Boolean, json: { name: "visibility", write: true } })], P2.prototype, "visible", void 0), P2 = r([a2("esri.layers.catalog.CatalogFootprintLayer")], P2);
var Z = P2;

// node_modules/@arcgis/core/layers/CatalogLayer.js
var B3 = s3();
function V4(e5) {
  return "object" == typeof e5 && null != e5 && "itemId" in e5 && "portalUrl" in e5;
}
function k(e5) {
  return "object" == typeof e5 && null != e5 && "url" in e5;
}
function J2(e5) {
  if (null == e5) return true;
  const t3 = Object.keys(e5);
  return !t3.length || 1 === t3.length && "id" === t3[0];
}
function K(e5, t3, r5, i2) {
  const o = e5.write({}, i2);
  J2(o) || (t3[r5] = o);
}
var H2 = class extends a4(R(F(p(p4(l3(t(f3(l2(b(j2(S2(e4(i(f2)))))))))))))) {
  constructor(e5) {
    super(e5), this.legendEnabled = true, this._portals = /* @__PURE__ */ new Map(), this._layerToFootprint = /* @__PURE__ */ new WeakMap(), this.drawOrderField = "cd_draworder", this.dynamicGroupLayer = new b3({ parent: this }), this.elevationInfo = null, this.fields = null, this.fieldsIndex = null, this.floorInfo = null, this.footprintLayer = new Z({ parent: this }), this.itemNameField = "cd_itemname", this.itemSourceField = "cd_itemsource", this.itemTypeField = "cd_itemtype", this.layers = new V2([this.dynamicGroupLayer, this.footprintLayer]), this.maxScaleField = "cd_maxscale", this.minScaleField = "cd_minscale", this.orderBy = null, this.outFields = null, this.supportedSourceTypes = /* @__PURE__ */ new Set(["Catalog Layer"]), this.source = new B2({ layer: this, supportedSourceTypes: this.supportedSourceTypes }), this.type = "catalog", this.typeIdField = null, this.types = null;
  }
  load(e5) {
    const t3 = null != e5 ? e5.signal : null, r5 = this.loadFromPortal({ supportedTypes: ["Feature Service"] }, e5).catch(a3).then(() => __async(this, null, function* () {
      const { url: e6, source: r6, portalItem: o } = this;
      if (!e6) throw new s("catalog-layer:missing-url", "Catalog layer must be created with a url");
      if (null == this.layerId) {
        const r7 = yield this._fetchFirstValidLayerId(t3);
        if (null == r7) throw new s("catalog-layer:missing-layerId", "There is no Catalog Layer in the service", { service: e6 });
        this.layerId = r7;
      }
      yield r6.load({ signal: t3 });
      const { sourceJSON: s4 } = r6;
      s4 && (this.sourceJSON = s4, this.read(s4, { origin: "service", portalItem: o, portal: o?.portal, url: this.parsedUrl }));
    })).then(() => {
      const e6 = [this.itemNameField, this.itemSourceField, this.itemTypeField, this.minScaleField, this.maxScaleField], t4 = e6.filter((e7) => !this.fieldsIndex.has(e7));
      if (t4.length) throw new s("catalog-layer:missing-fields", "There are missing fields to operate properly", { requiredFields: e6, missingFields: t4 });
    }).then(() => H(this, "load", e5));
    return this.addResolvingPromise(r5), Promise.resolve(this);
  }
  destroy() {
    this.footprintLayer.destroy(), this.dynamicGroupLayer.destroy();
    for (const e5 of this._portals.values()) e5.destroy();
    this._portals.clear();
  }
  get createQueryVersion() {
    return this.commitProperty("definitionExpression"), this.commitProperty("timeExtent"), this.commitProperty("timeOffset"), this.commitProperty("geometryType"), this.commitProperty("capabilities"), (this._get("createQueryVersion") ?? 0) + 1;
  }
  get editingEnabled() {
    return this.loaded && null != this.capabilities && this.capabilities.operations.supportsEditing && this.userHasEditingPrivileges;
  }
  get effectiveEditingEnabled() {
    return false;
  }
  get parsedUrl() {
    const e5 = I(this.url);
    return null != e5 && null != this.layerId && (e5.path = V(e5.path, this.layerId.toString())), e5;
  }
  applyEdits(e5, t3) {
    return __async(this, null, function* () {
      return q2(this, e5, t3);
    });
  }
  on(e5, t3) {
    return super.on(e5, t3);
  }
  createLayerFromFootprint(e5) {
    return __async(this, null, function* () {
      const t3 = yield this._createLayer(e5);
      return this._configureLayer(t3, e5), this._layerToFootprint.set(t3, e5), t3;
    });
  }
  createFootprintFromLayer(e5) {
    return this._layerToFootprint.get(e5)?.clone();
  }
  createQuery() {
    const e5 = new b2(), t3 = this.capabilities?.query;
    e5.returnGeometry = true, t3 && (e5.compactGeometryEnabled = t3.supportsCompactGeometry, e5.defaultSpatialReferenceEnabled = t3.supportsDefaultSpatialReference), e5.outFields = ["*"];
    const { timeOffset: r5, timeExtent: i2 } = this;
    return e5.timeExtent = null != r5 && null != i2 ? i2.offset(-r5.value, r5.unit) : i2 || null, e5.where = this.definitionExpression || "1=1", e5;
  }
  getFeatureType(e5) {
    return oe(this.types, this.typeIdField, e5);
  }
  getFieldDomain(e5, t3) {
    const r5 = t3?.feature, i2 = this.getFeatureType(r5);
    if (i2) {
      const t4 = i2.domains && i2.domains[e5];
      if (t4 && "inherited" !== t4.type) return t4;
    }
    return this.getField(e5)?.domain;
  }
  hasDataChanged() {
    return __async(this, null, function* () {
      return B(this);
    });
  }
  queryFeatures(e5, t3) {
    return __async(this, null, function* () {
      const r5 = yield this.load(), i2 = yield r5.source.queryFeatures(b2.from(e5) ?? r5.createQuery(), t3);
      if (i2?.features) for (const o of i2.features) o.layer = o.sourceLayer = r5.footprintLayer;
      return i2;
    });
  }
  queryObjectIds(e5, t3) {
    return __async(this, null, function* () {
      return (yield this.load()).source.queryObjectIds(b2.from(e5) ?? this.createQuery(), t3);
    });
  }
  queryFeatureCount(e5, t3) {
    return __async(this, null, function* () {
      return (yield this.load()).source.queryFeatureCount(b2.from(e5) ?? this.createQuery(), t3);
    });
  }
  queryExtent(e5, t3) {
    return __async(this, null, function* () {
      return (yield this.load()).source.queryExtent(b2.from(e5) ?? this.createQuery(), t3);
    });
  }
  serviceSupportsSpatialReference(e5) {
    return this.loaded && t2(this, e5);
  }
  read(e5, t3) {
    if (super.read(e5, t3), e5) {
      const { footprintLayer: r5, dynamicGroupLayer: i2 } = e5;
      r5 && this.footprintLayer.read(r5, t3), i2 && this.dynamicGroupLayer.read(i2, t3);
    }
  }
  _fetchFirstValidLayerId(e5) {
    return __async(this, null, function* () {
      const { data: r5 } = yield P(this.url, { query: __spreadProps(__spreadValues({ f: "json" }, this.customParameters), { token: this.apiKey }), responseType: "json", signal: e5 });
      if (Array.isArray(r5?.layers)) return r5.layers.find(({ type: e6 }) => this.supportedSourceTypes.has(e6))?.id;
    });
  }
  _createLayer(e5) {
    return __async(this, null, function* () {
      const t3 = e5.getAttribute(this.itemSourceField);
      if (!t3) throw new s("catalog-layer:item-source-missing", `The footprint is missing the "${this.itemSourceField}" attribute`);
      const r5 = JSON.parse(t3);
      if (V4(r5)) {
        const { itemId: e6, portalUrl: t4 } = r5, i2 = r3(t4), s5 = this.portalItem?.portal, a6 = C2.getDefault();
        let n3, l4 = true;
        s5 && J(t4, s5.url) ? n3 = s5 : J(t4, a6.url) ? n3 = a6 : (n3 = r2(this._portals, i2, () => new C2({ url: i2 })), l4 = false);
        const d3 = yield f2.fromPortalItem(new S({ id: e6, portal: n3 }));
        return l4 || (yield W(d3)), d3;
      }
      if (k(r5)) return f2.fromArcGISServerUrl({ url: r5.url });
      const { default: s4 } = yield import("./UnsupportedLayer-NNJVN4O6.js");
      return new s4();
    });
  }
  _configureLayer(e5, t3) {
    const r5 = t3.getAttribute(this.itemNameField);
    r5 && (e5.title = r5);
    const i2 = t3.getAttribute(this.maxScaleField);
    null != i2 && "maxScale" in e5 && (e5.maxScale = i2);
    const o = t3.getAttribute(this.minScaleField);
    null != o && "minScale" in e5 && (e5.minScale = o);
  }
};
function W(e5) {
  return __async(this, null, function* () {
    if ("portalItem" in e5 && e5.portalItem) {
      try {
        yield e5.load();
      } catch {
      }
      e5.portalItem = null, "group" === e5.type && (yield Promise.allSettled([...e5.layers.map((e6) => W(e6)), ...e5.tables.map((e6) => W(e6))]));
    }
  });
}
r([m(d2)], H2.prototype, "legendEnabled", void 0), r([m({ readOnly: true })], H2.prototype, "createQueryVersion", null), r([m({ readOnly: true })], H2.prototype, "drawOrderField", void 0), r([m({ type: b3, readOnly: true, json: { read: false, write: { ignoreOrigin: true, writer: K } } })], H2.prototype, "dynamicGroupLayer", void 0), r([m({ readOnly: true })], H2.prototype, "editingEnabled", null), r([m({ readOnly: true })], H2.prototype, "effectiveEditingEnabled", null), r([m({ json: { origins: { "web-scene": { name: "layerDefinition.elevationInfo", read: false, write: false } } } })], H2.prototype, "elevationInfo", void 0), r([m(__spreadProps(__spreadValues({}, B3.fields), { readOnly: true, json: { origins: { service: { read: true } }, read: false } }))], H2.prototype, "fields", void 0), r([m(B3.fieldsIndex)], H2.prototype, "fieldsIndex", void 0), r([m({ json: { origins: { "web-scene": { name: "layerDefinition.floorInfo", read: false, write: false } } } })], H2.prototype, "floorInfo", void 0), r([m({ type: Z, readOnly: true, json: { read: false, write: { ignoreOrigin: true, writer: K } } })], H2.prototype, "footprintLayer", void 0), r([m(u)], H2.prototype, "id", void 0), r([m({ readOnly: true })], H2.prototype, "itemNameField", void 0), r([m({ readOnly: true })], H2.prototype, "itemSourceField", void 0), r([m({ readOnly: true })], H2.prototype, "itemTypeField", void 0), r([m({ readOnly: true })], H2.prototype, "layers", void 0), r([m({ type: ["show", "hide", "hide-children"] })], H2.prototype, "listMode", void 0), r([m({ readOnly: true })], H2.prototype, "maxScaleField", void 0), r([m({ readOnly: true })], H2.prototype, "minScaleField", void 0), r([m({ value: "CatalogLayer", type: ["CatalogLayer"] })], H2.prototype, "operationalLayerType", void 0), r([m({ json: { origins: { "web-scene": { name: "layerDefinition.orderBy", write: true, read: true } } } })], H2.prototype, "orderBy", void 0), r([m(B3.outFields)], H2.prototype, "outFields", void 0), r([m({ readOnly: true })], H2.prototype, "parsedUrl", null), r([m({ readOnly: true })], H2.prototype, "source", void 0), r([m({ json: { read: false } })], H2.prototype, "type", void 0), r([m({ type: String })], H2.prototype, "typeIdField", void 0), r([m({ type: [c3] })], H2.prototype, "types", void 0), H2 = r([a2("esri.layers.CatalogLayer")], H2);
var $ = H2;
export {
  $ as default
};
//# sourceMappingURL=CatalogLayer-CY4A6QDL.js.map
