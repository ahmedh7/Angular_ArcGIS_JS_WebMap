import {
  html,
  nothing,
  safeClassMap
} from "./chunk-NMBGL4CC.js";

// node_modules/@esri/calcite-components/dist/chunks/Validation.js
var c = {
  validationContainer: "validation-container"
};
var m = ({ scale: i, status: a, id: t, icon: n, message: o }) => html`<div class=${safeClassMap(c.validationContainer)}><calcite-input-message aria-live=polite .icon=${n} id=${t ?? nothing} .scale=${i} .status=${a}>${o}</calcite-input-message></div>`;

export {
  m
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/Validation.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-GEZ5ITZ2.js.map
