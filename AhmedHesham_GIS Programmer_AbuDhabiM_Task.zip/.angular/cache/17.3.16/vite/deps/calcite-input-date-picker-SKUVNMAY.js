import "./chunk-HHEKWZOC.js";
import {
  o as o2,
  p as p2,
  x
} from "./chunk-PLIPJIB6.js";
import "./chunk-ASAOK2ML.js";
import "./chunk-CU2UWVEG.js";
import {
  k
} from "./chunk-FQS4PHWP.js";
import {
  X,
  Y,
  ct,
  ft,
  lt,
  ot,
  rt
} from "./chunk-K6AAVT2T.js";
import "./chunk-YANRGXVA.js";
import {
  s as s2
} from "./chunk-DK4MBEKC.js";
import {
  m as m6
} from "./chunk-6M3P2WWZ.js";
import {
  H,
  O,
  Q,
  X as X2,
  q
} from "./chunk-TAV7HQ6F.js";
import {
  m as m5
} from "./chunk-GEZ5ITZ2.js";
import {
  e,
  t
} from "./chunk-7BYAEWQF.js";
import "./chunk-47KWH5ND.js";
import "./chunk-RABWWKP5.js";
import {
  $,
  B,
  D,
  W
} from "./chunk-WXKM7U5Z.js";
import {
  T as T2,
  v
} from "./chunk-B2DAWPE2.js";
import "./chunk-ZNGJTAZC.js";
import {
  keyed
} from "./chunk-GYMHVFJE.js";
import {
  m as m3,
  p
} from "./chunk-JP6NVURN.js";
import {
  m as m4,
  o
} from "./chunk-JNDPOHLO.js";
import "./chunk-3EHTPQND.js";
import "./chunk-4OCBID5S.js";
import {
  createRef,
  ref
} from "./chunk-LPETJQKI.js";
import "./chunk-EJFZYJAF.js";
import {
  s
} from "./chunk-FJ5QMW6O.js";
import "./chunk-U3H4S3UY.js";
import {
  m as m2,
  mt,
  pt,
  wt
} from "./chunk-67TGT3ZY.js";
import {
  i
} from "./chunk-LPID7LVC.js";
import {
  LitElement2 as LitElement,
  S,
  T,
  createEvent,
  css,
  html,
  live,
  m,
  nothing,
  safeClassMap,
  setAttribute,
  stringOrBoolean
} from "./chunk-NMBGL4CC.js";
import {
  __async,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/chunks/date.js
function m7(t2, n3, e2) {
  if (!t2)
    return;
  const r = t2.getTime(), a = !(n3 instanceof Date) || r >= n3.getTime(), o4 = !(e2 instanceof Date) || r <= e2.getTime();
  return a && o4;
}
function p3(t2, n3, e2) {
  if (!(t2 instanceof Date))
    return null;
  const r = t2.getTime(), a = n3 instanceof Date && r < n3.getTime(), o4 = e2 instanceof Date && r > e2.getTime();
  return a ? n3 : o4 ? e2 : t2;
}
function O2(t2, n3 = false) {
  if (t2 instanceof Date)
    return t2;
  if (!t2 || typeof t2 != "string")
    return null;
  const e2 = t2.split(/[: T-]/).map(parseFloat), r = new Date(e2[0], (e2[1] || 1) - 1, e2[2] || 1);
  if (r.setFullYear(e2[0]), isNaN(r.getTime()))
    throw new Error(`Invalid ISO 8601 date: "${t2}"`);
  return n3 ? T3(r) : r;
}
function w(t2, n3) {
  if (!n3)
    return null;
  const { separator: e2 } = n3, r = y(t2, n3), { day: a, month: o4 } = r, s4 = M(r.year, n3), i2 = new Date(s4, o4, a);
  i2.setFullYear(s4);
  const c = a > 0, u = o4 > -1, g = !isNaN(i2.getTime()), l2 = t2.split(e2).filter((h) => h).length > 2, D3 = s4.toString().length > 0;
  return c && u && g && l2 && D3 ? i2 : null;
}
function M(t2, n3) {
  return f(t2, n3, "read");
}
function I(t2, n3) {
  return f(t2, n3, "write");
}
function f(t2, n3, e2) {
  if (n3["default-calendar"] !== "buddhist")
    return t2;
  const a = 543 * (e2 === "read" ? -1 : 1);
  return t2 + a;
}
function F(t2, n3) {
  const { separator: e2, unitOrder: r } = n3, a = S2(r), o4 = t2.split(e2).map((u) => q.delocalize(u)), s4 = o4[a.indexOf("d")], i2 = o4[a.indexOf("m")], c = o4[a.indexOf("y")];
  return { day: s4, month: i2, year: c };
}
function x2(t2) {
  if (t2 instanceof Date) {
    const n3 = String(t2.getMonth() + 1).padStart(2, "0"), e2 = String(t2.getDate()).padStart(2, "0");
    return `${String(t2.getFullYear()).padStart(4, "0")}-${n3}-${e2}`;
  }
  return "";
}
function E(t2) {
  const n3 = t2.split("-");
  return { day: n3[2], month: n3[1], year: n3[0] };
}
function v2(t2, n3) {
  return t2 instanceof Date && n3 instanceof Date && t2.getDate() === n3.getDate() && t2.getMonth() === n3.getMonth() && t2.getFullYear() === n3.getFullYear();
}
function A(t2) {
  const n3 = t2.getMonth(), e2 = new Date(t2);
  return e2.setMonth(n3 - 1), n3 === e2.getMonth() ? new Date(t2.getFullYear(), n3, 0) : e2;
}
function C(t2, n3) {
  const e2 = new Date(t2);
  return e2.setMonth(n3), e2;
}
function L(t2, n3, e2) {
  const r = new Date(t2);
  return r.setDate(1), m7(r, n3, e2) ? r : p3(r, n3, e2);
}
function N(t2) {
  const n3 = t2.getMonth(), e2 = new Date(t2);
  return e2.setMonth(n3 + 1), (n3 + 2) % 7 === e2.getMonth() % 7 ? new Date(t2.getFullYear(), n3 + 2, 0) : e2;
}
function y(t2, n3) {
  const { day: e2, month: r, year: a } = F(t2, n3);
  return {
    day: parseInt(e2),
    month: parseInt(r) - 1,
    // this subtracts by 1 because the month in the Date constructor is zero-based https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getMonth
    year: parseInt(a)
  };
}
function S2(t2) {
  const n3 = ["d", "m", "y"], e2 = t2.toLowerCase();
  return n3.sort((r, a) => e2.indexOf(r) - e2.indexOf(a));
}
function R(t2, n3) {
  const e2 = t2.getTime(), r = n3.getTime();
  return (e2 - r) / (1e3 * 3600 * 24);
}
function T3(t2) {
  return t2.setHours(23, 59, 59, 999), t2;
}
function _(t2, n3) {
  return t2 && n3 && t2.getMonth() === n3.getMonth() && t2.getFullYear() === n3.getFullYear();
}

// node_modules/@esri/calcite-components/dist/components/calcite-date-picker-day/customElement.js
var b = css`:host([disabled]){cursor:default;-webkit-user-select:none;user-select:none;opacity:var(--calcite-opacity-disabled)}:host([disabled]) *,:host([disabled]) ::slotted(*){pointer-events:none}:host{position:relative;display:flex;cursor:pointer;outline:none}:host([disabled]) ::slotted([calcite-hydrated][disabled]),:host([disabled]) [calcite-hydrated][disabled]{opacity:1}.interaction-container{display:contents}.day-wrapper{position:relative;display:flex;inline-size:100%;flex-direction:column;align-items:center;justify-content:center}.day{position:relative;display:flex;inline-size:100%;align-items:center;justify-content:center;font-size:var(--calcite-font-size--2);line-height:1rem;line-height:1;transition-property:background-color,block-size,border-color,box-shadow,color,inset-block-end,inset-block-start,inset-inline-end,inset-inline-start,inset-size,opacity,outline-color,transform;transition-duration:var(--calcite-animation-timing);transition-timing-function:ease-in-out;line-height:var(--calcite-font-line-height-fixed-base);block-size:var(--calcite-internal-day-size);outline-color:var(--calcite-color-transparent);background-color:var(--calcite-date-picker-day-background-color);color:var(--calcite-date-picker-day-text-color, var(--calcite-color-text-3))}.text{margin-block:1px 0px;margin-inline-start:0px}:host([scale=s]){--calcite-internal-day-size: 32px}:host([scale=s]) .day{font-size:var(--calcite-font-size--2)}:host([scale=m]){--calcite-internal-day-size: 40px}:host([scale=m]) .day{font-size:var(--calcite-font-size--1)}:host([scale=l]){--calcite-internal-day-size: 44px}:host([scale=l]) .day{font-size:var(--calcite-font-size-0)}:host(:not([current-month])) .day{opacity:var(--calcite-opacity-disabled)}:host(:hover:not([disabled]):not([selected])) .day{background-color:var(--calcite-date-picker-day-background-color-hover, var(--calcite-color-foreground-2));color:var(--calcite-date-picker-day-text-color-hover, var(--calcite-color-text-1))}:host(:not([range]):not([selected]).current-day) .day{color:var(--calcite-date-picker-current-day-text-color, var(--calcite-color-text-1));font-weight:var(--calcite-font-weight-medium)}:host(:focus[selected]) .day{z-index:var(--calcite-z-index);outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))));box-shadow:0 0 0 2px var(--calcite-color-foreground-1)}:host(:focus:not([disabled]):not([selected])) .day{outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(-2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))))}:host(:hover:not([disabled]):not([selected])) .day{outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(-2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))))}:host([selected]) .day{font-weight:var(--calcite-font-weight-medium);background-color:var(--calcite-date-picker-day-background-color-selected, var(--calcite-color-brand));color:var(--calcite-date-picker-day-text-color-selected, var(--calcite-color-foreground-1))}:host([range-hover]:not([selected])) .day{background-color:var(--calcite-date-picker-day-outside-range-background-color-hover, var(--calcite-color-foreground-2));color:var(--calcite-date-picker-day-outside-range-text-color-hover, var(--calcite-color-text-1))}:host([highlighted]:not([selected])) .day,:host(:hover[highlighted]:not([selected])) .day{color:var(--calcite-date-picker-day-range-text-color, var(--calcite-color-brand));background-color:var(--calcite-date-picker-day-range-background-color, var(--calcite-color-foreground-current))}@media (forced-colors: active){.day{border-radius:0}:host([selected]){outline:2px solid canvasText}:host(:hover:not([selected])) .day{border-radius:50%}:host([range][selected]) .day,:host([highlighted]) .day,:host([range-hover]:not([selected])) .day{background-color:highlight}:host([range-hover]) .day,:host([range][selected][start-of-range]) .day,:host([range][selected][end-of-range]) .day{background-color:canvas}}:host([hidden]){display:none}[hidden]{display:none}`;
var k2 = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.active = false, this.currentMonth = false, this.disabled = false, this.endOfRange = false, this.highlighted = false, this.range = false, this.rangeHover = false, this.selected = false, this.startOfRange = false, this.calciteInternalDayHover = createEvent({ cancelable: false }), this.calciteInternalDaySelect = createEvent({ cancelable: false }), this.listen("pointerover", this.pointerOverHandler), this.listen("click", this.onClick), this.listen("keydown", this.keyDownHandler);
  }
  static {
    this.properties = { active: 7, currentMonth: 7, dateTimeFormat: 0, day: 9, disabled: 7, endOfRange: 7, highlighted: 7, range: 7, rangeEdge: 3, rangeHover: 7, scale: 3, selected: 7, startOfRange: 7, value: 0 };
  }
  static {
    this.styles = b;
  }
  // #endregion
  // #region Public Methods
  /** Sets focus on the component. */
  setFocus() {
    return __async(this, null, function* () {
      yield m4(this), this.el.focus();
    });
  }
  load() {
    this.parentDatePickerEl = m2(this.el, "calcite-date-picker");
  }
  updated() {
    m3(this);
  }
  // #endregion
  // #region Private Methods
  onClick() {
    this.disabled || this.calciteInternalDaySelect.emit();
  }
  keyDownHandler(e2) {
    t(e2.key) && (this.disabled || this.calciteInternalDaySelect.emit(), e2.preventDefault());
  }
  pointerOverHandler() {
    this.disabled || this.calciteInternalDayHover.emit();
  }
  // #endregion
  // #region Rendering
  render() {
    const e2 = x2(this.value).replaceAll("-", "");
    if (this.parentDatePickerEl) {
      const { numberingSystem: t2, lang: a } = this.parentDatePickerEl;
      q.numberFormatOptions = __spreadValues(__spreadValues({
        useGrouping: false
      }, t2 && { numberingSystem: t2 }), a && { locale: a });
    }
    const r = q.localize(String(this.day)), l2 = this.dateTimeFormat.format(this.value);
    return this.el.ariaLabel = l2, this.el.ariaSelected = wt(this.active), setAttribute(this.el, "id", e2), this.el.role = "button", setAttribute(this.el, "tabIndex", this.active && !this.disabled ? 0 : -1), p({ disabled: this.disabled, children: html`<div aria-hidden=true class="day-wrapper"><span class="day"><span class="text">${r}</span></span></div>` });
  }
};
S("calcite-date-picker-day", k2);

// node_modules/@esri/calcite-components/dist/components/calcite-date-picker-month-header/customElement.js
var N2 = css`:host{display:block}.header{display:flex;block-size:100%;align-items:center;justify-content:space-between}.chevron-container{display:flex;align-items:center}:host([scale=s]){block-size:24px;margin:var(--calcite-spacing-xs);margin-inline-start:var(--calcite-spacing-sm)}:host([scale=s]) .chevron-container,:host([scale=s]) .chevron{min-inline-size:24px;block-size:24px}:host([scale=m]){block-size:32px;margin:var(--calcite-spacing-sm);margin-inline-start:var(--calcite-spacing-sm-plus)}:host([scale=m]) .chevron-container,:host([scale=m]) .chevron{min-inline-size:32px;block-size:32px;--calcite-internal-action-padding-block: var(--calcite-spacing-xxs)}:host([scale=l]){block-size:44px;margin:var(--calcite-spacing-xs);margin-inline-start:var(--calcite-spacing-sm)}:host([scale=l]) .chevron-container,:host([scale=l]) .chevron{min-inline-size:44px;block-size:44px;--calcite-internal-action-padding-block: var(--calcite-spacing-sm-plus)}.chevron{box-sizing:content-box;display:flex;block-size:100%;inline-size:100%;flex-grow:0;cursor:pointer;align-items:center;justify-content:center;border-style:none;outline-color:transparent;transition-property:background-color,block-size,border-color,box-shadow,color,inset-block-end,inset-block-start,inset-inline-end,inset-inline-start,inset-size,opacity,outline-color,transform;transition-duration:var(--calcite-animation-timing);transition-timing-function:ease-in-out;--calcite-internal-action-padding-block: 0;--calcite-action-background-color: var(--calcite-date-picker-header-action-background-color);--calcite-action-background-color-hover: var(--calcite-date-picker-header-action-background-color-hover);--calcite-action-background-color-press: var(--calcite-date-picker-header-action-background-color-press);--calcite-action-text-color: var(--calcite-date-picker-header-action-text-color);--calcite-action-text-color-press: var(--calcite-date-picker-header-action-text-color-press)}.chevron:focus{outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(-2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))))}.chevron[aria-disabled=true]{pointer-events:none}.month-year-container{display:flex;block-size:100%;inline-size:100%;flex:1 1 auto;align-items:center;justify-content:flex-start;text-align:center;line-height:1;gap:var(--calcite-spacing-xxs)}.month-year-container.range-calendar{justify-content:center}.year-container{position:relative;display:flex;block-size:100%}.suffix{display:flex;align-items:center}.year,.suffix{margin-inline:var(--calcite-spacing-xxs);font-weight:var(--calcite-font-weight-medium);color:var(--calcite-date-picker-year-text-color, var(--calcite-color-text-1));font-size:var(--calcite-font-size-md);line-height:var(--calcite-font-line-height-fixed-lg)}.year{position:relative;display:inline-block;border-style:none;background-color:transparent;text-align:center;font-family:inherit;outline-color:transparent;inline-size:44px}.year:hover{transition-duration:.1s;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-property:outline-color;outline:2px solid var(--calcite-color-border-2);outline-offset:-2px}.year:focus{outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(-2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))))}.month-select{--calcite-select-internal-border-width: 0;--calcite-select-internal-icon-border-inline-end-width: 0;--calcite-select-spacing-inline: var(--calcite-spacing-xxs);--calcite-select-font-size: var(--calcite-date-picker-month-select-font-size, var(--calcite-font-size-md));--calcite-select-text-color: var(--calcite-date-picker-month-select-text-color, var(--calcite-color-text-1));--calcite-select-icon-color: var(--calcite-date-picker-month-select-icon-color);--calcite-select-icon-color-hover: var(--calcite-date-picker-month-select-icon-color-hover);--calcite-internal-select-spacing-block: var(--calcite-spacing-xxs);--calcite-internal-select-icon-container-padding-inline: var(--calcite-spacing-xxs);--calcite-internal-select-line-height: var(--calcite-font-line-height-fixed-lg);--calcite-internal-select-font-weight: var(--calcite-font-weight-medium)}:host([scale=s]) .month-year-container .month-select{--calcite-select-spacing-inline: var(--calcite-spacing-base);--calcite-select-font-size: var(--calcite-date-picker-month-select-font-size, var(--calcite-font-size));--calcite-internal-select-spacing-block: var(--calcite-spacing-base);--calcite-internal-select-icon-container-padding-inline: var(--calcite-spacing-base);--calcite-internal-select-block-size: 24px;--calcite-internal-select-line-height: var(--calcite-font-line-height-fixed-base)}:host([scale=s]) .month-year-container .year{inline-size:40px}:host([scale=s]) .month-year-container .year,:host([scale=s]) .month-year-container .suffix{font-size:var(--calcite-font-size);line-height:var(--calcite-font-line-height-fixed-base)}:host([scale=l]) .month-year-container .month-select{--calcite-select-spacing-inline: var(--calcite-spacing-sm);--calcite-select-font-size: var(--calcite-date-picker-month-select-font-size, var(--calcite-font-size-lg));--calcite-internal-select-spacing-block: var(--calcite-spacing-sm);--calcite-internal-select-icon-container-padding-inline: var(--calcite-spacing-sm);--calcite-internal-select-block-size: 44px;--calcite-internal-select-line-height: var(--calcite-font-line-height-fixed-xl)}:host([scale=l]) .month-year-container .year{inline-size:48px}:host([scale=l]) .month-year-container .year,:host([scale=l]) .month-year-container .suffix{font-size:var(--calcite-font-size-lg);line-height:var(--calcite-font-line-height-fixed-xl)}:host([hidden]){display:none}[hidden]{display:none}`;
var s3 = {
  header: "header",
  chevron: "chevron",
  chevronContainer: "chevron-container",
  monthYearContainer: "month-year-container",
  monthPicker: "month-select",
  rangeCalendar: "range-calendar",
  suffix: "suffix",
  yearContainer: "year-container"
};
var M2 = {
  chevronLeft: "chevron-left",
  chevronRight: "chevron-right"
};
var L2 = 16;
var H2 = class extends LitElement {
  constructor() {
    super(...arguments), this.monthPickerEl = createRef(), this.yearInputEl = createRef(), this.calciteInternalDatePickerMonthHeaderSelectChange = createEvent({ cancelable: false });
  }
  static {
    this.properties = { nextMonthDate: 16, prevMonthDate: 16, activeDate: 0, headingLevel: 9, localeData: 0, max: 0, messages: 0, min: 0, monthStyle: 1, position: 1, scale: 3, selectedDate: 0 };
  }
  static {
    this.styles = N2;
  }
  // #endregion
  // #region Lifecycle
  connectedCallback() {
    super.connectedCallback(), this.setNextPrevMonthDates();
  }
  load() {
    this.parentDatePickerEl = m2(this.el, "calcite-date-picker");
  }
  willUpdate(e2) {
    this.hasUpdated && (e2.has("activeDate") || e2.has("localeData")) && this.setYearSelectMenuWidth(), this.hasUpdated && e2.has("scale") && this.setYearSelectWidthOffset(), (e2.has("min") || e2.has("max") || e2.has("activeDate")) && this.setNextPrevMonthDates();
  }
  loaded() {
    this.setYearSelectWidthOffset();
  }
  // #endregion
  // #region Private Methods
  setNextPrevMonthDates() {
    this.activeDate && (this.nextMonthDate = p3(N(this.activeDate), this.min, this.max), this.prevMonthDate = p3(A(this.activeDate), this.min, this.max));
  }
  /**
   * Increment year on UP/DOWN keys
   *
   * @param event
   */
  onYearKey(e2) {
    const t2 = this.parseCalendarYear(e2.target.value);
    switch (e2.key) {
      case "ArrowDown":
        e2.preventDefault(), this.setYear({ localizedYear: t2, offset: -1 });
        break;
      case "ArrowUp":
        e2.preventDefault(), this.setYear({ localizedYear: t2, offset: 1 });
        break;
    }
  }
  formatCalendarYear(e2) {
    return q.localize(`${I(e2, this.localeData)}`);
  }
  parseCalendarYear(e2) {
    return q.localize(`${M(Number(q.delocalize(e2)), this.localeData)}`);
  }
  onYearChange(e2) {
    this.setYear({
      localizedYear: this.parseCalendarYear(e2.target.value)
    });
  }
  onYearInput(e2) {
    this.setYear({
      localizedYear: this.parseCalendarYear(e2.target.value),
      commit: false
    });
  }
  prevMonthClick(e2) {
    this.handleArrowClick(e2, this.prevMonthDate);
  }
  prevMonthKeydown(e2) {
    t(e2.key) && this.prevMonthClick(e2);
  }
  nextMonthClick(e2) {
    this.handleArrowClick(e2, this.nextMonthDate);
  }
  nextMonthKeydown(e2) {
    t(e2.key) && this.nextMonthClick(e2);
  }
  handleArrowClick(e2, t2) {
    return __async(this, null, function* () {
      e2.preventDefault(), yield this.handlePenultimateValidMonth(e2), this.calciteInternalDatePickerMonthHeaderSelectChange.emit(t2);
    });
  }
  handleMonthChange(e2) {
    const t2 = e2.target, { abbreviated: a, wide: n3 } = this.localeData.months, i2 = (this.monthStyle === "wide" ? n3 : a).indexOf(t2.value);
    let l2 = C(this.activeDate, i2);
    m7(l2, this.min, this.max) || (l2 = p3(l2, this.min, this.max)), this.calciteInternalDatePickerMonthHeaderSelectChange.emit(l2), this.setYearSelectMenuWidth();
  }
  getInRangeDate({ localizedYear: e2, offset: t2 = 0 }) {
    const { min: a, max: n3, activeDate: c } = this, i2 = Number(q.delocalize(e2)), l2 = i2.toString().length, d = isNaN(i2) ? false : i2 + t2, D3 = d && (!a || a.getFullYear() <= d) && (!n3 || n3.getFullYear() >= d);
    if (d && D3 && l2 === e2.length) {
      const v3 = new Date(c);
      return v3.setFullYear(d), p3(v3, a, n3);
    }
  }
  /**
   * Parse localized year string from input,
   * set to active if in range
   *
   * @param root0
   * @param root0.localizedYear
   * @param root0.commit
   * @param root0.offset
   */
  setYear({ localizedYear: e2, commit: t2 = true, offset: a = 0 }) {
    const { yearInputEl: { value: n3 }, activeDate: c } = this, i2 = this.getInRangeDate({ localizedYear: e2, offset: a });
    i2 && this.calciteInternalDatePickerMonthHeaderSelectChange.emit(i2), t2 && (n3.value = this.formatCalendarYear((i2 || c).getFullYear()));
  }
  setYearSelectWidthOffset() {
    this.yearSelectWidthOffset = L2 + 3 * parseInt(this.getYearSelectPadding()), this.setYearSelectMenuWidth();
  }
  setYearSelectMenuWidth() {
    const e2 = this.monthPickerEl.value;
    e2 && requestAnimationFrame(() => {
      const t2 = getComputedStyle(e2), a = `${t2.fontStyle} ${t2.fontVariant} ${t2.fontWeight} ${t2.fontSize}/${t2.lineHeight} ${t2.fontFamily}`, c = this.localeData.months[this.monthStyle][this.activeDate.getMonth()], i2 = Math.ceil(pt(c, a));
      e2.style.width = `${i2 + this.yearSelectWidthOffset}px`;
    });
  }
  isMonthInRange(e2) {
    const t2 = C(this.activeDate, e2);
    return !this.min && !this.max || m7(t2, this.min, this.max) ? true : _(t2, this.max) || _(t2, this.min);
  }
  handlePenultimateValidMonth(e2) {
    return __async(this, null, function* () {
      const n3 = e2.target.getAttribute("data-direction") === "left";
      let c;
      if (n3 && this.min) {
        const i2 = p3(A(this.activeDate), this.min, this.max);
        c = _(i2, this.min);
      } else if (this.max) {
        const i2 = p3(N(this.activeDate), this.min, this.max);
        c = _(i2, this.max);
      }
      if (c)
        if (this.position)
          this.yearInputEl.value.focus();
        else {
          const i2 = n3 ? this.nextMonthAction : this.prevMonthAction;
          i2.disabled = false, yield i2.setFocus();
        }
    });
  }
  getPx(e2) {
    const t2 = Number(e2.replace(/[rem|px]/g, "")), a = 16;
    return e2.includes("rem") ? `${t2 * a}px` : `${t2}px`;
  }
  getYearSelectPadding() {
    let e2;
    switch (this.scale) {
      case "l":
        e2 = p2;
        break;
      case "s":
        e2 = x;
        break;
      default:
        e2 = o2;
        break;
    }
    return this.getPx(e2);
  }
  // #endregion
  // #region Rendering
  render() {
    return html`<div class=${safeClassMap(s3.header)}>${this.renderContent()}</div>`;
  }
  renderContent() {
    const { localeData: e2, activeDate: t2 } = this;
    if (!t2 || !e2)
      return null;
    if (this.parentDatePickerEl) {
      const { numberingSystem: c, lang: i2 } = this.parentDatePickerEl;
      q.numberFormatOptions = __spreadValues(__spreadValues({
        useGrouping: false
      }, c && { numberingSystem: c }), i2 && { locale: i2 });
    }
    const a = S2(e2.unitOrder), n3 = a.indexOf("y") < a.indexOf("m");
    return html`${this.position && html`<div class=${safeClassMap({ [s3.chevronContainer]: true })}>${this.position === "start" && this.renderChevron("left") || ""}</div>` || ""}<div class=${safeClassMap({
      [s3.monthYearContainer]: true,
      [s3.rangeCalendar]: !!this.position
    })}>${this.renderMonthYearContainer(n3)}</div>${!this.position && html`<div class=${safeClassMap({ [s3.chevronContainer]: true })}>${this.renderChevron("left")}</div>` || ""}<div class=${safeClassMap({ [s3.chevronContainer]: true })}>${this.position !== "start" && this.renderChevron("right") || ""}</div>`;
  }
  renderMonthYearContainer(e2) {
    return e2 ? [this.renderYearInput(), this.renderMonthPicker()] : [this.renderMonthPicker(), this.renderYearInput()];
  }
  renderMonthPicker() {
    const e2 = this.activeDate.getMonth(), t2 = this.localeData.months[this.monthStyle];
    return html`<calcite-select class=${safeClassMap(s3.monthPicker)} .label=${this.messages.monthMenu} @calciteSelectChange=${this.handleMonthChange} width=auto ${ref(this.monthPickerEl)}>${t2.map((a, n3) => html`<calcite-option .disabled=${!this.isMonthInRange(n3)} .selected=${n3 === e2} .value=${a}>${a}</calcite-option>`)}</calcite-select>`;
  }
  renderYearInput() {
    const e2 = this.localeData.year?.suffix, t2 = this.formatCalendarYear(this.activeDate.getFullYear());
    return html`<span class=${safeClassMap(s3.yearContainer)}><input .ariaLabel=${this.messages.year} class=${safeClassMap({
      year: true
    })} inputmode=numeric maxlength=4 minlength=1 @change=${this.onYearChange} @input=${this.onYearInput} @keydown=${this.onYearKey} pattern=\\d* type=text .value=${live(t2 ?? "")} ${ref(this.yearInputEl)}>${e2 && html`<span class=${safeClassMap(s3.suffix)}>${e2}</span>` || ""}</span>`;
  }
  renderChevron(e2) {
    const t2 = e2 === "right", a = _(t2 ? this.nextMonthDate : this.prevMonthDate, this.activeDate) || !m7(this.activeDate, this.min, this.max);
    return html`<calcite-action alignment=center .ariaDisabled=${a} .ariaLabel=${t2 ? this.messages.nextMonth : this.messages.prevMonth} class=${safeClassMap(s3.chevron)} compact data-direction=${e2 ?? nothing} .disabled=${a} .icon=${t2 ? M2.chevronRight : M2.chevronLeft} icon-flip-rtl @click=${t2 ? this.nextMonthClick : this.prevMonthClick} @keydown=${t2 ? this.nextMonthKeydown : this.prevMonthKeydown} role=button .scale=${this.scale === "l" ? "l" : "m"} .text=${t2 ? this.messages.nextMonth : this.messages.prevMonth} ${ref((n3) => t2 ? this.nextMonthAction = n3 : this.prevMonthAction = n3)}></calcite-action>`;
  }
};
S("calcite-date-picker-month-header", H2);

// node_modules/@esri/calcite-components/dist/components/calcite-date-picker-month/customElement.js
var D2 = {
  calendar: "calendar",
  calendarContainer: "calendar-container",
  calendarStart: "calendar--start",
  currentDay: "current-day",
  dayContainer: "day-container",
  insideRangeHover: "inside-range--hover",
  month: "month",
  noncurrent: "noncurrent",
  outsideRangeHover: "outside-range--hover",
  weekDays: "week-days",
  weekHeader: "week-header",
  weekHeaderContainer: "week-header-container"
};
var E2 = css`:host([hidden]){display:none}[hidden]{display:none}.calendar-container{display:flex;inline-size:100%}:host([range][layout=vertical]) .calendar-container{flex-direction:column}.calendar{inline-size:100%}.week-header-container{display:flex;block-size:16px;padding-inline:var(--calcite-spacing-sm);padding-block:var(--calcite-spacing-md)}.week-header{display:flex;align-items:center;justify-content:center;text-align:center;font-size:var(--calcite-font-size--2);line-height:1rem;font-weight:var(--calcite-font-weight-bold);inline-size:14.2857142857%;color:var(--calcite-date-picker-week-header-text-color, var(--calcite-color-text-3))}.day-container{display:flex;inline-size:100%;min-inline-size:0px;justify-content:center}.day-container calcite-date-picker-day{inline-size:100%}.week-days{display:grid;grid-template-columns:repeat(7,1fr);grid-auto-rows:1fr;padding-inline:var(--calcite-spacing-sm);padding-block-end:var(--calcite-spacing-sm)}.month-header{display:flex;inline-size:100%;justify-content:space-between}.month{display:flex;inline-size:100%;flex-direction:column;justify-content:space-between}.day{font-size:var(--calcite-font-size)}:host([scale=s]) .week-days{padding-inline:var(--calcite-spacing-xs);padding-block-end:var(--calcite-spacing-xs)}:host([scale=s]) .week-header-container{padding-inline:var(--calcite-spacing-xs);padding-block:var(--calcite-spacing-sm)}:host([scale=s]) .day{font-size:var(--calcite-font-size-sm)}:host([scale=l]) .week-header{font-size:var(--calcite-font-size--1);line-height:1rem}:host([scale=l]) .week-days{padding-inline:var(--calcite-spacing-md);padding-block-end:var(--calcite-spacing-md)}:host([scale=l]) .week-header-container{padding-inline:var(--calcite-spacing-md);padding-block:var(--calcite-spacing-md-plus)}:host([scale=l]) .day{font-size:var(--calcite-font-size-md)}.calendar--start{border-width:0px;border-style:solid;border-color:var(--calcite-date-picker-range-calendar-divider-color, var(--calcite-color-border-1))}:host([range][layout=horizontal]) .calendar--start{border-inline-end-width:var(--calcite-border-width-sm)}:host([range][layout=vertical]) .calendar--start{border-block-end-width:var(--calcite-border-width-sm)}.noncurrent{pointer-events:none;opacity:0}`;
var m8 = 7;
var k3 = 6;
var z = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.activeDate = /* @__PURE__ */ new Date(), this.range = false, this.calciteInternalDatePickerDayHover = createEvent({ cancelable: false }), this.calciteInternalDatePickerDaySelect = createEvent({ cancelable: false }), this.calciteInternalDatePickerMonthActiveDateChange = createEvent({ cancelable: false }), this.calciteInternalDatePickerMonthChange = createEvent({ cancelable: false }), this.calciteInternalDatePickerMonthMouseOut = createEvent({ cancelable: false }), this.listen("pointerout", this.pointerOutHandler), this.listen("focusout", this.disableActiveFocus);
  }
  static {
    this.properties = { focusedDate: 16, activeDate: 0, dateTimeFormat: 0, endDate: 0, headingLevel: 11, hoverRange: 0, layout: 3, localeData: 0, max: 0, messages: 0, min: 0, monthStyle: 1, range: 7, scale: 3, selectedDate: 0, startDate: 0 };
  }
  static {
    this.styles = E2;
  }
  load() {
    this.focusedDate = this.selectedDate || this.activeDate;
  }
  willUpdate(e2) {
    e2.has("activeDate") && this.updateFocusedDateWithActive(this.activeDate), e2.has("selectedDate") && (this.focusedDate = this.selectedDate);
  }
  // #endregion
  // #region Private Methods
  updateFocusedDateWithActive(e2) {
    this.selectedDate || (this.focusedDate = m7(e2, this.min, this.max) ? e2 : p3(e2, this.min, this.max));
  }
  keyDownHandler(e2) {
    if (e2.defaultPrevented)
      return;
    const a = this.el.dir === "rtl", t2 = e2.target.value;
    switch (e2.key) {
      case "ArrowUp":
        e2.preventDefault(), this.addDays(-7, t2);
        break;
      case "ArrowRight":
        e2.preventDefault(), this.addDays(a ? -1 : 1, t2);
        break;
      case "ArrowDown":
        e2.preventDefault(), this.addDays(7, t2);
        break;
      case "ArrowLeft":
        e2.preventDefault(), this.addDays(a ? 1 : -1, t2);
        break;
      case "PageUp":
        e2.preventDefault(), this.addMonths(-1, t2);
        break;
      case "PageDown":
        e2.preventDefault(), this.addMonths(1, t2);
        break;
      case "Home":
        e2.preventDefault(), this.activeDate.setDate(1), this.addDays(0, t2);
        break;
      case "End":
        e2.preventDefault(), this.activeDate.setDate(new Date(this.activeDate.getFullYear(), this.activeDate.getMonth() + 1, 0).getDate()), this.addDays(0, t2);
        break;
      case "Enter":
      case " ":
        e2.preventDefault();
        break;
      case "Tab":
        this.activeFocus = false;
    }
  }
  /**
   * Once user is not interacting via keyboard,
   * disable auto focusing of active date
   */
  disableActiveFocus() {
    this.activeFocus = false;
  }
  pointerOutHandler() {
    this.calciteInternalDatePickerMonthMouseOut.emit();
  }
  /**
   * Add n months to the current month
   *
   * @param step
   * @param targetDate
   */
  addMonths(e2, a) {
    const t2 = new Date(a);
    t2.setMonth(a.getMonth() + e2), this.calciteInternalDatePickerMonthActiveDateChange.emit(p3(t2, this.min, this.max)), this.focusedDate = p3(t2, this.min, this.max), this.activeFocus = true, this.calciteInternalDatePickerDayHover.emit(t2);
  }
  /**
   * Add n days to the current date
   *
   * @param step
   * @param targetDate
   */
  addDays(e2 = 0, a) {
    const t2 = new Date(a);
    t2.setDate(a.getDate() + e2), this.calciteInternalDatePickerMonthActiveDateChange.emit(p3(t2, this.min, this.max)), this.focusedDate = p3(t2, this.min, this.max), this.activeFocus = true, this.calciteInternalDatePickerDayHover.emit(t2);
  }
  /**
   * Get dates for last days of the previous month
   *
   * @param month
   * @param year
   * @param startOfWeek
   */
  getPreviousMonthDays(e2, a, t2) {
    const s4 = new Date(a, e2, 0), i2 = s4.getDate(), n3 = s4.getDay(), r = [];
    if (n3 === (t2 + k3) % m8)
      return r;
    if (n3 === t2)
      return [i2];
    for (let c = (m8 + n3 - t2) % m8; c >= 0; c--)
      r.push(i2 - c);
    return r;
  }
  /**
   * Get dates for the current month
   *
   * @param month
   * @param year
   */
  getCurrentMonthDays(e2, a) {
    const t2 = new Date(a, e2 + 1, 0).getDate(), s4 = [];
    for (let i2 = 0; i2 < t2; i2++)
      s4.push(i2 + 1);
    return s4;
  }
  /**
   * Get dates for first days of the next month
   *
   * @param month
   * @param year
   * @param startOfWeek
   */
  getNextMonthDays(e2, a, t2) {
    const s4 = new Date(a, e2 + 1, 0).getDay(), i2 = [];
    if (s4 === (t2 + k3) % m8)
      return i2;
    for (let n3 = 0; n3 < (k3 - (s4 - t2)) % m8; n3++)
      i2.push(n3 + 1);
    return i2;
  }
  /**
   * Determine if the date is in between the start and end dates
   *
   * @param date
   */
  betweenSelectedRange(e2) {
    return !!(this.startDate && this.endDate && e2 > this.startDate && e2 < this.endDate && !this.isRangeHover(e2));
  }
  /**
   * Determine if the date should be in selected state
   *
   * @param date
   */
  isSelected(e2) {
    return !!(v2(e2, this.selectedDate) || this.startDate && v2(e2, this.startDate) || this.endDate && v2(e2, this.endDate));
  }
  /**
   * Determine if the date is the start of the date range
   *
   * @param date
   */
  isStartOfRange(e2) {
    return !!(this.startDate && !v2(this.startDate, this.endDate) && v2(this.startDate, e2) && !this.isEndOfRange(e2));
  }
  isEndOfRange(e2) {
    return !!(this.endDate && !v2(this.startDate, this.endDate) && v2(this.endDate, e2) || !this.endDate && this.hoverRange && v2(this.startDate, this.hoverRange.end) && v2(e2, this.hoverRange.end));
  }
  dayHover(e2) {
    const a = e2.target;
    a.disabled ? this.calciteInternalDatePickerMonthMouseOut.emit() : this.calciteInternalDatePickerDayHover.emit(a.value), e2.stopPropagation();
  }
  daySelect(e2) {
    const a = e2.target;
    this.activeFocus = false, this.calciteInternalDatePickerDaySelect.emit(a.value), e2.stopPropagation();
  }
  isFocusedOnStart() {
    return this.hoverRange?.focused === "start";
  }
  isHoverInRange() {
    if (!this.hoverRange || !this.startDate)
      return false;
    const { start: e2, end: a } = this.hoverRange, t2 = this.isFocusedOnStart(), s4 = this.startDate && a > this.startDate, i2 = this.endDate && a < this.endDate, n3 = this.startDate && e2 > this.startDate, r = this.endDate && e2 < this.endDate, c = !t2 && this.startDate && s4 && (!this.endDate || i2), h = t2 && this.startDate && n3 && r;
    return c || h;
  }
  isRangeHover(e2) {
    if (!this.hoverRange)
      return false;
    const { start: a, end: t2 } = this.hoverRange, s4 = this.isFocusedOnStart(), i2 = this.isHoverInRange(), n3 = e2 > a && e2 < this.startDate, r = e2 < t2 && e2 > this.endDate, c = e2 > t2 && e2 < this.endDate, h = e2 < a && e2 > this.startDate, g = e2 < t2 && e2 > this.startDate, d = e2 > a && e2 < this.endDate, l2 = this.startDate && this.endDate;
    if (i2) {
      if (l2)
        return s4 ? e2 < this.endDate && (h || n3) : c || r;
      if (this.startDate && !this.endDate)
        return s4 ? n3 : g;
      if (!this.startDate && this.endDate)
        return s4 ? d : r;
    } else if (l2)
      return s4 ? n3 : r;
  }
  getDays(e2, a, t2, s4 = "start") {
    let i2 = this.activeDate.getMonth();
    const n3 = i2 + 1;
    i2 = s4 === "end" ? n3 : i2;
    let r = 0;
    const c = () => r++ % 7, h = this.activeDate.getFullYear();
    return [
      ...e2.map((d) => ({
        active: false,
        day: d,
        dayInWeek: c(),
        date: new Date(h, i2 - 1, d)
      })),
      ...a.map((d) => {
        const l2 = new Date(h, i2, d), p4 = v2(l2, /* @__PURE__ */ new Date());
        return {
          active: this.focusedDate && this.focusedDate !== this.startDate && this.focusedDate !== this.endDate ? v2(l2, this.focusedDate) : v2(l2, this.startDate) || v2(l2, this.endDate),
          currentMonth: true,
          currentDay: p4,
          day: d,
          dayInWeek: c(),
          date: l2,
          ref: true
        };
      }),
      ...t2.map((d) => ({
        active: false,
        day: d,
        dayInWeek: c(),
        date: new Date(h, n3, d)
      }))
    ];
  }
  monthHeaderSelectChange(e2) {
    const a = new Date(e2.detail), t2 = e2.target;
    this.updateFocusableDate(a), e2.stopPropagation(), this.calciteInternalDatePickerMonthChange.emit({ date: a, position: t2.position });
  }
  updateFocusableDate(e2) {
    !this.selectedDate || !this.range ? this.focusedDate = this.getFirstValidDateOfMonth(e2) : this.selectedDate && this.range && (!_(this.startDate, e2) || !_(this.endDate, e2)) && (this.focusedDate = this.getFirstValidDateOfMonth(e2));
  }
  getFirstValidDateOfMonth(e2) {
    return e2.getDate() === 1 ? e2 : L(e2, this.min, this.max);
  }
  // #endregion
  // #region Rendering
  render() {
    const e2 = this.activeDate.getMonth(), a = this.activeDate.getFullYear(), t2 = this.localeData.weekStart % 7, { abbreviated: s4, short: i2, narrow: n3 } = this.localeData.days, r = this.scale === "s" ? n3 || i2 || s4 : i2 || s4 || n3, c = [...r.slice(t2, 7), ...r.slice(0, t2)], h = this.getCurrentMonthDays(e2, a), g = this.getPreviousMonthDays(e2, a, t2), d = this.getNextMonthDays(e2, a, t2), l2 = e2 + 1, p4 = this.getPreviousMonthDays(l2, a, t2), w3 = this.getCurrentMonthDays(l2, a), b2 = this.getNextMonthDays(l2, a, t2), $3 = this.getDays(g, h, d), x3 = this.getDays(p4, w3, b2, "end");
    return html`<div class=${safeClassMap({ [D2.calendarContainer]: true })} role=grid>${this.renderCalendar(c, $3)}${this.range && this.renderCalendar(c, x3, true) || ""}</div>`;
  }
  /**
   * Render calcite-date-picker-day
   *
   * @param active.active
   * @param active
   * @param day
   * @param dayInWeek
   * @param date
   * @param currentMonth
   * @param ref
   * @param active.currentMonth
   * @param active.date
   * @param active.day
   * @param active.dayInWeek
   * @param active.ref
   * @param key
   * @param active.currentDay
   */
  renderDateDay({ active: e2, currentMonth: a, currentDay: t2, date: s4, day: i2, dayInWeek: n3, ref: r }, c) {
    const h = m7(s4, this.min, this.max);
    return keyed(c, html`<div class=${safeClassMap({ [D2.dayContainer]: true })} role=gridcell><calcite-date-picker-day .active=${e2} class=${safeClassMap({
      [D2.currentDay]: t2,
      [D2.insideRangeHover]: this.isHoverInRange(),
      [D2.outsideRangeHover]: !this.isHoverInRange(),
      [D2.noncurrent]: this.range && !a
    })} .currentMonth=${a} .dateTimeFormat=${this.dateTimeFormat} .day=${i2} .disabled=${!h} .endOfRange=${this.isEndOfRange(s4)} .highlighted=${this.betweenSelectedRange(s4)} @calciteInternalDayHover=${this.dayHover} @calciteInternalDaySelect=${this.daySelect} .range=${!!this.startDate && !!this.endDate && !v2(this.startDate, this.endDate)} .rangeEdge=${n3 === 0 ? "start" : n3 === 6 ? "end" : void 0} .rangeHover=${h && this.isRangeHover(s4)} .scale=${this.scale} .selected=${this.isSelected(s4)} .startOfRange=${this.isStartOfRange(s4)} .value=${s4} ${ref((g) => {
      r && e2 && this.activeFocus && g?.setFocus();
    })}></calcite-date-picker-day></div>`);
  }
  renderCalendar(e2, a, t2 = false) {
    return html`<div class=${safeClassMap({
      [D2.calendar]: true,
      [D2.calendarStart]: !t2
    })}><calcite-date-picker-month-header .activeDate=${t2 ? N(this.activeDate) : this.activeDate} data-test-calendar=${t2 ? "end" : "start"} .headingLevel=${this.headingLevel} .localeData=${this.localeData} .max=${this.max} .messages=${this.messages} .min=${this.min} .monthStyle=${this.monthStyle} @calciteInternalDatePickerMonthHeaderSelectChange=${this.monthHeaderSelectChange} .position=${t2 ? "end" : this.range ? "start" : null} .scale=${this.scale} .selectedDate=${this.selectedDate}></calcite-date-picker-month-header>${this.renderMonthCalendar(e2, a, t2)}</div>`;
  }
  renderMonthCalendar(e2, a, t2 = false) {
    return html`<div class=${safeClassMap({ [D2.month]: true })} @keydown=${this.keyDownHandler}><div class=${safeClassMap({ [D2.weekHeaderContainer]: true })} role=row>${e2.map((i2) => html`<span class=${safeClassMap({ [D2.weekHeader]: true })} role=columnheader>${i2}</span>`)}</div><div class=${safeClassMap({ [D2.weekDays]: true })} role=row>${a.map((i2, n3) => this.renderDateDay(i2, t2 ? 50 + n3 : n3))}</div></div>`;
  }
};
S("calcite-date-picker-month", z);

// node_modules/@esri/calcite-components/dist/chunks/utils2.js
var o3 = {};
var n = {};
function l(e2) {
  return __async(this, null, function* () {
    const t2 = O(e2);
    if (o3[t2])
      return o3[t2];
    n[t2] || (n[t2] = fetch(T(`./assets/date-picker/nls/${t2}.json`)).then((r) => r.json()).catch(() => (console.error(`Translations for "${t2}" not found or invalid, falling back to english`), l("en"))));
    const a = yield n[t2];
    return o3[t2] = a, a;
  });
}
function m9(e2) {
  return e2.map((t2, a) => O2(t2, a === 1));
}

// node_modules/@esri/calcite-components/dist/components/calcite-date-picker/customElement.js
var M3 = 2;
var $2 = { dateStyle: "full" };
var P = css`:host{box-sizing:border-box;background-color:var(--calcite-color-foreground-1);color:var(--calcite-color-text-2);font-size:var(--calcite-font-size--1)}:host *{box-sizing:border-box}:host{display:inline-block;inline-size:100%;overflow:visible;border-width:1px;border-style:solid;vertical-align:top;border-color:var(--calcite-date-picker-border-color, var(--calcite-color-border-1));border-radius:var(--calcite-date-picker-corner-radius, 0)}:host([scale=s]){inline-size:236px;min-inline-size:216px;max-inline-size:380px}:host([scale=s][range][layout=horizontal]){inline-size:480px;min-inline-size:432px;max-inline-size:772px}:host([scale=m]){inline-size:298px;min-inline-size:272px;max-inline-size:480px}:host([scale=m][range][layout=horizontal]){inline-size:608px;min-inline-size:544px;max-inline-size:972px}:host([scale=l]){inline-size:334px;min-inline-size:320px;max-inline-size:600px}:host([scale=l][range][layout=horizontal]){inline-size:684px;min-inline-size:640px;max-inline-size:1212px}:host([hidden]){display:none}[hidden]{display:none}`;
var w2 = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.rangeValueChangedByUser = false, this.layout = "horizontal", this.messages = s({ blocking: true }), this.monthStyle = "wide", this.proximitySelectionDisabled = false, this.range = false, this.scale = "m", this.calciteDatePickerChange = createEvent({ cancelable: false }), this.calciteDatePickerRangeChange = createEvent({ cancelable: false }), this.listen("keydown", this.keyDownHandler);
  }
  static {
    this.properties = { activeEndDate: 16, activeStartDate: 16, dateTimeFormat: 16, endAsDate: 16, hoverRange: 16, localeData: 16, startAsDate: 16, activeDate: 0, activeRange: 3, headingLevel: 11, layout: 3, max: 3, maxAsDate: 0, messageOverrides: 0, min: 3, minAsDate: 0, monthStyle: 1, numberingSystem: 3, proximitySelectionDisabled: 7, range: 7, scale: 3, value: 1, valueAsDate: 0 };
  }
  static {
    this.shadowRootOptions = { mode: "open", delegatesFocus: true };
  }
  static {
    this.styles = P;
  }
  // #endregion
  // #region Public Methods
  /**
   * Resets active date state.
   *
   * @private
   */
  reset() {
    return __async(this, null, function* () {
      this.resetActiveDates(), this.rangeValueChangedByUser = false;
    });
  }
  /** Sets focus on the component's first focusable element. */
  setFocus() {
    return __async(this, null, function* () {
      yield m4(this), mt(this.el);
    });
  }
  connectedCallback() {
    super.connectedCallback(), Array.isArray(this.value) ? this.valueAsDate = m9(this.value) : this.value && (this.valueAsDate = O2(this.value)), this.min && (this.minAsDate = O2(this.min)), this.max && (this.maxAsDate = O2(this.max)), this.setActiveStartAndEndDates();
  }
  load() {
    return __async(this, null, function* () {
      yield this.loadLocaleData(), this.onMinChanged(this.min), this.onMaxChanged(this.max);
    });
  }
  willUpdate(t2) {
    t2.has("activeDate") && this.activeDateWatcher(this.activeDate), t2.has("value") && this.valueHandler(this.value), t2.has("valueAsDate") && this.valueAsDateWatcher(this.valueAsDate), t2.has("min") && this.onMinChanged(this.min), t2.has("max") && this.onMaxChanged(this.max), t2.has("messages") && this.hasUpdated && this.loadLocaleData().catch(console.error);
  }
  // #endregion
  // #region Private Methods
  activeDateWatcher(t2) {
    this.range && (this.rangeValueChangedByUser || (t2 ? (this.activeStartDate = t2, this.activeEndDate = N(this.activeStartDate)) : this.resetActiveDates()));
  }
  valueHandler(t2) {
    Array.isArray(t2) ? (this.valueAsDate = m9(t2), this.rangeValueChangedByUser || this.resetActiveDates()) : t2 && (this.valueAsDate = O2(t2));
  }
  valueAsDateWatcher(t2) {
    this.range && Array.isArray(t2) && !this.rangeValueChangedByUser ? this.setActiveStartAndEndDates() : t2 && t2 !== this.activeDate && (this.activeDate = t2);
  }
  onMinChanged(t2) {
    this.minAsDate = O2(t2), this.range && this.setActiveStartAndEndDates();
  }
  onMaxChanged(t2) {
    this.maxAsDate = O2(t2), this.range && this.setActiveStartAndEndDates();
  }
  keyDownHandler(t2) {
    t2.key === "Escape" && this.resetActiveDates();
  }
  loadLocaleData() {
    return __async(this, null, function* () {
      m() && (q.numberFormatOptions = {
        numberingSystem: this.numberingSystem,
        locale: this.messages._lang,
        useGrouping: false
      }, this.localeData = yield l(this.messages._lang), this.dateTimeFormat = Q(this.messages._lang, $2));
    });
  }
  monthHeaderSelectChange(t2) {
    const e2 = new Date(t2.detail.date), a = t2.detail.position;
    this.range ? a === "end" ? (this.activeEndDate = e2, this.activeStartDate = A(e2)) : (this.activeStartDate = e2, this.activeEndDate = N(e2)) : this.activeDate = e2, t2.stopPropagation();
  }
  monthActiveDateChange(t2) {
    const e2 = new Date(t2.detail);
    if (!this.range)
      this.activeDate = e2;
    else {
      const a = e2.getMonth(), i2 = a !== this.activeStartDate.getMonth() && a !== N(this.activeStartDate).getMonth();
      this.activeRange === "end" ? (!this.activeEndDate || this.activeStartDate && i2) && (this.activeEndDate = e2, this.activeStartDate = A(e2)) : (this.activeStartDate && i2 || !this.activeStartDate) && (this.activeStartDate = e2, this.activeEndDate = N(e2));
    }
    t2.stopPropagation();
  }
  monthHoverChange(t2) {
    if (!this.range) {
      this.hoverRange = void 0;
      return;
    }
    const { valueAsDate: e2 } = this, a = Array.isArray(e2) && e2[0], i2 = Array.isArray(e2) && e2[1], s4 = new Date(t2.detail);
    if (this.hoverRange = {
      focused: this.activeRange || "start",
      start: a,
      end: i2
    }, this.proximitySelectionDisabled)
      i2 && a || !i2 && s4 >= a ? (this.hoverRange.focused = "end", this.hoverRange.end = s4) : !i2 && s4 < a ? this.hoverRange = {
        focused: "start",
        start: s4,
        end: a
      } : this.hoverRange = void 0;
    else if (this.activeRange)
      this.activeRange === "end" ? (this.hoverRange.end = s4, this.hoverRange.focused = "end") : (this.hoverRange.start = s4, this.hoverRange.focused = "start");
    else if (a && i2) {
      const c = Math.abs(R(s4, a)), l2 = Math.abs(R(s4, i2));
      s4 > i2 ? (this.hoverRange.end = s4, this.hoverRange.focused = "end") : s4 < a ? (this.hoverRange.start = s4, this.hoverRange.focused = "start") : s4 > a && s4 < i2 && (c < l2 ? (this.hoverRange.start = s4, this.hoverRange.focused = "start") : (this.hoverRange.end = s4, this.hoverRange.focused = "end"));
    } else
      a && (s4 < a ? this.hoverRange = {
        focused: "start",
        start: s4,
        end: a
      } : (this.hoverRange.end = s4, this.hoverRange.focused = "end"));
    t2.stopPropagation();
  }
  monthMouseOutChange(t2) {
    this.hoverRange && (this.hoverRange = void 0), t2.stopPropagation();
  }
  resetActiveDates() {
    const { valueAsDate: t2 } = this;
    !Array.isArray(t2) && t2 && t2 !== this.activeDate && (this.activeDate = new Date(t2)), Array.isArray(t2) && (t2[0] && t2[0] !== this.activeStartDate && (this.activeStartDate = new Date(t2[0])), t2[1] && t2[1] !== this.activeEndDate && (this.activeEndDate = new Date(t2[1]))), this.hoverRange = void 0;
  }
  getEndDate() {
    return Array.isArray(this.valueAsDate) && this.valueAsDate[1] || void 0;
  }
  setEndDate(t2) {
    const e2 = this.getStartDate();
    this.rangeValueChangedByUser = true, this.value = [x2(e2), x2(t2)], this.valueAsDate = [e2, t2], t2 && this.calciteDatePickerRangeChange.emit();
  }
  getStartDate() {
    return Array.isArray(this.valueAsDate) && this.valueAsDate[0];
  }
  setStartDate(t2) {
    const e2 = this.getEndDate();
    this.rangeValueChangedByUser = true, this.value = [x2(t2), x2(e2)], this.valueAsDate = [t2, e2], this.calciteDatePickerRangeChange.emit();
  }
  /**
   * Event handler for when the selected date changes
   *
   * @param event
   */
  monthDateChange(t2) {
    const e2 = new Date(t2.detail), a = x2(e2);
    if (!this.range && a === x2(this.valueAsDate))
      return;
    if (!this.range) {
      this.value = a || "", this.valueAsDate = e2 || null, this.activeDate = e2 || null, this.calciteDatePickerChange.emit();
      return;
    }
    const i2 = this.getStartDate(), s4 = this.getEndDate();
    if (!i2 || !s4 && e2 < i2)
      i2 && this.setEndDate(new Date(i2)), this.activeRange == "end" ? this.setEndDate(e2) : this.setStartDate(e2);
    else if (!s4)
      this.setEndDate(e2);
    else if (this.proximitySelectionDisabled)
      this.setStartDate(e2), this.setEndDate(null);
    else if (this.activeRange)
      this.activeRange == "end" ? this.setEndDate(e2) : (e2 > s4 && (this.setEndDate(null), this.activeEndDate = null), this.setStartDate(e2));
    else {
      const c = R(e2, i2), l2 = R(e2, s4);
      l2 === 0 || c < 0 ? this.setStartDate(e2) : c === 0 || l2 < 0 ? this.setEndDate(e2) : c < l2 ? this.setStartDate(e2) : this.setEndDate(e2);
    }
    t2.stopPropagation(), this.calciteDatePickerChange.emit();
  }
  /**
   * Get an active date using the value, or current date as default
   *
   * @param value
   * @param min
   * @param max
   */
  getActiveDate(t2, e2, a) {
    const i2 = p3(/* @__PURE__ */ new Date(), e2, a);
    return p3(this.activeDate, e2, a) || t2 || (v2(a, i2) && !this.range ? L(i2, e2, a) : i2);
  }
  getActiveEndDate(t2, e2, a) {
    return p3(this.activeEndDate, e2, a) || t2 || p3(N(/* @__PURE__ */ new Date()), e2, a);
  }
  setActiveStartAndEndDates() {
    if (this.range) {
      const t2 = p3(Array.isArray(this.valueAsDate) ? this.valueAsDate[0] : this.valueAsDate, this.minAsDate, this.maxAsDate), e2 = p3(Array.isArray(this.valueAsDate) ? this.valueAsDate[1] : null, this.minAsDate, this.maxAsDate);
      if (this.activeStartDate = this.getActiveDate(t2, this.minAsDate, this.maxAsDate), this.activeEndDate = this.getActiveEndDate(e2, this.minAsDate, this.maxAsDate), v2(this.activeStartDate, this.activeEndDate)) {
        const a = L(A(this.activeEndDate), this.minAsDate, this.maxAsDate), i2 = N(this.activeEndDate);
        m7(a, this.minAsDate, this.maxAsDate) ? this.activeStartDate = a : m7(i2, this.minAsDate, this.maxAsDate) && (this.activeEndDate = i2);
      }
    }
  }
  // #endregion
  // #region Rendering
  render() {
    const t2 = p3(this.range && Array.isArray(this.valueAsDate) ? this.valueAsDate[0] : this.valueAsDate, this.minAsDate, this.maxAsDate), e2 = this.getActiveDate(t2, this.minAsDate, this.maxAsDate), a = this.range && Array.isArray(this.valueAsDate) ? p3(this.valueAsDate[1], this.minAsDate, this.maxAsDate) : null, i2 = this.range && this.activeRange ? this.activeRange === "start" ? this.minAsDate : t2 : this.minAsDate, s4 = this.range ? this.activeStartDate : e2;
    return this.renderMonth(s4, this.maxAsDate, i2, t2, a);
  }
  /**
   * Render calcite-date-picker-month-header and calcite-date-picker-month
   *
   * @param activeDate
   * @param maxDate
   * @param minDate
   * @param date
   * @param endDate
   */
  renderMonth(t2, e2, a, i2, s4) {
    return this.localeData && html`<calcite-date-picker-month .activeDate=${t2} .dateTimeFormat=${this.dateTimeFormat} .endDate=${this.range ? s4 : void 0} .headingLevel=${this.headingLevel || M3} .hoverRange=${this.hoverRange} .layout=${this.layout} .localeData=${this.localeData} .max=${e2} .messages=${this.messages} .min=${a} .monthStyle=${this.monthStyle} @calciteInternalDatePickerDayHover=${this.monthHoverChange} @calciteInternalDatePickerDaySelect=${this.monthDateChange} @calciteInternalDatePickerMonthActiveDateChange=${this.monthActiveDateChange} @calciteInternalDatePickerMonthChange=${this.monthHeaderSelectChange} @calciteInternalDatePickerMonthMouseOut=${this.monthMouseOutChange} .range=${this.range} .scale=${this.scale} .selectedDate=${this.activeRange === "end" ? s4 : i2} .startDate=${this.range ? i2 : void 0}></calcite-date-picker-month>` || "";
  }
};
S("calcite-date-picker", w2);

// node_modules/@esri/calcite-components/dist/components/calcite-input-date-picker/customElement.js
var rt2 = css`:host{--calcite-icon-size: 1rem;--calcite-spacing-eighth: .125rem;--calcite-spacing-quarter: .25rem;--calcite-spacing-half: .5rem;--calcite-spacing-three-quarters: .75rem;--calcite-spacing: 1rem;--calcite-spacing-plus-quarter: 1.25rem;--calcite-spacing-plus-half: 1.5rem;--calcite-spacing-double: 2rem;--calcite-menu-min-width: 10rem;--calcite-header-min-height: 3rem;--calcite-footer-min-height: 3rem}:host([disabled]){cursor:default;-webkit-user-select:none;user-select:none;opacity:var(--calcite-opacity-disabled)}:host([disabled]) *,:host([disabled]) ::slotted(*){pointer-events:none}:host{position:relative;display:inline-block;width:100%;overflow:visible;vertical-align:top;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}:host .menu-container .calcite-floating-ui-anim{position:relative;transition:var(--calcite-floating-ui-transition);transition-property:inset,left,opacity;opacity:0;box-shadow:0 0 16px #00000029;z-index:var(--calcite-z-index);border-radius:.25rem}:host .menu-container[data-placement^=bottom] .calcite-floating-ui-anim{inset-block-start:-5px}:host .menu-container[data-placement^=top] .calcite-floating-ui-anim{inset-block-start:5px}:host .menu-container[data-placement^=left] .calcite-floating-ui-anim{left:5px}:host .menu-container[data-placement^=right] .calcite-floating-ui-anim{left:-5px}:host .menu-container[data-placement] .calcite-floating-ui-anim--active{opacity:1;inset-block-start:0;left:0}:host([scale=s]){--calcite-toggle-spacing: .5rem;--calcite-internal-input-text-input-padding-inline-end: calc(var(--calcite-toggle-spacing) + 1rem)}:host([scale=m]){--calcite-toggle-spacing: .75rem;--calcite-internal-input-text-input-padding-inline-end: calc(var(--calcite-toggle-spacing) + 1.5rem)}:host([scale=l]){--calcite-toggle-spacing: 1rem;--calcite-internal-input-text-input-padding-inline-end: calc(var(--calcite-toggle-spacing) + 2rem)}:host([disabled]) ::slotted([calcite-hydrated][disabled]),:host([disabled]) [calcite-hydrated][disabled]{opacity:1}.interaction-container{display:contents}.calendar-wrapper{--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow);transform:translateZ(0)}.input-wrapper{position:relative}.input-wrapper .chevron-icon{color:var(--calcite-color-text-3)}.input-wrapper:focus-within .chevron-icon,.input-wrapper:active .chevron-icon,.input-wrapper:hover .chevron-icon{color:var(--calcite-color-text-1)}.input-wrapper:focus-within~.input-wrapper .chevron-icon,.input-wrapper:active~.input-wrapper .chevron-icon,.input-wrapper:hover~.input-wrapper .chevron-icon{color:var(--calcite-color-text-1)}.toggle-icon{position:absolute;display:flex;cursor:pointer;align-items:center;inset-inline-end:0;inset-block:0;padding-inline:var(--calcite-toggle-spacing)}:host([range]) .container{display:flex}:host([range]) .input-container{display:flex;flex:1 1 auto}:host([range]) .input-wrapper{flex:1 1 auto}.divider-container{display:flex;align-items:stretch;border-width:1px;border-left-width:0px;border-right-width:0px;border-style:solid;border-color:var(--calcite-color-border-input);background-color:var(--calcite-color-foreground-1)}:host([layout=horizontal]) .divider-container{width:1px}.divider{display:inline-block;width:1px;margin-block:var(--calcite-spacing-xxs);background-color:var(--calcite-color-border-2)}:host([layout=vertical]) .divider-container{height:1px;width:100%;border-top-width:0px;border-bottom-width:0px;border-left-width:1px;border-right-width:0px;padding-inline:var(--calcite-spacing-md)}:host([layout=vertical]) .divider-container .divider{margin-top:0;margin-bottom:0;height:1px;width:100%}:host([range][layout=vertical]) .input-wrapper{width:100%}:host([range][layout=vertical]) .input-container{flex-direction:column;align-items:flex-start}.menu-container{--calcite-floating-ui-z-index: var(--calcite-z-index-dropdown);inline-size:max-content;display:none;max-inline-size:100vw;max-block-size:100vh;inset-block-start:0;left:0;z-index:var(--calcite-floating-ui-z-index)}.menu-container .calcite-floating-ui-anim{position:relative;transition:var(--calcite-floating-ui-transition);transition-property:inset,left,opacity;opacity:0;box-shadow:0 0 16px #00000029;z-index:var(--calcite-z-index);border-radius:.25rem}.menu-container[data-placement^=bottom] .calcite-floating-ui-anim{inset-block-start:-5px}.menu-container[data-placement^=top] .calcite-floating-ui-anim{inset-block-start:5px}.menu-container[data-placement^=left] .calcite-floating-ui-anim{left:5px}.menu-container[data-placement^=right] .calcite-floating-ui-anim{left:-5px}.menu-container[data-placement] .calcite-floating-ui-anim--active{opacity:1;inset-block-start:0;left:0}.input .calcite-input__wrapper{margin-top:0}.vertical-chevron-container{display:flex;align-items:center;border-width:1px;border-left-width:0px;border-style:solid;border-color:var(--calcite-color-border-input);padding-inline:var(--calcite-spacing-md);background-color:var(--calcite-color-foreground-1)}.vertical-chevron-container calcite-icon{color:var(--calcite-color-text-3)}.vertical-chevron-container calcite-icon:hover{color:var(--calcite-color-text-1)}:host([range][layout=vertical][scale=s]) .vertical-chevron-container,:host([range][layout=vertical][scale=s]) .divider-container{padding-inline:var(--calcite-spacing-sm)}:host([range][layout=vertical][scale=l]) .vertical-chevron-container,:host([range][layout=vertical][scale=l]) .divider-container{padding-inline:var(--calcite-spacing-lg)}.container:focus-within .vertical-chevron-container calcite-icon,.container:active .vertical-chevron-container calcite-icon,.container:hover .vertical-chevron-container calcite-icon{color:var(--calcite-color-text-1)}.validation-container{display:flex;flex-direction:column;align-items:flex-start;align-self:stretch}:host([scale=m]) .validation-container,:host([scale=l]) .validation-container{padding-block-start:.5rem}:host([scale=s]) .validation-container{padding-block-start:.25rem}::slotted(input[slot=hidden-form-input]){margin:0!important;opacity:0!important;outline:none!important;padding:0!important;position:absolute!important;inset:0!important;transform:none!important;-webkit-appearance:none!important;z-index:-1!important}.assistive-text{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}:host([hidden]){display:none}[hidden]{display:none}`;
var n2 = {
  assistiveText: "assistive-text",
  calendarWrapper: "calendar-wrapper",
  container: "container",
  dividerContainer: "divider-container",
  divider: "divider",
  inputContainer: "input-container",
  inputNoBottomBorder: "input--no-bottom-border",
  inputNoRightBorder: "input--no-right-border",
  inputNoTopBorder: "input--no-top-border",
  inputNoLeftBorder: "input--no-left-border",
  inputWrapper: "input-wrapper",
  input: "input",
  menu: "menu-container",
  toggleIcon: "toggle-icon",
  verticalChevronContainer: "vertical-chevron-container",
  chevronIcon: "chevron-icon"
};
var k4 = {
  validationMessage: "inputDatePickerValidationMessage"
};
function ot2(g) {
  if (!g)
    return false;
  const { year: t2 } = E(g);
  return Number(t2) < 100;
}
function lt2(g) {
  const t2 = (/* @__PURE__ */ new Date()).getFullYear();
  return Math.floor(t2 / 100) * 100 + g;
}
var ct2 = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.commonDateSeparators = [".", "-", "/"], this.dialogId = `date-picker-dialog--${i()}`, this.focusOnOpen = false, this.focusTrap = k({
      triggerProp: "open",
      focusTrapOptions: {
        onActivate: () => {
          this.focusOnOpen && (this.datePickerEl?.setFocus(), this.focusOnOpen = false);
        },
        allowOutsideClick: true,
        // Allow outside click and let the popover manager take care of closing the popover.
        clickOutsideDeactivates: false,
        initialFocus: false,
        setReturnFocus: false,
        onDeactivate: () => {
          this.open = false;
        }
      }
    })(this), this.transitionProp = "opacity", this.placeholderTextId = `calcite-input-date-picker-placeholder-${i()}`, this.rangeStartValueChangedByUser = false, this.userChangedValue = false, this._value = "", this.valueAsDateChangedExternally = false, this.focusedInput = "start", this.disabled = false, this.focusTrapDisabled = false, this.layout = "horizontal", this.messages = s({ blocking: true }), this.monthStyle = "wide", this.open = false, this.overlayPositioning = "absolute", this.placement = ot, this.proximitySelectionDisabled = false, this.range = false, this.readOnly = false, this.required = false, this.scale = "m", this.status = "idle", this.validity = {
      valid: false,
      badInput: false,
      customError: false,
      patternMismatch: false,
      rangeOverflow: false,
      rangeUnderflow: false,
      stepMismatch: false,
      tooLong: false,
      tooShort: false,
      typeMismatch: false,
      valueMissing: false
    }, this.calciteInputDatePickerBeforeClose = createEvent({ cancelable: false }), this.calciteInputDatePickerBeforeOpen = createEvent({ cancelable: false }), this.calciteInputDatePickerChange = createEvent({ cancelable: false }), this.calciteInputDatePickerClose = createEvent({ cancelable: false }), this.calciteInputDatePickerOpen = createEvent({ cancelable: false }), this.listen("blur", this.blurHandler), this.listen("keydown", this.keyDownHandler), this.handleDateTimeFormatChange();
  }
  static {
    this.properties = { datePickerActiveDate: 16, focusedInput: 16, localeData: 16, disabled: 7, flipPlacements: 0, focusTrapDisabled: 7, form: 3, headingLevel: 11, layout: 3, max: 3, maxAsDate: 0, messageOverrides: 0, min: 3, minAsDate: 0, monthStyle: 1, name: 3, numberingSystem: 3, open: 7, overlayPositioning: 3, placement: 3, proximitySelectionDisabled: 5, range: 7, readOnly: 7, required: 7, scale: 3, status: 3, validationIcon: [3, { converter: stringOrBoolean }], validationMessage: 1, validity: 0, value: 1, valueAsDate: 0 };
  }
  static {
    this.shadowRootOptions = { mode: "open", delegatesFocus: true };
  }
  static {
    this.styles = rt2;
  }
  /** Selected date as a string in ISO format (`"yyyy-mm-dd"`). */
  get value() {
    return this._value;
  }
  set value(t2) {
    const e2 = this._value;
    t2 !== e2 && (this._value = t2, this.valueWatcher(t2));
  }
  // #endregion
  // #region Public Methods
  /**
   * Updates the position of the component.
   *
   * @param delayed If true, the repositioning is delayed.
   * @returns void
   */
  reposition(t2 = false) {
    return __async(this, null, function* () {
      const { floatingEl: e2, referenceEl: a, placement: i2, overlayPositioning: s4, filteredFlipPlacements: r } = this;
      return ft(this, {
        floatingEl: e2,
        referenceEl: a,
        overlayPositioning: s4,
        placement: i2,
        flipPlacements: r,
        type: "menu"
      }, t2);
    });
  }
  /** Sets focus on the component. */
  setFocus() {
    return __async(this, null, function* () {
      yield m4(this), mt(this.el);
    });
  }
  connectedCallback() {
    super.connectedCallback();
    const { open: t2 } = this;
    if (t2 && this.openHandler(), this.min && (this.minAsDate = O2(this.min)), this.max && (this.maxAsDate = O2(this.max)), Array.isArray(this.value))
      this.valueAsDate = m9(this.value);
    else if (this.value)
      try {
        const e2 = O2(this.value), a = p3(e2, this.minAsDate, this.maxAsDate);
        this.valueAsDate = a;
      } catch {
        this.warnAboutInvalidValue(this.value), this.value = "";
      }
    else this.valueAsDate && (this.range && Array.isArray(this.valueAsDate) ? this.value = [x2(this.valueAsDate[0]), x2(this.valueAsDate[1])] : !this.range && !Array.isArray(this.valueAsDate) && (this.value = x2(this.valueAsDate)));
    v(this), D(this), this.setFilteredPlacements(), q.numberFormatOptions = {
      numberingSystem: this.numberingSystem,
      locale: this.messages._lang,
      useGrouping: false
    }, ct(this);
  }
  load() {
    return __async(this, null, function* () {
      this.handleDateTimeFormatChange(), yield this.loadLocaleData(), this.onMinChanged(this.min), this.onMaxChanged(this.max);
    });
  }
  willUpdate(t2) {
    t2.has("disabled") && (this.hasUpdated || this.disabled !== false) && this.handleDisabledAndReadOnlyChange(this.disabled), t2.has("readOnly") && (this.hasUpdated || this.readOnly !== false) && this.handleDisabledAndReadOnlyChange(this.readOnly), t2.has("valueAsDate") && this.valueAsDateWatcher(this.valueAsDate), t2.has("flipPlacements") && this.flipPlacementsHandler(), t2.has("min") && this.onMinChanged(this.min), t2.has("max") && this.onMaxChanged(this.max), t2.has("open") && (this.hasUpdated || this.open !== false) && this.openHandler(), t2.has("overlayPositioning") && (this.hasUpdated || this.overlayPositioning !== "absolute") && this.reposition(true), (t2.has("numberingSystem") || t2.has("messages")) && this.handleDateTimeFormatChange(), t2.has("layout") && (this.hasUpdated || this.layout !== "horizontal") && this.setReferenceEl(), t2.has("messages") && this.loadLocaleData();
  }
  updated() {
    m3(this);
  }
  loaded() {
    this.localizeInputValues(), ct(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), T2(this), W(this), Y(this);
  }
  // #endregion
  // #region Private Methods
  handleDisabledAndReadOnlyChange(t2) {
    t2 || (this.open = false);
  }
  valueWatcher(t2) {
    if (!this.userChangedValue) {
      let e2;
      Array.isArray(t2) ? e2 = m9(t2) : t2 ? e2 = O2(t2) : e2 = void 0, !this.valueAsDateChangedExternally && e2 !== this.valueAsDate && (this.valueAsDate = e2), this.localizeInputValues();
    }
    this.userChangedValue = false;
  }
  valueAsDateWatcher(t2) {
    const e2 = Array.isArray(t2) ? [x2(t2[0]), x2(t2[1])] : x2(t2);
    this.datePickerActiveDate = Array.isArray(t2) ? t2[0] : t2, this.value !== e2 && (this.valueAsDateChangedExternally = true, this.value = e2, this.valueAsDateChangedExternally = false);
  }
  flipPlacementsHandler() {
    this.setFilteredPlacements(), this.reposition(true);
  }
  onMinChanged(t2) {
    this.minAsDate = O2(t2);
  }
  onMaxChanged(t2) {
    this.maxAsDate = O2(t2);
  }
  openHandler() {
    s2(this), !(this.disabled || this.readOnly) && this.reposition(true);
  }
  calciteInternalInputInputHandler(t2) {
    const e2 = t2.target, a = e2.value, i2 = this.parseNumerals(a), s4 = this.formatNumerals(i2);
    e2.value = s4;
    const { year: r } = F(a, this.localeData);
    if (r && r.length < 4)
      return;
    const h = w(a, this.localeData);
    m7(h, this.min, this.max) && (this.datePickerActiveDate = h);
  }
  calciteInternalInputBlurHandler() {
    this.commitValue();
  }
  handleDateTimeFormatChange() {
    const t2 = {
      // we explicitly set numberingSystem to prevent the browser-inferred value
      // @see [Arabic numbering system support context](https://github.com/Esri/calcite-design-system/issues/3079#issuecomment-1168964195) for more info.
      numberingSystem: H(this.numberingSystem)
    };
    this.dateTimeFormat = new Intl.DateTimeFormat(X2(this.messages._lang), t2);
  }
  setReferenceEl() {
    const { focusedInput: t2, layout: e2, endWrapper: a, startWrapper: i2 } = this;
    this.referenceEl = t2 === "end" || e2 === "vertical" ? a || i2 : i2 || a, requestAnimationFrame(() => ct(this));
  }
  onInputWrapperPointerDown() {
    this.currentOpenInput = this.focusedInput;
  }
  onInputWrapperClick(t2) {
    const { range: e2, endInput: a, startInput: i2, currentOpenInput: s4 } = this, h = t2.currentTarget.getAttribute("data-position");
    t2.composedPath().find((v3) => v3.classList?.contains(n2.toggleIcon)) && (h === "start" ? i2 : a).setFocus(), (!e2 || !this.open || s4 === h) && (this.open = !this.open);
  }
  setFilteredPlacements() {
    const { el: t2, flipPlacements: e2 } = this;
    this.filteredFlipPlacements = e2 ? lt(e2, t2) : null;
  }
  setTransitionEl(t2) {
    t2 && (this.transitionEl = t2);
  }
  onLabelClick() {
    this.setFocus();
  }
  onBeforeOpen() {
    this.calciteInputDatePickerBeforeOpen.emit();
  }
  onOpen() {
    this.focusTrap.activate(), this.calciteInputDatePickerOpen.emit();
  }
  onBeforeClose() {
    this.calciteInputDatePickerBeforeClose.emit();
  }
  onClose() {
    this.calciteInputDatePickerClose.emit(), X(this), this.focusTrap.deactivate(), this.focusOnOpen = false, this.datePickerEl?.reset();
  }
  syncHiddenFormInput(t2) {
    m6("date", this, t2);
  }
  setStartInput(t2) {
    this.startInput = t2;
  }
  setEndInput(t2) {
    this.endInput = t2;
  }
  blurHandler() {
    this.open = false;
  }
  commitValue() {
    const { focusedInput: t2, value: e2 } = this, a = `${t2}Input`, i2 = this[a].value, s4 = w(i2, this.localeData), r = x2(s4), h = Array.isArray(e2);
    if (this.range) {
      const u = t2 === "start" ? 0 : 1;
      if (h) {
        if (r === e2[u])
          return;
        s4 ? (this.setRangeValue([
          t2 === "start" ? s4 : O2(e2[0]),
          t2 === "end" ? s4 : O2(e2[1])
        ]), this.localizeInputValues()) : this.setRangeValue([
          t2 === "end" && O2(e2[0]),
          t2 === "start" && O2(e2[1])
        ]);
      } else
        s4 && (this.setRangeValue([
          t2 === "start" ? s4 : O2(e2[0]),
          t2 === "end" ? s4 : O2(e2[1])
        ]), this.localizeInputValues());
    } else {
      if (r === e2)
        return;
      this.setValue(s4), this.localizeInputValues();
    }
  }
  keyDownHandler(t2) {
    const { defaultPrevented: e2, key: a } = t2;
    if (e2)
      return;
    const i2 = t2.composedPath().some((s4) => s4.tagName === "CALCITE-SELECT");
    a === "Enter" ? (t2.preventDefault(), this.commitValue(), this.shouldFocusRangeEnd() ? this.endInput?.setFocus() : this.shouldFocusRangeStart() && this.startInput?.setFocus(), $(this) && this.restoreInputFocus(true)) : (a === "ArrowDown" || a === "ArrowUp") && !i2 ? (this.open = true, this.focusOnOpen = true, t2.preventDefault()) : this.open && a === "Escape" && (this.open = false, t2.preventDefault(), this.restoreInputFocus(true));
  }
  startInputFocus() {
    this.focusedInput = "start";
  }
  endInputFocus() {
    this.focusedInput = "end";
  }
  setFloatingEl(t2) {
    this.floatingEl = t2, ct(this);
  }
  setStartWrapper(t2) {
    this.startWrapper = t2, this.setReferenceEl();
  }
  setEndWrapper(t2) {
    this.endWrapper = t2, this.setReferenceEl();
  }
  setDatePickerRef(t2) {
    t2 && (this.datePickerEl = t2, this.focusTrap.overrideFocusTrapEl(t2));
  }
  loadLocaleData() {
    return __async(this, null, function* () {
      m() && (q.numberFormatOptions = {
        numberingSystem: this.numberingSystem,
        locale: this.messages._lang,
        useGrouping: false
      }, this.localeData = yield l(this.messages._lang), this.localizeInputValues());
    });
  }
  /**
   * Event handler for when the selected date changes
   *
   * @param event CalciteDatePicker custom change event
   */
  handleDateChange(t2) {
    this.range || (t2.stopPropagation(), this.setValue(t2.target.valueAsDate), this.localizeInputValues(), this.restoreInputFocus());
  }
  shouldFocusRangeStart() {
    const t2 = this.value[0];
    return !!(this.value[1] && !t2 && this.focusedInput === "end" && this.startInput);
  }
  shouldFocusRangeEnd() {
    const t2 = this.value[0], e2 = this.value[1];
    return !!(t2 && !e2 && this.focusedInput === "start" && this.endInput);
  }
  handleDateRangeChange(t2) {
    if (!this.range)
      return;
    t2.stopPropagation();
    const e2 = t2.target.valueAsDate;
    this.setRangeValue(e2), this.localizeInputValues(), this.restoreInputFocus();
  }
  restoreInputFocus(t2 = false) {
    if (!this.range) {
      this.startInput.setFocus(), this.open = false;
      return;
    }
    if (t2) {
      this.focusInput();
      return;
    }
    this.rangeStartValueChangedByUser = this.focusedInput === "start", this.focusedInput = "end", !(this.shouldFocusRangeStart() || this.rangeStartValueChangedByUser) && (this.open = false, this.focusInput());
  }
  localizeInputValues() {
    const t2 = p3(this.range ? Array.isArray(this.valueAsDate) && this.valueAsDate[0] || void 0 : this.valueAsDate, this.minAsDate, this.maxAsDate), e2 = this.range ? p3(Array.isArray(this.valueAsDate) && this.valueAsDate[1] || void 0, this.minAsDate, this.maxAsDate) : null;
    this.setInputValue((t2 && this.dateTimeFormat.format(t2)) ?? "", "start"), this.setInputValue((this.range && e2 && this.dateTimeFormat.format(e2)) ?? "", "end");
  }
  setInputValue(t2, e2 = "start") {
    const a = this[`${e2}Input`];
    a && (a.value = t2);
  }
  setRangeValue(t2) {
    if (!this.range)
      return;
    const { value: e2 } = this, a = Array.isArray(e2), i2 = Array.isArray(t2), s4 = i2 ? t2[0] : null;
    let r = i2 ? x2(s4) : "";
    r && (r = this.getNormalizedDate(r));
    const h = i2 ? t2[1] : null;
    let u = i2 ? x2(h) : "";
    u && (u = this.getNormalizedDate(u));
    const f2 = r || u ? [r, u] : "";
    if (f2 === e2)
      return;
    this.userChangedValue = true, this.value = f2, this.valueAsDate = f2 ? m9(f2) : void 0;
    const v3 = this.calciteInputDatePickerChange.emit();
    v3 && v3.defaultPrevented && (this.value = e2, a ? (this.setInputValue(e2[0], "start"), this.setInputValue(e2[1], "end")) : (this.value = e2, this.setInputValue(e2)));
  }
  setValue(t2) {
    if (this.range)
      return;
    const e2 = this.value;
    let a = x2(t2);
    if (a = this.getNormalizedDate(a), a === e2)
      return;
    this.userChangedValue = true, this.valueAsDate = a ? O2(a) : void 0, this.value = a || "", this.calciteInputDatePickerChange.emit().defaultPrevented && (this.value = e2, this.setInputValue(e2));
  }
  warnAboutInvalidValue(t2) {
    console.warn(`The specified value "${t2}" does not conform to the required format, "YYYY-MM-DD".`);
  }
  formatNumerals(t2) {
    return t2 ? t2.split("").map((e2) => this.commonDateSeparators?.includes(e2) ? this.localeData?.separator : e?.includes(e2) ? q?.numberFormatter?.format(Number(e2)) : e2).join("") : "";
  }
  parseNumerals(t2) {
    return t2 ? t2.split("").map((e2) => e.includes(e2) ? q.delocalize(e2) : e2).join("") : "";
  }
  getNormalizedDate(t2) {
    if (!t2)
      return "";
    if (!ot2(t2))
      return t2;
    const { day: e2, month: a, year: i2 } = E(t2);
    return `${lt2(Number(i2))}-${a}-${e2}`;
  }
  focusInput() {
    (this.focusedInput === "start" ? this.startInput : this.endInput).setFocus();
  }
  // #endregion
  // #region Rendering
  render() {
    const { disabled: t2, messages: { _lang: e2 }, messages: a, numberingSystem: i2, readOnly: s4 } = this;
    return q.numberFormatOptions = {
      numberingSystem: i2,
      locale: e2,
      useGrouping: false
    }, p({ disabled: this.disabled, children: html`${this.localeData && html`<div class=${safeClassMap(n2.container)}><div class=${safeClassMap(n2.inputContainer)}><div class=${safeClassMap(n2.inputWrapper)} data-position=start @click=${this.onInputWrapperClick} @pointerdown=${this.onInputWrapperPointerDown} ${ref(this.setStartWrapper)}><calcite-input-text aria-controls=${this.dialogId ?? nothing} aria-describedby=${this.placeholderTextId ?? nothing} aria-errormessage=${k4.validationMessage} aria-autocomplete=none .ariaExpanded=${this.open} aria-haspopup=dialog .ariaInvalid=${this.status === "invalid"} class=${safeClassMap({
      [n2.input]: true,
      [n2.inputNoBottomBorder]: this.layout === "vertical" && this.range,
      [n2.inputNoRightBorder]: this.range
    })} .disabled=${t2} icon=calendar @calciteInputTextInput=${this.calciteInternalInputInputHandler} @calciteInternalInputTextBlur=${this.calciteInternalInputBlurHandler} @calciteInternalInputTextFocus=${this.startInputFocus} .placeholder=${this.localeData?.placeholder} .readOnly=${s4} role=combobox .scale=${this.scale} .status=${this.status} ${ref(this.setStartInput)}></calcite-input-text>${!this.readOnly && !this.range && this.renderToggleIcon(this.open && this.focusedInput === "start") || ""}<span aria-hidden=true class=${safeClassMap(n2.assistiveText)} id=${this.placeholderTextId ?? nothing}>${a.dateFormat.replace("{format}", this.localeData?.placeholder)}</span></div><div .ariaHidden=${!this.open} .ariaLabel=${a.chooseDate} aria-live=polite aria-modal=true class=${safeClassMap(n2.menu)} id=${this.dialogId ?? nothing} role=dialog ${ref(this.setFloatingEl)}><div class=${safeClassMap({
      [n2.calendarWrapper]: true,
      [rt.animation]: true,
      [rt.animationActive]: this.open
    })} ${ref(this.setTransitionEl)}><calcite-date-picker .activeDate=${this.datePickerActiveDate} .activeRange=${this.focusedInput} .headingLevel=${this.headingLevel} .layout=${this.layout} .max=${this.max} .maxAsDate=${this.maxAsDate} .messageOverrides=${this.messageOverrides} .min=${this.min} .minAsDate=${this.minAsDate} .monthStyle=${this.monthStyle} .numberingSystem=${i2} @calciteDatePickerChange=${this.handleDateChange} @calciteDatePickerRangeChange=${this.handleDateRangeChange} .proximitySelectionDisabled=${this.proximitySelectionDisabled} .range=${this.range} .scale=${this.scale} tabindex=${(this.open ? void 0 : -1) ?? nothing} .valueAsDate=${this.valueAsDate} ${ref(this.setDatePickerRef)}></calcite-date-picker></div></div>${this.range && html`<div class=${safeClassMap(n2.dividerContainer)}><div class=${safeClassMap(n2.divider)}></div></div>` || ""}${this.range && html`<div class=${safeClassMap(n2.inputWrapper)} data-position=end @click=${this.onInputWrapperClick} @pointerdown=${this.onInputWrapperPointerDown} ${ref(this.setEndWrapper)}><calcite-input-text aria-controls=${this.dialogId ?? nothing} aria-autocomplete=none .ariaExpanded=${this.open} aria-haspopup=dialog class=${safeClassMap({
      [n2.input]: true,
      [n2.inputNoTopBorder]: this.layout === "vertical" && this.range,
      [n2.inputNoLeftBorder]: this.layout === "horizontal" && this.range,
      [n2.inputNoRightBorder]: this.layout === "vertical" && this.range
    })} .disabled=${t2} icon=calendar @calciteInputTextInput=${this.calciteInternalInputInputHandler} @calciteInternalInputTextBlur=${this.calciteInternalInputBlurHandler} @calciteInternalInputTextFocus=${this.endInputFocus} .placeholder=${this.localeData?.placeholder} .readOnly=${s4} role=combobox .scale=${this.scale} .status=${this.status} ${ref(this.setEndInput)}></calcite-input-text>${!this.readOnly && this.layout === "horizontal" && this.renderToggleIcon(this.open) || ""}</div>` || ""}</div>${this.range && this.layout === "vertical" && html`<div class=${safeClassMap(n2.verticalChevronContainer)}><calcite-icon .icon=${this.open ? "chevron-up" : "chevron-down"} .scale=${o(this.scale)}></calcite-icon></div>` || ""}</div>` || ""}${B({ component: this })}${this.validationMessage && this.status === "invalid" ? m5({ icon: this.validationIcon, id: k4.validationMessage, message: this.validationMessage, scale: this.scale, status: this.status }) : null}` });
  }
  renderToggleIcon(t2) {
    return html`<span class=${safeClassMap(n2.toggleIcon)} tabindex=-1><calcite-icon class=${safeClassMap(n2.chevronIcon)} .icon=${t2 ? "chevron-up" : "chevron-down"} .scale=${o(this.scale)}></calcite-icon></span>`;
  }
};
S("calcite-input-date-picker", ct2);
export {
  ct2 as InputDatePicker
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/date.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-date-picker-day/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-date-picker-month-header/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-date-picker-month/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/chunks/utils2.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-date-picker/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-input-date-picker/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=calcite-input-date-picker-SKUVNMAY.js.map
