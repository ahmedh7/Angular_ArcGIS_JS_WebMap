import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/BooleanBindUniform.js
var e = class extends i {
  constructor(r, e2) {
    super(r, "bool", a.Bind, (o, s) => o.setUniform1b(r, e2(s)));
  }
};

export {
  e
};
//# sourceMappingURL=chunk-4B57TS4K.js.map
