import {
  n
} from "./chunk-GGHSCUSN.js";
import {
  b
} from "./chunk-U3H4S3UY.js";
import {
  LitElement2 as LitElement,
  S,
  createEvent,
  css,
  html,
  safeClassMap
} from "./chunk-NMBGL4CC.js";

// node_modules/@esri/calcite-components/dist/components/calcite-dropdown-group/customElement.js
var r = {
  title: "dropdown-title",
  separator: "dropdown-separator"
};
var p = css`:host{display:block}.container{text-align:start}.dropdown-title{margin-block-end:-1px;display:block;cursor:default;overflow-wrap:break-word;border-width:0px;border-block-end-width:1px;border-style:solid;font-weight:var(--calcite-font-weight-bold);border-color:var(--calcite-dropdown-group-border-color, var(--calcite-color-border-3));color:var(--calcite-dropdown-group-title-text-color, var(--calcite-color-text-2))}.dropdown-separator{display:block;block-size:1px;background-color:var(--calcite-dropdown-group-border-color, var(--calcite-color-border-3))}:host([scale=s]){font-size:var(--calcite-font-size--2);line-height:1rem}:host([scale=s]) .dropdown-title{padding:.5rem}:host([scale=m]){font-size:var(--calcite-font-size--1);line-height:1rem}:host([scale=m]) .dropdown-title{padding:.75rem}:host([scale=l]){font-size:var(--calcite-font-size-0);line-height:1.25rem}:host([scale=l]) .dropdown-title{padding:1rem}:host([hidden]){display:none}[hidden]{display:none}`;
var h = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.mutationObserver = b("mutation", () => this.updateItems()), this.position = -1, this.scale = "m", this.selectionMode = "single", this.calciteInternalDropdownItemChange = createEvent({ cancelable: false }), this.listen("calciteInternalDropdownItemSelect", this.updateActiveItemOnChange);
  }
  static {
    this.properties = { groupTitle: 3, position: 9, scale: 3, selectionMode: 3 };
  }
  static {
    this.shadowRootOptions = { mode: "open", delegatesFocus: true };
  }
  static {
    this.styles = p;
  }
  connectedCallback() {
    super.connectedCallback(), this.updateItems(), this.mutationObserver?.observe(this.el, { childList: true });
  }
  willUpdate(e) {
    e.has("selectionMode") && (this.hasUpdated || this.selectionMode !== "single") && this.updateItems();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.mutationObserver?.disconnect();
  }
  // #endregion
  // #region Private Methods
  updateActiveItemOnChange(e) {
    this.requestedDropdownGroup = e.detail.requestedDropdownGroup, this.requestedDropdownItem = e.detail.requestedDropdownItem, this.calciteInternalDropdownItemChange.emit({
      requestedDropdownGroup: this.requestedDropdownGroup,
      requestedDropdownItem: this.requestedDropdownItem
    });
  }
  updateItems() {
    Array.from(this.el.querySelectorAll("calcite-dropdown-item")).forEach((e) => e.selectionMode = this.selectionMode);
  }
  // #endregion
  // #region Rendering
  render() {
    const e = this.groupTitle ? html`<span aria-hidden=true class=${safeClassMap(r.title)}>${this.groupTitle}</span>` : null, s = this.position > 0 ? html`<div class=${safeClassMap(r.separator)} role=separator></div>` : null;
    return this.el.ariaLabel = this.groupTitle, this.el.role = "group", html`<div class=${safeClassMap({
      [n.container]: true
    })}>${s}${e}<slot></slot></div>`;
  }
};
S("calcite-dropdown-group", h);

export {
  h
};
/*! Bundled license information:

@esri/calcite-components/dist/components/calcite-dropdown-group/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-423ORWJN.js.map
