import {
  s
} from "./chunk-JB56QM27.js";

// node_modules/@arcgis/core/core/a11yUtils.js
var o = () => s.respectPrefersReducedMotion && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export {
  o
};
//# sourceMappingURL=chunk-GTHV6SQV.js.map
