import {
  Z
} from "./chunk-Y5L35WW6.js";
import {
  A,
  E,
  L,
  M as M2,
  S,
  T,
  l,
  v as v2
} from "./chunk-J3L36IWC.js";
import {
  t
} from "./chunk-TTSQRO2X.js";
import {
  D,
  J,
  M,
  g2,
  u,
  y
} from "./chunk-AXAMTBE6.js";
import {
  o
} from "./chunk-ULISRLN2.js";
import {
  n2 as n
} from "./chunk-L7IGKLK6.js";
import {
  g,
  v
} from "./chunk-2NHACHL3.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/Legend/styles/support/relationshipUtils.js
var b = "esri-relationship-ramp";
var u2 = `${b}--diamond`;
var c = `${b}--square`;
var f = "http://www.w3.org/2000/svg";
var p = { diamondContainer: `${u2}__container`, diamondLeftCol: `${u2}__left-column`, diamondRightCol: `${u2}__right-column`, diamondMidCol: `${u2}__middle-column`, diamondMidColLabel: `${u2}__middle-column--label`, diamondMidColRamp: `${u2}__middle-column--ramp`, squareTable: `${c}__table`, squareTableRow: `${c}__table-row`, squareTableCell: `${c}__table-cell`, squareTableLabel: `${c}__table-label`, squareTableLabelLeftBottom: `${c}__table-label--left-bottom`, squareTableLabelRightBottom: `${c}__table-label--right-bottom`, squareTableLabelLeftTop: `${c}__table-label--left-top`, squareTableLabelRightTop: `${c}__table-label--right-top` };
function k(e3, a2, l3 = {}) {
  const { focus: r, labels: t2 } = e3, s2 = !!r, o2 = T2(e3, a2, l3), i2 = { justifyContent: "center" }, b3 = g(), u4 = l3.key ?? a2;
  return s2 ? n("div", { class: p.diamondContainer, key: `${u4}-container`, styles: i2 }, n("div", { class: p.diamondLeftCol }, b3 ? t2.right : t2.left), n("div", { class: p.diamondMidCol }, n("div", { class: p.diamondMidColLabel }, t2.top), o2, n("div", { class: p.diamondMidColLabel }, t2.bottom)), n("div", { class: p.diamondRightCol }, b3 ? t2.left : t2.right)) : n("div", { class: p.squareTable, key: `${u4}-container` }, n("div", { class: p.squareTableRow }, n("div", { class: v(p.squareTableCell, p.squareTableLabel, p.squareTableLabelRightBottom) }, b3 ? t2.top : t2.left), n("div", { class: p.squareTableCell }), n("div", { class: v(p.squareTableCell, p.squareTableLabel, p.squareTableLabelLeftBottom) }, b3 ? t2.left : t2.top)), n("div", { class: p.squareTableRow }, n("div", { class: p.squareTableCell }), o2, n("div", { class: p.squareTableCell })), n("div", { class: p.squareTableRow }, n("div", { class: v(p.squareTableCell, p.squareTableLabel, p.squareTableLabelRightTop) }, b3 ? t2.right : t2.bottom), n("div", { class: p.squareTableCell }), n("div", { class: v(p.squareTableCell, p.squareTableLabel, p.squareTableLabelLeftTop) }, b3 ? t2.bottom : t2.right)));
}
function h(e3, a2, l3) {
  const r = `${l3}_arrowStart`, t2 = `${l3}_arrowEnd`, s2 = "left" === e3, o2 = { markerStart: null, markerEnd: null };
  switch (a2) {
    case "HL":
      s2 ? o2.markerStart = `url(#${t2})` : o2.markerEnd = `url(#${r})`;
      break;
    case "LL":
      o2.markerStart = `url(#${t2})`;
      break;
    case "LH":
      s2 ? o2.markerEnd = `url(#${r})` : o2.markerStart = `url(#${t2})`;
      break;
    default:
      o2.markerEnd = `url(#${r})`;
  }
  return o2;
}
function T2(n3, d2, b3 = {}) {
  const { focus: u4, numClasses: c3, colors: k3, rotation: T3 } = n3, { opacity: _, effectList: q, ariaLabel: $ } = b3, L3 = b3.size ?? 60, g4 = !!u4, C = Math.sqrt(L3 ** 2 + L3 ** 2) + (g4 ? 0 : 5), v3 = [], w3 = [], y2 = [], x2 = (L3 || 75) / c3;
  for (let s2 = 0; s2 < c3; s2++) {
    const o2 = s2 * x2;
    for (let i2 = 0; i2 < c3; i2++) {
      const n4 = i2 * x2, d3 = v2(k3[s2][i2]), m = S(null), b4 = { type: "rect", x: n4, y: o2, width: x2, height: x2 }, u5 = A(d3);
      u5 && v3.push(u5);
      const c4 = M2(b4, d3.fill, m, null);
      c4 && w3.push(c4), y2.push(T(b4));
    }
  }
  const R2 = 15, E2 = 15, M3 = 10;
  let S3 = null;
  g4 || (S3 = "margin: -15px -15px -18px -15px");
  const j2 = h("left", u4, d2), B = h("right", u4, d2), H2 = E(y2), U = L(H2, C, C, 0, false, T3, false), W = L(H2, C, C, 0, false, g4 ? -45 : null, false), X = { filter: M(q) ?? void 0, opacity: null == _ ? "" : `${_}` };
  return n("div", { class: g4 ? p.diamondMidColRamp : p.squareTableCell, styles: X }, n("svg", { "aria-label": $, focusable: false, height: C, role: "image", style: S3, width: C, xmlns: f }, n("defs", null, n("marker", { id: `${d2}_arrowStart`, markerHeight: "10", markerUnits: "strokeWidth", markerWidth: "10", orient: "auto", refX: "5", refY: "5" }, n("polyline", { fill: "none", points: "0,0 5,5 0,10", stroke: "#555555", "stroke-width": "1" })), n("marker", { id: `${d2}_arrowEnd`, markerHeight: "10", markerUnits: "strokeWidth", markerWidth: "10", orient: "auto", refX: "0", refY: "5" }, n("polyline", { fill: "none", points: "5,0 0,5 5,10", stroke: "#555555", "stroke-width": "1" })), v3), n("g", { transform: U }, w3), n("g", { transform: W }, n("line", { fill: "none", "marker-end": j2.markerEnd, "marker-start": j2.markerStart, stroke: "#555555", "stroke-width": "1", x1: -10, x2: -10, y1: L3 - R2, y2: R2 }), n("line", { fill: "none", "marker-end": B.markerEnd, "marker-start": B.markerStart, stroke: "#555555", "stroke-width": "1", x1: E2, x2: L3 - E2, y1: L3 + M3, y2: L3 + M3 }))));
}

// node_modules/@arcgis/core/widgets/Legend/support/relationshipRampUtils.js
var s = { HH: 315, HL: 45, LL: 135, LH: 225 };
var l2 = { 2: [["HL", "HH"], ["LL", "LH"]], 3: [["HL", "HM", "HH"], ["ML", "MM", "MH"], ["LL", "LM", "LH"]], 4: [["HL", "HM1", "HM2", "HH"], ["M2L", "M2M1", "M2M2", "M2H"], ["M1L", "M1M1", "M1M2", "M1H"], ["LL", "LM1", "LM2", "LH"]] };
function n2(t2) {
  if (!t2) return;
  const { type: s2 } = t2;
  if (s2.includes("3d")) return Z(t2.symbolLayers.at(0));
  if ("simple-line" === s2) {
    const e3 = y(t2);
    return e3 && e3.color;
  }
  if ("simple-marker" === t2.type && ("x" === t2.style || "cross" === t2.style)) {
    const e3 = y(t2);
    return e3 && e3.color;
  }
  return u(t2);
}
function H(t2, o2) {
  const e3 = o2.HH.label, r = o2.LL.label, s2 = o2.HL.label, l3 = o2.LH.label;
  switch (t2) {
    case "HH":
    default:
      return { top: e3, bottom: r, left: s2, right: l3 };
    case "HL":
      return { top: s2, bottom: l3, left: r, right: e3 };
    case "LL":
      return { top: r, bottom: e3, left: l3, right: s2 };
    case "LH":
      return { top: l3, bottom: s2, left: e3, right: r };
  }
}
function i(t2) {
  const { focus: o2, infos: e3, numClasses: r } = t2, s2 = l2[r], L3 = {};
  e3.forEach((t3) => {
    L3[t3.value] = { label: t3.label, fill: n2(t3.symbol) };
  });
  const i2 = [];
  for (let l3 = 0; l3 < r; l3++) {
    const t3 = [];
    for (let o3 = 0; o3 < r; o3++) {
      const e4 = L3[s2[l3][o3]];
      t3.push(e4.fill);
    }
    i2.push(t3);
  }
  return { type: "relationship-ramp", numClasses: r, focus: o2, colors: i2, labels: H(o2, L3), rotation: u3(o2) };
}
function u3(t2) {
  let o2 = s[t2];
  return t2 && null == o2 && (o2 = s.HH), o2 || 0;
}

// node_modules/@arcgis/core/symbols/support/symbolUtils.js
var b2 = null;
var d = [255, 255, 255];
function g3(e3, t2) {
  return Math.floor(Math.random() * (t2 - e3 + 1) + e3);
}
function w2(e3, t2, l3) {
  const { backgroundColor: a2, outline: r, dotSize: s2 } = e3, n3 = l3?.swatchSize || t.size, o2 = 0.8, c3 = Math.round(n3 * n3 / Math.max(s2, 0.5) ** 2 * o2), u4 = window.devicePixelRatio, f2 = document.createElement("canvas"), p2 = n3 * u4;
  f2.width = p2, f2.height = p2, f2.style.width = f2.width / u4 + "px", f2.style.height = f2.height / u4 + "px";
  const y2 = f2.getContext("2d");
  if (a2 && (y2.fillStyle = a2.toCss(true), y2.fillRect(0, 0, p2, p2), y2.fill()), y2.fillStyle = t2?.toCss(true) ?? "", b2 && b2.length / 2 === c3) for (let i2 = 0; i2 < 2 * c3; i2 += 2) {
    const e4 = b2[i2], t3 = b2[i2 + 1];
    y2.fillRect(e4, t3, s2 * u4, s2 * u4), y2.fill();
  }
  else {
    b2 = [];
    for (let e4 = 0; e4 < 2 * c3; e4 += 2) {
      const e5 = g3(0, p2), t3 = g3(0, p2);
      b2.push(e5, t3), y2.fillRect(e5, t3, s2 * u4, s2 * u4), y2.fill();
    }
  }
  r && (r.color && (y2.strokeStyle = r.color.toCss(true)), y2.lineWidth = r.width, y2.strokeRect(0, 0, p2, p2));
  const h4 = new Image(n3, n3);
  return h4.src = f2.toDataURL(), h4.ariaLabel = l3?.ariaLabel ?? null, h4.alt = l3?.ariaLabel ?? "", h4;
}
function S2(e3, t2 = {}) {
  const l3 = t2.radius || 40, i2 = 2 * Math.PI * l3, s2 = e3.length, n3 = i2 / s2, o2 = [], c3 = y(t2.outline);
  null != c3?.width && (c3.width *= 2), (c3 || t2.backgroundColor) && o2.push({ shape: { type: "circle", cx: l3, cy: l3, r: l3 }, fill: t2.backgroundColor, stroke: c3, offset: [0, 0] });
  const u4 = t2.values, f2 = u4 && u4.length === s2 && 100 === u4.reduce((e4, t3) => e4 + t3, 0), p2 = [0];
  for (let a2 = 0; a2 < s2; a2++) {
    let t3 = null;
    f2 && (t3 = u4[a2] * i2 / 100, p2.push(t3 + p2[a2])), o2.push({ shape: { type: "circle", cx: l3, cy: l3, r: l3 / 2 }, fill: [0, 0, 0, 0], stroke: { width: l3, dashArray: `${(t3 ?? n3) / 2} ${i2}`, dashoffset: "-" + (f2 ? p2[a2] / 2 : a2 * (n3 / 2)), color: e3[a2] }, offset: [0, 0] });
  }
  let y2 = null;
  const h4 = 2 * l3 + (c3?.width || 0), m = t2.holePercentage;
  if (m) {
    c3 && o2.push({ shape: { type: "circle", cx: l3, cy: l3, r: l3 * m }, fill: null, stroke: c3, offset: [0, 0] });
    const e4 = h4 / 2;
    y2 = [[{ shape: { type: "circle", cx: e4, cy: e4, r: e4 }, fill: d, stroke: c3 ? __spreadProps(__spreadValues({}, c3), { color: d }) : null, offset: [0, 0] }, { shape: { type: "circle", cx: e4, cy: e4, r: l3 * m }, fill: [0, 0, 0], stroke: null, offset: [0, 0] }]];
  }
  return l([o2], [h4, h4], { effectView: t2.effectList, ignoreStrokeWidth: true, masking: y2, rotations: [-90], ariaLabel: t2.ariaLabel });
}
function V(e3, t2 = {}) {
  const l3 = 24, a2 = 75, i2 = "horizontal" === t2.align, r = i2 ? a2 : l3, s2 = i2 ? l3 : a2, n3 = t2.width ?? r, o2 = t2.height ?? s2, c3 = t2.gradient ?? true, u4 = window.devicePixelRatio, f2 = n3 * u4, p2 = o2 * u4, y2 = document.createElement("canvas");
  y2.width = f2, y2.height = p2, y2.ariaLabel = t2.ariaLabel ?? null, y2.style.width = `${n3}px`, y2.style.height = `${o2}px`;
  const h4 = y2.getContext("2d"), m = i2 ? f2 : 0, b3 = i2 ? 0 : p2;
  if (c3) {
    const t3 = h4.createLinearGradient(0, 0, m, b3), l4 = e3.length, a3 = 1 === l4 ? 0 : 1 / (l4 - 1);
    e3.forEach((e4, l5) => t3.addColorStop(l5 * a3, e4.toString())), h4.fillStyle = t3, h4.fillRect(0, 0, f2, p2);
  } else {
    const t3 = i2 ? f2 / e3.length : f2, l4 = i2 ? p2 : p2 / e3.length;
    let a3 = 0, r2 = 0;
    for (const s3 of e3) h4.fillStyle = s3.toString(), h4.fillRect(a3, r2, t3, l4), a3 = i2 ? a3 + t3 : 0, r2 = i2 ? 0 : r2 + l4;
  }
  const d2 = document.createElement("div");
  return d2.style.width = `${n3}px`, d2.style.height = `${o2}px`, k2(d2, t2?.effectList), d2.appendChild(y2), d2;
}
function k2(e3, t2) {
  if (!t2) return;
  e3.style.filter = M(t2);
  const l3 = t2.effects;
  if (l3) {
    for (const a2 of l3) if ("drop-shadow" === a2?.type) {
      a2.offsetX < 0 ? e3.style.marginLeft = `${Math.abs(a2.offsetX)}px` : e3.style.marginRight = `${a2.offsetX}px`;
      break;
    }
  }
}
function L2(e3, t2) {
  return __async(this, null, function* () {
    switch (e3.type) {
      case "web-style": {
        const { previewWebStyleSymbol: l3 } = yield import("./previewWebStyleSymbol-OBMFGOIB.js");
        return l3(e3, L2, t2);
      }
      case "label-3d":
      case "line-3d":
      case "mesh-3d":
      case "point-3d":
      case "polygon-3d": {
        const { previewSymbol3D: l3 } = yield import("./previewSymbol3D-B7FO2ZYQ.js");
        return l3(e3, t2);
      }
      case "simple-marker":
      case "simple-line":
      case "simple-fill":
      case "picture-marker":
      case "picture-fill":
      case "text": {
        const { previewSymbol2D: l3 } = yield import("./previewSymbol2D-D35CK5HU.js");
        return l3(e3, t2);
      }
      case "cim": {
        const { previewCIMSymbol: l3 } = yield import("./previewCIMSymbol-QSSS37CZ.js");
        return l3(e3, t2);
      }
      default:
        return;
    }
  });
}
function x(e3) {
  return e3 && "opacity" in e3 ? e3.opacity * x(e3.parent) : 1;
}
function R(e3, t2) {
  return __async(this, null, function* () {
    if (!e3) return;
    const a2 = e3.sourceLayer, i2 = (null != t2 && t2.useSourceLayer ? a2 : e3.layer) ?? a2, r = t2?.ignoreOpacity ? 1 : x(i2);
    if (null != e3.symbol && (null == t2 || true !== t2.ignoreGraphicSymbol)) {
      const l3 = "web-style" === e3.symbol.type ? yield e3.symbol.fetchSymbol(__spreadProps(__spreadValues({}, t2), { acceptedFormats: ["web", "cim"], cache: null != t2 ? t2.webStyleCache : null })) : e3.symbol.clone();
      return g2(l3, null, r), l3;
    }
    const s2 = t2?.renderer ?? j(i2);
    let n3 = s2 && "getSymbolAsync" in s2 ? yield s2.getSymbolAsync(e3, t2) : null;
    if (!n3) return;
    if (n3 = "web-style" === n3.type ? yield n3.fetchSymbol(__spreadProps(__spreadValues({}, t2), { cache: null != t2 ? t2.webStyleCache : null })) : n3.clone(), !s2 || !("visualVariables" in s2) || !s2.visualVariables?.length) return g2(n3, null, r), n3;
    if ("arcadeRequiredForVisualVariables" in s2 && s2.arcadeRequiredForVisualVariables && null == t2?.arcade) {
      const e4 = __spreadValues({}, t2);
      e4.arcade = yield o(), t2 = e4;
    }
    const { getColor: f2, getOpacity: p2, getAllSizes: y2, getRotationAngle: h4 } = yield import("./visualVariableUtils-56TFSNIY.js"), m = [], b3 = [], d2 = [], g4 = [];
    for (const l3 of s2.visualVariables) switch (l3.type) {
      case "color":
        m.push(l3);
        break;
      case "opacity":
        b3.push(l3);
        break;
      case "rotation":
        g4.push(l3);
        break;
      case "size":
        l3.target || d2.push(l3);
    }
    const w3 = !!m.length && m[m.length - 1], S3 = w3 ? f2(w3, e3, t2) : null, v3 = !!b3.length && b3[b3.length - 1];
    let V2 = v3 ? p2(v3, e3, t2) : null;
    if (null != r && (V2 = null != V2 ? V2 * r : r), t2?.ignoreOpacity && (V2 = 1), g2(n3, S3, V2), d2.length && true !== t2?.ignoreSizeVariables) {
      const l3 = y2(d2, e3, t2);
      yield D(n3, l3);
    }
    if (true !== t2?.ignoreRotationVariables) for (const l3 of g4) J(n3, h4(l3, e3, t2), l3.axis);
    return n3;
  });
}
function j(e3) {
  if (e3) return "renderer" in e3 ? e3.renderer : void 0;
}

export {
  k,
  i,
  u3 as u,
  w2 as w,
  S2 as S,
  V,
  L2 as L,
  R
};
//# sourceMappingURL=chunk-772TINXM.js.map
