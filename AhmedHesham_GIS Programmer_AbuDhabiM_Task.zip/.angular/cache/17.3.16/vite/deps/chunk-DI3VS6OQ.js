import {
  nl
} from "./chunk-RPGOD7HK.js";
import {
  s
} from "./chunk-R342OI6W.js";

// node_modules/@arcgis/core/geometry/operators/gx/operatorUnion.js
var e = new nl();
function o(n, r, o2) {
  return e.execute(n, r, o2, null);
}
function t(r, o2) {
  return e.executeMany(new s(r), o2, null).next();
}
function s2() {
  return e.supportsCurves();
}

export {
  o,
  t,
  s2 as s
};
//# sourceMappingURL=chunk-DI3VS6OQ.js.map
