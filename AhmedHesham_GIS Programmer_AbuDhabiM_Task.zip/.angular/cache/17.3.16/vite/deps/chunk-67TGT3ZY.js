import {
  i
} from "./chunk-LPID7LVC.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/chunks/dom.js
var O = ["input:not([inert])", "select:not([inert])", "textarea:not([inert])", "a[href]:not([inert])", "button:not([inert])", "[tabindex]:not(slot):not([inert])", "audio[controls]:not([inert])", "video[controls]:not([inert])", '[contenteditable]:not([contenteditable="false"]):not([inert])', "details>summary:first-of-type:not([inert])", "details:not([inert])"];
var b = O.join(",");
var C = typeof Element > "u";
var d = C ? function() {
} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
var h = !C && Element.prototype.getRootNode ? function(e4) {
  var t;
  return e4 == null || (t = e4.getRootNode) === null || t === void 0 ? void 0 : t.call(e4);
} : function(e4) {
  return e4?.ownerDocument;
};
var v = function e(t, r) {
  var n;
  r === void 0 && (r = true);
  var a = t == null || (n = t.getAttribute) === null || n === void 0 ? void 0 : n.call(t, "inert"), o = a === "" || a === "true", i2 = o || r && t && e(t.parentNode);
  return i2;
};
var k = function(t) {
  var r, n = t == null || (r = t.getAttribute) === null || r === void 0 ? void 0 : r.call(t, "contenteditable");
  return n === "" || n === "true";
};
var M = function(t, r, n) {
  if (v(t))
    return [];
  var a = Array.prototype.slice.apply(t.querySelectorAll(b));
  return r && d.call(t, b) && a.unshift(t), a = a.filter(n), a;
};
var B = function e2(t, r, n) {
  for (var a = [], o = Array.from(t); o.length; ) {
    var i2 = o.shift();
    if (!v(i2, false))
      if (i2.tagName === "SLOT") {
        var u = i2.assignedElements(), s = u.length ? u : i2.children, l = e2(s, true, n);
        n.flatten ? a.push.apply(a, l) : a.push({
          scopeParent: i2,
          candidates: l
        });
      } else {
        var f = d.call(i2, b);
        f && n.filter(i2) && (r || !t.includes(i2)) && a.push(i2);
        var c = i2.shadowRoot || // check for an undisclosed shadow
        typeof n.getShadowRoot == "function" && n.getShadowRoot(i2), D2 = !v(c, false) && (!n.shadowRootFilter || n.shadowRootFilter(i2));
        if (c && D2) {
          var S = e2(c === true ? i2.children : c.children, true, n);
          n.flatten ? a.push.apply(a, S) : a.push({
            scopeParent: i2,
            candidates: S
          });
        } else
          o.unshift.apply(o, i2.children);
      }
  }
  return a;
};
var N = function(t) {
  return !isNaN(parseInt(t.getAttribute("tabindex"), 10));
};
var I = function(t) {
  if (!t)
    throw new Error("No node provided");
  return t.tabIndex < 0 && (/^(AUDIO|VIDEO|DETAILS)$/.test(t.tagName) || k(t)) && !N(t) ? 0 : t.tabIndex;
};
var L = function(t, r) {
  var n = I(t);
  return n < 0 && r && !N(t) ? 0 : n;
};
var P = function(t, r) {
  return t.tabIndex === r.tabIndex ? t.documentOrder - r.documentOrder : t.tabIndex - r.tabIndex;
};
var A = function(t) {
  return t.tagName === "INPUT";
};
var q = function(t) {
  return A(t) && t.type === "hidden";
};
var $ = function(t) {
  var r = t.tagName === "DETAILS" && Array.prototype.slice.apply(t.children).some(function(n) {
    return n.tagName === "SUMMARY";
  });
  return r;
};
var W = function(t, r) {
  for (var n = 0; n < t.length; n++)
    if (t[n].checked && t[n].form === r)
      return t[n];
};
var G = function(t) {
  if (!t.name)
    return true;
  var r = t.form || h(t), n = function(u) {
    return r.querySelectorAll('input[type="radio"][name="' + u + '"]');
  }, a;
  if (typeof window < "u" && typeof window.CSS < "u" && typeof window.CSS.escape == "function")
    a = n(window.CSS.escape(t.name));
  else
    try {
      a = n(t.name);
    } catch (i2) {
      return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", i2.message), false;
    }
  var o = W(a, t.form);
  return !o || o === t;
};
var U = function(t) {
  return A(t) && t.type === "radio";
};
var j = function(t) {
  return U(t) && !G(t);
};
var z = function(t) {
  var r, n = t && h(t), a = (r = n) === null || r === void 0 ? void 0 : r.host, o = false;
  if (n && n !== t) {
    var i2, u, s;
    for (o = !!((i2 = a) !== null && i2 !== void 0 && (u = i2.ownerDocument) !== null && u !== void 0 && u.contains(a) || t != null && (s = t.ownerDocument) !== null && s !== void 0 && s.contains(t)); !o && a; ) {
      var l, f, c;
      n = h(a), a = (l = n) === null || l === void 0 ? void 0 : l.host, o = !!((f = a) !== null && f !== void 0 && (c = f.ownerDocument) !== null && c !== void 0 && c.contains(a));
    }
  }
  return o;
};
var T = function(t) {
  var r = t.getBoundingClientRect(), n = r.width, a = r.height;
  return n === 0 && a === 0;
};
var X = function(t, r) {
  var n = r.displayCheck, a = r.getShadowRoot;
  if (getComputedStyle(t).visibility === "hidden")
    return true;
  var o = d.call(t, "details>summary:first-of-type"), i2 = o ? t.parentElement : t;
  if (d.call(i2, "details:not([open]) *"))
    return true;
  if (!n || n === "full" || n === "legacy-full") {
    if (typeof a == "function") {
      for (var u = t; t; ) {
        var s = t.parentElement, l = h(t);
        if (s && !s.shadowRoot && a(s) === true)
          return T(t);
        t.assignedSlot ? t = t.assignedSlot : !s && l !== t.ownerDocument ? t = l.host : t = s;
      }
      t = u;
    }
    if (z(t))
      return !t.getClientRects().length;
    if (n !== "legacy-full")
      return true;
  } else if (n === "non-zero-area")
    return T(t);
  return false;
};
var V = function(t) {
  if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(t.tagName))
    for (var r = t.parentElement; r; ) {
      if (r.tagName === "FIELDSET" && r.disabled) {
        for (var n = 0; n < r.children.length; n++) {
          var a = r.children.item(n);
          if (a.tagName === "LEGEND")
            return d.call(r, "fieldset[disabled] *") ? true : !a.contains(t);
        }
        return true;
      }
      r = r.parentElement;
    }
  return false;
};
var Y = function(t, r) {
  return !(r.disabled || // we must do an inert look up to filter out any elements inside an inert ancestor
  //  because we're limited in the type of selectors we can use in JSDom (see related
  //  note related to `candidateSelectors`)
  v(r) || q(r) || X(r, t) || // For a details element with a summary, the summary element gets the focus
  $(r) || V(r));
};
var E = function(t, r) {
  return !(j(r) || I(r) < 0 || !Y(t, r));
};
var Z = function(t) {
  var r = parseInt(t.getAttribute("tabindex"), 10);
  return !!(isNaN(r) || r >= 0);
};
var H = function e3(t) {
  var r = [], n = [];
  return t.forEach(function(a, o) {
    var i2 = !!a.scopeParent, u = i2 ? a.scopeParent : a, s = L(u, i2), l = i2 ? e3(a.candidates) : u;
    s === 0 ? i2 ? r.push.apply(r, l) : r.push(u) : n.push({
      documentOrder: o,
      tabIndex: s,
      item: a,
      isScope: i2,
      content: l
    });
  }), n.sort(P).reduce(function(a, o) {
    return o.isScope ? a.push.apply(a, o.content) : a.push(o.content), a;
  }, []).concat(r);
};
var K = function(t, r) {
  r = r || {};
  var n;
  return r.getShadowRoot ? n = B([t], r.includeContainer, {
    filter: E.bind(null, r),
    flatten: false,
    getShadowRoot: r.getShadowRoot,
    shadowRootFilter: Z
  }) : n = M(t, r.includeContainer, E.bind(null, r)), H(n);
};
var J = {
  getShadowRoot: true
};
function dt(e4) {
  return e4 ? e4.id = e4.id || `${e4.tagName.toLowerCase()}-${i()}` : "";
}
function gt(e4) {
  const t = "dir", r = `[${t}]`, n = m(e4, r);
  return n ? n.getAttribute(t) : "ltr";
}
function p(e4) {
  return e4.getRootNode();
}
function yt(e4) {
  const t = p(e4);
  return "host" in t ? t : null;
}
function pt(e4, t) {
  if (!e4)
    return 0;
  const n = document.createElement("canvas").getContext("2d");
  return n.font = t, n.measureText(e4).width;
}
function x(e4) {
  return e4.host || null;
}
function Q(e4, {
  selector: t,
  id: r
}) {
  if (!e4)
    return null;
  e4.assignedSlot && (e4 = e4.assignedSlot);
  const n = p(e4);
  return (r ? "getElementById" in n ? (
    /*
      Check to make sure 'getElementById' exists in cases where element is no longer connected to the DOM and getRootNode() returns the element.
      https://github.com/Esri/calcite-design-system/pull/4280
       */
    n.getElementById(r)
  ) : null : t ? n.querySelector(t) : null) || Q(x(n), { selector: t, id: r });
}
function m(e4, t) {
  return e4 ? e4.closest(t) || m(x(p(e4)), t) : null;
}
function _(e4) {
  return typeof e4?.setFocus == "function";
}
function tt(e4) {
  return __async(this, null, function* () {
    if (e4)
      return _(e4) ? e4.setFocus() : e4.focus();
  });
}
function et(e4) {
  if (e4)
    return K(e4, J)[0] ?? e4;
}
function mt(e4) {
  et(e4)?.focus();
}
function rt(e4, t) {
  return e4.filter((r) => r.matches(t));
}
function Tt(e4, t, r) {
  if (typeof t == "string" && t !== "")
    return t;
  if (t === "" || t === true)
    return e4[r];
}
function wt(e4) {
  return (!!e4).toString();
}
function Ct(e4) {
  return ot(e4) || at(e4);
}
function nt(e4) {
  return it(e4).filter((t) => t.nodeType === Node.TEXT_NODE).map((t) => t.textContent).join("").trim();
}
function Nt(e4) {
  for (const t of e4.childNodes)
    if (t.nodeType === Node.TEXT_NODE && t.textContent?.trim() !== "" || t.nodeType === Node.ELEMENT_NODE)
      return true;
  return false;
}
function at(e4) {
  return !!nt(e4);
}
function it(e4) {
  return e4.currentTarget.assignedNodes({
    flatten: true
  });
}
function ot(e4) {
  return !!ut(e4).length;
}
function ut(e4, t) {
  return st(e4.target, t);
}
function st(e4, t) {
  const r = e4.assignedElements({
    flatten: true
  });
  return t ? rt(r, t) : r;
}
function It(e4) {
  return !!(e4.isPrimary && e4.button === 0);
}
function At(e4) {
  return e4.detail === 0;
}
var xt = (e4, t, r, n = true) => {
  const a = e4.indexOf(t), o = a === 0, i2 = a === e4.length - 1;
  n && (r = r === "previous" && o ? "last" : r === "next" && i2 ? "first" : r);
  let u;
  return r === "previous" ? u = e4[a - 1] || e4[n ? e4.length - 1 : a] : r === "next" ? u = e4[a + 1] || e4[n ? 0 : a] : r === "last" ? u = e4[e4.length - 1] : u = e4[0], tt(u), u;
};
function Rt(e4, t) {
  if (e4.parentNode !== t.parentNode)
    return false;
  const r = Array.from(e4.parentNode.children);
  return r.indexOf(e4) < r.indexOf(t);
}
function Dt(e4, t, r, n) {
  return __async(this, null, function* () {
    return R(e4, t, "animation", r, n);
  });
}
function Ft(e4, t, r, n) {
  return __async(this, null, function* () {
    return R(e4, t, "transition", r, n);
  });
}
function lt(e4, t) {
  return __async(this, null, function* () {
    yield y(), e4?.(), yield y(), t?.();
  });
}
function w(e4, t, r) {
  const n = t === "transition" ? "transitionProperty" : "animationName";
  return e4.getAnimations().find((a) => a[n] === r);
}
function R(e4, t, r, n, a) {
  return __async(this, null, function* () {
    let o = w(e4, r, t);
    if (o || (yield y(), o = w(e4, r, t)), !o)
      return lt(n, a);
    n?.();
    try {
      yield o.finished;
    } catch {
    } finally {
      a?.();
    }
  });
}
function y() {
  return new Promise((e4) => requestAnimationFrame(() => e4()));
}
function Ot(e4) {
  return e4.endsWith("px");
}

export {
  J,
  dt,
  gt,
  p,
  yt,
  pt,
  Q,
  m,
  tt,
  et,
  mt,
  Tt,
  wt,
  Ct,
  Nt,
  ot,
  ut,
  It,
  At,
  xt,
  Rt,
  Dt,
  Ft,
  Ot
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/dom.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
  (*!
  * tabbable 6.2.0
  * @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
  *)
*/
//# sourceMappingURL=chunk-67TGT3ZY.js.map
