import {
  C
} from "./chunk-EOJGN7NW.js";

// node_modules/@arcgis/core/arcade/portalUtils.js
function l(l2, t) {
  if (null === l2) return t;
  return new C({ url: l2.field("url") });
}

export {
  l
};
//# sourceMappingURL=chunk-2MNCLHO3.js.map
