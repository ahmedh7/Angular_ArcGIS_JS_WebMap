import {
  s
} from "./chunk-6BUGRELN.js";

// node_modules/@arcgis/core/layers/graphics/data/optimizedFeatureQueryEngineAdapter.js
var e = { getObjectId: (t) => t.objectId, getAttributes: (t) => t.attributes, getAttribute: (t, e2) => t.attributes[e2], cloneWithGeometry: (e2, r) => new s(r, e2.attributes, null, e2.objectId), getGeometry: (t) => t.geometry, getCentroid: (t, e2) => t.ensureCentroid(e2) };

export {
  e
};
//# sourceMappingURL=chunk-CMXKYHQC.js.map
