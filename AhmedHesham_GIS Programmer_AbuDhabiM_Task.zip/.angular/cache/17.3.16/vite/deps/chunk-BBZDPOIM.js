import {
  E2 as E,
  s2 as s
} from "./chunk-DKRE5NM4.js";
import {
  H
} from "./chunk-SZIT3IYE.js";

// node_modules/@arcgis/core/views/interactive/snapping/hints/IntersectionSnappingHint.js
var o = class _o extends s {
  constructor(n, i, o2 = E.ALL) {
    super(i, o2), this.intersectionPoint = n;
  }
  equals(t) {
    return t instanceof _o && H(this.intersectionPoint, t.intersectionPoint);
  }
};

export {
  o
};
//# sourceMappingURL=chunk-BBZDPOIM.js.map
