import {
  e
} from "./chunk-CISWKCW5.js";
import {
  c
} from "./chunk-BLUYYJD4.js";
import {
  g
} from "./chunk-P5ELECBN.js";

// node_modules/@arcgis/core/geometry/projection/projectVectorToVector.js
function n(r, t, e2, n2, i) {
  return !(null == t || null == n2 || r.length < 2) && (a.x = r[0], a.y = r[1], a.z = r[2], a.spatialReference = t, c(a, e2, n2, i));
}
var a = e(0, 0, 0, g.WGS84);

export {
  n
};
//# sourceMappingURL=chunk-66HQ5M7W.js.map
