import {
  f,
  l
} from "./chunk-JIKC4GZP.js";
import "./chunk-QF6YRV6E.js";
import "./chunk-2OWCHVL2.js";
import {
  Be,
  Ie,
  Me,
  Pe
} from "./chunk-4SZH2Z4H.js";
import "./chunk-RPGOD7HK.js";
import "./chunk-R342OI6W.js";
import "./chunk-IXIHJCDJ.js";
import {
  I2 as I
} from "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import "./chunk-UNFSMTII.js";
import "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import {
  G
} from "./chunk-D5RIMQ7U.js";
import "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/geometry/operators/json/bufferOperator.js
function a(t, o, m = {}) {
  const { unit: a2 } = m, c2 = Ie(t);
  a2 && c2 && (o = I(o, a2, c2));
  const u = Pe(t), p = u.getSpatialReference();
  return Me(f(u.getGeometry(), p, o), p);
}
function c(e, i, a2 = {}) {
  let { maxDeviation: c2 = NaN, maxVerticesInFullCircle: u = 96, union: p = false, unit: f2 } = a2;
  const l2 = Ie(e);
  f2 && l2 && (i = i.map((t) => I(t, f2, l2)), c2 && (c2 = I(c2, f2, l2)));
  const [j, x] = Be(e);
  return l(j, x, i, c2, u, p).map((t) => Me(t, x)).filter(G);
}
export {
  a as execute,
  c as executeMany
};
//# sourceMappingURL=bufferOperator-3BCNAKE4.js.map
