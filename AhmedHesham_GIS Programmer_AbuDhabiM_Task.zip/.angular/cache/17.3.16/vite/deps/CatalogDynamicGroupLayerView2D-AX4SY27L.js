import {
  S
} from "./chunk-TDZIOYA4.js";
import {
  y
} from "./chunk-YPRFDORJ.js";
import "./chunk-YDLYZSD6.js";
import "./chunk-CEREZWZ6.js";
import "./chunk-5BGQWKMP.js";
import "./chunk-PAXNBAQG.js";
import "./chunk-LYJYKR5U.js";
import "./chunk-N3UNX5HB.js";
import "./chunk-VACYGDXY.js";
import "./chunk-L3LR7QC5.js";
import "./chunk-MKDJERJR.js";
import "./chunk-O3P5XPEU.js";
import "./chunk-P5BI27MR.js";
import "./chunk-DTRN4OOH.js";
import "./chunk-3P3SZYCX.js";
import "./chunk-V6AHEXFE.js";
import {
  r as r2
} from "./chunk-7F6XPLMG.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-DSFF7UA2.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-XYTETMU6.js";
import "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  d,
  e,
  k,
  t
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  n2 as n
} from "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/layers/CatalogDynamicGroupLayerView.js
var l = Symbol();
var u = (u2) => {
  let y2 = class extends u2 {
    constructor() {
      super(...arguments), this.layerViews = new V(), this._debouncedUpdate = k(() => __async(this, null, function* () {
        const { layer: e2, parent: r3 } = this, t2 = r3?.footprintLayerView;
        let s = [];
        const i2 = this._createQuery();
        if (i2 && t2) {
          const { features: r4 } = yield t2.queryFeatures(i2);
          this.suspended || (s = r4.map((r5) => e2.acquireLayer(r5)));
        }
        this.removeHandles(l), this.addHandles(s, l);
      }));
    }
    get creatingLayerViews() {
      return this.view?.layerViewManager.isCreatingLayerViewsForLayer(this.layer) ?? false;
    }
    isUpdating() {
      return this.creatingLayerViews || this.layer.updating || this.layerViews.some((e2) => e2.updating);
    }
    enableLayerUpdates() {
      return t([this._updatingHandles.addWhen(() => false === this.parent?.footprintLayerView?.dataUpdating, () => this.updateLayers()), this._updatingHandles.add(() => [this.layer.maximumVisibleSublayers, this.layer.parent?.orderBy, this.parent?.footprintLayerView?.filter, this.parent?.footprintLayerView?.timeExtent, this.suspended], () => this.updateLayers()), e(() => this.removeHandles(l))]);
    }
    updateLayers() {
      this.suspended ? this.removeHandles(l) : this._updatingHandles.addPromise(d(this._debouncedUpdate()).catch((e2) => {
        n.getLogger(this).error(e2);
      }));
    }
    _createQuery() {
      const e2 = this.parent?.footprintLayerView, r3 = this.layer?.parent;
      if (!e2 || !r3 || r3.destroyed) return null;
      const { layer: { maximumVisibleSublayers: t2 }, view: { scale: s } } = this;
      if (!t2) return null;
      const { itemTypeField: i2, itemSourceField: a2, itemNameField: o, minScaleField: d2, maxScaleField: p, objectIdField: l2, orderBy: u3 } = r3, y3 = r2(`${d2} IS NULL OR ${s} <= ${d2} OR ${d2} = 0`, `${p} IS NULL OR ${s} >= ${p}`), c2 = u3?.find((e3) => e3.field && !e3.valueExpression), m2 = e2.createQuery();
      if (m2.returnGeometry = false, m2.num = t2, m2.outFields = [l2, a2, o], m2.where = r2(m2.where, y3), null != this.unsupportedItemTypes) {
        const e3 = `${i2} NOT IN (${this.unsupportedItemTypes.map((e4) => `'${e4}'`)})`;
        m2.where = r2(m2.where, e3);
      }
      return c2?.field && (m2.orderByFields = [`${c2.field} ${"descending" === c2.order ? "DESC" : "ASC"}`], m2.outFields.push(c2.field)), m2;
    }
  };
  return r([m({ readOnly: true })], y2.prototype, "creatingLayerViews", null), r([m()], y2.prototype, "layer", void 0), r([m()], y2.prototype, "layerViews", void 0), r([m({ readOnly: true })], y2.prototype, "unsupportedItemTypes", void 0), r([m()], y2.prototype, "parent", void 0), r([m({ readOnly: true })], y2.prototype, "isUpdating", null), y2 = r([a("esri.views.layers.CatalogDynamicGroupLayerView")], y2), y2;
};

// node_modules/@arcgis/core/views/2d/layers/CatalogDynamicGroupLayerView2D.js
var i = class extends u(S(y)) {
  constructor() {
    super(...arguments), this.unsupportedItemTypes = ["Scene Service"], this.layerViews = new V();
  }
  attach() {
    this.addAttachHandles([this.layerViews.on("after-changes", () => this._updateStageChildren()), this.enableLayerUpdates()]);
  }
  detach() {
    this.container.removeAllChildren();
  }
  update(e2) {
    this.updateLayers();
  }
  viewChange() {
  }
  moveEnd() {
    this.requestUpdate();
  }
  _updateStageChildren() {
    this.container.removeAllChildren(), this.layerViews.forEach((e2, r3) => this.container.addChildAt(e2.container, r3));
  }
};
i = r([a("esri.views.2d.layers.CatalogDynamicGroupLayerView2D")], i);
var c = i;
export {
  c as default
};
//# sourceMappingURL=CatalogDynamicGroupLayerView2D-AX4SY27L.js.map
