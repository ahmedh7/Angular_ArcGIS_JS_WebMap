import {
  a
} from "./chunk-HZVZN4QC.js";
import {
  h as h2
} from "./chunk-ARKMS27Q.js";
import {
  f
} from "./chunk-7C4YASO2.js";
import {
  r
} from "./chunk-MWWEB6NO.js";
import {
  w
} from "./chunk-FMVDY4TM.js";
import {
  g
} from "./chunk-P5ELECBN.js";
import {
  h
} from "./chunk-ADRG7ORV.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/support/commonProperties.js
var s = { type: Boolean, value: true, json: { origins: { service: { read: false, write: false }, "web-map": { read: false, write: false } }, name: "screenSizePerspective", write: { enabled: true, layerContainerTypes: a } } };
var l = { type: Boolean, value: true, json: { name: "disablePopup", read: { reader: (e, r2) => !r2.disablePopup }, write: { enabled: true, writer(e, r2, n) {
  r2[n] = !e;
} } } };
var p = { type: Boolean, value: true, nonNullable: true, json: { name: "showLabels", write: { enabled: true, layerContainerTypes: a } } };
var y = { type: String, json: { origins: { "portal-item": { write: false } }, write: { isRequired: true, ignoreOrigin: true, writer: h } } };
var d = { type: Boolean, value: true, nonNullable: true, json: { origins: { service: { read: { enabled: false } } }, name: "showLegend", write: { enabled: true, layerContainerTypes: a } } };
var c = { value: null, type: h2, json: { origins: { service: { name: "elevationInfo", write: true } }, name: "layerDefinition.elevationInfo", write: { enabled: true, layerContainerTypes: a } } };
function m(e) {
  return { type: e, readOnly: true, json: { origins: { service: { read: true } }, read: false } };
}
var w2 = { write: { enabled: true, layerContainerTypes: a }, read: true };
var f2 = { type: Number, json: { origins: { "web-document": w2, "portal-item": { write: { layerContainerTypes: a } } } } };
var b = __spreadProps(__spreadValues({}, f2), { json: __spreadProps(__spreadValues({}, f2.json), { origins: { "web-document": __spreadProps(__spreadValues({}, w2), { write: { enabled: true, layerContainerTypes: a, target: { opacity: { type: Number }, "layerDefinition.drawingInfo.transparency": { type: Number } } } }) }, read: { source: ["layerDefinition.drawingInfo.transparency", "drawingInfo.transparency"], reader: (e, r2, n) => n && "service" !== n.origin || !r2.drawingInfo || void 0 === r2.drawingInfo.transparency ? r2.layerDefinition?.drawingInfo && void 0 !== r2.layerDefinition.drawingInfo.transparency ? r(r2.layerDefinition.drawingInfo.transparency) : void 0 : r(r2.drawingInfo.transparency) } }) });
var g2 = { type: w, readOnly: true, json: { origins: { service: { read: { source: ["fullExtent", "spatialReference"], reader: (e, i) => {
  const a2 = w.fromJSON(e);
  return null != i.spatialReference && "object" == typeof i.spatialReference && (a2.spatialReference = g.fromJSON(i.spatialReference)), a2;
} } } }, read: false } };
var u = { type: String, json: { origins: { service: { read: false }, "portal-item": { read: false } } } };
var j = { type: Number, json: { origins: { service: { write: { enabled: false } } }, name: "layerDefinition.minScale", write: { layerContainerTypes: a } } };
var v = { type: Number, json: { origins: { service: { write: { enabled: false } } }, name: "layerDefinition.maxScale", write: { layerContainerTypes: a } } };
var T = { json: { write: { ignoreOrigin: true, layerContainerTypes: a }, origins: { "web-map": { read: false, write: false } } } };
var I = { type: f, json: { name: "attributeTableInfo", write: true, origins: { "web-scene": { read: false, write: false } } } };

export {
  s,
  l,
  p,
  y,
  d,
  c,
  m,
  f2 as f,
  b,
  g2 as g,
  u,
  j,
  v,
  T,
  I
};
//# sourceMappingURL=chunk-AOJUXBCS.js.map
