import {
  c,
  c2,
  m as m3,
  u,
  u2
} from "./chunk-YUTTVJPP.js";
import {
  g as g2
} from "./chunk-MAJ7IL5K.js";
import {
  m as m2,
  s
} from "./chunk-Z4ITP2HY.js";
import {
  l
} from "./chunk-P6BYIY4S.js";
import {
  f
} from "./chunk-EXKRZGS6.js";
import {
  a as a2
} from "./chunk-J3AJBXLW.js";
import {
  p as p2
} from "./chunk-TAW5EJHA.js";
import {
  r as r2
} from "./chunk-Y4JUMKSA.js";
import {
  p
} from "./chunk-7PVOLFAH.js";
import {
  g
} from "./chunk-P5ELECBN.js";
import {
  o
} from "./chunk-TAT7XC7M.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a,
  w
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  n2 as n
} from "./chunk-JB56QM27.js";

// node_modules/@arcgis/core/rest/support/AttributeBinsQuery.js
var b = new o({ asc: "ascending", desc: "descending" });
var B = { base: u, key: "type", typeMap: { "auto-interval": c, date: u2, "fixed-boundaries": m3, "fixed-interval": c2 } };
var R = class extends a2.ClonableMixin(S) {
  constructor(e) {
    super(e), this.binParameters = null, this.binOrder = "ascending", this.cacheHint = void 0, this.datumTransformation = null, this.defaultSpatialReference = null, this.distance = void 0, this.geometry = null, this.lowerBoundaryAlias = null, this.outSpatialReference = null, this.outStatistics = null, this.returnDistinctValues = null, this.spatialRelationship = "intersects", this.timeExtent = null, this.upperBoundaryAlias = null, this.units = null, this.where = "1=1";
  }
  set outTimeZone(e) {
    this._set("outTimeZone", e), e && !p(e) && n.getLogger(this).warn("#outTimeZone", `the parsed value '${e}' may not be a valid IANA time zone`);
  }
};
r([m({ types: B, json: { name: "bin", write: true } })], R.prototype, "binParameters", void 0), r([r2(b)], R.prototype, "binOrder", void 0), r([m({ type: Boolean, json: { write: true } })], R.prototype, "cacheHint", void 0), r([m({ json: { write: true } })], R.prototype, "datumTransformation", void 0), r([m({ type: g, json: { name: "defaultSR", write: true } })], R.prototype, "defaultSpatialReference", void 0), r([m({ type: Number, json: { write: { overridePolicy: (e) => ({ enabled: e > 0 }) } } })], R.prototype, "distance", void 0), r([m({ types: l, json: { read: f, write: true } })], R.prototype, "geometry", void 0), r([m({ type: String, json: { write: true } })], R.prototype, "lowerBoundaryAlias", void 0), r([m({ type: g, json: { name: "outSR", write: true } })], R.prototype, "outSpatialReference", void 0), r([m({ type: [m2], json: { write: { enabled: true, overridePolicy() {
  return { enabled: null != this.outStatistics && this.outStatistics.length > 0 };
} } } })], R.prototype, "outStatistics", void 0), r([m({ value: null, json: { name: "outTimeReference", read: { reader: (e) => e.ianaTimeZone }, write: { writer: (e, t, o2) => {
  e && (t[o2] = { ianaTimeZone: e });
} } } })], R.prototype, "outTimeZone", null), r([m({ type: Boolean, json: { write: true } })], R.prototype, "returnDistinctValues", void 0), r([r2(s, { name: "spatialRel" })], R.prototype, "spatialRelationship", void 0), r([m({ type: p2, json: { write: true } })], R.prototype, "timeExtent", void 0), r([m({ type: String, json: { write: true } })], R.prototype, "upperBoundaryAlias", void 0), r([m({ type: String, json: { read: g2.read, write: { writer: g2.write, overridePolicy(e) {
  return { enabled: null != e && null != this.distance };
} } } })], R.prototype, "units", void 0), r([m({ type: String, json: { write: true } })], R.prototype, "where", void 0), R = r([a("esri.rest.support.AttributeBinsQuery")], R);
var T = R;
R.from = w(R);

export {
  T
};
//# sourceMappingURL=chunk-CYBG545K.js.map
