import {
  m as m2
} from "./chunk-4OCBID5S.js";
import {
  b
} from "./chunk-U3H4S3UY.js";
import {
  gt,
  wt
} from "./chunk-67TGT3ZY.js";
import {
  LitElement2 as LitElement,
  S,
  T,
  css,
  html,
  m,
  nothing,
  safeClassMap,
  svg
} from "./chunk-NMBGL4CC.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/components/calcite-icon/customElement.js
var P = {
  flipRtl: "flip-rtl"
};
var u = {};
var d = {};
var m3 = {
  s: 16,
  m: 24,
  l: 32
};
function b2({ icon: e, scale: t }) {
  const s = m3[t], i = L(e), n = i.charAt(i.length - 1) === "F";
  return `${n ? i.substring(0, i.length - 1) : i}${s}${n ? "F" : ""}`;
}
function O(e) {
  return __async(this, null, function* () {
    const t = b2(e), s = g(t);
    if (s)
      return s;
    d[t] || (d[t] = fetch(T(`./assets/icon/${t}.json`)).then((n) => n.json()).catch(() => (m2.error(`${e.icon} (${e.scale}) icon failed to load`), "")));
    const i = yield d[t];
    return u[t] = i, i;
  });
}
function U(e) {
  return g(b2(e));
}
function g(e) {
  return u[e];
}
function L(e) {
  const t = !isNaN(Number(e.charAt(0))), s = e.split("-");
  if (s.length > 0) {
    const n = /[a-z]/i;
    e = s.map((o, r) => o.replace(n, function(a, h) {
      return r === 0 && h === 0 ? a : a.toUpperCase();
    })).join("");
  }
  return t ? `i${e}` : e;
}
var R = css`:host{display:inline-flex;color:var(--calcite-icon-color, var(--calcite-ui-icon-color, currentColor))}:host([scale=s]){inline-size:16px;block-size:16px;min-inline-size:16px;min-block-size:16px}:host([scale=m]){inline-size:24px;block-size:24px;min-inline-size:24px;min-block-size:24px}:host([scale=l]){inline-size:32px;block-size:32px;min-inline-size:32px;min-block-size:32px}.flip-rtl{transform:scaleX(-1)}.svg{display:block}:host([hidden]){display:none}[hidden]{display:none}`;
var A = class extends LitElement {
  constructor() {
    super(...arguments), this.visible = false, this.flipRtl = false, this.icon = null, this.preload = false, this.scale = "m";
  }
  static {
    this.properties = { pathData: 16, visible: 16, flipRtl: 7, icon: 3, preload: 7, scale: 3, textLabel: 1 };
  }
  static {
    this.styles = R;
  }
  // #endregion
  // #region Lifecycle
  connectedCallback() {
    if (super.connectedCallback(), this.preload) {
      this.visible = true, this.loadIconPathData();
      return;
    }
    this.visible || this.waitUntilVisible(() => {
      this.visible = true, this.loadIconPathData();
    });
  }
  willUpdate(t) {
    (t.has("icon") && (this.hasUpdated || this.icon !== null) || t.has("scale") && (this.hasUpdated || this.scale !== "m")) && this.loadIconPathData();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.intersectionObserver?.disconnect(), this.intersectionObserver = null;
  }
  // #endregion
  // #region Private Methods
  loadIconPathData() {
    return __async(this, null, function* () {
      const { icon: t, scale: s, visible: i } = this;
      if (!m() || !t || !i)
        return;
      const n = { icon: t, scale: s }, o = U(n) || (yield O(n));
      t === this.icon && (this.pathData = o);
    });
  }
  waitUntilVisible(t) {
    if (this.intersectionObserver = b("intersection", (s) => {
      s.forEach((i) => {
        i.isIntersecting && (this.intersectionObserver.disconnect(), this.intersectionObserver = null, t());
      });
    }, { rootMargin: "50px" }), !this.intersectionObserver) {
      t();
      return;
    }
    this.intersectionObserver.observe(this.el);
  }
  // #endregion
  // #region Rendering
  render() {
    const { el: t, flipRtl: s, pathData: i, scale: n, textLabel: o } = this, r = gt(t), l = m3[n], a = !!o, h = [].concat(i || "");
    return this.el.ariaHidden = wt(!a), this.el.ariaLabel = a ? o : null, this.el.role = a ? "img" : null, html`<svg aria-hidden=true class=${safeClassMap({
      [P.flipRtl]: r === "rtl" && s,
      svg: true
    })} fill=currentColor height=100% viewBox=${`0 0 ${l} ${l}`} width=100% xmlns=http://www.w3.org/2000/svg>${h.map((c) => typeof c == "string" ? svg`<path d=${c ?? nothing} />` : svg`<path d=${c.d ?? nothing} opacity=${("opacity" in c ? c.opacity : 1) ?? nothing} />`)}</svg>`;
  }
};
S("calcite-icon", A);

export {
  A
};
/*! Bundled license information:

@esri/calcite-components/dist/components/calcite-icon/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-3EHTPQND.js.map
