import {
  S
} from "./chunk-TDZIOYA4.js";
import {
  y
} from "./chunk-YPRFDORJ.js";
import "./chunk-YDLYZSD6.js";
import "./chunk-CEREZWZ6.js";
import "./chunk-5BGQWKMP.js";
import "./chunk-PAXNBAQG.js";
import "./chunk-LYJYKR5U.js";
import "./chunk-N3UNX5HB.js";
import "./chunk-VACYGDXY.js";
import "./chunk-L3LR7QC5.js";
import "./chunk-MKDJERJR.js";
import "./chunk-O3P5XPEU.js";
import "./chunk-P5BI27MR.js";
import "./chunk-DTRN4OOH.js";
import "./chunk-3P3SZYCX.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-DSFF7UA2.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-XYTETMU6.js";
import "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/layers/CatalogLayerView.js
var i = (i2) => {
  let s = class extends i2 {
    constructor(...r2) {
      super(...r2), this.layerViews = new V();
    }
    get dynamicGroupLayerView() {
      return this.layerViews.find((r2) => r2.layer === this.layer?.dynamicGroupLayer);
    }
    get footprintLayerView() {
      return this.layerViews.find((r2) => r2.layer === this.layer?.footprintLayer);
    }
    isUpdating() {
      return !this.dynamicGroupLayerView || !this.footprintLayerView || this.dynamicGroupLayerView.updating || this.footprintLayerView.updating;
    }
  };
  return r([m()], s.prototype, "layer", void 0), r([m()], s.prototype, "layerViews", void 0), r([m({ readOnly: true })], s.prototype, "dynamicGroupLayerView", null), r([m({ readOnly: true })], s.prototype, "footprintLayerView", null), s = r([a("esri.views.layers.CatalogLayerView")], s), s;
};

// node_modules/@arcgis/core/views/2d/layers/CatalogLayerView2D.js
var l = class extends i(S(y)) {
  constructor() {
    super(...arguments), this.layerViews = new V();
  }
  update(e) {
  }
  viewChange() {
  }
  moveEnd() {
  }
  attach() {
    this.addAttachHandles([this._updatingHandles.addOnCollectionChange(() => this.layerViews, () => this._updateStageChildren(), { initial: true })]);
  }
  detach() {
    this.container.removeAllChildren();
  }
  _updateStageChildren() {
    this.container.removeAllChildren(), this.layerViews.forEach((e, r2) => this.container.addChildAt(e.container, r2));
  }
};
r([m()], l.prototype, "layerViews", void 0), l = r([a("esri.views.2d.layers.CatalogLayerView2D")], l);
var c = l;
export {
  c as default
};
//# sourceMappingURL=CatalogLayerView2D-NGF4CTID.js.map
