import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/support/lazyLayerLoader.js
var a = { BingMapsLayer: () => __async(void 0, null, function* () {
  return (yield import("./BingMapsLayer-FMX2GAYS.js")).default;
}), BuildingSceneLayer: () => __async(void 0, null, function* () {
  return (yield import("./BuildingSceneLayer-TMGDSOAI.js")).default;
}), CSVLayer: () => __async(void 0, null, function* () {
  return (yield import("./CSVLayer-F4DAIKXG.js")).default;
}), CatalogLayer: () => __async(void 0, null, function* () {
  return (yield import("./CatalogLayer-CY4A6QDL.js")).default;
}), DimensionLayer: () => __async(void 0, null, function* () {
  return (yield import("./DimensionLayer-J46I725I.js")).default;
}), ElevationLayer: () => __async(void 0, null, function* () {
  return (yield import("./ElevationLayer-OMPIM2L5.js")).default;
}), FeatureLayer: () => __async(void 0, null, function* () {
  return (yield import("./@arcgis_core_layers_FeatureLayer.js")).default;
}), GeoJSONLayer: () => __async(void 0, null, function* () {
  return (yield import("./GeoJSONLayer-EYUODCGK.js")).default;
}), GeoRSSLayer: () => __async(void 0, null, function* () {
  return (yield import("./GeoRSSLayer-43BLGRWU.js")).default;
}), GroupLayer: () => __async(void 0, null, function* () {
  return (yield import("./GroupLayer-TXTIVO2V.js")).default;
}), ImageryLayer: () => __async(void 0, null, function* () {
  return (yield import("./ImageryLayer-2AO42VP3.js")).default;
}), ImageryTileLayer: () => __async(void 0, null, function* () {
  return (yield import("./ImageryTileLayer-RWQMCMUY.js")).default;
}), IntegratedMesh3DTilesLayer: () => __async(void 0, null, function* () {
  return (yield import("./IntegratedMesh3DTilesLayer-ZZOLZIM4.js")).default;
}), IntegratedMeshLayer: () => __async(void 0, null, function* () {
  return (yield import("./IntegratedMeshLayer-UKWJKY3L.js")).default;
}), KMLLayer: () => __async(void 0, null, function* () {
  return (yield import("./KMLLayer-BMSEHOUB.js")).default;
}), KnowledgeGraphLayer: () => __async(void 0, null, function* () {
  return (yield import("./KnowledgeGraphLayer-M7XCM6WX.js")).default;
}), LineOfSightLayer: () => __async(void 0, null, function* () {
  return (yield import("./LineOfSightLayer-PIM7SOO7.js")).default;
}), LinkChartLayer: () => __async(void 0, null, function* () {
  return (yield import("./LinkChartLayer-DRDT2AAB.js")).default;
}), MapImageLayer: () => __async(void 0, null, function* () {
  return (yield import("./MapImageLayer-2OE4A7BE.js")).default;
}), MapNotesLayer: () => __async(void 0, null, function* () {
  return (yield import("./MapNotesLayer-B2KX2L3J.js")).default;
}), MediaLayer: () => __async(void 0, null, function* () {
  return (yield import("./MediaLayer-ARPWTXFJ.js")).default;
}), OGCFeatureLayer: () => __async(void 0, null, function* () {
  return (yield import("./OGCFeatureLayer-IPQG35OL.js")).default;
}), OpenStreetMapLayer: () => __async(void 0, null, function* () {
  return (yield import("./OpenStreetMapLayer-WHNS3FA5.js")).default;
}), OrientedImageryLayer: () => __async(void 0, null, function* () {
  return (yield import("./OrientedImageryLayer-VIZ2UNUM.js")).default;
}), PointCloudLayer: () => __async(void 0, null, function* () {
  return (yield import("./PointCloudLayer-JP2WYTK2.js")).default;
}), RouteLayer: () => __async(void 0, null, function* () {
  return (yield import("./RouteLayer-OAB6SA7X.js")).default;
}), SceneLayer: () => __async(void 0, null, function* () {
  return (yield import("./SceneLayer-HYK7P5ZZ.js")).default;
}), StreamLayer: () => __async(void 0, null, function* () {
  return (yield import("./StreamLayer-DD5MF22H.js")).default;
}), SubtypeGroupLayer: () => __async(void 0, null, function* () {
  return (yield import("./SubtypeGroupLayer-OIPEVPWL.js")).default;
}), TileLayer: () => __async(void 0, null, function* () {
  return (yield import("./TileLayer-DB6X3QIP.js")).default;
}), UnknownLayer: () => __async(void 0, null, function* () {
  return (yield import("./UnknownLayer-Y6RUVTNC.js")).default;
}), UnsupportedLayer: () => __async(void 0, null, function* () {
  return (yield import("./UnsupportedLayer-NNJVN4O6.js")).default;
}), VectorTileLayer: () => __async(void 0, null, function* () {
  return (yield import("./VectorTileLayer-52TZSIGO.js")).default;
}), VideoLayer: () => __async(void 0, null, function* () {
  return (yield import("./VideoLayer-CREOUVO2.js")).default;
}), ViewshedLayer: () => __async(void 0, null, function* () {
  return (yield import("./ViewshedLayer-UKUUXAJ2.js")).default;
}), VoxelLayer: () => __async(void 0, null, function* () {
  return (yield import("./VoxelLayer-3XKQ2QQ3.js")).default;
}), WCSLayer: () => __async(void 0, null, function* () {
  return (yield import("./WCSLayer-OMGCR5IJ.js")).default;
}), WFSLayer: () => __async(void 0, null, function* () {
  return (yield import("./WFSLayer-DEKDEPAP.js")).default;
}), WMSLayer: () => __async(void 0, null, function* () {
  return (yield import("./WMSLayer-DHJJRDO3.js")).default;
}), WMTSLayer: () => __async(void 0, null, function* () {
  return (yield import("./WMTSLayer-KRPTJYZJ.js")).default;
}), WebTileLayer: () => __async(void 0, null, function* () {
  return (yield import("./WebTileLayer-XDOKUTYM.js")).default;
}) };

export {
  a
};
//# sourceMappingURL=chunk-B6KUFXG7.js.map
