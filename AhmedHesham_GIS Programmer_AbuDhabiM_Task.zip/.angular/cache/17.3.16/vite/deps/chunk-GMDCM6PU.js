import {
  a as a3,
  c,
  i
} from "./chunk-55ETTKLO.js";
import {
  u
} from "./chunk-3X4RHLTI.js";
import {
  f,
  p,
  w
} from "./chunk-FMVDY4TM.js";
import {
  j2 as j,
  n,
  y
} from "./chunk-K2TU6MD2.js";
import {
  g,
  r as r2
} from "./chunk-P5ELECBN.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a
} from "./chunk-JB56QM27.js";
import {
  s
} from "./chunk-D5RIMQ7U.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/geometry/support/boundsUtils.js
function t(n3) {
  return void 0 !== n3.xmin && void 0 !== n3.ymin && void 0 !== n3.xmax && void 0 !== n3.ymax;
}
function i2(n3) {
  return void 0 !== n3.points;
}
function o(n3) {
  return void 0 !== n3.x && void 0 !== n3.y;
}
function e(n3) {
  return void 0 !== n3.paths;
}
function r3(n3) {
  return void 0 !== n3.rings;
}
function u2(n3) {
  function t4(t5, i4) {
    return null == t5 ? i4 : null == i4 ? t5 : n3(t5, i4);
  }
  return t4;
}
var l = u2(Math.min);
var h = u2(Math.max);
function a4(n3, u6) {
  return e(u6) ? x(n3, u6.paths, false, false) : r3(u6) ? x(n3, u6.rings, false, false) : i2(u6) ? g2(n3, u6.points, false, false, false, false) : t(u6) ? s2(n3, u6) : (o(u6) && (n3[0] = u6.x, n3[1] = u6.y, n3[2] = u6.x, n3[3] = u6.y), n3);
}
function c2(t4) {
  let i4, o4, e3, r6;
  for (t4.reset(), i4 = e3 = 1 / 0, o4 = r6 = -1 / 0; t4.nextPath(); ) {
    const n3 = f2(t4);
    i4 = Math.min(n3[0], i4), e3 = Math.min(n3[1], e3), o4 = Math.max(n3[2], o4), r6 = Math.max(n3[3], r6);
  }
  return u([i4, e3, o4, r6]);
}
function f2(t4) {
  let i4, o4, e3, r6;
  for (i4 = e3 = 1 / 0, o4 = r6 = -1 / 0; t4.nextPoint(); ) i4 = Math.min(t4.x, i4), e3 = Math.min(t4.y, e3), o4 = Math.max(t4.x, o4), r6 = Math.max(t4.y, r6);
  return u([i4, e3, o4, r6]);
}
function m2(n3, u6) {
  return e(u6) ? x(n3, u6.paths, true, false) : r3(u6) ? x(n3, u6.rings, true, false) : i2(u6) ? g2(n3, u6.points, true, false, true, false) : t(u6) ? s2(n3, u6, true, false, true, false) : (o(u6) && (n3[0] = u6.x, n3[1] = u6.y, n3[2] = u6.z, n3[3] = u6.x, n3[4] = u6.y, n3[5] = u6.z), n3);
}
function x(n3, t4, i4, o4) {
  const e3 = i4 ? 3 : 2;
  if (!t4.length || !t4[0].length) return null;
  let r6, u6, a6, c6, [f6, m5] = t4[0][0], [x5, s5] = t4[0][0];
  for (let g3 = 0; g3 < t4.length; g3++) {
    const n4 = t4[g3];
    for (let t5 = 0; t5 < n4.length; t5++) {
      const g4 = n4[t5], [y4, d3] = g4;
      if (f6 = l(f6, y4), m5 = l(m5, d3), x5 = h(x5, y4), s5 = h(s5, d3), i4 && g4.length > 2) {
        const n5 = g4[2];
        r6 = l(r6, n5), u6 = h(u6, n5);
      }
      if (o4 && g4.length > e3) {
        const n5 = g4[e3];
        a6 = l(r6, n5), c6 = h(u6, n5);
      }
    }
  }
  return i4 ? o4 ? (n3[0] = f6, n3[1] = m5, n3[2] = r6, n3[3] = a6, n3[4] = x5, n3[5] = s5, n3[6] = u6, n3[7] = c6, n3.length = 8, n3) : (n3[0] = f6, n3[1] = m5, n3[2] = r6, n3[3] = x5, n3[4] = s5, n3[5] = u6, n3.length = 6, n3) : o4 ? (n3[0] = f6, n3[1] = m5, n3[2] = a6, n3[3] = x5, n3[4] = s5, n3[5] = c6, n3.length = 6, n3) : (n3[0] = f6, n3[1] = m5, n3[2] = x5, n3[3] = s5, n3.length = 4, n3);
}
function s2(n3, t4, i4, o4, e3, r6) {
  const u6 = t4.xmin, l4 = t4.xmax, h5 = t4.ymin, a6 = t4.ymax;
  let c6 = t4.zmin, f6 = t4.zmax, m5 = t4.mmin, x5 = t4.mmax;
  return e3 ? (c6 = c6 || 0, f6 = f6 || 0, r6 ? (m5 = m5 || 0, x5 = x5 || 0, n3[0] = u6, n3[1] = h5, n3[2] = c6, n3[3] = m5, n3[4] = l4, n3[5] = a6, n3[6] = f6, n3[7] = x5, n3) : (n3[0] = u6, n3[1] = h5, n3[2] = c6, n3[3] = l4, n3[4] = a6, n3[5] = f6, n3)) : r6 ? (m5 = m5 || 0, x5 = x5 || 0, n3[0] = u6, n3[1] = h5, n3[2] = m5, n3[3] = l4, n3[4] = a6, n3[5] = x5, n3) : (n3[0] = u6, n3[1] = h5, n3[2] = l4, n3[3] = a6, n3);
}
function g2(n3, t4, i4, o4, e3, r6) {
  const u6 = i4 ? 3 : 2, a6 = o4 && r6, c6 = i4 && e3;
  if (!t4.length || !t4[0].length) return null;
  let f6, m5, x5, s5, [g3, y4] = t4[0], [d3, M] = t4[0];
  for (let v3 = 0; v3 < t4.length; v3++) {
    const n4 = t4[v3], [i5, o5] = n4;
    if (g3 = l(g3, i5), y4 = l(y4, o5), d3 = h(d3, i5), M = h(M, o5), c6 && n4.length > 2) {
      const t5 = n4[2];
      f6 = l(f6, t5), m5 = h(m5, t5);
    }
    if (a6 && n4.length > u6) {
      const t5 = n4[u6];
      x5 = l(f6, t5), s5 = h(m5, t5);
    }
  }
  return e3 ? (f6 = f6 || 0, m5 = m5 || 0, r6 ? (x5 = x5 || 0, s5 = s5 || 0, n3[0] = g3, n3[1] = y4, n3[2] = f6, n3[3] = x5, n3[4] = d3, n3[5] = M, n3[6] = m5, n3[7] = s5, n3) : (n3[0] = g3, n3[1] = y4, n3[2] = f6, n3[3] = d3, n3[4] = M, n3[5] = m5, n3)) : r6 ? (x5 = x5 || 0, s5 = s5 || 0, n3[0] = g3, n3[1] = y4, n3[2] = x5, n3[3] = d3, n3[4] = M, n3[5] = s5, n3) : (n3[0] = g3, n3[1] = y4, n3[2] = d3, n3[3] = M, n3);
}

// node_modules/@arcgis/core/geometry/geometryCursorCollectUtils.js
function t2(t4) {
  const n3 = [];
  for (t4.reset(); t4.nextPath(); ) {
    const e3 = [];
    for (; t4.nextPoint(); ) e3.push([t4.x, t4.y]);
    n3.push(e3);
  }
  return t4.reset(), n3;
}
function n2(t4) {
  const n3 = [];
  for (; t4.nextPoint(); ) n3.push([t4.x, t4.y]);
  return t4.seekPathStart(), n3;
}

// node_modules/@arcgis/core/geometry/support/centroid.js
function r4(t4) {
  return t4 ? t4.hasZ ? [t4.xmax - t4.xmin / 2, t4.ymax - t4.ymin / 2, t4.zmax - t4.zmin / 2] : [t4.xmax - t4.xmin / 2, t4.ymax - t4.ymin / 2] : null;
}
function l2(t4) {
  return t4 ? o2(t4.rings, t4.hasZ ?? false) : null;
}
function o2(t4, n3) {
  if (!t4?.length) return null;
  const e3 = [], r6 = [], l4 = n3 ? [1 / 0, -1 / 0, 1 / 0, -1 / 0, 1 / 0, -1 / 0] : [1 / 0, -1 / 0, 1 / 0, -1 / 0];
  for (let o4 = 0, i4 = t4.length; o4 < i4; o4++) {
    const e4 = u3(t4[o4], n3, l4);
    e4 && r6.push(e4);
  }
  if (r6.sort((t5, e4) => {
    let r7 = t5[2] - e4[2];
    return 0 === r7 && n3 && (r7 = t5[4] - e4[4]), r7;
  }), r6.length && (e3[0] = r6[0][0], e3[1] = r6[0][1], n3 && (e3[2] = r6[0][3]), (e3[0] < l4[0] || e3[0] > l4[1] || e3[1] < l4[2] || e3[1] > l4[3] || n3 && (e3[2] < l4[4] || e3[2] > l4[5])) && (e3.length = 0)), !e3.length) {
    const r7 = t4[0] && t4[0].length ? s3(t4[0], n3) : null;
    if (!r7) return null;
    e3[0] = r7[0], e3[1] = r7[1], n3 && r7.length > 2 && (e3[2] = r7[2]);
  }
  return e3;
}
function u3(t4, n3, e3) {
  let r6 = 0, l4 = 0, o4 = 0, u6 = 0, i4 = 0;
  const s5 = t4.length ? t4[0][0] : 0, I2 = t4.length ? t4[0][1] : 0, h5 = t4.length && n3 ? t4[0][2] : 0;
  for (let f6 = 0; f6 < t4.length; f6++) {
    const c7 = t4[f6], N2 = t4[(f6 + 1) % t4.length], [x5, g3, a6] = c7, m5 = x5 - s5, P2 = g3 - I2, [T, y4, E] = N2, S = T - s5, p2 = y4 - I2, z = m5 * p2 - S * P2;
    if (u6 += z, r6 += (m5 + S) * z, l4 += (P2 + p2) * z, n3 && c7.length > 2 && N2.length > 2) {
      const t5 = a6 - h5, n4 = E - h5, e4 = m5 * n4 - S * t5;
      o4 += (t5 + n4) * e4, i4 += e4;
    }
    x5 < e3[0] && (e3[0] = x5), x5 > e3[1] && (e3[1] = x5), g3 < e3[2] && (e3[2] = g3), g3 > e3[3] && (e3[3] = g3), n3 && (a6 < e3[4] && (e3[4] = a6), a6 > e3[5] && (e3[5] = a6));
  }
  if (u6 > 0 && (u6 *= -1), i4 > 0 && (i4 *= -1), !u6) return null;
  u6 *= 0.5, i4 *= 0.5;
  const c6 = [r6 / (6 * u6) + s5, l4 / (6 * u6) + I2, u6];
  return n3 && (e3[4] === e3[5] || 0 === i4 ? (c6[3] = (e3[4] + e3[5]) / 2, c6[4] = 0) : (c6[3] = o4 / (6 * i4) + h5, c6[4] = i4)), c6;
}
function i3(t4, n3) {
  let e3 = 0, r6 = 0, l4 = 0;
  t4.nextPoint();
  const o4 = t4.pathSize ? t4.x : 0, u6 = t4.pathSize ? t4.y : 0;
  for (let i4 = 0; i4 < t4.pathSize; i4++) {
    t4.seekInPath(i4);
    const s5 = [t4.x, t4.y];
    t4.seekInPath((i4 + 1) % t4.pathSize);
    const I2 = [t4.x, t4.y], [h5, c6] = s5, f6 = h5 - o4, N2 = c6 - u6, [x5, g3] = I2, a6 = x5 - o4, m5 = g3 - u6, P2 = f6 * m5 - a6 * N2;
    l4 += P2, e3 += (f6 + a6) * P2, r6 += (N2 + m5) * P2, h5 < n3[0] && (n3[0] = h5), h5 > n3[1] && (n3[1] = h5), c6 < n3[2] && (n3[2] = c6), c6 > n3[3] && (n3[3] = c6);
  }
  if (l4 > 0 && (l4 *= -1), !l4) return null;
  l4 *= 0.5;
  return [e3 / (6 * l4) + o4, r6 / (6 * l4) + u6, l4];
}
function s3(t4, r6) {
  const l4 = r6 ? [0, 0, 0] : [0, 0], o4 = r6 ? [0, 0, 0] : [0, 0];
  let u6 = 0, i4 = 0, s5 = 0, I2 = 0;
  for (let h5 = 0, c6 = t4.length; h5 < c6 - 1; h5++) {
    const c7 = t4[h5], f6 = t4[h5 + 1];
    if (c7 && f6) {
      l4[0] = c7[0], l4[1] = c7[1], o4[0] = f6[0], o4[1] = f6[1], r6 && c7.length > 2 && f6.length > 2 && (l4[2] = c7[2], o4[2] = f6[2]);
      const t5 = i(l4, o4);
      if (t5) {
        u6 += t5;
        const n3 = c(c7, f6);
        i4 += t5 * n3[0], s5 += t5 * n3[1], r6 && n3.length > 2 && (I2 += t5 * n3[2]);
      }
    }
  }
  return u6 > 0 ? r6 ? [i4 / u6, s5 / u6, I2 / u6] : [i4 / u6, s5 / u6] : t4.length ? t4[0] : null;
}
function I(n3) {
  const { hasZ: e3, totalSize: r6 } = n3;
  if (0 === r6) return null;
  const l4 = [], o4 = [], i4 = e3 ? [Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY] : [Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY];
  for (n3.reset(); n3.nextPath(); ) {
    const e4 = u3(n2(n3), n3.hasZ, i4);
    e4 && o4.push(e4);
  }
  if (o4.sort((t4, n4) => {
    let r7 = t4[2] - n4[2];
    return 0 === r7 && e3 && (r7 = t4[4] - n4[4]), r7;
  }), o4.length && (l4[0] = o4[0][0], l4[1] = o4[0][1], e3 && (l4[2] = o4[0][3]), (l4[0] < i4[0] || l4[0] > i4[1] || l4[1] < i4[2] || l4[1] > i4[3] || e3 && (l4[2] < i4[4] || l4[2] > i4[5])) && (l4.length = 0)), !l4.length) {
    n3.reset(), n3.nextPath();
    const t4 = n3.pathSize ? h2(n3) : null;
    if (!t4) return null;
    l4[0] = t4[0], l4[1] = t4[1], e3 && t4.length > 2 && (l4[2] = t4[2]);
  }
  return l4;
}
function h2(t4) {
  const { hasZ: r6 } = t4, l4 = r6 ? [0, 0, 0] : [0, 0], o4 = r6 ? [0, 0, 0] : [0, 0];
  let u6 = 0, i4 = 0, s5 = 0, I2 = 0;
  if (t4.nextPoint()) {
    let h5 = t4.x, c6 = t4.y, f6 = t4.z;
    for (; t4.nextPoint(); ) {
      const N2 = t4.x, x5 = t4.y, g3 = t4.z;
      l4[0] = h5, l4[1] = c6, o4[0] = N2, o4[1] = x5, r6 && (l4[2] = f6, o4[2] = g3);
      const a6 = i(l4, o4);
      if (a6) {
        u6 += a6;
        const t5 = c(l4, o4);
        i4 += a6 * t5[0], s5 += a6 * t5[1], r6 && t5.length > 2 && (I2 += a6 * t5[2]);
      }
      h5 = N2, c6 = x5, f6 = g3;
    }
  }
  return u6 > 0 ? r6 ? [i4 / u6, s5 / u6, I2 / u6] : [i4 / u6, s5 / u6] : t4.pathSize ? (t4.seekPathStart(), t4.nextPoint(), [t4.x, t4.y]) : null;
}
var c3 = 1e-6;
function f3(t4) {
  let n3 = 0;
  for (t4.reset(); t4.nextPath(); ) n3 += t4.getCurrentRingArea();
  if (n3 < c3) {
    const n4 = I(t4);
    return n4 ? [n4[0], n4[1]] : null;
  }
  const e3 = [0, 0];
  if (t4.reset(), !t4.nextPath() || !t4.nextPoint()) return null;
  const r6 = [t4.x, t4.y];
  for (t4.reset(); t4.nextPath(); ) x2(e3, r6, t4);
  return e3[0] *= 1 / n3, e3[1] *= 1 / n3, e3[0] += r6[0], e3[1] += r6[1], e3;
}
var N = 1 / 3;
function x2(t4, n3, e3) {
  if (!e3 || e3.pathSize < 3) return null;
  e3.nextPoint();
  const r6 = e3.x, l4 = e3.y;
  e3.nextPoint();
  let o4, u6 = e3.x - r6, i4 = e3.y - l4, s5 = 0, I2 = 0;
  for (; e3.nextPoint(); ) s5 = e3.x - r6, I2 = e3.y - l4, o4 = 0.5 * N * (s5 * i4 - I2 * u6), t4[0] += o4 * (u6 + s5), t4[1] += o4 * (i4 + I2), u6 = s5, i4 = I2;
  const h5 = e3.getCurrentRingArea(), c6 = [r6, l4];
  return c6[0] -= n3[0], c6[1] -= n3[1], c6[0] *= h5, c6[1] *= h5, t4[0] += c6[0], t4[1] += c6[1], t4;
}

// node_modules/@arcgis/core/geometry/support/extentUtils.js
function t3(n3) {
  return void 0 !== n3.xmin && void 0 !== n3.ymin && void 0 !== n3.xmax && void 0 !== n3.ymax;
}
function u4(n3) {
  return void 0 !== n3.points;
}
function m3(n3) {
  return void 0 !== n3.x && void 0 !== n3.y;
}
function o3(n3) {
  return void 0 !== n3.paths;
}
function r5(n3) {
  return void 0 !== n3.rings;
}
var x3 = [];
function a5(n3, i4, t4, u6) {
  return { xmin: n3, ymin: i4, xmax: t4, ymax: u6 };
}
function c4(n3, i4, t4, u6, m5, o4) {
  return { xmin: n3, ymin: i4, zmin: t4, xmax: u6, ymax: m5, zmax: o4 };
}
function s4(n3, i4, t4, u6, m5, o4) {
  return { xmin: n3, ymin: i4, mmin: t4, xmax: u6, ymax: m5, mmax: o4 };
}
function e2(n3, i4, t4, u6, m5, o4, r6, x5) {
  return { xmin: n3, ymin: i4, zmin: t4, mmin: u6, xmax: m5, ymax: o4, zmax: r6, mmax: x5 };
}
function f4(n3, i4 = false, t4 = false) {
  return i4 ? t4 ? e2(n3[0], n3[1], n3[2], n3[3], n3[4], n3[5], n3[6], n3[7]) : c4(n3[0], n3[1], n3[2], n3[3], n3[4], n3[5]) : t4 ? s4(n3[0], n3[1], n3[2], n3[3], n3[4], n3[5]) : a5(n3[0], n3[1], n3[2], n3[3]);
}
function l3(n3) {
  return n3 ? t3(n3) ? n3 : m3(n3) ? d(n3) : r5(n3) ? v(n3) : o3(n3) ? h3(n3) : u4(n3) ? y2(n3) : null : null;
}
function y2(i4) {
  const { hasZ: t4, hasM: u6, points: m5 } = i4;
  return f4(g2(x3, m5, t4 ?? false, u6 ?? false), t4, u6);
}
function d(n3) {
  const { x: i4, y: t4, z: u6, m: m5 } = n3, o4 = null != m5;
  return null != u6 ? o4 ? e2(i4, t4, u6, m5, i4, t4, u6, m5) : c4(i4, t4, u6, i4, t4, u6) : o4 ? s4(i4, t4, m5, i4, t4, m5) : a5(i4, t4, i4, t4);
}
function v(n3) {
  const { hasZ: t4, hasM: u6, rings: m5 } = n3, o4 = x(x3, m5, t4 ?? false, u6 ?? false);
  return o4 ? f4(o4, t4, u6) : null;
}
function h3(n3) {
  const { hasZ: t4, hasM: u6, paths: m5 } = n3, o4 = x(x3, m5, t4 ?? false, u6 ?? false);
  return o4 ? f4(o4, t4, u6) : null;
}

// node_modules/@arcgis/core/geometry/support/zmUtils.js
function h4(h5, a6, s5 = false) {
  let { hasM: t4, hasZ: e3 } = h5;
  Array.isArray(a6) ? 4 !== a6.length || t4 || e3 ? 3 === a6.length && s5 && !t4 ? (e3 = true, t4 = false) : 3 === a6.length && t4 && e3 && (t4 = false, e3 = false) : (t4 = true, e3 = true) : (e3 = !e3 && a6.hasZ && (!t4 || a6.hasM), t4 = !t4 && a6.hasM && (!e3 || a6.hasZ)), h5.hasZ = e3, h5.hasM = t4;
}

// node_modules/@arcgis/core/geometry/Polygon.js
var R;
function d2(t4) {
  return !Array.isArray(t4[0]);
}
function w2(t4) {
  return "number" == typeof t4[0]?.[0];
}
function v2(t4) {
  if (!t4) return;
  let { rings: e3, hasM: r6, hasZ: s5, spatialReference: i4 } = t4;
  switch (e3 ??= [], w2(e3) && (e3 = [e3]), e3[0]?.[0]?.length) {
    case 4:
      s5 ??= true, r6 ??= true;
      break;
    case 3:
      s5 ??= true !== r6, r6 ??= !s5;
      break;
    default:
      s5 ??= false, r6 ??= false;
  }
  return i4 ??= g.WGS84, __spreadProps(__spreadValues({}, t4), { hasM: r6, hasZ: s5, rings: e3, spatialReference: i4 });
}
var x4 = R = class extends n {
  static fromExtent(t4) {
    const e3 = t4.clone().normalize(), { spatialReference: r6 } = t4;
    let s5 = false, i4 = false;
    for (const o4 of e3) o4.hasZ && (s5 = true), o4.hasM && (i4 = true);
    const n3 = { rings: e3.map((t5) => {
      const e4 = [[t5.xmin, t5.ymin], [t5.xmin, t5.ymax], [t5.xmax, t5.ymax], [t5.xmax, t5.ymin], [t5.xmin, t5.ymin]];
      if (s5 && t5.hasZ) {
        const r7 = t5.zmin + 0.5 * (t5.zmax - t5.zmin);
        for (let t6 = 0; t6 < e4.length; t6++) e4[t6].push(r7);
      }
      if (i4 && t5.hasM) {
        const r7 = t5.mmin + 0.5 * (t5.mmax - t5.mmin);
        for (let t6 = 0; t6 < e4.length; t6++) e4[t6].push(r7);
      }
      return e4;
    }), spatialReference: r6 };
    return s5 && (n3.hasZ = true), i4 && (n3.hasM = true), new R(n3);
  }
  constructor(t4) {
    super(v2(t4)), this.curveRings = void 0, this.rings = [], this.type = "polygon";
  }
  get cache() {
    return this.commitProperty("curveRings"), this.commitProperty("hasM"), this.commitProperty("hasZ"), this.commitProperty("rings"), this.commitProperty("spatialReference"), {};
  }
  get centroid() {
    const t4 = l2(this);
    if (!t4 || isNaN(t4[0]) || isNaN(t4[1]) || this.hasZ && isNaN(t4[2])) return null;
    const e3 = new j();
    return e3.x = t4[0], e3.y = t4[1], e3.spatialReference = this.spatialReference, this.hasZ && (e3.z = t4[2]), e3;
  }
  writeCurveRings(t4, e3) {
    e3.curveRings = a(t4);
  }
  get extent() {
    const t4 = v(this), { spatialReference: e3 } = this;
    return t4 ? new w(__spreadProps(__spreadValues({}, t4), { spatialReference: e3 })) : null;
  }
  get isSelfIntersecting() {
    return p(this.rings);
  }
  writeRings(t4, e3) {
    e3.rings = a(this.rings);
  }
  addRing(t4) {
    if (!t4) return;
    const e3 = this.rings, r6 = e3.length;
    if (d2(t4)) {
      const s5 = [];
      for (let e4 = 0, r7 = t4.length; e4 < r7; e4++) s5[e4] = t4[e4].toArray();
      e3[r6] = s5;
    } else e3[r6] = t4.slice();
    return this.notifyChange("rings"), this;
  }
  clone() {
    const t4 = new R();
    return t4.spatialReference = this.spatialReference, t4.rings = a(this.rings), t4.curveRings = a(this.curveRings), t4.hasZ = this.hasZ, t4.hasM = this.hasM, t4;
  }
  equals(t4) {
    if (this === t4) return true;
    if (null == t4) return false;
    const r6 = this.spatialReference, s5 = t4.spatialReference;
    if (null != r6 != (null != s5)) return false;
    if (null != r6 && null != s5 && !r6.equals(s5)) return false;
    if (this.rings.length !== t4.rings.length) return false;
    const i4 = ([t5, e3, r7, s6], [i5, n3, o4, a6]) => t5 === i5 && e3 === n3 && (null == r7 && null == o4 || r7 === o4) && (null == s6 && null == a6 || s6 === a6);
    for (let n3 = 0; n3 < this.rings.length; n3++) {
      const r7 = this.rings[n3], s6 = t4.rings[n3];
      if (!s(r7, s6, i4)) return false;
    }
    return true;
  }
  contains(t4) {
    if (!t4) return false;
    const e3 = y(t4, this.spatialReference);
    return f(this, null != e3 ? e3 : t4);
  }
  isClockwise(t4) {
    const e3 = d2(t4) ? t4.map((t5) => this.hasZ ? this.hasM ? [t5.x, t5.y, t5.z, t5.m] : [t5.x, t5.y, t5.z] : [t5.x, t5.y]) : t4;
    return a3(e3);
  }
  getPoint(t4, e3) {
    if (!this._validateInputs(t4, e3)) return null;
    const r6 = this.rings[t4][e3], s5 = this.hasZ, i4 = this.hasM;
    return s5 && !i4 ? new j(r6[0], r6[1], r6[2], void 0, this.spatialReference) : i4 && !s5 ? new j(r6[0], r6[1], void 0, r6[2], this.spatialReference) : s5 && i4 ? new j(r6[0], r6[1], r6[2], r6[3], this.spatialReference) : new j(r6[0], r6[1], this.spatialReference);
  }
  insertPoint(t4, e3, r6) {
    return this._validateInputs(t4, e3, true) ? (h4(this, r6), Array.isArray(r6) || (r6 = r6.toArray()), this.rings[t4].splice(e3, 0, r6), this.notifyChange("rings"), this) : this;
  }
  removePoint(t4, e3) {
    if (!this._validateInputs(t4, e3)) return null;
    const r6 = new j(this.rings[t4].splice(e3, 1)[0], this.spatialReference);
    return this.notifyChange("rings"), r6;
  }
  removeRing(t4) {
    if (!this._validateInputs(t4, null)) return null;
    const e3 = this.rings.splice(t4, 1)[0], r6 = this.spatialReference, s5 = e3.map((t5) => new j(t5, r6));
    return this.notifyChange("rings"), s5;
  }
  setPoint(t4, e3, r6) {
    return this._validateInputs(t4, e3) ? (h4(this, r6), Array.isArray(r6) || (r6 = r6.toArray()), this.rings[t4][e3] = r6, this.notifyChange("rings"), this) : this;
  }
  _validateInputs(t4, e3, r6 = false) {
    if (null == t4 || t4 < 0 || t4 >= this.rings.length) return false;
    if (null != e3) {
      const s5 = this.rings[t4];
      if (r6 && (e3 < 0 || e3 > s5.length)) return false;
      if (!r6 && (e3 < 0 || e3 >= s5.length)) return false;
    }
    return true;
  }
  toJSON(t4) {
    return this.write({}, t4);
  }
};
r([m({ readOnly: true })], x4.prototype, "cache", null), r([m({ readOnly: true })], x4.prototype, "centroid", null), r([m({ json: { write: true, origins: { "portal-item": { write: false }, "web-map": { write: false }, "web-scene": { write: false } } } })], x4.prototype, "curveRings", void 0), r([r2("curveRings")], x4.prototype, "writeCurveRings", null), r([m({ readOnly: true })], x4.prototype, "extent", null), r([m({ readOnly: true })], x4.prototype, "isSelfIntersecting", null), r([m({ type: [[[Number]]], json: { write: { isRequired: true } } })], x4.prototype, "rings", void 0), r([r2("rings")], x4.prototype, "writeRings", null), x4 = R = r([a2("esri.geometry.Polygon")], x4);
var j2 = x4;
x4.prototype.toJSON.isDefaultToJSON = true;

// node_modules/@arcgis/core/geometry/Polyline.js
var c5;
function u5(t4) {
  return !Array.isArray(t4[0]);
}
function f5(t4) {
  return "number" == typeof t4[0]?.[0];
}
function m4(t4) {
  if (!t4) return;
  let { paths: e3, hasM: s5, hasZ: r6, spatialReference: i4 } = t4;
  switch (e3 ??= [], f5(e3) && (e3 = [e3]), e3[0]?.[0]?.length) {
    case 4:
      r6 ??= true, s5 ??= true;
      break;
    case 3:
      r6 ??= true !== s5, s5 ??= !r6;
      break;
    default:
      r6 ??= false, s5 ??= false;
  }
  return i4 ??= g.WGS84, __spreadProps(__spreadValues({}, t4), { hasM: s5, hasZ: r6, paths: e3, spatialReference: i4 });
}
var y3 = c5 = class extends n {
  constructor(t4) {
    super(m4(t4)), this.curvePaths = void 0, this.paths = [], this.type = "polyline";
  }
  get cache() {
    return this.commitProperty("curvePaths"), this.commitProperty("hasM"), this.commitProperty("hasZ"), this.commitProperty("paths"), this.commitProperty("spatialReference"), {};
  }
  writeCurvePaths(t4, s5) {
    s5.curvePaths = a(t4);
  }
  get extent() {
    const t4 = h3(this), { spatialReference: e3 } = this;
    return t4 ? new w(__spreadProps(__spreadValues({}, t4), { spatialReference: e3 })) : null;
  }
  writePaths(t4, s5) {
    s5.paths = a(this.paths);
  }
  addPath(t4) {
    if (!t4) return;
    const e3 = this.paths, s5 = e3.length;
    if (u5(t4)) {
      const r6 = [];
      for (let e4 = 0, s6 = t4.length; e4 < s6; e4++) r6[e4] = t4[e4].toArray();
      e3[s5] = r6;
    } else e3[s5] = t4.slice();
    return this.notifyChange("paths"), this;
  }
  clone() {
    const t4 = new c5();
    return t4.spatialReference = this.spatialReference, t4.paths = a(this.paths), t4.curvePaths = a(this.curvePaths), t4.hasZ = this.hasZ, t4.hasM = this.hasM, t4;
  }
  getPoint(t4, e3) {
    if (!this._validateInputs(t4, e3)) return null;
    const s5 = this.paths[t4][e3], r6 = this.hasZ, i4 = this.hasM;
    return r6 && !i4 ? new j(s5[0], s5[1], s5[2], void 0, this.spatialReference) : i4 && !r6 ? new j(s5[0], s5[1], void 0, s5[2], this.spatialReference) : r6 && i4 ? new j(s5[0], s5[1], s5[2], s5[3], this.spatialReference) : new j(s5[0], s5[1], this.spatialReference);
  }
  insertPoint(t4, e3, s5) {
    return this._validateInputs(t4, e3, true) ? (h4(this, s5), Array.isArray(s5) || (s5 = s5.toArray()), this.paths[t4].splice(e3, 0, s5), this.notifyChange("paths"), this) : this;
  }
  removePath(t4) {
    if (!this._validateInputs(t4, null)) return null;
    const e3 = this.paths.splice(t4, 1)[0], s5 = this.spatialReference, r6 = e3.map((t5) => new j(t5, s5));
    return this.notifyChange("paths"), r6;
  }
  removePoint(t4, e3) {
    if (!this._validateInputs(t4, e3)) return null;
    const s5 = new j(this.paths[t4].splice(e3, 1)[0], this.spatialReference);
    return this.notifyChange("paths"), s5;
  }
  setPoint(t4, e3, s5) {
    return this._validateInputs(t4, e3) ? (h4(this, s5), Array.isArray(s5) || (s5 = s5.toArray()), this.paths[t4][e3] = s5, this.notifyChange("paths"), this) : this;
  }
  _validateInputs(t4, e3, s5 = false) {
    if (null == t4 || t4 < 0 || t4 >= this.paths.length) return false;
    if (null != e3) {
      const r6 = this.paths[t4];
      if (s5 && (e3 < 0 || e3 > r6.length)) return false;
      if (!s5 && (e3 < 0 || e3 >= r6.length)) return false;
    }
    return true;
  }
  toJSON(t4) {
    return this.write({}, t4);
  }
};
r([m({ readOnly: true })], y3.prototype, "cache", null), r([m({ json: { write: true, origins: { "portal-item": { write: false }, "web-map": { write: false }, "web-scene": { write: false } } } })], y3.prototype, "curvePaths", void 0), r([r2("curvePaths")], y3.prototype, "writeCurvePaths", null), r([m({ readOnly: true })], y3.prototype, "extent", null), r([m({ type: [[[Number]]], json: { write: { isRequired: true } } })], y3.prototype, "paths", void 0), r([r2("paths")], y3.prototype, "writePaths", null), y3 = c5 = r([a2("esri.geometry.Polyline")], y3);
var P = y3;
y3.prototype.toJSON.isDefaultToJSON = true;

export {
  h4 as h,
  t2 as t,
  n2 as n,
  r4 as r,
  l2 as l,
  o2 as o,
  i3 as i,
  f3 as f,
  a4 as a,
  c2 as c,
  f2,
  m2 as m,
  x,
  l3 as l2,
  v,
  j2 as j,
  P
};
//# sourceMappingURL=chunk-GMDCM6PU.js.map
