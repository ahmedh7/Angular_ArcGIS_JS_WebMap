import {
  g,
  u
} from "./chunk-EMGBZTFR.js";
import {
  s2 as s
} from "./chunk-JB56QM27.js";
import {
  G
} from "./chunk-D5RIMQ7U.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/renderers/support/rendererConversion.js
function s2(r) {
  return null == r || "simple" === r.type || "unique-value" === r.type || "class-breaks" === r.type || "dictionary" === r.type || "heatmap" === r.type;
}
function t(r, n) {
  if (null == r) return null;
  if (!s2(r)) return new s("renderer-conversion-3d:unsupported-renderer", `Unsupported renderer of type '${r.type || r.declaredClass}'`, { renderer: r });
  switch (r.type) {
    case "simple":
      return a(r, n);
    case "unique-value":
      return u2(r, n);
    case "class-breaks":
      return i(r, n);
    case "dictionary":
    case "heatmap":
      return null;
  }
  return null;
}
function l(r, n) {
  if (!n) return null;
  if (Array.isArray(n) || (n = [n]), n.length > 0) {
    const o = n.map((r2) => r2.details.symbol.type || r2.details.symbol.declaredClass).filter((r2) => !!r2);
    o.sort();
    const s3 = new Array();
    return o.forEach((r2, e) => {
      0 !== e && r2 === o[e - 1] || s3.push(r2);
    }), new s("renderer-conversion-3d:unsupported-symbols", `Renderer contains symbols (${s3.join(", ")}) which are not supported in 3D`, { renderer: r, symbolErrors: n });
  }
  return null;
}
function a(r, e) {
  const s3 = __spreadProps(__spreadValues(__spreadValues({}, g), e), { cimFallbackEnabled: true });
  return l(r, u(r.symbol, s3).error);
}
function u2(e, s3) {
  const t2 = __spreadProps(__spreadValues(__spreadValues({}, g), s3), { cimFallbackEnabled: true }), a2 = e.uniqueValueInfos?.map((r) => u(r.symbol, t2).error).filter(G), u3 = u(e.defaultSymbol, t2);
  return u3.error && a2?.unshift(u3.error), l(e, a2);
}
function i(e, s3) {
  const t2 = __spreadProps(__spreadValues(__spreadValues({}, g), s3), { cimFallbackEnabled: true }), a2 = e.classBreakInfos.map((r) => u(r.symbol, t2).error).filter(G), u3 = u(e.defaultSymbol, t2);
  return u3.error && a2.unshift(u3.error), l(e, a2);
}

export {
  s2 as s,
  t
};
//# sourceMappingURL=chunk-ANBDVZMM.js.map
