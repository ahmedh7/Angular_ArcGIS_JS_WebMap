import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/Float3PassUniform.js
var e = class extends i {
  constructor(s, e2) {
    super(s, "vec3", a.Pass, (r, o, t) => r.setUniform3fv(s, e2(o, t)));
  }
};

export {
  e
};
//# sourceMappingURL=chunk-4WQG2466.js.map
