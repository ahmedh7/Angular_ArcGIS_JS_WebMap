import {
  h
} from "./chunk-423ORWJN.js";
import "./chunk-GGHSCUSN.js";
import "./chunk-U3H4S3UY.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-HZUW4HM7.js";
export {
  h as DropdownGroup
};
//# sourceMappingURL=calcite-dropdown-group-KHQP6LCC.js.map
