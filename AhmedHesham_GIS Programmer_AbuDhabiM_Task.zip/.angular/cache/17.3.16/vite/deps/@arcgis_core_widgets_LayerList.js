import {
  O as O2
} from "./chunk-4JZKYSSB.js";
import {
  I,
  N,
  e as e5,
  f,
  h,
  i as i2,
  m as m2,
  q,
  s as s2,
  t,
  u,
  v as v2
} from "./chunk-GTVPP55O.js";
import "./chunk-OFAEEHL4.js";
import {
  s
} from "./chunk-3P3SZYCX.js";
import "./chunk-YHKJPCKF.js";
import {
  e as e4
} from "./chunk-DSFF7UA2.js";
import "./chunk-JYALIYUG.js";
import {
  e as e3
} from "./chunk-HL6SQA2H.js";
import "./chunk-ECG7JDDX.js";
import "./chunk-NE6ESLWJ.js";
import {
  e as e2
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c,
  e
} from "./chunk-PPAPRIQT.js";
import {
  n2 as n
} from "./chunk-L7IGKLK6.js";
import {
  T
} from "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import "./chunk-723TUEOK.js";
import {
  n as n2
} from "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import {
  P,
  d,
  v
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  i
} from "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/LayerList/css.js
var t2 = "esri-layer-list";
var i3 = `${t2}__item`;
var e6 = { base: t2, actionMenu: `${t2}__action-menu`, actionGroup: `${t2}__action-group`, filterNoResults: `${t2}__filter-no-results`, item: i3, itemActive: `${i3}--active`, itemContentBottom: `${i3}-content-bottom`, itemMessage: `${i3}-message`, itemActionIcon: `${i3}-action-icon`, itemActionImage: `${i3}-action-image`, itemTemporaryIcon: `${i3}-temporary-icon`, itemTableIcon: `${i3}-table-icon`, itemCatalogIcon: `${i3}-catalog-icon`, statusIndicator: `${t2}__status-indicator`, publishing: `${t2}__publishing`, updating: `${t2}__updating`, connectionStatus: `${t2}__connection-status`, connectionStatusConnected: `${t2}__connection-status--connected`, visibleToggle: `${t2}__visible-toggle`, visibleIcon: `${t2}__visible-icon` };

// node_modules/@arcgis/core/widgets/LayerList/LayerListViewModel.js
var m3 = { view: "view", viewLayers: "view-layers", mapLayers: "map-layers", layerViews: "layer-views", layerListMode: "layer-list-mode" };
var c2 = "hide";
var p = V.ofType(O2);
var y = class extends i.EventedAccessor {
  constructor(e7) {
    super(e7), this.checkPublishStatusEnabled = false, this.listItemCreatedFunction = null, this.listModeDisabled = false, this.operationalItems = new p(), this.view = null;
  }
  initialize() {
    this.addHandles([d(() => true === this.view?.ready, () => this._viewHandles(), P), d(() => [this.listItemCreatedFunction, this.checkPublishStatusEnabled, this.listModeDisabled], () => this._recompileList()), d(() => e4(this.view) ? this.view.inGeographicLayout : null, () => this._compileList())], m3.view);
  }
  destroy() {
    this._removeAllItems(), this.view = null;
  }
  get state() {
    const { view: e7 } = this;
    return e7?.ready ? "ready" : e7 ? "loading" : "disabled";
  }
  get totalItems() {
    return this.operationalItems.flatten((e7) => e7.children).length;
  }
  triggerAction(e7, t3) {
    e7 && !e7.disabled && this.emit("trigger-action", { action: e7, item: t3 });
  }
  moveListItem(e7, t3, s4, i4) {
    const r2 = e7?.layer;
    if (!r2 || "subtype-sublayer" === r2.type || "sublayer" === r2.type) return;
    const a2 = this.view?.map?.layers, o = t3 ? m2(t3) : a2, l2 = s4 ? m2(s4) : a2;
    if (!o || !l2) return;
    const { operationalItems: n3 } = this, h2 = t3?.children || n3, m4 = s4?.children || n3, c3 = l2.length - i4;
    e7.parent = s4 || null, h2.remove(e7), o.remove(r2), m4.includes(e7) || m4.add(e7, c3), l2.includes(r2) || l2.add(r2, c3), this._compileList();
  }
  _createLayerViewHandles(e7) {
    this.removeHandles(m3.layerViews), this._compileList(), e7 && this.addHandles(e7.on("change", () => this._compileList()), m3.layerViews);
  }
  _createMapLayerHandles(e7) {
    this.removeHandles(m3.mapLayers), this._compileList(), e7 && this.addHandles(e7.on("change", () => this._compileList()), m3.mapLayers);
  }
  _createListItem(e7) {
    const { view: t3, listItemCreatedFunction: s4, checkPublishStatusEnabled: i4, listModeDisabled: r2 } = this;
    return new O2({ checkPublishStatusEnabled: i4, listModeDisabled: r2, layer: e7, listItemCreatedFunction: s4, view: t3 });
  }
  _removeAllItems() {
    this.operationalItems.destroyAll();
  }
  _getViewableLayers(e7) {
    return e7 ? this.listModeDisabled ? e7 : e7.filter((e8) => u(e8) !== c2) : void 0;
  }
  _watchLayersListMode(e7) {
    this.removeHandles(m3.layerListMode), e7 && !this.listModeDisabled && this.addHandles(d(() => e7.filter((e8) => "listMode" in e8).map((e8) => e8.listMode).toArray(), () => this._compileList()), m3.layerListMode);
  }
  _compileList() {
    const e7 = this.view?.map?.layers, t3 = e4(this.view) && !this.view.inGeographicLayout ? e7?.filter(({ type: e8 }) => "link-chart" === e8) : e7;
    this._watchLayersListMode(t3);
    const s4 = this._getViewableLayers(t3);
    s4?.length ? (this._createNewItems(s4), this._removeItems(s4), this._sortItems(s4)) : this._removeAllItems();
  }
  _createNewItems(e7) {
    const { operationalItems: t3 } = this;
    e7.forEach((e8) => {
      t3.some((t4) => t4.layer === e8) || t3.add(this._createListItem(e8));
    });
  }
  _removeItems(e7) {
    const { operationalItems: t3 } = this, s4 = [];
    t3.forEach((t4) => {
      t4 && e7 && e7.includes(t4.layer) || s4.push(t4);
    }), t3.destroyMany(s4);
  }
  _sortItems(e7) {
    const { operationalItems: t3 } = this;
    t3.sort((t4, s4) => {
      const i4 = e7.indexOf(t4.layer), r2 = e7.indexOf(s4.layer);
      return i4 > r2 ? -1 : i4 < r2 ? 1 : 0;
    });
  }
  _recompileList() {
    this._removeAllItems(), this._compileList();
  }
  _viewHandles() {
    const { view: e7 } = this;
    this.removeHandles([m3.mapLayers, m3.layerViews, m3.viewLayers]), e7?.ready ? this.addHandles([d(() => this.view?.map?.allLayers, (e8) => this._createMapLayerHandles(e8), P), d(() => this.view?.allLayerViews, (e8) => this._createLayerViewHandles(e8), P)], m3.viewLayers) : this._removeAllItems();
  }
};
r([m()], y.prototype, "checkPublishStatusEnabled", void 0), r([m()], y.prototype, "listItemCreatedFunction", void 0), r([m({ nonNullable: true })], y.prototype, "listModeDisabled", void 0), r([m({ type: p })], y.prototype, "operationalItems", void 0), r([m({ readOnly: true })], y.prototype, "state", null), r([m()], y.prototype, "totalItems", null), r([m()], y.prototype, "view", void 0), y = r([a("esri.widgets.LayerList.LayerListViewModel")], y);
var v3 = y;

// node_modules/@arcgis/core/widgets/LayerList/LayerListVisibleElements.js
var s3 = class extends g {
  constructor() {
    super(...arguments), this.catalogLayerList = true, this.closeButton = false, this.collapseButton = false, this.errors = false, this.filter = false, this.flow = true, this.heading = false, this.statusIndicators = true, this.temporaryLayerIndicators = false;
  }
};
r([m({ type: Boolean, nonNullable: true })], s3.prototype, "catalogLayerList", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "closeButton", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "collapseButton", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "errors", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "filter", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "flow", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "heading", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "statusIndicators", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "temporaryLayerIndicators", void 0), s3 = r([a("esri.widgets.LayerList.LayerListVisibleElements")], s3);
var l = s3;

// node_modules/@arcgis/core/widgets/LayerList.js
var P2 = V.ofType(O2);
var A = "nested";
var j = class extends n2.IdentifiableMixin(O) {
  constructor(e7, i4) {
    super(e7, i4), this._rootListEl = null, this._activeItem = null, this._tooltipReferenceMap = new s(), this._focusRootFlowItem = false, this._focusPanelFlowItem = false, this._focusLayerFlowItem = null, this._layerListMap = new s(), this._lastDragDetail = null, this._selectedDragItemLayerUid = null, this._rootGroupUid = `operational-${this.uid}`, this._openedLayersController = null, this.catalogLayerList = null, this.catalogOptions = null, this.collapsed = false, this.dragEnabled = false, this.filterPlaceholder = "", this.filterPredicate = null, this.filterText = "", this.headingLevel = 2, this.knowledgeGraphOptions = null, this.layerTablesEnabled = new V(["knowledge-graph"]), this.listItemCanGiveFunction = null, this.listItemCanReceiveFunction = null, this.mapImageOptions = null, this.messages = null, this.messagesCommon = null, this.minDragEnabledItems = e5, this.minFilterItems = i2, this.openedLayers = new V(), this.openedLayerLists = new V(), this.selectedItems = new P2(), this.selectionMode = "none", this.tableList = null, this.tileOptions = null, this.viewModel = new v3(), this.visibilityAppearance = "default", this.visibleElements = new l(), this._canMove = ({ dragEl: e8, fromEl: t3, toEl: i5 }, o) => {
      const s4 = "pull" === o ? this.listItemCanGiveFunction : this.listItemCanReceiveFunction, l2 = N(e8);
      if (!l2?.sortable) return false;
      const r2 = N(t3), a2 = q(t3), n3 = N(i5), d2 = q(i5), p2 = !!a2 && !!d2 && a2 === d2, c3 = { selected: l2, from: r2, to: n3 }, m4 = t3.group, h2 = i5.group, y2 = r2?.layer?.type ?? "", u2 = n3?.layer?.type ?? "", g2 = /* @__PURE__ */ new Set(["map-image", "catalog", "knowledge-graph"]), f2 = "sublayer";
      return m4 && h2 && "function" == typeof s4 ? s4.call(null, c3) : p2 && !g2.has(y2) && !g2.has(u2) && l2?.layer?.type !== f2;
    }, this._onCatalogOpen = (e8) => {
      this.openedLayers.push(e8.layer?.parent), this._focusLayerFlowItem = e8.layer?.uid;
    }, this._onTablesOpen = (e8) => {
      this.openedLayers.push(e8.layer), this._focusLayerFlowItem = e8.layer?.uid;
    }, this._onPanelOpen = () => {
      this._focusPanelFlowItem = true;
    }, this._onTooltipReferenceChange = (e8, t3) => {
      t3 ? this._tooltipReferenceMap.set(e8, t3) : this._tooltipReferenceMap.delete(e8);
    }, this._onSelectedDragItemLayerUidChange = (e8) => {
      this._selectedDragItemLayerUid = e8;
    }, this._onTriggerAction = (e8, t3) => {
      this.triggerAction(e8, t3);
    }, this._clearActiveItem = () => {
      this._activeItem = null;
    }, this._setActiveItem = (e8) => {
      if ("default" !== this.visibilityAppearance) return;
      const t3 = Array.from(e8.composedPath()).find((e9) => e9.classList?.contains(e6.item));
      this._activeItem = N(t3);
    }, this._onCalciteListOrderChange = (e8) => {
      const { _lastDragDetail: t3 } = this, { toEl: i5, fromEl: o, dragEl: s4, newIndex: l2 } = e8;
      if (o && i5 && !(t3?.newIndex === l2 && t3?.dragEl === s4 && t3?.toEl === i5 && t3?.fromEl === o)) if (this._lastDragDetail = e8, this._selectedDragItemLayerUid = s4.value, o !== i5) this._moveLayerFromChildList({ toEl: i5, fromEl: o, dragEl: s4, newIndex: l2 });
      else {
        const e9 = Array.from(o.children).filter((e10) => e10?.matches("calcite-list-item")).map((e10) => e10.value);
        this._sortLayers(o, e9);
      }
    };
  }
  initialize() {
    this.addHandles([v(() => this.openedLayers, "change", () => this._handleOpenedLayersChange(), P), v(() => this.viewModel.operationalItems, "change", () => s2(this.selectedItems), P), d(() => [this.filterPredicate, this._rootListEl], () => f(this._rootListEl, this.filterPredicate))]);
  }
  loadDependencies() {
    return c({ button: () => import("./calcite-button-FV2OB3GT.js"), flow: () => import("./calcite-flow-WJTOGM45.js"), "flow-item": () => import("./calcite-flow-item-VOEDA3NN.js"), list: () => import("./calcite-list-W42EHRHD.js"), notice: () => import("./calcite-notice-X7K5RWS6.js"), tooltip: () => import("./calcite-tooltip-ZEJ36TWO.js") });
  }
  destroy() {
    this._destroyOpenedLayerLists(), this._tooltipReferenceMap.clear();
  }
  get _totalItems() {
    return this.viewModel.operationalItems.flatten((e7) => e7.children.filter((e8) => "catalog-dynamic-group" !== e8.layer?.type)).length;
  }
  get _visibleItems() {
    return this.operationalItems?.filter((e7) => !e7.hidden && (this.visibleElements.errors || !e7.error));
  }
  get _openedPanelItems() {
    return this._visibleItems.flatten((e7) => e7.children).filter(({ hidden: e7, panel: t3 }) => !e7 && t3?.open && !t3.disabled && t3.flowEnabled);
  }
  get _dragEnabled() {
    return this._totalItems >= this.minDragEnabledItems && this.dragEnabled;
  }
  get _filterEnabled() {
    return this._totalItems >= this.minFilterItems && this.visibleElements.filter;
  }
  get _renderedOpenLayerFlowItems() {
    const { openedLayers: e7 } = this;
    return e7.toArray().map((t3, i4) => this._renderLayerFlowItem(t3, i4 === e7.length - 1));
  }
  get icon() {
    return "layers";
  }
  set icon(e7) {
    this._overrideIfSome("icon", e7);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e7) {
    this._overrideIfSome("label", e7);
  }
  get listItemCreatedFunction() {
    return this.viewModel.listItemCreatedFunction;
  }
  set listItemCreatedFunction(e7) {
    this.viewModel.listItemCreatedFunction = e7;
  }
  get operationalItems() {
    return this.viewModel.operationalItems;
  }
  set operationalItems(e7) {
    this.viewModel.operationalItems = e7;
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e7) {
    this.viewModel.view = e7;
  }
  triggerAction(e7, t3) {
    return this.viewModel.triggerAction(e7, t3);
  }
  render() {
    const e7 = this.viewModel?.state, { _visibleItems: t3 } = this, i4 = { [e2.hidden]: "loading" === e7, [e2.disabled]: "disabled" === e7 };
    return n("div", { class: this.classes(e6.base, e2.widget, e2.panel, i4) }, t3?.length ? [this._renderItemTooltips(), this._renderItems()] : this._renderNoItems());
  }
  _createFlowList(e7, t3) {
    return __async(this, null, function* () {
      const { _layerListMap: i4 } = this, o = i4.get(e7);
      if (o) return o;
      const s4 = "catalog" === e7.type ? yield this._createCatalogLayerList(e7) : yield this._createTableList(e7);
      return t3.aborted || i4.set(e7, s4), s4;
    });
  }
  _handleOpenedLayersChange() {
    return __async(this, null, function* () {
      const { _layerListMap: e7, openedLayers: t3, openedLayerLists: i4 } = this;
      this._openedLayersController?.abort();
      const o = new AbortController(), { signal: s4 } = o;
      this._openedLayersController = o, e7.forEach((i5, o2) => {
        t3.includes(o2) || (i5.destroy(), e7.delete(o2));
      });
      const l2 = yield Promise.all(t3.map((e8) => this._createFlowList(e8, s4)));
      if (s4.aborted) return;
      i4.removeAll(), i4.addMany(l2);
      const r2 = i4.at(-1);
      r2 ? "catalogLayer" in r2 ? (this._set("catalogLayerList", r2), this._set("tableList", null)) : (this._set("catalogLayerList", null), this._set("tableList", r2)) : (this._set("catalogLayerList", null), this._set("tableList", null));
    });
  }
  _destroyOpenedLayerLists() {
    this.openedLayerLists.destroyAll(), this.openedLayers.removeAll(), this._layerListMap.clear();
  }
  _renderItemTooltip(e7) {
    const { _tooltipReferenceMap: t3, messages: i4 } = this;
    return e7 ? n("calcite-tooltip", { key: `tooltip-${e7.layer?.uid}`, overlayPositioning: "fixed", referenceElement: t3.get(e7.layer?.uid) }, i4.layerIncompatibleTooltip) : null;
  }
  _renderItemTooltipNodes(e7) {
    return e7.incompatible ? this._renderItemTooltip(e7) : e7.children?.filter((e8) => !e8.hidden).toArray().map((e8) => this._renderItemTooltipNodes(e8));
  }
  _renderItemTooltips() {
    return this._visibleItems?.toArray().map((e7) => this._renderItemTooltipNodes(e7));
  }
  _renderNoItemsMessage() {
    return n("div", { slot: "message" }, this.messages.noItemsToDisplay);
  }
  _renderNoItems() {
    return n("div", { class: e6.itemMessage, key: "esri-layer-list__no-items" }, n("calcite-notice", { icon: "information", kind: "info", open: true, width: "full" }, this._renderNoItemsMessage()));
  }
  _createCatalogLayerList(e7) {
    return __async(this, null, function* () {
      const { default: t3 } = yield import("./CatalogLayerList-YGQZHYPT.js"), { headingLevel: i4, catalogOptions: o, view: s4, filterPlaceholder: l2, listItemCreatedFunction: r2, minFilterItems: a2, selectionMode: n3, visibilityAppearance: d2, _onCatalogOpen: p2, _onTablesOpen: c3, layerTablesEnabled: m4 } = this;
      return new t3(__spreadProps(__spreadValues({ headingLevel: i4, view: s4, filterPlaceholder: l2, listItemCreatedFunction: r2, minFilterItems: a2, selectionMode: n3, visibilityAppearance: d2 }, o), { catalogLayer: e7, layerTablesEnabled: m4, onCatalogOpen: p2, onTablesOpen: c3 }));
    });
  }
  _getTableListParams(e7) {
    switch (e7.type) {
      case "knowledge-graph":
        return __spreadProps(__spreadValues({}, this.knowledgeGraphOptions), { tables: e7.tables });
      case "map-image":
        return __spreadProps(__spreadValues({}, this.mapImageOptions), { tables: e7.subtables });
      case "tile":
        return __spreadProps(__spreadValues({}, this.tileOptions), { tables: e7.subtables });
      default:
        return null;
    }
  }
  _createTableList(e7) {
    return __async(this, null, function* () {
      const { default: t3 } = yield import("./TableList-HVTMVBZ6.js"), { headingLevel: i4, selectionMode: o, dragEnabled: s4 } = this;
      return new t3(__spreadValues({ headingLevel: i4, selectionMode: o, dragEnabled: s4 }, this._getTableListParams(e7)));
    });
  }
  _renderLayerFlowItem(e7, t3) {
    const { messages: i4, openedLayers: o } = this, s4 = e7.title || this.messages.untitledLayer;
    return n("calcite-flow-item", { afterCreate: this._focusLayerFlowItemNode, afterUpdate: this._focusLayerFlowItemNode, bind: this, "data-layer-uid": e7.uid, description: s4, heading: i4["catalog" === e7.type ? "catalogLayers" : "tables"], headingLevel: this.headingLevel, key: `flow-layer-list-${e7.uid}`, selected: t3, onCalciteFlowItemBack: (e8) => {
      e8.preventDefault(), o.pop();
      const t4 = o.at(-1);
      t4 ? this._focusLayerFlowItem = t4.uid : this._focusRootFlowItem = true;
    } }, this._layerListMap.get(e7)?.render());
  }
  _renderPanelFlowItems() {
    const { _openedPanelItems: e7, openedLayers: t3 } = this;
    return e7.toArray().map(({ title: i4, panel: o }, s4) => {
      const l2 = () => this._handlePanelFlowItemBack(o);
      return n("calcite-flow-item", { afterCreate: this._focusPanelFlowItemNode, afterUpdate: this._focusPanelFlowItemNode, bind: this, description: i4, heading: o.title, headingLevel: this.headingLevel, key: `flow-panel-${o.uid}`, selected: !t3.length && s4 === e7.length - 1, onCalciteFlowItemBack: (e8) => {
        e8.preventDefault(), l2();
      } }, o.render(), n("calcite-button", { appearance: "transparent", onclick: l2, slot: "footer-actions", width: "full" }, this.messagesCommon.back));
    });
  }
  _handlePanelFlowItemBack(e7) {
    e7.open = false, this._focusRootFlowItem = true;
  }
  _focusRootFlowItemNode(e7) {
    this._focusRootFlowItem && (this._focusRootFlowItem = false, T(e7));
  }
  _focusLayerFlowItemNode(e7) {
    this._focusLayerFlowItem === e7.dataset.layerUid && (this._focusLayerFlowItem = null, T(e7));
  }
  _focusPanelFlowItemNode(e7) {
    this._focusPanelFlowItem && (this._focusPanelFlowItem = false, T(e7));
  }
  _renderItems() {
    const { visible: e7, collapsed: t3, _visibleItems: i4, _openedPanelItems: o, _filterEnabled: s4, _rootGroupUid: l2, visibleElements: { closeButton: r2, collapseButton: a2, heading: n3, flow: d2 }, _dragEnabled: c3, selectionMode: m4, filterText: h2, openedLayers: y2, filterPlaceholder: u2, messages: g2 } = this, _ = [n("calcite-flow-item", { afterCreate: this._focusRootFlowItemNode, afterUpdate: this._focusRootFlowItemNode, bind: this, closable: r2, closed: !e7, collapsed: t3, collapsible: a2, heading: n3 ? g2.widgetLabel : void 0, headingLevel: this.headingLevel, key: "root-flow-item", selected: !y2.length && !o.length, onCalciteFlowItemClose: () => this.visible = false }, n("calcite-list", { afterCreate: (e8) => {
      this._rootListEl = e8, e8.addEventListener("focusin", this._setActiveItem), e8.addEventListener("focusout", this._clearActiveItem);
    }, afterRemoved: (e8) => {
      this._rootListEl = null, e8.removeEventListener("focusin", this._setActiveItem), e8.removeEventListener("focusout", this._clearActiveItem);
    }, canPull: (e8) => this._canMove(e8, "pull"), canPut: (e8) => this._canMove(e8, "put"), "data-layer-type": l2, displayMode: A, dragEnabled: c3, filterEnabled: s4, filterPlaceholder: u2, filterProps: t, filterText: s4 ? h2 : "", group: l2, key: "root-list", label: g2.widgetLabel, onmouseleave: this._clearActiveItem, onmouseover: this._setActiveItem, selectionAppearance: "border", selectionMode: m4, onCalciteListChange: (e8) => this._handleCalciteListChange(e8), onCalciteListDragEnd: (e8) => this._handleCalciteListDragEnd(e8.detail), onCalciteListFilter: (e8) => this.filterText = e8.currentTarget?.filterText ?? "", onCalciteListOrderChange: (e8) => this._onCalciteListOrderChange(e8.detail) }, i4?.toArray().map((e8) => this._renderItem(e8)), i4?.length && s4 ? n("div", { class: e6.filterNoResults, slot: "filter-no-results" }, n("calcite-notice", { kind: "info", open: true, width: "full" }, this._renderNoItemsMessage())) : null)), this._renderPanelFlowItems(), this._renderedOpenLayerFlowItems];
    return e7 ? d2 ? n("calcite-flow", { key: "root-flow" }, _) : _ : null;
  }
  _renderItem(e7, t3, i4) {
    return n(I, { activeItem: this._activeItem, canMove: this._canMove, css: e6, displayMode: A, dragEnabled: this.dragEnabled, item: e7, key: `layerListItem-${e7.layer?.uid}`, layerTablesEnabled: this.layerTablesEnabled, listModeDisabled: this.viewModel.listModeDisabled, messages: this.messages, messagesCommon: this.messagesCommon, parent: t3, parentTitles: i4, rootGroupUid: this._rootGroupUid, selectedDragItemLayerUid: this._selectedDragItemLayerUid, selectedItems: this.selectedItems, selectionMode: this.selectionMode, visibilityAppearance: this.visibilityAppearance, visibleElements: this.visibleElements, onAction: this._onTriggerAction, onCatalogOpen: this._onCatalogOpen, onPanelOpen: this._onPanelOpen, onSelectedDragItemLayerUidChange: this._onSelectedDragItemLayerUidChange, onTablesOpen: this._onTablesOpen, onTooltipReferenceChange: this._onTooltipReferenceChange });
  }
  _moveLayerFromChildList({ toEl: e7, fromEl: t3, dragEl: i4, newIndex: o }) {
    const s4 = N(i4), l2 = N(e7), r2 = N(t3);
    this.viewModel.moveListItem(s4, r2, l2, o);
  }
  _handleCalciteListDragEnd(e7) {
    const { fromEl: t3, dragEl: i4, oldIndex: o } = e7;
    t3.insertBefore(i4, t3.children[o]);
  }
  _sortLayers(e7, t3) {
    if (e7) if (e7 === this._rootListEl) v2(this.view?.map?.layers, t3);
    else {
      const i4 = N(e7);
      if (!i4) return;
      h(i4, t3);
    }
  }
  _handleCalciteListChange(e7) {
    const { selectionMode: t3, selectedItems: i4 } = this;
    if ("none" === t3) return;
    const o = e7.target.selectedItems.map((e8) => N(e8)).filter(Boolean);
    i4.removeAll(), i4.addMany(o);
  }
};
r([m()], j.prototype, "_rootListEl", void 0), r([m()], j.prototype, "_activeItem", void 0), r([m()], j.prototype, "_tooltipReferenceMap", void 0), r([m()], j.prototype, "_focusRootFlowItem", void 0), r([m()], j.prototype, "_focusPanelFlowItem", void 0), r([m()], j.prototype, "_focusLayerFlowItem", void 0), r([m()], j.prototype, "_layerListMap", void 0), r([m()], j.prototype, "_totalItems", null), r([m()], j.prototype, "_visibleItems", null), r([m()], j.prototype, "_openedPanelItems", null), r([m()], j.prototype, "_dragEnabled", null), r([m()], j.prototype, "_filterEnabled", null), r([m()], j.prototype, "_renderedOpenLayerFlowItems", null), r([m({ readOnly: true })], j.prototype, "catalogLayerList", void 0), r([m()], j.prototype, "catalogOptions", void 0), r([m()], j.prototype, "collapsed", void 0), r([m()], j.prototype, "dragEnabled", void 0), r([m()], j.prototype, "filterPlaceholder", void 0), r([m()], j.prototype, "filterPredicate", void 0), r([m()], j.prototype, "filterText", void 0), r([m()], j.prototype, "headingLevel", void 0), r([m()], j.prototype, "icon", null), r([m()], j.prototype, "knowledgeGraphOptions", void 0), r([m()], j.prototype, "label", null), r([m()], j.prototype, "layerTablesEnabled", void 0), r([m()], j.prototype, "listItemCanGiveFunction", void 0), r([m()], j.prototype, "listItemCanReceiveFunction", void 0), r([m()], j.prototype, "listItemCreatedFunction", null), r([m()], j.prototype, "mapImageOptions", void 0), r([m(), e("esri/widgets/LayerList/t9n/LayerList")], j.prototype, "messages", void 0), r([m(), e("esri/t9n/common")], j.prototype, "messagesCommon", void 0), r([m()], j.prototype, "minDragEnabledItems", void 0), r([m()], j.prototype, "minFilterItems", void 0), r([m({ readOnly: true })], j.prototype, "openedLayers", void 0), r([m({ readOnly: true })], j.prototype, "openedLayerLists", void 0), r([m()], j.prototype, "operationalItems", null), r([m()], j.prototype, "selectedItems", void 0), r([m()], j.prototype, "selectionMode", void 0), r([m({ readOnly: true })], j.prototype, "tableList", void 0), r([m()], j.prototype, "tileOptions", void 0), r([m()], j.prototype, "view", null), r([e3("trigger-action"), m({ type: v3 })], j.prototype, "viewModel", void 0), r([m()], j.prototype, "visibilityAppearance", void 0), r([m({ type: l, nonNullable: true })], j.prototype, "visibleElements", void 0), j = r([a("esri.widgets.LayerList")], j);
var D = j;
export {
  D as default
};
//# sourceMappingURL=@arcgis_core_widgets_LayerList.js.map
