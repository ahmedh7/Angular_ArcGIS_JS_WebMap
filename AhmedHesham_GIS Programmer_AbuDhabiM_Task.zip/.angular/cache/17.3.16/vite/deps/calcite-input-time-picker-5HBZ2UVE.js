import "./chunk-HHEKWZOC.js";
import {
  FORMAT_DEFAULT,
  esm_default
} from "./chunk-LWPHQFWG.js";
import "./chunk-H7SDJUQE.js";
import {
  i,
  s as s2
} from "./chunk-MZWUOCJB.js";
import "./chunk-GFDFTTQ5.js";
import "./chunk-FQS4PHWP.js";
import "./chunk-IXY5PUGT.js";
import "./chunk-K6AAVT2T.js";
import "./chunk-YANRGXVA.js";
import "./chunk-DK4MBEKC.js";
import {
  m as m4
} from "./chunk-6M3P2WWZ.js";
import {
  H,
  O,
  Q,
  W as W2,
  f,
  q
} from "./chunk-TAV7HQ6F.js";
import {
  m as m3
} from "./chunk-GEZ5ITZ2.js";
import {
  e
} from "./chunk-7BYAEWQF.js";
import "./chunk-47KWH5ND.js";
import "./chunk-RABWWKP5.js";
import {
  $,
  B,
  D,
  W
} from "./chunk-WXKM7U5Z.js";
import "./chunk-6EA7357B.js";
import {
  I,
  T,
  v
} from "./chunk-B2DAWPE2.js";
import "./chunk-ZNGJTAZC.js";
import "./chunk-GYMHVFJE.js";
import {
  m,
  p
} from "./chunk-JP6NVURN.js";
import {
  m as m2,
  o
} from "./chunk-JNDPOHLO.js";
import "./chunk-3EHTPQND.js";
import "./chunk-4OCBID5S.js";
import {
  ref
} from "./chunk-LPETJQKI.js";
import "./chunk-EJFZYJAF.js";
import {
  s
} from "./chunk-FJ5QMW6O.js";
import "./chunk-U3H4S3UY.js";
import {
  gt,
  mt
} from "./chunk-67TGT3ZY.js";
import "./chunk-LPID7LVC.js";
import {
  LitElement2 as LitElement,
  S,
  createEvent,
  css,
  html,
  nothing,
  safeClassMap,
  stringOrBoolean
} from "./chunk-NMBGL4CC.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/chunks/time.js
var U = 5;
function p2({
  locale: t4,
  numberingSystem: e2,
  includeSeconds: n = true,
  fractionalSecondDigits: r,
  hour12: i2
}) {
  const o2 = {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "UTC",
    numberingSystem: H(e2)
  };
  return typeof i2 == "boolean" && (o2.hour12 = i2), n && (o2.second = "2-digit", r && (o2.fractionalSecondDigits = r)), Q(t4, o2);
}
function S2(t4, e2) {
  if (t4 == null)
    return;
  const n = t4.toString(), r = s2(t4);
  if (t4 < 1 && r > 0 && r < 4) {
    const i2 = n.replace("0.", "");
    return !e2 || i2.length === e2 ? i2 : i2.length < e2 ? i2.padEnd(e2, "0") : i2;
  }
  if (t4 >= 0 && t4 < 10)
    return n.padStart(2, "0");
  if (t4 >= 10)
    return n;
}
function V(t4) {
  if (!g(t4))
    return null;
  const { hour: e2, minute: n, second: r, fractionalSecond: i2 } = x(t4);
  let o2 = `${S2(parseInt(e2))}:${S2(parseInt(n))}`;
  return r && (o2 += `:${S2(parseInt(r))}`, i2 && (o2 += `.${i2}`)), o2;
}
function O2(t4) {
  return parseInt((parseFloat(`0.${t4}`) / 1e-3).toFixed(3));
}
function b(t4) {
  const e2 = { locale: t4 };
  t4 === "mk" ? e2.hour12 = false : t4.toLowerCase() === "es-mx" && (e2.hour12 = true);
  const r = p2(e2).formatToParts(new Date(Date.UTC(0, 0, 0, 0, 0, 0)));
  return l("meridiem", r) ? "12" : "24";
}
function H2(t4) {
  return b(t4) === "24" ? "12" : "24";
}
function P(t4, e2, n = "latn") {
  const r = p2({ hour12: true, locale: t4, numberingSystem: n }), i2 = 6, o2 = 18, u3 = new Date(
    Date.UTC(0, 0, 0, e2 === "AM" ? i2 : o2, 0)
  ), c = r.formatToParts(u3);
  return l("meridiem", c);
}
function D2(t4, e2) {
  return q.numberFormatOptions = {
    locale: t4,
    numberingSystem: e2
  }, q.localize("1.1").split("")[1];
}
function k(t4, e2, n = "latn") {
  const i2 = p2({ locale: e2, numberingSystem: n }).formatToParts(new Date(Date.UTC(0, 0, 0, 0, 0, 0)));
  return l(`${t4}Suffix`, i2);
}
function l(t4, e2) {
  if (!t4 || !e2)
    return null;
  if (t4 === "hourSuffix") {
    const n = e2.indexOf(e2.find(({ type: o2 }) => o2 === "hour")), r = e2.indexOf(e2.find(({ type: o2 }) => o2 === "minute")), i2 = e2[n + 1];
    return i2 && i2.type === "literal" && r - n === 2 && i2.value?.trim() || null;
  }
  if (t4 === "minuteSuffix") {
    const n = e2.indexOf(e2.find(({ type: o2 }) => o2 === "minute")), r = e2.indexOf(e2.find(({ type: o2 }) => o2 === "second")), i2 = e2[n + 1];
    return i2 && i2.type === "literal" && r - n === 2 && i2.value?.trim() || null;
  }
  if (t4 === "secondSuffix") {
    const n = e2.indexOf(e2.find(({ type: i2 }) => i2 === "second")), r = e2[n + 1];
    return r && r.type === "literal" && r.value?.trim() || null;
  }
  return e2.find(({ type: n }) => t4 == "meridiem" ? n === "dayPeriod" : n === t4)?.value || null;
}
function W3(t4) {
  if (!f(t4))
    return null;
  const e2 = parseInt(t4);
  return e2 >= 0 && e2 <= 11 ? "AM" : "PM";
}
function E(t4) {
  const e2 = P(t4, "AM"), n = P(t4, "PM"), r = L(t4), i2 = z({
    hour12: true,
    value: "00:00:00",
    locale: t4,
    numberingSystem: "latn"
  }), o2 = i2[r === 0 ? 1 : r - 1].type === "hour" || i2[r - 1]?.type === "second" ? "" : " ";
  return (
    // Unknown dayjs parsing bug with norwegian.  Dayjs only accepts uppercase meridiems for some reason, despite the LT/LTS config
    t4 !== "no" && e2 === e2.toLocaleLowerCase(t4) && n === n.toLocaleLowerCase(t4) ? r === 0 ? `a${o2}` : `${o2}a` : r === 0 ? `A${o2}` : `${o2}A`
  );
}
function L(t4) {
  return z({
    hour12: true,
    value: "00:00:00",
    locale: t4,
    numberingSystem: "latn"
  }).findIndex((n) => n.type === "dayPeriod");
}
function Z(t4, e2) {
  return t4 === H2(e2);
}
function g(t4) {
  if (!t4 || t4.startsWith(":") || t4.endsWith(":"))
    return false;
  const e2 = t4.split(":");
  if (!(e2.length > 1 && e2.length < 4))
    return false;
  const [r, i2, o2] = e2, u3 = parseInt(e2[0]), c = parseInt(e2[1]), f2 = parseInt(e2[2]), d = f(r) && u3 >= 0 && u3 < 24, a = f(i2) && c >= 0 && c < 60, m5 = f(o2) && f2 >= 0 && f2 < 60;
  if (d && a && !o2 || d && a && m5)
    return true;
}
function w(t4, e2) {
  if (e2 === "meridiem")
    return t4 === "AM" || t4 === "PM";
  if (!f(t4))
    return false;
  const n = Number(t4);
  return e2 === "hour" ? n >= 0 && n < 24 : n >= 0 && n < 60;
}
function y({
  value: t4,
  part: e2,
  locale: n,
  numberingSystem: r = "latn",
  hour12: i2
}) {
  if (e2 === "fractionalSecond") {
    const d = D2(n, r);
    let a = null;
    if (t4) {
      q.numberFormatOptions = {
        locale: n,
        numberingSystem: r
      };
      const m5 = q.localize("0");
      parseInt(t4) === 0 ? a = "".padStart(t4.length, m5) : (a = q.localize(`0.${t4}`).replace(`${m5}${d}`, ""), a.length < t4.length && (a = a.padEnd(t4.length, m5)));
    }
    return a;
  }
  if (!w(t4, e2))
    return;
  const o2 = parseInt(t4), u3 = new Date(
    Date.UTC(
      0,
      0,
      0,
      e2 === "hour" ? o2 : e2 === "meridiem" ? t4 === "AM" ? 0 : 12 : 0,
      e2 === "minute" ? o2 : 0,
      e2 === "second" ? o2 : 0
    )
  );
  if (!u3)
    return;
  const f2 = p2({ hour12: i2, locale: n, numberingSystem: r }).formatToParts(u3);
  return l(e2, f2);
}
function j({
  value: t4,
  locale: e2,
  numberingSystem: n = "latn",
  includeSeconds: r = true,
  fractionalSecondDigits: i2,
  hour12: o2
}) {
  if (!g(t4))
    return null;
  const { hour: u3, minute: c, second: f2 = "0", fractionalSecond: d } = x(t4), a = new Date(
    Date.UTC(
      0,
      0,
      0,
      parseInt(u3),
      parseInt(c),
      parseInt(f2),
      d && O2(d)
    )
  );
  let s3 = p2({
    locale: e2,
    numberingSystem: n,
    includeSeconds: r,
    fractionalSecondDigits: i2,
    hour12: o2
  }).format(a) || null;
  if (s3 && e2 === "bg" && s3.includes(" ч.") && (s3 = s3.replaceAll(" ч.", "")), e2 === "bs" || e2 === "mk") {
    const I2 = W2.get(e2);
    s3.includes("AM") ? s3 = s3.replaceAll("AM", I2.am) : s3.includes("PM") && (s3 = s3.replaceAll("PM", I2.pm)), s3.indexOf(".") !== s3.length - 1 && (s3 = s3.replace(".", ","));
  }
  return s3;
}
function B2({
  value: t4,
  locale: e2,
  numberingSystem: n = "latn",
  hour12: r
}) {
  if (!g(t4))
    return null;
  const { hour: i2, minute: o2, second: u3 = "0", fractionalSecond: c } = x(t4), f2 = new Date(Date.UTC(0, 0, 0, parseInt(i2), parseInt(o2), parseInt(u3)));
  if (f2) {
    const a = p2({ locale: e2, numberingSystem: n, hour12: r }).formatToParts(f2);
    let m5 = l("meridiem", a);
    if (r && (e2 === "bs" || e2 === "mk")) {
      const s3 = W2.get(e2);
      m5 = f2.getHours() > 11 ? s3.am : s3.pm;
    }
    return {
      localizedHour: l("hour", a),
      localizedHourSuffix: l("hourSuffix", a),
      localizedMinute: l("minute", a),
      localizedMinuteSuffix: l("minuteSuffix", a),
      localizedSecond: l("second", a),
      localizedDecimalSeparator: D2(e2, n),
      localizedFractionalSecond: y({
        value: c,
        part: "fractionalSecond",
        locale: e2,
        numberingSystem: n
      }),
      localizedSecondSuffix: l("secondSuffix", a),
      localizedMeridiem: m5
    };
  }
  return null;
}
function z({
  hour12: t4,
  value: e2,
  locale: n,
  numberingSystem: r
}) {
  if (!g(e2))
    return null;
  const { hour: i2, minute: o2, second: u3 = "0" } = x(e2), c = new Date(Date.UTC(0, 0, 0, parseInt(i2), parseInt(o2), parseInt(u3)));
  return c ? p2({ hour12: t4, locale: n, numberingSystem: r }).formatToParts(c) : null;
}
function x(t4) {
  if (g(t4)) {
    const [e2, n, r] = t4.split(":");
    let i2 = r, o2 = null;
    return r?.includes(".") && ([i2, o2] = r.split(".")), {
      fractionalSecond: o2,
      hour: e2,
      minute: n,
      second: i2
    };
  }
  return {
    fractionalSecond: null,
    hour: null,
    minute: null,
    second: null
  };
}
function q2(t4, e2 = true) {
  if (!g(t4))
    return "";
  const { hour: n, minute: r, second: i2, fractionalSecond: o2 } = x(t4);
  let u3 = `${S2(parseInt(n))}:${S2(parseInt(r))}`;
  return e2 && (u3 += `:${S2(parseInt(e2 && i2 || "0"))}`, o2 && (u3 += `.${o2}`)), u3;
}

// node_modules/@esri/calcite-components/dist/components/calcite-time-picker/customElement.js
var t = {
  button: "button",
  buttonBottomLeft: "button--bottom-left",
  buttonBottomRight: "button--bottom-right",
  buttonFractionalSecondDown: "button--fractionalSecond-down",
  buttonFractionalSecondUp: "button--fractionalSecond-up",
  buttonHourDown: "button--hour-down",
  buttonHourUp: "button--hour-up",
  buttonMeridiemDown: "button--meridiem-down",
  buttonMeridiemUp: "button--meridiem-up",
  buttonMinuteDown: "button--minute-down",
  buttonMinuteUp: "button--minute-up",
  buttonSecondDown: "button--second-down",
  buttonSecondUp: "button--second-up",
  buttonTopLeft: "button--top-left",
  buttonTopRight: "button--top-right",
  column: "column",
  decimalSeparator: "decimal-separator",
  delimiter: "delimiter",
  fractionalSecond: "fractionalSecond",
  hour: "hour",
  hourSuffix: "hour-suffix",
  input: "input",
  inputFocus: "inputFocus",
  meridiem: "meridiem",
  minute: "minute",
  minuteSuffix: "minute-suffix",
  second: "second",
  secondSuffix: "second-suffix",
  showMeridiem: "show-meridiem",
  showSecond: "show-second",
  "scale-s": "scale-s",
  "scale-m": "scale-m",
  "scale-l": "scale-l",
  timePicker: "time-picker",
  meridiemStart: "meridiem--start"
};
var j2 = css`:host{display:inline-block}.time-picker{display:flex;-webkit-user-select:none;user-select:none;align-items:center;background-color:var(--calcite-color-foreground-1);font-weight:var(--calcite-font-weight-medium);color:var(--calcite-color-text-1);--tw-shadow: 0 6px 20px -4px rgba(0, 0, 0, .1), 0 4px 12px -2px rgba(0, 0, 0, .08);--tw-shadow-colored: 0 6px 20px -4px var(--tw-shadow-color), 0 4px 12px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow);border-radius:var(--calcite-border-radius)}.time-picker .column{display:flex;flex-direction:column}.time-picker .meridiem--start{order:-1}.time-picker .button{display:inline-flex;cursor:pointer;align-items:center;justify-content:center;background-color:var(--calcite-color-foreground-1)}.time-picker .button:hover,.time-picker .button:focus{background-color:var(--calcite-color-foreground-2);outline:2px solid transparent;outline-offset:2px;z-index:var(--calcite-z-index-header);outline-offset:0}.time-picker .button:active{background-color:var(--calcite-color-foreground-3)}.time-picker .button.top-left{border-start-start-radius:var(--calcite-border-radius)}.time-picker .button.bottom-left{border-end-start-radius:var(--calcite-border-radius)}.time-picker .button.top-right{border-start-end-radius:var(--calcite-border-radius)}.time-picker .button.bottom-right{border-end-end-radius:var(--calcite-border-radius)}.time-picker .button calcite-icon{color:var(--calcite-color-text-3)}.time-picker .input{display:inline-flex;cursor:pointer;align-items:center;justify-content:center;background-color:var(--calcite-color-foreground-1);font-weight:var(--calcite-font-weight-medium)}.time-picker .input:hover{box-shadow:inset 0 0 0 2px var(--calcite-color-foreground-2);z-index:var(--calcite-z-index-header)}.time-picker .input:focus,.time-picker .input:hover:focus{outline:2px solid transparent;outline-offset:2px;outline-offset:0}.time-picker .input.inputFocus,.time-picker .input:hover.inputFocus{box-shadow:inset 0 0 0 2px var(--calcite-color-brand);z-index:var(--calcite-z-index-header)}.time-picker.scale-s{font-size:var(--calcite-font-size--1)}.time-picker.scale-s .button,.time-picker.scale-s .input{padding-inline:.75rem;padding-block:.25rem}.time-picker.scale-s:not(.show-meridiem) .delimiter:last-child{padding-inline-end:.75rem}.time-picker.scale-m{font-size:var(--calcite-font-size-0)}.time-picker.scale-m .button,.time-picker.scale-m .input{padding-inline:1rem;padding-block:.5rem}.time-picker.scale-m:not(.show-meridiem) .delimiter:last-child{padding-inline-end:1rem}.time-picker.scale-l{font-size:var(--calcite-font-size-1)}.time-picker.scale-l .button,.time-picker.scale-l .input{padding-inline:1.25rem;padding-block:.75rem}.time-picker.scale-l:not(.show-meridiem) .delimiter:last-child{padding-inline-end:1.25rem}:host([hidden]){display:none}[hidden]{display:none}`;
function W4(w2) {
  return w2.charAt(0).toUpperCase() + w2.slice(1);
}
var q3 = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.pointerActivated = false, this.localizedDecimalSeparator = ".", this.hourFormat = "user", this.messages = s(), this.scale = "m", this.step = 60, this.value = null, this.calciteTimePickerChange = createEvent({ cancelable: false }), this.listen("blur", this.blurHandler), this.listen("keydown", this.keyDownHandler), this.listen("pointerdown", this.pointerDownHandler);
  }
  static {
    this.properties = { activeEl: 16, effectiveHourFormat: 16, fractionalSecond: 16, hour: 16, localizedDecimalSeparator: 16, localizedFractionalSecond: 16, localizedHour: 16, localizedHourSuffix: 16, localizedMeridiem: 16, localizedMinute: 16, localizedMinuteSuffix: 16, localizedSecond: 16, localizedSecondSuffix: 16, meridiem: 16, minute: 16, second: 16, showFractionalSecond: 16, showSecond: 16, hourFormat: 3, messageOverrides: 0, numberingSystem: 1, scale: 3, step: 11, value: 1 };
  }
  static {
    this.shadowRootOptions = { mode: "open", delegatesFocus: true };
  }
  static {
    this.styles = j2;
  }
  // #endregion
  // #region Public Methods
  /** Sets focus on the component's first focusable element. */
  setFocus() {
    return __async(this, null, function* () {
      yield m2(this), this.el?.focus();
    });
  }
  connectedCallback() {
    super.connectedCallback(), this.updateLocale(), this.toggleSecond();
  }
  willUpdate(e2) {
    e2.has("step") && (this.hasUpdated || this.step !== 60) && this.toggleSecond(), e2.has("value") && (this.hasUpdated || this.value !== null) && this.setValue(this.value), (e2.has("hourFormat") || e2.has("messages")) && this.updateLocale();
  }
  // #endregion
  // #region Private Methods
  blurHandler() {
    this.activeEl = void 0, this.pointerActivated = false;
  }
  keyDownHandler(e2) {
    this.pointerActivated = false;
    const { defaultPrevented: i2, key: s3 } = e2;
    if (!i2)
      switch (this.activeEl) {
        case this.hourEl:
          s3 === "ArrowRight" && (this.focusPart("minute"), e2.preventDefault());
          break;
        case this.minuteEl:
          switch (s3) {
            case "ArrowLeft":
              this.focusPart("hour"), e2.preventDefault();
              break;
            case "ArrowRight":
              this.step !== 60 ? (this.focusPart("second"), e2.preventDefault()) : this.effectiveHourFormat === "12" && (this.focusPart("meridiem"), e2.preventDefault());
              break;
          }
          break;
        case this.secondEl:
          switch (s3) {
            case "ArrowLeft":
              this.focusPart("minute"), e2.preventDefault();
              break;
            case "ArrowRight":
              this.showFractionalSecond ? this.focusPart("fractionalSecond") : this.effectiveHourFormat === "12" && (this.focusPart("meridiem"), e2.preventDefault());
              break;
          }
          break;
        case this.fractionalSecondEl:
          switch (s3) {
            case "ArrowLeft":
              this.focusPart("second"), e2.preventDefault();
              break;
            case "ArrowRight":
              this.effectiveHourFormat === "12" && (this.focusPart("meridiem"), e2.preventDefault());
              break;
          }
          break;
        case this.meridiemEl:
          switch (s3) {
            case "ArrowLeft":
              this.showFractionalSecond ? this.focusPart("fractionalSecond") : this.step !== 60 ? (this.focusPart("second"), e2.preventDefault()) : (this.focusPart("minute"), e2.preventDefault());
              break;
          }
          break;
      }
  }
  pointerDownHandler() {
    this.pointerActivated = true;
  }
  focusPart(e2) {
    return __async(this, null, function* () {
      yield m2(this), this[`${e2 || "hour"}El`]?.focus();
    });
  }
  decrementHour() {
    const e2 = this.hour ? parseInt(this.hour) === 0 ? 23 : parseInt(this.hour) - 1 : 0;
    this.setValuePart("hour", e2);
  }
  decrementMeridiem() {
    const e2 = this.meridiem === "PM" ? "AM" : "PM";
    this.setValuePart("meridiem", e2);
  }
  decrementMinuteOrSecond(e2) {
    let i2;
    if (f(this[e2])) {
      const s3 = parseInt(this[e2]);
      i2 = s3 === 0 ? 59 : s3 - 1;
    } else
      i2 = 59;
    this.setValuePart(e2, i2);
  }
  decrementMinute() {
    this.decrementMinuteOrSecond("minute");
  }
  decrementSecond() {
    this.decrementMinuteOrSecond("second");
  }
  focusHandler(e2) {
    this.pointerActivated || (this.activeEl = e2.currentTarget);
  }
  fractionalSecondKeyDownHandler(e2) {
    const { key: i2 } = e2;
    if (e.includes(i2)) {
      const s3 = s2(this.step), a = parseInt(this.fractionalSecond), n = a.toString().length;
      let r;
      n >= s3 ? r = i2.padStart(s3, "0") : n < s3 && (r = `${a}${i2}`.padStart(s3, "0")), this.setValuePart("fractionalSecond", parseFloat(`0.${r}`));
    } else
      switch (i2) {
        case "Backspace":
        case "Delete":
          this.setValuePart("fractionalSecond", null);
          break;
        case "ArrowDown":
          e2.preventDefault(), this.nudgeFractionalSecond("down");
          break;
        case "ArrowUp":
          e2.preventDefault(), this.nudgeFractionalSecond("up");
          break;
        case " ":
          e2.preventDefault();
          break;
      }
  }
  fractionalSecondDownClickHandler() {
    this.activeEl = this.fractionalSecondEl, this.fractionalSecondEl.focus(), this.nudgeFractionalSecond("down");
  }
  fractionalSecondUpClickHandler() {
    this.activeEl = this.fractionalSecondEl, this.fractionalSecondEl.focus(), this.nudgeFractionalSecond("up");
  }
  hourDownClickHandler() {
    this.activeEl = this.hourEl, this.hourEl.focus(), this.decrementHour();
  }
  hourKeyDownHandler(e2) {
    const { key: i2 } = e2;
    if (e.includes(i2)) {
      const s3 = parseInt(i2);
      let a;
      if (f(this.hour))
        switch (this.effectiveHourFormat) {
          case "12":
            a = this.hour === "01" && s3 >= 0 && s3 <= 2 ? `1${s3}` : s3;
            break;
          case "24":
            this.hour === "01" ? a = `1${s3}` : this.hour === "02" && s3 >= 0 && s3 <= 3 ? a = `2${s3}` : a = s3;
            break;
        }
      else
        a = s3;
      this.setValuePart("hour", a);
    } else
      switch (i2) {
        case "Backspace":
        case "Delete":
          this.setValuePart("hour", null);
          break;
        case "ArrowDown":
          e2.preventDefault(), this.decrementHour();
          break;
        case "ArrowUp":
          e2.preventDefault(), this.incrementHour();
          break;
        case " ":
          e2.preventDefault();
          break;
      }
  }
  hourUpClickHandler() {
    this.activeEl = this.hourEl, this.hourEl.focus(), this.incrementHour();
  }
  incrementMeridiem() {
    const e2 = this.meridiem === "AM" ? "PM" : "AM";
    this.setValuePart("meridiem", e2);
  }
  incrementHour() {
    const e2 = f(this.hour) ? this.hour === "23" ? 0 : parseInt(this.hour) + 1 : 1;
    this.setValuePart("hour", e2);
  }
  incrementMinuteOrSecond(e2) {
    const i2 = f(this[e2]) ? this[e2] === "59" ? 0 : parseInt(this[e2]) + 1 : 0;
    this.setValuePart(e2, i2);
  }
  incrementMinute() {
    this.incrementMinuteOrSecond("minute");
  }
  incrementSecond() {
    this.incrementMinuteOrSecond("second");
  }
  inputClickHandler(e2) {
    this.activeEl = e2.target;
  }
  meridiemUpClickHandler() {
    this.activeEl = this.meridiemEl, this.meridiemEl.focus(), this.incrementMeridiem();
  }
  meridiemKeyDownHandler(e2) {
    switch (e2.key) {
      case "a":
        this.setValuePart("meridiem", "AM");
        break;
      case "p":
        this.setValuePart("meridiem", "PM");
        break;
      case "Backspace":
      case "Delete":
        this.setValuePart("meridiem", null);
        break;
      case "ArrowUp":
        e2.preventDefault(), this.incrementMeridiem();
        break;
      case "ArrowDown":
        e2.preventDefault(), this.decrementMeridiem();
        break;
      case " ":
        e2.preventDefault();
        break;
    }
  }
  meridiemDownClickHandler() {
    this.activeEl = this.meridiemEl, this.meridiemEl.focus(), this.decrementMeridiem();
  }
  minuteDownClickHandler() {
    this.activeEl = this.minuteEl, this.minuteEl.focus(), this.decrementMinute();
  }
  minuteUpClickHandler() {
    this.activeEl = this.minuteEl, this.minuteEl.focus(), this.incrementMinute();
  }
  minuteKeyDownHandler(e2) {
    const { key: i2 } = e2;
    if (e.includes(i2)) {
      const s3 = parseInt(i2);
      let a;
      if (f(this.minute) && this.minute.startsWith("0")) {
        const n = parseInt(this.minute);
        a = n > U ? s3 : `${n}${s3}`;
      } else
        a = s3;
      this.setValuePart("minute", a);
    } else
      switch (i2) {
        case "Backspace":
        case "Delete":
          this.setValuePart("minute", null);
          break;
        case "ArrowDown":
          e2.preventDefault(), this.decrementMinute();
          break;
        case "ArrowUp":
          e2.preventDefault(), this.incrementMinute();
          break;
        case " ":
          e2.preventDefault();
          break;
      }
  }
  nudgeFractionalSecond(e2) {
    const i2 = i(this.step), s3 = s2(this.step), a = parseInt(this.fractionalSecond), n = parseFloat(`0.${this.fractionalSecond}`);
    let r, l2, c, u3;
    e2 === "up" && (r = isNaN(a) ? 0 : n + i2, l2 = parseFloat(r.toFixed(s3)), c = i(l2), u3 = l2 < 1 && s2(c) > 0 ? S2(c, s3) : "".padStart(s3, "0")), e2 === "down" && (r = isNaN(a) || a === 0 ? 1 - i2 : n - i2, l2 = parseFloat(r.toFixed(s3)), c = i(l2), u3 = l2 < 1 && s2(c) > 0 && Math.sign(c) === 1 ? S2(c, s3) : "".padStart(s3, "0")), this.setValuePart("fractionalSecond", u3);
  }
  sanitizeValue(e2) {
    const { hour: i2, minute: s3, second: a, fractionalSecond: n } = x(e2);
    if (n) {
      const r = this.sanitizeFractionalSecond(n);
      return `${i2}:${s3}:${a}.${r}`;
    }
    return g(e2) && e2;
  }
  sanitizeFractionalSecond(e2) {
    return e2 && s2(this.step) !== e2.length ? parseFloat(`0.${e2}`).toFixed(s2(this.step)).replace("0.", "") : e2;
  }
  secondKeyDownHandler(e2) {
    const { key: i2 } = e2;
    if (e.includes(i2)) {
      const s3 = parseInt(i2);
      let a;
      if (f(this.second) && this.second.startsWith("0")) {
        const n = parseInt(this.second);
        a = n > U ? s3 : `${n}${s3}`;
      } else
        a = s3;
      this.setValuePart("second", a);
    } else
      switch (i2) {
        case "Backspace":
        case "Delete":
          this.setValuePart("second", null);
          break;
        case "ArrowDown":
          e2.preventDefault(), this.decrementSecond();
          break;
        case "ArrowUp":
          e2.preventDefault(), this.incrementSecond();
          break;
        case " ":
          e2.preventDefault();
          break;
      }
  }
  secondDownClickHandler() {
    this.activeEl = this.secondEl, this.secondEl.focus(), this.decrementSecond();
  }
  secondUpClickHandler() {
    this.activeEl = this.secondEl, this.secondEl.focus(), this.incrementSecond();
  }
  setHourEl(e2) {
    this.hourEl = e2;
  }
  setMeridiemEl(e2) {
    this.meridiemEl = e2;
  }
  setMinuteEl(e2) {
    this.minuteEl = e2;
  }
  setSecondEl(e2) {
    this.secondEl = e2;
  }
  setFractionalSecondEl(e2) {
    this.fractionalSecondEl = e2;
  }
  setValue(e2) {
    if (g(e2)) {
      const { hour: i2, minute: s3, second: a, fractionalSecond: n } = x(e2), { effectiveHourFormat: r, messages: { _lang: l2 }, numberingSystem: c } = this, { localizedHour: u3, localizedHourSuffix: M, localizedMinute: F, localizedMinuteSuffix: P2, localizedSecond: A, localizedDecimalSeparator: V2, localizedFractionalSecond: y3, localizedSecondSuffix: U2, localizedMeridiem: $2 } = B2({
        value: e2,
        locale: l2,
        numberingSystem: c,
        hour12: r === "12"
      });
      this.hour = i2, this.minute = s3, this.second = a, this.fractionalSecond = this.sanitizeFractionalSecond(n), this.localizedHour = u3, this.localizedHourSuffix = M, this.localizedMinute = F, this.localizedMinuteSuffix = P2, this.localizedSecond = A, this.localizedDecimalSeparator = V2, this.localizedFractionalSecond = y3, this.localizedSecondSuffix = U2, $2 && (this.localizedMeridiem = $2, this.meridiem = W3(this.hour));
    } else
      this.hour = null, this.fractionalSecond = null, this.localizedHour = null, this.localizedHourSuffix = k("hour", this.messages._lang, this.numberingSystem), this.localizedMeridiem = null, this.localizedMinute = null, this.localizedMinuteSuffix = k("minute", this.messages._lang, this.numberingSystem), this.localizedSecond = null, this.localizedDecimalSeparator = D2(this.messages._lang, this.numberingSystem), this.localizedFractionalSecond = null, this.localizedSecondSuffix = k("second", this.messages._lang, this.numberingSystem), this.meridiem = null, this.minute = null, this.second = null, this.value = null;
  }
  setValuePart(e2, i2) {
    const { effectiveHourFormat: s3, messages: { _lang: a }, numberingSystem: n } = this, r = s3 === "12";
    if (e2 === "meridiem") {
      if (this.meridiem = i2, f(this.hour)) {
        const u3 = parseInt(this.hour);
        switch (i2) {
          case "AM":
            u3 >= 12 && (this.hour = S2(u3 - 12));
            break;
          case "PM":
            u3 < 12 && (this.hour = S2(u3 + 12));
            break;
        }
        this.localizedHour = y({
          value: this.hour,
          part: "hour",
          locale: a,
          numberingSystem: n,
          hour12: r
        });
      }
    } else if (e2 === "fractionalSecond") {
      const u3 = s2(this.step);
      typeof i2 == "number" ? this.fractionalSecond = i2 === 0 ? "".padStart(u3, "0") : S2(i2, u3) : this.fractionalSecond = i2, this.localizedFractionalSecond = y({
        value: this.fractionalSecond,
        part: "fractionalSecond",
        locale: a,
        numberingSystem: n,
        hour12: r
      });
    } else
      this[e2] = typeof i2 == "number" ? S2(i2) : i2, this[`localized${W4(e2)}`] = y({
        value: this[e2],
        part: e2,
        locale: a,
        numberingSystem: n,
        hour12: r
      });
    let l2 = false, c;
    this.hour && this.minute ? (c = `${this.hour}:${this.minute}`, this.showSecond && (c = `${c}:${this.second ?? "00"}`, this.showFractionalSecond && this.fractionalSecond && (c = `${c}.${this.fractionalSecond}`))) : c = null, this.value !== c && (l2 = true), this.value = c, this.localizedMeridiem = this.value ? B2({
      hour12: r,
      locale: a,
      numberingSystem: n,
      value: this.value
    })?.localizedMeridiem || null : y({ value: this.meridiem, part: "meridiem", locale: a, numberingSystem: n }), l2 && this.calciteTimePickerChange.emit();
  }
  toggleSecond() {
    this.showSecond = this.step < 60, this.showFractionalSecond = s2(this.step) > 0;
  }
  updateLocale() {
    this.effectiveHourFormat = this.hourFormat === "user" ? b(this.messages._lang) : this.hourFormat, this.localizedDecimalSeparator = D2(this.messages._lang, this.numberingSystem), this.meridiemOrder = L(this.messages._lang), this.setValue(this.sanitizeValue(this.value));
  }
  // #endregion
  render() {
    const e2 = f(this.hour), i2 = o(this.scale), s3 = f(this.minute), a = f(this.second), n = f(this.fractionalSecond), r = this.messages._lang !== "bg" && this.localizedSecondSuffix, l2 = this.effectiveHourFormat === "12";
    return html`<div class=${safeClassMap({
      [t.timePicker]: true,
      [t.showMeridiem]: l2,
      [t.showSecond]: this.showSecond,
      [t[`scale-${this.scale}`]]: true
    })} dir=ltr><div class=${safeClassMap(t.column)} role=group><span .ariaLabel=${this.messages.hourUp} class=${safeClassMap({
      [t.button]: true,
      [t.buttonHourUp]: true,
      [t.buttonTopLeft]: true
    })} @click=${this.hourUpClickHandler} role=button><calcite-icon icon=chevron-up .scale=${i2}></calcite-icon></span><span .ariaLabel=${this.messages.hour} aria-valuemax=23 aria-valuemin=1 .ariaValueNow=${e2 && parseInt(this.hour) || "0"} .ariaValueText=${this.hour} class=${safeClassMap({
      [t.input]: true,
      [t.hour]: true,
      [t.inputFocus]: this.activeEl && this.activeEl === this.hourEl
    })} @click=${this.inputClickHandler} @focus=${this.focusHandler} @keydown=${this.hourKeyDownHandler} role=spinbutton tabindex=0 ${ref(this.setHourEl)}>${this.localizedHour || "--"}</span><span .ariaLabel=${this.messages.hourDown} class=${safeClassMap({
      [t.button]: true,
      [t.buttonHourDown]: true,
      [t.buttonBottomLeft]: true
    })} @click=${this.hourDownClickHandler} role=button><calcite-icon icon=chevron-down .scale=${i2}></calcite-icon></span></div><span class=${safeClassMap({ [t.delimiter]: true, [t.hourSuffix]: true })}>${this.localizedHourSuffix}</span><div class=${safeClassMap(t.column)} role=group><span .ariaLabel=${this.messages.minuteUp} class=${safeClassMap({
      [t.button]: true,
      [t.buttonMinuteUp]: true
    })} @click=${this.minuteUpClickHandler} role=button><calcite-icon icon=chevron-up .scale=${i2}></calcite-icon></span><span .ariaLabel=${this.messages.minute} aria-valuemax=12 aria-valuemin=1 .ariaValueNow=${s3 && parseInt(this.minute) || "0"} .ariaValueText=${this.minute} class=${safeClassMap({
      [t.input]: true,
      [t.minute]: true,
      [t.inputFocus]: this.activeEl && this.activeEl === this.minuteEl
    })} @click=${this.inputClickHandler} @focus=${this.focusHandler} @keydown=${this.minuteKeyDownHandler} role=spinbutton tabindex=0 ${ref(this.setMinuteEl)}>${this.localizedMinute || "--"}</span><span .ariaLabel=${this.messages.minuteDown} class=${safeClassMap({
      [t.button]: true,
      [t.buttonMinuteDown]: true
    })} @click=${this.minuteDownClickHandler} role=button><calcite-icon icon=chevron-down .scale=${i2}></calcite-icon></span></div>${this.showSecond && html`<span class=${safeClassMap({ [t.delimiter]: true, [t.minuteSuffix]: true })}>${this.localizedMinuteSuffix}</span>` || ""}${this.showSecond && html`<div class=${safeClassMap(t.column)} role=group><span .ariaLabel=${this.messages.secondUp} class=${safeClassMap({
      [t.button]: true,
      [t.buttonSecondUp]: true
    })} @click=${this.secondUpClickHandler} role=button><calcite-icon icon=chevron-up .scale=${i2}></calcite-icon></span><span .ariaLabel=${this.messages.second} aria-valuemax=59 aria-valuemin=0 .ariaValueNow=${a && parseInt(this.second) || "0"} .ariaValueText=${this.second} class=${safeClassMap({
      [t.input]: true,
      [t.second]: true,
      [t.inputFocus]: this.activeEl && this.activeEl === this.secondEl
    })} @click=${this.inputClickHandler} @focus=${this.focusHandler} @keydown=${this.secondKeyDownHandler} role=spinbutton tabindex=0 ${ref(this.setSecondEl)}>${this.localizedSecond || "--"}</span><span .ariaLabel=${this.messages.secondDown} class=${safeClassMap({
      [t.button]: true,
      [t.buttonSecondDown]: true
    })} @click=${this.secondDownClickHandler} role=button><calcite-icon icon=chevron-down .scale=${i2}></calcite-icon></span></div>` || ""}${this.showFractionalSecond && html`<span class=${safeClassMap({ [t.delimiter]: true, [t.decimalSeparator]: true })}>${this.localizedDecimalSeparator}</span>` || ""}${this.showFractionalSecond && html`<div class=${safeClassMap(t.column)} role=group><span .ariaLabel=${this.messages.fractionalSecondUp} class=${safeClassMap({
      [t.button]: true,
      [t.buttonFractionalSecondUp]: true
    })} @click=${this.fractionalSecondUpClickHandler} role=button><calcite-icon icon=chevron-up .scale=${i2}></calcite-icon></span><span .ariaLabel=${this.messages.fractionalSecond} aria-valuemax=999 aria-valuemin=1 .ariaValueNow=${n && parseInt(this.fractionalSecond) || "0"} .ariaValueText=${this.localizedFractionalSecond} class=${safeClassMap({
      [t.input]: true,
      [t.fractionalSecond]: true,
      [t.inputFocus]: this.activeEl && this.activeEl === this.fractionalSecondEl
    })} @click=${this.inputClickHandler} @focus=${this.focusHandler} @keydown=${this.fractionalSecondKeyDownHandler} role=spinbutton tabindex=0 ${ref(this.setFractionalSecondEl)}>${this.localizedFractionalSecond || "--"}</span><span .ariaLabel=${this.messages.fractionalSecondDown} class=${safeClassMap({
      [t.button]: true,
      [t.buttonFractionalSecondDown]: true
    })} @click=${this.fractionalSecondDownClickHandler} role=button><calcite-icon icon=chevron-down .scale=${i2}></calcite-icon></span></div>` || ""}${r && html`<span class=${safeClassMap({ [t.delimiter]: true, [t.secondSuffix]: true })}>${this.localizedSecondSuffix}</span>` || ""}${l2 && html`<div class=${safeClassMap({
      [t.column]: true,
      [t.meridiemStart]: this.meridiemOrder === 0 || gt(this.el) === "rtl"
    })} role=group><span .ariaLabel=${this.messages.meridiemUp} class=${safeClassMap({
      [t.button]: true,
      [t.buttonMeridiemUp]: true,
      [t.buttonTopRight]: true
    })} @click=${this.meridiemUpClickHandler} role=button><calcite-icon icon=chevron-up .scale=${i2}></calcite-icon></span><span .ariaLabel=${this.messages.meridiem} aria-valuemax=2 aria-valuemin=1 .ariaValueNow=${this.meridiem === "PM" && "2" || "1"} .ariaValueText=${this.meridiem} class=${safeClassMap({
      [t.input]: true,
      [t.meridiem]: true,
      [t.inputFocus]: this.activeEl && this.activeEl === this.meridiemEl
    })} @click=${this.inputClickHandler} @focus=${this.focusHandler} @keydown=${this.meridiemKeyDownHandler} role=spinbutton tabindex=0 ${ref(this.setMeridiemEl)}>${this.localizedMeridiem || "--"}</span><span .ariaLabel=${this.messages.meridiemDown} class=${safeClassMap({
      [t.button]: true,
      [t.buttonMeridiemDown]: true,
      [t.buttonBottomRight]: true
    })} @click=${this.meridiemDownClickHandler} role=button><calcite-icon icon=chevron-down .scale=${i2}></calcite-icon></span></div>` || ""}</div>`;
  }
};
S("calcite-time-picker", q3);

// node_modules/dayjs/esm/plugin/localizedFormat/utils.js
var t2 = function t3(format) {
  return format.replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, function(_, a, b2) {
    return a || b2.slice(1);
  });
};
var englishFormats = {
  LTS: "h:mm:ss A",
  LT: "h:mm A",
  L: "MM/DD/YYYY",
  LL: "MMMM D, YYYY",
  LLL: "MMMM D, YYYY h:mm A",
  LLLL: "dddd, MMMM D, YYYY h:mm A"
};
var u = function u2(formatStr, formats) {
  return formatStr.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, function(_, a, b2) {
    var B3 = b2 && b2.toUpperCase();
    return a || formats[b2] || englishFormats[b2] || t2(formats[B3]);
  });
};

// node_modules/dayjs/esm/plugin/customParseFormat/index.js
var formattingTokens = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g;
var match1 = /\d/;
var match2 = /\d\d/;
var match3 = /\d{3}/;
var match4 = /\d{4}/;
var match1to2 = /\d\d?/;
var matchSigned = /[+-]?\d+/;
var matchOffset = /[+-]\d\d:?(\d\d)?|Z/;
var matchWord = /\d*[^-_:/,()\s\d]+/;
var locale = {};
var parseTwoDigitYear = function parseTwoDigitYear2(input) {
  input = +input;
  return input + (input > 68 ? 1900 : 2e3);
};
function offsetFromString(string) {
  if (!string) return 0;
  if (string === "Z") return 0;
  var parts = string.match(/([+-]|\d\d)/g);
  var minutes = +(parts[1] * 60) + (+parts[2] || 0);
  return minutes === 0 ? 0 : parts[0] === "+" ? -minutes : minutes;
}
var addInput = function addInput2(property) {
  return function(input) {
    this[property] = +input;
  };
};
var zoneExpressions = [matchOffset, function(input) {
  var zone = this.zone || (this.zone = {});
  zone.offset = offsetFromString(input);
}];
var getLocalePart = function getLocalePart2(name) {
  var part = locale[name];
  return part && (part.indexOf ? part : part.s.concat(part.f));
};
var meridiemMatch = function meridiemMatch2(input, isLowerCase) {
  var isAfternoon;
  var _locale = locale, meridiem = _locale.meridiem;
  if (!meridiem) {
    isAfternoon = input === (isLowerCase ? "pm" : "PM");
  } else {
    for (var i2 = 1; i2 <= 24; i2 += 1) {
      if (input.indexOf(meridiem(i2, 0, isLowerCase)) > -1) {
        isAfternoon = i2 > 12;
        break;
      }
    }
  }
  return isAfternoon;
};
var expressions = {
  A: [matchWord, function(input) {
    this.afternoon = meridiemMatch(input, false);
  }],
  a: [matchWord, function(input) {
    this.afternoon = meridiemMatch(input, true);
  }],
  Q: [match1, function(input) {
    this.month = (input - 1) * 3 + 1;
  }],
  S: [match1, function(input) {
    this.milliseconds = +input * 100;
  }],
  SS: [match2, function(input) {
    this.milliseconds = +input * 10;
  }],
  SSS: [match3, function(input) {
    this.milliseconds = +input;
  }],
  s: [match1to2, addInput("seconds")],
  ss: [match1to2, addInput("seconds")],
  m: [match1to2, addInput("minutes")],
  mm: [match1to2, addInput("minutes")],
  H: [match1to2, addInput("hours")],
  h: [match1to2, addInput("hours")],
  HH: [match1to2, addInput("hours")],
  hh: [match1to2, addInput("hours")],
  D: [match1to2, addInput("day")],
  DD: [match2, addInput("day")],
  Do: [matchWord, function(input) {
    var _locale2 = locale, ordinal = _locale2.ordinal;
    var _input$match = input.match(/\d+/);
    this.day = _input$match[0];
    if (!ordinal) return;
    for (var i2 = 1; i2 <= 31; i2 += 1) {
      if (ordinal(i2).replace(/\[|\]/g, "") === input) {
        this.day = i2;
      }
    }
  }],
  w: [match1to2, addInput("week")],
  ww: [match2, addInput("week")],
  M: [match1to2, addInput("month")],
  MM: [match2, addInput("month")],
  MMM: [matchWord, function(input) {
    var months = getLocalePart("months");
    var monthsShort = getLocalePart("monthsShort");
    var matchIndex = (monthsShort || months.map(function(_) {
      return _.slice(0, 3);
    })).indexOf(input) + 1;
    if (matchIndex < 1) {
      throw new Error();
    }
    this.month = matchIndex % 12 || matchIndex;
  }],
  MMMM: [matchWord, function(input) {
    var months = getLocalePart("months");
    var matchIndex = months.indexOf(input) + 1;
    if (matchIndex < 1) {
      throw new Error();
    }
    this.month = matchIndex % 12 || matchIndex;
  }],
  Y: [matchSigned, addInput("year")],
  YY: [match2, function(input) {
    this.year = parseTwoDigitYear(input);
  }],
  YYYY: [match4, addInput("year")],
  Z: zoneExpressions,
  ZZ: zoneExpressions
};
function correctHours(time) {
  var afternoon = time.afternoon;
  if (afternoon !== void 0) {
    var hours = time.hours;
    if (afternoon) {
      if (hours < 12) {
        time.hours += 12;
      }
    } else if (hours === 12) {
      time.hours = 0;
    }
    delete time.afternoon;
  }
}
function makeParser(format) {
  format = u(format, locale && locale.formats);
  var array = format.match(formattingTokens);
  var length = array.length;
  for (var i2 = 0; i2 < length; i2 += 1) {
    var token = array[i2];
    var parseTo = expressions[token];
    var regex = parseTo && parseTo[0];
    var parser = parseTo && parseTo[1];
    if (parser) {
      array[i2] = {
        regex,
        parser
      };
    } else {
      array[i2] = token.replace(/^\[|\]$/g, "");
    }
  }
  return function(input) {
    var time = {};
    for (var _i = 0, start = 0; _i < length; _i += 1) {
      var _token = array[_i];
      if (typeof _token === "string") {
        start += _token.length;
      } else {
        var _regex = _token.regex, _parser = _token.parser;
        var part = input.slice(start);
        var match = _regex.exec(part);
        var value = match[0];
        _parser.call(time, value);
        input = input.replace(value, "");
      }
    }
    correctHours(time);
    return time;
  };
}
var parseFormattedInput = function parseFormattedInput2(input, format, utc, dayjs) {
  try {
    if (["x", "X"].indexOf(format) > -1) return new Date((format === "X" ? 1e3 : 1) * input);
    var parser = makeParser(format);
    var _parser2 = parser(input), year = _parser2.year, month = _parser2.month, day = _parser2.day, hours = _parser2.hours, minutes = _parser2.minutes, seconds = _parser2.seconds, milliseconds = _parser2.milliseconds, zone = _parser2.zone, week = _parser2.week;
    var now = /* @__PURE__ */ new Date();
    var d = day || (!year && !month ? now.getDate() : 1);
    var y3 = year || now.getFullYear();
    var M = 0;
    if (!(year && !month)) {
      M = month > 0 ? month - 1 : now.getMonth();
    }
    var h = hours || 0;
    var m5 = minutes || 0;
    var s3 = seconds || 0;
    var ms = milliseconds || 0;
    if (zone) {
      return new Date(Date.UTC(y3, M, d, h, m5, s3, ms + zone.offset * 60 * 1e3));
    }
    if (utc) {
      return new Date(Date.UTC(y3, M, d, h, m5, s3, ms));
    }
    var newDate;
    newDate = new Date(y3, M, d, h, m5, s3, ms);
    if (week) {
      newDate = dayjs(newDate).week(week).toDate();
    }
    return newDate;
  } catch (e2) {
    return /* @__PURE__ */ new Date("");
  }
};
var customParseFormat_default = function(o2, C, d) {
  d.p.customParseFormat = true;
  if (o2 && o2.parseTwoDigitYear) {
    parseTwoDigitYear = o2.parseTwoDigitYear;
  }
  var proto = C.prototype;
  var oldParse = proto.parse;
  proto.parse = function(cfg) {
    var date = cfg.date, utc = cfg.utc, args = cfg.args;
    this.$u = utc;
    var format = args[1];
    if (typeof format === "string") {
      var isStrictWithoutLocale = args[2] === true;
      var isStrictWithLocale = args[3] === true;
      var isStrict = isStrictWithoutLocale || isStrictWithLocale;
      var pl = args[2];
      if (isStrictWithLocale) {
        pl = args[2];
      }
      locale = this.$locale();
      if (!isStrictWithoutLocale && pl) {
        locale = d.Ls[pl];
      }
      this.$d = parseFormattedInput(date, format, utc, d);
      this.init();
      if (pl && pl !== true) this.$L = this.locale(pl).$L;
      if (isStrict && date != this.format(format)) {
        this.$d = /* @__PURE__ */ new Date("");
      }
      locale = {};
    } else if (format instanceof Array) {
      var len = format.length;
      for (var i2 = 1; i2 <= len; i2 += 1) {
        args[1] = format[i2 - 1];
        var result = d.apply(this, args);
        if (result.isValid()) {
          this.$d = result.$d;
          this.$L = result.$L;
          this.init();
          break;
        }
        if (i2 === len) this.$d = /* @__PURE__ */ new Date("");
      }
    } else {
      oldParse.call(this, cfg);
    }
  };
};

// node_modules/dayjs/esm/plugin/localeData/index.js
var localeData_default = function(o2, c, dayjs) {
  var proto = c.prototype;
  var getLocalePart3 = function getLocalePart4(part) {
    return part && (part.indexOf ? part : part.s);
  };
  var getShort = function getShort2(ins, target, full, num, localeOrder) {
    var locale2 = ins.name ? ins : ins.$locale();
    var targetLocale = getLocalePart3(locale2[target]);
    var fullLocale = getLocalePart3(locale2[full]);
    var result = targetLocale || fullLocale.map(function(f2) {
      return f2.slice(0, num);
    });
    if (!localeOrder) return result;
    var weekStart = locale2.weekStart;
    return result.map(function(_, index) {
      return result[(index + (weekStart || 0)) % 7];
    });
  };
  var getDayjsLocaleObject = function getDayjsLocaleObject2() {
    return dayjs.Ls[dayjs.locale()];
  };
  var getLongDateFormat = function getLongDateFormat2(l2, format) {
    return l2.formats[format] || t2(l2.formats[format.toUpperCase()]);
  };
  var localeData = function localeData2() {
    var _this = this;
    return {
      months: function months(instance) {
        return instance ? instance.format("MMMM") : getShort(_this, "months");
      },
      monthsShort: function monthsShort(instance) {
        return instance ? instance.format("MMM") : getShort(_this, "monthsShort", "months", 3);
      },
      firstDayOfWeek: function firstDayOfWeek() {
        return _this.$locale().weekStart || 0;
      },
      weekdays: function weekdays(instance) {
        return instance ? instance.format("dddd") : getShort(_this, "weekdays");
      },
      weekdaysMin: function weekdaysMin(instance) {
        return instance ? instance.format("dd") : getShort(_this, "weekdaysMin", "weekdays", 2);
      },
      weekdaysShort: function weekdaysShort(instance) {
        return instance ? instance.format("ddd") : getShort(_this, "weekdaysShort", "weekdays", 3);
      },
      longDateFormat: function longDateFormat(format) {
        return getLongDateFormat(_this.$locale(), format);
      },
      meridiem: this.$locale().meridiem,
      ordinal: this.$locale().ordinal
    };
  };
  proto.localeData = function() {
    return localeData.bind(this)();
  };
  dayjs.localeData = function() {
    var localeObject = getDayjsLocaleObject();
    return {
      firstDayOfWeek: function firstDayOfWeek() {
        return localeObject.weekStart || 0;
      },
      weekdays: function weekdays() {
        return dayjs.weekdays();
      },
      weekdaysShort: function weekdaysShort() {
        return dayjs.weekdaysShort();
      },
      weekdaysMin: function weekdaysMin() {
        return dayjs.weekdaysMin();
      },
      months: function months() {
        return dayjs.months();
      },
      monthsShort: function monthsShort() {
        return dayjs.monthsShort();
      },
      longDateFormat: function longDateFormat(format) {
        return getLongDateFormat(localeObject, format);
      },
      meridiem: localeObject.meridiem,
      ordinal: localeObject.ordinal
    };
  };
  dayjs.months = function() {
    return getShort(getDayjsLocaleObject(), "months");
  };
  dayjs.monthsShort = function() {
    return getShort(getDayjsLocaleObject(), "monthsShort", "months", 3);
  };
  dayjs.weekdays = function(localeOrder) {
    return getShort(getDayjsLocaleObject(), "weekdays", null, null, localeOrder);
  };
  dayjs.weekdaysShort = function(localeOrder) {
    return getShort(getDayjsLocaleObject(), "weekdaysShort", "weekdays", 3, localeOrder);
  };
  dayjs.weekdaysMin = function(localeOrder) {
    return getShort(getDayjsLocaleObject(), "weekdaysMin", "weekdays", 2, localeOrder);
  };
};

// node_modules/dayjs/esm/plugin/localizedFormat/index.js
var localizedFormat_default = function(o2, c, d) {
  var proto = c.prototype;
  var oldFormat = proto.format;
  d.en.formats = englishFormats;
  proto.format = function(formatStr) {
    if (formatStr === void 0) {
      formatStr = FORMAT_DEFAULT;
    }
    var _this$$locale = this.$locale(), _this$$locale$formats = _this$$locale.formats, formats = _this$$locale$formats === void 0 ? {} : _this$$locale$formats;
    var result = u(formatStr, formats);
    return oldFormat.call(this, result);
  };
};

// node_modules/dayjs/esm/plugin/preParsePostFormat/index.js
var preParsePostFormat_default = function(option, dayjsClass) {
  var oldParse = dayjsClass.prototype.parse;
  dayjsClass.prototype.parse = function(cfg) {
    if (typeof cfg.date === "string") {
      var locale2 = this.$locale();
      cfg.date = locale2 && locale2.preparse ? locale2.preparse(cfg.date) : cfg.date;
    }
    return oldParse.bind(this)(cfg);
  };
  var oldFormat = dayjsClass.prototype.format;
  dayjsClass.prototype.format = function() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    var result = oldFormat.call.apply(oldFormat, [this].concat(args));
    var locale2 = this.$locale();
    return locale2 && locale2.postformat ? locale2.postformat(result) : result;
  };
  var oldFromTo = dayjsClass.prototype.fromToBase;
  if (oldFromTo) {
    dayjsClass.prototype.fromToBase = function(input, withoutSuffix, instance, isFrom) {
      var locale2 = this.$locale() || instance.$locale();
      return oldFromTo.call(this, input, withoutSuffix, instance, isFrom, locale2 && locale2.postformat);
    };
  }
};

// node_modules/dayjs/esm/plugin/updateLocale/index.js
var updateLocale_default = function(option, Dayjs, dayjs) {
  dayjs.updateLocale = function(locale2, customConfig) {
    var localeList = dayjs.Ls;
    var localeConfig = localeList[locale2];
    if (!localeConfig) return;
    var customConfigKeys = customConfig ? Object.keys(customConfig) : [];
    customConfigKeys.forEach(function(c) {
      localeConfig[c] = customConfig[c];
    });
    return localeConfig;
  };
};

// node_modules/@esri/calcite-components/dist/components/calcite-input-time-picker/customElement.js
var se = css`:host([disabled]){cursor:default;-webkit-user-select:none;user-select:none;opacity:var(--calcite-opacity-disabled)}:host([disabled]) *,:host([disabled]) ::slotted(*){pointer-events:none}:host{display:inline-block;-webkit-user-select:none;user-select:none}:host([disabled]) ::slotted([calcite-hydrated][disabled]),:host([disabled]) [calcite-hydrated][disabled]{opacity:1}.interaction-container{display:contents}::slotted(input[slot=hidden-form-input]){margin:0!important;opacity:0!important;outline:none!important;padding:0!important;position:absolute!important;inset:0!important;transform:none!important;-webkit-appearance:none!important;z-index:-1!important}:host([scale=s]){--calcite-toggle-spacing: .5rem;--calcite-internal-input-text-input-padding-inline-end: calc(var(--calcite-toggle-spacing) + 1rem)}:host([scale=m]){--calcite-toggle-spacing: .75rem;--calcite-internal-input-text-input-padding-inline-end: calc(var(--calcite-toggle-spacing) + 1.5rem)}:host([scale=l]){--calcite-toggle-spacing: 1rem;--calcite-internal-input-text-input-padding-inline-end: calc(var(--calcite-toggle-spacing) + 2rem)}.input-wrapper{position:relative}.toggle-icon{position:absolute;display:flex;cursor:pointer;align-items:center;inset-inline-end:0;inset-block:0;padding-inline:var(--calcite-toggle-spacing);--calcite-icon-color: var(--calcite-color-text-3)}.input-wrapper:hover .toggle-icon,calcite-input-text:focus+.toggle-icon{--calcite-icon-color: var(--calcite-color-text-1)}.validation-container{display:flex;flex-direction:column;align-items:flex-start;align-self:stretch}:host([scale=m]) .validation-container,:host([scale=l]) .validation-container{padding-block-start:.5rem}:host([scale=s]) .validation-container{padding-block-start:.25rem}:host([hidden]){display:none}[hidden]{display:none}`;
var ae = {
  toggleIcon: "toggle-icon"
};
var y2 = {
  validationMessage: "inputTimePickerValidationMessage"
};
var oe = /* @__PURE__ */ new Map([
  ["ar", () => import("./ar-KYEDN5NR.js")],
  ["bg", () => import("./bg-X5ZAMDRU.js")],
  ["bs", () => import("./bs-W7N5TYPD.js")],
  ["ca", () => import("./ca-BSEBC7BE.js")],
  ["cs", () => import("./cs-32EMR6RT.js")],
  ["da", () => import("./da-XCDBZCOZ.js")],
  ["de", () => import("./de-4PKHQQVG.js")],
  ["de-at", () => import("./de-at-OL2O5NWH.js")],
  ["de-ch", () => import("./de-ch-S6IUNGSW.js")],
  ["el", () => import("./el-DLL5GOHP.js")],
  ["en", () => import("./en-CPGLRYMH.js")],
  ["en-au", () => import("./en-au-FYSWUI4A.js")],
  ["en-ca", () => import("./en-ca-LPSZJZV6.js")],
  ["en-gb", () => import("./en-gb-7FP6DHNH.js")],
  ["es", () => import("./es-7KMF7CUL.js")],
  ["es-mx", () => import("./es-mx-3FTCAHW5.js")],
  ["et", () => import("./et-7WXL5PJ5.js")],
  ["fi", () => import("./fi-MNR4GXHV.js")],
  ["fr", () => import("./fr-FL4A5WRZ.js")],
  ["fr-ch", () => import("./fr-ch-3ICSDLCQ.js")],
  ["he", () => import("./he-Q4B7IWHZ.js")],
  ["hi", () => import("./hi-IIEYRASY.js")],
  ["hr", () => import("./hr-RTMTA2FM.js")],
  ["hu", () => import("./hu-73H2SHL7.js")],
  ["id", () => import("./id-AQSMMYNJ.js")],
  ["it", () => import("./it-UBYYZTB4.js")],
  ["it-ch", () => import("./it-ch-GNWTKZOO.js")],
  ["ja", () => import("./ja-FXLUTOQM.js")],
  ["ko", () => import("./ko-DPOZHWPA.js")],
  ["lt", () => import("./lt-FPXXRLCV.js")],
  ["lv", () => import("./lv-Y52KTOAV.js")],
  ["mk", () => import("./mk-VQANZMJF.js")],
  ["nl", () => import("./nl-CCLVULUF.js")],
  ["nb", () => import("./nb-LZDI7SZN.js")],
  ["pl", () => import("./pl-LLQTZ7B6.js")],
  ["pt", () => import("./pt-CS6G7N5M.js")],
  ["pt-br", () => import("./pt-br-UB475ZBM.js")],
  ["ro", () => import("./ro-WGJCZGIQ.js")],
  ["ru", () => import("./ru-R3CLWHYU.js")],
  ["sk", () => import("./sk-PCTACKER.js")],
  ["sl", () => import("./sl-GYB6VNZJ.js")],
  ["sr", () => import("./sr-JSHZUZHZ.js")],
  ["sv", () => import("./sv-YLWVGXRX.js")],
  ["th", () => import("./th-BJYRBWWV.js")],
  ["tr", () => import("./tr-KE2LQ4VB.js")],
  ["uk", () => import("./uk-UM5GSKWD.js")],
  ["vi", () => import("./vi-BVQGUTSH.js")],
  ["zh-cn", () => import("./zh-cn-A7BLHSUY.js")],
  ["zh-hk", () => import("./zh-hk-MOYEEC57.js")],
  ["zh-tw", () => import("./zh-tw-AHVYHWNZ.js")]
]);
esm_default.extend(customParseFormat_default);
esm_default.extend(localeData_default);
esm_default.extend(localizedFormat_default);
esm_default.extend(preParsePostFormat_default);
esm_default.extend(updateLocale_default);
var le = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.userChangedValue = false, this._value = null, this.disabled = false, this.focusTrapDisabled = false, this.hourFormat = "user", this.messages = s(), this.open = false, this.overlayPositioning = "absolute", this.placement = "auto", this.readOnly = false, this.required = false, this.scale = "m", this.status = "idle", this.step = 60, this.validity = {
      valid: false,
      badInput: false,
      customError: false,
      patternMismatch: false,
      rangeOverflow: false,
      rangeUnderflow: false,
      stepMismatch: false,
      tooLong: false,
      tooShort: false,
      typeMismatch: false,
      valueMissing: false
    }, this.calciteInputTimePickerBeforeClose = createEvent({ cancelable: false }), this.calciteInputTimePickerBeforeOpen = createEvent({ cancelable: false }), this.calciteInputTimePickerChange = createEvent(), this.calciteInputTimePickerClose = createEvent({ cancelable: false }), this.calciteInputTimePickerOpen = createEvent({ cancelable: false }), this.setLocalizedInputValue = (e2) => {
      this.setInputValue(this.getLocalizedTimeString(e2));
    }, this.listen("blur", this.hostBlurHandler), this.listen("keydown", this.keyDownHandler);
  }
  static {
    this.properties = { calciteInputEl: 16, effectiveHourFormat: 16, disabled: 7, focusTrapDisabled: 7, form: 3, hourFormat: 3, max: 3, messageOverrides: 0, min: 3, name: 1, numberingSystem: 1, open: 7, overlayPositioning: 1, placement: 3, readOnly: 7, required: 7, scale: 3, status: 3, step: 9, validationIcon: [3, { converter: stringOrBoolean }], validationMessage: 1, validity: 0, value: 1 };
  }
  static {
    this.shadowRootOptions = { mode: "open", delegatesFocus: true };
  }
  static {
    this.styles = se;
  }
  /** The time value in ISO (24-hour) format. */
  get value() {
    return this._value;
  }
  set value(e2) {
    const t4 = this._value;
    e2 !== t4 && (this._value = e2, this.valueWatcher(e2));
  }
  // #endregion
  // #region Public Methods
  /**
   * Updates the position of the component.
   *
   * @param delayed If true, delay the repositioning.
   */
  reposition(e2 = false) {
    return __async(this, null, function* () {
      this.popoverEl?.reposition(e2);
    });
  }
  /** Sets focus on the component. */
  setFocus() {
    return __async(this, null, function* () {
      yield m2(this), mt(this.el);
    });
  }
  connectedCallback() {
    super.connectedCallback(), g(this.value) ? this.setValueDirectly(this.value) : this.value = void 0, v(this), D(this);
  }
  load() {
    return __async(this, null, function* () {
      yield this.loadLocaleData(), this.updateLocale();
    });
  }
  willUpdate(e2) {
    e2.has("open") && (this.hasUpdated || this.open !== false) && this.openHandler(), e2.has("disabled") && (this.hasUpdated || this.disabled !== false) && (this.disabled || (this.open = false)), e2.has("hourFormat") && this.updateLocale(), e2.has("readOnly") && (this.hasUpdated || this.readOnly !== false) && (this.readOnly || (this.open = false)), e2.has("messages") && this.langWatcher(), e2.has("numberingSystem") && this.setLocalizedInputValue({ numberingSystem: e2.get("numberingSystem") }), e2.has("step") && (this.hasUpdated || this.step !== 60) && this.stepWatcher(this.step, e2.get("step"));
  }
  updated() {
    m(this);
  }
  loaded() {
    g(this.value) && this.setLocalizedInputValue();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), T(this), W(this);
  }
  // #endregion
  // #region Private Methods
  langWatcher() {
    return __async(this, null, function* () {
      yield this.loadLocaleData(), this.updateLocale();
    });
  }
  openHandler() {
    this.disabled || this.readOnly || this.popoverEl && (this.popoverEl.open = this.open);
  }
  stepWatcher(e2, t4) {
    (t4 >= 60 && e2 > 0 && e2 < 60 || e2 >= 60 && t4 > 0 && t4 < 60) && this.setValueDirectly(this.value);
  }
  valueWatcher(e2) {
    this.userChangedValue || this.setValueDirectly(e2), this.userChangedValue = false;
  }
  hostBlurHandler() {
    const e2 = this.delocalizeTimeString(this.calciteInputEl.value);
    e2 ? e2 !== this.value && (this.setValue(e2), this.setLocalizedInputValue()) : this.setValue(""), this.deactivate();
  }
  calciteInternalInputFocusHandler(e2) {
    this.readOnly || e2.stopPropagation();
  }
  calciteInternalInputInputHandler(e2) {
    const { messages: { _lang: t4 }, numberingSystem: i2 } = this;
    if (i2 && i2 !== "latn") {
      const s3 = e2.target;
      q.numberFormatOptions = {
        locale: t4,
        numberingSystem: i2,
        useGrouping: false
      };
      const l2 = q.delocalize(s3.value).split("").map((o2) => e.includes(o2) ? q.numberFormatter.format(Number(o2)) : o2).join("");
      this.setInputValue(l2);
    }
  }
  timePickerChangeHandler(e2) {
    e2.stopPropagation();
    const i2 = e2.target.value, s3 = this.shouldIncludeSeconds();
    this.setValue(q2(i2, s3)), this.setLocalizedInputValue({ isoTimeString: i2 });
  }
  updateLocale(e2 = this.messages._lang) {
    this.effectiveHourFormat = this.hourFormat === "user" ? b(this.messages._lang) : this.hourFormat, this.localeDefaultLTFormat = this.localeConfig.formats.LT, this.localeDefaultLTSFormat = this.localeConfig.formats.LTS, this.setLocalizedInputValue({ locale: e2 });
  }
  popoverBeforeOpenHandler(e2) {
    e2.stopPropagation(), this.calciteInputTimePickerBeforeOpen.emit();
  }
  popoverOpenHandler(e2) {
    e2.stopPropagation(), this.calciteInputTimePickerOpen.emit();
  }
  popoverBeforeCloseHandler(e2) {
    e2.stopPropagation(), this.calciteInputTimePickerBeforeClose.emit();
  }
  popoverCloseHandler(e2) {
    e2.stopPropagation(), this.calciteInputTimePickerClose.emit(), this.open = false;
  }
  syncHiddenFormInput(e2) {
    m4("time", this, e2);
  }
  delocalizeTimeString(e2) {
    esm_default.locale(this.getSupportedDayjsLocale(this.messages._lang.toLowerCase()));
    const t4 = this.delocalizeTimeStringToParts(e2);
    let i2;
    if (this.shouldIncludeFractionalSeconds()) {
      const s3 = s2(this.step), l2 = this.delocalizeTimeStringToParts(e2, "S");
      if (s3 === 1)
        i2 = l2.millisecond !== 0 ? this.getTimeStringFromParts(l2) : this.getTimeStringFromParts(t4);
      else {
        const o2 = this.delocalizeTimeStringToParts(e2, "SS");
        if (s3 === 2)
          o2.millisecond !== 0 ? i2 = this.getTimeStringFromParts(o2) : l2.millisecond !== 0 ? i2 = this.getTimeStringFromParts(l2) : i2 = this.getTimeStringFromParts(t4);
        else if (s3 >= 3) {
          const n = this.delocalizeTimeStringToParts(e2, "SSS");
          n.millisecond !== 0 ? i2 = this.getTimeStringFromParts(n) : o2.millisecond !== 0 ? i2 = this.getTimeStringFromParts(o2) : l2.millisecond !== 0 ? i2 = this.getTimeStringFromParts(l2) : i2 = this.getTimeStringFromParts(t4);
        }
      }
    } else
      i2 = this.getTimeStringFromParts(t4);
    return i2;
  }
  delocalizeTimeStringToParts(e2, t4) {
    const i2 = this.messages._lang;
    let s3 = e2;
    const l2 = Z(this.effectiveHourFormat, i2) ? H2(i2) : b(i2);
    if (W2.has(i2) && l2 === "12") {
      const n = W2.get(i2).am, a = W2.get(i2).pm, c = E(i2), m5 = c === c.toUpperCase() ? "AM" : "am", d = c === c.toUpperCase() ? "PM" : "pm";
      s3 = s3.includes(a) ? s3.replaceAll(a, d) : s3.replaceAll(n, m5);
    }
    this.setLocaleTimeFormat({
      fractionalSecondFormatToken: t4,
      hourFormat: l2
    });
    const o2 = esm_default(s3, ["LTS", "LT"]);
    return o2.isValid() ? {
      hour: o2.get("hour"),
      minute: o2.get("minute"),
      second: o2.get("second"),
      millisecond: o2.get("millisecond")
    } : {
      hour: null,
      minute: null,
      second: null,
      millisecond: null
    };
  }
  getTimeStringFromParts(e2) {
    let t4 = "";
    if (!e2)
      return t4;
    if (e2.hour !== null && e2.minute !== null && (t4 = `${S2(e2.hour)}:${S2(e2.minute)}`, this.shouldIncludeSeconds() && e2.second !== null && (t4 += `:${S2(e2.second)}`, this.shouldIncludeFractionalSeconds() && e2.millisecond !== null))) {
      const i2 = (e2.millisecond * 1e-3).toFixed(s2(this.step));
      t4 += `.${i2.toString().replace("0.", "")}`;
    }
    return t4;
  }
  keyDownHandler(e2) {
    const { defaultPrevented: t4, key: i2 } = e2;
    if (!t4)
      if (i2 === "Enter") {
        if ($(this) && (e2.preventDefault(), this.calciteInputEl.setFocus()), e2.composedPath().includes(this.calciteTimePickerEl))
          return;
        const s3 = this.delocalizeTimeString(this.calciteInputEl.value);
        g(s3) ? (this.setValue(s3), this.setLocalizedInputValue()) : this.setValue("");
      } else i2 === "ArrowDown" ? (this.open = true, e2.preventDefault()) : this.open && this.focusTrapDisabled && i2 === "Escape" && (this.open = false, e2.preventDefault());
  }
  getSupportedDayjsLocale(e2) {
    const t4 = e2.toLowerCase();
    return t4 === "no" ? "nb" : t4 === "pt-pt" ? "pt" : t4;
  }
  loadLocaleData() {
    return __async(this, null, function* () {
      let e2 = O(this.messages._lang).toLowerCase();
      e2 = this.getSupportedDayjsLocale(e2);
      const { default: t4 } = yield oe.get(e2)();
      this.localeConfig = t4, esm_default.locale(this.localeConfig, null, true), esm_default.updateLocale(e2, this.getExtendedLocaleConfig(e2));
    });
  }
  getExtendedLocaleConfig(e2) {
    if (e2 === "ar")
      return {
        meridiem: (t4) => t4 > 12 ? "م" : "ص",
        formats: {
          LT: "h:mm a",
          LTS: "h:mm:ss a",
          L: "DD/MM/YYYY",
          LL: "D MMMM YYYY",
          LLL: "D MMMM YYYY h:mm a",
          LLLL: "dddd D MMMM YYYY h:mm a"
        }
      };
    if (e2 === "en-au")
      return {
        meridiem: (t4) => t4 > 12 ? "pm" : "am"
      };
    if (e2 === "en-ca")
      return {
        meridiem: (t4) => t4 > 12 ? "p.m." : "a.m."
      };
    if (e2 === "el")
      return {
        meridiem: (t4) => t4 > 12 ? "μ.μ." : "π.μ."
      };
    if (e2 === "es-mx")
      return {
        formats: {
          LT: "h:mm a",
          LTS: "h:mm:ss a",
          L: "DD/MM/YYYY",
          LL: "D [de] MMMM [de] YYYY",
          LLL: "D [de] MMMM [de] YYYY H:mm",
          LLLL: "dddd, D [de] MMMM [de] YYYY H:mm"
        }
      };
    if (e2 === "hi")
      return {
        formats: {
          LT: "h:mm A",
          LTS: "h:mm:ss A",
          L: "DD/MM/YYYY",
          LL: "D MMMM YYYY",
          LLL: "D MMMM YYYY, h:mm A",
          LLLL: "dddd, D MMMM YYYY, h:mm A"
        },
        meridiem: (t4) => t4 > 12 ? "pm" : "am"
      };
    if (e2 === "ja")
      return {
        meridiem: (t4) => t4 > 12 ? "午後" : "午前"
      };
    if (e2 === "ko")
      return {
        meridiem: (t4) => t4 > 12 ? "오후" : "오전"
      };
    if (e2 === "no")
      return {
        meridiem: (t4) => t4 > 12 ? "p.m." : "a.m."
      };
    if (e2 === "ru")
      return {
        meridiem: (t4) => t4 > 12 ? "PM" : "AM"
      };
    if (e2 === "zh-cn")
      return {
        meridiem: (t4) => t4 > 12 ? "下午" : "上午"
      };
    if (e2 === "zh-tw")
      return {
        formats: {
          LT: "Ah:mm",
          LTS: "Ah:mm:ss"
        }
      };
    if (e2 === "zh-hk")
      return {
        formats: {
          LT: "Ah:mm",
          LTS: "Ah:mm:ss"
        },
        meridiem: (t4) => t4 > 12 ? "下午" : "上午"
      };
  }
  getLocalizedTimeString(e2) {
    const t4 = e2?.hourFormat === "12" || this.effectiveHourFormat && this.effectiveHourFormat === "12", i2 = e2?.locale ?? this.messages._lang, s3 = e2?.numberingSystem ?? this.numberingSystem, l2 = e2?.isoTimeString ?? this.value;
    return j({
      fractionalSecondDigits: s2(this.step),
      hour12: t4,
      includeSeconds: this.shouldIncludeSeconds(),
      locale: i2,
      numberingSystem: s3,
      value: l2
    }) ?? "";
  }
  onLabelClick() {
    this.setFocus();
  }
  shouldIncludeSeconds() {
    return this.step < 60;
  }
  shouldIncludeFractionalSeconds() {
    return s2(this.step) > 0;
  }
  setCalcitePopoverEl(e2) {
    this.popoverEl = e2, this.openHandler();
  }
  setInputEl(e2) {
    e2 && (this.calciteInputEl = e2);
  }
  setCalciteTimePickerEl(e2) {
    e2 && (this.calciteTimePickerEl = e2);
  }
  setLocaleTimeFormat({ fractionalSecondFormatToken: e2, hourFormat: t4 }) {
    const i2 = this.messages._lang, s3 = b(i2), l2 = /h+|H+/g, o2 = /\s+|a+|A+|\s+/g;
    let n = this.localeConfig.formats.LT, a = this.localeConfig.formats.LTS;
    if (t4 === "12" && s3 === "24") {
      const m5 = E(i2), d = L(i2);
      n = n.replaceAll(l2, "h"), n = n.replaceAll(o2, ""), n = d === 0 ? `${m5}${n}` : `${n}${m5}`, a = a.replaceAll(l2, "h"), a = a.replaceAll(o2, ""), a = d === 0 ? `${m5}${a}` : `${a}${m5}`;
    } else t4 === "24" && s3 === "12" ? (n = n.replaceAll(l2, "H"), n = n.replaceAll(o2, ""), a = a.replaceAll(l2, "H"), a = a.replaceAll(o2, "")) : (n = this.localeDefaultLTFormat, a = this.localeDefaultLTSFormat);
    const c = a?.match(/ss\.*(S+)/g);
    if (e2 && this.shouldIncludeFractionalSeconds()) {
      const m5 = `ss.${e2}`;
      a = c ? a.replace(c[0], m5) : a.replace("ss", m5);
    } else c && (a = a.replace(c[0], "ss"));
    this.localeConfig.formats.LT = n, this.localeConfig.formats.LTS = a, esm_default.updateLocale(this.getSupportedDayjsLocale(O(i2)), this.localeConfig);
  }
  setInputValue(e2) {
    this.calciteInputEl && (this.calciteInputEl.value = e2);
  }
  /**
   * Sets the value and emits a change event.
   * This is used to update the value as a result of user interaction.
   *
   * @param value The new value
   */
  setValue(e2) {
    const t4 = this.value, i2 = V(e2) || "";
    if (i2 === t4)
      return;
    this.userChangedValue = true, this.value = i2 || "", this.calciteInputTimePickerChange.emit().defaultPrevented && (this.userChangedValue = false, this.value = t4, this.setLocalizedInputValue({ isoTimeString: t4 }));
  }
  /**
   * Sets the value directly without emitting a change event.
   * This is used to update the value on initial load and when props change that are not the result of user interaction.
   *
   * @param value The new value
   */
  setValueDirectly(e2) {
    const t4 = this.shouldIncludeSeconds();
    this.value = q2(e2, t4), this.setLocalizedInputValue();
  }
  onInputWrapperClick() {
    this.open = !this.open;
  }
  deactivate() {
    this.open = false;
  }
  // #endregion
  // #region Rendering
  render() {
    const { disabled: e2, messages: t4, readOnly: i2 } = this;
    return p({ disabled: this.disabled, children: html`<div class="input-wrapper" @click=${this.onInputWrapperClick}><calcite-input-text aria-errormessage=${y2.validationMessage} aria-autocomplete=none aria-haspopup=dialog .ariaInvalid=${this.status === "invalid"} .disabled=${e2} icon=clock .label=${I(this)} lang=${this.messages._lang ?? nothing} @calciteInputTextInput=${this.calciteInternalInputInputHandler} @calciteInternalInputTextFocus=${this.calciteInternalInputFocusHandler} .readOnly=${i2} role=combobox .scale=${this.scale} .status=${this.status} ${ref(this.setInputEl)}>${!this.readOnly && this.renderToggleIcon(this.open) || ""}</calcite-input-text></div><calcite-popover auto-close .focusTrapDisabled=${this.focusTrapDisabled} .focusTrapOptions=${{ initialFocus: false }} .label=${t4.chooseTime} lang=${this.messages._lang ?? nothing} @calcitePopoverBeforeClose=${this.popoverBeforeCloseHandler} @calcitePopoverBeforeOpen=${this.popoverBeforeOpenHandler} @calcitePopoverClose=${this.popoverCloseHandler} @calcitePopoverOpen=${this.popoverOpenHandler} .overlayPositioning=${this.overlayPositioning} .placement=${this.placement} .referenceElement=${this.calciteInputEl} trigger-disabled ${ref(this.setCalcitePopoverEl)}><calcite-time-picker .hourFormat=${this.effectiveHourFormat} lang=${this.messages._lang ?? nothing} .messageOverrides=${this.messageOverrides} .numberingSystem=${this.numberingSystem} @calciteTimePickerChange=${this.timePickerChangeHandler} .scale=${this.scale} .step=${this.step} tabindex=${(this.open ? void 0 : -1) ?? nothing} .value=${this.value} ${ref(this.setCalciteTimePickerEl)}></calcite-time-picker></calcite-popover>${B({ component: this })}${this.validationMessage && this.status === "invalid" ? m3({ icon: this.validationIcon, id: y2.validationMessage, message: this.validationMessage, scale: this.scale, status: this.status }) : null}` });
  }
  renderToggleIcon(e2) {
    return html`<span class=${safeClassMap(ae.toggleIcon)} slot=action><calcite-icon .icon=${e2 ? "chevron-up" : "chevron-down"} .scale=${o(this.scale)}></calcite-icon></span>`;
  }
};
S("calcite-input-time-picker", le);
export {
  le as InputTimePicker
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/time.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-time-picker/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-input-time-picker/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=calcite-input-time-picker-5HBZ2UVE.js.map
