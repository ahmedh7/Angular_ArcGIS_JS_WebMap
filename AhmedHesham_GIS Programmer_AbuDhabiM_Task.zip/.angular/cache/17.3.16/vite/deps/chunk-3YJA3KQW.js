import {
  Xe,
  ke
} from "./chunk-3SPX7DOW.js";
import {
  o
} from "./chunk-ULISRLN2.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  d
} from "./chunk-TZVX7A54.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  __async,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/support/TitleCreator.js
var p = "relationships/";
var c = "expression/";
var d2 = class extends g {
  constructor(e) {
    super(e), this._featureUtils = null, this.effectivePopupTemplate = null;
  }
  get _arcadeTask() {
    if (this.expressionsUsedInTitle.length > 0) {
      return this._get("_arcadeTask") || d(() => o());
    }
    return null;
  }
  get featureUtilsPromise() {
    return this._get("featureUtilsPromise") ?? import("./featureUtils-OZXN2EIK.js").then((e) => this._featureUtils = e);
  }
  get calculatedExpressions() {
    const e = new V();
    if (!this.expressionsUsedInTitle.length) return e;
    if (!this._arcadeTask?.value) {
      for (const t of this.expressionsUsedInTitle ?? []) e.push({ name: t.name, invalid: true });
      return e;
    }
    for (const t of this.expressionsUsedInTitle) try {
      const s = this._arcadeTask.value.arcade.parseScript(t.expression, ["$layer", "$map", "$datastore"]);
      if (s.isAsync) {
        e.push({ name: t.name, invalid: true });
        break;
      }
      e.push({ name: t.name, syntax: s, invalid: false, func: this._arcadeTask.value.arcade.compileScript(s, { vars: { $feature: "any" } }) });
    } catch {
      e.push({ name: t.name, invalid: true });
      break;
    }
    return e;
  }
  get expressionsUsedInTitle() {
    let e = this.effectivePopupTemplate?.title ?? "";
    return "string" != typeof e ? [] : (e = e.toLowerCase(), this.effectivePopupTemplate?.expressionInfos?.filter((t) => e.includes(`{expression/${t.name.toLowerCase()}}`)) ?? []);
  }
  get fieldInfoMap() {
    return this._featureUtils ? this._createFieldInfoMap(this._featureUtils.getAllFieldInfos(this.effectivePopupTemplate)) : null;
  }
  get hasBadExpressions() {
    return this.calculatedExpressions.some((e) => true === e.invalid);
  }
  get requiredFields() {
    const e = /* @__PURE__ */ new Set();
    if (this._arcadeTask?.value && !this.hasBadExpressions) for (const s of this.calculatedExpressions?.toArray() ?? []) try {
      const t2 = this._arcadeTask.value.arcade.extractFieldLiterals(s.syntax);
      for (const s2 of t2) {
        const t3 = s2.split("."), i = this.fieldsIndex.get(t3.at(-1) ?? "");
        i && e.add(i.name);
      }
    } catch {
    }
    const t = this._extractFieldNames(this.workingTitle);
    for (const s of t) {
      const t2 = this.fieldsIndex.get(s);
      t2 && e.add(t2.name);
    }
    return e;
  }
  get titleFromDisplayField() {
    let e = "";
    return this.displayField && (e = this.fieldsIndex.get(this.displayField)?.name ?? ""), e || (e = this.fieldsIndex.get(this.objectIdField)?.name ?? ""), e ? `{${e}}` : "";
  }
  get workingTitle() {
    const e = this.effectivePopupTemplate ? this.effectivePopupTemplate.title : "";
    return "" === e || null == e || this.hasBadExpressions || "string" != typeof e ? this.titleFromDisplayField : e;
  }
  getTitle(e, t, s) {
    return __async(this, null, function* () {
      try {
        const { attributes: i } = t, r2 = s?.timeZone ?? "system", [{ substituteFieldsInLinksAndAttributes: a2 }] = yield Promise.all([this.featureUtilsPromise, this._arcadeTask?.promise]);
        if (s.fetchMissingFields && (t = yield this._checkAndReQueryGraphic(e, t)), this.workingTitle && this.fieldInfoMap) {
          const s2 = this._createFormattedAttributes(e, t, r2).global;
          return a2({ attributes: i, expressionAttributes: null, fieldInfoMap: this.fieldInfoMap, globalAttributes: s2, layer: e, text: this.workingTitle });
        }
        return "";
      } catch {
      }
      return "";
    });
  }
  _checkAndReQueryGraphic(e, t) {
    return __async(this, null, function* () {
      const s = t.getObjectId();
      if (null == s) return t;
      if (!ke(this.requiredFields, t)) {
        const t2 = e.createQuery();
        t2.where = "1=1", t2.outFields = [...this.requiredFields], t2.objectIds = [s];
        const i = yield e.queryFeatures(t2);
        if (1 === i?.features.length) return i.features[0];
      }
      return t;
    });
  }
  _createFieldInfoMap(e) {
    const t = /* @__PURE__ */ new Map();
    if (!e) return t;
    for (const s of e) {
      if (!s.fieldName) continue;
      const e2 = this.fieldsIndex.get(s.fieldName), i = e2?.name ?? s.fieldName;
      s.fieldName = i, t.set(i.toLowerCase(), s);
    }
    return t;
  }
  _createFormattedAttributes(e, t, s = "system") {
    const i = this.effectivePopupTemplate?.fieldInfos ?? [], r2 = {};
    if (!this._featureUtils) return {};
    if (!this.hasBadExpressions && this.calculatedExpressions.length > 0 && this._arcadeTask?.value) {
      const s2 = this._arcadeTask.value.Feature.createFromGraphicLikeObject(t.geometry, t.attributes, e, null);
      for (const e2 of this.calculatedExpressions) try {
        r2[`expression/${e2.name}`] = e2.func({ vars: { $feature: s2 } });
      } catch {
      }
    }
    const a2 = __spreadValues(__spreadValues({}, t.attributes), r2);
    return { global: this._featureUtils.formatAttributes({ fieldInfos: i, attributes: a2, graphic: t, timeZone: s, layer: e, fieldInfoMap: this.fieldInfoMap }), content: [] };
  }
  _extractFieldNames(e) {
    return Xe(e).filter((e2) => !(0 === e2.indexOf(p) || 0 === e2.indexOf(c)));
  }
};
r([m({ readOnly: true })], d2.prototype, "_arcadeTask", null), r([m()], d2.prototype, "_featureUtils", void 0), r([m({ readOnly: true })], d2.prototype, "featureUtilsPromise", null), r([m({ readOnly: true })], d2.prototype, "calculatedExpressions", null), r([m()], d2.prototype, "displayField", void 0), r([m()], d2.prototype, "effectivePopupTemplate", void 0), r([m()], d2.prototype, "expressionsUsedInTitle", null), r([m()], d2.prototype, "fieldsIndex", void 0), r([m()], d2.prototype, "fieldInfoMap", null), r([m()], d2.prototype, "fields", void 0), r([m()], d2.prototype, "objectIdField", void 0), r([m()], d2.prototype, "requiredFields", null), d2 = r([a("esri.layers.support.TitleCreator")], d2);
var u = d2;

export {
  u
};
//# sourceMappingURL=chunk-3YJA3KQW.js.map
