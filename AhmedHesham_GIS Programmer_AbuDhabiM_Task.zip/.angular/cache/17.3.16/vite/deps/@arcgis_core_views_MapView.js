import {
  g as g6,
  l as l5
} from "./chunk-V3G2D7LW.js";
import "./chunk-ZCYDOVQX.js";
import {
  i as i6,
  n as n14,
  o as o10,
  r as r11
} from "./chunk-VCMSD6S6.js";
import {
  o as o9
} from "./chunk-RXQKGJEY.js";
import {
  e as e13
} from "./chunk-JOHWFF2N.js";
import {
  r as r13
} from "./chunk-DV4XAZXR.js";
import {
  _ as _2,
  d as d5,
  t2 as t9
} from "./chunk-TOC3BXJP.js";
import "./chunk-4UFPVFZG.js";
import {
  r as r14
} from "./chunk-ILKILLWA.js";
import {
  m as m8
} from "./chunk-SQ26WZ7J.js";
import {
  g as g7,
  t as t12
} from "./chunk-PAXNBAQG.js";
import {
  c3 as c9,
  e as e12,
  u as u6
} from "./chunk-LYJYKR5U.js";
import {
  t as t11
} from "./chunk-272SUFHQ.js";
import {
  a as a5,
  c as c8,
  r as r12,
  s as s13
} from "./chunk-4A7XBP5F.js";
import {
  o as o8
} from "./chunk-GTHV6SQV.js";
import {
  Gt,
  H,
  Y,
  Z,
  _ as _3,
  at,
  ft,
  gt,
  ht,
  jt,
  kt,
  lt,
  m as m3,
  mt,
  ot,
  pt,
  tt,
  ut,
  wt,
  xt,
  yt
} from "./chunk-LDQQXG3C.js";
import {
  e as e10
} from "./chunk-MPZGLJHN.js";
import {
  r as r10
} from "./chunk-LGV2N5ZC.js";
import {
  i as i5
} from "./chunk-NEUXHWYB.js";
import "./chunk-YPWSYT7S.js";
import {
  h as h7,
  s as s11
} from "./chunk-UF7FRKBZ.js";
import {
  h as h6
} from "./chunk-N3UNX5HB.js";
import {
  t as t8
} from "./chunk-H2P3UBJX.js";
import {
  t as t7
} from "./chunk-Z5NJN26E.js";
import {
  e as e8
} from "./chunk-UQISDG6Y.js";
import "./chunk-VACYGDXY.js";
import {
  I,
  I2
} from "./chunk-S3WAQSEF.js";
import "./chunk-3UR6P3OM.js";
import {
  c as c6,
  l as l4,
  n as n12
} from "./chunk-OVUDVDEJ.js";
import "./chunk-XPIZMMFW.js";
import {
  t as t6
} from "./chunk-77RFUTEK.js";
import "./chunk-L3LR7QC5.js";
import "./chunk-MKDJERJR.js";
import "./chunk-O3P5XPEU.js";
import {
  n as n11
} from "./chunk-UPSWNHFU.js";
import "./chunk-ZMOJDLSO.js";
import {
  M as M3,
  h as h5,
  i as i3,
  o as o6,
  r as r8
} from "./chunk-EDBHW3EG.js";
import {
  S as S3,
  e as e7,
  m as m5,
  o as o7,
  r as r9
} from "./chunk-3RDPSSYB.js";
import {
  g as g5
} from "./chunk-SZIT3IYE.js";
import {
  P as P2
} from "./chunk-CVMQJ2BZ.js";
import "./chunk-UX6MBXX3.js";
import "./chunk-BF5XGRKQ.js";
import "./chunk-ZFPFQ4J4.js";
import "./chunk-P5BI27MR.js";
import {
  e as e11
} from "./chunk-AH3BFXAV.js";
import {
  c as c7,
  m as m6,
  p as p6
} from "./chunk-DTRN4OOH.js";
import "./chunk-ZENTKHGR.js";
import {
  s as s6
} from "./chunk-3P3SZYCX.js";
import {
  n as n13
} from "./chunk-4VNKTESB.js";
import {
  f as f3,
  i as i4,
  s as s12,
  u as u5
} from "./chunk-KVZR5ILN.js";
import {
  m as m7
} from "./chunk-NEOVY6GP.js";
import "./chunk-ELAKODAU.js";
import {
  v as v2
} from "./chunk-RY6EUXME.js";
import "./chunk-CMPLJJCX.js";
import "./chunk-JHB4QD5T.js";
import {
  b as b2
} from "./chunk-XWFSWJ3K.js";
import "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import {
  b as b3
} from "./chunk-7OZN72PM.js";
import "./chunk-Z4ITP2HY.js";
import "./chunk-WOVS7CNY.js";
import "./chunk-4VQUNH2Z.js";
import "./chunk-7SLET7NM.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import {
  a as a4
} from "./chunk-J3AJBXLW.js";
import {
  l as l3
} from "./chunk-GW436Z36.js";
import {
  p as p5,
  z
} from "./chunk-MMJWRZE3.js";
import "./chunk-WSZKFRXT.js";
import {
  K,
  L as L2,
  O as O2,
  U,
  k
} from "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import {
  n as n6
} from "./chunk-ECG7JDDX.js";
import {
  t as t10
} from "./chunk-NE6ESLWJ.js";
import {
  e as e9
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c as c3,
  e as e4,
  n as n4,
  t as t4
} from "./chunk-PPAPRIQT.js";
import {
  i as i2,
  n2 as n5
} from "./chunk-L7IGKLK6.js";
import {
  T,
  g as g3
} from "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import {
  L as L3
} from "./chunk-S7AA7ZZE.js";
import {
  n as n10
} from "./chunk-NJQL4TDO.js";
import {
  n as n7
} from "./chunk-52K7EZBS.js";
import "./chunk-RQSCVY76.js";
import "./chunk-723TUEOK.js";
import {
  f as f2
} from "./chunk-GYDLT2MD.js";
import {
  h as h4
} from "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import {
  p as p4
} from "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import "./chunk-KW4QKNM6.js";
import "./chunk-LYIAE2PQ.js";
import "./chunk-C6UECS42.js";
import "./chunk-B6U4AYDJ.js";
import "./chunk-JCECTBEZ.js";
import "./chunk-YFQQ5MRE.js";
import "./chunk-CYXXOYR3.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import {
  e as e6,
  u as u4
} from "./chunk-FHAIN2FL.js";
import {
  n as n8
} from "./chunk-7NHDAECT.js";
import {
  c as c4
} from "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import {
  c as c5,
  l as l2
} from "./chunk-2K433C2G.js";
import "./chunk-EOJGN7NW.js";
import {
  m as m4
} from "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import {
  n as n9
} from "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import {
  p as p2
} from "./chunk-XYTETMU6.js";
import {
  A as A3,
  C,
  P,
  d as d3,
  p as p3,
  v,
  w
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  i
} from "./chunk-JEGE7NFK.js";
import {
  _,
  d as d2
} from "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import {
  e as e3,
  p
} from "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import {
  h as h3,
  r as r5
} from "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import {
  j as j3
} from "./chunk-GMDCM6PU.js";
import {
  s as s8
} from "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import {
  M as M2,
  s as s10,
  u as u3
} from "./chunk-3X4RHLTI.js";
import {
  f,
  t as t5,
  w as w2
} from "./chunk-FMVDY4TM.js";
import {
  e2 as e5,
  j,
  j2,
  y
} from "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import {
  g as g4
} from "./chunk-P5ELECBN.js";
import {
  M,
  o as o5,
  r as r7,
  s as s9
} from "./chunk-HJWYGMG7.js";
import {
  d as d4,
  r as r6,
  s2 as s7
} from "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import {
  s as s5
} from "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import {
  S as S2
} from "./chunk-XIZ4X35L.js";
import {
  c2,
  g as g2,
  m,
  o,
  o2,
  r2 as r3,
  s2 as s3,
  t,
  t3 as t2
} from "./chunk-UNFSMTII.js";
import {
  a3,
  h,
  n as n2,
  r as r2,
  s2
} from "./chunk-QYUZVPLR.js";
import {
  A as A2,
  F
} from "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  A,
  E,
  L,
  S,
  b,
  c2 as c,
  d,
  e,
  e2,
  g,
  h as h2,
  l2 as l,
  m as m2,
  o3,
  o4,
  s as s4,
  u2 as u,
  u3 as u2
} from "./chunk-VT56RVNM.js";
import {
  n as n3,
  r as r4,
  t as t3
} from "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a as a2,
  n2 as n,
  s2 as s
} from "./chunk-JB56QM27.js";
import {
  G,
  a,
  has
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/BreakpointsOwner.js
var l6 = { widthBreakpoint: { getValue(e28) {
  const i25 = e28.viewSize[0], s31 = e28.breakpoints, a27 = this.values;
  return i25 <= s31.xsmall ? a27.xsmall : i25 <= s31.small ? a27.small : i25 <= s31.medium ? a27.medium : i25 <= s31.large ? a27.large : a27.xlarge;
}, values: { xsmall: "xsmall", small: "small", medium: "medium", large: "large", xlarge: "xlarge" }, valueToClassName: { xsmall: "esri-view-width-xsmall esri-view-width-less-than-small esri-view-width-less-than-medium esri-view-width-less-than-large esri-view-width-less-than-xlarge", small: "esri-view-width-small esri-view-width-greater-than-xsmall esri-view-width-less-than-medium esri-view-width-less-than-large esri-view-width-less-than-xlarge", medium: "esri-view-width-medium esri-view-width-greater-than-xsmall esri-view-width-greater-than-small esri-view-width-less-than-large esri-view-width-less-than-xlarge", large: "esri-view-width-large esri-view-width-greater-than-xsmall esri-view-width-greater-than-small esri-view-width-greater-than-medium esri-view-width-less-than-xlarge", xlarge: "esri-view-width-xlarge esri-view-width-greater-than-xsmall esri-view-width-greater-than-small esri-view-width-greater-than-medium esri-view-width-greater-than-large" } }, heightBreakpoint: { getValue(e28) {
  const i25 = e28.viewSize[1], s31 = e28.breakpoints, a27 = this.values;
  return i25 <= s31.xsmall ? a27.xsmall : i25 <= s31.small ? a27.small : i25 <= s31.medium ? a27.medium : i25 <= s31.large ? a27.large : a27.xlarge;
}, values: { xsmall: "xsmall", small: "small", medium: "medium", large: "large", xlarge: "xlarge" }, valueToClassName: { xsmall: "esri-view-height-xsmall esri-view-height-less-than-small esri-view-height-less-than-medium esri-view-height-less-than-large esri-view-height-less-than-xlarge", small: "esri-view-height-small esri-view-height-greater-than-xsmall esri-view-height-less-than-medium esri-view-height-less-than-large esri-view-height-less-than-xlarge", medium: "esri-view-height-medium esri-view-height-greater-than-xsmall esri-view-height-greater-than-small esri-view-height-less-than-large esri-view-height-less-than-xlarge", large: "esri-view-height-large esri-view-height-greater-than-xsmall esri-view-height-greater-than-small esri-view-height-greater-than-medium esri-view-height-less-than-xlarge", xlarge: "esri-view-height-xlarge esri-view-height-greater-than-xsmall esri-view-height-greater-than-small esri-view-height-greater-than-medium esri-view-height-greater-than-large" } }, orientation: { getValue(e28) {
  const i25 = e28.viewSize, s31 = i25[0], a27 = i25[1], t30 = this.values;
  return a27 >= s31 ? t30.portrait : t30.landscape;
}, values: { portrait: "portrait", landscape: "landscape" }, valueToClassName: { portrait: "esri-view-orientation-portrait", landscape: "esri-view-orientation-landscape" } } };
var h8 = { xsmall: 544, small: 768, medium: 992, large: 1200 };
function n15(e28) {
  const i25 = e28;
  return i25 && i25.xsmall < i25.small && i25.small < i25.medium && i25.medium < i25.large;
}
function m9(e28, i25) {
  return i25 ? l6[e28].valueToClassName[i25].split(" ") : [];
}
var o11 = (o29) => {
  let g16 = class extends o29 {
    constructor(...e28) {
      super(...e28), this.orientation = null, this.widthBreakpoint = null, this.heightBreakpoint = null, this.breakpoints = h8;
    }
    initialize() {
      this.addHandles(d3(() => [this.breakpoints, this.size], () => this._updateClassNames(), P));
    }
    destroy() {
      this.destroyed || this._removeActiveClassNames();
    }
    set breakpoints(e28) {
      if (e28 === this._get("breakpoints")) return;
      if (!n15(e28)) {
        const i25 = JSON.stringify(h8, null, 2);
        console.warn("provided breakpoints are not valid, using defaults:" + i25), e28 = h8;
      }
      this._set("breakpoints", __spreadValues({}, e28));
    }
    _updateClassNames() {
      if (!this.container) return;
      const e28 = t2.acquire(), s31 = t2.acquire();
      let a27, t30 = false;
      for (a27 in l6) {
        const i25 = this[a27], r33 = l6[a27].getValue({ viewSize: this.size, breakpoints: this.breakpoints });
        i25 !== r33 && (t30 = true, this[a27] = r33, m9(a27, i25).forEach((e29) => s31.push(e29)), m9(a27, r33).forEach((i26) => e28.push(i26)));
      }
      t30 && (this._applyClassNameChanges(e28, s31), t2.release(e28), t2.release(s31));
    }
    _applyClassNameChanges(e28, i25) {
      const s31 = this.container;
      s31 && (i25.forEach((e29) => s31.classList.remove(e29)), e28.forEach((e29) => s31.classList.add(e29)));
    }
    _removeActiveClassNames() {
      const e28 = this.container;
      if (!e28) return;
      let i25;
      for (i25 in l6) m9(i25, this[i25]).forEach((i26) => e28.classList.remove(i26));
    }
  };
  return r([m()], g16.prototype, "breakpoints", null), r([m()], g16.prototype, "orientation", void 0), r([m()], g16.prototype, "widthBreakpoint", void 0), r([m()], g16.prototype, "heightBreakpoint", void 0), g16 = r([a3("esri.views.BreakpointsOwner")], g16), g16;
};

// node_modules/@arcgis/core/views/overlay/ViewOverlay.js
var a6 = class extends g2 {
  constructor() {
    super(...arguments), this.items = new V(), this._watchUpdatingTracking = new h6(), this._callbacks = /* @__PURE__ */ new Map(), this._projector = i2(), this._hiddenProjector = i2();
  }
  get needsRender() {
    return this.items.length > 0;
  }
  get updating() {
    return this._watchUpdatingTracking?.updating ?? false;
  }
  initialize() {
    const t30 = document.createElement("div");
    t30.className = "esri-overlay-surface", this._set("surface", t30), this._hiddenSurface = document.createElement("div"), this._hiddenSurface.setAttribute("style", "visibility: hidden;"), t30.appendChild(this._hiddenSurface), this._watchUpdatingTracking.addOnCollectionChange(() => this.items, (t31) => {
      for (const e28 of t31.added) {
        const t32 = () => e28.render();
        this._callbacks.set(e28, t32), this._projector.append(this.surface, t32);
      }
      for (const e28 of t31.removed) {
        const t32 = this._projector.detach(this._callbacks.get(e28));
        this.surface.removeChild(t32.domNode), this._callbacks.delete(e28);
      }
    });
  }
  addItem(t30) {
    this.items.add(t30);
  }
  removeItem(t30) {
    this.items.remove(t30);
  }
  destroy() {
    this.items.removeAll(), this._callbacks.forEach((t30) => this._projector.detach(t30)), this._callbacks = null, this._projector = null, this._watchUpdatingTracking.destroy();
  }
  render() {
    this._projector.renderNow();
  }
  computeBoundingRect(t30) {
    const e28 = this._hiddenSurface, o29 = this._hiddenProjector;
    let r33;
    const s31 = () => (r33 = t30.render(), r33);
    o29.append(e28, s31), o29.renderNow();
    const i25 = { left: 0, top: 0, right: 0, bottom: 0 };
    if (r33?.domNode) {
      const t31 = r33.domNode.getBoundingClientRect();
      i25.left = t31.left, i25.top = t31.top, i25.right = t31.right, i25.bottom = t31.bottom;
    }
    for (o29.detach(s31); e28.firstChild; ) e28.removeChild(e28.firstChild);
    return i25;
  }
  overlaps(t30, e28) {
    const o29 = this.computeBoundingRect(t30), r33 = this.computeBoundingRect(e28);
    return Math.max(o29.left, r33.left) <= Math.min(o29.right, r33.right) && Math.max(o29.top, r33.top) <= Math.min(o29.bottom, r33.bottom);
  }
  get hasVisibleItems() {
    return this.items.some((t30) => t30.visible);
  }
  prepare() {
    return __async(this, null, function* () {
      yield document.fonts.load(this._fontString()).catch(() => {
      });
    });
  }
  renderCanvas(t30, e28) {
    const o29 = !!e28?.disableDecorations;
    if (!this.items.some((t31) => t31.visible && !(o29 && t31.isDecoration))) return;
    const r33 = t30.getContext("2d");
    r33.save(), r33.font = this._fontString(), this.items.forEach((t31) => {
      o29 && t31.isDecoration || (r33.save(), t31.renderCanvas(r33), r33.restore());
    }), r33.restore();
  }
  _fontString() {
    return `10px ${getComputedStyle(this.surface).fontFamily}`;
  }
};
r([m({ readOnly: true })], a6.prototype, "surface", void 0), r([m({ readOnly: true })], a6.prototype, "items", void 0), r([m({ readOnly: true })], a6.prototype, "needsRender", null), r([m({ readOnly: true })], a6.prototype, "_watchUpdatingTracking", void 0), r([m({ readOnly: true })], a6.prototype, "updating", null), a6 = r([a3("esri.views.overlay.ViewOverlay")], a6);
var c10 = a6;

// node_modules/@arcgis/core/views/DOMContainer.js
var p7 = [0, 0];
function m10(e28) {
  const t30 = (e28.ownerDocument || window.document).defaultView, s31 = e28.getBoundingClientRect();
  return p7[0] = s31.left + (t30?.pageXOffset ?? 0), p7[1] = s31.top + (t30?.pageYOffset ?? 0), p7;
}
function f4(e28) {
  e28 && (e28.textContent = "", e28.parentNode && e28.parentNode.removeChild(e28));
}
function y2(e28) {
  const t30 = document.createElement("div");
  return e28.appendChild(t30), t30;
}
var g8 = 16;
var v3 = 750;
var _4 = 512;
var w3 = 2;
var C2 = (p31) => {
  let C7 = class extends p31 {
    constructor(...e28) {
      super(...e28), this._freqInfo = { freq: g8, time: v3 }, this._overlayRenderTaskHandle = null, this.height = 0, this.messagesCommon = null, this.overlay = null, this.position = null, this.resizing = false, this.root = null, this.surface = null, this.suspended = true, this.ui = null, this.userContent = null, this.width = 0, this.widthBreakpoint = null, this.addHandles([d3(() => this.cursor, (e29) => {
        const { surface: t30 } = this;
        t30 && t30.setAttribute("data-cursor", e29);
      }), d3(() => this.navigating, (e29) => {
        const { surface: t30 } = this;
        t30 && t30.setAttribute("data-navigating", e29.toString());
      })]);
    }
    initialize() {
      this.addHandles([d3(() => this.ui, (e28, t30) => this._handleUIChange(e28, t30), P), this.on("focus", () => this.notifyChange("focused")), this.on("blur", () => this.notifyChange("focused"))]);
    }
    destroy() {
      this.destroyed || (this.ui?.destroy(), this.container = null);
    }
    get container() {
      return this._get("container") ?? null;
    }
    set container(e28) {
      const i25 = this._get("container"), r33 = n4(e28);
      if (r33 || "string" != typeof e28 || n.getLogger(this).error("#container", `element with id '${e28}' not found`), i25 === r33) return;
      if (this._stopMeasuring(), i25 && (i25.classList.remove("esri-view"), this._overlayRenderTaskHandle && (this._overlayRenderTaskHandle.remove(), this._overlayRenderTaskHandle = null), this.overlay && (this.overlay.destroy(), this._set("overlay", null)), this.root && (f4(this.root), this._set("root", null)), this.userContent && (t4(this.userContent, i25), f4(this.userContent), this._set("userContent", null))), !r33) return this._set("width", 0), this._set("height", 0), this._set("position", null), this._set("suspended", true), this._set("surface", null), void this._set("container", null);
      r33.classList.add("esri-view");
      const h21 = document.createElement("div");
      h21.className = "esri-view-user-storage", t4(r33, h21), r33.appendChild(h21), this._set("userContent", h21);
      const l20 = document.createElement("div");
      l20.className = "esri-view-root", r33.insertBefore(l20, r33.firstChild), this._set("root", l20);
      const u17 = document.createElement("div");
      u17.className = "esri-view-surface", u17.setAttribute("role", "application"), u17.tabIndex = 0, l20.appendChild(u17), this._set("surface", u17);
      const p32 = new c10();
      l20.appendChild(p32.surface), this._set("overlay", p32), this.addHandles(d3(() => p32.needsRender, (e29) => {
        e29 && !this._overlayRenderTaskHandle ? this._overlayRenderTaskHandle = F({ render: () => this.overlay?.render() }) : this._overlayRenderTaskHandle = l(this._overlayRenderTaskHandle);
      })), this.forceDOMReadyCycle(), this._set("container", r33), this._startMeasuring();
    }
    get focused() {
      const e28 = document.activeElement === this.surface;
      return document.hasFocus() && e28;
    }
    get size() {
      return [this.width, this.height];
    }
    blur() {
      this.surface?.blur();
    }
    focus() {
      this.surface?.focus();
    }
    pageToContainer(e28, t30, s31) {
      const i25 = this.position;
      return e28 -= i25 ? i25[0] : 0, t30 -= i25 ? i25[1] : 0, s31 ? (s31[0] = e28, s31[1] = t30) : s31 = [e28, t30], s31;
    }
    containerToPage(e28, t30, s31) {
      const i25 = this.position;
      return e28 += i25 ? i25[0] : 0, t30 += i25 ? i25[1] : 0, s31 ? (s31[0] = e28, s31[1] = t30) : s31 = [e28, t30], s31;
    }
    _handleUIChange(e28, t30) {
      this.removeHandles("ui"), t30 && t30 !== e28 && t30.destroy(), e28 && (e28.view = this, this.addHandles(d3(() => this.root, (t31) => {
        e28.container = t31 ? y2(t31) : null;
      }, P), "ui")), this._set("ui", e28);
    }
    _stopMeasuring() {
      this.removeHandles("measuring"), this._get("resizing") && this._set("resizing", false);
    }
    _startMeasuring() {
      const e28 = this._freqInfo;
      e28.freq = g8, e28.time = v3;
      const t30 = F({ prepare: (e29) => {
        const s32 = this._measure(), i25 = this._freqInfo;
        if (i25.time += e29.deltaTime, s32 && (i25.freq = g8, this._get("resizing") || this._set("resizing", true)), i25.time < i25.freq) return;
        i25.time = 0;
        const r33 = this._position();
        i25.freq = r33 || s32 ? g8 : Math.min(v3, i25.freq * w3), !s32 && i25.freq >= _4 && (t30.pause(), this._get("resizing") && this._set("resizing", false));
      } }), s31 = new ResizeObserver((s32) => {
        e28.freq = g8, e28.time = v3, t30.resume();
      });
      null != this.container && s31.observe(this.container);
      const o29 = e(() => s31.disconnect());
      this.addHandles([o4(window, "resize", () => {
        e28.freq = g8, e28.time = v3, t30.resume();
      }), o29, t30], "measuring"), this._measure(), this._position();
    }
    _measure() {
      const e28 = this.container, t30 = e28 ? e28.clientWidth : 0, s31 = e28 ? e28.clientHeight : 0;
      if (0 === t30 || 0 === s31) return this.suspended || this._set("suspended", true), false;
      const i25 = this.width, r33 = this.height;
      return t30 === i25 && s31 === r33 ? (this.suspended && this._set("suspended", false), false) : (this._set("width", t30), this._set("height", s31), this.suspended && this._set("suspended", false), this.emit("resize", { oldWidth: i25, oldHeight: r33, width: t30, height: s31 }), true);
    }
    _position() {
      const e28 = this.container, t30 = this.position, s31 = e28 && m10(e28);
      return !!s31 && ((!t30 || s31[0] !== t30[0] || s31[1] !== t30[1]) && (this._set("position", [s31[0], s31[1]]), true));
    }
    forceDOMReadyCycle() {
    }
  };
  return r([m()], C7.prototype, "container", null), r([m({ readOnly: true })], C7.prototype, "focused", null), r([m({ readOnly: true })], C7.prototype, "height", void 0), r([m()], C7.prototype, "messagesCommon", void 0), r([m({ type: c10 })], C7.prototype, "overlay", void 0), r([m({ readOnly: true })], C7.prototype, "position", void 0), r([m({ readOnly: true })], C7.prototype, "resizing", void 0), r([m({ readOnly: true })], C7.prototype, "root", void 0), r([m({ value: null, readOnly: true })], C7.prototype, "size", null), r([m({ readOnly: true })], C7.prototype, "surface", void 0), r([m({ readOnly: true })], C7.prototype, "suspended", void 0), r([m({ nonNullable: true })], C7.prototype, "ui", void 0), r([m({ readOnly: true })], C7.prototype, "userContent", void 0), r([m({ readOnly: true })], C7.prototype, "width", void 0), r([m()], C7.prototype, "widthBreakpoint", void 0), C7 = r([a3("esri.views.DOMContainer")], C7), C7;
};

// node_modules/@arcgis/core/views/PopupView.js
function m11(p31) {
  return null != p31 && "open" in p31 && "declaredClass" in p31;
}
function f5(p31) {
  return null != p31 && "declaredClass" in p31 && "dockOptions" in p31;
}
var w4 = (a27) => {
  let w10 = class extends a27 {
    constructor() {
      super(...arguments), this._popupSetupTask = null, this.popup = {}, this.popupEnabled = true;
    }
    initialize() {
      this.addHandles([d3(() => [this.ui, this.popup], ([p31, e28], t30) => {
        const o29 = "popup", i25 = "manual";
        if (t30) {
          const [p32, e29] = t30;
          p32 && m11(e29) && (e29.view = null, f5(e29) && p32.remove(e29, o29));
        }
        p31 && m11(e28) && (e28.view = this, f5(e28) && p31.add(e28, { key: o29, position: i25, internal: true }));
      }, P), this.on("click", (p31) => {
        this.popup && this.popupEnabled && ("mouse" !== p31.pointerType || 0 === p31.button) && (m11(this.popup) ? this.popup.viewModel.handleViewClick(p31) : p31.async(() => __async(this, null, function* () {
          yield this.setupPopup(), m11(this.popup) && !this.destroyed && this.ready && this.popupEnabled && this.popup.viewModel.handleViewClick(p31);
        })));
      }, _2.WIDGET)]), w(() => this.ready && this.popupEnabled && !this.updating).then(() => {
        import("./Popup-PKVKW63T.js");
      });
    }
    destroy() {
      this.destroyed || this.closePopup();
    }
    openPopup(p31) {
      return __async(this, null, function* () {
        if (m11(this.popup)) return this.popup.open(p31);
        try {
          if (yield this.setupPopup(), !this.popup) return void n.getLogger(this).error(new s("view:null-popup", "Popup is null and can't be opened"));
          this.popup.open(p31);
        } catch {
        }
      });
    }
    closePopup() {
      this._popupSetupTask?.abort(), m11(this.popup) && this.popup.close();
    }
    fetchPopupFeatures(p31, e28) {
      return __async(this, null, function* () {
        return yield this.when(), this._popupHitsToFeatures(yield this._getPopupHits(p31, e28), e28);
      });
    }
    setupPopup() {
      return __async(this, null, function* () {
        if (this._popupSetupTask?.abort(), this.popup && !m11(this.popup)) return this._popupSetupTask = d2((p31) => __async(this, null, function* () {
          const { default: e28 } = yield import("./Popup-PKVKW63T.js");
          if (s4(p31), !this.popup || m11(this.popup)) return;
          const t30 = this.popup;
          delete t30.open, delete t30.close, this.popup = new e28(t30);
        })), this._popupSetupTask.promise;
      });
    }
    _popupHitsToFeatures(_0, _1) {
      return __async(this, arguments, function* ({ location: p31, hits: e28 }, t30) {
        const o29 = [], i25 = [];
        let a28 = false;
        const u17 = E(t30, has("popup-view-fetch-timeout") ?? P3), n33 = (p32) => {
          const e29 = new y3(p32);
          return i25.push(e29), o29.push(e29.promise), e29;
        }, c29 = (p32) => {
          const e29 = i25.at(-1);
          return e29 && e29.layerView === p32 && !a28 ? e29 : n33(p32);
        };
        for (const s31 of e28) if ("graphic" in s31) {
          c29(s31.layerView).graphics.push(s31.graphic), a28 = false;
        } else o29.push(s31.layerView.fetchPopupFeaturesAtLocation(s31.mapPoint, u17)), a28 = true;
        i25.map((p32) => p32.resolve(u17));
        const h21 = g(o29).then((p32) => p32.filter((p33) => !!p33).flat());
        return { pendingFeatures: o29, allGraphicsPromise: h21, location: p31 };
      });
    }
    _getPopupHits(p31, e28) {
      return __async(this, null, function* () {
        const { hits: t30, location: o29 } = yield this.popupHitTest(p31);
        s4(e28);
        const s31 = [];
        for (const i25 of t30) if ("graphic" in i25) {
          if (this._isValidPopupGraphic(i25.graphic, e28)) {
            const p32 = this._isValidPopupGraphicsLayerView(i25.layerView) ? i25.layerView : void 0;
            s31.push({ graphic: i25.graphic, layerView: p32 });
          }
        } else this._isValidPopupLocationLayerView(i25.layerView) && s31.push({ mapPoint: i25.mapPoint, layerView: i25.layerView });
        return { hits: s31, location: o29 };
      });
    }
    _isValidPopupGraphic(p31, e28) {
      return p31 && !!p31.getEffectivePopupTemplate(e28?.defaultPopupTemplateEnabled);
    }
    _isValidPopupGraphicsLayerView(p31) {
      return !p31 || (!("layer" in p31) || !p31.suspended) && "fetchPopupFeaturesFromGraphics" in p31;
    }
    _isValidPopupLocationLayerView(p31) {
      return (!("layer" in p31) || !p31.suspended) && "fetchPopupFeaturesAtLocation" in p31;
    }
  };
  return r([m()], w10.prototype, "popup", void 0), r([m()], w10.prototype, "popupEnabled", void 0), w10 = r([a3("esri.views.PopupView")], w10), w10;
};
var y3 = class {
  constructor(p31) {
    this.layerView = p31, this._resolver = L(), this.graphics = [];
  }
  get promise() {
    return this._resolver.promise;
  }
  resolve(p31) {
    const { layerView: e28, graphics: t30, _resolver: o29 } = this;
    if (!e28) return o29.resolve(t30), o29.promise;
    let i25;
    return e28.fetchPopupFeaturesFromGraphics(t30, p31).catch((p32) => (i25 = p32, null)).then((p32) => {
      p32 ? o29.resolve(p32) : o29.reject(i25);
    }), o29.promise;
  }
};
var P3 = 5e3;

// node_modules/@arcgis/core/support/AnalysesCollection.js
var t13 = class extends n12 {
  constructor(e28) {
    super(e28), this.addHandles(this.on("before-add", (e29) => {
      null != e29.item && e29.item.parent === this.owner && (n.getLogger(this).warn("Analysis inside the collection must be unique. Not adding this element again."), e29.preventDefault());
    }));
  }
  _own(e28) {
    e28.parent = this.owner;
  }
  _release(e28) {
    e28.parent = null;
  }
};
t13 = r([a3("esri.support.AnalysesCollection")], t13);

// node_modules/@arcgis/core/views/BasemapView.js
var n16 = class extends g2 {
  constructor(e28) {
    super(e28), this.view = null, this.baseLayerViews = new V(), this.referenceLayerViews = new V(), this._loadingHandle = d3(() => this.view?.map?.basemap, (e29) => {
      e29 && e29.load().catch(() => {
      });
    }, P);
  }
  destroy() {
    this._set("view", null), this._loadingHandle && (this._loadingHandle.remove(), this._loadingHandle = null);
    for (const e28 of this.baseLayerViews) e28.destroy();
    this.baseLayerViews.length = 0;
    for (const e28 of this.referenceLayerViews) e28.destroy();
    this.referenceLayerViews.length = 0;
  }
  get suspended() {
    return this.view?.suspended ?? true;
  }
  get updating() {
    if (this.view?.suspended) return false;
    const e28 = this.view?.map?.basemap;
    return !!e28?.loaded && (this.baseLayerViews.some((e29) => e29.updating) || this.referenceLayerViews.some((e29) => e29.updating));
  }
};
r([m({ constructOnly: true })], n16.prototype, "view", void 0), r([m({ readOnly: true })], n16.prototype, "baseLayerViews", void 0), r([m({ readOnly: true })], n16.prototype, "referenceLayerViews", void 0), r([m({ readOnly: true })], n16.prototype, "suspended", null), r([m({ type: Boolean, readOnly: true })], n16.prototype, "updating", null), n16 = r([a3("esri.views.BasemapView")], n16);
var p8 = n16;

// node_modules/@arcgis/core/views/LayerViewManager.js
function v4(e28) {
  return "tryRecycleWith" in e28;
}
function L4(e28) {
  return null != e28 && "object" == typeof e28 && "layerViews" in e28;
}
var M4 = class {
  constructor(e28, r33, t30) {
    this.layer = e28, this.view = r33, this.layerViewImporter = t30, this._controller = new AbortController(), this._deferred = L(), this._started = false, this.done = false, this.promise = this._deferred.promise, m2(this._controller.signal, () => {
      const r34 = new s("cancelled:layerview-create", "layerview creation cancelled", { layer: e28 });
      this._deferred.reject(r34);
    });
  }
  tryRecycle(e28) {
    if (!this.done || !this.layerView || !v4(this.layerView)) return null;
    const r33 = this.layer.type, i25 = this._controller.signal;
    for (let t30 = 0; t30 < e28.length; t30++) {
      const s31 = e28[t30];
      if (s31.type !== r33) continue;
      const a27 = this.layerView.tryRecycleWith(s31, { signal: i25 });
      if (a27) {
        e28.splice(t30, 1), this.layer = s31;
        const r34 = this.layerView, i26 = r34.view;
        return this.promise = Promise.race([a27.then(() => (s4(this._controller.signal), s31.emit("layerview-destroy", { view: i26, layerView: r34 }), i26.emit("layerview-destroy", { view: i26, layerView: r34 }), s31.emit("layerview-create", { view: i26, layerView: r34 }), i26.emit("layerview-create", { view: i26, layerView: r34 }), r34)), new Promise((e29, r35) => m2(this._controller.signal, () => r35(u2())))]), this.promise;
      }
    }
    return null;
  }
  destroy() {
    this._controller.abort();
    const { layerView: e28 } = this;
    if (e28) {
      const { layer: r33, view: i25 } = this;
      r33.emit("layerview-destroy", { view: i25, layerView: e28 }), i25.emit("layerview-destroy", { layer: r33, layerView: e28 });
    }
    this.done = true, this.layer = null, this.layerView = null, this.view = null, this.layerViewImporter = null, this._map = null;
  }
  start() {
    return __async(this, null, function* () {
      if (this._started) return;
      this._started = true;
      const { _controller: { signal: e28 }, layer: r33, view: t30 } = this;
      this._map = t30.map;
      try {
        let o29, l20;
        if (yield r33.load({ signal: e28 }), r33.prefetchResources && (yield r33.prefetchResources({ signal: e28 })), C3(r33)) o29 = yield r33.createLayerView(t30, { signal: e28 });
        else {
          if (!this.layerViewImporter.hasLayerViewModule(r33)) throw new s("layer:view-not-supported", "No layerview implementation was found");
          const s31 = yield this.layerViewImporter.importLayerView(r33);
          s4(e28), o29 = "default" in s31 ? new s31.default({ layer: r33, view: t30 }) : new s31({ layer: r33, view: t30 });
        }
        const n33 = () => {
          l20 = l(l20), o29.destroyed || o29.destroy(), o29.layer = null, o29.parent = null, o29.view = null, this.done = true;
        };
        l20 = m2(e28, n33), s4(e28);
        try {
          yield o29.when();
        } catch (s31) {
          throw n33(), s31;
        }
        const c29 = this._map?.allLayers?.includes(r33);
        if (!c29) return n33(), void this._deferred.reject(new s("view:no-layerview-for-layer", "The layer has been removed from the map", { layer: r33 }));
        this.layerView = o29, r33.emit("layerview-create", { view: t30, layerView: o29 }), t30.emit("layerview-create", { layer: r33, layerView: o29 }), this.done = true, this._deferred.resolve(o29);
      } catch (s31) {
        r33.emit("layerview-create-error", { view: t30, error: s31 }), t30.emit("layerview-create-error", { layer: r33, error: s31 }), this.done = true, this._deferred.reject(new s("layerview:create-error", "layerview creation failed", { layer: r33, error: s31 }));
      }
    });
  }
};
var I3 = class extends g2 {
  constructor(e28) {
    super(e28), this._layerLayerViewInfoMap = /* @__PURE__ */ new Map(), this._recyclingInfoMap = /* @__PURE__ */ new Map(), this._watchUpdatingTracking = new h6(), this.supportsGround = true, this._preloadLayerViewModules = () => {
      const e29 = this.view.map?.allLayers;
      if (e29) for (const r33 of e29) this.layerViewImporter.hasLayerViewModule(r33) && this.layerViewImporter.importLayerView(r33);
    }, this._reschedule = () => this.destroyed ? Promise.reject() : (null == this._workPromise && (this._workPromise = L(), this._workPromise.promise.catch(() => {
    })), this.removeHandles("reschedule"), this.addHandles(A2(this._doWork), "reschedule"), this._workPromise.promise), this._doWork = () => {
      if (this.destroyed) return;
      const e29 = this.view.map;
      if (this._map !== e29 && (this.clear(), this._map = e29), null == this._workPromise) return void this.notifyChange("updating");
      this.removeHandles("reschedule"), this.removeHandles("collection-change");
      const r33 = /* @__PURE__ */ new Set(), i25 = [], t30 = this.view.ready, s31 = (e30) => {
        if (null != e30) {
          for (const a28 of e30) if (a28) {
            r33.add(a28);
            const e31 = this._layerLayerViewInfoMap.get(a28);
            e31 && t30 ? e31.start() : e31 || this._recyclingInfoMap.has(a28) || i25.push(a28), "layers" in a28 && a28.layers && s31(a28.layers);
          }
        }
      };
      for (const o29 of this._rootCollectionNames) s31(o(this, o29));
      for (const [o29, l20] of this._layerLayerViewInfoMap) if (!r33.has(o29)) {
        this._layerLayerViewInfoMap.delete(l20.layer);
        const e30 = l20.tryRecycle(i25);
        e30 ? (this.notifyChange("updating"), this._recyclingInfoMap.set(l20.layer, l20), e30.then(() => {
          this.notifyChange("updating"), this._recyclingInfoMap.delete(l20.layer), this._layerLayerViewInfoMap.set(l20.layer, l20), this._reschedule();
        }).catch(() => {
          this.notifyChange("updating"), this._recyclingInfoMap.delete(l20.layer), l20.destroy(), this._reschedule();
        })) : l20.destroy();
      }
      for (const [o29, l20] of this._recyclingInfoMap) r33.has(o29) || (this.notifyChange("updating"), this._recyclingInfoMap.delete(l20.layer), l20.destroy());
      for (const o29 of i25) this._createLayerView(o29);
      this._refreshCollections();
      const a27 = [e29?.ground?.layers, e29?.basemap?.baseLayers, e29?.basemap?.referenceLayers, e29?.layers].filter((e30) => !!e30);
      r33.forEach((e30) => "layers" in e30 && a27.push(e30.layers)), this.addHandles(a27.map((e30) => this._watchUpdatingTracking.addOnCollectionChange(() => e30, this._reschedule)), "collection-change"), this._workPromise.resolve(), this._workPromise = null;
    };
  }
  initialize() {
    this.addHandles([v(() => this.view?.map?.allLayers, "change", this._preloadLayerViewModules, { onListenerAdd: this._preloadLayerViewModules }), d3(() => {
      const e28 = this.view, r33 = e28?.map;
      return [r33?.basemap, r33?.ground, r33?.layers, e28?.ready];
    }, () => this._reschedule(), A3)]), this._preloadLayerViewModules(), this._reschedule();
  }
  destroy() {
    this.clear(), n10(this._recyclingInfoMap), n10(this._layerLayerViewInfoMap), this._watchUpdatingTracking.destroy(), this._map = null, null != this._workPromise && (this._workPromise.reject(u2()), this._workPromise = null);
  }
  get _layersToLayerViews() {
    const e28 = [["view.map.basemap.baseLayers", "view.basemapView.baseLayerViews"], ["view.map.layers", "view.layerViews"], ["view.map.basemap.referenceLayers", "view.basemapView.referenceLayerViews"]];
    return this.supportsGround && e28.push(["view.map.ground.layers", "view.groundView.layerViews"]), new Map(e28);
  }
  get _rootCollectionNames() {
    return Array.from(this._layersToLayerViews.keys());
  }
  get updating() {
    return null != this._workPromise || this._watchUpdatingTracking.updating || n2(this._layerLayerViewInfoMap, (e28) => !e28.done) || this._recyclingInfoMap.size > 0;
  }
  get updatingRemaining() {
    let e28 = 0;
    for (const r33 of this._layerLayerViewInfoMap.values()) r33.done || ++e28;
    return e28;
  }
  clear() {
    this.destroyed || (n10(this._layerLayerViewInfoMap), this._refreshCollections());
  }
  whenLayerView(e28) {
    return __async(this, null, function* () {
      if (yield this._reschedule(), !this._layerLayerViewInfoMap.has(e28)) {
        if (this._recyclingInfoMap.has(e28)) return this._recyclingInfoMap.get(e28).promise;
        throw new s("view:no-layerview-for-layer", "No layerview has been found for the layer", { layer: e28 });
      }
      return this._layerLayerViewInfoMap.get(e28).promise;
    });
  }
  isCreatingLayerViewsForLayer(e28, r33) {
    this.commitProperty("updatingRemaining");
    const i25 = this._layerLayerViewInfoMap.get(e28);
    if (!i25?.done) return true;
    const t30 = i25.layerView;
    return !(!t30 || !r33 || t30.parent === r33) || !!(i25.done && t30 && "layers" in e28 && e28.layers?.length) && e28.layers.some((e29) => this.isCreatingLayerViewsForLayer(e29, t30));
  }
  _refreshCollections() {
    for (const [e28, r33] of this._layersToLayerViews) this._populateLayerViewsOwners(o(this, e28), o(this, r33), this.view);
    this.notifyChange("updating"), this.notifyChange("updatingRemaining");
  }
  _populateLayerViewsOwners(e28, r33, i25) {
    if (!e28 || !r33) return void (r33 && r33.removeAll());
    let t30 = 0;
    for (const s31 of e28) {
      const e29 = this._layerLayerViewInfoMap.get(s31);
      if (!e29?.layerView) continue;
      const a27 = e29.layerView;
      a27.layer = s31, a27.parent = i25, r33.at(t30) !== a27 && r33.splice(t30, 0, a27), "layers" in s31 && L4(a27) && this._populateLayerViewsOwners(s31.layers, a27.layerViews, a27), t30 += 1;
    }
    t30 < r33.length && r33.splice(t30, r33.length);
  }
  _createLayerView(e28) {
    e28.load().catch(() => {
    }), this.layerViewImporter.hasLayerViewModule(e28) && this.layerViewImporter.importLayerView(e28);
    const r33 = new M4(e28, this.view, this.layerViewImporter);
    r33.promise.then(() => this._refreshCollections(), (r34) => {
      r34 && (b(r34) || "cancelled:layerview-create" === r34.name) || n.getLogger(this).error(`Failed to create layerview for layer title:'${e28.title ?? "no title"}', id:'${e28.id ?? "no id"}' of type '${e28.type}'.`, { layer: e28, error: r34 }), this._refreshCollections();
    }), this._layerLayerViewInfoMap.set(e28, r33), this.view.ready && r33.start(), this.notifyChange("updating"), this.notifyChange("updatingRemaining");
  }
};
r([m()], I3.prototype, "_workPromise", void 0), r([m({ readOnly: true })], I3.prototype, "_watchUpdatingTracking", void 0), r([m({ readOnly: true })], I3.prototype, "_layersToLayerViews", null), r([m({ readOnly: true })], I3.prototype, "_rootCollectionNames", null), r([m()], I3.prototype, "layerViewImporter", void 0), r([m()], I3.prototype, "supportsGround", void 0), r([m({ readOnly: true })], I3.prototype, "updating", null), r([m({ readOnly: true })], I3.prototype, "updatingRemaining", null), r([m({ constructOnly: true })], I3.prototype, "view", void 0), I3 = r([a3("esri.views.LayerViewManager")], I3);
var j4 = I3;
function C3(e28) {
  return e28.createLayerView !== f2.prototype.createLayerView;
}

// node_modules/@arcgis/core/views/Magnifier.js
var i7 = class extends g2 {
  constructor(o29) {
    super(o29), this.factor = 1.5, this.offset = c4(0, 0), this.position = null, this.size = 120, this.maskUrl = null, this.maskEnabled = true, this.overlayUrl = null, this.overlayEnabled = true, this.visible = true;
  }
  get version() {
    return this.commitProperty("factor"), this.commitProperty("offset"), this.commitProperty("position"), this.commitProperty("visible"), this.commitProperty("size"), this.commitProperty("maskUrl"), this.commitProperty("maskEnabled"), this.commitProperty("overlayUrl"), this.commitProperty("overlayEnabled"), (this._get("version") || 0) + 1;
  }
};
r([m({ type: Number })], i7.prototype, "factor", void 0), r([m({ nonNullable: true })], i7.prototype, "offset", void 0), r([m()], i7.prototype, "position", void 0), r([m({ type: Number, range: { min: 0 } })], i7.prototype, "size", void 0), r([m()], i7.prototype, "maskUrl", void 0), r([m()], i7.prototype, "maskEnabled", void 0), r([m()], i7.prototype, "overlayUrl", void 0), r([m()], i7.prototype, "overlayEnabled", void 0), r([m({ readOnly: true })], i7.prototype, "version", null), r([m({ type: Boolean })], i7.prototype, "visible", void 0), i7 = r([a3("esri.views.Magnifier")], i7);
var p9 = i7;

// node_modules/@arcgis/core/views/SelectionManager.js
var y4 = class extends i.EventedAccessor {
  constructor(e28) {
    super(e28), this._selectionMap = new s6(), this._sources = new V(), this._trashCan = [], this._layerEditHandles = new V(), this._vizTaskId = 0, this.showHighlight = true, this.highlightName = "default";
  }
  initialize() {
    this.addHandles([d3(() => [this.view, this.showHighlight], () => this._refreshVisualization()), v(() => this.sources, "change", (e29) => {
      const t30 = this._selectionMap;
      for (const s31 of e29.removed) t30.delete(s31);
      this._refreshListeners(), this._refreshVisualization();
    }, { onListenerAdd: () => this._refreshListeners() })]);
    const e28 = new V();
    this.view.when().then(() => {
      this.view.map && (this.view.map.allLayers.flatten((e29) => "sublayers" in e29 && e29.sublayers ? e29.sublayers : null).forEach((t30) => {
        (e11(t30) && !c5(t30) || l2(t30)) && e28.add(t30);
      }), this.sources = e28);
    });
  }
  destroy() {
    this._layerEditHandles.drain(l);
  }
  get selections() {
    return Array.from(this._selectionMap.entries()).map((e28) => {
      const [t30, s31] = e28;
      return { layer: t30, selection: [...s31.selection] };
    });
  }
  get count() {
    let e28 = 0;
    for (const t30 of this._selectionMap.values()) e28 += t30.selection.length;
    return e28;
  }
  get hasSelection() {
    return this.count > 0;
  }
  get sources() {
    return this._sources;
  }
  set sources(e28) {
    n8(e28, this._sources);
  }
  getSelectedFeatures(_0) {
    return __async(this, arguments, function* (e28, t30 = {}, s31 = "layerView") {
      const { view: i25, selections: o29 } = this, n33 = (void 0 !== e28 ? o29.filter((t31) => e28.includes(t31.layer)) : o29).filter((e29) => e29.selection.length > 0).map((e29) => __async(this, null, function* () {
        const { layer: o30, selection: n34 } = e29, l20 = l2(o30) ? o30.parent : o30;
        if (null == l20 || !S4(l20)) return null;
        if ("layer" === s31) return M5(l20, n34, t30);
        if (v5(l20)) return null;
        const r33 = yield i25.whenLayerView(l20).catch(() => null);
        return r33 ? M5(r33, n34, t30) : null;
      }));
      return (yield Promise.all(n33)).filter((e29) => null != e29);
    });
  }
  updateSelection(e28) {
    const s31 = /* @__PURE__ */ new Map();
    for (const [t30, n33] of this._selectionMap) s31.set(t30, [...n33.selection]);
    let i25 = false;
    const o29 = e28.current.concat(e28.added);
    for (const t30 of o29) {
      const e29 = t30.sourceLayer, o30 = t30.getObjectId();
      if (this.sources.includes(e29) && (e11(e29) || l2(e29)) && null !== o30) {
        const t31 = r2(s31, e29, () => []);
        t31.includes(o30) || (t31.push(o30), i25 = true);
      }
    }
    for (const t30 of e28.removed) {
      const e29 = t30.sourceLayer, o30 = t30.getObjectId();
      if (this.sources.includes(e29) && (e11(e29) || l2(e29)) && null !== o30) {
        const t31 = s31.get(e29), n33 = t31?.indexOf(o30);
        void 0 !== n33 && n33 >= 0 && (t31?.splice(n33, 1), i25 = true);
      }
    }
    if (i25) {
      const { _selectionMap: e29, _trashCan: i26 } = this, o30 = [];
      for (const [n33, l20] of s31) {
        const s32 = e29.get(n33);
        void 0 !== s32 && i26.push(s32), e29.set(n33, { selection: l20 }), o30.push(__spreadValues({ layer: n33, selection: l20 }, a(void 0 !== s32 ? s32.selection : [], l20)));
      }
      this._onSelectionChange(o30);
    }
  }
  setSelection(e28, t30) {
    this._setSelection(e28, t30);
  }
  getSelection(e28) {
    const t30 = this._selectionMap.get(e28);
    return t30?.selection;
  }
  appendToSelection(e28, t30) {
    const s31 = this._selectionMap.get(e28), i25 = void 0 !== s31 ? [...s31.selection] : [];
    for (const o29 of t30) i25.includes(o29) || i25.push(o29);
    this._setSelection(e28, i25);
  }
  removeFromSelection(e28, t30) {
    const s31 = this._selectionMap.get(e28);
    if (!s31) return;
    const i25 = [];
    for (const o29 of s31.selection) t30.includes(o29) || i25.push(o29);
    this._setSelection(e28, i25);
  }
  toggleInSelection(e28, t30) {
    const s31 = this._selectionMap.get(e28);
    if (!s31 || 0 === s31.selection.length) return void this._setSelection(e28, t30);
    const i25 = new Set(s31.selection), o29 = new Set(t30), n33 = c2(i25, o29);
    this._setSelection(e28, Array.from(n33));
  }
  clear() {
    const e28 = this._selectionMap.values();
    this._trashCan.push(...e28);
    const t30 = [];
    for (const [s31, i25] of this._selectionMap.entries()) t30.push({ layer: s31, added: [], removed: [...i25.selection], selection: [] });
    this._selectionMap.clear(), this._onSelectionChange(t30);
  }
  _onSelectionChange(e28) {
    this._refreshVisualization(), this.emit("selection-change", { view: this.view, changes: e28 });
  }
  _refreshVisualization() {
    if (null == this.view || null == this.sources) return;
    for (this._vizTaskId++; this._trashCan.length > 0; ) {
      const e29 = this._trashCan.pop();
      e29?.highlightHandle?.remove();
    }
    const { sources: e28, view: t30, _selectionMap: s31, showHighlight: i25 } = this, o29 = this._vizTaskId;
    for (const n33 of e28) {
      const e29 = s31.get(n33), l20 = l2(n33) ? n33.parent : n33;
      if (null != l20 && S4(l20)) {
        if (v5(l20)) continue;
        t30.whenLayerView(l20).then((t31) => {
          e29?.highlightHandle?.remove(), null != e29 && i25 && o29 === this._vizTaskId && "highlight" in t31 && "function" == typeof t31.highlight && e29.selection.length > 0 && (e29.highlightHandle = t31.highlight(e29.selection, this.highlightName));
        }).catch(() => {
          e29?.highlightHandle?.remove();
        });
      }
    }
  }
  _refreshListeners() {
    this._layerEditHandles.drain(l);
    for (const e28 of this.sources) {
      const t30 = l2(e28) ? e28.parent : e28;
      if (null != t30 && e11(t30)) {
        const s31 = t30.on("edits", (t31) => {
          this._handleEditChanges(t31, e28);
        });
        this._layerEditHandles.push(s31);
      }
    }
  }
  _handleEditChanges(e28, t30) {
    if (void 0 !== e28.deletedFeatures && e28.deletedFeatures.length > 0 && this._selectionMap.has(t30)) {
      const i25 = e28.deletedFeatures.filter((e29) => null == e29.error).map((e29) => e29.objectId).filter(G);
      this.removeFromSelection(t30, i25);
    }
  }
  _setSelection(e28, s31) {
    if (!this.sources.includes(e28)) throw new Error(`Cannot set selection on layer ${e28.title} because it is not in 'sources'`);
    const i25 = this._selectionMap.get(e28);
    if (void 0 === i25 || !j5(i25, { selection: s31 })) {
      void 0 !== i25 && this._trashCan.push(i25), this._selectionMap.set(e28, { selection: [...s31] });
      const o29 = __spreadValues({ layer: e28, selection: [...s31] }, a(void 0 !== i25 ? i25.selection : [], s31));
      this._onSelectionChange([o29]);
    }
  }
};
r([m({ readOnly: true, nonNullable: true })], y4.prototype, "selections", null), r([m({ readOnly: true, nonNullable: true })], y4.prototype, "count", null), r([m({ constructOnly: true, nonNullable: true })], y4.prototype, "view", void 0), r([m({ readOnly: true, nonNullable: true })], y4.prototype, "hasSelection", null), r([m()], y4.prototype, "showHighlight", void 0), r([m()], y4.prototype, "sources", null), r([m()], y4.prototype, "highlightName", void 0), y4 = r([a3("esri.views.SelectionManager")], y4);
var v5 = (e28) => l2(e28) ? true === e28.parent?.isTable : e28.isTable;
var w5 = (e28) => void 0 !== e28.layer;
var S4 = (e28) => void 0 !== e28?.when;
var j5 = (e28, t30) => {
  if (null == e28 && null == t30) return true;
  if (null != e28 && null == t30 || null == e28 && null != t30) return false;
  if (null != e28 && null != t30 && null != e28.selection && null != t30.selection) {
    const s31 = [...e28.selection], i25 = [...t30.selection];
    if (s31.length !== i25.length) return false;
    s31.sort(), i25.sort();
    for (let e29 = 0; e29 < s31.length; e29++) if (s31[e29] !== i25[e29]) return false;
  }
  return true;
};
var M5 = (_0, _1, ..._22) => __async(void 0, [_0, _1, ..._22], function* (e28, t30, s31 = {}) {
  let i25;
  if (w5(e28)) {
    const o29 = e28;
    i25 = void 0 === o29 ? null : yield o29.queryFeatures(new b3(__spreadProps(__spreadValues({}, s31), { objectIds: t30 }))).then((t31) => ({ data: t31, layer: e28.layer }));
  } else {
    const o29 = e28;
    i25 = void 0 === o29 ? null : yield o29.queryFeatures(new b3(__spreadProps(__spreadValues({}, s31), { objectIds: t30 }))).then((e29) => ({ data: e29, layer: o29 }));
  }
  return i25;
});
var b4 = y4;

// node_modules/@arcgis/core/views/Theme.js
var p10 = class extends a4.ClonableMixin(g2) {
  constructor(o29) {
    super(o29), this.accentColor = new h4([255, 127, 0]), this.textColor = new h4([255, 255, 255]);
  }
};
r([m({ type: h4, nonNullable: true })], p10.prototype, "accentColor", void 0), r([m({ type: h4, nonNullable: true })], p10.prototype, "textColor", void 0), p10 = r([a3("esri.views.Theme")], p10);
var l7 = p10;

// node_modules/@arcgis/core/views/input/ViewEvents.js
var r15 = ["click", "double-click", "immediate-click", "immediate-double-click", "hold", "drag", "key-down", "key-up", "pointer-down", "pointer-move", "pointer-up", "pointer-drag", "mouse-wheel", "pointer-enter", "pointer-leave", "gamepad", "focus", "blur"];
var o12 = {};
function s14(t30) {
  return !!o12[t30];
}
function p11(t30) {
  for (const e28 of t30) if (!s14(e28)) return false;
  return true;
}
r15.forEach((t30) => {
  o12[t30] = true;
});
var c11 = class {
  constructor(t30) {
    this._handlers = /* @__PURE__ */ new Map(), this._counter = 0, this._handlerCounts = /* @__PURE__ */ new Map(), this.view = t30, this.inputManager = null;
  }
  connect(t30) {
    t30 && this.disconnect(), this.inputManager = t30, this._handlers.forEach(({ handler: t31, priority: e28 }, n33) => this.inputManager?.installHandlers(n33, [t31], e28));
  }
  disconnect() {
    this.inputManager && this._handlers.forEach((t30, e28) => this.inputManager?.uninstallHandlers(e28)), this.inputManager = null;
  }
  destroy() {
    this.disconnect(), this._handlers.clear(), this.view = null;
  }
  on(e28, n33, a27, r33) {
    const o29 = Array.isArray(e28) ? e28 : e28.split(",");
    if (!p11(o29)) return o29.some(s14) && console.error("Error: registering input events and other events on the view at the same time is not supported."), null;
    let c29, u17;
    Array.isArray(n33) ? u17 = n33 : (c29 = n33, u17 = []), "function" == typeof a27 ? c29 = a27 : r33 = a27, r33 = null != r33 ? r33 : _2.DEFAULT;
    const m24 = this._createUniqueGroupName(), d18 = new l8(this.view, o29, u17, c29);
    this._handlers.set(m24, { handler: d18, priority: r33 });
    for (const t30 of o29) {
      const e29 = this._handlerCounts.get(t30) || 0;
      this._handlerCounts.set(t30, e29 + 1);
    }
    return this.inputManager && this.inputManager.installHandlers(m24, [d18], r33), e(() => this._removeHandler(m24, o29));
  }
  hasHandler(t30) {
    return !!this._handlerCounts.get(t30);
  }
  _removeHandler(t30, e28) {
    if (this._handlers.has(t30)) {
      this._handlers.delete(t30);
      for (const t31 of e28) {
        const e29 = this._handlerCounts.get(t31);
        void 0 === e29 || (1 === e29 ? this._handlerCounts.delete(t31) : this._handlerCounts.set(t31, e29 - 1));
      }
    }
    this.inputManager && this.inputManager.uninstallHandlers(t30);
  }
  _createUniqueGroupName() {
    return this._counter += 1, `viewEvents_${this._counter}`;
  }
};
var l8 = class extends t9 {
  constructor(t30, e28, n33, a27) {
    super(true), this._latestDragStart = void 0, this.view = t30;
    for (const i25 of e28) switch (i25) {
      case "click":
        this.registerIncoming("click", n33, (e29) => a27(d6(t30, e29)));
        break;
      case "double-click":
        this.registerIncoming("double-click", n33, (e29) => a27(g9(t30, e29)));
        break;
      case "immediate-click":
        this.registerIncoming("immediate-click", n33, (e29) => a27(y5(t30, e29)));
        break;
      case "immediate-double-click":
        this.registerIncoming("immediate-double-click", n33, (e29) => a27(v6(t30, e29)));
        break;
      case "hold":
        this.registerIncoming("hold", n33, (e29) => a27(h9(t30, e29)));
        break;
      case "drag":
        this.registerIncoming("drag", n33, (t31) => {
          const e29 = this._wrapDrag(t31);
          e29 && a27(e29);
        });
        break;
      case "key-down":
        this.registerIncoming("key-down", n33, (t31) => a27(f6(t31)));
        break;
      case "key-up":
        this.registerIncoming("key-up", n33, (t31) => a27(k2(t31)));
        break;
      case "pointer-down":
        this.registerIncoming("pointer-down", n33, (t31) => a27(I4(t31, "pointer-down")));
        break;
      case "pointer-move":
        this.registerIncoming("pointer-move", n33, (t31) => a27(I4(t31, "pointer-move")));
        break;
      case "pointer-up":
        this.registerIncoming("pointer-up", n33, (t31) => a27(I4(t31, "pointer-up")));
        break;
      case "pointer-drag":
        this.registerIncoming("pointer-drag", n33, (t31) => a27(D(t31)));
        break;
      case "mouse-wheel":
        this.registerIncoming("mouse-wheel", n33, (t31) => a27(P4(t31)));
        break;
      case "pointer-enter":
        this.registerIncoming("pointer-enter", n33, (t31) => a27(I4(t31, "pointer-enter")));
        break;
      case "pointer-leave":
        this.registerIncoming("pointer-leave", n33, (t31) => a27(I4(t31, "pointer-leave")));
        break;
      case "gamepad":
        this.registerIncoming("gamepad", n33, (t31) => {
          a27(_5(t31));
        });
        break;
      case "focus":
        this.registerIncoming("focus", n33, (t31) => {
          a27(u7(t31));
        });
        break;
      case "blur":
        this.registerIncoming("blur", n33, (t31) => {
          a27(m12(t31));
        });
    }
  }
  _wrapDrag(t30) {
    const n33 = t30.data, { x: a27, y: i25 } = n33.center, { action: r33, pointerType: o29, button: s31 } = n33;
    if ("start" === r33 && (this._latestDragStart = n33), !this._latestDragStart) return;
    const p31 = n33.pointer.native, c29 = n33.buttons, { cancelable: l20, timestamp: u17 } = t30, m24 = { x: this._latestDragStart.center.x, y: this._latestDragStart.center.y };
    return "end" === r33 && (this._latestDragStart = void 0), { type: "drag", action: r33, x: a27, y: i25, origin: m24, pointerType: o29, button: s31, buttons: c29, radius: n33.radius, angle: M(n33.angle), native: p31, timestamp: u17, cancelable: l20, stopPropagation: () => t30.stopPropagation(), async: (e28) => t30.async(e28), preventDefault: () => t30.preventDefault() };
  }
};
function u7(t30) {
  return { type: "focus", timestamp: t30.timestamp, native: t30.data.native, cancelable: t30.cancelable, stopPropagation: () => t30.stopPropagation(), async: (e28) => t30.async(e28), preventDefault: () => t30.preventDefault() };
}
function m12(t30) {
  return { type: "blur", timestamp: t30.timestamp, native: t30.data.native, cancelable: t30.cancelable, stopPropagation: () => t30.stopPropagation(), async: (e28) => t30.async(e28), preventDefault: () => t30.preventDefault() };
}
function d6(t30, e28) {
  const { pointerType: a27, button: i25, buttons: r33, x: o29, y: s31, native: p31, eventId: c29 } = e28.data, { cancelable: l20, timestamp: u17 } = e28;
  return { type: "click", pointerType: a27, button: i25, buttons: r33, x: o29, y: s31, native: p31, timestamp: u17, screenPoint: c4(o29, s31), mapPoint: b5(t30, o29, s31), eventId: c29, cancelable: l20, stopPropagation: () => e28.stopPropagation(), async: (t31) => e28.async(t31), preventDefault: () => e28.preventDefault() };
}
function g9(t30, e28) {
  const { pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, eventId: p31 } = e28.data, { cancelable: c29, timestamp: l20 } = e28;
  return { type: "double-click", pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, timestamp: l20, mapPoint: b5(t30, r33, o29), eventId: p31, cancelable: c29, stopPropagation: () => e28.stopPropagation(), async: (t31) => e28.async(t31), preventDefault: () => e28.preventDefault() };
}
function y5(t30, e28) {
  const { pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, eventId: p31 } = e28.data, c29 = s31.pointerId, { cancelable: l20, timestamp: u17 } = e28;
  return { type: "immediate-click", pointerId: c29, pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, timestamp: u17, mapPoint: b5(t30, r33, o29), eventId: p31, cancelable: l20, stopPropagation: () => e28.stopPropagation(), async: (t31) => e28.async(t31), preventDefault: () => e28.preventDefault() };
}
function v6(t30, e28) {
  const { pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, eventId: p31 } = e28.data, c29 = s31.pointerId, { cancelable: l20, timestamp: u17 } = e28;
  return { type: "immediate-double-click", pointerId: c29, pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, timestamp: u17, mapPoint: b5(t30, r33, o29), eventId: p31, cancelable: l20, stopPropagation: () => e28.stopPropagation(), async: (t31) => e28.async(t31), preventDefault: () => e28.preventDefault() };
}
function h9(t30, e28) {
  const { pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31 } = e28.data, { cancelable: p31, timestamp: c29 } = e28;
  return { type: "hold", pointerType: n33, button: a27, buttons: i25, x: r33, y: o29, native: s31, timestamp: c29, mapPoint: b5(t30, r33, o29), cancelable: p31, stopPropagation: () => e28.stopPropagation(), async: (t31) => e28.async(t31), preventDefault: () => e28.preventDefault() };
}
function b5(t30, e28, a27) {
  return t30.toMap(c4(e28, a27), { exclude: [] });
}
function f6(t30) {
  const { key: e28, repeat: n33, native: a27 } = t30.data, { cancelable: i25, timestamp: r33 } = t30;
  return { type: "key-down", key: e28, repeat: n33, native: a27, timestamp: r33, cancelable: i25, stopPropagation: () => t30.stopPropagation(), async: (e29) => t30.async(e29), preventDefault: () => t30.preventDefault() };
}
function k2(t30) {
  const { key: e28, native: n33 } = t30.data, { cancelable: a27, timestamp: i25 } = t30;
  return { type: "key-up", key: e28, native: n33, timestamp: i25, cancelable: a27, stopPropagation: () => t30.stopPropagation(), async: (e29) => t30.async(e29), preventDefault: () => t30.preventDefault() };
}
function I4(t30, e28) {
  const { x: n33, y: a27, button: i25, buttons: r33, native: o29, eventId: s31 } = t30.data, p31 = o29.pointerId, c29 = o29.pointerType, { cancelable: l20, timestamp: u17 } = t30;
  return { type: e28, x: n33, y: a27, pointerId: p31, pointerType: c29, button: i25, buttons: r33, native: o29, timestamp: u17, eventId: s31, cancelable: l20, stopPropagation: () => t30.stopPropagation(), async: (e29) => t30.async(e29), preventDefault: () => t30.preventDefault() };
}
function D(t30) {
  const { x: e28, y: n33, buttons: a27, native: i25, eventId: r33 } = t30.data.currentEvent, { button: o29 } = t30.data.startEvent, s31 = t30.data.startEvent.native.pointerId, p31 = t30.data.startEvent.native.pointerType, c29 = t30.data.action, l20 = { x: t30.data.startEvent.x, y: t30.data.startEvent.y }, { cancelable: u17, timestamp: m24 } = t30;
  return { type: "pointer-drag", x: e28, y: n33, pointerId: s31, pointerType: p31, button: o29, buttons: a27, action: c29, origin: l20, native: i25, timestamp: m24, eventId: r33, cancelable: u17, stopPropagation: () => t30.stopPropagation(), async: (e29) => t30.async(e29), preventDefault: () => t30.preventDefault() };
}
function P4(t30) {
  const { cancelable: e28, data: n33, timestamp: a27 } = t30, { x: i25, y: r33, deltaY: o29, native: s31 } = n33;
  return { type: "mouse-wheel", x: i25, y: r33, deltaY: o29, native: s31, timestamp: a27, cancelable: e28, stopPropagation: () => t30.stopPropagation(), async: (e29) => t30.async(e29), preventDefault: () => t30.preventDefault() };
}
function _5(t30) {
  const { action: e28, state: n33, device: a27 } = t30.data, { cancelable: i25, timestamp: r33 } = t30, { buttons: o29, axes: s31 } = n33;
  return { type: "gamepad", device: a27, timestamp: r33, action: e28, buttons: o29, axes: s31, cancelable: i25, stopPropagation: () => t30.stopPropagation(), async: (e29) => t30.async(e29), preventDefault: () => t30.preventDefault() };
}

// node_modules/@arcgis/core/views/interactive/interactiveToolUtils.js
function o13(t30) {
  return [t30.on("before-add", (o29) => {
    const i25 = o29.item;
    if (null == i25 || t30.includes(i25)) return n.getLogger("esri.views.interactive.interactiveToolUtils").warn("Tool is either already in the list of tools or tool is `null`. Not adding tool."), void o29.preventDefault();
    i25.onAdd();
  }), t30.on("after-remove", (e28) => {
    const t31 = e28.item;
    t31.active && (t31.view.activeTool = null), t31.destroy();
  })];
}
function i8(e28) {
  return e28.visible && null != e28.getEditableFlag && e28.getEditableFlag(o9.USER) && e28.getEditableFlag(o9.MANAGER);
}

// node_modules/@arcgis/core/views/interactive/ToolViewManagerManipulatorState.js
var i9 = class {
  constructor() {
    this._pointerLocations = /* @__PURE__ */ new Map(), this._hoveredManipulators = /* @__PURE__ */ new Map(), this._grabbedManipulators = /* @__PURE__ */ new Map(), this._draggedManipulators = /* @__PURE__ */ new Map(), this._stopDrag = false, this._externallyDragging = false, this._revertToNullActiveTool = false, this._cursor = null;
  }
  get cursor() {
    return this._cursor;
  }
  hasFocusedManipulators() {
    return this._grabbedManipulators.size > 0 || this._draggedManipulators.size > 0;
  }
  handleInputEvent(e28, o29) {
    const a27 = () => e28.stopPropagation();
    switch (e28.type) {
      case "pointer-move":
        l9(e28.pointerType) && this._pointerLocations.set(e28.pointerId, { x: e28.x, y: e28.y, pointerType: e28.pointerType });
        break;
      case "drag":
        this._grabbedManipulators.size > 0 ? this._stopDrag = true : "start" === e28.action ? this._externallyDragging = true : "end" === e28.action && (this._externallyDragging = false), this._stopDrag && (a27(), "end" === e28.action && (this._stopDrag = false));
        break;
      case "pointer-down": {
        if (!p12(e28)) break;
        const t30 = n14(e28), i25 = s15(t30, e28.pointerType, o29.forEachTool);
        if (null == i25) break;
        const n33 = i25.manipulator, l20 = i25.tool;
        null == n33 || null == l20 || !n33.interactive || n33.grabbable && n33.grabbableForEvent(e28) || !n33.grabbing || n33.dragging || this._releaseManipulatorBeforeDragging(n33, e28, o29), null != n33 && null != l20 && n33.interactive && n33.grabbable && n33.grabbableForEvent(e28) && !n33.grabbing && (this._grabbedManipulators.set(e28.pointerId, { manipulator: n33, tool: l20, start: t30, pointerType: e28.pointerType }), 1 === this._grabbedManipulators.size && null == o29.activeTool && (this._revertToNullActiveTool = true, o29.setActiveTool(i25.tool)), n33.grabbing = true, n33.events.emit("grab-changed", { action: "start", pointerType: e28.pointerType, screenPoint: t30 }), a27());
        break;
      }
      case "pointer-up":
        this._draggedManipulators.has(e28.pointerId) || this._handlePointerEnd(e28, o29);
        break;
      case "pointer-drag": {
        if (!p12(e28)) break;
        const i25 = this._grabbedManipulators.get(e28.pointerId), n33 = i25?.manipulator, s31 = i25?.tool;
        if (null == n33 || null == s31) break;
        const l20 = n14(e28);
        l20.x = r7(l20.x, 0, o29.view.width), l20.y = r7(l20.y, 0, o29.view.height);
        const u17 = i25.start, c29 = this._draggedManipulators.get(e28.pointerId);
        switch (e28.action) {
          case "start":
          case "update":
            "update" !== e28.action && 1 !== this._grabbedManipulators.size || (n33.dragging = true, c29 ? n33.events.emit("drag", { action: "update", start: u17, screenPoint: l20 }) : n33.events.emit("drag", { action: "start", start: u17, screenPoint: l20, pointerType: e28.pointerType }), this._draggedManipulators.set(e28.pointerId, { tool: s31, manipulator: n33, start: u17 }));
            break;
          case "end":
            n33.dragging = false, c29 && n33.events.emit("drag", { action: "end", start: u17, screenPoint: l20 }), this._draggedManipulators.delete(e28.pointerId), this._handlePointerEnd(e28, o29);
        }
        a27();
        break;
      }
      case "immediate-click": {
        const t30 = n14(e28), i25 = s15(t30, e28.pointerType, o29.forEachTool);
        if (u8(e28) || o29.forEachTool((e29) => {
          if ((null == i25 || i25.tool !== e29 || e29.automaticManipulatorSelection) && e29.manipulators) {
            let t31 = false;
            e29.manipulators.forEach(({ manipulator: e30 }) => {
              e30.selected && (e30.selected = false, t31 = true);
            }), t31 && e29.onManipulatorSelectionChanged && e29.onManipulatorSelectionChanged();
          }
        }), null == i25) break;
        const { manipulator: n33, tool: l20 } = i25;
        if (!n33.interactive) break;
        n33.selectable && l20.automaticManipulatorSelection && (n33.selected = !n33.selected, l20.onManipulatorSelectionChanged && l20.onManipulatorSelectionChanged());
        const p31 = e28.native.shiftKey;
        n33.events.emit("immediate-click", { screenPoint: t30, button: e28.button, pointerType: e28.pointerType, shiftKey: p31, stopPropagation: a27 }), c12(n33, a27);
        break;
      }
      case "click": {
        const t30 = n14(e28), i25 = s15(t30, e28.pointerType, o29.forEachTool), n33 = i25?.manipulator;
        if (null == n33 || !n33.interactive) break;
        const l20 = e28.native.shiftKey;
        n33.events.emit(e28.type, { screenPoint: t30, button: e28.button, pointerType: e28.pointerType, shiftKey: l20 }), a27();
        break;
      }
      case "double-click": {
        const t30 = n14(e28), i25 = s15(t30, e28.pointerType, o29.forEachTool), n33 = null != i25 ? i25.manipulator : null;
        if (null == n33 || !n33.interactive) break;
        const l20 = e28.native.shiftKey;
        n33.events.emit("double-click", { screenPoint: t30, button: e28.button, pointerType: e28.pointerType, shiftKey: l20, stopPropagation: a27 }), c12(n33, a27);
        break;
      }
      case "immediate-double-click": {
        const t30 = n14(e28), i25 = s15(t30, e28.pointerType, o29.forEachTool), n33 = null != i25 ? i25.manipulator : null;
        if (null == n33 || !n33.interactive) break;
        const l20 = e28.native.shiftKey;
        n33.events.emit("immediate-double-click", { screenPoint: t30, button: e28.button, pointerType: e28.pointerType, shiftKey: l20, stopPropagation: a27 }), "mouse" === e28.pointerType && c12(n33, a27);
        break;
      }
    }
    this._onFocusChange(o29.forEachTool);
  }
  _releaseManipulatorBeforeDragging(e28, t30, o29) {
    e28.grabbing = false, e28.events.emit("grab-changed", { action: "end", pointerType: t30.pointerType, screenPoint: n14(t30) }), this._grabbedManipulators.forEach(({ manipulator: t31 }, o30) => {
      t31 === e28 && this._grabbedManipulators.delete(o30);
    }), this._afterManipulatorRelease(o29.setActiveTool);
  }
  _handlePointerEnd(e28, t30) {
    const o29 = this._grabbedManipulators.get(e28.pointerId)?.manipulator;
    null != o29 && o29.grabbing && (o29.grabbing = false, o29.events.emit("grab-changed", { action: "end", pointerType: e28.pointerType, screenPoint: n14(e28) }), this._grabbedManipulators.delete(e28.pointerId), this._afterManipulatorRelease(t30.setActiveTool));
  }
  _onFocusChange(e28) {
    this._updateCursor(), this._updateFocusedManipulatorTools(e28);
  }
  _updateCursor() {
    this._grabbedManipulators.size > 0 ? this._cursor = n17(this._grabbedManipulators) || "grabbing" : this._hoveredManipulators.size > 0 ? this._cursor = n17(this._hoveredManipulators) || "pointer" : this._cursor = null;
  }
  _updateFocusedManipulatorTools(t30) {
    const o29 = /* @__PURE__ */ new Set(), a27 = /* @__PURE__ */ new Set();
    this._grabbedManipulators.forEach(({ tool: e28 }) => {
      o29.add(e28);
    }), this._hoveredManipulators.forEach(({ tool: e28 }) => {
      a27.add(e28);
    }), t30((t31) => {
      t31.hasGrabbedManipulators = o29.has(t31), t31.hasHoveredManipulators = a27.has(t31);
      const r33 = this._grabbedManipulators.values(), i25 = o2(r33, ({ tool: e28 }) => e28 === t31);
      t31.firstGrabbedManipulator = null != i25 ? i25.manipulator : null;
    });
  }
  clearPointers(e28, { forEachTool: t30, setActiveTool: o29 }, a27 = true, r33) {
    const i25 = (t31, o30) => t31 === e28 && (null == r33 || r33 === o30);
    this._grabbedManipulators.forEach(({ tool: e29, manipulator: t31, pointerType: o30 }, a28) => {
      i25(e29, t31) && (this._grabbedManipulators.delete(a28), t31.grabbing = false, t31.events.emit("grab-changed", { action: "end", screenPoint: null, pointerType: o30 }));
    }), this._draggedManipulators.forEach(({ tool: e29, manipulator: t31 }, o30) => {
      i25(e29, t31) && (this._draggedManipulators.delete(o30), t31.dragging = false, t31.events.emit("drag", { action: "cancel" }));
    }), a27 && this._hoveredManipulators.forEach(({ tool: e29, manipulator: t31 }, o30) => {
      i25(e29, t31) && (this._hoveredManipulators.delete(o30), t31.hovering = false);
    }), this._afterManipulatorRelease(o29), this._onFocusChange(t30);
  }
  updateHoveredStateFromKnownPointers(e28) {
    this._pointerLocations.forEach((t30, a27) => {
      this._updateHoveredStateForPointerAtScreenPosition(c4(t30.x, t30.y), a27, t30.pointerType, e28);
    });
  }
  handleHoverEvent(e28, t30) {
    const o29 = e28.type;
    "pointer-up" !== o29 && "immediate-click" !== o29 && "pointer-move" !== o29 || !l9(e28.pointerType) || ("pointer-up" !== o29 && this._externallyDragging ? this._clearHoveredManipulatorStates(e28.pointerId) : this._updateHoveredStateForPointerAtScreenPosition(n14(e28), e28.pointerId, e28.pointerType, t30));
  }
  _updateHoveredStateForPointerAtScreenPosition(e28, t30, o29, a27) {
    let r33 = s15(e28, o29, a27);
    const i25 = this._hoveredManipulators.get(t30)?.manipulator;
    null == r33 || r33.manipulator.interactive || (r33 = null), null != r33 && i25 === r33.manipulator || (null != i25 && (i25.hovering = false), null != r33 ? (r33.manipulator.hovering = true, this._hoveredManipulators.set(t30, r33)) : this._hoveredManipulators.delete(t30), this._onFocusChange(a27));
  }
  _afterManipulatorRelease(e28) {
    0 === this._grabbedManipulators.size && this._revertToNullActiveTool && (e28(null), this._revertToNullActiveTool = false);
  }
  _clearHoveredManipulatorStates(e28) {
    this._hoveredManipulators.forEach(({ manipulator: t30 }, o29) => {
      e28 === o29 && (this._hoveredManipulators.delete(e28), t30.hovering = false);
    });
  }
};
function n17(e28) {
  for (const { manipulator: t30 } of e28.values()) if (null != t30 && t30.interactive) {
    if (t30.grabbing && t30.grabCursor) return t30.grabCursor;
    if (t30.cursor) return t30.cursor;
  }
  return null;
}
function s15(e28, t30, o29) {
  let r33 = null;
  return o29((o30) => {
    if (null == o30.manipulators || !i8(o30)) return false;
    const i25 = o30.manipulators.intersect(e28, t30);
    return null != i25 && (r33 = { tool: o30, manipulator: i25 }, true);
  }), r33;
}
function l9(e28) {
  return "mouse" === e28;
}
function p12(e28) {
  return "mouse" !== e28.pointerType || 0 === e28.button;
}
function u8(e28) {
  return !!e28.native.shiftKey;
}
function c12(e28, t30) {
  e28?.consumesClicks && t30();
}

// node_modules/@arcgis/core/views/ToolViewManager.js
var _6 = "attached";
var g10 = "tools";
var T2 = 1e3;
var f7 = class extends g2 {
  constructor(t30) {
    super(t30), this._updatingHandles = new h6(), this._clock = o3, this._manipulatorState = new i9(), this.tools = new V(), this.cursor = null, this._interacting = false, this._interactingTimeout = T2, this._interactingTimeoutHandle = null, this._forEachTool = (t31) => {
      for (const o29 of this.tools.items) if (t31(o29)) return;
    };
  }
  initialize() {
    this.addHandles([this.view.on(r15, (t30) => {
      this._handleInputEvent(t30);
    }, _2.TOOL), ...o13(this.tools), this.tools.on("before-add", ({ item: t30 }) => {
      this._updateToolEditableFlag(t30);
    }), this.tools.on("before-remove", ({ item: t30 }) => {
      this._manipulatorState.clearPointers(t30, this._manipulatorStateEventArgs), this._updateCursor();
    }), this.tools.on("change", () => {
      this._refreshToolWatchers();
    })]);
  }
  destroy() {
    this.activeTool = null, this.tools.drain((t30) => t30.destroy()), this._clearInteractingTimeout(), this._interacting = false, this._updatingHandles.destroy();
  }
  get _manipulatorStateEventArgs() {
    return { forEachTool: this._forEachTool, activeTool: this.activeTool, setActiveTool: (t30) => {
      this.activeTool = t30;
    }, view: this.view };
  }
  set activeTool(t30) {
    if (null != t30 && !this.view.ready) return void n.getLogger(this).error("Cannot set active tool while view is not ready.");
    if (t30 === this.activeTool) return;
    const o29 = this.activeTool;
    this._set("activeTool", t30), null != o29 && o29.deactivate(), null != t30 && t30.activate(), this._removeIncompleteTools(t30);
    for (const e28 of this.tools) {
      this._updateToolEditableFlag(e28);
      const t31 = i8(e28);
      null != this.activeTool && t31 || this._manipulatorState.clearPointers(e28, this._manipulatorStateEventArgs, !t31);
    }
    this._updateCursor();
  }
  get updating() {
    return this._updatingHandles.updating || this.tools.some((t30) => t30.updating);
  }
  get interacting() {
    return this._interacting;
  }
  _clearInteractingTimeout() {
    this._interactingTimeoutHandle = l(this._interactingTimeoutHandle);
  }
  _startInteractingTimeout() {
    this._clearInteractingTimeout(), this._interactingTimeoutHandle = this._clock.setTimeout(() => this._interacting = false, this._interactingTimeout);
  }
  attach() {
    "3d" === this.view.type ? this.addHandles([d3(() => {
      const { state: t30 } = this.view;
      return "camera" in t30 && t30.camera;
    }, () => this._forEachManipulator((t30) => t30.onViewChange())), this.view.elevationProvider?.on("elevation-change", (t30) => this._forEachManipulator((o29) => o29.onElevationChange(t30)))], _6) : this.addHandles(d3(() => this.view.extent, () => this._forEachManipulator((t30) => t30.onViewChange())));
  }
  detach() {
    this.activeTool = null, this.tools.removeAll(), this.removeHandles(_6), this._clearInteractingTimeout(), this._interacting = false;
  }
  _forEachManipulator(t30) {
    this._forEachTool((o29) => {
      o29.manipulators && o29.manipulators.forEach(({ manipulator: e28 }) => t30(e28, o29));
    });
  }
  _handleInputEvent(t30) {
    let o29 = false;
    const e28 = __spreadProps(__spreadValues({}, t30), { stopPropagation: () => {
      o29 = true, t30.stopPropagation();
    } });
    null != this.activeTool ? this.activeTool.handleInputEvent && this.activeTool.handleInputEvent(e28) : this._forEachTool((t31) => {
      !o29 && t31.visible && t31.handleInputEvent(e28);
    }), !o29 && "key-down" === t30.type && "Escape" === t30.key && this.activeTool && (t30.stopPropagation(), this.activeTool = null), this._manipulatorState.handleInputEvent(e28, this._manipulatorStateEventArgs), o29 || null == this.activeTool || this.activeTool.handleInputEventAfter(e28), this._manipulatorState.handleHoverEvent(e28, this._forEachTool), this._updateCursor(), "pointer-move" === t30.type && (this._manipulatorState.hasFocusedManipulators() || this.activeTool) && (this._interacting = true, this._startInteractingTimeout());
  }
  _refreshToolWatchers() {
    this.removeHandles(g10), this._forEachTool((t30) => {
      if (t30 instanceof g2) {
        const o29 = d3(() => [t30.cursor, t30.visible, t30.editable], () => {
          i8(t30) || this._manipulatorState.clearPointers(t30, this._manipulatorStateEventArgs), this._updateCursor();
        });
        this.addHandles(o29, g10);
      }
      t30.manipulators && this.addHandles([t30.manipulators.on("after-remove", (o29) => {
        this._manipulatorState.clearPointers(t30, this._manipulatorStateEventArgs, true, o29.item.manipulator);
      }), t30.manipulators.on("change", () => {
        this._manipulatorState.updateHoveredStateFromKnownPointers(this._forEachTool), this._updateCursor();
      })], g10);
    }), this._manipulatorState.updateHoveredStateFromKnownPointers(this._forEachTool), this._updateCursor();
  }
  _updateToolEditableFlag(t30) {
    t30.setEditableFlag?.(o9.MANAGER, null == this.activeTool || t30 === this.activeTool);
  }
  _updateCursor() {
    let t30 = this._manipulatorState.cursor;
    null == t30 && this._forEachTool((o29) => !(null == o29.cursor || !o29.visible) && (t30 = o29.cursor, true)), this._get("cursor") !== t30 && this._set("cursor", t30);
  }
  _removeIncompleteTools(t30) {
    this.tools.filter((o29) => (null == t30 || o29 !== t30) && !o29.created && o29.removeIncompleteOnCancel).forEach((t31) => {
      this.tools.remove(t31);
    });
  }
  get test() {
  }
};
r([m({ constructOnly: true, nonNullable: true })], f7.prototype, "view", void 0), r([m({ value: null })], f7.prototype, "activeTool", null), r([m({ readOnly: true, type: V })], f7.prototype, "tools", void 0), r([m({ readOnly: true })], f7.prototype, "cursor", void 0), r([m({ readOnly: true })], f7.prototype, "updating", null), r([m()], f7.prototype, "_interacting", void 0), r([m({ readOnly: true })], f7.prototype, "interacting", null), f7 = r([a3("esri.views.ToolViewManager")], f7);

// node_modules/@arcgis/core/views/3d/support/DefaultHighlights.js
function n18() {
  return new (V.ofType(u6))([new u6({ name: c7 }), new u6({ name: m6, color: p6 })]);
}

// node_modules/@arcgis/core/views/input/gamepad/GamepadInputDevice.js
var n19 = class extends g2 {
  constructor(e28) {
    super(), this.nativeIndex = null, this._detectedDeviceType = "unknown", "standard" === e28.mapping ? this._detectedDeviceType = "standard" : i10.test(e28.id) ? this._detectedDeviceType = "spacemouse" : this._detectedDeviceType = "unknown", this.nativeIndex = e28.index;
  }
  get native() {
    const e28 = navigator.getGamepads ? navigator.getGamepads() : [];
    return null != this.nativeIndex && this.nativeIndex < e28.length ? e28[this.nativeIndex] : null;
  }
  get deviceType() {
    return this._detectedDeviceType;
  }
  get axisThreshold() {
    return a7[this.deviceType];
  }
};
r([m({ nonNullable: true, readOnly: true })], n19.prototype, "nativeIndex", void 0), r([m({ type: String, readOnly: true })], n19.prototype, "deviceType", null), r([m({ type: Number, readOnly: true })], n19.prototype, "axisThreshold", null), n19 = r([a3("esri.views.input.gamepad.GamepadInputDevice")], n19);
var o14 = n19;
var i10 = new RegExp("^(3dconnexion|space(mouse|navigator|pilot|explorer))", "i");
var a7 = { standard: 0.15, spacemouse: 0.025, unknown: 0 };

// node_modules/@arcgis/core/views/input/gamepad/GamepadSettings.js
var p13 = class extends g2 {
  constructor(...o29) {
    super(...o29), this.devices = new V(), this.enabledFocusMode = "document";
  }
};
r([m({ type: V.ofType(o14), readOnly: true })], p13.prototype, "devices", void 0), r([m({ type: ["document", "view", "none"] })], p13.prototype, "enabledFocusMode", void 0), p13 = r([a3("esri.views.input.gamepad.GamepadSettings")], p13);
var i11 = p13;

// node_modules/@arcgis/core/views/input/Input.js
var p14 = class extends g2 {
  constructor() {
    super(...arguments), this.gamepad = new i11();
  }
};
r([m({ readOnly: true })], p14.prototype, "gamepad", void 0), p14 = r([a3("esri.views.input.Input")], p14);
var a8 = p14;

// node_modules/@arcgis/core/views/navigation/NavigationActionMap.js
var s16 = () => m({ type: ["pan", "rotate", "zoom", "none"], nonNullable: true });
var a9 = class extends g2 {
  constructor(o29) {
    super(o29), this.dragPrimary = "pan", this.dragSecondary = "rotate", this.dragTertiary = "zoom", this.mouseWheel = "zoom";
  }
};
r([s16()], a9.prototype, "dragPrimary", void 0), r([s16()], a9.prototype, "dragSecondary", void 0), r([s16()], a9.prototype, "dragTertiary", void 0), r([m({ type: ["zoom", "none"], nonNullable: true })], a9.prototype, "mouseWheel", void 0), a9 = r([a3("esri.views.navigation.NavigationActionMap")], a9);
var p15 = a9;

// node_modules/@arcgis/core/views/navigation/gamepad/GamepadSettings.js
var s17 = class extends g2 {
  constructor(o29) {
    super(o29), this.enabled = true, this.device = null, this.mode = "pan", this.tiltDirection = "forward-down", this.velocityFactor = 1;
  }
};
r([m({ type: Boolean, nonNullable: true })], s17.prototype, "enabled", void 0), r([m({ type: o14 })], s17.prototype, "device", void 0), r([m({ type: ["pan", "zoom"], nonNullable: true })], s17.prototype, "mode", void 0), r([m({ type: ["forward-down", "forward-up"], nonNullable: true })], s17.prototype, "tiltDirection", void 0), r([m({ type: Number, nonNullable: true })], s17.prototype, "velocityFactor", void 0), s17 = r([a3("esri.views.navigation.gamepad.GamepadSettings")], s17);
var i12 = s17;

// node_modules/@arcgis/core/views/navigation/Navigation.js
var i13 = class extends g2 {
  constructor(o29) {
    super(o29), this.actionMap = new p15(), this.browserTouchPanEnabled = true, this.gamepad = new i12(), this.momentumEnabled = true;
  }
  get effectiveMomentumEnabled() {
    return this.momentumEnabled && !o8();
  }
  get mouseWheelZoomEnabled() {
    return "zoom" === this.actionMap.mouseWheel;
  }
  set mouseWheelZoomEnabled(o29) {
    s3(n.getLogger(this), "mouseWheelZoomEnabled", { replacement: "actionMap.mouseWheel", version: "4.32", warnOnce: true }), this.actionMap.mouseWheel = o29 ? "zoom" : "none";
  }
};
r([m({ type: p15, nonNullable: true })], i13.prototype, "actionMap", void 0), r([m({ type: Boolean })], i13.prototype, "browserTouchPanEnabled", void 0), r([m({ type: i12, nonNullable: true })], i13.prototype, "gamepad", void 0), r([m({ type: Boolean })], i13.prototype, "momentumEnabled", void 0), r([m({ type: Boolean })], i13.prototype, "mouseWheelZoomEnabled", null), i13 = r([a3("esri.views.navigation.Navigation")], i13);
var l10 = i13;

// node_modules/@arcgis/core/views/support/projectionUtils.js
var n20;
var s18 = null;
function c13(r33) {
  return __async(this, null, function* () {
    s18 || (s18 = import("./geometryServiceUtils-SY7IU6EB.js").then((e28) => n20 = e28)), yield s18, s4(r33);
  });
}
function p16(e28, s31, a27, m24) {
  return __async(this, null, function* () {
    if (!e28) return null;
    const l20 = e28.spatialReference;
    return k() || L2(l20, s31) ? O2(e28, s31) : n20 ? n20.projectGeometry(e28, s31, a27, m24) : (yield Promise.race([c13(m24), K(m24)]), p16(e28, s31, a27, m24));
  });
}

// node_modules/@arcgis/core/views/support/DefaultsFromMap.js
var d7 = class extends g2 {
  constructor(e28) {
    super(e28), this.required = { extent: false, heightModelInfo: false, tileInfo: false }, this.defaultSpatialReference = null, this.userSpatialReference = null, this.sourcePreloadCount = 10, this.priorityCollection = null, this.requiresExtentInSpatialReference = true, this.suspended = false, this._projectExtentTask = { task: null, input: null, output: null, spatialReference: null };
  }
  destroy() {
    this._projectExtentTask.task && (this._projectExtentTask.task = e2(this._projectExtentTask.task)), this._set("map", null);
  }
  get ready() {
    return !this._spatialReferenceTask.updating && !this._tileInfoTask.updating && !this._extentTask.updating;
  }
  get heightModelInfoReady() {
    return !this._heightModelInfoTask.updating;
  }
  get spatialReference() {
    return this.userSpatialReference ?? this._spatialReferenceTask.spatialReference;
  }
  get extent() {
    return this._extentTask.extent;
  }
  get heightModelInfo() {
    return this._heightModelInfoTask.heightModelInfo;
  }
  get vcsWkid() {
    return this._heightModelInfoTask.vcsWkid;
  }
  get latestVcsWkid() {
    return this._heightModelInfoTask.latestVcsWkid;
  }
  get viewingMode() {
    return null == this.userSpatialReference || this.userSpatialReference.equals(this._spatialReferenceTask.spatialReference) ? this._spatialReferenceTask.viewingMode : null;
  }
  get tileInfo() {
    return this._tileInfoTask.tileInfo;
  }
  get mapCollections() {
    const e28 = this.map?.(), t30 = [];
    return null != this.priorityCollection && t30.push(this.priorityCollection), t30.push({ parent: e28?.basemap, layers: e28?.basemap?.baseLayers }, { layers: e28?.layers }, { parent: e28?.ground, layers: e28?.ground?.layers }, { parent: e28?.basemap, layers: e28?.basemap?.referenceLayers }), t30;
  }
  get _spatialReferenceTask() {
    if (this.suspended) return this._get("_spatialReferenceTask") ?? { updating: false };
    let e28;
    if (this._collectLayers(this.mapCollections, (t31) => {
      const n33 = this._getSupportedSpatialReferences(t31);
      if (n33.length > 0) {
        const t32 = this._narrowDownSpatialReferenceCandidates(e28, n33);
        null != t32 && (e28 = t32);
      }
      return 1 === e28?.length;
    }) && 1 !== e28?.length) return { updating: true };
    const t30 = this._pickSpatialReferenceCandidate(e28);
    return { spatialReference: t30?.spatialReference ?? null, viewingMode: t30?.viewingMode ?? null, updating: false };
  }
  get _tileInfoTask() {
    if (!this.required.tileInfo) return this._get("_tileInfoTask") ?? { updating: false };
    const e28 = this.map?.(), t30 = this.spatialReference;
    if (!t30) return { updating: this._spatialReferenceTask.updating };
    let n33;
    const a27 = this._collectLayers([{ parent: e28?.basemap, layers: e28?.basemap?.baseLayers }, { layers: e28?.layers }], (e29) => !(!("tileInfo" in e29) || !e29.tileInfo?.spatialReference.equals(t30)) && (n33 = e29, true), (e29) => "tileInfo" in e29);
    if (n33) {
      return { tileInfo: n33.tileInfo, updating: false };
    }
    return { updating: a27 };
  }
  get _heightModelInfoTask() {
    if (!this.required.heightModelInfo || this.suspended && this._get("_heightModelInfoTask")?.heightModelInfo) return this._get("_heightModelInfoTask") ?? { updating: false };
    let e28 = {};
    const t30 = this._collectLayers(this.mapCollections, (t31) => {
      const n33 = l5(t31);
      return !!n33 && (e28 = { heightModelInfo: n33, vcsWkid: t31.spatialReference?.vcsWkid, latestVcsWkid: t31.spatialReference?.latestVcsWkid }, true);
    }, (e29) => g6(e29));
    return __spreadProps(__spreadValues({}, e28), { updating: t30 });
  }
  get _extentCandidatesTask() {
    if (this.suspended || !this.required.extent) return this._get("_extentCandidatesTask") ?? { updating: false };
    if (!this.spatialReference) return { updating: this._spatialReferenceTask.updating };
    const e28 = [], t30 = this._collectLayers(this.mapCollections, (t31) => {
      const n33 = "fullExtents" in t31 && t31.fullExtents || (null != t31.fullExtent ? [t31.fullExtent] : []), a27 = this.requiresExtentInSpatialReference ? null : n33[0], s31 = n33.find((e29) => e29.spatialReference.equals(this.spatialReference)) ?? a27;
      if (s31) return e28.push({ extent: s31, layer: t31 }), true;
      if (this._getSupportedSpatialReferences(t31).length > 0) for (const i25 of n33) e28.push({ extent: i25, layer: t31 });
      return false;
    });
    return { candidates: e28, updating: t30 };
  }
  get _extentTask() {
    const { candidates: e28, updating: t30 } = this._extentCandidatesTask;
    if (t30) return { updating: t30 };
    if (null == e28 || 0 === e28.length) return { updating: false };
    if (!this.spatialReference) return { updating: this._spatialReferenceTask.updating };
    const i25 = this._pickExtentCandidate(e28), r33 = this.spatialReference;
    return i25.extent.equals(this._projectExtentTask.input) && r33.equals(this._projectExtentTask.spatialReference) ? { extent: this._projectExtentTask.output, updating: null != this._projectExtentTask.task && !this._projectExtentTask.task.finished } : (null != this._projectExtentTask.task && (this._projectExtentTask.task = e2(this._projectExtentTask.task)), this._projectExtentTask = { input: i25.extent.clone(), output: null, spatialReference: r33.clone(), task: d2((e29) => __async(this, null, function* () {
      try {
        const t31 = yield p16(i25.extent, r33, "portalItem" in i25.layer ? i25.layer.portalItem : void 0, e29);
        this._projectExtentTask = __spreadProps(__spreadValues({}, this._projectExtentTask), { task: null, output: t31 });
      } catch (t31) {
        if (c(e29)) return;
        this._projectExtentTask = __spreadProps(__spreadValues({}, this._projectExtentTask), { task: null });
      }
    })) }, { updating: true });
  }
  _narrowDownSpatialReferenceCandidates(e28, t30) {
    if (null == e28) return t30;
    const n33 = new Array();
    for (const a27 of e28) for (const e29 of t30) {
      if (!a27.spatialReference.equals(e29.spatialReference)) continue;
      const t31 = h10(a27.viewingMode, e29.viewingMode);
      if (false !== t31) {
        n33.push({ spatialReference: a27.spatialReference, viewingMode: t31 });
        break;
      }
    }
    return n33.length > 0 ? n33 : null;
  }
  _pickSpatialReferenceCandidate(e28) {
    const t30 = this.defaultSpatialReference;
    return null == e28 || e28.length < 1 ? t30 ? { spatialReference: t30, viewingMode: null } : null : (null != t30 && e28.length > 1 && e28.some(({ spatialReference: e29 }) => e29.equals(t30)) && (e28 = e28.filter(({ spatialReference: e29 }) => e29.equals(t30))), e28.length > 1 && e28.some(({ viewingMode: e29 }) => e29 !== l3.Local) && (e28 = e28.filter(({ viewingMode: e29 }) => e29 !== l3.Local)), e28[0]);
  }
  _getSupportedSpatialReferences(e28) {
    const t30 = "supportedSpatialReferences" in e28 && e28.supportedSpatialReferences || (e28.spatialReference ? [e28.spatialReference] : []);
    if (0 === t30.length) return [];
    const n33 = [];
    for (const a27 of t30) {
      const t31 = this.getSpatialReferenceSupport(a27, e28);
      if (null != t31) {
        const e29 = t31.constraints ?? [{ spatialReference: a27, viewingMode: null }];
        for (const { spatialReference: t32, viewingMode: a28 } of e29) this.requiresExtentInSpatialReference && null != this.userSpatialReference && !t32.equals(this.userSpatialReference) || n33.push({ spatialReference: t32, viewingMode: a28 });
      }
    }
    return n33;
  }
  _pickExtentCandidate(e28) {
    const t30 = this.spatialReference;
    return e28.find(({ extent: e29 }) => t30.equals(e29.spatialReference)) || e28[0];
  }
  _collectLayers(e28, t30, n33 = () => true) {
    switch (this._loadMaybe(this.map?.())) {
      case "loading":
        return true;
      case "failed":
        return false;
    }
    const a27 = new f8(n33, t30);
    for (const s31 of e28) if (this._collectCollection(s31, a27), a27.done || a27.preloading === this.sourcePreloadCount) break;
    return a27.updating;
  }
  _collectCollection(e28, t30) {
    if (e28.layers) {
      switch (this._loadMaybe(e28.parent)) {
        case "loading":
          return t30.updating = true, void ++t30.preloading;
        case "failed":
          return;
      }
      for (const n33 of e28.layers) if (t30.layerFilter(n33)) {
        switch (this._loadMaybe(n33)) {
          case "failed":
            continue;
          case "loading":
            t30.updating = true, ++t30.preloading;
            break;
          case "loaded":
            if (t30.updating || (t30.done = t30.pushLayer(n33)), t30.done || t30.preloading === this.sourcePreloadCount) break;
            "layers" in n33 && this._collectCollection({ layers: n33.layers }, t30);
        }
        if (t30.done || t30.preloading === this.sourcePreloadCount) break;
      }
    }
  }
  _loadMaybe(e28) {
    return e28 && "loadStatus" in e28 && null != e28.loadStatus ? "not-loaded" === e28.loadStatus ? (e28.load().catch((e29) => {
      b(e29);
    }), "loading") : e28.loadStatus : "loaded";
  }
};
r([m()], d7.prototype, "required", void 0), r([m({ constructOnly: true })], d7.prototype, "map", void 0), r([m({ constructOnly: true })], d7.prototype, "getSpatialReferenceSupport", void 0), r([m()], d7.prototype, "defaultSpatialReference", void 0), r([m()], d7.prototype, "userSpatialReference", void 0), r([m()], d7.prototype, "sourcePreloadCount", void 0), r([m()], d7.prototype, "priorityCollection", void 0), r([m()], d7.prototype, "requiresExtentInSpatialReference", void 0), r([m()], d7.prototype, "suspended", void 0), r([m({ readOnly: true })], d7.prototype, "ready", null), r([m({ readOnly: true })], d7.prototype, "heightModelInfoReady", null), r([m({ readOnly: true })], d7.prototype, "spatialReference", null), r([m({ readOnly: true })], d7.prototype, "extent", null), r([m({ readOnly: true })], d7.prototype, "heightModelInfo", null), r([m({ readOnly: true })], d7.prototype, "vcsWkid", null), r([m({ readOnly: true })], d7.prototype, "latestVcsWkid", null), r([m({ readOnly: true })], d7.prototype, "viewingMode", null), r([m({ readOnly: true })], d7.prototype, "tileInfo", null), r([m({ readOnly: true })], d7.prototype, "mapCollections", null), r([m({ readOnly: true })], d7.prototype, "_spatialReferenceTask", null), r([m({ readOnly: true })], d7.prototype, "_tileInfoTask", null), r([m({ readOnly: true })], d7.prototype, "_heightModelInfoTask", null), r([m({ readOnly: true })], d7.prototype, "_extentCandidatesTask", null), r([m()], d7.prototype, "_extentTask", null), r([m()], d7.prototype, "_projectExtentTask", void 0), d7 = r([a3("esri.views.support.DefaultsFromMap")], d7);
var f8 = class {
  constructor(e28, t30) {
    this.layerFilter = e28, this.pushLayer = t30, this.preloading = -1, this.updating = false, this.done = false;
  }
};
function h10(e28, t30) {
  return null != e28 ? null != t30 ? e28 === t30 && e28 : e28 : t30;
}

// node_modules/@arcgis/core/views/support/RequiredFieldsOptions.js
var t15 = class extends g2 {
  constructor(o29) {
    super(o29), this.featureTitleFields = false, this.utilityNetworkFields = false, this.globalIdField = false;
  }
};
r([m()], t15.prototype, "featureTitleFields", void 0), r([m()], t15.prototype, "utilityNetworkFields", void 0), r([m()], t15.prototype, "globalIdField", void 0), t15 = r([a3("esri.views.support.RequiredFieldsOptions")], t15);
var i14 = t15;

// node_modules/@arcgis/core/views/View.js
var $;
var B = $ = class extends i.EventedMixin(p2.EsriPromiseMixin(g2)) {
  constructor(e28) {
    super(e28), this._userSpatialReference = null, this._cursor = null, this.handles = new r3(), this.updatingHandles = new h6(), this.allLayerViews = new n7({ getCollections: () => [this.basemapView?.baseLayerViews, this.groundView?.layerViews, this.layerViews, this.basemapView?.referenceLayerViews], getChildrenFunction: Q }), this.groundView = null, this.basemapView = null, this.displayFilterEnabled = true, this.fatalError = null, this.graphics = new c6(), this.analyses = new t13(), this.typeSpecificPreconditionsReady = true, this.layerViews = new V(), this.magnifier = new p9(), this.padding = { left: 0, top: 0, right: 0, bottom: 0 }, this.ready = false, this._readyStateWaitingTask = null, this.supportsGround = true, this.type = null, this.scale = null, this.updating = false, this.initialExtentRequired = true, this.input = new a8(), this.navigation = new l10(), this.layerViewManager = null, this.analysisViewManager = null, this.isHeightModelInfoRequired = false, this.width = null, this.height = null, this.resizing = false, this.suspended = false, this.viewEvents = new c11(this), this.persistableViewModels = new V(), this.requiredFieldsOptions = new i14(), this._isValid = false, this._readyCycleForced = false, this._lockedSpatialReference = null, this._userTimeZone = null, this._lockedTimeZone = null, this._userTimeExtent = null, this._lockedTimeExtent = null, this.theme = null, this.handles.add(d3(() => this.preconditionsReady, (e29) => {
      const t30 = this.ready;
      if (e29 ? (this._lockedSpatialReference = this.spatialReference, this._lockedTimeZone = this.timeZone, this._lockedTimeExtent = this.timeExtent, $.views.add(this)) : (this._lockedSpatialReference = null, $.views.remove(this)), this.notifyChange("spatialReference"), !e29 && t30) this.toolViewManager?.detach(), null != this.analysisViewManager && this.analysisViewManager.detach(), this.layerViewManager?.clear(), this._teardown();
      else if (e29 && !t30) {
        try {
          this._startup();
        } catch (i25) {
          return void queueMicrotask(() => {
            this.fatalError = new s("startup-error", null, i25);
          });
        }
        null != this.analysisViewManager && this.analysisViewManager.attach(), this.toolViewManager.attach();
      }
    }, C));
  }
  initialize() {
    this.addResolvingPromise(Promise.all([this.loadAsyncDependencies(), this.validate()]).then(() => (this._isValid = true, w(() => this.ready)))), this.basemapView = new p8({ view: this }), this.layerViewManager = new j4({ view: this, layerViewImporter: { importLayerView: (e28) => this.importLayerView(e28), hasLayerViewModule: (e28) => this.hasLayerViewModule(e28) }, supportsGround: this.supportsGround }), this.toolViewManager = new f7({ view: this }), this.selectionManager = new b4({ view: this }), this.addHandles([p3(() => "map-content-error" === this.readyState && !this.spatialReference, () => {
      n.getLogger(this).warn("#spatialReference", "no spatial reference could be derived from the currently added map layers");
    }), d3(() => this.initialExtentRequired, (e28) => this.defaultsFromMap.required = __spreadProps(__spreadValues({}, this.defaultsFromMap.required), { extent: e28 }), A3), d3(() => this.ready, (e28) => {
      this.defaultsFromMap && (this.defaultsFromMap.suspended = e28, this.defaultsFromMap.userSpatialReference = e28 ? this.spatialReference : this._userSpatialReference);
    }, C), d3(() => this._userSpatialReference, (e28) => {
      this.defaultsFromMap && (this.defaultsFromMap.userSpatialReference = e28);
    }, A3)]);
  }
  destroy() {
    this.destroyed || ($.views.remove(this), this.viewEvents.destroy(), this.allLayerViews.destroy(), this.navigation && (this.navigation.destroy(), this._set("navigation", null)), this.graphics = u(this.graphics), this.analyses = u(this.analyses), this.defaultsFromMap.destroy(), this._set("defaultsFromMap", null), u(this.analysisViewManager), this.toolViewManager = u(this.toolViewManager), this.layerViewManager = u(this.layerViewManager), this.selectionManager = u(this.selectionManager), this.basemapView = u(this.basemapView), this.groundView?.destroy(), this.layerViews?.forEach((e28) => e28.destroy()), this.layerViews.length = 0, this.invalidate(), this._emitter.clear(), this.handles.destroy(), this.map = u(this.map), this.updatingHandles.destroy());
  }
  _startup() {
    this._set("ready", true);
  }
  _teardown() {
    this._set("ready", false);
  }
  whenReady() {
    return Promise.resolve(this);
  }
  toMap() {
    return n.getLogger(this).error("#toMap()", "Not implemented on this instance of View"), null;
  }
  get activeTool() {
    return this.toolViewManager?.activeTool;
  }
  set activeTool(e28) {
    this.toolViewManager && (this.toolViewManager.activeTool = e28);
  }
  get animation() {
    return this._get("animation");
  }
  set animation(e28) {
    this._set("animation", e28);
  }
  get center() {
    return null;
  }
  get defaultsFromMapSettings() {
    return {};
  }
  get defaultsFromMap() {
    return new d7(__spreadValues({ required: { tileInfo: false, heightModelInfo: false, extent: false }, map: () => this.map, getSpatialReferenceSupport: (e28, t30) => this.getSpatialReferenceSupport(e28, t30) }, this.defaultsFromMapSettings));
  }
  get extent() {
    return this._get("extent");
  }
  set extent(e28) {
    this._set("extent", e28);
  }
  get heightModelInfo() {
    return this.getDefaultHeightModelInfo();
  }
  get highlights() {
    return this._get("highlights") ?? n18();
  }
  set highlights(e28) {
    this._set("highlights", n8(e28, this._get("highlights"), V.ofType(u6)));
  }
  get interacting() {
    return this.navigating;
  }
  get navigating() {
    return false;
  }
  get preconditionsReady() {
    return !(this.fatalError || !this._isValid || this._readyCycleForced || !this.map || m4.isLoadable(this.map) && !this.map.loaded || 0 === this.width || 0 === this.height || !this.spatialReference || !this._validateSpatialReference(this.spatialReference) || !this._lockedSpatialReference && !this.defaultsFromMap?.ready || !this.typeSpecificPreconditionsReady);
  }
  get resolution() {
    return 0;
  }
  set map(e28) {
    e28 !== this._get("map") && (e28?.destroyed && (n.getLogger(this).warn("#map", "The provided map is already destroyed", { map: e28 }), e28 = null), m4.isLoadable(e28) && e28.load().catch(() => {
    }), this.constructed && !this.destroyed && (this.forceReadyCycle(), this._lockedSpatialReference = null), this._set("map", e28));
  }
  get readyState() {
    if (this.destroyed) return this._get("readyState");
    if (!this.map) return "missing-map";
    if ("container" in this && !this.container) return "missing-container";
    if (this.fatalError) return "rendering-error";
    if ((this.defaultsFromMap?.ready ?? false) && !this.spatialReference) {
      const e28 = !("loaded" in this.map) || this.map.loaded, t30 = this.map.ground.loaded, i25 = this.map.basemap?.loaded ?? true;
      return e28 && i25 && t30 && !this.map?.allLayers.length ? "empty-map" : (this._readyStateWaitingTask || (this._readyStateWaitingTask = d2((e29) => A(has("view-readyState-waiting-delay"), null, e29)), this.addHandles(this._readyStateWaitingTask), this.addHandles(this._readyStateWaitingTask, "ready-state-task")), this._readyStateWaitingTask?.finished ? "map-content-error" : "loading");
    }
    return this._readyStateWaitingTask = e2(this._readyStateWaitingTask), this.removeHandles("ready-state-task"), this.ready ? "ready" : "loading";
  }
  get spatialReference() {
    const e28 = this._userSpatialReference || this._lockedSpatialReference || this.getDefaultSpatialReference() || null;
    if (e28 && this.defaultsFromMap?.required?.heightModelInfo) {
      const t30 = e28.clone();
      return t30.vcsWkid = this.defaultsFromMap.vcsWkid, t30.latestVcsWkid = this.defaultsFromMap.latestVcsWkid, t30;
    }
    return e28;
  }
  set spatialReference(e28) {
    const t30 = !s7(e28, this._get("spatialReference"));
    this._set("_userSpatialReference", e28), t30 && (this._set("spatialReference", e28), this._spatialReferenceChanged(e28));
  }
  _spatialReferenceChanged(e28) {
  }
  get stationary() {
    return !this.animation && !this.navigating && !this.resizing;
  }
  get timeExtent() {
    return this._userTimeExtent ?? this._lockedTimeExtent ?? this.getDefaultTimeExtent() ?? null;
  }
  set timeExtent(e28) {
    this._userTimeExtent = e28;
  }
  get timeZone() {
    return this._userTimeZone ?? this._lockedTimeZone ?? this.getDefaultTimeZone() ?? e3;
  }
  set timeZone(e28) {
    this._userTimeZone = e28, p(e28) || n.getLogger(this).warn("#timeZone", `the parsed value '${e28}' may not be a valid IANA time zone`);
  }
  get tools() {
    return this.toolViewManager?.tools;
  }
  get initialExtent() {
    return this.defaultsFromMap?.extent;
  }
  get cursor() {
    return this.toolViewManager?.cursor ?? this._cursor ?? "default";
  }
  set cursor(e28) {
    this._cursor = e28, this.notifyChange("cursor");
  }
  get size() {
    return [this.width, this.height];
  }
  get effectiveTheme() {
    return this.theme ?? new l7();
  }
  whenLayerView(e28) {
    return this.layerViewManager?.whenLayerView(e28) ?? Promise.reject();
  }
  getDefaultSpatialReference() {
    return this.defaultsFromMap?.spatialReference;
  }
  getDefaultHeightModelInfo() {
    return (this.map && "heightModelInfo" in this.map ? this.map.heightModelInfo : void 0) ?? this.defaultsFromMap?.heightModelInfo ?? null;
  }
  getDefaultTimeZone() {
    return null;
  }
  getDefaultTimeExtent() {
    return null;
  }
  importLayerView(e28) {
    throw new s("importLayerView() not implemented");
  }
  hasLayerViewModule(e28) {
    return false;
  }
  validate() {
    return __async(this, null, function* () {
    });
  }
  loadAsyncDependencies() {
    return __async(this, null, function* () {
    });
  }
  invalidate() {
    this._isValid = false;
  }
  getSpatialReferenceSupport() {
    return { constraints: null };
  }
  _validateSpatialReference(e28) {
    return null != this.getSpatialReferenceSupport(e28);
  }
  when(e28, t30) {
    return this.isResolved() && !this.ready && n.getLogger(this).warn("#when()", "Calling view.when() while the view is no longer ready but was already resolved once will resolve immediately. Use reactiveUtils.whenOnce(() => view.ready).then(...) instead."), super.when(e28, t30);
  }
  forceReadyCycle() {
    this.ready && (p3(() => this.destroyed || false === this.preconditionsReady, () => this._readyCycleForced = false, { once: true }), this._readyCycleForced = true);
  }
  addAndActivateTool(e28) {
    this.toolViewManager.tools.add(e28), this.activeTool = e28;
  }
  tryFatalErrorRecovery() {
    this.fatalError = null;
  }
};
B.views = new V(), r([m()], B.prototype, "_userSpatialReference", void 0), r([m()], B.prototype, "activeTool", null), r([m({ readOnly: true })], B.prototype, "allLayerViews", void 0), r([m()], B.prototype, "groundView", void 0), r([m()], B.prototype, "animation", null), r([m()], B.prototype, "basemapView", void 0), r([m()], B.prototype, "center", null), r([m()], B.prototype, "defaultsFromMapSettings", null), r([m()], B.prototype, "defaultsFromMap", null), r([m()], B.prototype, "displayFilterEnabled", void 0), r([m()], B.prototype, "fatalError", void 0), r([m({ type: w2 })], B.prototype, "extent", null), r([m(l4(c6, "graphics"))], B.prototype, "graphics", void 0), r([m(l4(t13, "analyses"))], B.prototype, "analyses", void 0), r([m({ readOnly: true, type: v2 })], B.prototype, "heightModelInfo", null), r([m({ type: V.ofType(u6) })], B.prototype, "highlights", null), r([m({ readOnly: true })], B.prototype, "interacting", null), r([m({ readOnly: true })], B.prototype, "navigating", null), r([m({ readOnly: true, dependsOn: ["fatalError", "_isValid", "_readyCycleForced", "map", "map.loaded?", "width", "height", "spatialReference", "_lockedSpatialReference", "defaultsFromMap.ready", "typeSpecificPreconditionsReady"] })], B.prototype, "preconditionsReady", null), r([m({ readOnly: true })], B.prototype, "typeSpecificPreconditionsReady", void 0), r([m({ type: V, readOnly: true })], B.prototype, "layerViews", void 0), r([m()], B.prototype, "resolution", null), r([m({ type: p9 })], B.prototype, "magnifier", void 0), r([m({ value: null, type: L3 })], B.prototype, "map", null), r([m()], B.prototype, "padding", void 0), r([m({ readOnly: true })], B.prototype, "ready", void 0), r([m()], B.prototype, "_readyStateWaitingTask", void 0), r([m({ readOnly: true })], B.prototype, "readyState", null), r([m({ type: g4 })], B.prototype, "spatialReference", null), r([m()], B.prototype, "stationary", null), r([m({ readOnly: true })], B.prototype, "supportsGround", void 0), r([m({ type: p4 })], B.prototype, "timeExtent", null), r([m({ type: String, nonNullable: true })], B.prototype, "timeZone", null), r([m()], B.prototype, "tools", null), r([m()], B.prototype, "toolViewManager", void 0), r([m({ readOnly: true })], B.prototype, "type", void 0), r([m({ type: Number })], B.prototype, "scale", void 0), r([m({ readOnly: true })], B.prototype, "updating", void 0), r([m({ readOnly: true })], B.prototype, "initialExtentRequired", void 0), r([m({ readOnly: true })], B.prototype, "initialExtent", null), r([m()], B.prototype, "cursor", null), r([m({ readOnly: true })], B.prototype, "input", void 0), r([m({ type: l10, nonNullable: true })], B.prototype, "navigation", void 0), r([m()], B.prototype, "layerViewManager", void 0), r([m()], B.prototype, "analysisViewManager", void 0), r([m()], B.prototype, "selectionManager", void 0), r([m()], B.prototype, "width", void 0), r([m()], B.prototype, "height", void 0), r([m({ readOnly: true })], B.prototype, "resizing", void 0), r([m({ value: null, readOnly: true })], B.prototype, "size", null), r([m({ readOnly: true })], B.prototype, "suspended", void 0), r([m({ readOnly: true })], B.prototype, "viewEvents", void 0), r([m({ readOnly: true })], B.prototype, "persistableViewModels", void 0), r([m()], B.prototype, "_isValid", void 0), r([m()], B.prototype, "_readyCycleForced", void 0), r([m()], B.prototype, "_lockedSpatialReference", void 0), r([m()], B.prototype, "_userTimeZone", void 0), r([m()], B.prototype, "_lockedTimeZone", void 0), r([m()], B.prototype, "_userTimeExtent", void 0), r([m()], B.prototype, "_lockedTimeExtent", void 0), r([m({ type: l7 })], B.prototype, "theme", void 0), r([m({ readOnly: true, type: l7 })], B.prototype, "effectiveTheme", null), B = $ = r([a3("esri.views.View")], B);
var J = globalThis.$arcgis;
J && !J.views && Object.defineProperty(J, "views", { configurable: false, enumerable: true, writable: false, value: B.views });
var K2 = B;
function Q(e28) {
  return e28.layerViews;
}

// node_modules/@arcgis/core/core/libs/gl-matrix-2/types/vec2.js
function n21(n33) {
  return n33 instanceof Float32Array && n33.length >= 2;
}
function r16(n33) {
  return Array.isArray(n33) && n33.length >= 2;
}
function t16(t30) {
  return n21(t30) || r16(t30);
}

// node_modules/@arcgis/core/views/2d/ViewState.js
var G2;
var O3 = [0, 0];
var W = G2 = class extends S2 {
  constructor(t30) {
    super(t30), this._viewpoint2D = { center: n11(), rotation: 0, scale: 0, spatialReference: void 0 }, this.center = [0, 0], this.extent = new w2(), this.id = 0, this.inverseTransform = e10(), this.resolution = 0, this.rotation = 0, this.scale = 0, this.transform = e10(), this.transformNoRotation = e10(), this.displayMat3 = e12(), this.displayViewMat3 = e12(), this.viewMat3 = e12(), this.viewMat2d = n13(), this.worldScreenWidth = 0, this.size = [0, 0];
  }
  set pixelRatio(t30) {
    this._set("pixelRatio", t30), this._update();
  }
  set size(t30) {
    this._set("size", t30), this._update();
  }
  set viewpoint(t30) {
    if (t30) {
      const i25 = this._viewpoint2D, e28 = t30.targetGeometry;
      i25.center[0] = e28.x, i25.center[1] = e28.y, i25.rotation = t30.rotation, i25.scale = t30.scale, i25.spatialReference = e28.spatialReference;
    }
    this._update();
  }
  get visibleArea() {
    const [t30, i25] = this.size;
    return [this.toMap([0, 0], 0, 0), this.toMap([0, 0], 0, i25), this.toMap([0, 0], t30, i25), this.toMap([0, 0], t30, 0)];
  }
  copy(t30) {
    const i25 = this.size, e28 = this.viewpoint;
    return e28 && i25 ? (this.viewpoint = Z(e28, t30.viewpoint), this._set("size", r9(i25, t30.size))) : (this.viewpoint = t30.viewpoint.clone(), this._set("size", [t30.size[0], t30.size[1]])), this._set("pixelRatio", t30.pixelRatio), this;
  }
  clone() {
    return new G2({ size: this.size, viewpoint: this.viewpoint.clone(), pixelRatio: this.pixelRatio });
  }
  toMap(t30, i25, e28) {
    return t16(i25) ? S3(t30, i25, this.inverseTransform) : (O3[0] = i25, O3[1] = e28, S3(t30, O3, this.inverseTransform));
  }
  toScreen(t30, i25, e28) {
    return t16(i25) ? S3(t30, i25, this.transform) : (O3[0] = i25, O3[1] = e28, S3(t30, O3, this.transform));
  }
  toScreenNoRotation(t30, i25, e28) {
    return t16(i25) ? S3(t30, i25, this.transformNoRotation) : (O3[0] = i25, O3[1] = e28, S3(t30, O3, this.transformNoRotation));
  }
  wrapMapCoordinate(t30, i25) {
    r9(t30, i25);
    const [e28] = i25, [s31] = this.center, { extent: o29, spatialReference: r33 } = this;
    let { xmin: a27, xmax: n33 } = o29;
    if (r33.isWrappable) {
      const t31 = mt(r33) / 2;
      a27 = Math.max(a27, s31 - t31), n33 = Math.min(n33, s31 + t31);
    }
    return (e28 < a27 || e28 > n33) && (t30[0] = P2(e28, s31, r33)), t30;
  }
  getScreenTransform(t30, i25) {
    const { center: e28 } = this._viewpoint2D, s31 = this._get("pixelRatio") || 1, o29 = this._get("size");
    return ut(t30, e28, o29, i25, 0, s31), t30;
  }
  _update() {
    const { center: t30, spatialReference: e28, scale: s31, rotation: o29 } = this._viewpoint2D, h21 = this._get("pixelRatio") || 1, c29 = this._get("size"), u17 = new m3({ targetGeometry: new j2(t30[0], t30[1], e28), scale: s31, rotation: o29 });
    if (this._set("viewpoint", u17), !c29 || !e28 || !s31) return;
    this.resolution = ot(u17), this.rotation = o29, this.scale = s31, this.spatialReference = e28, r9(this.center, t30);
    const j8 = 0 !== c29[0] ? 2 / c29[0] : 0, g16 = 0 !== c29[1] ? -2 / c29[1] : 0;
    r8(this.displayMat3, j8, 0, 0, 0, g16, 0, -1, 1, 1);
    const R = o6(this.viewMat3), _10 = t6(c29[0] / 2, c29[1] / 2), b9 = t6(-c29[0] / 2, -c29[1] / 2), z4 = u4(o29);
    M3(R, R, _10), h5(R, R, z4), M3(R, R, b9), i3(this.displayViewMat3, this.displayMat3, R);
    const S5 = f3(this.viewMat2d, _10);
    return s12(S5, S5, z4), i4(S5, S5, b9), _3(this.extent, u17, c29), lt(this.transform, u17, c29, h21), u5(this.inverseTransform, this.transform), ft(this.transformNoRotation, u17, c29, h21), this.worldScreenWidth = yt(this.spatialReference, this.resolution), this._set("id", this.id + 1), this.notifyChange("visibleArea"), this;
  }
};
r([m({ readOnly: true })], W.prototype, "id", void 0), r([m({ value: 1, json: { write: true } })], W.prototype, "pixelRatio", null), r([m({ json: { write: true } })], W.prototype, "size", null), r([m()], W.prototype, "spatialReference", void 0), r([m({ type: m3, json: { write: true } })], W.prototype, "viewpoint", null), r([m({ readOnly: true })], W.prototype, "visibleArea", null), W = G2 = r([a3("esri.views.2d.ViewState")], W);
var L5 = W;

// node_modules/@arcgis/core/views/2d/PaddedViewState.js
var l11;
var m13;
var g11 = l11 = class extends g2 {
  constructor() {
    super(...arguments), this.left = 0, this.top = 0, this.right = 0, this.bottom = 0;
  }
  clone() {
    return new l11({ left: this.left, top: this.top, right: this.right, bottom: this.bottom });
  }
};
r([m()], g11.prototype, "left", void 0), r([m()], g11.prototype, "top", void 0), r([m()], g11.prototype, "right", void 0), r([m()], g11.prototype, "bottom", void 0), g11 = l11 = r([a3("esri.views.2d.PaddedViewState.Padding")], g11);
var w6 = m13 = class extends L5 {
  constructor(...t30) {
    super(...t30), this.paddedViewState = new L5(), this._updateContent = (() => {
      const t31 = n11();
      return () => {
        const e28 = this._get("size"), i25 = this._get("padding");
        if (!e28 || !i25) return;
        const o29 = this.paddedViewState;
        o7(t31, i25.left + i25.right, i25.top + i25.bottom), e7(t31, e28, t31), r9(o29.size, t31);
        const s31 = o29.viewpoint;
        s31 && (this.viewpoint = s31);
      };
    })(), this.addHandles(d3(() => [this.size, this.padding], () => this._updateContent(), C)), this.padding = new g11(), this.size = [0, 0];
  }
  set padding(t30) {
    this._set("padding", t30 || new g11());
  }
  set viewpoint(t30) {
    if (t30) {
      this.paddedViewState.viewpoint = t30;
      let e28 = t30;
      const i25 = this._get("padding");
      i25 && (e28 = gt(t30.clone(), t30, this._get("size"), i25));
      const { targetGeometry: o29, rotation: s31, scale: r33 } = e28, { x: p31, y: d18, spatialReference: a27 } = o29, n33 = this._viewpoint2D;
      n33.center[0] = p31, n33.center[1] = d18, n33.rotation = s31, n33.scale = r33, n33.spatialReference = a27, this._update();
    }
  }
  clone() {
    return new m13({ padding: this.padding.clone(), size: this.size.slice(), viewpoint: this.paddedViewState.viewpoint.clone(), pixelRatio: this.pixelRatio });
  }
};
r([m()], w6.prototype, "paddedViewState", void 0), r([m({ type: g11 })], w6.prototype, "padding", null), r([m()], w6.prototype, "viewpoint", null), w6 = m13 = r([a3("esri.views.2d.PaddedViewState")], w6);
var f9 = w6;

// node_modules/@arcgis/core/views/2d/FrameTask.js
var h11 = class {
  constructor(a27) {
    this.view = a27, this._stationaryHandle = null, this._frameTaskHandle = null, this._updateParameters = null, this._updateRequested = false, this._scheduler = I2(), this._schedulerHandle = p3(() => this._scheduler.updating, () => this.requestFrame()), this.stationary = true, this.prepare = () => {
      this._updateParameters && (this._updateParameters.state = this.view.state, this._updateParameters.stationary = this.view.stationary, this._updateParameters.pixelRatio = window.devicePixelRatio, this._updateParameters.renderingOptions = this.view.renderingOptions, this._updateParameters.targetState.copy(this.view.state), null == this.view.animation?.target || S(this.view.animation.target) || (this._updateParameters.targetState.viewpoint = this.view.animation.target));
    }, this.update = (e28) => {
      if (this._updateRequested = false, this.view?.destroyed) return;
      const { allLayerViews: t30, graphicsView: a28, labelManager: s31, state: { id: i25 } } = this.view;
      t30?.forEach(this._updateLayerView, this), null != s31 && (s31.lastUpdateId !== i25 && (s31.viewChange(), s31.lastUpdateId = i25), s31.updateRequested && s31.processUpdate(this._updateParameters)), null != a28 && (a28.lastUpdateId !== i25 && (a28.viewChange(), a28.lastUpdateId = i25), a28.updateRequested && a28.processUpdate(this._updateParameters)), this.view.graphicsTileStore?.setViewState(this._updateParameters.state), this.view.animation ? this._scheduler.state = I.ANIMATING : this.view.interacting ? this._scheduler.state = I.INTERACTING : this._scheduler.state = I.IDLE;
      this._scheduler.frame(e28) || this._updateRequested || this._scheduler.state !== I.IDLE || this._frameTaskHandle?.pause();
    };
  }
  destroy() {
    this.stop(), this._schedulerHandle.remove(), this._scheduler.destroy();
  }
  get scheduler() {
    return this._scheduler;
  }
  start() {
    if (this._frameTaskHandle) return;
    const e28 = this.view;
    this.stationary = e28.stationary, this._updateParameters = { state: e28.state, targetState: new f9(), pixelRatio: window.devicePixelRatio, stationary: this.stationary, renderingOptions: e28.renderingOptions }, this._stationaryHandle = d3(() => e28.stationary, (e29) => {
      this.stationary = e29, this.requestFrame();
    }), this._frameTaskHandle = F(this), this.requestUpdate();
  }
  stop() {
    this._frameTaskHandle && (this._updateRequested = false, this._stationaryHandle?.remove(), this._frameTaskHandle.remove(), this._updateParameters = this._stationaryHandle = this._frameTaskHandle = null, this.stationary = true);
  }
  requestUpdate() {
    this._updateRequested || (this._updateRequested = true, this.requestFrame());
  }
  requestFrame() {
    this._frameTaskHandle && this._frameTaskHandle.resume();
  }
  _updateLayerView(e28) {
    if (!e28.attached) return void this.requestUpdate();
    const t30 = this.view.state, a27 = e28.lastUpdateId;
    null != a27 && (this.stationary || e28.moving) || (e28.moving = true), a27 !== t30.id && e28.viewChange(), this.stationary && e28.moving && (e28.moving = false, e28.moveEnd()), e28.lastUpdateId = t30.id, e28.updateRequested && e28.processUpdate(this._updateParameters), "layerViews" in e28 && e28.layerViews?.forEach(this._updateLayerView, this);
  }
};

// node_modules/@arcgis/core/views/ViewAnimation.js
var p17 = class extends p2 {
  constructor(t30) {
    super(t30), this.state = "running", this.target = null, this._resolver = null;
  }
  initialize() {
    this._resolver = L(), this.addResolvingPromise(this._resolver.promise);
  }
  get done() {
    return "finished" === this.state || "stopped" === this.state;
  }
  stop() {
    "stopped" !== this.state && "finished" !== this.state && (this._set("state", "stopped"), this._resolver?.reject(new s("ViewAnimation stopped")));
  }
  finish() {
    "stopped" !== this.state && "finished" !== this.state && (this._set("state", "finished"), this._resolver?.resolve());
  }
  update(t30, s31) {
    s31 || (s31 = S(t30) ? "waiting-for-target" : "running"), this._set("target", t30), this._set("state", s31);
  }
};
r([m({ readOnly: true })], p17.prototype, "done", null), r([m({ readOnly: true, type: String })], p17.prototype, "state", void 0), r([m()], p17.prototype, "target", void 0), p17 = r([a3("esri.views.ViewAnimation")], p17), function(t30) {
  t30.State = { RUNNING: "running", STOPPED: "stopped", FINISHED: "finished", WAITING_FOR_TARGET: "waiting-for-target" };
}(p17 || (p17 = {}));
var a10 = p17;

// node_modules/@arcgis/core/views/2d/GoToManager.js
var h12 = class extends g2 {
  constructor(t30) {
    super(t30), this._gotoTask = null;
  }
  destroy() {
    this._gotoTask = null;
  }
  goTo(t30, e28) {
    return __async(this, null, function* () {
      if (!t30) return void n.getLogger(this).error("#goTo()", "target cannot be null or undefined");
      const i25 = new a10();
      this.view.animation = i25, yield w(() => this.view.ready, e28);
      const s31 = __spreadProps(__spreadValues({}, e28), { animate: e28?.animate ?? !o8(), animationMode: e28?.animationMode ?? "auto" }), { extent: a27, spatialReference: c29, size: m24, viewpoint: h21, constraints: g16, padding: w10, allLayerViews: d18 } = this.view, u17 = Y(t30, { extent: a27, spatialReference: c29, size: m24, viewpoint: h21, constraints: g16, padding: w10, allLayerViews: d18, pickClosestTarget: e28?.pickClosestTarget ?? true });
      return i25?.update(u17), this._gotoTask = {}, s31.animate ? this._gotoAnimated(u17, s31) : this._gotoImmediate(u17, s31);
    });
  }
  _gotoImmediate(t30, o29) {
    const e28 = this._gotoTask, r33 = this.view.animation, a27 = t30.then((t31) => {
      if (s4(o29), e28 !== this._gotoTask) throw new s("view:goto-interrupted", "Goto was interrupted");
      this.view.viewpoint = r33.target = t31, r33.finish();
    });
    return this._cancellableGoTo(e28, r33, a27, o29);
  }
  _gotoAnimated(t30, o29) {
    const e28 = this._gotoTask, r33 = this.view.animation;
    if (!r33) return Promise.resolve();
    const a27 = t30.then((t31) => {
      if (s4(o29), e28 !== this._gotoTask) throw new s("view:goto-interrupted", "Goto was interrupted");
      return r33.update(t31), this.view.animationManager.animate(r33, this.view.viewpoint, o29), r33.when().then(() => {
      }, () => {
      });
    });
    return this._cancellableGoTo(e28, r33, a27, o29);
  }
  _cancellableGoTo(t30, o29, e28, i25) {
    const r33 = () => t30 === this._gotoTask;
    return h2(e28, i25).finally(() => {
      r33() && (o29.done || o29.stop());
    });
  }
};
r([m({ constructOnly: true })], h12.prototype, "view", void 0), h12 = r([a3("esri.views.2d.GoToManager")], h12);

// node_modules/@arcgis/core/geometry/support/near.js
function r17(r33, l20) {
  const { spatialReference: s31 } = l20, a27 = [l20.x, l20.y];
  let c29, m24, x3, f17;
  const p31 = [0, 0], u17 = i15(r33);
  for (let e28 = 0; e28 < u17.length; e28++) {
    const t30 = u17[e28];
    for (let r34 = 0; r34 < t30.length - 1; r34++) {
      s8(p31, a27, t30, r34);
      const i25 = m5(a27, p31);
      (null == c29 || i25 < c29) && (c29 = i25, m24 = [...p31], x3 = e28, f17 = r34);
    }
  }
  if (null == c29 || !m24 || null == x3 || null == f17) throw new s("nearest-coordinate:failed", "Failed to find the nearest coordinate");
  const [y11, d18] = m24;
  return { coordinate: new j2({ x: y11, y: d18, spatialReference: s31 }), distance: c29 };
}
function i15(e28) {
  switch (e28.type) {
    case "extent":
      return [[[e28.xmin, e28.ymin], [e28.xmin, e28.ymax], [e28.xmax, e28.ymax], [e28.xmax, e28.ymin], [e28.xmin, e28.ymin]]];
    case "polygon":
      return e28.rings;
    case "polyline":
      return e28.paths;
  }
}

// node_modules/@arcgis/core/views/2d/constraints/GeometryConstraint.js
var l12;
var p18 = l12 = class extends n9.NumericIdentifiableMixin(g2) {
  constructor(e28) {
    super(e28), this.geometry = null, this.spatialReference = null;
  }
  get normalizedGeometry() {
    if (null == this.geometry || !this.spatialReference) return null;
    if (!this.spatialReference.equals(this.geometry.spatialReference)) try {
      return O2(this.geometry, this.spatialReference);
    } catch (e28) {
      return n.getLogger(this).error("#constraints.geometry", "could not project the geometry to the view's spatial reference", { geometry: this.geometry, spatialReference: this.spatialReference, error: e28 }), null;
    }
    return this.geometry;
  }
  constrain(e28, r33) {
    if (null == this.normalizedGeometry) return e28;
    const t30 = e28.targetGeometry;
    if ("extent" === this.normalizedGeometry.type ? t5(this.normalizedGeometry, t30) : f(this.normalizedGeometry, t30)) return e28;
    const { coordinate: o29 } = r17(this.normalizedGeometry, t30);
    return o29 ? (e28.targetGeometry = o29, e28) : e28;
  }
  clone() {
    return new l12({ geometry: this.geometry?.clone(), spatialReference: this.spatialReference?.clone() });
  }
};
r([m({ constructOnly: true })], p18.prototype, "geometry", void 0), r([m({ readOnly: true })], p18.prototype, "normalizedGeometry", null), r([m({ constructOnly: true })], p18.prototype, "spatialReference", void 0), p18 = l12 = r([a3("esri.views.2d.constraints.GeometryConstraint")], p18);

// node_modules/@arcgis/core/views/2d/constraints/RotationConstraint.js
var i16;
var n22 = i16 = class extends n9.NumericIdentifiableMixin(g2) {
  constructor() {
    super(...arguments), this.enabled = true, this.rotationEnabled = true;
  }
  constrain(o29, t30) {
    return this.enabled && t30 ? (this.rotationEnabled || (o29.rotation = t30.rotation), o29) : o29;
  }
  clone() {
    return new i16({ enabled: this.enabled, rotationEnabled: this.rotationEnabled });
  }
};
r([m()], n22.prototype, "enabled", void 0), r([m()], n22.prototype, "rotationEnabled", void 0), n22 = i16 = r([a3("esri.views.2d.constraints.RotationConstraint")], n22);
var a11 = n22;

// node_modules/@arcgis/core/views/2d/constraints/ZoomConstraint.js
var a12;
var c14 = a12 = class extends n9.NumericIdentifiableMixin(g2) {
  constructor(e28) {
    super(e28), this._lodByScale = {}, this._scales = [], this.effectiveLODs = null, this.effectiveMinZoom = -1, this.effectiveMaxZoom = -1, this.effectiveMinScale = 0, this.effectiveMaxScale = 0, this.lods = null, this.minZoom = -1, this.maxZoom = -1, this.minScale = 0, this.maxScale = 0, this.snapToZoom = true;
  }
  initialize() {
    let e28, { lods: t30, minScale: o29, maxScale: s31, minZoom: i25, maxZoom: a27 } = this, c29 = -1, l20 = -1, r33 = false, n33 = false;
    if (0 !== o29 && 0 !== s31 && o29 < s31 && ([o29, s31] = [s31, o29]), !t30?.length) return this._set("effectiveMinScale", o29), void this._set("effectiveMaxScale", s31);
    t30 = t30.map((e29) => e29.clone()), t30.sort((e29, t31) => t31.scale - e29.scale), t30.forEach((e29, t31) => e29.level = t31);
    for (const f17 of t30) !r33 && o29 > 0 && o29 >= f17.scale && (c29 = f17.level, r33 = true), !n33 && s31 > 0 && s31 >= f17.scale && (l20 = e28 ? e28.level : -1, n33 = true), e28 = f17;
    -1 === i25 && (i25 = 0 === o29 ? 0 : c29), -1 === a27 && (a27 = 0 === s31 ? t30.length - 1 : l20), i25 = Math.max(i25, 0), i25 = Math.min(i25, t30.length - 1), a27 = Math.max(a27, 0), a27 = Math.min(a27, t30.length - 1), i25 > a27 && ([i25, a27] = [a27, i25]), o29 = t30[i25].scale, s31 = t30[a27].scale, t30.splice(0, i25), t30.splice(a27 - i25 + 1, t30.length), t30.forEach((e29, t31) => {
      this._lodByScale[e29.scale] = e29, this._scales[t31] = e29.scale;
    }), this._set("effectiveLODs", t30), this._set("effectiveMinZoom", i25), this._set("effectiveMaxZoom", a27), this._set("effectiveMinScale", o29), this._set("effectiveMaxScale", s31);
  }
  constrain(e28, t30) {
    if (t30 && e28.scale === t30.scale) return e28;
    const o29 = this.effectiveMinScale, s31 = this.effectiveMaxScale, i25 = e28.targetGeometry, a27 = t30 && t30.targetGeometry, c29 = 0 !== s31 && e28.scale < s31, l20 = 0 !== o29 && e28.scale > o29;
    if (c29 || l20) {
      const c30 = l20 ? o29 : s31;
      if (t30 && a27) {
        const o30 = (c30 - t30.scale) / (e28.scale - t30.scale);
        i25.x = a27.x + (i25.x - a27.x) * o30, i25.y = a27.y + (i25.y - a27.y) * o30;
      }
      e28.scale = c30;
    }
    return this.snapToZoom && this.effectiveLODs && (e28.scale = this._getClosestScale(e28.scale)), e28;
  }
  fit(e28) {
    if (!this.effectiveLODs || !this.snapToZoom) return this.constrain(e28, null);
    const t30 = this.scaleToZoom(e28.scale), o29 = Math.abs(t30 - Math.floor(t30));
    return e28.scale = this.zoomToScale(o29 > 0.99 ? Math.round(t30) : Math.floor(t30)), e28;
  }
  zoomToScale(e28) {
    if (!this.effectiveLODs) return 0;
    e28 -= this.effectiveMinZoom, e28 = Math.max(0, e28);
    const t30 = this._scales;
    if (e28 <= 0) return t30[0];
    if (e28 >= t30.length) return t30[t30.length - 1];
    const o29 = Math.floor(e28), s31 = Math.ceil(e28);
    return t30[o29] + (e28 - o29) * (t30[s31] - t30[o29]);
  }
  scaleToZoom(e28) {
    if (!this.effectiveLODs) return -1;
    const t30 = this._scales;
    let o29, s31;
    if (e28 >= t30[0]) return this.effectiveMinZoom;
    if (e28 <= t30[t30.length - 1]) return this.effectiveMaxZoom;
    for (let i25 = 0; i25 < t30.length - 1; i25++) {
      if (o29 = t30[i25], s31 = t30[i25 + 1], s31 === e28) {
        return i25 + this.effectiveMinZoom + 1;
      }
      if (o29 > e28 && s31 < e28) {
        return i25 + this.effectiveMinZoom + 1 - (e28 - s31) / (o29 - s31);
      }
    }
    return -1;
  }
  snapToClosestScale(e28) {
    if (!this.effectiveLODs) return e28;
    const t30 = this.scaleToZoom(e28);
    return this.zoomToScale(Math.round(t30));
  }
  snapToNextScale(e28, t30 = 0.5) {
    if (!this.effectiveLODs) return e28 * t30;
    const o29 = Math.round(this.scaleToZoom(e28));
    return this.zoomToScale(o29 + 1);
  }
  snapToPreviousScale(e28, t30 = 2) {
    if (!this.effectiveLODs) return e28 * t30;
    const o29 = Math.round(this.scaleToZoom(e28));
    return this.zoomToScale(o29 - 1);
  }
  clone() {
    return new a12({ lods: this.lods, minZoom: this.minZoom, maxZoom: this.maxZoom, minScale: this.minScale, maxScale: this.maxScale });
  }
  _getClosestScale(e28) {
    return this._lodByScale[e28] || (e28 = this._scales.reduce((t30, o29) => Math.abs(o29 - e28) <= Math.abs(t30 - e28) ? o29 : t30, this._scales[0])), this._lodByScale[e28].scale;
  }
};
r([m({ readOnly: true })], c14.prototype, "effectiveLODs", void 0), r([m({ readOnly: true })], c14.prototype, "effectiveMinZoom", void 0), r([m({ readOnly: true })], c14.prototype, "effectiveMaxZoom", void 0), r([m({ readOnly: true })], c14.prototype, "effectiveMinScale", void 0), r([m({ readOnly: true })], c14.prototype, "effectiveMaxScale", void 0), r([m()], c14.prototype, "lods", void 0), r([m()], c14.prototype, "minZoom", void 0), r([m()], c14.prototype, "maxZoom", void 0), r([m()], c14.prototype, "minScale", void 0), r([m()], c14.prototype, "maxScale", void 0), r([m()], c14.prototype, "snapToZoom", void 0), c14 = a12 = r([a3("esri.views.2d.constraints.ZoomConstraint")], c14);
var l13 = c14;

// node_modules/@arcgis/core/views/2d/MapViewConstraints.js
var p19 = { base: null, key: "type", typeMap: { extent: w2, polygon: j3 } };
var y6 = class extends g2 {
  constructor(o29) {
    super(o29), this.lods = null, this.minScale = 0, this.maxScale = 0, this.minZoom = -1, this.maxZoom = -1, this.rotationEnabled = true, this.snapToZoom = true, this.customConstraints = new V();
  }
  destroy() {
    this.view = null;
  }
  get effectiveLODs() {
    return this._zoom.effectiveLODs;
  }
  get effectiveMinScale() {
    return this._zoom.effectiveMinScale;
  }
  get effectiveMaxScale() {
    return this._zoom.effectiveMaxScale;
  }
  get effectiveMinZoom() {
    return this._zoom.effectiveMinZoom;
  }
  get effectiveMaxZoom() {
    return this._zoom.effectiveMaxZoom;
  }
  set geometry(o29) {
    o29 ? this._set("geometry", o29) : this._set("geometry", null);
  }
  get version() {
    return `${this._zoom?.uid}/${this._rotation?.uid}/${this._geometry?.uid}`;
  }
  get _geometry() {
    const o29 = this._get("_geometry");
    return o29 && this.geometry === o29.geometry && this.view?.constraintsInfo.spatialReference === o29.spatialReference ? o29 : new p18({ geometry: this.geometry, spatialReference: this.view?.constraintsInfo.spatialReference });
  }
  get _rotation() {
    return new a11({ rotationEnabled: this.rotationEnabled });
  }
  get _zoom() {
    const o29 = this._get("_zoom"), t30 = this.lods || this.view?.constraintsInfo.lods, e28 = this.minZoom, r33 = this.maxZoom, s31 = this.minScale, n33 = this.maxScale, i25 = this.snapToZoom;
    return o29 && o29.lods === t30 && o29.minZoom === e28 && o29.maxZoom === r33 && o29.minScale === s31 && o29.maxScale === n33 && o29.snapToZoom === i25 ? o29 : new l13({ lods: t30, minZoom: e28, maxZoom: r33, minScale: s31, maxScale: n33, snapToZoom: i25 });
  }
  canZoomInTo(o29) {
    const t30 = this.effectiveMaxScale;
    return 0 === t30 || o29 >= t30;
  }
  canZoomOutTo(o29) {
    const t30 = this.effectiveMinScale;
    return 0 === t30 || o29 <= t30;
  }
  constrain(o29, t30) {
    return this._zoom.constrain(o29, t30), this._rotation.constrain(o29, t30), this._geometry.constrain(o29, t30), this.customConstraints.forEach((e28) => e28.constrain(o29, t30)), o29;
  }
  constrainByGeometry(o29) {
    return this._geometry.constrain(o29), this.customConstraints.forEach((t30) => t30.applyPanConstraint?.(o29)), o29;
  }
  fit(o29) {
    return this._zoom.fit(o29);
  }
  zoomToScale(o29) {
    return this._zoom.zoomToScale(o29);
  }
  scaleToZoom(o29) {
    return this._zoom.scaleToZoom(o29);
  }
  snapScale(o29) {
    return this._zoom.snapToClosestScale(o29);
  }
  snapToNextScale(o29) {
    return this._zoom.snapToNextScale(o29);
  }
  snapToPreviousScale(o29) {
    return this._zoom.snapToPreviousScale(o29);
  }
};
r([m({ readOnly: true })], y6.prototype, "effectiveLODs", null), r([m({ readOnly: true })], y6.prototype, "effectiveMinScale", null), r([m({ readOnly: true })], y6.prototype, "effectiveMaxScale", null), r([m({ readOnly: true })], y6.prototype, "effectiveMinZoom", null), r([m({ readOnly: true })], y6.prototype, "effectiveMaxZoom", null), r([m({ types: p19, value: null })], y6.prototype, "geometry", null), r([m({ type: [p5] })], y6.prototype, "lods", void 0), r([m()], y6.prototype, "minScale", void 0), r([m()], y6.prototype, "maxScale", void 0), r([m()], y6.prototype, "minZoom", void 0), r([m()], y6.prototype, "maxZoom", void 0), r([m()], y6.prototype, "rotationEnabled", void 0), r([m()], y6.prototype, "snapToZoom", void 0), r([m({ type: V })], y6.prototype, "customConstraints", void 0), r([m()], y6.prototype, "view", void 0), r([m({ readOnly: true })], y6.prototype, "version", null), r([m({ type: p18, readOnly: true })], y6.prototype, "_geometry", null), r([m({ type: a11 })], y6.prototype, "_rotation", null), r([m({ readOnly: true, type: l13 })], y6.prototype, "_zoom", null), y6 = r([a3("esri.views.2d.MapViewConstraints")], y6);
var f10 = y6;

// node_modules/@arcgis/core/views/2d/ViewStateManager.js
var z2 = class extends g2 {
  constructor(t30) {
    super(t30), this.constraints = null, this.ready = false, this.resizeAlign = "center", this.addHandles([d3(() => this.constraints?.version, (t31) => {
      this.constraints && t31 && this.ready && (this.state.viewpoint = this.constraints.fit(this.state.paddedViewState.viewpoint));
    }, C)]);
  }
  get center() {
    if (!this.ready) return this._get("center");
    const { center: t30, spatialReference: e28 } = this.state.paddedViewState;
    return this.state.commitProperty("id"), new j2({ x: t30[0], y: t30[1], spatialReference: e28 });
  }
  set center(t30) {
    if (null == t30) return;
    if (!this.ready) return void this._set("center", t30);
    let e28;
    try {
      e28 = this._project(t30, this.state.spatialReference);
    } catch (o29) {
      return void n.getLogger(this).error(new s("mapview:invalid-center", "could not project the value in the view's spatial reference", { input: t30, error: o29 }));
    }
    const i25 = this.viewpoint;
    xt(i25, i25, e28), this.viewpoint = i25;
  }
  get extent() {
    return this.ready ? (this.state.commitProperty("id"), this.state.paddedViewState.extent.clone()) : this._get("extent");
  }
  set extent(t30) {
    if (null == t30) return;
    if (!t30.width || !t30.height) return void n.getLogger(this).error(new s("mapview:invalid-extent", "invalid extent size"));
    if (!this.ready) return this._set("extent", t30), this._set("center", void 0), this._set("viewpoint", void 0), this._set("scale", void 0), void this._set("zoom", void 0);
    let e28;
    try {
      e28 = this._project(t30, this.state.spatialReference);
    } catch (o29) {
      return void n.getLogger(this).error(new s("mapview:invalid-extent", "could not project the value in the view's spatial reference", { error: o29 }));
    }
    const i25 = this.viewpoint;
    tt(i25, i25, e28, this.state.size, { constraints: this.constraints }), this.viewpoint = i25;
  }
  get padding() {
    return this.ready ? this.state.padding : this._get("padding");
  }
  set padding(t30) {
    this.ready ? (this.state.padding = t30, this._set("padding", this.state.padding)) : this._set("padding", t30);
  }
  get resolution() {
    return this.ready ? (this.state.commitProperty("id"), this.state.resolution) : 0;
  }
  get rotation() {
    return this.ready ? (this.state.commitProperty("id"), this.state.rotation) : this._get("rotation");
  }
  set rotation(t30) {
    if (isNaN(t30)) return;
    if (!this.ready) return void this._set("rotation", t30);
    const e28 = this.viewpoint;
    wt(e28, e28, t30), this.viewpoint = e28;
  }
  get scale() {
    return this.ready ? (this.state.commitProperty("id"), this.state.scale) : this._get("scale");
  }
  set scale(t30) {
    if (!t30 || isNaN(t30)) return;
    if (!this.ready) {
      this._set("scale", t30), this._set("zoom", void 0);
      const e29 = this._get("extent");
      return void (e29 && (this._set("extent", void 0), this._set("center", e29.center)));
    }
    const e28 = this.viewpoint;
    jt(e28, e28, t30), this.viewpoint = e28;
  }
  get viewpoint() {
    if (!this.ready) return this._get("viewpoint");
    return this.state.paddedViewState.viewpoint.clone();
  }
  set viewpoint(t30) {
    if (null == t30) return;
    if (!this.ready) return this._set("viewpoint", t30), this._set("extent", void 0), this._set("center", void 0), this._set("zoom", void 0), void this._set("scale", void 0);
    let i25, o29;
    try {
      i25 = this._project(t30, this.state.spatialReference), !t30.scale || isNaN(t30.scale) ? o29 = new s("mapview:invalid-viewpoint", `invalid scale value of ${t30.scale}`) : null == t30.targetGeometry && (o29 = new s("mapview:invalid-viewpoint", "geometry not defined"));
    } catch (a27) {
      o29 = new s("mapview:invalid-viewpoint", "could not project the value in the view's spatial reference", { error: a27 });
    }
    if (o29) return void n.getLogger(this).error(o29);
    this._scaleBeforeChangingSpatialReference = null;
    const n33 = new m3({ targetGeometry: new j2(), scale: 0, rotation: 0 });
    Z(n33, i25), this.constraints?.constrain(n33, this.state.paddedViewState.viewpoint), this.state.viewpoint = n33, this._set("viewpoint", n33);
  }
  get visibleArea() {
    return this.ready ? this.state.visibleArea : null;
  }
  get zoom() {
    return this.ready ? this.constraints?.scaleToZoom(this.scale) ?? -1 : this._get("zoom");
  }
  set zoom(t30) {
    if (!(t30 >= 0)) return;
    if (!this.ready) {
      this._set("zoom", t30), this._set("scale", void 0);
      const e29 = this._get("extent");
      return void (e29 && (this._set("extent", void 0), this._set("center", e29.center)));
    }
    const e28 = this.constraints?.zoomToScale(t30) ?? 0;
    if (!e28) return void this._set("zoom", -1);
    const i25 = this.viewpoint;
    jt(i25, i25, e28), this.viewpoint = i25, this._set("zoom", this.constraints?.scaleToZoom(this.scale) ?? -1);
  }
  getUserStartupOptions(t30) {
    if (!t30[0] && !t30[1]) return { center: void 0, rotation: void 0, scale: void 0 };
    const { padding: e28, constraints: i25 } = this, s31 = this._get("center"), r33 = this._get("extent"), o29 = this._get("scale"), n33 = this._get("rotation"), a27 = this._get("viewpoint"), c29 = this._get("zoom"), p31 = null != c29 && null != i25 && i25.zoomToScale(c29) || void 0;
    let h21, l20, d18;
    const v10 = a27?.rotation, u17 = a27?.targetGeometry;
    "extent" === u17?.type ? h21 = u17 : "point" === u17?.type && (l20 = u17, d18 = a27?.scale);
    const m24 = r33 ?? h21;
    return { center: s31 ?? l20 ?? m24?.center, rotation: n33 ?? v10, scale: (o29 ?? p31 ?? d18 ?? (m24 && H(m24, [t30[0] - e28.left - e28.right, t30[1] - e28.top - e28.bottom]))) || void 0 };
  }
  startup(t30, e28, i25, s31) {
    const o29 = t30.targetGeometry;
    try {
      this._project(t30, i25);
    } catch (n33) {
      n.getLogger(this).warn(new s2("mapview:startup-projection-error", "projection of initial viewpoint to the view's spatial reference, defaulting to the initial viewpoint.", { center: o29.toJSON(), spatialReference: i25, error: n33 })), t30.targetGeometry = s31 || new j2({ x: 0, y: 0, spatialReference: i25 });
    }
    this.constraints?.fit(t30), this._set("state", new f9({ padding: this.padding, size: e28, viewpoint: t30 })), this._set("ready", true);
  }
  teardown() {
    this._set("ready", false);
    const { center: [t30, e28], spatialReference: i25, rotation: s31, scale: r33 } = this.state.paddedViewState, o29 = new j2({ x: t30, y: e28, spatialReference: i25 });
    this._set("viewpoint", null), this._set("extent", null), this._set("center", o29), this._set("zoom", -1), this._set("rotation", s31), this._set("scale", r33), this._set("state", null);
  }
  changeSpatialReference(t30) {
    const i25 = this.state.paddedViewState.clone();
    if (null == this._scaleBeforeChangingSpatialReference) this._scaleBeforeChangingSpatialReference = i25.scale;
    else {
      const t31 = i25.viewpoint.clone();
      t31.scale = this._scaleBeforeChangingSpatialReference, i25.viewpoint = t31;
    }
    const s31 = i25.clone(), [o29, n33] = i25.center;
    let a27 = null;
    try {
      a27 = this._project(new j2({ x: o29, y: n33, spatialReference: i25.spatialReference }), t30);
    } catch (h21) {
      r6() || n.getLogger(this).warn(new s2("mapview:spatial-reference-change", "could not project the view's center to the new spatial reference", { center: a27?.toJSON(), spatialReference: t30, error: h21 }));
    }
    a27 || (a27 = new j2({ x: 0, y: 0, spatialReference: t30 }));
    const p31 = xt(new m3({ targetGeometry: new j2(), scale: 0, rotation: 0 }), i25.viewpoint, a27);
    s31.viewpoint = p31;
    try {
      const e28 = 20, r33 = [i25.size[0] / 2, i25.size[1] / 2], o30 = [r33[0] + e28, r33[1]], n34 = i25.toMap([0, 0], o30), { x: a28, y: c29 } = this._project(new j2({ x: n34[0], y: n34[1], spatialReference: i25.spatialReference }), t30);
      n34[0] = a28, n34[1] = c29, s31.toScreen(n34, n34);
      const h21 = pt(r33, n34, o30), l20 = Math.hypot(n34[0] - r33[0], n34[1] - r33[1]) / e28;
      !Number.isFinite(l20) || Math.abs(l20) > 4 ? (p31.rotation = 0, p31.targetGeometry = new j2({ x: 0, y: 0, spatialReference: t30 })) : (p31.scale *= l20, p31.scale > has("mapview-srswitch-adjust-rotation-scale-threshold") ? p31.rotation = 0 : p31.rotation += Number.isFinite(h21) ? h21 : 0);
    } catch {
    }
    this._get("constraints")?.constrain(p31, void 0), this._get("state").viewpoint = p31;
  }
  resize(t30, e28) {
    if (!this.ready) return;
    const i25 = this.state;
    let s31 = this.state.paddedViewState.viewpoint;
    const r33 = this.state.paddedViewState.size.slice();
    i25.size = [t30, e28], ht(s31, s31, r33, this.state.paddedViewState.size, this.resizeAlign), s31 = this.constraints?.constrain(s31, void 0) ?? s31, this.state.viewpoint = s31;
  }
  toMap(t30) {
    if (!this.ready) return null;
    const e28 = [0, 0], [i25, s31] = this.state.toMap(e28, [t30.x, t30.y]), r33 = this.state.spatialReference;
    return new j2({ x: i25, y: s31, spatialReference: r33 });
  }
  toScreen(t30, e28) {
    if (!this.ready) return null;
    const i25 = this._project(t30, this.state.spatialReference), s31 = [i25.x, i25.y];
    return false === e28?.pickClosestTarget || this.state.paddedViewState.wrapMapCoordinate(s31, s31), this.state.toScreen(s31, s31), c4(s31[0], s31[1]);
  }
  _project(t30, e28) {
    const i25 = t30?.targetGeometry || t30;
    if (!e28) return t30;
    if (!i25) return null;
    if (e28.imageCoordinateSystem || i25.spatialReference?.imageCoordinateSystem) return t30;
    if (s7(e28, i25.spatialReference)) return t30;
    const r33 = O2(i25, e28);
    if (!r33) throw new s("mapview:projection-not-possible", "projecting input geometry to target spatial reference returned a null value", { geometry: i25, spatialReference: e28 });
    return V2(t30) ? (t30.targetGeometry = r33, t30) : r33;
  }
};
function V2(t30) {
  return "esri.Viewpoint" === t30?.declaredClass;
}
r([m({ type: j2 })], z2.prototype, "center", null), r([m()], z2.prototype, "constraints", void 0), r([m({ type: w2 })], z2.prototype, "extent", null), r([m({ value: { top: 0, right: 0, bottom: 0, left: 0 }, cast: (t30) => __spreadValues({ top: 0, right: 0, bottom: 0, left: 0 }, t30) })], z2.prototype, "padding", null), r([m()], z2.prototype, "ready", void 0), r([m()], z2.prototype, "resizeAlign", void 0), r([m({ readOnly: true })], z2.prototype, "resolution", null), r([m({ type: Number })], z2.prototype, "rotation", null), r([m({ type: Number })], z2.prototype, "scale", null), r([m({ readOnly: true })], z2.prototype, "state", void 0), r([m({ type: m3 })], z2.prototype, "viewpoint", null), r([m({ readOnly: true })], z2.prototype, "visibleArea", null), r([m()], z2.prototype, "zoom", null), z2 = r([a3("esri.views.2d.ViewStateManager")], z2);

// node_modules/@arcgis/core/views/input/handlers/support.js
function r18(r33, e28) {
  switch (e28) {
    case "primary":
      return "touch" === r33.pointerType || 0 === r33.button;
    case "secondary":
      return "touch" !== r33.pointerType && 2 === r33.button;
    case "tertiary":
      return "touch" !== r33.pointerType && 1 === r33.button;
  }
}
function e14(e28, t30) {
  return t30.some((t31) => r18(e28, t31));
}
function n23(r33, { dragPrimary: e28, dragSecondary: t30, dragTertiary: n33 }) {
  return [{ key: "primary", value: e28 }, { key: "secondary", value: t30 }, { key: "tertiary", value: n33 }].filter((e29) => e29.value === r33).map((r34) => r34.key);
}

// node_modules/@arcgis/core/views/2d/input/handlers/DoubleClickZoom.js
var a13 = class extends t9 {
  constructor(t30, i25) {
    super(true), this._view = t30, this.registerIncoming("double-click", i25, (t31) => this._handleDoubleClick(t31, i25));
  }
  _handleDoubleClick(t30, a27) {
    r18(t30.data, "primary") && (t30.stopPropagation(), a27 ? this._view.mapViewNavigation.zoomOut([t30.data.x, t30.data.y]) : this._view.mapViewNavigation.zoomIn([t30.data.x, t30.data.y]));
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/DoubleTapDragZoom.js
var e15 = class extends t9 {
  constructor(t30, e28, a27) {
    super(true), this.view = t30, this.pointerType = e28, this.registerIncoming("double-tap-drag", a27, (t31) => this._handleDoubleTapDrag(t31));
  }
  _handleDoubleTapDrag(t30) {
    const { data: e28 } = t30, { pointerType: a27 } = e28;
    if (a27 !== this.pointerType) return;
    t30.stopPropagation();
    const { action: s31, delta: i25 } = e28, { view: r33 } = this, { mapViewNavigation: n33 } = r33;
    switch (s31) {
      case "begin": {
        const { scale: t31 } = r33;
        this._startScale = t31, this._currentScale = t31, this._previousDelta = i25, n33.begin();
        break;
      }
      case "update": {
        if (this._previousDelta.y === i25.y) return;
        this._previousDelta = i25;
        const t31 = 1.015 ** i25.y, e29 = this._startScale * t31, a28 = e29 / this._currentScale;
        n33.setViewpointImmediate(a28), this._currentScale = e29;
        break;
      }
      case "end": {
        const { constraints: t31 } = r33, { effectiveLODs: e29, snapToZoom: a28 } = t31;
        if (!a28 || !e29) return void n33.end();
        const s32 = t31.snapScale(this._currentScale), o29 = (i25.y > 0 ? Math.max(s32, t31.snapToPreviousScale(this._startScale)) : Math.min(s32, t31.snapToNextScale(this._startScale))) / this._currentScale;
        n33.zoom(o29).then(() => {
          n33.end();
        });
        break;
      }
    }
  }
};

// node_modules/@arcgis/core/views/input/DragEventSeparator.js
var t17 = class {
  constructor(t30) {
    this._callbacks = t30, this._currentCount = 0, this._callbacks.condition || (this._callbacks.condition = () => true);
  }
  handle(t30) {
    const s31 = t30.data, i25 = s31.pointers.size;
    switch (s31.action) {
      case "start":
        this._currentCount = i25, this._emitStart(t30);
        break;
      case "added":
        this._emitEnd(this._previousEvent), this._currentCount = i25, this._emitStart(t30);
        break;
      case "update":
        this._emitUpdate(t30);
        break;
      case "removed":
        this._startEvent && this._emitEnd(this._previousEvent), this._currentCount = i25, this._emitStart(t30);
        break;
      case "end":
        this._emitEnd(t30), this._currentCount = 0;
    }
    this._previousEvent = t30;
  }
  _emitStart(t30) {
    this._startEvent = t30, this._callbacks.condition?.(this._currentCount, t30) && this._callbacks.start(this._currentCount, t30, this._startEvent);
  }
  _emitUpdate(t30) {
    this._callbacks.condition?.(this._currentCount, t30) && this._callbacks.update(this._currentCount, t30, this._startEvent);
  }
  _emitEnd(t30) {
    this._callbacks.condition?.(this._currentCount, t30) && this._callbacks.end(this._currentCount, t30, this._startEvent), this._startEvent = null;
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/DragPan.js
var n24 = class extends t9 {
  constructor(t30, i25, a27) {
    super(true), this.view = t30, this.pointerActions = i25, this.registerIncoming("drag", a27, (t31) => this._handleDrag(t31)), this.registerIncoming("pointer-down", () => this.stopMomentumNavigation());
  }
  onInstall(i25) {
    super.onInstall(i25), this._dragEventSeparator = new t17({ start: (t30, i26) => {
      this.view.mapViewNavigation.pan.begin(this.view, i26.data), i26.stopPropagation();
    }, update: (t30, i26) => {
      this.view.mapViewNavigation.pan.update(this.view, i26.data), i26.stopPropagation();
    }, end: (t30, i26) => {
      this.view.mapViewNavigation.pan.end(this.view, i26.data), i26.stopPropagation();
    }, condition: (t30, i26) => 1 === t30 && e14(i26.data, this.pointerActions) });
  }
  _handleDrag(t30) {
    const i25 = this.view.mapViewNavigation;
    i25.pinch.zoomMomentum || i25.pinch.rotateMomentum ? this.stopMomentumNavigation() : this._dragEventSeparator.handle(t30);
  }
  stopMomentumNavigation() {
    this.view.mapViewNavigation.pan.stopMomentumNavigation();
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/DragRotate.js
var o15 = class extends t9 {
  constructor(a27, o29, r33) {
    super(true), this._view = a27, this.pointerActions = o29;
    const e28 = this._view.mapViewNavigation;
    this._dragEventSeparator = new t17({ start: (t30, a28) => {
      e28.rotate.begin(this._view, a28.data), a28.stopPropagation();
    }, update: (t30, a28) => {
      e28.rotate.update(this._view, a28.data), a28.stopPropagation();
    }, end: (t30, a28) => {
      e28.rotate.end(), a28.stopPropagation();
    }, condition: (t30, a28) => 1 === t30 && e14(a28.data, this.pointerActions) }), this.registerIncoming("drag", r33, (t30) => this._dragEventSeparator.handle(t30));
  }
};

// node_modules/@arcgis/core/views/navigation/gamepadAndKeyboardUtils.js
function n25(t30) {
  let n33 = t30 * t30;
  return t30 < 0 && (n33 *= -1), n33;
}
function a14(t30) {
  return t30.translation[0] = 0, t30.translation[1] = 0, t30.translation[2] = 0, t30.heading = 0, t30.tilt = 0, t30;
}
function i17(a27, i25, o29) {
  const s31 = o29, e28 = a27.state, r33 = a27.device, l20 = "forward-down" === i25.tiltDirection ? 1 : -1, c29 = 1;
  return "standard" === r33.deviceType ? (s31.translation[0] = n25(e28.axes[0]), s31.translation[1] = n25(e28.axes[1]), s31.translation[2] = n25(e28.buttons[7]) - n25(e28.buttons[6]), s31.heading = n25(e28.axes[2]), s31.tilt = n25(e28.axes[3])) : "spacemouse" === r33.deviceType && (s31.translation[0] = 1.2 * n25(e28.axes[0]), s31.translation[1] = 1.2 * n25(e28.axes[1]), s31.translation[2] = 2 * -n25(e28.axes[2]), s31.heading = 1.2 * n25(e28.axes[5]), s31.tilt = 1.2 * n25(e28.axes[3])), s31.tilt *= l20, g5(s31.translation, s31.translation, c29), s31;
}
function s19(t30) {
  return 0 === t30.translation[0] && 0 === t30.translation[1] && 0 === t30.translation[2] && 0 === t30.heading && 0 === t30.tilt && 0 === t30.zoom;
}

// node_modules/@arcgis/core/views/2d/input/handlers/GamepadNavigation.js
var m14 = class extends t9 {
  constructor(e28) {
    super(true), this._view = e28, this._frameTask = null, this._watchHandles = new r3(), this._currentDevice = null, this._transformation = { translation: [0, 0, 0], heading: 0, tilt: 0, zoom: 0 }, this._handle = this.registerIncoming("gamepad", (t30) => this._handleGamePadEvent(t30)), this._handle.pause();
  }
  onInstall(t30) {
    super.onInstall(t30), this._watchHandles.add([d3(() => this._view.navigation.gamepad?.enabled, (t31) => {
      t31 ? (this._handle.resume(), this._frameTask || (this._frameTask = F({ update: (t32) => this._frameUpdate(t32.deltaTime) }))) : (this._handle.pause(), this._frameTask && (this._frameTask.remove(), this._frameTask = null));
    }, P)]);
  }
  onUninstall() {
    this._watchHandles.removeAll(), this._frameTask && (this._frameTask.remove(), this._frameTask = null), super.onUninstall();
  }
  _handleGamePadEvent(t30) {
    const e28 = this._view.navigation.gamepad.device;
    e28 && t30.data.device !== e28 || this._currentDevice && this._currentDevice !== t30.data.device || ("end" === t30.data.action ? (this._currentDevice = null, a14(this._transformation)) : (this._currentDevice = t30.data.device, i17(t30.data, this._view.navigation.gamepad, this._transformation)), this._frameTask?.resume());
  }
  _frameUpdate(t30) {
    const e28 = this._transformation;
    if (s19(e28)) return void this._frameTask?.pause();
    const i25 = this._view.viewpoint.clone(), a27 = this._view.navigation.gamepad.velocityFactor, r33 = _7 * a27 * t30;
    kt(i25, i25, [e28.translation[0] * r33, -e28.translation[1] * r33]);
    const o29 = 1 + e28.translation[2] * c15 * t30, h21 = this._view.constraints.rotationEnabled ? -e28.heading * d8 * t30 : 0, m24 = this._view.size, v10 = [m24[0] / 2, m24[1]];
    Gt(i25, i25, o29, h21, v10, m24);
    const p31 = this._view.constraints.constrain(i25, this._view.viewpoint);
    this._view.viewpoint = p31;
  }
};
var d8 = 0.06;
var _7 = 0.7;
var c15 = 6e-4;

// node_modules/@arcgis/core/views/input/VisibilityChange.js
function i18(i25) {
  const t30 = () => i25("visible" === document.visibilityState);
  return document.addEventListener("visibilitychange", t30), e(() => document.removeEventListener("visibilitychange", t30));
}

// node_modules/@arcgis/core/views/2d/input/handlers/KeyPan.js
var e16 = class extends t9 {
  constructor(i25, e28, s31) {
    super(true), this.view = i25, this.keys = e28, this._isSticky = false, this._pressedKeys = /* @__PURE__ */ new Set(), this._timeout = void 0, this._currentDirection = void 0, this._stickyKeyDuration = 200, this._handleKey = (i26) => {
      const t30 = this._keyMap[i26.data.key];
      if (i26.modifiers.has("Meta") || i26.modifiers.has("Control")) return void this._stopMovement();
      if (null == t30) return;
      i26.stopPropagation(), i26.preventDefault();
      const e29 = "key-down" === i26.type;
      if (this._pressedKeys[e29 ? "add" : "delete"](t30), e29) {
        if (this._direction === t30) return;
        this._direction = t30, this._isSticky = false, this._setTimeout(() => {
          this._isSticky && this._handlePopKey();
        });
      } else {
        const i27 = void 0 === this._timeout, t31 = this._pressedKeys.size > 0;
        i27 || t31 ? this._handlePopKey() : this._isSticky = true;
      }
    }, this._handlePopKey = () => {
      this._direction = Array.from(this._pressedKeys).pop(), null == this._direction && this._stopMovement();
    }, this._stopMovement = () => {
      this._isSticky = false, this._direction = void 0, this._pressedKeys.clear(), this._setTimeout(void 0);
    }, this._keyMap = { [e28.left]: "left", [e28.right]: "right", [e28.up]: "up", [e28.down]: "down" }, this.registerIncoming("key-down", s31, this._handleKey), this.registerIncoming("key-up", s31, this._handleKey), this.registerIncoming("blur", s31, this._stopMovement), this._visibilityHandle = i18((i26) => i26 ? null : this._stopMovement());
  }
  onUninstall() {
    this._stopMovement(), this._visibilityHandle?.remove();
  }
  get _direction() {
    return this._currentDirection;
  }
  set _direction(i25) {
    const t30 = null != this._currentDirection;
    if (null != i25) {
      if (t30 || this.view.mapViewNavigation.begin(), this._currentDirection !== i25) switch (i25) {
        case "left":
          this.view.mapViewNavigation.continuousPanLeft();
          break;
        case "right":
          this.view.mapViewNavigation.continuousPanRight();
          break;
        case "up":
          this.view.mapViewNavigation.continuousPanUp();
          break;
        case "down":
          this.view.mapViewNavigation.continuousPanDown();
      }
    } else t30 && this.view.mapViewNavigation.stop();
    this._currentDirection = i25;
  }
  _setTimeout(i25) {
    clearTimeout(this._timeout), this._timeout = void 0 === i25 ? void 0 : setTimeout(() => {
      this._timeout = void 0, i25();
    }, this._stickyKeyDuration);
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/KeyRotate.js
var t18 = class extends t9 {
  constructor(e28, t30, s31) {
    super(true), this.view = e28, this.keys = t30, this._keyToDirection = /* @__PURE__ */ new Map(), this._pressed = false, this._addKeysMapping(t30), this.registerIncoming("key-down", s31, (e29) => this._handleKeyDown(e29)), this.registerIncoming("key-up", s31, (e29) => this._handleKeyUp(e29)), this.registerIncoming("blur", s31, () => this._handleStop()), this._visibilityHandle = i18((e29) => e29 ? null : this._handleStop());
  }
  onUninstall() {
    this._visibilityHandle?.remove(), this._handleStop();
  }
  _addKeysMapping(e28) {
    this._addKeyMapping(e28.clockwise, "clockwise"), this._addKeyMapping(e28.counterClockwise, "counterClockwise"), this._addKeyMapping(e28.reset, "reset");
  }
  _addKeyMapping(e28, i25) {
    for (const t30 of e28) this._keyToDirection.set(t30, i25);
  }
  _handleKeyDown(e28) {
    e28.data.repeat || this._handleKey(e28, true);
  }
  _handleKeyUp(e28) {
    this._handleKey(e28, false);
  }
  _handleStop() {
    this._pressed && (this._pressed = false, this.view.mapViewNavigation.stop());
  }
  _handleKey(e28, i25) {
    const t30 = e28.modifiers;
    if (t30.size > 0 && !t30.has("Shift") || !this.view.constraints.rotationEnabled) return;
    const s31 = this._keyToDirection.get(e28.data.key);
    if (this._pressed = null != s31, this._pressed) {
      if (e28.preventDefault(), i25) switch (this.view.mapViewNavigation.begin(), s31) {
        case "clockwise":
          this.view.mapViewNavigation.continuousRotateClockwise();
          break;
        case "counterClockwise":
          this.view.mapViewNavigation.continuousRotateCounterclockwise();
          break;
        case "reset":
          this.view.mapViewNavigation.resetRotation();
      }
      else this._pressed = false, this.view.mapViewNavigation.stop();
      e28.stopPropagation();
    }
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/KeyZoom.js
var t19;
!function(o29) {
  o29[o29.IN = 0] = "IN", o29[o29.OUT = 1] = "OUT";
}(t19 || (t19 = {}));
var e17 = class extends t9 {
  constructor(o29, e28, i25) {
    super(true), this.view = o29, this.keys = e28, this._keysToZoomAction = {}, this.registerIncoming("key-down", i25, (o30) => this._handleKeyDown(o30)), e28.zoomIn.forEach((o30) => this._keysToZoomAction[o30] = t19.IN), e28.zoomOut.forEach((o30) => this._keysToZoomAction[o30] = t19.OUT);
  }
  _handleKeyDown(o29) {
    this._handleKey(o29);
  }
  _handleKey(o29) {
    const e28 = o29.modifiers;
    if (e28.size > 0 && !e28.has("Shift")) return;
    const { key: i25 } = o29.data;
    if (!(i25 in this._keysToZoomAction)) return;
    const n33 = this._keysToZoomAction[i25], { mapViewNavigation: s31 } = this.view;
    let r33 = null;
    switch (n33) {
      case t19.IN:
        r33 = s31.zoomIn();
        break;
      case t19.OUT:
        r33 = s31.zoomOut();
        break;
      default:
        return;
    }
    s31.begin(), r33.then(() => s31.end()), o29.stopPropagation();
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/MouseWheelZoom.js
var t20 = 0.6;
var o16 = class extends t9 {
  constructor(e28, t30) {
    super(true), this._view = e28, this._canZoom = true, this.registerIncoming("mouse-wheel", t30, (e29) => this._handleMouseWheel(e29));
  }
  _handleMouseWheel(e28) {
    if ("zoom" !== this._view.navigation.actionMap.mouseWheel) return;
    if (e28.preventDefault(), e28.stopPropagation(), !this._canZoom) return;
    const o29 = this._view.mapViewNavigation, { x: i25, y: n33, deltaY: s31 } = e28.data, a27 = 1 / t20 ** (1 / 60 * s31), h21 = o29.zoom(a27, [i25, n33]);
    h21 && (this._canZoom = false, h21.catch(() => {
    }).then(() => {
      this._canZoom = true, o29.end();
    }));
  }
};

// node_modules/@arcgis/core/views/2d/input/handlers/PinchAction.js
var a15 = class extends t9 {
  constructor(i25) {
    super(true), this.view = i25, this.registerIncoming("drag", (t30) => this._handleDrag(t30)), this.registerIncoming("pointer-down", () => this._stopMomentumNavigation());
    const a27 = this.view.mapViewNavigation;
    this._dragEventSeparator = new t17({ start: (t30, i26) => {
      a27.pinch.begin(this.view, i26.data), i26.stopPropagation();
    }, update: (t30, i26) => {
      a27.pinch.update(this.view, i26.data), i26.stopPropagation();
    }, end: (t30, i26) => {
      a27.pinch.end(this.view), i26.stopPropagation();
    }, condition: (t30) => t30 >= 2 });
  }
  _handleDrag(t30) {
    this._dragEventSeparator.handle(t30);
  }
  _stopMomentumNavigation() {
    this.view.mapViewNavigation.pinch.stopMomentumNavigation();
  }
};

// node_modules/@arcgis/core/views/input/gamepad/GamepadState.js
function t21(t30) {
  const n33 = t30.native;
  return n33 ? { buttons: n33.buttons.map((t31) => t31.pressed ? t31.value || 1 : 0), axes: n33.axes.map((n34) => s20(n34, t30.axisThreshold)) } : { buttons: [], axes: [] };
}
function n26(t30, n33) {
  if (t30.axes.length !== n33.axes.length) return false;
  if (t30.buttons.length !== n33.buttons.length) return false;
  for (let e28 = 0; e28 < t30.axes.length; e28++) if (t30.axes[e28] !== n33.axes[e28]) return false;
  for (let e28 = 0; e28 < t30.buttons.length; e28++) if (t30.buttons[e28] !== n33.buttons[e28]) return false;
  return true;
}
function e18(t30) {
  for (let n33 = 0; n33 < t30.axes.length; n33++) if (0 !== t30.axes[n33]) return false;
  for (let n33 = 0; n33 < t30.buttons.length; n33++) if (0 !== t30.buttons[n33]) return false;
  return true;
}
function s20(t30, n33) {
  const e28 = Math.abs(t30);
  return e28 < n33 ? 0 : Math.sign(t30) * (e28 - n33) / (1 - n33);
}

// node_modules/@arcgis/core/views/input/gamepad/GamepadSource.js
var a16 = class {
  constructor(e28, t30) {
    this._element = e28, this._input = t30, this._hasEventListeners = false, this._onConnectGamepad = (e29) => {
      this._connectGamepad(e29.gamepad);
    }, this._onDisconnectGamepad = (e29) => {
      const t31 = e29.gamepad, n34 = t31.index, i26 = this._inputDevices[n34];
      i26 && (this._emitGamepadEvent(t31, t21(i26), false), this._inputDevices.splice(n34, 1), this._latestUpdate.splice(n34, 1), this._input.gamepad.devices.remove(i26), this.ensurePollingState());
    }, this._frameTask = null, this._latestUpdate = new Array(), this._inputDevices = new Array(), this._callback = null;
    const n33 = "getGamepads" in window.navigator, i25 = window.isSecureContext;
    this.supported = n33 && i25, this.supported && (d9((e29) => this._connectGamepad(e29)), window.addEventListener("gamepadconnected", this._onConnectGamepad), window.addEventListener("gamepaddisconnected", this._onDisconnectGamepad), this.ensurePollingState());
  }
  destroy() {
    this.hasEventListeners = false, this.supported && (window.removeEventListener("gamepadconnected", this._onConnectGamepad), window.removeEventListener("gamepaddisconnected", this._onDisconnectGamepad));
  }
  set hasEventListeners(e28) {
    this._hasEventListeners !== e28 && (this._hasEventListeners = e28, this.ensurePollingState());
  }
  get _eventsEnabled() {
    return this.supported && this._inputDevices.length > 0 && this._hasEventListeners;
  }
  set onEvent(e28) {
    this._callback = e28;
  }
  _connectGamepad(e28) {
    const s31 = new o14(e28);
    "unknown" !== s31.deviceType && (this._inputDevices[e28.index] = s31, this._input.gamepad.devices.add(s31)), this.ensurePollingState();
  }
  ensurePollingState() {
    this._eventsEnabled ? this._startPolling() : this._stopPolling();
  }
  _startPolling() {
    null == this._frameTask && (this._frameTask = F({ update: () => this._readGamepadState() }));
  }
  _stopPolling() {
    null != this._frameTask && (this._frameTask.remove(), this._frameTask = null, this._latestUpdate = new Array());
  }
  _readGamepadState() {
    const e28 = document.hasFocus(), t30 = this._element.contains(document.activeElement), a27 = "document" === this._input.gamepad.enabledFocusMode && !e28 || "view" === this._input.gamepad.enabledFocusMode && !t30;
    d9((e29) => {
      const t31 = this._inputDevices[e29.index];
      if (!t31) return;
      const o29 = this._latestUpdate[e29.index], d18 = t21(t31), c29 = a27 || e18(d18);
      if (o29) {
        if (o29.timestamp === e29.timestamp) return;
        if (!o29.active && c29) return;
        if (n26(o29.state, d18)) return;
      }
      this._emitGamepadEvent(e29, d18, !c29);
    });
  }
  _emitGamepadEvent(e28, t30, s31) {
    const n33 = this._latestUpdate[e28.index], i25 = n33 && n33.active;
    if (!i25 && !s31) return;
    const a27 = !i25 && s31 ? "start" : i25 && s31 ? "update" : "end";
    this._latestUpdate[e28.index] = { timestamp: e28.timestamp, state: t30, active: s31 }, this._callback && this._callback({ device: this._inputDevices[e28.index], state: t30, action: a27 });
  }
};
function o17(e28) {
  if (!e28) return false;
  if (!e28.connected) return false;
  for (let t30 = 0; t30 < e28.axes.length; t30++) if (isNaN(e28.axes[t30])) return false;
  return true;
}
function d9(e28) {
  for (const t30 of navigator.getGamepads()) o17(t30) && e28(t30);
}

// node_modules/@arcgis/core/views/input/BrowserEventSource.js
var i19 = has("edge");
var a17 = has("chrome");
var o18 = has("ff");
var s21 = has("safari");
var r19 = "esri-view-surface";
var h13 = { touchNone: `${r19}--touch-none`, touchPan: `${r19}--touch-pan` };
var l14 = class _l {
  constructor(e28, n33) {
    this._active = {}, this._callback = () => {
    }, this._activePointerCaptures = /* @__PURE__ */ new Set(), this._keyDownState = /* @__PURE__ */ new Set(), this._eventId = 1, this._browserTouchPanningEnabled = false, this._element = e28, e28.getAttribute("tabindex") || e28.setAttribute("tabindex", "0"), this._eventHandlers = { "key-down": this._handleKey, "key-up": this._handleKey, "pointer-down": this._handlePointer, "pointer-move": this._handlePointerPreventDefault, "pointer-up": this._handlePointerPreventDefault, "pointer-enter": this._handlePointer, "pointer-leave": this._handlePointer, "pointer-cancel": this._handlePointer, "mouse-wheel": this._handleMouseWheel, "pointer-capture-lost": this._handlePointerCaptureLost }, this._updateTouchAction(), this._element.addEventListener("keydown", this._preventAltKeyDefault), this._gamepadSource = new a16(e28, n33), this._gamepadSource.onEvent = (e29) => this._callback("gamepad", e29);
  }
  destroy() {
    this._callback = () => {
    }, this.activeEvents = null, this._activePointerCaptures.forEach((e28) => this._releasePointerCaptureSafe(e28)), this._activePointerCaptures.clear(), this._gamepadSource = u(this._gamepadSource), this._removeTouchAction(), this._element.removeEventListener("keydown", this._preventAltKeyDefault);
  }
  get browserTouchPanningEnabled() {
    return this._browserTouchPanningEnabled;
  }
  set browserTouchPanningEnabled(e28) {
    this._browserTouchPanningEnabled = e28, this._updateTouchAction(), this._updateTouchEventHandling();
  }
  set onEventReceived(e28) {
    this._callback = e28;
  }
  set activeEvents(e28) {
    for (const t30 in this._active) if (!e28 || !e28.has(t30)) {
      const e29 = this._active[t30];
      this._element.removeEventListener(c16[t30], e29), delete this._active[t30];
    }
    e28 && e28.forEach((e29) => {
      if (!this._active[e29] && c16[e29]) {
        const t30 = (this._eventHandlers[e29] || this._handleDefault).bind(this, e29);
        this._element.addEventListener(c16[e29], t30), this._active[e29] = t30;
      }
    }), this._gamepadSource && (this._gamepadSource.hasEventListeners = e28?.has("gamepad") ?? false);
  }
  setPointerCapture(e28, t30) {
    t30 ? this._setPointerCaptureSafe(e28.pointerId) : (this._releasePointerCaptureSafe(e28.pointerId), this._activePointerCaptures.delete(e28.pointerId));
  }
  _updateTouchAction() {
    this._element.classList.remove(this._browserTouchPanningEnabled ? h13.touchNone : h13.touchPan), this._element.classList.add(this._browserTouchPanningEnabled ? h13.touchPan : h13.touchNone);
  }
  _updateTouchEventHandling() {
    this._browserTouchPanningEnabled ? this._element.addEventListener("touchmove", this._preventMultiTouchPanning) : this._element.removeEventListener("touchmove", this._preventMultiTouchPanning);
  }
  _removeTouchAction() {
    this._element.classList.remove(h13.touchNone), this._element.classList.remove(h13.touchPan), this._element.removeEventListener("touchmove", this._preventMultiTouchPanning);
  }
  _setPointerCaptureSafe(e28) {
    try {
      this._element.setPointerCapture(e28), this._activePointerCaptures.add(e28);
    } catch {
    }
  }
  _releasePointerCaptureSafe(e28) {
    try {
      if (this._element.hasPointerCapture && !this._element.hasPointerCapture(e28)) return;
      this._element.releasePointerCapture(e28);
    } catch (t30) {
    }
  }
  _updateNormalizedPointerLikeEvent(e28, t30) {
    const i25 = i6(this._element, e28);
    return _l.test.disableSubpixelCoordinates && (i25.x = Math.round(i25.x), i25.y = Math.round(i25.y)), t30.x = i25.x, t30.y = i25.y, t30;
  }
  _handleKey(e28, t30) {
    const { key: n33 } = t30;
    n33 && "key-up" === e28 && this._keyDownState.delete(n33);
    const i25 = { native: t30, key: n33, repeat: !!n33 && this._keyDownState.has(n33) };
    n33 && "key-down" === e28 && this._keyDownState.add(i25.key), this._callback(e28, i25);
  }
  _handlePointer(e28, t30) {
    const n33 = this._updateNormalizedPointerLikeEvent(t30, { native: t30, x: 0, y: 0, pointerType: t30.pointerType, button: t30.button, buttons: t30.buttons, eventId: this._eventId++ });
    this._callback(e28, n33);
  }
  _handlePointerPreventDefault(e28, t30) {
    const n33 = this._updateNormalizedPointerLikeEvent(t30, { native: t30, x: 0, y: 0, pointerType: t30.pointerType, button: t30.button, buttons: t30.buttons, eventId: this._eventId++ });
    t30.preventDefault(), this._callback(e28, n33);
  }
  _getDeltaFromTrackpadOrMouseWheel(e28) {
    return e28.shiftKey && has("mac") && 0 === e28.deltaY ? e28.deltaX : e28.deltaY;
  }
  _handleMouseWheel(e28, t30) {
    let n33 = this._getDeltaFromTrackpadOrMouseWheel(t30);
    switch (t30.deltaMode) {
      case 0:
        i19 && (n33 = n33 / document.documentElement.clientHeight * 600);
        break;
      case 1:
        n33 *= 30;
        break;
      case 2:
        n33 *= 900;
    }
    i19 ? n33 *= 0.7 : a17 || s21 ? n33 *= 0.6 : o18 && (n33 *= 1.375);
    const r33 = 100, h21 = Math.abs(n33);
    if (h21 > r33) {
      n33 = n33 / h21 * 200 / (1 + Math.exp(-0.02 * (h21 - r33)));
    }
    const l20 = this._updateNormalizedPointerLikeEvent(t30, { native: t30, x: 0, y: 0, deltaY: n33 });
    this._callback(e28, l20);
  }
  _handlePointerCaptureLost(e28, t30) {
    this._activePointerCaptures.delete(t30.pointerId), this._handleDefault(e28, t30);
  }
  _handleDefault(e28, t30) {
    const n33 = { native: t30 };
    t30.preventDefault(), this._callback(e28, n33);
  }
  _preventAltKeyDefault(e28) {
    "Alt" === e28.key && e28.preventDefault();
  }
  _preventMultiTouchPanning(e28) {
    e28.touches.length > 1 && e28.preventDefault();
  }
};
l14.test = { disableSubpixelCoordinates: false };
var c16 = { "key-down": "keydown", "key-up": "keyup", "pointer-down": "pointerdown", "pointer-up": "pointerup", "pointer-move": "pointermove", "mouse-wheel": "wheel", "pointer-capture-got": "gotpointercapture", "pointer-capture-lost": "lostpointercapture", "context-menu": "contextmenu", "pointer-enter": "pointerenter", "pointer-leave": "pointerleave", "pointer-cancel": "pointercancel", focus: "focus", blur: "blur" };

// node_modules/@arcgis/core/views/input/handlers/PreventContextMenu.js
var e19 = class extends t9 {
  constructor() {
    super(true), this.registerIncoming("context-menu", (t30) => t30.data.native.preventDefault());
  }
};

// node_modules/@arcgis/core/views/input/recognizers/support.js
var t22 = { maximumClickDelay: 300, movementUntilMouseDrag: 1.5, movementUntilPenDrag: 6, movementUntilTouchDrag: 6, holdDelay: 500, maximumDoubleClickDelay: 250, maximumDoubleClickDistance: 10, maximumDoubleTouchDelay: 350, maximumDoubleTouchDistance: 35 };
function n27(e28, t30) {
  return Math.abs(t30.x - e28.x) + Math.abs(t30.y - e28.y);
}
function r20(e28, t30) {
  const n33 = t30.x - e28.x, r33 = t30.y - e28.y;
  return Math.sqrt(n33 * n33 + r33 * r33);
}
function o19(t30, n33) {
  if (n33 ? (n33.radius = 0, n33.center.x = 0, n33.center.y = 0) : n33 = { radius: 0, center: c4() }, 0 === t30.length) return n33;
  if (1 === t30.length) return n33.center.x = t30[0].x, n33.center.y = t30[0].y, n33;
  if (2 === t30.length) {
    const [e28, r34] = t30, [o30, u18] = [r34.x - e28.x, r34.y - e28.y];
    return n33.radius = Math.sqrt(o30 * o30 + u18 * u18) / 2, n33.center.x = (e28.x + r34.x) / 2, n33.center.y = (e28.y + r34.y) / 2, n33;
  }
  let r33 = 0, o29 = 0;
  for (let e28 = 0; e28 < t30.length; e28++) r33 += t30[e28].x, o29 += t30[e28].y;
  r33 /= t30.length, o29 /= t30.length;
  const u17 = t30.map((e28) => e28.x - r33), c29 = t30.map((e28) => e28.y - o29);
  let i25 = 0, a27 = 0, l20 = 0, m24 = 0, s31 = 0, x3 = 0, y11 = 0;
  for (let e28 = 0; e28 < u17.length; e28++) {
    const t31 = u17[e28], n34 = c29[e28], r34 = t31 * t31, o30 = n34 * n34;
    i25 += r34, a27 += o30, l20 += t31 * n34, m24 += r34 * t31, s31 += o30 * n34, x3 += t31 * o30, y11 += n34 * r34;
  }
  const h21 = 0.5 * (m24 + x3), D4 = 0.5 * (s31 + y11), g16 = i25 * a27 - l20 * l20, f17 = (h21 * a27 - D4 * l20) / g16, b9 = (i25 * D4 - l20 * h21) / g16, p31 = c4(f17 + r33, b9 + o29);
  return { radius: Math.sqrt(f17 * f17 + b9 * b9 + (i25 + a27) / t30.length), center: p31 };
}
function u9(e28) {
  const { native: t30 } = e28, { pointerId: n33, button: r33, pointerType: o29 } = t30;
  return "mouse" === o29 ? `${n33}:${r33}` : `${o29}`;
}

// node_modules/@arcgis/core/views/input/recognizers/DoubleTapDrag.js
var u10 = class extends t9 {
  constructor(e28 = t22.maximumDoubleClickDelay, a27 = t22.maximumDoubleClickDistance, n33 = t22.maximumDoubleTouchDelay, s31 = t22.maximumDoubleTouchDistance, u17 = o3) {
    super(false), this._maximumDoubleClickDelay = e28, this._maximumDoubleClickDistance = a27, this._maximumDoubleTouchDelay = n33, this._maximumDoubleTouchDistance = s31, this._clock = u17, this._doubleTapDragReady = false, this._doubleTapDragActive = false, this._dragStartCenter = c4(0, 0), this._pointerState = /* @__PURE__ */ new Map(), this._doubleTapDrag = this.registerOutgoing("double-tap-drag"), this._dragEventSeparator = new t17({ start: (t30, e29) => this._dragStart(t30, e29), update: (t30, e29) => this._dragUpdate(e29), end: (t30, e29) => this._dragEnd(e29) }), this.registerIncoming("drag", (t30) => this._dragEventSeparator.handle(t30)), this.registerIncoming("pointer-down", (t30) => this._handlePointerDown(t30)), this.registerIncoming("pointer-up", () => this._handlePointerUp());
  }
  onUninstall() {
    this._pointerState.forEach((t30) => {
      t30.doubleTapTimeout = l(t30.doubleTapTimeout);
    });
  }
  get hasPendingInputs() {
    for (const t30 of this._pointerState.values()) if (null != t30.doubleTapTimeout) return true;
    return false;
  }
  _clearPointerDown(t30) {
    const i25 = this._pointerState.get(t30);
    i25 && (i25.doubleTapTimeout = l(i25.doubleTapTimeout), this._pointerState.delete(t30), this.refreshHasPendingInputs());
  }
  _dragStart(t30, e28) {
    if (!this._doubleTapDragReady || 1 !== t30) return;
    this._doubleTapDragReady = false, this._doubleTapDragActive = true;
    const { data: o29, modifiers: a27 } = e28, { center: r33 } = o29;
    this._dragStartCenter = r33;
    const n33 = d10("begin", c4(0, 0), o29);
    this._doubleTapDrag.emit(n33, void 0, a27), e28.stopPropagation();
  }
  _dragUpdate(t30) {
    if (!this._doubleTapDragActive) return;
    const { data: e28, modifiers: o29 } = t30, { center: a27 } = e28, r33 = d10("update", c4(a27.x - this._dragStartCenter.x, a27.y - this._dragStartCenter.y), e28);
    this._doubleTapDrag.emit(r33, void 0, o29), t30.stopPropagation();
  }
  _dragEnd(t30) {
    if (!this._doubleTapDragActive) return;
    const { data: e28, modifiers: o29 } = t30, { center: a27 } = e28, r33 = d10("end", c4(a27.x - this._dragStartCenter.x, a27.y - this._dragStartCenter.y), e28);
    this._doubleTapDrag.emit(r33, void 0, o29), this._doubleTapDragActive = false, t30.stopPropagation();
  }
  _handlePointerDown(t30) {
    const { data: e28 } = t30, i25 = u9(e28), o29 = this._pointerState.get(i25), { pointerType: a27 } = e28.native;
    if (o29) {
      const r33 = "touch" === a27 ? this._maximumDoubleTouchDistance : this._maximumDoubleClickDistance;
      this._clearPointerDown(i25), n27(o29.event.data, e28) > r33 ? this._storePointerDown(t30) : this._doubleTapDragReady = true;
    } else this._storePointerDown(t30);
  }
  _handlePointerUp() {
    this._doubleTapDragReady = false;
  }
  _storePointerDown(t30) {
    const { data: e28 } = t30, { pointerType: i25 } = e28.native, o29 = u9(e28), a27 = "touch" === i25 ? this._maximumDoubleTouchDelay : this._maximumDoubleClickDelay, r33 = this._clock.setTimeout(() => this._clearPointerDown(o29), a27);
    this._pointerState.set(o29, { event: t30, doubleTapTimeout: r33 }), this.refreshHasPendingInputs();
  }
};
function d10(t30, e28, i25) {
  const { button: o29, buttons: a27, pointer: r33, pointers: n33, pointerType: s31, timestamp: u17 } = i25;
  return { action: t30, delta: e28, button: o29, buttons: a27, pointer: r33, pointers: n33, pointerType: s31, timestamp: u17 };
}

// node_modules/@arcgis/core/views/input/recognizers/Drag.js
var s22 = class extends t9 {
  constructor(t30) {
    super(false), this._navigationTouch = t30, this._startStateModifiers = /* @__PURE__ */ new Set(), this._activePointerMap = /* @__PURE__ */ new Map(), this._isDragging = false, this._isCurrentDragSuppressed = false, this._drag = this.registerOutgoing("drag"), this.registerIncoming("pointer-drag", this._handlePointerDrag.bind(this)), this.registerIncoming("pointer-up", this._handlePointerUpAndPointerLost.bind(this)), this.registerIncoming("pointer-capture-lost", this._handlePointerUpAndPointerLost.bind(this)), this.registerIncoming("pointer-cancel", this._handlePointerUpAndPointerLost.bind(this));
  }
  _createPayload(t30, e28, i25, n33) {
    return { action: t30, pointerType: this._pointerType, button: this._mouseButton, buttons: e28.buttons, timestamp: n33, pointers: o20(this._activePointerMap), pointer: e28, angle: i25.angle, radius: i25.radius, center: i25.center };
  }
  _addPointer(t30) {
    const e28 = t30.native.pointerId, i25 = a18(this._activePointerMap).angle, n33 = { event: t30, initialAngle: 0, lastAngle: 0 };
    this._activePointerMap.set(e28, n33);
    const s31 = h14(n33, r21(this._activePointerMap));
    n33.initialAngle = s31, n33.lastAngle = s31, this._updatePointerAngles(i25);
  }
  _updatePointer(t30) {
    if (t30 && null == t30.x && null == t30.y) return;
    const e28 = t30.native.pointerId, i25 = this._activePointerMap.get(e28);
    i25 ? i25.event = t30 : this._addPointer(t30);
  }
  _removePointer(t30) {
    const e28 = a18(this._activePointerMap).angle;
    this._activePointerMap.delete(t30), this._updatePointerAngles(e28);
  }
  _updatePointerAngles(t30) {
    const e28 = a18(this._activePointerMap);
    this._activePointerMap.forEach((i25) => {
      i25.initialAngle = h14(i25, e28) - t30, i25.lastAngle = h14(i25, e28) - t30;
    });
  }
  _emitEvent(t30, e28, i25) {
    const n33 = a18(this._activePointerMap);
    this._drag.emit(this._createPayload(t30, e28, n33, i25), void 0, this._startStateModifiers);
  }
  _handlePointerUpAndPointerLost(t30) {
    const i25 = t30.data.native.pointerId, n33 = n3(t30.timestamp);
    this._activePointerMap.get(i25) && (1 === this._activePointerMap.size ? (this._updatePointer(t30.data), !this._isCurrentDragSuppressed && this._emitEvent("end", t30.data, n33), this._isDragging = false, this._isCurrentDragSuppressed = false, this._removePointer(i25)) : (this._removePointer(i25), this._emitEvent("removed", t30.data, n3(t30.timestamp))));
  }
  _handlePointerDrag(t30) {
    const i25 = t30.data, n33 = i25.currentEvent, s31 = n3(t30.timestamp);
    switch (i25.action) {
      case "start":
      case "update":
        this._isDragging ? this._activePointerMap.has(n33.native.pointerId) ? (this._updatePointer(n33), !this._isCurrentDragSuppressed && this._emitEvent("update", n33, s31)) : (this._addPointer(n33), this._emitEvent("added", n33, s31), this._isCurrentDragSuppressed = this._isSuppressed) : (this._updatePointer(n33), this._pointerType = t30.data.startEvent.pointerType, this._mouseButton = t30.data.startEvent.button, this._startStateModifiers = t30.modifiers, this._isDragging = true, this._isCurrentDragSuppressed = this._isSuppressed, !this._isCurrentDragSuppressed && this._emitEvent("start", n33, s31));
    }
  }
  get _isSuppressed() {
    return !!this._navigationTouch && !this._navigationTouch.browserTouchPanEnabled && "touch" === this._pointerType && 1 === this._activePointerMap.size;
  }
};
function r21(e28) {
  const i25 = [];
  return e28.forEach((e29) => {
    i25.push(c4(e29.event.x, e29.event.y));
  }), o19(i25);
}
function a18(t30) {
  const e28 = r21(t30);
  let i25 = 0;
  return t30.forEach((t31) => {
    let n33 = h14(t31, e28), s31 = n33 - t31.lastAngle;
    for (; s31 > Math.PI; ) s31 -= 2 * Math.PI;
    for (; s31 < -Math.PI; ) s31 += 2 * Math.PI;
    n33 = t31.lastAngle + s31, t31.lastAngle = n33;
    const r33 = n33 - t31.initialAngle;
    i25 += r33;
  }), i25 /= t30.size || 1, { angle: i25, radius: e28.radius, center: e28.center };
}
function o20(t30) {
  const e28 = /* @__PURE__ */ new Map();
  return t30.forEach((t31, i25) => e28.set(i25, t31.event)), e28;
}
function h14(t30, e28) {
  const i25 = t30.event, n33 = i25.x - e28.center.x, s31 = i25.y - e28.center.y;
  return Math.atan2(s31, n33);
}
var p20;
!function(t30) {
  t30[t30.Left = 0] = "Left", t30[t30.Middle = 1] = "Middle", t30[t30.Right = 2] = "Right", t30[t30.Back = 3] = "Back", t30[t30.Forward = 4] = "Forward", t30[t30.Undefined = -1] = "Undefined";
}(p20 || (p20 = {}));

// node_modules/@arcgis/core/views/input/recognizers/ImmediateDoubleClick.js
var m15 = class extends t9 {
  constructor(e28 = t22.maximumDoubleClickDelay, o29 = t22.maximumDoubleClickDistance, a27 = t22.maximumDoubleTouchDelay, m24 = t22.maximumDoubleTouchDistance, n33 = o3) {
    super(false), this._maximumDoubleClickDelay = e28, this._maximumDoubleClickDistance = o29, this._maximumDoubleTouchDelay = a27, this._maximumDoubleTouchDistance = m24, this._clock = n33, this._pointerState = /* @__PURE__ */ new Map(), this._immediateDoubleClick = this.registerOutgoing("immediate-double-click"), this.registerIncoming("pointer-down", this._handlePointerDown.bind(this)), this.registerIncoming("pointer-up", this._handlePointerUp.bind(this));
  }
  onUninstall() {
    this._pointerState.forEach((t30) => {
      t30.immediateDoubleClick && t30.immediateDoubleClick.timeoutHandle.remove();
    }), super.onUninstall();
  }
  _handlePointerDown(t30) {
    const e28 = t30.data, i25 = u9(e28);
    if (!this._pointerState.has(i25)) {
      const t31 = { downButton: e28.native.button, x: e28.x, y: e28.y, immediateDoubleClick: null };
      this._pointerState.set(i25, t31), this.startCapturingPointer(e28.native);
    }
  }
  _handlePointerUp(t30) {
    const e28 = t30.data, i25 = u9(e28), m24 = this._pointerState.get(i25);
    if (m24 && m24.downButton === e28.native.button) {
      const i26 = m24.immediateDoubleClick, o29 = "touch" === t30.data.native.pointerType ? this._maximumDoubleTouchDistance : this._maximumDoubleClickDistance;
      i26 ? (i26.timeoutHandle.remove(), n27(i26, t30.data) > o29 ? this._startImmediateDoubleClick(t30, m24) : (this._immediateDoubleClick.emit(t30.data, void 0, i26.modifiers), this._removeState(e28))) : n27(m24, t30.data) > o29 ? this._removeState(e28) : this._startImmediateDoubleClick(t30, m24);
    }
  }
  _startImmediateDoubleClick(t30, e28) {
    const i25 = "touch" === t30.data.native.pointerType ? this._maximumDoubleTouchDelay : this._maximumDoubleClickDelay;
    e28.immediateDoubleClick = { x: t30.data.x, y: t30.data.y, modifiers: t30.modifiers, timeoutHandle: this._clock.setTimeout(() => this._removeState(t30.data), i25) };
  }
  _removeState(t30) {
    const e28 = u9(t30);
    this._pointerState.delete(e28), this.stopCapturingPointer(t30.native), this.refreshHasPendingInputs();
  }
};

// node_modules/@arcgis/core/views/input/recognizers/PointerClickHoldAndDrag.js
var r22 = class extends t9 {
  constructor(e28 = t22.maximumClickDelay, i25 = t22.movementUntilMouseDrag, o29 = t22.movementUntilPenDrag, r33 = t22.movementUntilTouchDrag, s31 = t22.holdDelay, a27 = o3) {
    super(false), this._maximumClickDelay = e28, this._movementUntilMouseDrag = i25, this._movementUntilPenDrag = o29, this._movementUntilTouchDrag = r33, this._holdDelay = s31, this._clock = a27, this._pointerState = /* @__PURE__ */ new Map(), this._pointerDrag = this.registerOutgoing("pointer-drag"), this._immediateClick = this.registerOutgoing("immediate-click"), this._pointerHold = this.registerOutgoing("hold"), this.registerIncoming("pointer-down", (t30) => this._handlePointerDown(t30)), this.registerIncoming("pointer-up", (t30) => this._handlePointerLoss(t30, "pointer-up")), this.registerIncoming("pointer-capture-lost", (t30) => this._handlePointerLoss(t30, "pointer-capture-lost")), this.registerIncoming("pointer-cancel", (t30) => this._handlePointerLoss(t30, "pointer-cancel")), this._moveHandle = this.registerIncoming("pointer-move", (t30) => this._handlePointerMove(t30)), this._moveHandle.pause();
  }
  onUninstall() {
    this._pointerState.forEach((t30) => {
      t30.holdTimeout = l(t30.holdTimeout);
    }), super.onUninstall();
  }
  _handlePointerDown(t30) {
    const e28 = t30.data, i25 = e28.native.pointerId;
    let n33 = null;
    0 === this._pointerState.size && (n33 = this._clock.setTimeout(() => {
      const e29 = this._pointerState.get(i25);
      if (e29) {
        if (!e29.isDragging) {
          const i26 = e29.previousEvent;
          this._pointerHold.emit(i26, void 0, t30.modifiers), e29.holdEmitted = true;
        }
        e29.holdTimeout = null;
      }
    }, this._holdDelay));
    const o29 = { startEvent: e28, previousEvent: e28, startTimestamp: t30.timestamp, isDragging: false, downButton: e28.native.button, holdTimeout: n33, modifiers: /* @__PURE__ */ new Set() };
    this._pointerState.set(i25, o29), this.startCapturingPointer(e28.native), this._moveHandle.resume(), this._pointerState.size > 1 && this._startDragging(t30);
  }
  _handlePointerMove(t30) {
    const e28 = t30.data, i25 = e28.native.pointerId, n33 = this._pointerState.get(i25);
    if (n33) {
      if (n33.isDragging) this._pointerDrag.emit(s23("update", n33, e28), void 0, n33.modifiers);
      else {
        r20(e28, n33.startEvent) > this._getDragThreshold(e28.native.pointerType) && this._startDragging(t30);
      }
      n33.previousEvent = e28;
    }
  }
  _getDragThreshold(t30) {
    switch (t30) {
      case "touch":
        return this._movementUntilTouchDrag;
      case "pen":
        return this._movementUntilPenDrag;
      default:
        return this._movementUntilMouseDrag;
    }
  }
  _startDragging(t30) {
    const e28 = t30.data, i25 = e28.native.pointerId;
    this._pointerState.forEach((n33) => {
      null != n33.holdTimeout && (n33.holdTimeout.remove(), n33.holdTimeout = null), n33.isDragging || (n33.modifiers = t30.modifiers, n33.isDragging = true, i25 === n33.startEvent.native.pointerId ? this._pointerDrag.emit(s23("start", n33, e28)) : this._pointerDrag.emit(s23("start", n33, n33.previousEvent), t30.timestamp));
    });
  }
  _handlePointerLoss(t30, e28) {
    const i25 = t30.data, n33 = i25.native.pointerId, o29 = this._pointerState.get(n33);
    if (o29) {
      if (null != o29.holdTimeout && (o29.holdTimeout.remove(), o29.holdTimeout = null), o29.isDragging) this._pointerDrag.emit(s23("end", o29, "pointer-up" === e28 ? i25 : o29.previousEvent), void 0, o29.modifiers);
      else if ("pointer-up" === e28 && o29.downButton === i25.native.button) {
        t30.timestamp - o29.startTimestamp <= this._maximumClickDelay && !o29.holdEmitted && this._immediateClick.emit(i25);
      }
      this._pointerState.delete(n33), this.stopCapturingPointer(i25.native), 0 === this._pointerState.size && this._moveHandle.pause();
    }
  }
};
function s23(t30, e28, i25) {
  return { action: t30, startEvent: e28.startEvent, previousEvent: e28.previousEvent, currentEvent: i25 };
}

// node_modules/@arcgis/core/views/input/recognizers/SingleAndDoubleClick.js
var l15 = class extends t9 {
  constructor(t30 = t22.maximumDoubleClickDelay, i25 = t22.maximumDoubleClickDistance, n33 = t22.maximumDoubleTouchDelay, s31 = t22.maximumDoubleTouchDistance, l20 = o3) {
    super(false), this._maximumDoubleClickDelay = t30, this._maximumDoubleClickDistance = i25, this._maximumDoubleTouchDelay = n33, this._maximumDoubleTouchDistance = s31, this._clock = l20, this._pointerState = /* @__PURE__ */ new Map(), this._click = this.registerOutgoing("click"), this._doubleClick = this.registerOutgoing("double-click"), this.registerIncoming("immediate-click", (e28) => this._handleImmediateClick(e28)), this.registerIncoming("pointer-down", (e28) => this._handlePointerDown(e28));
  }
  onUninstall() {
    this._pointerState.forEach((e28) => e28.doubleClickTimer = l(e28.doubleClickTimer));
  }
  get hasPendingInputs() {
    for (const e28 of this._pointerState.values()) if (null != e28.doubleClickTimer) return true;
    return false;
  }
  _clearDoubleClickTimer(e28, i25) {
    const o29 = this._pointerState.get(e28);
    o29 && (o29.doubleClickTimer = l(o29.doubleClickTimer), i25 && this._click.emit(o29.event.data, void 0, o29.event.modifiers), this._pointerState.delete(e28), this.refreshHasPendingInputs());
  }
  _doubleClickTimeoutExceeded(e28) {
    const t30 = this._pointerState.get(e28);
    1 === t30.pointerDownCount && this._click.emit(t30.event.data, void 0, t30.event.modifiers), t30.doubleClickTimer = null, this._pointerState.delete(e28), this.refreshHasPendingInputs();
  }
  _handleImmediateClick(e28) {
    const t30 = e28.data, { pointerType: i25 } = t30.native, o29 = r23(t30);
    if (!this._pointerState.has(o29)) return void this._startClick(e28);
    const s31 = this._pointerState.get(o29), { data: l20, modifiers: c29 } = s31.event, a27 = "touch" === i25 ? this._maximumDoubleTouchDistance : this._maximumDoubleClickDistance;
    n27(l20, t30) > a27 ? (this._clearDoubleClickTimer(o29, true), this._startClick(e28)) : (this._clearDoubleClickTimer(o29, false), 2 === s31.pointerDownCount && this._doubleClick.emit(l20, void 0, c29));
  }
  _handlePointerDown(e28) {
    const t30 = u9(e28.data), i25 = this._pointerState.get(t30);
    i25 && (i25.pointerDownCount += 1);
  }
  _startClick(e28) {
    const { data: t30 } = e28, { native: { pointerType: i25 } } = t30, o29 = u9(t30), n33 = "touch" === i25 ? this._maximumDoubleTouchDelay : this._maximumDoubleClickDelay, l20 = this._clock.setTimeout(() => this._doubleClickTimeoutExceeded(o29), n33), r33 = 1;
    this._pointerState.set(o29, { event: e28, doubleClickTimer: l20, pointerDownCount: r33 }), this.refreshHasPendingInputs();
  }
};
function r23(e28) {
  const { pointerId: t30, pointerType: i25, button: o29 } = e28.native;
  return "mouse" === i25 ? `${t30}:${o29}` : `${i25}`;
}

// node_modules/@arcgis/core/views/2d/input/MapViewInputManager.js
var C4 = { counter: "Control", pan: { left: "ArrowLeft", right: "ArrowRight", up: "ArrowUp", down: "ArrowDown" }, zoom: { zoomIn: ["=", "+"], zoomOut: ["-", "_"] }, rotate: { clockwise: ["a", "A"], counterClockwise: ["d", "D"], reset: ["n", "N"] } };
var L6 = Symbol("handles");
var k3 = class extends g2 {
  initialize() {
    const e28 = () => this.view?.ready;
    this.addHandles([p3(() => !e28(), () => this._disconnect()), p3(e28, () => this._connect())]);
  }
  destroy() {
    this._disconnect();
  }
  get latestPointerType() {
    return this._inputManager?.latestPointerType;
  }
  get latestPointerLocation() {
    return this._inputManager?.latestPointerLocation;
  }
  get multiTouchActive() {
    return this._inputManager?.multiTouchActive ?? false;
  }
  isModifierKeyDown(e28) {
    return this._inputManager?.isModifierKeyDown(e28) ?? false;
  }
  _disconnect() {
    this.view.viewEvents.disconnect(), this.removeHandles(L6), this._inputManager = u(this._inputManager);
  }
  _connect() {
    const e28 = this.view.surface, t30 = new l14(e28, this.view.input), o29 = [new m15(), new r22(), new l15(), new s22(this.view.navigation), new u10()], r33 = new d5({ eventSource: t30, recognizers: o29 }), a27 = new n24(this.view, ["primary"]), c29 = new o15(this.view, ["secondary"]);
    r33.installHandlers("prevent-context-menu", [new e19()], _2.INTERNAL), r33.installHandlers("navigation", [new a15(this.view), new m14(this.view), new o16(this.view), new a13(this.view), new a13(this.view, [C4.counter]), a27, new e16(this.view, C4.pan), new e17(this.view, C4.zoom), new t18(this.view, C4.rotate), c29, new e15(this.view, "touch")], _2.INTERNAL), this.view.viewEvents.connect(r33), this._source = t30, this._inputManager = r33, this.addHandles([d3(() => this.view?.navigation?.browserTouchPanEnabled, (e29) => {
      this._source && (this._source.browserTouchPanningEnabled = !e29);
    }, P), d3(() => {
      const { actionMap: e29 } = this.view.navigation;
      return { panActions: n23("pan", e29), rotateActions: n23("rotate", e29) };
    }, ({ panActions: e29, rotateActions: t31 }) => {
      a27.pointerActions = e29, c29.pointerActions = t31;
    }, A3)], L6);
  }
  get test() {
  }
};
r([m()], k3.prototype, "view", void 0), r([m()], k3.prototype, "latestPointerType", null), r([m()], k3.prototype, "latestPointerLocation", null), r([m()], k3.prototype, "multiTouchActive", null), k3 = r([a3("esri.views.2d.input.MapViewInputManager")], k3);
var E2 = k3;

// node_modules/@arcgis/core/views/2d/support/StationaryManager.js
var e20 = 160;
var i20 = class extends g2 {
  constructor() {
    super(...arguments), this._timer = void 0;
  }
  get stationary() {
    return !this._timer;
  }
  flip() {
    this._timestamp = performance.now(), null == this._timer && (this._timer = setInterval(() => {
      performance.now() - this._timestamp >= e20 && this.clear();
    }, e20));
  }
  clear() {
    this._timer && (clearInterval(this._timer), this._timer = void 0);
  }
};
r([m()], i20.prototype, "_timer", void 0), r([m()], i20.prototype, "stationary", null), i20 = r([a3("esri.views.2d.support.StationaryManager")], i20);

// node_modules/@arcgis/core/views/Viewport2DMixin.js
var u11 = (u17) => {
  let m24 = class extends u17 {
    constructor(...t30) {
      super(...t30), this.fullOpacity = 1, this.stateManager = new z2({ constraints: new f10({ view: this }) }), this.goToManager = new h12({ view: this }), this.stationaryManager = new i20(), this.mapViewNavigation = null, this.renderingOptions = { samplingMode: "dynamic", edgeLabelsVisible: false, labelsAnimationTime: 0, labelCollisionsEnabled: false }, this.frameTask = new h11(this), this.inputManager = new E2({ view: this }), this.viewEvents = new c11(this), this.padding = { top: 0, right: 0, bottom: 0, left: 0 }, this.addHandles([d3(() => this.viewpoint, () => this.stationaryManager.flip(), C), this.on("resize", (t31) => this.stateManager.resize(t31.width, t31.height))]);
    }
    get constraintsInfo() {
      return { lods: null, spatialReference: null };
    }
    get extent() {
      return this.stateManager?.extent ?? null;
    }
    set extent(t30) {
      this.stateManager.extent = t30;
    }
    get state() {
      return this.stateManager.state;
    }
    get interacting() {
      return this.navigating;
    }
    get stationary() {
      return !this.animation && !this.navigating && !this.resizing && this.stationaryManager.stationary;
    }
    set animation(t30) {
      const e28 = this._get("animation");
      if (t30 === e28) return;
      if (e28 && e28.stop(), t30 !== this.animationManager.animation && this.animationManager.stop(), !t30 || t30.isFulfilled()) return void this._set("animation", null);
      this._set("animation", t30);
      const i25 = () => {
        this.destroyed || t30 === this._get("animation") && (this._set("animation", null), this.frameTask?.requestFrame());
      };
      t30.when(i25, i25);
    }
    get constraints() {
      return this.stateManager?.constraints;
    }
    set constraints(t30) {
      t30.view = this;
      const e28 = this.stateManager.constraints;
      this.stateManager.constraints = t30, e28?.destroy();
    }
    get padding() {
      return this.stateManager?.padding;
    }
    set padding(t30) {
      this.stateManager && (this.stateManager.padding = t30);
    }
    get resizeAlign() {
      return this.stateManager.resizeAlign;
    }
    set resizeAlign(t30) {
      this.stateManager.resizeAlign = t30;
    }
    get rotation() {
      return this.stateManager.rotation ?? 0;
    }
    set rotation(t30) {
      const { rotationEnabled: e28 } = this.constraints;
      this.constraints.rotationEnabled = true, this.stateManager.rotation = t30, this.constraints.rotationEnabled = e28;
    }
    get viewpoint() {
      return this.stateManager.viewpoint ?? null;
    }
    set viewpoint(t30) {
      this.stateManager.viewpoint = t30, this.frameTask.requestFrame();
    }
    on(t30, e28, i25, n33) {
      const a27 = this.inputManager && this.viewEvents.on(t30, e28, i25, n33);
      return a27 || super.on(t30, e28);
    }
    hasEventListener(t30) {
      return super.hasEventListener(t30) || this.viewEvents.hasHandler(t30);
    }
    goTo(t30, e28) {
      return this.goToManager.goTo(t30, e28);
    }
  };
  return r([m({ readOnly: true })], m24.prototype, "animationManager", void 0), r([m({ readOnly: true })], m24.prototype, "fullOpacity", void 0), r([m()], m24.prototype, "stateManager", void 0), r([m()], m24.prototype, "constraintsInfo", null), r([m()], m24.prototype, "extent", null), r([m()], m24.prototype, "goToManager", void 0), r([m({ readOnly: true })], m24.prototype, "state", null), r([m({ readOnly: true })], m24.prototype, "mapViewNavigation", void 0), r([m()], m24.prototype, "renderingOptions", void 0), r([m({ readOnly: true })], m24.prototype, "interacting", null), r([m()], m24.prototype, "stationary", null), r([m()], m24.prototype, "animation", null), r([m({ type: f10 })], m24.prototype, "constraints", null), r([m({ readOnly: true })], m24.prototype, "inputManager", void 0), r([m()], m24.prototype, "padding", null), r([m()], m24.prototype, "resizeAlign", null), r([m()], m24.prototype, "rotation", null), r([m({ readOnly: true })], m24.prototype, "viewEvents", void 0), r([m({ type: m3 })], m24.prototype, "viewpoint", null), m24 = r([a3("esri.views.Viewport2DMixin")], m24), m24;
};

// node_modules/@arcgis/core/views/2d/pointToPoint/Camera.js
var a19 = class {
  constructor(e28) {
    this._view = e28, this.viewpoint = new m3({ targetGeometry: new j2(), scale: 0, rotation: 0 });
  }
  get view() {
    return this._view;
  }
  get size() {
    const [t30, e28] = this._view.size;
    return Math.sqrt(t30 * t30 + e28 * e28);
  }
  get scale() {
    return this.viewpoint.scale;
  }
  get rotation() {
    return this.viewpoint.rotation;
  }
  get center() {
    return this.viewpoint.targetGeometry;
  }
  get scaleToResolutionFactor() {
    return at(this.center.spatialReference);
  }
  pixelsPerPanAtZoom(t30) {
    return 1 / (t30 * this.scaleToResolutionFactor);
  }
  zoomAtPixelsPerPan(t30) {
    return 1 / (t30 * this.scaleToResolutionFactor);
  }
  pixelsPerRotate() {
    return this.size / 2;
  }
  compareTo(t30, o29) {
    o29.pan = e5(this.center, t30.center);
    let i25 = Math.abs(t30.rotation - this.rotation);
    i25 = i25 >= 180 ? 360 - i25 : i25, o29.rotate = s9(i25), o29.sourceZoom = this.scale, o29.targetZoom = t30.scale;
  }
  interpolate(t30, e28, i25) {
    const { pan: r33, rotate: s31, zoom: n33, zoomOffset: a27 } = i25, { center: c29 } = this;
    c29.spatialReference = t30.center.spatialReference, c29.x = o5(t30.center.x, e28.center.x, r33), c29.y = o5(t30.center.y, e28.center.y, r33), this.viewpoint.scale = o5(t30.scale, e28.scale + a27, n33);
    let p31 = t30.rotation;
    const l20 = e28.rotation;
    Math.abs(l20 - p31) >= 180 && (p31 += 360 * (p31 < l20 ? 1 : -1)), this.viewpoint.rotation = o5(p31, l20, s31);
  }
  copyFrom(t30) {
    Z(this.viewpoint, t30.viewpoint), this._view = t30.view;
  }
};

// node_modules/@arcgis/core/views/animation/easing.js
var u12 = (t30) => t30;
var i21 = (t30) => t30 * t30;
var o21 = (t30) => 1 - i21(1 - t30);
var n28 = (t30) => t30 < 0.5 ? i21(2 * t30) / 2 : (o21(2 * (t30 - 0.5)) + 1) / 2;
var a20 = (t30) => t30 * t30 * t30;
var c17 = (t30) => 1 - a20(1 - t30);
var s24 = (t30) => t30 < 0.5 ? a20(2 * t30) / 2 : (c17(2 * (t30 - 0.5)) + 1) / 2;
var e21 = (t30) => t30 * t30 * t30 * t30;
var q = (t30) => 1 - e21(1 - t30);
var r24 = (t30) => t30 < 0.5 ? e21(2 * t30) / 2 : (q(2 * (t30 - 0.5)) + 1) / 2;
var d11 = (t30) => t30 * t30 * t30 * t30 * t30;
var b6 = (t30) => 1 - d11(1 - t30);
var p21 = (t30) => t30 < 0.5 ? d11(2 * t30) / 2 : (b6(2 * (t30 - 0.5)) + 1) / 2;
var h15 = (t30) => 1 - Math.cos(t30 * Math.PI / 2);
var x = (t30) => 1 - h15(1 - t30);
var M6 = (t30) => t30 < 0.5 ? h15(2 * t30) / 2 : (x(2 * (t30 - 0.5)) + 1) / 2;
var f11 = (t30) => 2 ** (10 * (t30 - 1));
var I5 = (t30) => 1 - f11(1 - t30);
var m16 = (t30) => t30 < 0.5 ? f11(2 * t30) / 2 : (I5(2 * (t30 - 0.5)) + 1) / 2;
var O4 = (t30) => -(Math.sqrt(1 - t30 * t30) - 1);
var j6 = (t30) => 1 - O4(1 - t30);
var l16 = (t30) => t30 < 0.5 ? O4(2 * t30) / 2 : (j6(2 * (t30 - 0.5)) + 1) / 2;
function z3(t30) {
  const u17 = 2 * (t30 - Math.sqrt((t30 - 1) * t30)), i25 = u17 / 2 / t30;
  return (o29) => o29 < i25 ? t30 * o29 * o29 : u17 * o29 - u17 + 1;
}
function B2(t30, u17) {
  return (i25, o29) => i25 < u17 ? u17 * t30(i25 / u17, o29) : 1 - t30((1 - i25) / (1 - u17), o29) * (1 - u17);
}
var P5 = B2(z3(1), 1);
var g12 = B2(z3(1), 0);
var k4 = B2(z3(1), 0.5);
var v7 = B2(z3(2), 1);
var w7 = B2(z3(2), 0);
var y7 = B2(z3(2), 0.5);
var A4 = B2(z3(3), 1);
var C5 = B2(z3(3), 0);
var D2 = B2(z3(3), 0.5);
var E3 = B2(z3(4), 1);
var F2 = B2(z3(4), 0);
var G3 = B2(z3(4), 0.5);
var H2 = { linear: u12, "in-quad": i21, "out-quad": o21, "in-out-quad": n28, "in-coast-quad": P5, "out-coast-quad": g12, "in-out-coast-quad": k4, "in-cubic": a20, "out-cubic": c17, "in-out-cubic": s24, "in-coast-cubic": v7, "out-coast-cubic": w7, "in-out-coast-cubic": y7, "in-quart": e21, "out-quart": q, "in-out-quart": r24, "in-coast-quart": A4, "out-coast-quart": C5, "in-out-coast-quart": D2, "in-quint": d11, "out-quint": b6, "in-out-quint": p21, "in-coast-quint": E3, "out-coast-quint": F2, "in-out-coast-quint": G3, "in-sine": h15, "out-sine": x, "in-out-sine": M6, "in-expo": f11, "out-expo": I5, "in-out-expo": m16, "in-circ": O4, "out-circ": j6, "in-out-circ": l16, ease: (u17) => t7.ease(u17), "ease-in": (u17) => t7.easeIn(u17), "ease-out": (u17) => t7.easeOut(u17), "ease-in-out": (u17) => t7.easeInOut(u17) };

// node_modules/@arcgis/core/views/animation/pointToPoint/Camera.js
var t23 = class {
  constructor() {
    this.pan = 0, this.rotate = 0, this.fov = 0, this.sourceZoom = 0, this.targetZoom = 0;
  }
};

// node_modules/@arcgis/core/views/animation/pointToPoint/Settings.js
var o22 = { desiredScreenFlow: 2, minDuration: n3(500), maxDuration: n3(8e3) };
var r25 = __spreadProps(__spreadValues({}, o22), { maxDuration: n3(4e3) });

// node_modules/@arcgis/core/views/animation/pointToPoint/Definition.js
var r26 = class _r {
  constructor(t30) {
    this._createCamera = t30, this.compared = new t23(), this.segmentStart = 0, this.segmentEnd = 1, this.settings = { desiredScreenFlow: o22.desiredScreenFlow }, this.source = t30(), this.target = t30();
  }
  clone() {
    const t30 = new _r(this._createCamera);
    return t30.copyFrom(this), t30;
  }
  copyFrom(t30) {
    this.update(t30.source, t30.target, t30.settings);
  }
  update(t30, e28, r33) {
    this.source !== t30 && this.source.copyFrom(t30), this.target !== e28 && this.target.copyFrom(e28), this.source.compareTo(this.target, this.compared), this.settings.desiredScreenFlow = r33.desiredScreenFlow ?? o22.desiredScreenFlow, this.desiredPixelFlow = this.settings.desiredScreenFlow * this.target.size, this.halfWindowSize = this.target.size / 2;
  }
  halfWindowPanAtZoom(t30) {
    const e28 = this.target.pixelsPerPanAtZoom(t30);
    return this.halfWindowSize / e28;
  }
  get hasZoom() {
    return Math.abs(this.compared.sourceZoom - this.compared.targetZoom) > 1e-5;
  }
  get hasPan() {
    return this.compared.pan > e6();
  }
  get hasFov() {
    return Math.abs(this.compared.fov) > e6();
  }
  get hasRotate() {
    return this.compared.rotate > e6();
  }
};

// node_modules/@arcgis/core/views/animation/pointToPoint/InterpolateComponents.js
var t24 = class {
  constructor() {
    this.pan = 0, this.rotate = 0, this.zoom = 0, this.fov = 0, this.zoomOffset = 0;
  }
};

// node_modules/@arcgis/core/views/animation/pointToPoint/Path.js
var e22 = class {
  constructor() {
    this.segments = new Array();
  }
  get time() {
    return this.segments.reduce((e28, o29) => t3(e28 + o29.time), t3(0));
  }
  interpolateComponentsAt(t30, e28) {
    t30 = Math.min(Math.max(t30, 0), 1), t30 *= this.time;
    let o29 = 0, s31 = 0;
    const n33 = this.definition, a27 = this.segments.reduce((t31, e29) => t31 || e29.definition.hasZoom, false);
    for (let i25 = 0; i25 < this.segments.length; i25++) {
      const m24 = this.segments[i25], r33 = m24.definition;
      if (t30 <= m24.time || i25 === this.segments.length - 1) {
        if (this.segmentInterpolateComponentsAt(m24, 0 === m24.time ? 0 : t30 / m24.time, e28), n33.hasPan && !isNaN(e28.pan) && isFinite(n33.compared.pan) ? e28.pan = (o29 + r33.compared.pan * e28.pan) / n33.compared.pan : e28.pan = 1, n33.hasRotate && !isNaN(e28.rotate) && isFinite(n33.compared.rotate) ? e28.rotate = (s31 + r33.compared.rotate * e28.rotate) / n33.compared.rotate : e28.rotate = 1, a27 && !isNaN(e28.zoom) && isFinite(r33.compared.targetZoom)) {
          const { sourceZoom: t31, targetZoom: o30 } = r33.compared, s32 = e28.zoom * (o30 - t31) + t31, n34 = this.segments[0].definition.compared.sourceZoom, a28 = this.segments[this.segments.length - 1].definition.compared.targetZoom, i26 = Math.abs(o30 - n34) > Math.abs(t31 - n34) ? o30 : t31;
          e28.zoomOffset = i26 - a28, e28.zoom = (s32 - n34) / (i26 - n34);
        } else e28.zoom = 1;
        return e28;
      }
      t30 -= m24.time, o29 += r33.compared.pan, s31 += r33.compared.rotate;
    }
  }
  segmentInterpolateComponentsAt(t30, e28, o29) {
    t30.interpolateComponentsAt(e28, o29);
  }
};

// node_modules/@arcgis/core/views/animation/pointToPoint/Segment.js
var o23 = class {
  get time() {
    return this._time;
  }
  constructor(t30) {
    t30 && this.update(t30);
  }
  update(t30) {
    t30 && (this.definition ? this.definition.copyFrom(t30) : this.definition = t30.clone()), this._updatePrecomputedVariables(), this._updatePixelFlow();
  }
  _updatePrecomputedVariables() {
    const t30 = this.definition, i25 = t30.compared, o29 = i25.sourceZoom, e28 = i25.targetZoom;
    this._zoomSign = o29 > e28 ? 1 : -1, this._panPixelsAtSource = i25.pan * t30.source.pixelsPerPanAtZoom(o29);
    const n33 = (t30.source.pixelsPerRotate() + t30.target.pixelsPerRotate()) / 2;
    this._rotatePixels = i25.rotate * n33;
  }
  _updatePixelFlow() {
    const t30 = this.definition.compared.sourceZoom, o29 = this.definition.compared.targetZoom, { hasZoom: e28, hasPan: n33, hasRotate: s31 } = this.definition;
    let h21 = 0, a27 = 0;
    e28 && (n33 && (h21 = (o29 / t30 - 1) / (-1 / (this._zoomSign * this.definition.halfWindowSize) * Math.LN2 * this._panPixelsAtSource)), s31 && (a27 = this._zoomSign * (Math.log(t30 / o29) / Math.LN2) * this.definition.halfWindowSize / this._rotatePixels)), this._zoomPixelFlow = 0, this._panPixelFlow = 0, this._rotatePixelFlow = 0;
    const r33 = this.definition.desiredPixelFlow;
    if (e28 && n33 && s31) {
      const t31 = h21 + a27 + h21 * a27;
      this._zoomPixelFlow = h21 * a27 / t31 * r33, this._panPixelFlow = a27 / t31 * r33, this._rotatePixelFlow = h21 / t31 * r33;
    } else if (e28 && n33) {
      const t31 = 1 + h21;
      this._zoomPixelFlow = h21 / t31 * r33, this._panPixelFlow = 1 / t31 * r33;
    } else if (e28 && s31) {
      const t31 = 1 + a27;
      this._zoomPixelFlow = a27 / t31 * r33, this._rotatePixelFlow = 1 / t31 * r33;
    } else if (n33 && s31) {
      const t31 = this._panPixelsAtSource / this._rotatePixels, i25 = 1 + t31;
      this._panPixelFlow = t31 / i25 * r33, this._rotatePixelFlow = 1 / i25 * r33;
    } else n33 ? this._panPixelFlow = r33 : e28 ? this._zoomPixelFlow = r33 : s31 && (this._rotatePixelFlow = r33);
    if (this._time = t3(Math.max(this.rotateTime, this.zoomTime, this.panTime)), this.fovTime > this._time) {
      const t31 = this.fovTime / this._time;
      this._time = this.fovTime, this._zoomPixelFlow /= t31, this._panPixelFlow /= t31, this._rotatePixelFlow /= t31;
    }
  }
  get rotateTime() {
    return this.definition.hasRotate ? t3(this._rotatePixels / this._rotatePixelFlow) : t3(0);
  }
  get zoomTime() {
    return this.definition.hasZoom ? t3(this._zoomSign * (Math.log(this.definition.compared.sourceZoom / this.definition.compared.targetZoom) / Math.LN2) * this.definition.halfWindowSize / this._zoomPixelFlow) : t3(0);
  }
  get fovTime() {
    return this.definition.hasFov ? t3(Math.abs(this.definition.compared.fov) / e23) : t3(0);
  }
  get panTime() {
    if (!this.definition.hasPan) return t3(0);
    if (this.definition.hasZoom) {
      const t30 = -1 / (this._zoomSign * this.definition.halfWindowSize) * Math.LN2, o29 = t30 * this._panPixelsAtSource;
      return t3(Math.log(o29 * (this._zoomPixelFlow / this._panPixelFlow) + 1) / (t30 * this._zoomPixelFlow));
    }
    return t3(this._panPixelsAtSource / this._panPixelFlow);
  }
  _interpolateComponentsZoom(t30) {
    if (0 === t30 || 1 === t30) return t30;
    if (this.definition.hasZoom) {
      const i25 = this.definition.compared.sourceZoom, o29 = this.definition.compared.targetZoom;
      return (i25 * (i25 / o29) ** -t30 - i25) / (o29 - i25);
    }
    return t30;
  }
  _interpolateComponentsFov(t30) {
    if (0 === t30) return this.definition.segmentStart;
    if (1 === t30) return this.definition.segmentEnd;
    if (this.definition.hasFov) {
      const { segmentStart: i25, segmentEnd: o29 } = this.definition;
      return i25 + t30 * (o29 - i25);
    }
    return this.definition.segmentStart;
  }
  _interpolateComponentsPan(t30) {
    if (0 === t30 || 1 === t30) return t30;
    if (this.definition.hasPan && this.definition.hasZoom) {
      const i25 = -1 / (this._zoomSign * this.definition.halfWindowSize) * this._zoomPixelFlow;
      return 1 / this._panPixelsAtSource * (this._panPixelFlow * (2 ** (i25 * t30 * this._time) - 1)) / (i25 * Math.LN2);
    }
    return t30;
  }
  _interpolateComponentsRotate(t30) {
    return t30;
  }
  interpolateComponentsAt(t30, i25) {
    t30 = Math.min(Math.max(t30, 0), 1), i25.zoom = this._interpolateComponentsZoom(t30), i25.pan = this._interpolateComponentsPan(t30), i25.rotate = this._interpolateComponentsRotate(t30), i25.zoomOffset = 0, i25.fov = this._interpolateComponentsFov(t30);
  }
};
var e23 = s9(45);

// node_modules/@arcgis/core/views/animation/pointToPoint/apex/functions.js
function o24(o29, e28, a27) {
  const n33 = e28 - o29.compared.sourceZoom, t30 = o29.halfWindowPanAtZoom(n33);
  return -o29.halfWindowSize * (a27.ascensionFactor * Math.LN2 * o29.compared.pan + t30) * Math.log(o29.compared.sourceZoom / e28) / (o29.desiredPixelFlow * Math.LN2 * t30);
}
function e24(o29, e28, a27) {
  const n33 = 1 / e28, t30 = Math.log(o29.compared.sourceZoom * n33), i25 = 1 / o29.desiredPixelFlow, r33 = 1 / Math.LN2, d18 = e28 - o29.compared.sourceZoom, c29 = 1 / d18, l20 = (a27.ascensionFactor * Math.LN2 * o29.compared.pan + o29.halfWindowPanAtZoom(d18)) / o29.halfWindowPanAtZoom(1);
  return o29.halfWindowSize * n33 * i25 * r33 * c29 * l20 - o29.halfWindowSize * t30 * i25 * r33 * c29 + o29.halfWindowSize * t30 * i25 * r33 * l20 / (d18 * d18);
}
function a21(o29, e28, a27) {
  const n33 = e28 - o29.compared.sourceZoom, t30 = 1 / n33, i25 = 1 / e28, r33 = Math.log(o29.compared.sourceZoom * i25), d18 = (a27.ascensionFactor * Math.LN2 * o29.compared.pan + o29.halfWindowPanAtZoom(n33)) / o29.halfWindowPanAtZoom(1);
  return o29.halfWindowSize * t30 * (-2 * t30 * i25 * d18 + 2 * t30 * r33 + 2 * i25 - 2 * r33 * d18 / (n33 * n33) - d18 / (e28 * e28)) / (o29.desiredPixelFlow * Math.LN2);
}
function n29(o29, e28) {
  return -o29.halfWindowSize * Math.log(o29.compared.sourceZoom / e28) / (o29.desiredPixelFlow * Math.LN2);
}
function t25(o29, e28) {
  return o29.halfWindowSize / (e28 * o29.desiredPixelFlow * Math.LN2);
}
function i22(o29, e28) {
  return -o29.halfWindowSize / (e28 * e28 * o29.desiredPixelFlow * Math.LN2);
}
function r27(o29, e28, a27) {
  return -o29.compared.pan * o29.halfWindowSize * (a27.ascensionFactor + a27.descensionFactor - 1) / (o29.desiredPixelFlow * o29.halfWindowPanAtZoom(e28));
}
function d12(o29, e28, a27) {
  return o29.compared.pan * o29.halfWindowSize * (a27.ascensionFactor + a27.descensionFactor - 1) / (o29.desiredPixelFlow * o29.halfWindowPanAtZoom(e28 * e28));
}
function c18(o29, e28, a27) {
  return -2 * o29.compared.pan * o29.halfWindowSize * (a27.ascensionFactor + a27.descensionFactor - 1) / (o29.desiredPixelFlow * o29.halfWindowPanAtZoom(e28 * e28 * e28));
}
function l17(o29, e28, a27) {
  return o29.halfWindowSize * (-o29.halfWindowPanAtZoom(e28) - a27.descensionFactor * Math.LN2 * o29.compared.pan + o29.halfWindowPanAtZoom(o29.compared.targetZoom)) * Math.log(e28 / o29.compared.targetZoom) / (o29.desiredPixelFlow * Math.LN2 * o29.halfWindowPanAtZoom(-e28 + o29.compared.targetZoom));
}
function m17(o29, e28, a27) {
  const n33 = Math.log(e28 / o29.compared.targetZoom), t30 = 1 / o29.desiredPixelFlow, i25 = 1 / Math.LN2, r33 = -e28 + o29.compared.targetZoom, d18 = 1 / r33, c29 = (-o29.halfWindowPanAtZoom(e28) - a27.descensionFactor * Math.LN2 * o29.compared.pan + o29.halfWindowPanAtZoom(o29.compared.targetZoom)) / o29.halfWindowPanAtZoom(1);
  return -o29.halfWindowSize * n33 * t30 * i25 * d18 + o29.halfWindowSize * n33 * t30 * i25 * c29 / (r33 * r33) + o29.halfWindowSize * t30 * i25 * d18 * c29 / e28;
}
function h16(o29, e28, a27) {
  const n33 = e28 - o29.compared.targetZoom, t30 = 1 / n33, i25 = 1 / e28, r33 = Math.log(e28 / o29.compared.targetZoom), d18 = (o29.halfWindowPanAtZoom(e28) + a27.descensionFactor * Math.LN2 * o29.compared.pan - o29.halfWindowPanAtZoom(o29.compared.targetZoom)) / o29.halfWindowPanAtZoom(1);
  return o29.halfWindowSize * t30 * (-2 * t30 * i25 * d18 - 2 * t30 * r33 + 2 * i25 + 2 * r33 * d18 / (n33 * n33) - d18 / (e28 * e28)) / (o29.desiredPixelFlow * Math.LN2);
}
function s25(o29, e28) {
  return o29.halfWindowSize * Math.log(e28 / o29.compared.targetZoom) / (o29.desiredPixelFlow * Math.LN2);
}
function f12(o29, e28) {
  return o29.halfWindowSize / (e28 * o29.desiredPixelFlow * Math.LN2);
}
function w8(o29, e28) {
  return -o29.halfWindowSize / (e28 * e28 * o29.desiredPixelFlow * Math.LN2);
}
function p22(o29) {
  const e28 = o29.compared.sourceZoom - o29.compared.targetZoom;
  if (0 === e28) return o29.compared.pan * o29.halfWindowSize / (o29.desiredPixelFlow * o29.halfWindowPanAtZoom(o29.compared.sourceZoom));
  const a27 = Math.LN2 * o29.compared.pan, n33 = e28, t30 = o29.halfWindowPanAtZoom(n33), i25 = o29.halfWindowSize * Math.log(o29.compared.sourceZoom / o29.compared.targetZoom) / (o29.desiredPixelFlow * Math.LN2 * t30);
  return o29.compared.sourceZoom <= o29.compared.targetZoom ? i25 * (a27 - t30) : i25 * (a27 + t30);
}

// node_modules/@arcgis/core/views/animation/pointToPoint/apex/planning.js
function f13(f17, Z3) {
  let b9 = D3(f17, Z3);
  const h21 = { ascensionFactor: null != Z3.ascensionFactor ? Z3.ascensionFactor : 0.5, descensionFactor: null != Z3.descensionFactor ? Z3.descensionFactor : 0.5 }, M7 = 0 === h21.ascensionFactor, P7 = 0 === h21.descensionFactor, g16 = M7 ? n29 : o24, k5 = M7 ? t25 : e24, N = M7 ? i22 : a21, j8 = P7 ? s25 : l17, w10 = P7 ? f12 : m17, z4 = P7 ? w8 : h16, A6 = (o29) => g16(f17, o29, h21) + r27(f17, o29, h21) + j8(f17, o29, h21), I6 = (o29) => k5(f17, o29, h21) + d12(f17, o29, h21) + w10(f17, o29, h21), S5 = (o29) => N(f17, o29, h21) + c18(f17, o29, h21) + z4(f17, o29, h21);
  let q2 = A6(b9);
  const v10 = p22(f17);
  let y11;
  const B4 = Z3.maximumIterations || 20, C7 = null != Z3.maximumDistance ? Z3.maximumDistance : 1 / 0;
  for (y11 = 0; y11 < B4; y11++) {
    const o29 = Z3.desiredSlope ?? 1e-6;
    let e28 = I6(b9);
    Math.abs(e28) > o29 && (e28 += o29);
    const n33 = e28 / S5(b9);
    if (isNaN(n33) || b9 >= C7 && n33 < 0) {
      if (!isFinite(C7)) return null;
      b9 = C7, q2 = A6(b9);
      break;
    }
    if (b9 -= n33, b9 < f17.compared.sourceZoom || b9 < f17.compared.targetZoom) return null;
    const a27 = A6(b9);
    if (Math.abs(a27 - q2) / q2 <= 5e-3) break;
    q2 = a27;
  }
  return q2 > v10 * (1 - 0.3) || b9 < f17.compared.sourceZoom || b9 < f17.compared.targetZoom ? null : b9;
}
function D3(o29, e28) {
  const n33 = Math.max(o29.compared.sourceZoom, o29.compared.targetZoom), a27 = o29.source.zoomAtPixelsPerPan(o29.desiredPixelFlow / o29.compared.pan) / 2;
  return a27 < n33 ? null != e28.maximumDistance ? n33 + (e28.maximumDistance - n33) / 2 : 1.5 * n33 : e28.maximumDistance ? Math.min(e28.maximumDistance, a27) : a27;
}

// node_modules/@arcgis/core/views/animation/pointToPoint/apex/Path.js
var s26 = class extends e22 {
  constructor(i25, n33) {
    super(), this._preallocSegments = [new o23(), new o23(), new o23()], this._ascensionSegment = null, this._descensionSegment = null, this.update(i25, n33);
  }
  update(i25, n33) {
    if (!i25) return;
    this.definition ? this.definition.copyFrom(i25) : this.definition = i25.clone();
    const e28 = n33?.apex ? f13(i25, n33.apex) : null;
    this.segments.length = 0, this._ascensionSegment = null, this._descensionSegment = null, e28 ? this._updateWithApex(e28, n33?.apex) : this._updateWithoutApex();
  }
  segmentInterpolateComponentsAt(e28, t30, o29) {
    e28.interpolateComponentsAt(t30, o29), e28 === this._ascensionSegment ? o29.zoom = o21(o29.zoom) : e28 === this._descensionSegment && (o29.zoom = i21(o29.zoom));
  }
  _updateWithApex(i25, n33) {
    const [e28, t30, o29] = this._preallocSegments, s31 = n33?.ascensionFactor ?? 0.5, d18 = Math.min(1 - s31, null != n33?.ascensionFactor && null != n33.descensionFactor ? n33.descensionFactor : 0.5), a27 = 1 - s31 - d18;
    e28.definition ? e28.definition.copyFrom(this.definition) : e28.definition = this.definition.clone(), e28.definition.compared.targetZoom = i25, e28.definition.compared.pan = this.definition.compared.pan * s31, e28.definition.compared.rotate = this.definition.compared.rotate * s31, e28.definition.segmentEnd = s31, e28.update(), this._ascensionSegment = e28, this.segments.push(e28), a27 > 0 && (t30.definition ? t30.definition.copyFrom(this.definition) : t30.definition = this.definition.clone(), t30.definition.copyFrom(this.definition), t30.definition.compared.sourceZoom = i25, t30.definition.compared.targetZoom = i25, t30.definition.compared.pan = this.definition.compared.pan * a27, t30.definition.compared.rotate = this.definition.compared.rotate * a27, t30.definition.segmentStart = e28.definition.segmentEnd, t30.definition.segmentEnd = e28.definition.segmentEnd + a27, t30.update(), this.segments.push(t30)), o29.definition ? o29.definition.copyFrom(this.definition) : o29.definition = this.definition.clone(), o29.definition.compared.sourceZoom = i25, o29.definition.compared.pan = this.definition.compared.pan * d18, o29.definition.compared.rotate = this.definition.compared.rotate * d18, o29.definition.segmentStart = s31 + a27, o29.update(), this._descensionSegment = o29, this.segments.push(o29);
  }
  _updateWithoutApex() {
    const [i25] = this._preallocSegments;
    i25.update(this.definition), this.segments.push(i25);
  }
};

// node_modules/@arcgis/core/views/animation/pointToPoint/Animation.js
var h17 = new t24();
var p23 = class {
  get time() {
    return this._time;
  }
  get isLinear() {
    return 1 === this.path.segments.length;
  }
  constructor(i25) {
    this._time = n3(0), this._easing = k4, this.definition = new r26(i25), this.path = new s26();
  }
  update(t30, a27, o29) {
    this.definition.update(t30, a27, o29), this.path.update(this.definition, o29), this._time = this._applyTimeSettings(r4(isFinite(this.path.time) ? this.path.time : t3(0)), o29), this._easing = o29.easing ?? (this._time >= 1e3 ? k4 : I5);
  }
  cameraAt(t30, i25) {
    t30 = Math.min(Math.max(0, t30), 1), t30 = this._normalizedEasing(t30);
    const e28 = this.path.interpolateComponentsAt(t30, h17);
    i25.interpolate(this.definition.source, this.definition.target, e28);
  }
  _normalizedEasing(t30) {
    const i25 = this._easing(0, this._time), e28 = this._easing(1, this._time);
    return (this._easing(t30, this._time) - i25) / (e28 - i25);
  }
  _applyTimeSettings(i25, e28) {
    const n33 = null != e28.speedFactor ? e28.speedFactor : 1, s31 = e28.minDuration ?? o22.minDuration / n33, a27 = e28.maxDuration ?? o22.maxDuration / n33;
    return i25 = null != e28.duration ? n3(e28.duration) : n3(Math.min(Math.max(i25 / n33, s31), a27));
  }
};

// node_modules/@arcgis/core/views/2d/AnimationManager.js
var f14 = 2e3;
var g13 = 64;
var j7 = class {
  constructor(t30) {
    this._view = t30, this._animation = new p23(() => new a19(this._view)), this._current = new a19(this._view);
  }
  get _source() {
    return this._animation.definition.source;
  }
  get _target() {
    return this._animation.definition.target;
  }
  get duration() {
    return this._animation.time;
  }
  get animation() {
    return this._animation;
  }
  update(t30, i25, e28 = {}) {
    Z(this._current.viewpoint, t30), Z(this._source.viewpoint, t30), Z(this._target.viewpoint, i25), this._animation.update(this._source, this._target, e28);
  }
  applyRatio(t30, i25) {
    this._animation.cameraAt(i25, this._current), Z(t30, this._current.viewpoint);
  }
};
var y8 = class extends g2 {
  constructor(t30) {
    super(t30), this._animation = null, this._destinationViewState = new f9(), this.updateFunction = null, this.easing = H2.ease, this.viewpoint = new m3({ targetGeometry: new j2(), scale: 0, rotation: 0 }), this._updateTask = F({ postRender: this._postRender.bind(this) }), this._updateTask.pause(), this._transition = new j7(t30.view);
  }
  destroy() {
    this._updateTask = l(this._updateTask);
  }
  get animation() {
    return this._animation;
  }
  set animation(t30) {
    this._animation = t30, this.view.animation = t30;
  }
  animate(t30, i25, e28) {
    this.stop();
    const n33 = this.viewpoint;
    Z(n33, i25);
    const s31 = t30.target;
    this._transition.update(this.viewpoint, s31, { apex: { maximumDistance: Math.min(Math.min(i25.scale, s31.scale) * g13, this.view.constraints.effectiveMinScale), desiredSlope: 5e-8 }, duration: e28?.duration, maxDuration: "auto" === e28?.animationMode ? n3(1 / 0) : e28?.maxDuration ?? r25.maxDuration, speedFactor: e28?.speedFactor, easing: ("string" == typeof e28?.easing ? H2[e28.easing] : e28?.easing) || this.easing }), "auto" === e28?.animationMode && (this._destinationViewState.copy(this.view.state), this._destinationViewState.viewpoint = s31, T3(this._transition.animation, e28, this.view.state, this._destinationViewState) || this._transition.update(this.viewpoint, s31, { duration: n3(0) }));
    const o29 = () => {
      this.animation === t30 && this._updateTask && ("finished" === t30.state && (this._transition.applyRatio(this.viewpoint, 1), this.view.state && (this.view.state.viewpoint = this.viewpoint.clone())), this.animation = null, this.updateFunction = null);
    };
    return t30.when(o29, o29), this._startTime = performance.now(), this._updateTask.resume(), this.animation = t30, t30;
  }
  animateContinuous(t30, i25) {
    this.stop(), this.updateFunction = i25, this.viewpoint = t30;
    const e28 = new a10({ target: t30.clone() }), n33 = () => {
      this.animation === e28 && this._updateTask && (this.animation = null, this.updateFunction = null);
    };
    return e28.when(n33, n33), this._startTime = performance.now(), this._updateTask.resume(), this.animation = e28, e28;
  }
  stop() {
    this.animation && (this.animation.stop(), this.animation = null, this.updateFunction = null);
  }
  _postRender(t30) {
    const i25 = this.animation;
    if (i25 && i25.state !== a10.State.STOPPED) {
      if (this.updateFunction) this.updateFunction(this.viewpoint, t30.deltaTime), this.animation?.update(this.viewpoint);
      else {
        const t31 = performance.now() - this._startTime, i26 = this._transition.duration, e28 = i26 > 0 ? t31 / i26 : 1, n33 = e28 >= 1;
        this._transition.applyRatio(this.viewpoint, e28), n33 && this.animation?.finish();
      }
      this.view.state && (this.view.state.viewpoint = this.viewpoint.clone());
    } else this._updateTask.pause();
  }
};
function T3(t30, i25, e28, n33) {
  if (null != i25?.duration) return true;
  const { time: s31, isLinear: a27 } = t30, r33 = i25?.speedFactor || 1;
  if (s31 > (i25?.maxDuration ?? r25.maxDuration / r33)) return false;
  if (a27) {
    const t31 = 1.5, i26 = n11(), a28 = c4(...n33.toScreen(i26, ...e28.center)), m24 = c4(...e28.toScreen(i26, ...n33.center)), h21 = null != m24 && m24.x > -1 * e28.size[0] && m24.x < (t31 + 0.5) * e28.size[0] && m24.y > -1 * e28.size[1] && m24.y < (t31 + 0.5) * e28.size[1], u17 = null != a28 && a28.x > -1 * n33.size[0] && a28.x < (t31 + 0.5) * n33.size[0] && a28.y > -1 * n33.size[1] && a28.y < (t31 + 0.5) * n33.size[1];
    if (s31 > f14 / r33 && !h21 && !u17) return false;
  }
  return true;
}
r([m()], y8.prototype, "easing", void 0), r([m()], y8.prototype, "view", void 0), r([m()], y8.prototype, "viewpoint", void 0), y8 = r([a3("esri.views.2d.AnimationManager")], y8);
var x2 = y8;

// node_modules/@arcgis/core/views/2d/layerViewModuleImportUtils.js
function r28() {
  return Promise.all([import("./webglDeps-S6GV76SY.js"), import("./mapViewDeps-IDK4SUKW.js")]);
}
var a22 = () => r28().then(() => import("./TileLayerView2D-3K5I7QUL.js"));
var t26 = () => r28().then(() => import("./FeatureLayerView2D-IIKF2CP6.js"));
var i23 = { "base-dynamic": () => r28().then(() => import("./BaseDynamicLayerView2D-3E24VTOI.js")), "base-tile": a22, "bing-maps": a22, catalog: () => r28().then(() => import("./CatalogLayerView2D-NGF4CTID.js")), "catalog-dynamic-group": () => r28().then(() => import("./CatalogDynamicGroupLayerView2D-AX4SY27L.js")), "catalog-footprint": () => r28().then(() => import("./CatalogFootprintLayerView2D-NG7OVUS2.js")), csv: t26, "geo-rss": () => r28().then(() => import("./GeoRSSLayerView2D-5FBAO6Z7.js")), feature: t26, geojson: t26, parquet: t26, graphics: () => r28().then(() => import("./GraphicsLayerView2D-U6Z7K363.js")), group: () => r28().then(() => import("./GroupLayerView2D-IYJ6PTAV.js")), imagery: () => r28().then(() => import("./ImageryLayerView2D-I7PKNYFM.js")), "imagery-tile": () => r28().then(() => import("./ImageryTileLayerView2D-ZAIAWKMX.js")), kml: () => r28().then(() => import("./KMLLayerView2D-VC5QFSAR.js")), "knowledge-graph": () => r28().then(() => import("./KnowledgeGraphLayerView2D-QXYNO2FI.js")), "link-chart": () => r28().then(() => import("./KnowledgeGraphLayerView2D-QXYNO2FI.js")), "knowledge-graph-sublayer": t26, "map-image": () => r28().then(() => import("./MapImageLayerView2D-JGESTJ6P.js")), "map-notes": () => r28().then(() => import("./MapNotesLayerView2D-3JQFBFAM.js")), media: () => r28().then(() => import("./MediaLayerView2D-DSCPXWWG.js")), "ogc-feature": () => r28().then(() => import("./OGCFeatureLayerView2D-EN7BHJBH.js")), "open-street-map": a22, "oriented-imagery": t26, route: () => r28().then(() => import("./RouteLayerView2D-6I33LFK6.js")), stream: () => r28().then(() => import("./StreamLayerView2D-ZJNTBJWY.js")), "subtype-group": () => r28().then(() => import("./SubtypeGroupLayerView2D-ZARVPEM6.js")), tile: a22, "vector-tile": () => r28().then(() => import("./VectorTileLayerView2D-7FQTFB3B.js")), video: () => r28().then(() => import("./VideoLayerView2D-SA3H75LO.js")), wcs: () => r28().then(() => import("./ImageryTileLayerView2D-ZAIAWKMX.js")), "web-tile": a22, wfs: t26, wms: () => r28().then(() => import("./WMSLayerView2D-4GR5MGD3.js")), wmts: () => r28().then(() => import("./WMTSLayerView2D-BZRYUXN3.js")), "line-of-sight": null, "base-elevation": null, "building-scene": null, dimension: null, elevation: null, "integrated-mesh": null, "integrated-mesh-3dtiles": null, "point-cloud": null, viewshed: null, voxel: null, scene: null, unknown: null, unsupported: null };
function s27(r33) {
  const a27 = r33.declaredClass ? r33.declaredClass.slice(r33.declaredClass.lastIndexOf(".") + 1) : "Unknown", t30 = a27.replaceAll(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
  return new s(`${t30}:view-not-supported`, `${a27} is not supported in 2D`);
}
var l18 = { hasLayerViewModule: (e28) => null != i23[e28.type], importLayerView: (e28) => {
  const r33 = i23[e28.type];
  if (null == r33) throw s27(e28);
  return r33(e28);
} };

// node_modules/@arcgis/core/views/2d/layers/features/support/TileStore.js
var d13 = { added: [], removed: [] };
var a23 = /* @__PURE__ */ new Set();
var c19 = new e8(0, 0, 0, 0);
function m18(e28, t30) {
  const s31 = d4(t30);
  if (!s31) return null;
  const [i25, r33] = s31.valid;
  return e28[2] > r33 ? [u3([e28[0], e28[1], r33, e28[3]]), u3([i25, e28[1], i25 + e28[2] - r33, e28[3]])] : e28[0] < i25 ? [u3([i25, e28[1], e28[2], e28[3]]), u3([r33 - (i25 - e28[0]), e28[1], r33, e28[3]])] : null;
}
var u13 = class extends i {
  constructor(e28) {
    super(), this._tiles = /* @__PURE__ */ new Map(), this._index = i5(9, has("esri-csp-restrictions") ? (e29) => ({ minX: e29.bounds[0], minY: e29.bounds[1], maxX: e29.bounds[2], maxY: e29.bounds[3] }) : [".bounds[0]", ".bounds[1]", ".bounds[2]", ".bounds[3]"]), this.tiles = [], this.tileScheme = e28;
  }
  destroy() {
    this.clear();
  }
  clear() {
    this.tiles.length = 0, this._tiles.clear(), this._index.clear();
  }
  has(e28) {
    return this._tiles.has(e28);
  }
  get(e28) {
    return this._tiles.get(e28);
  }
  getIntersectingTiles(e28) {
    if (!e28 || 0 === M2(e28) || 0 === s10(e28)) return [];
    const t30 = m18(e28, this.tileScheme.spatialReference);
    return null != t30 ? [.../* @__PURE__ */ new Set([...this.boundsIntersections(t30[0]), ...this.boundsIntersections(t30[1])])] : this.boundsIntersections(e28);
  }
  boundsIntersections(e28) {
    return this._index.search({ minX: e28[0], minY: e28[1], maxX: e28[2], maxY: e28[3] });
  }
  updateTiles(e28) {
    const t30 = { added: [], removed: [] };
    for (const s31 of e28.added) if (!this.has(s31)) {
      const e29 = new r10(this.tileScheme, s31);
      this._tiles.set(s31, e29), this._index.insert(e29), t30.added.push(e29);
    }
    for (const s31 of e28.removed) if (this.has(s31)) {
      const e29 = this.get(s31);
      this._tiles.delete(s31), this._index.remove(e29), t30.removed.push(e29);
    }
    this.tiles.length = 0, this._tiles.forEach((e29) => this.tiles.push(e29)), (t30.added.length || t30.removed.length) && this.emit("update", t30);
  }
  setViewState(e28) {
    const t30 = this.tileScheme.getTileCoverage(e28, 0);
    if (!t30) return;
    const { spans: s31, lodInfo: i25 } = t30, { level: o29 } = i25;
    if (s31.length > 0) for (const { row: n33, colFrom: l20, colTo: h21 } of s31) for (let e29 = l20; e29 <= h21; e29++) {
      const t31 = c19.set(o29, n33, i25.normalizeCol(e29), i25.getWorldForColumn(e29)).id;
      if (a23.add(t31), !this.has(t31)) {
        const e30 = new r10(this.tileScheme, t31);
        this._tiles.set(t31, e30), this._index.insert(e30), this.tiles.push(e30), d13.added.push(e30);
      }
    }
    for (let n33 = this.tiles.length - 1; n33 >= 0; n33--) {
      const e29 = this.tiles[n33];
      a23.has(e29.id) || (this._tiles.delete(e29.id), this.tiles.splice(n33, 1), this._index.remove(e29), d13.removed.push(e29));
    }
    (d13.added.length || d13.removed.length) && this.emit("update", d13), s11.pool.release(t30), a23.clear(), d13.added.length = 0, d13.removed.length = 0;
  }
};

// node_modules/@arcgis/core/views/2d/support/hitTestUtils.js
function s28(e28, i25, s31) {
  return __async(this, null, function* () {
    const f17 = o10(i25) ? r11(e28, i25) : i25;
    if (!e28.ready || isNaN(f17.x) || isNaN(f17.y)) return { screenPoint: f17, results: [] };
    let d18 = /* @__PURE__ */ new Set();
    const y11 = /* @__PURE__ */ new Set();
    let u17 = false, h21 = null, g16 = null;
    s31?.include ? o25(s31.include, n30(e28, (e29) => {
      d18.add(e29), p24(e29, (e30) => y11.add(e30));
    }, (e29, r33) => {
      y11.add(e29), d18.add(r33);
    }, (e29) => {
      h21 || (h21 = /* @__PURE__ */ new Set()), h21.add(e29);
    }, (e29) => d18.add(e29), () => u17 = true)) : (u17 = true, d18 = new Set(e28.allLayerViews), d18.forEach((e29) => {
      p24(e29, (e30) => y11.add(e30));
    })), s31?.exclude && o25(s31.exclude, n30(e28, (e29) => {
      d18.delete(e29), p24(e29, (e30) => y11.delete(e30));
    }, (e29) => y11.delete(e29), (e29) => {
      g16 || (g16 = /* @__PURE__ */ new Set()), g16.add(e29);
    }));
    const m24 = e28.toMap(f17), w10 = e28.allLayerViews.filter((r33) => !r33.suspended && d18.has(r33) && r33.clips.every((r34) => m8(e28, r34, f17, m24))).reverse();
    let V3 = [...u17 ? e28.graphicsView.hitTest(m24).map((e29) => ({ type: "graphic", graphic: e29, layer: null, mapPoint: m24 })) : [], ...yield Promise.all(w10.map((e29) => e29.hitTest(m24, f17)).toArray())].filter(G).flat().filter(G);
    return V3 = V3.filter((e29) => "graphic" !== e29.type || "subtype-group" !== e29.layer?.type || y11.has(e29.graphic.layer)), h21 && (V3 = V3.filter((e29) => !("graphic" in e29) || !e29.graphic || h21?.has(c20(e29.graphic)))), g16 && (V3 = V3.filter((e29) => !("graphic" in e29) || !e29.graphic || !g16?.has(c20(e29.graphic)))), { screenPoint: f17, results: V3 };
  });
}
function n30(r33, i25, t30, a27, l20, s31) {
  return (n33) => {
    if (n33 instanceof b2) {
      if (n33.layer === r33) s31?.();
      else {
        const e28 = r33.allLayerViews.find((e29) => e29.layer === n33.layer);
        e28 && l20?.(e28);
      }
      a27(c20(n33));
    } else if ("layer" in n33 && "element" in n33) ;
    else if ("subtype-sublayer" === n33.type) {
      const e28 = r33.allLayerViews.find((e29) => e29.layer === n33.parent);
      e28 && t30(n33, e28);
    } else {
      const e28 = r33.allLayerViews.find((e29) => e29.layer === n33);
      e28 && i25(e28);
    }
  };
}
function o25(e28, r33) {
  if (e28) if (t(e28)) for (const t30 of e28) if (t(t30)) for (const e29 of t30) r33(e29);
  else r33(t30);
  else r33(e28);
}
function c20(e28) {
  const r33 = e28.getObjectId();
  return r33 ? `${e28.layer?.uid ?? e28.sourceLayer?.uid ?? "MapView"}/${r33}` : `"MapView/${e28.uid}`;
}
function p24({ layer: e28 }, r33) {
  "subtype-group" === e28?.type && e28.sublayers.forEach((e29) => {
    r33(e29);
  });
}

// node_modules/@arcgis/core/views/2d/support/screenshotUtils.js
var e25 = { flipY: true, premultipliedAlpha: true };
function o26(h21, n33) {
  return __async(this, null, function* () {
    const o29 = yield a24(h21, n33), { format: r33, quality: l20 } = c8(n33?.format, n33?.quality);
    return a5(o29, { format: r33, quality: l20 }, e25);
  });
}
function r29(t30, i25) {
  return __async(this, null, function* () {
    const n33 = yield a24(t30, i25);
    return r12(n33, e25);
  });
}
function a24(t30, i25) {
  const h21 = d14(i25 || {}, u14(t30.stage, t30.size), t30.size, t30.padding), n33 = l19(i25, t30.allLayerViews);
  return t30.stage.takeScreenshot(h21, n33, t30.backgroundColor, i25?.rotation);
}
function l19(t30 = {}, i25) {
  if (!t30.layers) return;
  const h21 = [];
  return t30.layers.forEach((t31) => {
    const n33 = i25.find((i26) => i26.layer.id === t31.id);
    n33?.container && h21.push(n33.container);
  }), h21;
}
function u14(t30, i25) {
  return Math.min(4, s13(i25, Math.min(4096, t30.context.parameters.maxTextureSize)));
}
function d14(t30, i25, h21, n33) {
  t30.ignorePadding && (n33 = { left: 0, right: 0, top: 0, bottom: 0 });
  let e28 = null;
  null != t30.width && null != t30.height ? e28 = [t30.width, t30.height] : null == t30.width && null != t30.height ? e28 = [t30.height, t30.height] : null != t30.width && null == t30.height ? e28 = [t30.width, t30.width] : null == t30.width && null == t30.height && (e28 = null);
  const o29 = h21[0] - (n33.left + n33.right), r33 = h21[1] - (n33.top + n33.bottom);
  let a27, l20, u17 = t30.area || { x: 0, y: 0, width: o29, height: r33 };
  if (e28) {
    const t31 = o29 / r33, i26 = e28[0] / e28[1];
    if (i26 > t31) {
      const t32 = u17.width / i26;
      u17 = { x: u17.x, y: Math.round(u17.y + (u17.height - t32) / 2), width: u17.width, height: Math.round(t32) };
    } else {
      const t32 = u17.height * i26;
      u17 = { x: Math.round(u17.x + (u17.width - t32) / 2), y: u17.y, width: Math.round(t32), height: u17.height };
    }
  } else e28 = [u17.width, u17.height];
  return e28[0] > u17.width ? (a27 = Math.min(e28[0] / u17.width, i25), l20 = e28[0] / u17.width / a27) : (a27 = 1, l20 = e28[0] / u17.width), { cropArea: { x: Math.round((u17.x + n33.left) * a27), y: Math.round((u17.y + n33.top) * a27), width: Math.round(u17.width * a27), height: Math.round(u17.height * a27) }, outputScale: l20, resolutionScale: a27 };
}

// node_modules/@arcgis/core/views/support/WebGLRequirements.js
function t27(t30) {
  const o29 = t8();
  return o29.available ? "3d" === t30 && o29.majorPerformanceCaveat ? new s("webgl:major-performance-caveat-detected", `Your WebGL implementation (${o29.unmaskedRenderer}) doesn't seem to support hardware accelerated rendering. Check your browser settings or if your GPU is in a blocklist.`) : o29.supportsHighPrecisionFragment ? o29.supportsVertexShaderSamplers ? null : new s("webgl:vertex-shader-samplers-required", "WebGL support for vertex shader samplers is required but not supported.") : new s("webgl:high-precision-fragment-required", "WebGL support for high precision fragment shaders is required but not supported.") : new s("webgl:required", "WebGL2 is required but not supported.", new Error().stack);
}

// node_modules/@arcgis/core/views/ui/Component.js
function n31(t30) {
  return t30 && "nodeType" in t30;
}
function d15(t30) {
  return t30 && "function" == typeof t30.render;
}
var c21 = { component: "esri-component" };
var p25 = class extends g2 {
  constructor() {
    super(...arguments), this.widget = null;
  }
  destroy() {
    this.node = null, this.widget?.destroy();
  }
  get id() {
    return this._get("id") ?? this.widget?.id ?? this.node?.id;
  }
  set id(t30) {
    this._set("id", t30);
  }
  set node(t30) {
    const o29 = this._get("node");
    t30 !== o29 && (t30 && t30.classList.add(c21.component), o29 && o29.classList.remove(c21.component), this._set("node", t30));
  }
  castNode(t30) {
    return this.widget?.destroy(), t30 ? "string" == typeof t30 || n31(t30) ? (this._set("widget", null), n4(t30)) : (d15(t30) && !t30.domNode && (t30.domNode = document.createElement("div")), this._set("widget", t30), t30.domNode) : (this._set("widget", null), null);
  }
};
r([m()], p25.prototype, "id", null), r([m()], p25.prototype, "node", null), r([s5("node")], p25.prototype, "castNode", null), r([m({ readOnly: true })], p25.prototype, "widget", void 0), p25 = r([a3("esri.views.ui.Component")], p25);
var m19 = p25;

// node_modules/@arcgis/core/views/ui/UI.js
var f15 = { left: 0, top: 0, bottom: 0, right: 0 };
var _8 = { bottom: 30, top: 15, right: 15, left: 15 };
var g14 = "esri-ui";
var y9 = { ui: g14, corner: `${g14}-corner`, innerContainer: `${g14}-inner-container`, manualContainer: `${g14}-manual-container`, cornerContainer: `${g14}-corner-container`, topLeft: `${g14}-top-left`, topRight: `${g14}-top-right`, bottomLeft: `${g14}-bottom-left`, bottomRight: `${g14}-bottom-right` };
function C6(t30) {
  return t30 && !t30._started && "function" == typeof t30.postMixInProperties && "function" == typeof t30.buildRendering && "function" == typeof t30.postCreate && "function" == typeof t30.startup;
}
function v8(t30) {
  return 0 === t30 ? "0" : `${t30}px`;
}
function b7(t30) {
  const o29 = "object" == typeof t30 && null !== t30 && Object.getPrototypeOf(t30);
  return (null === o29 || o29 === Object.prototype) && ("component" in t30 || "index" in t30 || "position" in t30) ? t30 : null;
}
function w9(t30, { top: o29, bottom: e28, left: n33, right: i25 }) {
  t30.style.top = o29, t30.style.bottom = e28, t30.style.left = n33, t30.style.right = i25;
}
var P6 = class extends i.EventedAccessor {
  constructor(t30) {
    super(t30), this._cornerNameToContainerLookup = {}, this._positionNameToContainerLookup = {}, this._components = new Array(), this._componentMap = /* @__PURE__ */ new Map(), this._removeWidgetHandleKey = Symbol("componentOnRemoveSymbol"), this._locale = r5(), this.view = null, this._applyViewPadding = () => {
      const t31 = this.container;
      t31 && w9(t31, this._toPixelPosition(this._getViewPadding()));
    }, this._applyUIPadding = () => {
      const t31 = this._innerContainer;
      t31 && w9(t31, this._toPixelPosition(this.padding));
    }, this._initContainers();
  }
  initialize() {
    this.addHandles([d3(() => [this.view?.padding, this.container], this._applyViewPadding, P), d3(() => this.padding, this._applyUIPadding, P), d3(() => [this.container, this._locale], ([t30, o29]) => {
      t30 && t30.setAttribute("lang", o29);
    }, P), h3((t30) => {
      this._locale = t30;
    })]);
  }
  destroy() {
    this.container = null;
    for (const t30 of this._components) t30.destroy();
    this._components.length = 0, this._componentMap.clear();
  }
  set container(t30) {
    const o29 = this._get("container");
    t30 !== o29 && (t30 && (t30.classList.add(y9.ui), n6(t30), this._attachContainers(t30)), o29 && (o29.classList.remove(y9.ui), w9(o29, { top: "", bottom: "", left: "", right: "" }), o29.textContent = ""), this._set("container", t30));
  }
  get height() {
    const t30 = this.view?.height ?? 0;
    if (0 === t30) return t30;
    const o29 = this._getViewPadding(), { top: e28, bottom: n33 } = o29;
    return Math.max(t30 - e28 - n33, 0);
  }
  get padding() {
    return this._get("padding");
  }
  set padding(t30) {
    this._overrideIfSome("padding", t30);
  }
  castPadding(t30) {
    return "number" == typeof t30 ? { bottom: t30, top: t30, right: t30, left: t30 } : __spreadValues(__spreadValues({}, _8), t30);
  }
  get width() {
    const t30 = this.view?.width ?? 0;
    if (0 === t30) return t30;
    const o29 = this._getViewPadding(), { left: e28, right: n33 } = o29;
    return Math.max(t30 - e28 - n33, 0);
  }
  add(t30, o29) {
    let e28, n33, i25;
    if (Array.isArray(t30)) return void t30.forEach((t31) => this.add(t31, o29));
    const r33 = b7(t30);
    r33 && ({ index: e28, position: o29, component: t30, key: n33 } = r33), o29 && "object" == typeof o29 && ({ index: e28, key: n33, position: o29, internal: i25 } = o29), !t30 || o29 && !this._isValidPosition(o29) || this._add(t30, o29, e28, n33, i25);
  }
  remove(t30, o29) {
    if (!t30) return;
    if (Array.isArray(t30)) return t30.map((t31) => this.remove(t31, o29));
    const e28 = this._find(t30);
    if (e28) {
      if (this._componentMap.has(e28) && this._componentMap.get(e28)?.key !== o29) return;
      const t31 = this._components.indexOf(e28), n33 = e28.node.parentNode;
      return n33?.removeChild(e28.node), this._componentMap.delete(e28), e28.widget?.removeHandlesReference(this._removeWidgetHandleKey), this._components.splice(t31, 1)[0];
    }
  }
  empty(t30, o29 = { removeInternal: false }) {
    if (Array.isArray(t30)) {
      for (const e29 of t30) this.empty(e29, o29);
      return;
    }
    const e28 = this._positionNameToContainerLookup[t30 ?? "manual"], n33 = Array.prototype.slice.call(e28.children).map((t31) => this._findByNode(t31)).filter((t31) => {
      if (null == t31) return false;
      return !(this._componentMap.get(t31)?.internal ?? false) || o29.removeInternal;
    });
    for (const i25 of n33) this.remove(i25);
  }
  move(t30, o29) {
    if (Array.isArray(t30) && t30.forEach((t31) => this.move(t31, o29)), !t30) return;
    let e28;
    const n33 = b7(t30) || b7(o29);
    if (n33 && (e28 = n33.index, o29 = n33.position, t30 = n33.component || t30), o29 && !this._isValidPosition(o29)) return;
    const i25 = this.remove(t30);
    i25 && this.add(i25, { position: o29, index: e28 });
  }
  find(t30) {
    if (!t30) return null;
    const o29 = this._findById(t30);
    return o29 && (o29.widget || o29.node);
  }
  getComponents(t30, o29 = { includeInternal: false }) {
    return t30 ? Array.isArray(t30) ? t30.flatMap((t31) => this._getComponentsAtPosition(t31, o29)) : this._getComponentsAtPosition(t30, o29) : this._components.filter((t31) => o29.includeInternal || !this._componentMap.get(t31)?.internal).map(({ widget: t31, node: o30 }) => t31 ?? o30);
  }
  getPosition(t30) {
    for (const o29 in this._positionNameToContainerLookup) {
      if (this._positionNameToContainerLookup[o29].contains(t30)) return o29;
    }
    return null;
  }
  _add(t30, e28, n33, r33, s31) {
    t30 instanceof m19 || (t30 = new m19({ node: t30 }));
    const { widget: a27 } = t30;
    null != a27 && a27 instanceof g2 && a27.addHandles(e(() => {
      queueMicrotask(() => this.remove(t30));
    }), this._removeWidgetHandleKey), this._place({ component: t30, position: e28, index: n33 }), this._components.push(t30), this._componentMap.set(t30, { key: r33, internal: s31 });
  }
  _find(t30) {
    return t30 ? t30 instanceof m19 ? this._findByComponent(t30) : "string" == typeof t30 ? this._findById(t30) : this._findByNode(t30.domNode || t30) : null;
  }
  _getViewPadding() {
    return this.view?.padding ?? f15;
  }
  _attachContainers(t30) {
    t30.appendChild(this._innerContainer), t30.appendChild(this._manualContainer);
  }
  _initContainers() {
    const t30 = document.createElement("div");
    t30.classList.add(y9.innerContainer, y9.cornerContainer);
    const o29 = document.createElement("div");
    o29.classList.add(y9.innerContainer, y9.manualContainer);
    const e28 = document.createElement("div");
    e28.classList.add(y9.topLeft, y9.corner), t30.appendChild(e28);
    const n33 = document.createElement("div");
    n33.classList.add(y9.topRight, y9.corner), t30.appendChild(n33);
    const i25 = document.createElement("div");
    i25.classList.add(y9.bottomLeft, y9.corner), t30.appendChild(i25);
    const r33 = document.createElement("div");
    r33.classList.add(y9.bottomRight, y9.corner), t30.appendChild(r33), this._innerContainer = t30, this._manualContainer = o29;
    const s31 = g3();
    this._cornerNameToContainerLookup = { "top-left": e28, "top-right": n33, "bottom-left": i25, "bottom-right": r33, "top-leading": s31 ? n33 : e28, "top-trailing": s31 ? e28 : n33, "bottom-leading": s31 ? r33 : i25, "bottom-trailing": s31 ? i25 : r33 }, this._positionNameToContainerLookup = __spreadValues({ manual: o29 }, this._cornerNameToContainerLookup);
  }
  _isValidPosition(t30) {
    return !!this._positionNameToContainerLookup[t30];
  }
  _place(t30) {
    const o29 = t30.position ?? "manual", { component: e28, index: n33 } = t30, i25 = this._positionNameToContainerLookup[o29], r33 = null != n33 && n33 > -1;
    if (C6(e28.widget) && e28.widget.startup(), !r33) return void i25.appendChild(e28.node);
    const s31 = Array.from(i25.children);
    if (0 === n33) {
      const { firstChild: t31 } = i25;
      return void (t31 ? t31.parentNode?.insertBefore(e28.node, t31) : i25.appendChild(e28.node));
    }
    if (n33 >= s31.length) return void i25.appendChild(e28.node);
    const a27 = s31[n33];
    a27.parentNode?.insertBefore(e28.node, a27);
  }
  _toPixelPosition(t30) {
    return { top: v8(t30.top), left: v8(t30.left), right: v8(t30.right), bottom: v8(t30.bottom) };
  }
  _findByComponent(t30) {
    return this._components.find((o29) => o29 === t30) ?? null;
  }
  _findById(t30) {
    return this._components.find(({ id: o29 }) => o29 === t30) ?? null;
  }
  _findByNode(t30) {
    return this._components.find(({ node: o29 }) => o29 === t30) ?? null;
  }
  _getComponentsAtPosition(t30, o29) {
    const n33 = this._positionNameToContainerLookup[t30];
    return Array.prototype.slice.call(n33.children).map((t31) => this._findByNode(t31)).filter(G).filter((t31) => o29.includeInternal || !this._componentMap.get(t31)?.internal).map(({ widget: t31, node: o30 }) => t31 ?? o30);
  }
};
r([m()], P6.prototype, "_locale", void 0), r([m()], P6.prototype, "container", null), r([m()], P6.prototype, "height", null), r([m({ value: _8 })], P6.prototype, "padding", null), r([s5("padding")], P6.prototype, "castPadding", null), r([m()], P6.prototype, "view", void 0), r([m()], P6.prototype, "width", null), P6 = r([a3("esri.views.ui.UI")], P6);
var L7 = P6;

// node_modules/@arcgis/core/views/3d/layers/Lyr3DWasm.js
var i24 = /* @__PURE__ */ new Map();
function r30(e28) {
  return i24.get(e28);
}

// node_modules/@arcgis/core/widgets/Attribution/AttributionViewModel.js
function f16(t30, e28) {
  return t30 && "copyright" in t30 && (!e28 || "function" == typeof t30.originOf && "user" === t30.originOf("copyright"));
}
function y10(t30, e28) {
  return t30.length !== e28.length || t30.some((t31, i25) => t31.text !== e28[i25].text);
}
function b8(t30, e28, i25) {
  if (!i25 || !e28) return;
  t30.find((t31) => t31.layerView === e28 && t31.text === i25) || t30.push({ text: i25, layerView: e28 });
}
function g15(t30) {
  return "bing-maps" === t30.type;
}
var A5 = [];
var _9 = class extends g2 {
  constructor(t30) {
    super(t30), this._clear = () => {
      this._fetchedAttributionData.clear(), this._pendingAttributions.clear(), this.removeHandles("suspension"), this.notifyChange("state");
    }, this._pendingAttributions = /* @__PURE__ */ new Set(), this._fetchedAttributionData = /* @__PURE__ */ new Map(), this.items = new V(), this.view = null, this._allLayerViewsChange = (t31) => {
      this.removeHandles("suspension"), this.removeHandles("visible-geometry-changed");
      const e28 = this.view?.allLayerViews;
      e28 && (this.addHandles(e28.map((t32) => d3(() => [t32.suspended, t32.layer?.attributionVisible], () => this._updateAttributionItems())).toArray(), "suspension"), e28.forEach((t32) => {
        "esri.views.3d.layers.Tiles3DLayerView3D" === t32.declaredClass && this.addHandles(t32.on("visible-geometry-changed", () => this._updateAttributionItems()), "visible-geometry-changed");
      })), t31?.removed && t31.removed.forEach((t32) => {
        this._pendingAttributions.delete(t32), this._fetchedAttributionData.delete(t32);
      }), this._updateAttributionItems();
    }, this.addHandles([v(() => this.view?.allLayerViews, "change", (t31) => this._allLayerViewsChange(t31), { onListenerAdd: () => this._allLayerViewsChange(), onListenerRemove: this._clear }), p3(() => true === this.view?.stationary, () => this._updateAttributionItems())]);
  }
  destroy() {
    this.view = null, this._fetchedAttributionData.clear(), this._pendingAttributions.clear(), this.items.removeAll();
  }
  get state() {
    return this.view?.ready ? this._pendingAttributions.size > 0 ? "loading" : "ready" : "disabled";
  }
  _updateAttributionItems() {
    const t30 = this.view, e28 = t30?.allLayerViews;
    if (A5.length = 0, !t30 || !e28) return void this._clear();
    e28.forEach((e29) => {
      if (e29.suspended || !e29.layer?.attributionVisible) return;
      const i26 = e29.layer;
      if (f16(i26, "user")) return void b8(A5, e29, i26.copyright);
      if (i26.hasAttributionData) {
        if (this._fetchedAttributionData.has(e29)) {
          const r34 = this._fetchedAttributionData.get(e29);
          return void (r34 ? b8(A5, e29, this._getDynamicAttribution(r34, t30, i26)) : f16(i26) && b8(A5, e29, i26.copyright));
        }
        return void this._fetchAttributionData(e29);
      }
      const r33 = "portalItem" in i26 ? i26.portalItem?.accessInformation : void 0;
      b8(A5, e29, r33 || i26.copyright);
    });
    const i25 = e28.find((t31) => "integrated-mesh-3dtiles" === t31.layer?.type);
    if (this.view && i25) {
      const t31 = r30(this.view);
      if (t31) {
        const e29 = t31.getAttributionText();
        for (let t32 = 0; t32 < e29.length; ++t32) b8(A5, i25, e29[t32]);
      }
    }
    y10(this.items, A5) && (this.items.removeAll(), this.items.addMany(A5)), A5.length = 0, this.notifyChange("state");
  }
  _fetchAttributionData(t30) {
    return __async(this, null, function* () {
      if (this._pendingAttributions.has(t30)) return;
      this._pendingAttributions.add(t30);
      const e28 = yield _(t30.layer.fetchAttributionData());
      if (this._pendingAttributions.has(t30)) {
        const i25 = e28.ok ? this._createContributionIndex(e28.value, g15(t30.layer)) : null;
        this._pendingAttributions.delete(t30), this._fetchedAttributionData.set(t30, i25);
      }
      this._updateAttributionItems();
    });
  }
  _createContributionIndex(t30, e28) {
    const i25 = t30.contributors, r33 = {};
    if (!i25) return r33;
    for (let s31 = 0; s31 < i25.length; s31++) {
      const t31 = i25[s31], o29 = t31.coverageAreas;
      if (!o29) return;
      for (const i26 of o29) {
        const o30 = i26.bbox, n33 = i26.zoomMin - (e28 && i26.zoomMin ? 1 : 0), a27 = i26.zoomMax - (e28 && i26.zoomMax ? 1 : 0), c29 = new w2({ xmin: o30[1], ymin: o30[0], xmax: o30[3], ymax: o30[2], spatialReference: g4.WGS84 }), u17 = { extent: j(c29), attribution: t31.attribution || "", score: null != i26.score ? i26.score : 100, id: s31 };
        for (let t32 = n33; t32 <= a27; t32++) r33[t32] ??= [], r33[t32].push(u17);
      }
    }
    return r33.maxKey = Math.max.apply(null, Object.keys(r33)), r33;
  }
  _getDynamicAttribution(t30, e28, i25) {
    const { extent: r33, scale: s31 } = e28;
    let o29 = i25.tileInfo?.scaleToZoom(s31) ?? 0;
    if (o29 = Math.min(t30.maxKey ?? 0, Math.round(o29)), !r33 || null == o29 || o29 <= -1) return "";
    const n33 = t30[o29], a27 = y(r33.center.clone().normalize(), g4.WebMercator), c29 = /* @__PURE__ */ new Set();
    return n33 ? n33.filter((t31) => {
      const e29 = t31.id, i26 = !c29.has(e29) && a27 && t31.extent && t5(t31.extent, a27);
      return i26 && c29.add(e29), i26;
    }).sort((t31, e29) => e29.score - t31.score || t31.objectId - e29.objectId).map((t31) => t31.attribution).join(", ") : "";
  }
};
r([m({ readOnly: true, type: V })], _9.prototype, "items", void 0), r([m({ readOnly: true })], _9.prototype, "state", null), r([m()], _9.prototype, "view", void 0), _9 = r([a3("esri.widgets.Attribution.AttributionViewModel")], _9);
var v9 = _9;

// node_modules/@arcgis/core/widgets/Attribution.js
var c22 = "esri-attribution";
var a25 = { base: c22, poweredBy: `${c22}__powered-by`, sources: `${c22}__sources`, open: `${c22}--open`, sourcesOpen: `${c22}__sources--open`, link: `${c22}__link` };
var h18 = class extends O {
  constructor(e28, t30) {
    super(e28, t30), this._isOpen = false, this._attributionTextOverflowed = false, this._prevSourceNodeHeight = 0, this._resizeObserver = new ResizeObserver((e29) => e29.forEach(({ target: e30 }) => this._checkSourceTextOverflow(e30))), this.itemDelimiter = " | ", this.messages = null, this.viewModel = new v9();
  }
  initialize() {
    this.addHandles(v(() => this.viewModel?.items, "change", () => this.scheduleRender()));
  }
  destroy() {
    this._resizeObserver?.disconnect();
  }
  get _isInteractive() {
    return this._isOpen || this._attributionTextOverflowed;
  }
  get attributionText() {
    return this.viewModel.items.reduce((e28, t30) => (e28.includes(t30.text) || e28.push(t30.text), e28), []).join(this.itemDelimiter);
  }
  get icon() {
    return "description";
  }
  set icon(e28) {
    this._overrideIfSome("icon", e28);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e28) {
    this._overrideIfSome("label", e28);
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e28) {
    this.viewModel.view = e28;
  }
  render() {
    const e28 = { [a25.open]: this._isOpen };
    return n5("div", { bind: this, class: this.classes(a25.base, e9.widget, e28), dir: "ltr", onclick: this._toggleState, onkeydown: this._toggleState }, this._renderSourcesNode(), this._renderPoweredBy());
  }
  _renderPoweredBy() {
    return n5("div", { class: a25.poweredBy }, "Powered by", " ", n5("a", { class: a25.link, href: "https://www.esri.com/", rel: "noreferrer", target: "_blank" }, "Esri"));
  }
  _renderSourcesNode() {
    const e28 = this._isOpen, t30 = this._isInteractive, i25 = t30 ? 0 : void 0, { attributionText: r33 } = this, s31 = { [a25.sourcesOpen]: e28, [e9.interactive]: t30 };
    return n5("div", { afterCreate: this._afterSourcesNodeCreate, bind: this, class: this.classes(a25.sources, s31), innerHTML: r33, tabIndex: i25 });
  }
  _afterSourcesNodeCreate(e28) {
    this._prevSourceNodeHeight = e28.clientWidth, this._resizeObserver.observe(e28);
  }
  _checkSourceTextOverflow(e28) {
    let t30 = false;
    const { clientHeight: i25, clientWidth: r33, scrollWidth: s31 } = e28, o29 = s31 > r33, n33 = this._attributionTextOverflowed !== o29;
    if (this._attributionTextOverflowed = o29, n33 && (t30 = true), this._isOpen) {
      const e29 = i25 < this._prevSourceNodeHeight;
      this._prevSourceNodeHeight = i25, e29 && (this._isOpen = false, t30 = true);
    }
    t30 && this.scheduleRender();
  }
  _toggleState() {
    this._isInteractive && (this._isOpen = !this._isOpen);
  }
};
r([m()], h18.prototype, "_isOpen", void 0), r([m()], h18.prototype, "_isInteractive", null), r([m()], h18.prototype, "_attributionTextOverflowed", void 0), r([m()], h18.prototype, "_prevSourceNodeHeight", void 0), r([m({ readOnly: true, dependsOn: ["viewModel.items.length", "itemDelimiter"] })], h18.prototype, "attributionText", null), r([m()], h18.prototype, "icon", null), r([m()], h18.prototype, "itemDelimiter", void 0), r([m()], h18.prototype, "label", null), r([m(), e4("esri/widgets/Attribution/t9n/Attribution")], h18.prototype, "messages", void 0), r([m()], h18.prototype, "view", null), r([m({ type: v9 })], h18.prototype, "viewModel", void 0), r([t10()], h18.prototype, "_toggleState", null), h18 = r([a3("esri.widgets.Attribution")], h18);
var u15 = h18;

// node_modules/@arcgis/core/widgets/Compass/utils.js
function e26(e28) {
  return e28?.spatialReference?.isWebMercator || e28?.spatialReference?.isGeographic || false;
}

// node_modules/@arcgis/core/widgets/Compass/CompassViewModel.js
var h19 = class extends t11(g2) {
  constructor(t30) {
    super(t30), this.orientation = { x: 0, y: 0, z: 0 }, this.view = null, this._updateForCamera = this._updateForCamera.bind(this), this._updateForRotation = this._updateForRotation.bind(this), this._updateRotationWatcher = this._updateRotationWatcher.bind(this);
  }
  initialize() {
    this._watchForView(P);
  }
  destroy() {
    this.view = null;
  }
  get canShowNorth() {
    return e26(this.view);
  }
  get state() {
    return !this.view?.ready || "2d" === this.view.type && !this.view.constraints.rotationEnabled ? "disabled" : this.canShowNorth ? "compass" : "rotation";
  }
  reset() {
    this.view?.ready && ("2d" === this.view?.type ? this.callGoTo({ target: { rotation: 0 }, options: { animationMode: "always", duration: r13() } }) : this.callGoTo({ target: { heading: 0 } }));
  }
  _updateForRotation(t30) {
    null != t30 && this._set("orientation", { z: t30 });
  }
  _updateForCamera(t30) {
    if (!t30) return;
    const o29 = -t30.heading;
    this._set("orientation", { x: 0, y: 0, z: o29 });
  }
  _updateRotationWatcher(t30) {
    this.removeAllHandles(), this._watchForView(), t30 && this.addHandles("2d" === t30.type ? d3(() => t30?.rotation, this._updateForRotation, P) : d3(() => t30?.camera, this._updateForCamera, P));
  }
  _watchForView(t30) {
    this.addHandles(d3(() => this.view, this._updateRotationWatcher, t30));
  }
};
r([m({ readOnly: true })], h19.prototype, "canShowNorth", null), r([m({ readOnly: true })], h19.prototype, "orientation", void 0), r([m({ readOnly: true })], h19.prototype, "state", null), r([m()], h19.prototype, "view", void 0), h19 = r([a3("esri.widgets.Compass.CompassViewModel")], h19);
var p26 = h19;

// node_modules/@arcgis/core/widgets/Compass/css.js
var n32 = "esri-compass";
var o27 = { base: n32, iconContainer: `${n32}__icon-container` };

// node_modules/@arcgis/core/widgets/Compass.js
var c23 = class extends O {
  constructor(e28, t30) {
    super(e28, t30), this.messages = null, this.viewModel = new p26(), this._reset = () => {
      this.viewModel.reset();
    }, this._toRotationTransform = (e29) => ({ transform: `rotateZ(${e29.z}deg)` });
  }
  loadDependencies() {
    return c3({ button: () => import("./calcite-button-FV2OB3GT.js"), icon: () => import("./calcite-icon-TH7JL242.js") });
  }
  get goToOverride() {
    return this.viewModel.goToOverride;
  }
  set goToOverride(e28) {
    this.viewModel.goToOverride = e28;
  }
  get icon() {
    return "rotation" === this.viewModel.state ? "arrow-up" : "compass-needle";
  }
  set icon(e28) {
    this._overrideIfSome("icon", e28);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e28) {
    this._overrideIfSome("label", e28);
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e28) {
    this.viewModel.view = e28;
  }
  reset() {
    return this.viewModel.reset();
  }
  render() {
    const { orientation: e28, state: t30 } = this.viewModel, { messages: o29 } = this;
    return n5("div", { class: this.classes(o27.base, e9.widget) }, n5("calcite-button", { class: e9.widgetButton, disabled: "disabled" === t30, kind: "neutral", label: o29.reset, onclick: this._reset, round: true, scale: "s", title: o29.reset }, n5("div", { "aria-hidden": "true", class: o27.iconContainer, title: o29.reset }, n5("calcite-icon", { icon: this.icon, styles: this._toRotationTransform(e28) }))));
  }
};
r([m()], c23.prototype, "goToOverride", null), r([m()], c23.prototype, "icon", null), r([m()], c23.prototype, "label", null), r([m(), e4("esri/widgets/Compass/t9n/Compass")], c23.prototype, "messages", void 0), r([m()], c23.prototype, "view", null), r([m({ type: p26 })], c23.prototype, "viewModel", void 0), c23 = r([a3("esri.widgets.Compass")], c23);
var d16 = c23;

// node_modules/@arcgis/core/widgets/NavigationToggle/css.js
var o28 = "esri-navigation-toggle";
var t28 = { base: o28, isLayoutHorizontal: `${o28}--horizontal` };

// node_modules/@arcgis/core/widgets/NavigationToggle/NavigationToggleViewModel.js
var s29 = class extends g2 {
  constructor(t30) {
    super(t30), this._navigationMode = "pan", this.view = null;
  }
  initialize() {
    this.addHandles(p3(() => this.view?.navigation?.actionMap, () => this._updateNavigationActionMap()));
  }
  destroy() {
    this.view = null;
  }
  get state() {
    return this.view?.ready && "3d" === this.view?.type ? "ready" : "disabled";
  }
  get navigationMode() {
    return this._navigationMode;
  }
  set navigationMode(t30) {
    this._navigationMode = t30, this._updateNavigationActionMap();
  }
  toggle() {
    "disabled" !== this.state && (this.navigationMode = "pan" !== this.navigationMode ? "pan" : "rotate");
  }
  _updateNavigationActionMap() {
    const t30 = this.view?.navigation?.actionMap;
    if (!t30) return;
    const o29 = "pan" === this._navigationMode;
    t30.dragPrimary = o29 ? "pan" : "rotate", t30.dragSecondary = o29 ? "rotate" : "pan";
  }
};
r([m({ readOnly: true })], s29.prototype, "state", null), r([m()], s29.prototype, "_navigationMode", void 0), r([m()], s29.prototype, "view", void 0), s29 = r([a3("esri.widgets.NavigationToggle.NavigationToggleViewModel")], s29);
var r31 = s29;

// node_modules/@arcgis/core/widgets/NavigationToggle.js
var c24 = class extends O {
  constructor(t30, e28) {
    super(t30, e28), this.messages = null, this.viewModel = new r31(), this.toggle = () => this.viewModel.toggle(), this._panButton = null, this._rotateButton = null, this._toggle = () => {
      const t31 = "pan" === this.viewModel?.navigationMode ? this._rotateButton : this._panButton;
      T(t31), this.toggle();
    };
  }
  loadDependencies() {
    return c3({ button: () => import("./calcite-button-FV2OB3GT.js") });
  }
  get icon() {
    return "move";
  }
  set icon(t30) {
    this._overrideIfSome("icon", t30);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(t30) {
    this._overrideIfSome("label", t30);
  }
  set layout(t30) {
    "horizontal" !== t30 && (t30 = "vertical"), this._set("layout", t30);
  }
  get view() {
    return this.viewModel.view;
  }
  set view(t30) {
    this.viewModel.view = t30;
  }
  render() {
    const t30 = "disabled" === this.viewModel?.state, e28 = "pan" === this.viewModel?.navigationMode, o29 = this.messages.toggle;
    return n5("div", { class: this.classes(t28.base, e9.widget, { [t28.isLayoutHorizontal]: "horizontal" === this.layout }) }, n5("calcite-button", { afterCreate: (t31) => {
      this._panButton = t31;
    }, appearance: e28 ? "outline-fill" : "solid", class: e9.widgetButton, disabled: t30, iconStart: "move", kind: "neutral", label: o29, onclick: this._toggle, tabIndex: e28 ? void 0 : -1, title: o29 }), n5("calcite-button", { afterCreate: (t31) => {
      this._rotateButton = t31;
    }, appearance: e28 ? "solid" : "outline-fill", class: e9.widgetButton, disabled: t30, iconStart: "rotate", kind: "neutral", label: o29, onclick: this._toggle, tabIndex: e28 ? -1 : void 0, title: o29 }));
  }
};
r([m()], c24.prototype, "icon", null), r([m()], c24.prototype, "label", null), r([m({ value: "vertical" })], c24.prototype, "layout", null), r([m(), e4("esri/widgets/NavigationToggle/t9n/NavigationToggle")], c24.prototype, "messages", void 0), r([m()], c24.prototype, "view", null), r([m({ type: r31 })], c24.prototype, "viewModel", void 0), c24 = r([a3("esri.widgets.NavigationToggle")], c24);
var d17 = c24;

// node_modules/@arcgis/core/widgets/Zoom/ZoomConditions2D.js
var r32 = class extends g2 {
  get canZoomIn() {
    const o29 = this.view?.ready;
    if (!o29) return false;
    const t30 = this.view?.constraints?.effectiveMaxScale;
    return 0 === t30 || this._scale > t30;
  }
  get canZoomOut() {
    const { view: o29 } = this, t30 = o29?.ready;
    if (!t30) return false;
    const e28 = o29.constraints?.effectiveMinScale;
    return 0 === e28 || this._scale < e28;
  }
  get _scale() {
    const o29 = this.view?.animation?.target;
    return (o29 && "then" in o29 ? void 0 : o29?.scale) ?? this.view?.scale ?? 0;
  }
};
r([m({ readOnly: true })], r32.prototype, "canZoomIn", null), r([m({ readOnly: true })], r32.prototype, "canZoomOut", null), r([m()], r32.prototype, "view", void 0), r([m()], r32.prototype, "_scale", null), r32 = r([a3("esri.widgets.Zoom.ZoomConditions2D")], r32);
var c25 = r32;

// node_modules/@arcgis/core/widgets/Zoom/ZoomConditions3D.js
var s30 = class extends g2 {
  get canZoomIn() {
    return !!this.view.ready;
  }
  get canZoomOut() {
    return !!this.view.ready;
  }
};
r([m({ readOnly: true })], s30.prototype, "canZoomIn", null), r([m({ readOnly: true })], s30.prototype, "canZoomOut", null), r([m()], s30.prototype, "view", void 0), s30 = r([a3("esri.widgets.Zoom.ZoomConditions3D")], s30);
var c26 = s30;

// node_modules/@arcgis/core/widgets/Zoom/ZoomViewModel.js
var m20 = class extends g2 {
  constructor(o29) {
    super(o29);
  }
  destroy() {
    this.view = null;
  }
  get canZoomIn() {
    return null != this._zoomConditions && this._zoomConditions.canZoomIn;
  }
  get canZoomOut() {
    return null != this._zoomConditions && this._zoomConditions?.canZoomOut;
  }
  get state() {
    return this.view?.ready ? "ready" : "disabled";
  }
  set view(o29) {
    o29 ? "2d" === o29.type ? this._zoomConditions = new c25({ view: o29 }) : "3d" === o29.type && (this._zoomConditions = new c26({ view: o29 })) : this._zoomConditions = null, this._set("view", o29);
  }
  zoomIn() {
    const o29 = this.view;
    this.canZoomIn && o29 && ("2d" === o29.type ? o29.mapViewNavigation.zoomIn() : d(o29.goTo({ zoomFactor: 2 })));
  }
  zoomOut() {
    const o29 = this.view;
    this.canZoomOut && o29 && ("2d" === o29.type ? o29.mapViewNavigation.zoomOut() : d(o29.goTo({ zoomFactor: 0.5 })));
  }
};
r([m()], m20.prototype, "_zoomConditions", void 0), r([m()], m20.prototype, "canZoomIn", null), r([m()], m20.prototype, "canZoomOut", null), r([m({ readOnly: true })], m20.prototype, "state", null), r([m()], m20.prototype, "view", null), m20 = r([a3("esri.widgets.Zoom.ZoomViewModel")], m20);
var p27 = m20;

// node_modules/@arcgis/core/widgets/Zoom.js
var m21 = { base: "esri-zoom", horizontalLayout: "esri-zoom--horizontal" };
var c27 = class extends O {
  constructor(o29, t30) {
    super(o29, t30), this.messages = null, this.viewModel = new p27(), this.zoomIn = () => this.viewModel.zoomIn(), this.zoomOut = () => this.viewModel.zoomOut();
  }
  loadDependencies() {
    return c3({ button: () => import("./calcite-button-FV2OB3GT.js") });
  }
  get icon() {
    return "magnifying-glass-plus";
  }
  set icon(o29) {
    this._overrideIfSome("icon", o29);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(o29) {
    this._overrideIfSome("label", o29);
  }
  set layout(o29) {
    "horizontal" !== o29 && (o29 = "vertical"), this._set("layout", o29);
  }
  set view(o29) {
    this.viewModel.view = o29;
  }
  get view() {
    return this.viewModel.view;
  }
  render() {
    const o29 = { [m21.horizontalLayout]: "horizontal" === this.layout }, { canZoomIn: t30, canZoomOut: e28 } = this.viewModel, { zoomIn: s31, zoomOut: i25 } = this.messages;
    return n5("div", { class: this.classes(m21.base, e9.widget, o29) }, n5("calcite-button", { class: e9.widgetButton, disabled: !t30, iconStart: "plus", kind: "neutral", label: s31, onclick: this.zoomIn, title: s31 }), n5("calcite-button", { class: e9.widgetButton, disabled: !e28, iconStart: "minus", kind: "neutral", label: i25, onclick: this.zoomOut, title: i25 }));
  }
};
r([m()], c27.prototype, "icon", null), r([m()], c27.prototype, "label", null), r([m({ value: "vertical" })], c27.prototype, "layout", null), r([m(), e4("esri/widgets/Zoom/t9n/Zoom")], c27.prototype, "messages", void 0), r([m()], c27.prototype, "view", null), r([m({ type: p27 })], c27.prototype, "viewModel", void 0), c27 = r([a3("esri.widgets.Zoom")], c27);
var p28 = c27;

// node_modules/@arcgis/core/views/ui/DefaultUI.js
function m22(t30) {
  return void 0 !== t30?.view;
}
var h20 = class extends L7 {
  constructor(t30) {
    super(t30), this._defaultPositionLookup = { attribution: "manual", compass: "top-left", "navigation-toggle": "top-left", zoom: "top-left" }, this.components = [], this._updateViewAwareWidgets = (t31) => {
      this.components.forEach((o29) => {
        const e28 = this._find(o29), i25 = e28?.widget;
        m22(i25) && (i25.view = t31);
      });
    }, this._componentsWatcher = (t31, o29) => {
      this._removeComponents(o29), this._addComponents(t31), this._adjustPadding(t31);
    };
  }
  initialize() {
    this.addHandles([d3(() => this.components, this._componentsWatcher, P), d3(() => this.view, this._updateViewAwareWidgets, P)]);
  }
  _add(t30, o29, e28, i25, s31) {
    let r33 = t30;
    if ("string" == typeof t30 && this._defaultPositionLookup[t30]) {
      if (this._find(t30)) return;
      r33 = this._createComponent(t30);
    }
    super._add(r33, o29, e28, i25, s31);
  }
  _removeComponents(t30) {
    t30.forEach((t31) => {
      const o29 = this._find(t31);
      o29 && (this.remove(o29), o29.destroy());
    });
  }
  _adjustPadding(t30) {
    if (!t30.includes("attribution") && !this._isOverridden("padding")) {
      const { top: t31 } = this.padding;
      this.padding = t31;
    }
  }
  _addComponents(t30) {
    this.constructed && t30.forEach((t31) => this.add(this._createComponent(t31), this._defaultPositionLookup[t31]));
  }
  _createComponent(t30) {
    const o29 = this._createWidget(t30);
    return new m19({ id: t30, node: o29 });
  }
  _createWidget(t30) {
    const o29 = this.view;
    switch (t30) {
      case "attribution":
        return new u15({ view: o29 });
      case "compass":
        return new d16({ view: o29 });
      case "navigation-toggle":
        return new d17({ view: o29 });
      case "zoom":
        return new p28({ view: o29 });
    }
  }
};
r([m()], h20.prototype, "components", void 0), h20 = r([a3("esri.views.ui.DefaultUI")], h20);
var u16 = h20;

// node_modules/@arcgis/core/views/ui/2d/DefaultUI2D.js
var e27 = class extends u16 {
  constructor(o29) {
    super(o29), this.components = ["attribution", "zoom"];
  }
};
r([m()], e27.prototype, "components", void 0), e27 = r([a3("esri.views.ui.2d.DefaultUI2D")], e27);
var c28 = e27;

// node_modules/@arcgis/core/webmap/background/ColorBackground.js
var p29;
var a26 = p29 = class extends S2 {
  constructor(o29) {
    super(o29), this.color = new h4([0, 0, 0, 1]);
  }
  clone() {
    return new p29(a2({ color: this.color }));
  }
};
r([m({ type: h4, json: { write: true } })], a26.prototype, "color", void 0), a26 = p29 = r([a3("esri.webmap.background.ColorBackground")], a26);
var m23 = a26;

// node_modules/@arcgis/core/views/View2D.js
var F3;
var H3;
var B3;
var Z2;
var J2;
var K3;
var Q2;
function X() {
  return __async(this, null, function* () {
    const [, { GraphicsView2D: e28, GraphicContainer: t30, LabelManager: i25, MapViewNavigation: r33, MagnifierView2D: s31, GridView2D: a27, Stage: n33 }] = yield Promise.all([import("./webglDeps-S6GV76SY.js"), import("./mapViewDeps-IDK4SUKW.js")]);
    H3 = e28, B3 = t30, Z2 = i25, J2 = r33, K3 = s31, Q2 = a27, F3 = n33;
  });
}
var Y2 = class extends u11(o11(w4(C2(K2)))) {
  constructor(e28) {
    super(e28), this._magnifierView = null, this._gridView = null, this.stage = null, this._resolveWhenReady = [], this.rootLayerViews = new n7({ getCollections: () => [this.basemapView?.baseLayerViews, this.layerViews, this.basemapView?.referenceLayerViews], getChildrenFunction: () => null }), this.featuresTilingScheme = null, this.graphicsView = null, this.labelManager = null, this.navigation = new l10({ actionMap: new p15({ dragTertiary: "none" }) }), this.renderingOptions = { samplingMode: "dynamic", edgeLabelsVisible: true, labelsAnimationTime: 125, labelCollisionsEnabled: true }, this.supersampleScreenshotsEnabled = true, this.supportsGround = false, this.floors = new V(), this.grid = null, this.map = null, this.spatialReferenceLocked = false, this.timeline = new e13(), this.type = "2d", this.view2dType = null, this.ui = new c28(), this.test = { takeScreenshot: (e29) => __async(this, null, function* () {
      return r29(this._getScreenshotView(e29), e29);
    }) }, this.padding = { top: 0, right: 0, bottom: 0, left: 0 }, m7();
  }
  destroy() {
    this.layerViewManager.clear(), this._set("preconditionsReady", false), this.frameTask = u(this.frameTask), this.goToManager.destroy(), this.rootLayerViews.destroy(), this.inputManager.destroy(), this._set("inputManager", null);
  }
  get graphicsTileStore() {
    return new u13(this.featuresTilingScheme);
  }
  get constraintsInfo() {
    const e28 = this.defaultsFromMap?.tileInfo, t30 = this.spatialReference;
    return { lods: e28?.spatialReference?.equals(t30) ? e28.lods : null, spatialReference: t30 };
  }
  get initialExtentRequired() {
    if (!this.stateManager) return false;
    const { scale: e28, constraints: t30, center: i25, viewpoint: r33, extent: s31 } = this;
    let a27 = this.zoom;
    return !(this.map && "initialViewProperties" in this.map && this.map.initialViewProperties?.viewpoint) && (!s31 && (t30?.effectiveLODs || (a27 = -1), (!i25 || 0 === e28 && -1 === a27) && (null == r33?.targetGeometry || "extent" !== r33.targetGeometry.type && !r33.scale)));
  }
  get defaultsFromMapSettings() {
    return { required: { extent: false, heightModelInfo: false, tileInfo: true }, requiresExtentInSpatialReference: this.spatialReferenceLocked };
  }
  get scheduler() {
    return this.frameTask.scheduler;
  }
  get typeSpecificPreconditionsReady() {
    const e28 = this._getDefaultViewpoint();
    if (!e28) return false;
    const t30 = e28.targetGeometry, i25 = this.spatialReference;
    return U(t30.spatialReference, i25);
  }
  get background() {
    return r14(this.map) ? this.map.initialViewProperties.background : null;
  }
  set background(e28) {
    this._override("background", e28);
  }
  get center() {
    return this.stateManager?.center ?? null;
  }
  set center(e28) {
    this.stateManager.center = e28;
  }
  get highlightOptions() {
    return t12(this);
  }
  set highlightOptions(e28) {
    g7(this, e28);
  }
  get padding() {
    return this.stateManager?.padding;
  }
  set padding(e28) {
    this.stateManager && (this.stateManager.padding = e28);
  }
  get rendering() {
    return this.stage?.renderRequested ?? false;
  }
  get resolution() {
    return this.stateManager.resolution ?? 0;
  }
  get scale() {
    return this.stateManager?.scale ?? 0;
  }
  set scale(e28) {
    this.stateManager && (this.stateManager.scale = e28);
  }
  get tileInfo() {
    return this.featuresTilingScheme?.tileInfo;
  }
  get updating() {
    const e28 = !(!this.magnifier.visible || null === this.magnifier.position || !this._magnifierView?.updatingHandles.updating), t30 = !this.destroyed && (!this.layerViewManager || !this.labelManager || !this.graphicsView || true === this.layerViewManager.updating || true === this.labelManager.updating || true === this.graphicsView.updating || this.allLayerViews.some((e29) => !e29.destroyed && !("layerViews" in e29) && true === e29.updating) || e28);
    if (has("esri-2d-log-updating")) {
      const i25 = this.allLayerViews.reduce((e29, t31) => __spreadProps(__spreadValues({}, e29), { [`${t31.layer.id}(${t31.layer.type})`]: !t31.destroyed && !("layerViews" in t31) && t31.updating }), {});
      console.log(`Updating MapView: ${t30}
-> Null LayerViewManager: ${!this.layerViewManager}
-> Null LabelManager: ${!this.labelManager}
-> Null GraphicsView: ${!this.graphicsView}
-> layerViewManager.updating: ${this.layerViewManager?.updating}
-> labelManager.updating: ${this.labelManager?.updating}
-> graphicsView.updating: ${this.graphicsView?.updating}
-> allLayerViews: ${JSON.stringify(i25)}
-> updatingMagnifier: ${e28}
`);
    }
    return t30;
  }
  get visibleArea() {
    const e28 = this.stateManager.visibleArea;
    return e28 ? new j3({ rings: [e28.map((e29) => [e29[0], e29[1]])], spatialReference: this.spatialReference }) : e28;
  }
  get zoom() {
    return this.stateManager.zoom ?? -1;
  }
  set zoom(e28) {
    this.stateManager.zoom = e28;
  }
  get navigating() {
    return this.mapViewNavigation?.interacting ?? false;
  }
  hitTest(e28, t30) {
    return __async(this, null, function* () {
      return s28(this, e28, t30);
    });
  }
  takeScreenshot(e28) {
    return __async(this, null, function* () {
      return o26(this._getScreenshotView(e28), e28);
    });
  }
  toMap(e28) {
    if (!this.ready) return null;
    const t30 = o10(e28) ? r11(this, e28) : e28;
    return this.stateManager.toMap(t30);
  }
  toScreen(e28, t30) {
    return this.stateManager.toScreen(e28, t30);
  }
  whenLayerView(e28) {
    return super.whenLayerView(e28);
  }
  graphicChanged(e28) {
    if (this.graphicsView) {
      this.graphicsView.graphicUpdateHandler(e28);
    }
  }
  whenReady() {
    return new Promise((e28) => {
      this.ready ? e28(this) : this._resolveWhenReady.push(e28);
    });
  }
  forceDOMReadyCycle() {
    this.forceReadyCycle();
  }
  getDefaultSpatialReference() {
    return this.map && "initialViewProperties" in this.map && this.map.initialViewProperties.spatialReference || this.defaultsFromMap?.spatialReference || null;
  }
  getDefaultTimeZone() {
    return r14(this.map) ? this.map.initialViewProperties.timeZone : null;
  }
  getDefaultTimeExtent() {
    return r14(this.map) ? this.map.initialViewProperties.timeExtent : null;
  }
  hasLayerViewModule(e28) {
    return l18.hasLayerViewModule(e28);
  }
  importLayerView(e28) {
    return l18.importLayerView(e28);
  }
  pixelSizeAt() {
    return this.ready ? this.resolution : (n.getLogger(this).error("#pixelSizeAt()", "Map view cannot be used before it is ready"), null);
  }
  popupHitTest(e28) {
    return __async(this, null, function* () {
      const t30 = this.toMap(e28), i25 = yield this.hitTest(e28), r33 = this.allLayerViews.toArray().filter((i26) => i26.clips.every((i27) => m8(this, i27, e28, t30))).reverse(), s31 = new globalThis.Map(r33.map((e29) => [e29.layer.uid, e29])), a27 = [];
      let n33 = 0, o29 = 0;
      for (; n33 < i25.results.length || o29 < r33.length; ) {
        const e29 = i25.results.at(n33);
        if (e29 && "graphic" !== e29.type) {
          ++n33;
          continue;
        }
        const l20 = s31.get((e29?.layer ?? e29?.graphic.layer)?.uid);
        if ((!e29 || l20) && o29 < r33.length && r33.at(o29) !== l20) {
          const e30 = r33.at(o29);
          "fetchPopupFeaturesAtLocation" in e30 && a27.push({ mapPoint: t30, layerView: e30 }), ++o29;
        } else e29 && (a27.push({ graphic: e29.graphic, layerView: l20 }), ++n33);
      }
      return { hits: a27, location: t30 };
    });
  }
  requestUpdate() {
    this.ready && this.frameTask.requestUpdate();
  }
  validate() {
    return __async(this, null, function* () {
      let e28 = t27(this.type);
      if (has("safari") && has("safari") < 9 && (e28 = new s("mapview:browser-not-supported", "This browser is not supported by MapView (Safari < 9)", { type: "safari", requiredVersion: 9, detectedVersion: has("safari") })), null != e28) throw n.getLogger(this).warn("#validate()", e28.message), e28;
    });
  }
  loadAsyncDependencies() {
    return X();
  }
  _getDefaultViewpoint() {
    const { constraints: e28, initialExtent: i25, map: r33, padding: s31, size: a27 } = this;
    if (!e28) return null;
    const n33 = r33 && "initialViewProperties" in r33 ? r33.initialViewProperties : void 0, o29 = this.stateManager.getUserStartupOptions(this.size), l20 = n33?.viewpoint, p31 = l20?.targetGeometry?.extent ?? i25, h21 = p31?.center, g16 = l20?.rotation ?? 0, d18 = l20?.scale || p31 && H(p31, [a27[0] - s31.left - s31.right, a27[1] - s31.top - s31.bottom]), c29 = o29.center ?? h21, u17 = o29.rotation ?? g16, m24 = o29.scale ?? d18;
    return c29 && m24 ? new m3({ targetGeometry: c29, scale: m24, rotation: u17 }) : null;
  }
  _startup() {
    this.timeline.begin("MapView Startup");
    const e28 = this._getDefaultViewpoint();
    this.stateManager.startup(e28, this.size, this.spatialReference, this.defaultsFromMap.extent?.center), this.graphics.owner = this;
    const t30 = new F3(this.surface, { canvas: this.renderCanvas, contextOptions: { disabledExtensions: this.deactivatedWebGLExtensions, debugWebGLExtensions: this.debugWebGLExtensions }, renderingOptions: this.renderingOptions, timeline: this.timeline });
    this.stage = t30, this._magnifierView = new K3(), this._magnifierView.magnifier = this.magnifier, this._gridView = new Q2();
    const i25 = new Z2({ view: this });
    this._set("labelManager", i25);
    const r33 = new x2({ view: this });
    this._set("animationManager", r33);
    const s31 = new J2({ view: this, animationManager: r33 });
    this._set("mapViewNavigation", s31), this._setupSpatialReferenceDependentProperties(), this.addHandles([this.rootLayerViews.on("change", () => this._updateStageChildren()), t30.on("webgl-error", (e29) => this.fatalError = e29.error), d3(() => this.stationary, (e29) => t30.stationary = e29, A3), d3(() => this.background, (e29) => {
      t30.backgroundColor = e29?.color, this._magnifierView.backgroundColor = e29?.color;
    }, A3), d3(() => this.magnifier, (e29) => this._magnifierView.magnifier = e29, A3), d3(() => this.grid, (e29) => this._gridView.grid = e29, A3), d3(() => this.renderingOptions, (e29) => t30.renderingOptions = e29, A3), d3(() => this.highlights.items.map((e29) => ({ name: e29.name, options: { fillColor: e29.color, haloColor: e29.haloColor, fillOpacity: e29.fillOpacity, haloOpacity: e29.haloOpacity, haloWidth: e29.haloWidth, haloBlur: e29.haloBlur } })), () => {
      t30.highlightGradient = c9(t30.highlightGradient, this.highlights.items);
    }, A3), d3(() => this.state.id, () => t30.state = this.state, A3)], "map-view"), this._updateStageChildren();
    const a27 = this._resolveWhenReady;
    this._resolveWhenReady = [], a27.forEach((e29) => e29(this)), this.timeline.end("MapView Startup"), this.frameTask.start(), this._set("ready", true);
  }
  _teardown() {
    this._destroySpatialReferenceDependentProperties(), this.removeHandles("map-view"), this.mapViewNavigation.destroy(), this._set("mapViewNavigation", null), this.animation = null, this.animationManager.destroy(), this._set("animationManager", null), this.layerViewManager.clear(), this.labelManager.destroy(), this._magnifierView.destroy(), this._gridView.destroy(), this.stage.destroy(), this.stage = null, this._set("graphicsView", null), this._magnifierView = null, this._gridView = null, this._set("labelManager", null), this._set("mapViewNavigation", null), this.graphics.owner = null, this.frameTask.stop(), this.stationaryManager.clear(), this._set("ready", false), this.stateManager.teardown();
  }
  _updateStageChildren() {
    this.stage.removeAllChildren(), this.rootLayerViews.forEach((e29) => {
      this.stage.addChild(e29.container);
    });
    const e28 = this.graphicsView;
    this.stage.addChild(e28.container), this.stage.addChild(this._magnifierView), this.stage.addChild(this._gridView);
  }
  _setupSpatialReferenceDependentProperties() {
    const e28 = new h7(z.create({ spatialReference: this.spatialReference, size: 512, numLODs: 36 }));
    this._set("featuresTilingScheme", e28);
    const t30 = new H3({ view: this, graphics: this.graphics, requestUpdateCallback: () => this.requestUpdate(), container: new B3(e28) });
    this._set("graphicsView", t30);
  }
  _destroySpatialReferenceDependentProperties() {
    const e28 = this.graphicsView;
    this._set("graphicsView", null), e28.destroy(), this._set("featuresTilingScheme", null);
  }
  _getScreenshotView(e28) {
    const { allLayerViews: t30, padding: i25, size: r33, stage: s31 } = this;
    return { allLayerViews: t30, backgroundColor: e28?.ignoreBackground ? null : this.background?.color, padding: i25, size: r33, stage: s31 };
  }
  _spatialReferenceChanged(e28) {
    if (this.ready) {
      this.frameTask.stop();
      for (const e29 of this.allLayerViews) e29.processDetach();
      this._destroySpatialReferenceDependentProperties(), this.stateManager.changeSpatialReference(e28), this.stage.state = this.state, this._setupSpatialReferenceDependentProperties();
      for (const e29 of this.allLayerViews) e29.processAttach();
      this.frameTask.requestFrame(), this.frameTask.start(), this._updateStageChildren();
    }
  }
};
Y2.type = "2d", r([m({ constructOnly: true })], Y2.prototype, "deactivatedWebGLExtensions", void 0), r([m({ constructOnly: true })], Y2.prototype, "debugWebGLExtensions", void 0), r([m({ readOnly: true })], Y2.prototype, "featuresTilingScheme", void 0), r([m({ readOnly: true })], Y2.prototype, "graphicsTileStore", null), r([m()], Y2.prototype, "graphicsView", void 0), r([m()], Y2.prototype, "constraintsInfo", null), r([m()], Y2.prototype, "initialExtentRequired", null), r([m()], Y2.prototype, "labelManager", void 0), r([m({ type: l10, nonNullable: true })], Y2.prototype, "navigation", void 0), r([m({ constructOnly: true })], Y2.prototype, "renderCanvas", void 0), r([m()], Y2.prototype, "renderingOptions", void 0), r([m({ constructOnly: true })], Y2.prototype, "supersampleScreenshotsEnabled", void 0), r([m({ readOnly: true })], Y2.prototype, "supportsGround", void 0), r([m()], Y2.prototype, "defaultsFromMapSettings", null), r([m({ readOnly: true })], Y2.prototype, "typeSpecificPreconditionsReady", null), r([m({ type: m23 })], Y2.prototype, "background", null), r([m()], Y2.prototype, "center", null), r([m({ type: V })], Y2.prototype, "floors", void 0), r([m()], Y2.prototype, "grid", void 0), r([m({ type: u6 })], Y2.prototype, "highlightOptions", null), r([m()], Y2.prototype, "map", void 0), r([m()], Y2.prototype, "padding", null), r([m({ readOnly: true })], Y2.prototype, "rendering", null), r([m({ readOnly: true })], Y2.prototype, "resolution", null), r([m()], Y2.prototype, "scale", null), r([m({ constructOnly: true })], Y2.prototype, "spatialReferenceLocked", void 0), r([m({ readOnly: true })], Y2.prototype, "tileInfo", null), r([m({ type: e13, readOnly: true })], Y2.prototype, "timeline", void 0), r([m({ readOnly: true })], Y2.prototype, "type", void 0), r([m({ readOnly: true })], Y2.prototype, "updating", null), r([m({ readOnly: true })], Y2.prototype, "view2dType", void 0), r([m({ readOnly: true })], Y2.prototype, "visibleArea", null), r([m()], Y2.prototype, "zoom", null), r([m({ readOnly: true })], Y2.prototype, "navigating", null), r([m(), s5((e28) => e28 instanceof u16 ? e28 : h(c28, e28))], Y2.prototype, "ui", void 0), Y2 = r([a3("esri.views.View2D")], Y2);
var ee = Y2;

// node_modules/@arcgis/core/views/MapView.js
var t29 = class extends ee {
  constructor(o29) {
    super(o29), this.view2dType = "map";
  }
};
r([m({ readOnly: true })], t29.prototype, "view2dType", void 0), t29 = r([a3("esri.views.MapView")], t29);
var p30 = t29;
export {
  p30 as default
};
//# sourceMappingURL=@arcgis_core_views_MapView.js.map
