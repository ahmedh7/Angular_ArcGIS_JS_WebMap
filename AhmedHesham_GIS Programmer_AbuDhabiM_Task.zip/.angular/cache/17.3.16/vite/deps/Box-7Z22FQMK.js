import {
  h as h2
} from "./chunk-2NDXJF6H.js";
import {
  j as j3,
  p as p2
} from "./chunk-4ZOWSYHM.js";
import {
  e as e2
} from "./chunk-O2HCMPLO.js";
import {
  i as i4,
  o,
  s as s2
} from "./chunk-AMOGDIP4.js";
import {
  i as i3
} from "./chunk-P2V4WQPX.js";
import {
  a as a3,
  i as i2,
  m as m3,
  s
} from "./chunk-PGXUURLG.js";
import {
  R,
  m as m2
} from "./chunk-3JP6TRAH.js";
import {
  l2 as l
} from "./chunk-UZA3BAHW.js";
import "./chunk-GEPOYLUJ.js";
import "./chunk-7YOPNK5D.js";
import "./chunk-XWSW55Z6.js";
import "./chunk-SAZ53PXC.js";
import "./chunk-WM4YRQFB.js";
import "./chunk-OFP6RWZG.js";
import "./chunk-55OIOK5X.js";
import "./chunk-RMHCP7SH.js";
import "./chunk-GZQNIE27.js";
import "./chunk-66HQ5M7W.js";
import "./chunk-CISWKCW5.js";
import "./chunk-2CGNNVDA.js";
import "./chunk-ECGH6E32.js";
import "./chunk-VIMZSBVM.js";
import "./chunk-RMXLL62T.js";
import "./chunk-I55BQRXQ.js";
import "./chunk-BLUYYJD4.js";
import "./chunk-YBPYGATC.js";
import "./chunk-TZC4SNZT.js";
import "./chunk-KCIVZXDK.js";
import "./chunk-MILHALWW.js";
import "./chunk-54GNLAEA.js";
import "./chunk-ICZGPYI7.js";
import "./chunk-RZMBEHWM.js";
import "./chunk-OQ5J23EQ.js";
import "./chunk-BUKXCG5D.js";
import {
  h
} from "./chunk-FOU3TQ4S.js";
import "./chunk-ZOQURDQK.js";
import "./chunk-CEREZWZ6.js";
import "./chunk-246FW4WO.js";
import "./chunk-5V6LISMP.js";
import "./chunk-VCMSD6S6.js";
import "./chunk-TOC3BXJP.js";
import "./chunk-4UFPVFZG.js";
import "./chunk-GTHV6SQV.js";
import "./chunk-OVUDVDEJ.js";
import "./chunk-UPSWNHFU.js";
import "./chunk-3RDPSSYB.js";
import "./chunk-SZIT3IYE.js";
import "./chunk-P5BI27MR.js";
import "./chunk-DTRN4OOH.js";
import "./chunk-ZENTKHGR.js";
import "./chunk-SWTEWHKX.js";
import "./chunk-CLCRCQS5.js";
import "./chunk-HZVZN4QC.js";
import "./chunk-ARKMS27Q.js";
import "./chunk-DEBJAVLQ.js";
import "./chunk-LMKW53EF.js";
import "./chunk-245OSL56.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import "./chunk-CMPLJJCX.js";
import {
  b
} from "./chunk-XWFSWJ3K.js";
import "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import {
  S,
  y
} from "./chunk-BNLIASJH.js";
import {
  d as d2
} from "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import "./chunk-ECG7JDDX.js";
import "./chunk-PPAPRIQT.js";
import "./chunk-L7IGKLK6.js";
import "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import "./chunk-GYDLT2MD.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import "./chunk-JCECTBEZ.js";
import "./chunk-YFQQ5MRE.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-2K433C2G.js";
import "./chunk-EOJGN7NW.js";
import "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import {
  A,
  P,
  d,
  p
} from "./chunk-VYI6FOKY.js";
import "./chunk-EC2O3UFA.js";
import {
  i
} from "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import {
  u as u2
} from "./chunk-TN5VWI6D.js";
import {
  P as P2,
  j as j2,
  x
} from "./chunk-GMDCM6PU.js";
import {
  a as a2,
  e
} from "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import {
  u as u3
} from "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import {
  j2 as j
} from "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  u2 as u
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/geometry/support/rotate.js
function o2(n, e3, t, s3) {
  const i5 = [];
  for (const o3 of n) {
    const n2 = o3.slice();
    i5.push(n2);
    const r3 = e3 * (o3[0] - s3.x) - t * (o3[1] - s3.y) + s3.x, a4 = t * (o3[0] - s3.x) + e3 * (o3[1] - s3.y) + s3.y;
    n2[0] = r3, n2[1] = a4;
  }
  return i5;
}
function r2(r3, a4, c) {
  const { hasM: m4, hasZ: x2, spatialReference: f } = r3, p3 = a4 * Math.PI / 180, l2 = Math.cos(p3), h3 = Math.sin(p3);
  if ("xmin" in r3 && (c = c ?? r3.center, r3 = new j2({ spatialReference: f, rings: [[[r3.xmin, r3.ymin], [r3.xmin, r3.ymax], [r3.xmax, r3.ymax], [r3.xmax, r3.ymin], [r3.xmin, r3.ymin]]] })), "paths" in r3) {
    c = c ?? r3.extent.center;
    const n = [];
    for (const e3 of r3.paths) n.push(o2(e3, l2, h3, c));
    return new P2({ hasM: m4, hasZ: x2, spatialReference: f, paths: n });
  }
  if ("rings" in r3) {
    c = c ?? r3.extent.center;
    const n = [];
    for (const e3 of r3.rings) {
      const t = a2(e3), s3 = o2(e3, l2, h3, c);
      a2(s3) !== t && s3.reverse(), n.push(s3);
    }
    return new j2({ hasM: m4, hasZ: x2, spatialReference: f, rings: n });
  }
  if ("x" in r3) {
    c = c ?? r3;
    const n = new j({ x: l2 * (r3.x - c.x) - h3 * (r3.y - c.y) + c.x, y: h3 * (r3.x - c.x) + l2 * (r3.y - c.y) + c.y, spatialReference: f });
    return null != r3.z && (n.z = r3.z), null != r3.m && (n.m = r3.m), n;
  }
  return "points" in r3 ? (c = c ?? r3.extent.center, new u2({ hasM: m4, hasZ: x2, points: o2(r3.points, l2, h3, c), spatialReference: f })) : null;
}

// node_modules/@arcgis/core/views/draw/support/Box.js
var z = class {
  constructor(t, e3, i5, s3) {
    this.graphics = t, this.mover = e3, this.dx = i5, this.dy = s3, this.type = "move-start";
  }
};
var B = class {
  constructor(t, e3, i5, s3) {
    this.graphics = t, this.mover = e3, this.dx = i5, this.dy = s3, this.type = "move";
  }
};
var Y = class {
  constructor(t, e3, i5, s3) {
    this.graphics = t, this.mover = e3, this.dx = i5, this.dy = s3, this.type = "move-stop";
  }
};
var N = class {
  constructor(t, e3, i5) {
    this.graphics = t, this.mover = e3, this.angle = i5, this.type = "rotate-start";
  }
};
var U = class {
  constructor(t, e3, i5) {
    this.graphics = t, this.mover = e3, this.angle = i5, this.type = "rotate";
  }
};
var A2 = class {
  constructor(t, e3, i5) {
    this.graphics = t, this.mover = e3, this.angle = i5, this.type = "rotate-stop";
  }
};
var P3 = class {
  constructor(t, e3, i5, s3) {
    this.graphics = t, this.mover = e3, this.xScale = i5, this.yScale = s3, this.type = "scale-start";
  }
};
var X = class {
  constructor(t, e3, i5, s3) {
    this.graphics = t, this.mover = e3, this.xScale = i5, this.yScale = s3, this.type = "scale";
  }
};
var F = class {
  constructor(t, e3, i5, s3) {
    this.graphics = t, this.mover = e3, this.xScale = i5, this.yScale = s3, this.type = "scale-stop";
  }
};
var D = h2.transformGraphics;
var V = { centerIndicator: new y({ style: "cross", size: D.center.size, color: D.center.color }), fill: { default: new S({ color: D.fill.color, outline: { color: D.fill.outlineColor, join: "round", width: 1 } }), active: new S({ color: D.fill.stagedColor, outline: { color: D.fill.outlineColor, join: "round", style: "dash", width: 1 } }) }, handles: { default: new y({ style: "square", size: D.vertex.size, color: D.vertex.color, outline: { color: D.vertex.outlineColor, width: 1 } }), hover: new y({ style: "square", size: D.vertex.hoverSize, color: D.vertex.hoverColor, outline: { color: D.vertex.hoverOutlineColor, width: 1 } }) }, rotator: { default: new y({ style: "circle", size: D.vertex.size, color: D.vertex.color, outline: { color: D.vertex.outlineColor, width: 1 } }), hover: new y({ style: "circle", size: D.vertex.hoverSize, color: D.vertex.hoverColor, outline: { color: D.vertex.hoverOutlineColor, width: 1 } }) }, rotatorLine: new d2({ color: D.line.color, width: 1 }) };
var q = class extends i.EventedAccessor {
  constructor(t) {
    super(t), this._activeHandleGraphic = null, this._graphicAttributes = { esriSketchTool: "box" }, this._mover = null, this._centerGraphic = null, this._backgroundGraphic = null, this._vertexGraphics = [], this._rotateHandleGraphic = null, this._rotateGraphicOffset = 20, this._angleOfRotation = 0, this._rotateLineGraphic = null, this._startInfo = null, this._totalDx = 0, this._totalDy = 0, this._xScale = 1, this._yScale = 1, this.tooltip = null, this.type = "box", this.callbacks = { onMoveStart() {
    }, onMove() {
    }, onMoveStop() {
    }, onScaleStart() {
    }, onScale() {
    }, onScaleStop() {
    }, onRotateStart() {
    }, onRotate() {
    }, onRotateStop() {
    }, onGraphicClick() {
    } }, this.enableMovement = true, this.enableRotation = true, this.enableScaling = true, this.graphics = [], this.highlightsEnabled = true, this.layer = null, this.preserveAspectRatio = false, this.showCenterGraphic = true, this.symbols = V, this.sketchOptions = new l(), this.view = null, this._getBounds = (() => {
      const t2 = u3();
      return (e3, i5) => {
        e3[0] = Number.POSITIVE_INFINITY, e3[1] = Number.POSITIVE_INFINITY, e3[2] = Number.NEGATIVE_INFINITY, e3[3] = Number.NEGATIVE_INFINITY;
        for (const s3 of i5) {
          if (!s3) continue;
          let i6, o3, r3, a4;
          if ("point" === s3.type) i6 = r3 = s3.x, o3 = a4 = s3.y;
          else if ("multipoint" === s3.type) {
            const e4 = e(s3);
            [i6, o3, r3, a4] = x(t2, [e4]);
          } else if ("extent" === s3.type) [i6, o3, r3, a4] = [s3.xmin, s3.ymin, s3.xmax, s3.ymax];
          else {
            const e4 = e(s3);
            [i6, o3, r3, a4] = x(t2, e4);
          }
          e3[0] = Math.min(i6, e3[0]), e3[1] = Math.min(o3, e3[1]), e3[2] = Math.max(r3, e3[2]), e3[3] = Math.max(a4, e3[3]);
        }
        return e3;
      };
    })();
  }
  initialize() {
    const t = this.view;
    this._highlightHelper = new p2({ view: t }), this._setup(), this.addHandles([p(() => t?.ready, () => {
      const { layer: t2, view: e3 } = this;
      e2(e3, t2);
    }, { once: true, initial: true }), d(() => this.preserveAspectRatio, () => {
      this._activeHandleGraphic && (this._scaleGraphic(this._activeHandleGraphic), this._updateGraphics(), this._updateTooltip(this._activeHandleGraphic));
    }), d(() => t?.scale, () => {
      this._updateRotateGraphic(), this._updateRotateLineGraphic();
    }), d(() => this.graphics, () => this.refresh()), d(() => this.layer, (t2, e3) => {
      e3 && this._resetGraphics(e3), this.refresh();
    }), d(() => this.highlightsEnabled, () => {
      this._highlightHelper?.removeAll(), this._setUpHighlights();
    }), d(() => this.sketchOptions.tooltips.effectiveEnabled, (e3) => {
      this.tooltip = e3 ? R(() => ({ view: t, options: this.sketchOptions.tooltips })) : u(this.tooltip);
    }, A), d(() => this.view.effectiveTheme.accentColor, () => this._updateSymbolsForTheme(), P), this.on("move-start", (t2) => this.callbacks?.onMoveStart?.(t2)), this.on("move", (t2) => this.callbacks?.onMove?.(t2)), this.on("move-stop", (t2) => this.callbacks?.onMoveStop?.(t2)), this.on("rotate-start", (t2) => this.callbacks?.onRotateStart?.(t2)), this.on("rotate", (t2) => this.callbacks?.onRotate?.(t2)), this.on("rotate-stop", (t2) => this.callbacks?.onRotateStop?.(t2)), this.on("scale-start", (t2) => this.callbacks?.onScaleStart?.(t2)), this.on("scale", (t2) => this.callbacks?.onScale?.(t2)), this.on("scale-stop", (t2) => this.callbacks?.onScaleStop?.(t2))]);
  }
  destroy() {
    this._reset(), this.tooltip = u(this.tooltip);
  }
  get state() {
    const t = this.view?.ready ?? false, e3 = this.graphics.length && this.layer;
    return t && e3 ? "active" : t ? "ready" : "disabled";
  }
  isUIGraphic(t) {
    return this._vertexGraphics.includes(t) || t === this._backgroundGraphic || t === this._centerGraphic || t === this._rotateHandleGraphic || t === this._rotateLineGraphic;
  }
  move(t, e3) {
    if (this._mover && this.graphics.length) {
      for (const i5 of this.graphics) {
        const s3 = i5.geometry, o3 = i2(s3, t, e3, this.view);
        i5.geometry = o3;
      }
      this.refresh(), this.emit("move-stop", new Y(this.graphics, null, t, e3));
    }
  }
  scale(t, e3) {
    if (this._mover && this.graphics.length) {
      for (const i5 of this.graphics) {
        const s3 = i5.geometry, o3 = s(s3, t, e3);
        i5.geometry = o3;
      }
      this.refresh(), this.emit("scale-stop", new F(this.graphics, null, t, e3));
    }
  }
  rotate(t, e3) {
    if (this._mover && this.graphics.length) {
      if (!e3) {
        const t2 = this._vertexGraphics[1].geometry.x, i5 = this._vertexGraphics[3].geometry.y;
        e3 = new j(t2, i5, this.view.spatialReference);
      }
      for (const i5 of this.graphics) {
        const s3 = i5.geometry, o3 = r2(s3, t, e3);
        i5.geometry = o3;
      }
      this.refresh(), this.emit("rotate-stop", new A2(this.graphics, null, t));
    }
  }
  refresh() {
    this._reset(), this._setup();
  }
  reset() {
    this.graphics = [];
  }
  _setup() {
    "active" === this.state && (this._setUpHighlights(), this._setupGraphics(), this._setupMover(), this._updateGraphics());
  }
  _reset() {
    this._highlightHelper?.removeAll(), this._resetGraphicStateVars(), this._resetGraphics(), this._updateTooltip(), this._mover && this._mover.destroy(), this._mover = null, this.view.cursor = "default";
  }
  _resetGraphicStateVars() {
    this._startInfo = null, this._activeHandleGraphic = null, this._totalDx = 0, this._totalDy = 0, this._xScale = 1, this._yScale = 1, this._angleOfRotation = 0;
  }
  _resetGraphics(t) {
    (t = t || this.layer) && (t.removeMany(this._vertexGraphics), t.remove(this._backgroundGraphic), t.remove(this._centerGraphic), t.remove(this._rotateHandleGraphic), t.remove(this._rotateLineGraphic)), this._vertexGraphics.forEach((t2) => !t2.destroyed && t2.destroy()), !this._backgroundGraphic.destroyed && this._backgroundGraphic.destroy(), !this._centerGraphic.destroyed && this._centerGraphic.destroy(), !this._rotateHandleGraphic.destroyed && this._rotateHandleGraphic.destroy(), !this._rotateLineGraphic.destroyed && this._rotateLineGraphic.destroy(), this._vertexGraphics = [], this._backgroundGraphic = null, this._centerGraphic = null, this._rotateHandleGraphic = null, this._rotateLineGraphic = null;
  }
  _setupMover() {
    let t = [];
    this.enableScaling && (t = t.concat(this._vertexGraphics)), this.enableRotation && t.push(this._rotateHandleGraphic), this.enableMovement && (t = t.concat(this.graphics, this._backgroundGraphic)), this.showCenterGraphic && t.push(this._centerGraphic), this._mover = new j3({ enableMoveAllGraphics: false, highlightsEnabled: false, indicatorsEnabled: false, view: this.view, graphics: t, callbacks: { onGraphicClick: (t2) => this._onGraphicClickCallback(t2), onGraphicMoveStart: (t2) => this._onGraphicMoveStartCallback(t2), onGraphicMove: (t2) => this._onGraphicMoveCallback(t2), onGraphicMoveStop: (t2) => this._onGraphicMoveStopCallback(t2), onGraphicPointerOver: (t2) => this._onGraphicPointerOverCallback(t2), onGraphicPointerOut: (t2) => this._onGraphicPointerOutCallback(t2) } });
  }
  _getStartInfo(t) {
    const [e3, i5, s3, o3] = this._getBoxBounds(u3()), r3 = Math.abs(s3 - e3), a4 = Math.abs(o3 - i5), h3 = (s3 + e3) / 2, c = (o3 + i5) / 2, { x: n, y: l2 } = t.geometry;
    return { width: r3, height: a4, centerX: h3, centerY: c, startX: n, startY: l2, graphicInfos: this._getGraphicInfos(), box: this._backgroundGraphic.geometry, rotate: this._rotateHandleGraphic.geometry };
  }
  _getGraphicInfos() {
    return this.graphics.map((t) => this._getGraphicInfo(t));
  }
  _getGraphicInfo(t) {
    const e3 = t.geometry, [i5, s3, o3, r3] = this._getBounds(u3(), [e3]);
    return { width: Math.abs(o3 - i5), height: Math.abs(r3 - s3), centerX: (o3 + i5) / 2, centerY: (r3 + s3) / 2, geometry: e3 };
  }
  _onGraphicClickCallback(t) {
    t.viewEvent.stopPropagation(), this.emit("graphic-click", t), this.callbacks.onGraphicClick && this.callbacks.onGraphicClick(t);
  }
  _onGraphicMoveStartCallback(t) {
    const { _angleOfRotation: e3, _xScale: i5, _yScale: s3, _backgroundGraphic: o3, _vertexGraphics: r3, _rotateHandleGraphic: a4, symbols: h3 } = this, c = t.graphic;
    this._resetGraphicStateVars(), this._hideGraphicsBeforeUpdate(), o3.symbol = h3.fill.active, this._startInfo = this._getStartInfo(c), this._updateTooltip(c, t.viewEvent), c === a4 ? (this.view.cursor = "grabbing", this.emit("rotate-start", new N(this.graphics, c, e3))) : r3.includes(c) ? (this._activeHandleGraphic = c, this.emit("scale-start", new P3(this.graphics, c, i5, s3))) : this.emit("move-start", new z(this.graphics, c, t.dx, t.dy));
  }
  _onGraphicMoveCallback(t) {
    const e3 = t.graphic;
    if (this._startInfo) if (this._vertexGraphics.includes(e3)) this._scaleGraphic(e3), this._updateTooltip(e3, t.viewEvent), this.emit("scale", new X(this.graphics, e3, this._xScale, this._yScale));
    else if (e3 === this._rotateHandleGraphic) this._rotateGraphic(e3), this._updateTooltip(e3, t.viewEvent), this.emit("rotate", new U(this.graphics, e3, this._angleOfRotation));
    else {
      const { dx: i5, dy: s3 } = t;
      this._totalDx += i5, this._totalDy += s3, this._moveGraphic(e3, i5, s3), this._updateTooltip(e3, t.viewEvent), this.emit("move", new B(this.graphics, e3, i5, s3));
    }
  }
  _onGraphicMoveStopCallback(t) {
    const e3 = t.graphic;
    if (!this._startInfo) return void this.refresh();
    const { _angleOfRotation: i5, _totalDx: s3, _totalDy: o3, _xScale: r3, _yScale: a4, _vertexGraphics: h3, _rotateHandleGraphic: c } = this;
    this.refresh(), e3 === c ? (this.view.cursor = "pointer", this.emit("rotate-stop", new A2(this.graphics, e3, i5))) : h3.includes(e3) ? this.emit("scale-stop", new F(this.graphics, e3, r3, a4)) : this.emit("move-stop", new Y(this.graphics, e3, s3, o3));
  }
  _onGraphicPointerOverCallback(t) {
    const { _backgroundGraphic: e3, _vertexGraphics: i5, graphics: s3, _rotateHandleGraphic: o3, symbols: r3, view: a4 } = this, h3 = t.graphic;
    if (this._hoveredGraphic = h3, h3 === o3) return o3.symbol = r3.rotator.hover, a4.cursor = "pointer", void this._updateTooltip(h3);
    if (s3.includes(h3) || h3 === e3) return void (a4.cursor = "move");
    if (!i5.includes(h3)) return void (a4.cursor = "pointer");
    this._updateTooltip(h3), t.graphic.symbol = r3.handles.hover;
    const c = a4.rotation;
    let n, l2 = t.index;
    switch (l2 < 8 && (c >= 0 && c < 45 ? l2 %= 8 : l2 = c >= 45 && c < 90 ? (l2 + 1) % 8 : c >= 90 && c < 135 ? (l2 + 2) % 8 : c >= 135 && c < 180 ? (l2 + 3) % 8 : c >= 180 && c < 225 ? (l2 + 4) % 8 : c >= 225 && c < 270 ? (l2 + 5) % 8 : c >= 270 && c < 315 ? (l2 + 6) % 8 : (l2 + 7) % 8), l2) {
      case 0:
      case 4:
        n = "nwse-resize";
        break;
      case 1:
      case 5:
        n = "ns-resize";
        break;
      case 2:
      case 6:
        n = "nesw-resize";
        break;
      case 3:
      case 7:
        n = "ew-resize";
        break;
      default:
        n = "pointer";
    }
    a4.cursor = n;
  }
  _onGraphicPointerOutCallback(t) {
    const { _vertexGraphics: e3, _rotateHandleGraphic: i5, symbols: s3, view: o3 } = this;
    this._hoveredGraphic = null, t.graphic === i5 ? i5.symbol = s3.rotator.default : e3.includes(t.graphic) && (t.graphic.symbol = s3.handles.default), o3.cursor = "default", this._updateTooltip();
  }
  _scaleGraphic(t) {
    const { _startInfo: e3, _vertexGraphics: i5, preserveAspectRatio: s3, view: o3 } = this, { centerX: r3, centerY: a4, graphicInfos: h3, height: c, startX: n, startY: l2, width: _ } = e3, { resolution: d3, transform: m4 } = o3.state, u4 = i5.indexOf(t);
    1 !== u4 && 5 !== u4 || this._updateX(t, r3), 3 !== u4 && 7 !== u4 || this._updateY(t, a4);
    const { x: g, y: y2 } = t.geometry, v = m4[0] * g + m4[2] * y2 + m4[4], f = m4[1] * g + m4[3] * y2 + m4[5], G = h3?.map((t2) => t2.geometry) ?? [], w = G.every((t2) => "point" === t2.type);
    if ((0 === _ || 0 === c) && w) {
      const t2 = J((g - n) / d3), i6 = J((l2 - y2) / d3);
      for (let e4 = 0; e4 < G.length; e4++) this.graphics[e4].geometry = i2(G[e4], t2, i6, o3, true);
      return this._centerGraphic.geometry = new j(g, y2, o3.spatialReference), void (this._backgroundGraphic.geometry = i2(e3.box, t2, i6, o3, true));
    }
    if (s3) {
      const t2 = J(m4[0] * r3 + m4[2] * a4 + m4[4], 2), e4 = J(m4[1] * r3 + m4[3] * a4 + m4[5], 2), i6 = J(m4[0] * n + m4[2] * l2 + m4[4], 2), s4 = J(m4[1] * n + m4[3] * l2 + m4[5], 2);
      let o4 = a3(t2, e4, i6, s4, v, f);
      0 !== o4 && Math.abs(o4) !== 1 / 0 || (o4 = 1), this._xScale = this._yScale = o4;
      for (const h4 of G) {
        const t3 = G.indexOf(h4);
        this.graphics[t3].geometry = s(h4, this._xScale, this._yScale, [r3, a4]);
      }
      this._updateBackgroundGraphic();
    } else {
      let t2 = g - n, i6 = l2 - y2;
      if (1 === u4 || 5 === u4 ? t2 = 0 : 3 !== u4 && 7 !== u4 || (i6 = 0), 0 === t2 && 0 === i6) return;
      const s4 = r3 + t2 / 2, h4 = a4 + i6 / 2;
      let m5 = (_ + (n > r3 ? t2 : -1 * t2)) / _, v2 = (c + (l2 < a4 ? i6 : -1 * i6)) / c;
      1 !== u4 && 5 !== u4 && 0 !== m5 && Math.abs(m5) !== 1 / 0 || (m5 = 1), 3 !== u4 && 7 !== u4 && 0 !== v2 && Math.abs(v2) !== 1 / 0 || (v2 = 1), this._xScale = m5, this._yScale = v2;
      const f2 = (s4 - r3) / d3, w2 = (h4 - a4) / d3, S2 = s(e3.box, this._xScale, this._yScale);
      this._backgroundGraphic.geometry = i2(S2, f2, w2, o3, true);
      const { centerX: k, centerY: R2 } = this._getGraphicInfo(this._backgroundGraphic), M = (k - r3) / d3, I = -1 * (R2 - a4) / d3;
      for (const e4 of G) {
        const t3 = G.indexOf(e4), i7 = s(e4, this._xScale, this._yScale, [r3, a4]);
        this.graphics[t3].geometry = i2(i7, M, I, o3, true);
      }
      this._centerGraphic.geometry = new j(k, R2, o3.spatialReference);
    }
  }
  _rotateGraphic(t) {
    const { centerX: e3, centerY: i5, startX: s3, startY: o3, box: r3, rotate: a4 } = this._startInfo, h3 = this.view.spatialReference, c = new j(s3, o3, h3), n = new j(e3, i5, h3), l2 = t.geometry;
    this._angleOfRotation = m3(c, l2, n);
    const _ = this._startInfo.graphicInfos?.map((t2) => t2.geometry) ?? [];
    for (const p3 of _) {
      const t2 = _.indexOf(p3), e4 = r2(p3, this._angleOfRotation, n);
      this.graphics[t2].geometry = e4;
    }
    this._backgroundGraphic.geometry = r2(r3, this._angleOfRotation, n), this._rotateHandleGraphic.geometry = r2(a4, this._angleOfRotation, n);
  }
  _moveGraphic(t, e3, i5) {
    if (this.graphics.includes(t)) {
      const s3 = this._backgroundGraphic.geometry;
      this._backgroundGraphic.geometry = i2(s3, e3, i5, this.view);
      for (const o3 of this.graphics) o3 !== t && (o3.geometry = i2(o3.geometry, e3, i5, this.view));
    } else if (t === this._centerGraphic) {
      const t2 = this._backgroundGraphic.geometry;
      this._backgroundGraphic.geometry = i2(t2, e3, i5, this.view);
    }
    if (t === this._backgroundGraphic || t === this._centerGraphic) for (const s3 of this.graphics) s3.geometry = i2(s3.geometry, e3, i5, this.view);
  }
  _setUpHighlights() {
    this.highlightsEnabled && this.graphics.length && this._highlightHelper?.add(this.graphics);
  }
  _setupGraphics() {
    const { _graphicAttributes: t, symbols: i5 } = this;
    this._centerGraphic = new b({ symbol: i5.centerIndicator, attributes: t }), this.showCenterGraphic && this.layer.add(this._centerGraphic), this._backgroundGraphic = new b({ symbol: i5.fill.default, attributes: t }), this.layer.add(this._backgroundGraphic), this._rotateLineGraphic = new b({ symbol: i5.rotatorLine, attributes: t }), this._rotateHandleGraphic = new b({ symbol: i5.rotator.default, attributes: t }), this.enableRotation && !this._hasExtentGraphic() && this.layer.addMany([this._rotateLineGraphic, this._rotateHandleGraphic]);
    for (let s3 = 0; s3 < 8; s3++) this._vertexGraphics.push(new b({ symbol: i5.handles.default, attributes: t }));
    this.enableScaling && this.layer.addMany(this._vertexGraphics);
  }
  _updateSymbolsForTheme() {
    const t = this.view.effectiveTheme.accentColor;
    this.symbols = __spreadProps(__spreadValues({}, this.symbols), { fill: { active: this.symbols.fill.active?.clone().set("outline.color", t), default: this.symbols.fill.default?.clone().set("outline.color", t) }, handles: __spreadProps(__spreadValues({}, this.symbols.handles), { default: this.symbols.handles.default.clone().set("outline.color", t) }), rotator: __spreadProps(__spreadValues({}, this.symbols.rotator), { default: this.symbols.rotator.default.clone().set("outline.color", t) }), rotatorLine: this.symbols.rotatorLine.clone().set("color", t) });
    for (const e3 of this._vertexGraphics) e3.symbol = e3 === this._hoveredGraphic ? this.symbols.handles.hover : this.symbols.handles.default;
    this._backgroundGraphic.symbol = this.symbols.fill.default, this._rotateHandleGraphic.symbol = this._rotateHandleGraphic === this._hoveredGraphic ? this.symbols.rotator.hover : this.symbols.rotator.default, this._rotateLineGraphic.symbol = this.symbols.rotatorLine;
  }
  _updateGraphics() {
    this._updateBackgroundGraphic(), this._updateHandleGraphics(), this._updateCenterGraphic(), this._updateRotateGraphic(), this._updateRotateLineGraphic();
  }
  _hideGraphicsBeforeUpdate() {
    this._centerGraphic.visible = false, this._rotateHandleGraphic.visible = false, this._rotateLineGraphic.visible = false, this._vertexGraphics.forEach((t) => t.visible = false);
  }
  _updateHandleGraphics() {
    const t = this._getCoordinates(true);
    this._vertexGraphics.forEach((e3, i5) => {
      const [s3, o3] = t[i5];
      this._updateXY(e3, s3, o3);
    });
  }
  _updateBackgroundGraphic() {
    const t = this._getCoordinates().map(([t2, e3]) => [t2, e3]);
    this._backgroundGraphic.geometry = new j2({ rings: [t], spatialReference: this.view.spatialReference });
  }
  _updateCenterGraphic() {
    const [t, e3, i5, s3] = this._getBoxBounds(u3()), o3 = (i5 + t) / 2, r3 = (s3 + e3) / 2;
    this._centerGraphic.geometry = new j(o3, r3, this.view.spatialReference);
  }
  _updateRotateGraphic() {
    if (!this._vertexGraphics.length) return;
    const { x: t, y: e3 } = this._vertexGraphics[1].geometry, i5 = e3 + this.view.state.resolution * this._rotateGraphicOffset;
    this._rotateHandleGraphic.geometry = new j(t, i5, this.view.spatialReference);
  }
  _updateRotateLineGraphic() {
    if (!this._vertexGraphics.length || !this._rotateHandleGraphic?.geometry) return;
    const t = this._vertexGraphics[1].geometry, e3 = this._rotateHandleGraphic.geometry;
    this._rotateLineGraphic.geometry = new P2({ paths: [[[t.x, t.y], [e3.x, e3.y]]], spatialReference: this.view.spatialReference });
  }
  _updateXY(t, e3, i5) {
    t.geometry = new j(e3, i5, this.view.spatialReference);
  }
  _updateX(t, e3) {
    const i5 = t.geometry.y;
    t.geometry = new j(e3, i5, this.view.spatialReference);
  }
  _updateY(t, e3) {
    const i5 = t.geometry.x;
    t.geometry = new j(i5, e3, this.view.spatialReference);
  }
  _hasExtentGraphic() {
    return this.graphics.some((t) => null != t?.geometry && "extent" === t.geometry.type);
  }
  _getBoxBounds(t) {
    const e3 = this.graphics.map((t2) => t2.geometry);
    return this._getBounds(t, e3);
  }
  _getCoordinates(t) {
    const [e3, i5, s3, o3] = this._getBoxBounds(u3());
    if (t) {
      const t2 = (e3 + s3) / 2, r3 = (o3 + i5) / 2;
      return [[e3, o3], [t2, o3], [s3, o3], [s3, r3], [s3, i5], [t2, i5], [e3, i5], [e3, r3]];
    }
    return [[e3, o3], [s3, o3], [s3, i5], [e3, i5]];
  }
  _updateTooltip(t, e3) {
    if (null == this.tooltip) return;
    if (!t) return void this.tooltip.clear();
    const { _backgroundGraphic: i5, graphics: s3, _vertexGraphics: o3, _rotateHandleGraphic: r3 } = this;
    t === r3 ? this._updateRotateTooltip() : o3.includes(t) ? this._updateScaleTooltip() : (s3.includes(t) || t === i5) && this._updateMoveTooltip(e3);
  }
  _updateRotateTooltip() {
    null != this.tooltip && (this.tooltip.info = new s2({ sketchOptions: this.sketchOptions, angle: -this._angleOfRotation }));
  }
  _updateScaleTooltip() {
    const { tooltip: t, _xScale: e3, _yScale: i5, sketchOptions: s3, view: o3 } = this;
    if (null == t) return;
    const r3 = this._getCoordinates(), a4 = o({ topLeft: r3[0], topRight: r3[1], bottomRight: r3[2], bottomLeft: r3[3], spatialReference: o3.spatialReference });
    if (null == a4) return;
    const { xSize: h3, ySize: c } = a4, n = Math.abs(e3), l2 = Math.abs(i5);
    t.info = new i4({ sketchOptions: s3, xScale: n, yScale: l2, xSize: h3, ySize: c });
  }
  _updateMoveTooltip(t) {
    const { tooltip: e3, sketchOptions: i5, view: s3 } = this;
    if (null == e3) return;
    const r3 = new i3({ sketchOptions: i5 });
    if (t) {
      const { x: e4, y: i6 } = t.origin, a4 = s3.toMap(t), h3 = s3.toMap({ x: e4, y: i6 }), c = m2(h3, a4);
      r3.distance = null != c ? c : h;
    }
    e3.info = r3;
  }
};
function J(t, e3 = 2) {
  return Number.parseFloat(t.toFixed(e3));
}
r([m()], q.prototype, "tooltip", void 0), r([m({ readOnly: true })], q.prototype, "type", void 0), r([m()], q.prototype, "callbacks", void 0), r([m()], q.prototype, "enableMovement", void 0), r([m()], q.prototype, "enableRotation", void 0), r([m()], q.prototype, "enableScaling", void 0), r([m()], q.prototype, "graphics", void 0), r([m()], q.prototype, "highlightsEnabled", void 0), r([m()], q.prototype, "layer", void 0), r([m()], q.prototype, "preserveAspectRatio", void 0), r([m()], q.prototype, "showCenterGraphic", void 0), r([m({ readOnly: true })], q.prototype, "state", null), r([m()], q.prototype, "symbols", void 0), r([m({ type: l })], q.prototype, "sketchOptions", void 0), r([m({ constructOnly: true })], q.prototype, "view", void 0), q = r([a("esri.views.draw.support.Box")], q);
var K = q;
export {
  K as default
};
//# sourceMappingURL=Box-7Z22FQMK.js.map
