// node_modules/@arcgis/core/views/webgl/NoParameters.js
var s = class {
};
var c = s;
var e = new c();

export {
  c,
  e
};
//# sourceMappingURL=chunk-2HPGVA3W.js.map
