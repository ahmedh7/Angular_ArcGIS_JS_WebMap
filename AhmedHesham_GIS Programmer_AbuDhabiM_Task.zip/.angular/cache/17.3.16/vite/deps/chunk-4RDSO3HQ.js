import {
  _,
  i as i3
} from "./chunk-LKSBHV7Q.js";
import {
  x
} from "./chunk-CNHVBYZW.js";
import {
  s as s5
} from "./chunk-NCDGRISH.js";
import {
  a as a3
} from "./chunk-OQT7GIOX.js";
import {
  K as K2,
  a2 as a4,
  e as e4,
  p as p3
} from "./chunk-KLEGUCFX.js";
import {
  T
} from "./chunk-BUKXCG5D.js";
import {
  C,
  D,
  E,
  J,
  K,
  L,
  M,
  O as O2,
  Q,
  R,
  Te,
  ae,
  de,
  ee,
  fe,
  he,
  ie,
  le,
  oe,
  pe,
  q,
  re,
  se,
  we,
  x as x2
} from "./chunk-246FW4WO.js";
import {
  x as x3
} from "./chunk-S5Z7N22V.js";
import {
  o
} from "./chunk-GTHV6SQV.js";
import {
  Ye
} from "./chunk-TBHNOGW4.js";
import {
  c as c6
} from "./chunk-7T32KOGA.js";
import {
  c as c5
} from "./chunk-XAJHU5YA.js";
import {
  d as d5
} from "./chunk-OPMACZPA.js";
import {
  b as b2
} from "./chunk-XWFSWJ3K.js";
import {
  I,
  c as c4,
  d as d4,
  i,
  i3 as i2,
  n as n4,
  n3 as n5,
  p as p2
} from "./chunk-RQIC5Q3A.js";
import {
  ge
} from "./chunk-3SPX7DOW.js";
import {
  b as b3
} from "./chunk-7OZN72PM.js";
import {
  m as m2
} from "./chunk-Z4ITP2HY.js";
import {
  a as a2
} from "./chunk-J3AJBXLW.js";
import {
  e as e6
} from "./chunk-OWFGHE2Q.js";
import {
  e as e7,
  t
} from "./chunk-JYALIYUG.js";
import {
  r as r2
} from "./chunk-ECG7JDDX.js";
import {
  e as e5
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c as c3,
  e as e3
} from "./chunk-PPAPRIQT.js";
import {
  n2
} from "./chunk-L7IGKLK6.js";
import {
  g as g2,
  w as w2,
  y as y2
} from "./chunk-2NHACHL3.js";
import {
  n as n3
} from "./chunk-PLXIETOO.js";
import {
  s as s3
} from "./chunk-4MEW2QUW.js";
import {
  l
} from "./chunk-GMGPROHW.js";
import {
  P,
  d as d3,
  p,
  v,
  w
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  d as d2
} from "./chunk-TZVX7A54.js";
import {
  e as e2
} from "./chunk-7PVOLFAH.js";
import {
  j2 as j
} from "./chunk-K2TU6MD2.js";
import {
  g as g3
} from "./chunk-P5ELECBN.js";
import {
  s as s4
} from "./chunk-REZDV4AU.js";
import {
  P2
} from "./chunk-ADRG7ORV.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  A,
  b,
  d,
  e2 as e,
  h,
  k,
  s as s2,
  u2 as u,
  y
} from "./chunk-VT56RVNM.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  c as c2,
  n2 as n,
  s2 as s
} from "./chunk-JB56QM27.js";
import {
  G,
  c
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/Attachments/AttachmentsViewModel.js
var u2 = { editing: false, operations: { add: true, update: true, delete: true } };
var f = V.ofType(a3);
var y3 = class extends g {
  constructor(t3) {
    super(t3), this._getAttachmentsPromise = null, this._attachmentLayer = null, this.capabilities = __spreadValues({}, u2), this.activeAttachmentInfo = null, this.activeFileInfo = null, this.attachmentInfos = new f(), this.fileInfos = new V(), this.graphic = null, this.mode = "view", this.orderByFields = null, this.filesEnabled = false, this.addHandles(d3(() => this.graphic, () => this._graphicChanged(), P));
  }
  destroy() {
    this._attachmentLayer = null, this.graphic = null;
  }
  castCapabilities(t3) {
    return __spreadValues(__spreadValues({}, u2), t3);
  }
  get state() {
    return this._getAttachmentsPromise ? "loading" : this.graphic ? "ready" : "disabled";
  }
  get supportsResizeAttachments() {
    const { graphic: t3 } = this;
    if (!t3) return false;
    const e11 = t3.layer || t3.sourceLayer;
    return e11?.loaded && "capabilities" in e11 && e11.capabilities && "attachment" in e11.capabilities && e11.capabilities.attachment && "supportsResize" in e11.capabilities.attachment && e11.capabilities.attachment.supportsResize || false;
  }
  getAttachments() {
    return __async(this, null, function* () {
      const { _attachmentLayer: t3, attachmentInfos: e11, orderByFields: i6 } = this;
      if (!t3 || "function" != typeof t3.queryAttachments) throw new s("invalid-layer", "getAttachments(): A valid layer is required.");
      const a5 = this._getObjectId();
      if ("number" != typeof a5) throw new s("invalid-object-id", "getAttachments(): Numeric object id is required");
      const r3 = i6?.map((t4) => `${t4.field} ${"descending" === t4.order ? "DESC" : "ASC"}`), s7 = new c5({ objectIds: [a5], returnMetadata: true, orderByFields: r3 }), o3 = [], c14 = t3.queryAttachments(s7).then((t4) => t4[a5] || o3).catch(() => o3);
      this._getAttachmentsPromise = c14, this.notifyChange("state");
      const h7 = yield c14;
      return e11.destroyAll(), h7.length && e11.addMany(h7), this._getAttachmentsPromise = null, this.notifyChange("state"), h7;
    });
  }
  addAttachment(_0) {
    return __async(this, arguments, function* (t3, e11 = this.graphic) {
      const { _attachmentLayer: i6, attachmentInfos: a5, capabilities: r3 } = this;
      if (!e11) throw new s("invalid-graphic", "addAttachment(): A valid graphic is required.", { graphic: e11 });
      if (!t3) throw new s("invalid-attachment", "addAttachment(): An attachment is required.", { attachment: t3 });
      if (!r3.operations?.add) throw new s("invalid-capabilities", "addAttachment(): add capabilities are required.");
      if (!i6 || "function" != typeof i6.addAttachment) throw new s("invalid-layer", "addAttachment(): A valid layer is required.");
      const s7 = i6.addAttachment(e11, t3).then((t4) => this._queryAttachment(t4.objectId, e11)), o3 = yield s7;
      return a5.add(o3), o3;
    });
  }
  deleteAttachment(t3) {
    return __async(this, null, function* () {
      const { _attachmentLayer: e11, attachmentInfos: i6, graphic: a5, capabilities: r3 } = this;
      if (!t3) throw new s("invalid-attachment-info", "deleteAttachment(): An attachmentInfo is required.", { attachmentInfo: t3 });
      if (!r3.operations?.delete) throw new s("invalid-capabilities", "deleteAttachment(): delete capabilities are required.");
      if (!e11 || "function" != typeof e11.deleteAttachments) throw new s("invalid-layer", "deleteAttachment(): A valid layer is required.");
      if (!a5) throw new s("invalid-graphic", "deleteAttachment(): A graphic is required.");
      const s7 = e11.deleteAttachments(a5, [t3.id]).then(() => t3), o3 = yield s7;
      return i6.remove(o3), o3.destroy(), o3;
    });
  }
  updateAttachment(_0) {
    return __async(this, arguments, function* (t3, e11 = this.activeAttachmentInfo) {
      const { _attachmentLayer: i6, attachmentInfos: a5, graphic: r3, capabilities: s7 } = this;
      if (!t3) throw new s("invalid-attachment", "updateAttachment(): An attachment is required.", { attachment: t3 });
      if (!e11) throw new s("invalid-attachment-info", "updateAttachment(): An attachmentInfo is required.", { attachmentInfo: e11 });
      if (!s7.operations?.update) throw new s("invalid-capabilities", "updateAttachment(): Update capabilities are required.");
      const o3 = a5.indexOf(e11);
      if (!i6 || "function" != typeof i6.updateAttachment) throw new s("invalid-layer", "updateAttachment(): A valid layer is required.");
      if (!r3) throw new s("invalid-graphic", "updateAttachment(): A graphic is required.");
      const c14 = i6.updateAttachment(r3, e11.id, t3).then((t4) => this._queryAttachment(t4.objectId)), h7 = yield c14;
      return a5.splice(o3, 1, h7), h7;
    });
  }
  commitFiles() {
    return __async(this, null, function* () {
      return yield Promise.all(this.fileInfos.items.map((t3) => this.addAttachment(t3.form))), this.fileInfos.removeAll(), this.getAttachments();
    });
  }
  addFile(t3, e11) {
    if (!t3 || !e11) return null;
    const i6 = { file: t3, form: e11 };
    return this.fileInfos.add(i6), i6;
  }
  updateFile(t3, e11, i6 = this.activeFileInfo) {
    if (!t3 || !e11 || !i6) return null;
    const a5 = this.fileInfos.indexOf(i6);
    return a5 > -1 && this.fileInfos.splice(a5, 1, { file: t3, form: e11 }), this.fileInfos.items[a5];
  }
  deleteFile(t3) {
    const e11 = this.fileInfos.find((e12) => e12.file === t3);
    return e11 ? (this.fileInfos.remove(e11), e11) : null;
  }
  _queryAttachment(t3, e11) {
    return __async(this, null, function* () {
      const { _attachmentLayer: i6 } = this;
      if (!t3 || !i6?.queryAttachments) throw new s("invalid-attachment-id", "Could not query attachment.");
      const a5 = this._getObjectId(e11);
      if ("number" != typeof a5) throw new s("invalid-object-id", "getAttachments(): Numeric object id is required");
      const r3 = new c5({ objectIds: [a5], attachmentsWhere: `AttachmentId=${t3}`, returnMetadata: true });
      return i6.queryAttachments(r3).then((t4) => t4[a5][0]);
    });
  }
  _getObjectId(t3 = this.graphic) {
    return t3?.getObjectId() ?? null;
  }
  _graphicChanged() {
    this.graphic && (this._setAttachmentLayer(), this.getAttachments().catch(() => this.attachmentInfos.destroyAll()));
  }
  _setAttachmentLayer() {
    const { graphic: t3 } = this, e11 = L(t3);
    this._attachmentLayer = e11 ? "scene" === e11.type && null != e11.associatedLayer ? e11.associatedLayer : e11 : null;
  }
};
r([m()], y3.prototype, "capabilities", void 0), r([s4("capabilities")], y3.prototype, "castCapabilities", null), r([m()], y3.prototype, "activeAttachmentInfo", void 0), r([m()], y3.prototype, "activeFileInfo", void 0), r([m({ readOnly: true, type: f })], y3.prototype, "attachmentInfos", void 0), r([m()], y3.prototype, "fileInfos", void 0), r([m({ type: b2 })], y3.prototype, "graphic", void 0), r([m()], y3.prototype, "mode", void 0), r([m({ type: [n4] })], y3.prototype, "orderByFields", void 0), r([m({ readOnly: true })], y3.prototype, "state", null), r([m()], y3.prototype, "filesEnabled", void 0), r([m({ readOnly: true })], y3.prototype, "supportsResizeAttachments", null), y3 = r([a("esri.widgets.Attachments.AttachmentsViewModel")], y3);
var A2 = y3;

// node_modules/@arcgis/core/widgets/support/legacyIcon.js
var i4 = { close: "esri-icon-close", collapse: "esri-icon-collapse", down: "esri-icon-down", downArrow: "esri-icon-down-arrow", dragHorizontal: "esri-icon-drag-horizontal", dragVertical: "esri-icon-drag-vertical", duplicate: "esri-icon-duplicate", expand: "esri-icon-expand", fontFallbackText: "esri-icon-font-fallback-text", forward: "esri-icon-forward", handleVertical: "esri-icon-handle-vertical", icon: "esri-icon", left: "esri-icon-left", locateCircled: "esri-icon-locate-circled", noticeTriangle: "esri-icon-notice-triangle", pause: "esri-icon-pause", play: "esri-icon-play", plus: "esri-icon-plus", radioChecked: "esri-icon-radio-checked", radioUnchecked: "esri-icon-radio-unchecked", refresh: "esri-icon-refresh", reverse: "esri-icon-reverse", right: "esri-icon-right", search: "esri-icon-search", swap: "esri-icon-swap", table: "esri-icon-table", trash: "esri-icon-trash", up: "esri-icon-up", upArrow: "esri-icon-up-arrow", upDownArrows: "esri-icon-up-down-arrows", urbanModel: "esri-icon-urban-model", zoomInMagnifyingGlass: "esri-icon-zoom-in-magnifying-glass", zoomToObject: "esri-icon-zoom-to-object" };

// node_modules/@arcgis/core/widgets/Attachments.js
var A3 = { addButton: true, addSubmitButton: true, cancelAddButton: true, cancelUpdateButton: true, deleteButton: true, errorMessage: true, progressBar: true, updateButton: true };
var w3 = "esri-attachments";
var F = { base: w3, loaderContainer: `${w3}__loader-container`, loader: `${w3}__loader`, fadeIn: `${w3}--fade-in`, container: `${w3}__container`, containerList: `${w3}__container--list`, containerPreview: `${w3}__container--preview`, actions: `${w3}__actions`, deleteButton: `${w3}__delete-button`, addAttachmentButton: `${w3}__add-attachment-button`, errorMessage: `${w3}__error-message`, items: `${w3}__items`, item: `${w3}__item`, itemButton: `${w3}__item-button`, itemMask: `${w3}__item-mask`, itemMaskIcon: `${w3}__item-mask--icon`, itemImage: `${w3}__image`, itemImageResizable: `${w3}__image--resizable`, itemLabel: `${w3}__label`, itemFilename: `${w3}__filename`, itemChevronIcon: `${w3}__item-chevron-icon`, itemLink: `${w3}__item-link`, itemLinkOverlay: `${w3}__item-link-overlay`, itemLinkOverlayIcon: `${w3}__item-link-overlay-icon`, itemEditIcon: `${w3}__item-edit-icon`, itemAddIcon: `${w3}__item-add-icon`, itemAddButton: `${w3}__item-add-button`, formNode: `${w3}__form-node`, fileFieldset: `${w3}__file-fieldset`, fileLabel: `${w3}__file-label`, fileName: `${w3}__file-name`, fileInput: `${w3}__file-input`, metadata: `${w3}__metadata`, metadataFieldset: `${w3}__metadata-fieldset`, progressBar: `${w3}__progress-bar` };
var k2 = window.CSS;
var M2 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this.displayType = "auto", this.messages = null, this.messagesUnits = null, this.selectedFile = null, this.submitting = false, this.viewModel = null, this.visibleElements = __spreadValues({}, A3), this._supportsImageOrientation = k2 && k2.supports && k2.supports("image-orientation", "from-image"), this._addAttachmentForm = null, this._updateAttachmentForm = null;
  }
  normalizeCtorArgs(e11) {
    return e11?.viewModel || (e11 = __spreadValues({ viewModel: new A2() }, e11)), e11;
  }
  initialize() {
    this.addHandles([v(() => this.viewModel?.attachmentInfos, "change", () => this.scheduleRender()), v(() => this.viewModel?.fileInfos, "change", () => this.scheduleRender()), d3(() => this.viewModel?.mode, () => this._modeChanged(), P)]);
  }
  loadDependencies() {
    return c3({ icon: () => import("./calcite-icon-TH7JL242.js") });
  }
  get capabilities() {
    return this.viewModel.capabilities;
  }
  set capabilities(e11) {
    this.viewModel.capabilities = e11;
  }
  get effectiveDisplayType() {
    const { displayType: e11 } = this;
    return e11 && "auto" !== e11 ? e11 : this.viewModel.supportsResizeAttachments ? "preview" : "list";
  }
  get graphic() {
    return this.viewModel.graphic;
  }
  set graphic(e11) {
    this.viewModel.graphic = e11;
  }
  get icon() {
    return "attachment";
  }
  set icon(e11) {
    this._overrideIfSome("icon", e11);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e11) {
    this._overrideIfSome("label", e11);
  }
  castVisibleElements(e11) {
    return __spreadValues(__spreadValues({}, A3), e11);
  }
  addAttachment() {
    const { _addAttachmentForm: e11, viewModel: s7 } = this;
    return this._set("submitting", true), this._set("error", null), s7.addAttachment(e11).then((e12) => (this._set("submitting", false), this._set("error", null), s7.mode = "view", e12)).catch((e12) => {
      throw this._set("submitting", false), this._set("error", new s("attachments:add-attachment", this.messages.addErrorMessage, e12)), e12;
    });
  }
  deleteAttachment(e11) {
    const { viewModel: s7 } = this;
    return this._set("submitting", true), this._set("error", null), s7.deleteAttachment(e11).then((e12) => (this._set("submitting", false), this._set("error", null), s7.mode = "view", e12)).catch((e12) => {
      throw this._set("submitting", false), this._set("error", new s("attachments:delete-attachment", this.messages.deleteErrorMessage, e12)), e12;
    });
  }
  updateAttachment() {
    const { viewModel: e11 } = this, { _updateAttachmentForm: s7 } = this;
    return this._set("submitting", true), this._set("error", null), e11.updateAttachment(s7).then((t3) => (this._set("submitting", false), this._set("error", null), e11.mode = "view", t3)).catch((e12) => {
      throw this._set("submitting", false), this._set("error", new s("attachments:update-attachment", this.messages.updateErrorMessage, e12)), e12;
    });
  }
  addFile() {
    const e11 = this.viewModel.addFile(this.selectedFile, this._addAttachmentForm);
    return this.viewModel.mode = "view", e11;
  }
  updateFile() {
    const { viewModel: e11 } = this, t3 = e11.updateFile(this.selectedFile, this._updateAttachmentForm, e11.activeFileInfo);
    return e11.mode = "view", t3;
  }
  deleteFile(e11) {
    const t3 = this.viewModel.deleteFile(e11 || this.viewModel.activeFileInfo?.file);
    return this.viewModel.mode = "view", t3;
  }
  render() {
    const { submitting: e11, viewModel: t3 } = this, { state: s7 } = t3;
    return n2("div", { class: this.classes(F.base, e5.widget) }, e11 ? this._renderProgressBar() : null, "loading" === s7 ? this._renderLoading() : this._renderAttachments(), this._renderErrorMessage());
  }
  _renderErrorMessage() {
    const { error: e11, visibleElements: t3 } = this;
    return e11 && t3.errorMessage ? n2("div", { class: F.errorMessage, key: "error-message" }, e11.message) : null;
  }
  _renderAttachments() {
    const { activeFileInfo: e11, mode: t3, activeAttachmentInfo: s7 } = this.viewModel;
    return "add" === t3 ? this._renderAddForm() : "edit" === t3 ? this._renderDetailsForm(s7 || e11) : this._renderAttachmentContainer();
  }
  _renderLoading() {
    return n2("div", { class: F.loaderContainer, key: "loader" }, n2("div", { class: F.loader }));
  }
  _renderProgressBar() {
    return this.visibleElements.progressBar ? n2("div", { class: F.progressBar, key: "progress-bar" }) : null;
  }
  _renderAddForm() {
    const { submitting: e11, selectedFile: t3 } = this, s7 = e11 || !t3, i6 = this.visibleElements.cancelAddButton ? n2("button", { bind: this, class: this.classes(e5.button, e5.buttonTertiary, e5.buttonSmall, e5.buttonHalf, e11 && e5.buttonDisabled), disabled: e11, onclick: this._cancelForm, type: "button" }, this.messages.cancel) : null, a5 = this.visibleElements.addSubmitButton ? n2("button", { class: this.classes(e5.button, e5.buttonSecondary, e5.buttonSmall, e5.buttonHalf, { [e5.buttonDisabled]: s7 }), disabled: s7, type: "submit" }, this.messages.add) : null, n10 = t3 ? n2("span", { class: F.fileName, key: "file-name" }, t3.name) : null, l6 = n2("form", { afterCreate: y2, afterRemoved: w2, bind: this, "data-node-ref": "_addAttachmentForm", onsubmit: this._submitAddAttachment }, n2("fieldset", { class: F.fileFieldset }, n10, n2("label", { class: this.classes(F.fileLabel, e5.button, e5.buttonSecondary) }, t3 ? this.messages.changeFile : this.messages.selectFile, n2("input", { bind: this, class: F.fileInput, name: "attachment", onchange: this._handleFileInputChange, type: "file" }))), a5, i6);
    return n2("div", { class: F.formNode, key: "add-form-container" }, l6);
  }
  _renderDetailsForm(e11) {
    const { visibleElements: t3, viewModel: s7, selectedFile: i6, submitting: a5 } = this, { capabilities: l6 } = s7, r3 = a5 || !i6;
    let o3, d9, c14, m8;
    i6 ? (o3 = i6.type, d9 = i6.name, c14 = i6.size) : e11 && "file" in e11 ? (o3 = e11.file.type, d9 = e11.file.name, c14 = e11.file.size) : e11 && "contentType" in e11 && (o3 = e11.contentType, d9 = e11.name, c14 = e11.size, m8 = e11.url);
    const h7 = l6.editing && l6.operations?.delete && t3.deleteButton ? n2("button", { bind: this, class: this.classes(e5.button, e5.buttonSmall, e5.buttonTertiary, F.deleteButton, { [e5.buttonDisabled]: a5 }), disabled: a5, key: "delete-button", onclick: (t4) => this._submitDeleteAttachment(t4, e11), type: "button" }, this.messages.delete) : void 0, u6 = l6.editing && l6.operations?.update && t3.updateButton ? n2("button", { class: this.classes(e5.button, e5.buttonSmall, e5.buttonThird, { [e5.buttonDisabled]: r3 }), disabled: r3, key: "update-button", type: "submit" }, this.messages.update) : void 0, b9 = this.visibleElements.cancelUpdateButton ? n2("button", { bind: this, class: this.classes(e5.button, e5.buttonSmall, e5.buttonTertiary, e5.buttonThird, { [e5.buttonDisabled]: a5 }), disabled: a5, key: "cancel-button", onclick: this._cancelForm, type: "button" }, this.messages.cancel) : void 0, f5 = l6.editing && l6.operations?.update ? n2("fieldset", { class: F.fileFieldset, key: "file" }, n2("span", { class: F.fileName, key: "file-name" }, d9), n2("label", { class: this.classes(F.fileLabel, e5.button, e5.buttonSecondary) }, this.messages.changeFile, n2("input", { bind: this, class: F.fileInput, name: "attachment", onchange: this._handleFileInputChange, type: "file" }))) : void 0, v7 = n2("fieldset", { class: F.metadataFieldset, key: "size" }, n2("label", null, T(this.messagesUnits, c14 ?? 0))), A5 = n2("fieldset", { class: F.metadataFieldset, key: "content-type" }, n2("label", null, o3)), w8 = null != m8 ? n2("a", { class: F.itemLink, href: m8, rel: "noreferrer", target: "_blank" }, this._renderImageMask(e11, 400), n2("div", { class: F.itemLinkOverlay }, n2("span", { class: F.itemLinkOverlayIcon }, n2("calcite-icon", { icon: "launch" })))) : this._renderImageMask(e11, 400), k4 = n2("form", { afterCreate: y2, afterRemoved: w2, bind: this, "data-node-ref": "_updateAttachmentForm", onsubmit: (t4) => this._submitUpdateAttachment(t4, e11) }, n2("div", { class: F.metadata }, v7, A5), f5, n2("div", { class: F.actions }, h7, b9, u6));
    return n2("div", { class: F.formNode, key: "edit-form-container" }, w8, k4);
  }
  _renderImageMask(e11, t3) {
    return e11 ? "file" in e11 ? this._renderGenericImageMask(e11.file.name, e11.file.type) : this._renderImageMaskForAttachment(e11, t3) : null;
  }
  _renderGenericImageMask(e11, t3) {
    const { supportsResizeAttachments: s7 } = this.viewModel, i6 = p3(t3), a5 = { [F.itemImageResizable]: s7 };
    return n2("div", { class: this.classes(F.itemMaskIcon, F.itemMask), key: i6 }, n2("img", { alt: e11, class: this.classes(a5, F.itemImage), src: i6, title: e11 }));
  }
  _renderImageMaskForAttachment(e11, t3) {
    const { supportsResizeAttachments: s7 } = this.viewModel;
    if (!e11) return null;
    const { contentType: i6, name: a5, url: n10 } = e11;
    if (!s7 || !e4(i6)) return this._renderGenericImageMask(a5, i6);
    const l6 = this._getCSSTransform(e11), r3 = l6 ? { transform: l6, "image-orientation": "none" } : {}, o3 = `${n10}${n10?.includes("?") ? "&" : "?"}w=${t3}`, d9 = { [F.itemImageResizable]: s7 };
    return n2("div", { class: this.classes(F.itemMask), key: o3 }, n2("img", { alt: a5, class: this.classes(d9, F.itemImage), src: o3, styles: r3, title: a5 }));
  }
  _renderFile(e11) {
    const { file: t3 } = e11;
    return n2("li", { class: F.item, key: t3 }, n2("button", { "aria-label": this.messages.attachmentDetails, bind: this, class: F.itemButton, key: "details-button", onclick: () => this._startEditFile(e11), title: this.messages.attachmentDetails, type: "button" }, this._renderImageMask(e11), n2("label", { class: F.itemLabel }, n2("span", { class: F.itemFilename }, t3.name || this.messages.noTitle), n2("span", { "aria-hidden": "true", class: this.classes(F.itemChevronIcon, g2(this.container) ? i4.left : i4.right) }))));
  }
  _renderAttachmentInfo({ attachmentInfo: e11, displayType: t3 }) {
    const { viewModel: s7, effectiveDisplayType: i6 } = this, { capabilities: a5, supportsResizeAttachments: n10 } = s7, { contentType: l6, name: r3, url: o3 } = e11, d9 = this._renderImageMask(e11, "list" === t3 ? 48 : 400), c14 = a5.editing ? n2("span", { "aria-hidden": "true", class: this.classes(F.itemChevronIcon, g2(this.container) ? i4.left : i4.right) }) : null, m8 = [d9, "preview" === i6 && n10 && e4(l6) ? null : n2("label", { class: F.itemLabel }, n2("span", { class: F.itemFilename }, r3 || this.messages.noTitle), c14)], u6 = a5.editing ? n2("button", { "aria-label": this.messages.attachmentDetails, bind: this, class: F.itemButton, "data-attachment-info-id": e11.id, key: "details-button", onclick: () => this._startEditAttachment(e11), title: this.messages.attachmentDetails, type: "button" }, m8) : n2("a", { class: F.itemButton, href: o3 ?? void 0, key: "details-link", rel: "noreferrer", target: "_blank" }, m8);
    return n2("li", { class: F.item, key: e11 }, u6);
  }
  _renderAttachmentContainer() {
    const { effectiveDisplayType: e11, viewModel: t3, visibleElements: s7 } = this, { attachmentInfos: i6, capabilities: a5, fileInfos: n10 } = t3, l6 = !!i6?.length, r3 = !!n10?.length, o3 = { [F.containerList]: "preview" !== e11, [F.containerPreview]: "preview" === e11 }, d9 = a5.editing && a5.operations?.add && s7.addButton ? n2("button", { bind: this, class: this.classes(e5.button, e5.buttonTertiary, F.addAttachmentButton), onclick: () => this._startAddAttachment(), type: "button" }, n2("span", { "aria-hidden": "true", class: this.classes(F.itemAddIcon, i4.plus) }), this.messages.add) : void 0, c14 = l6 ? n2("ul", { class: F.items, key: "attachments-list" }, i6.toArray().map((t4) => this._renderAttachmentInfo({ attachmentInfo: t4, displayType: e11 }))) : void 0, m8 = r3 ? n2("ul", { class: F.items, key: "file-list" }, n10.toArray().map((e12) => this._renderFile(e12))) : void 0, h7 = r3 || l6 ? void 0 : n2("div", { class: e5.empty }, this.messages.noAttachments);
    return n2("div", { class: this.classes(F.container, o3), key: "attachments-container" }, c14, m8, h7, d9);
  }
  _modeChanged() {
    this._set("error", null), this._set("selectedFile", null);
  }
  _handleFileInputChange(e11) {
    const t3 = e11.target, s7 = t3.files?.item(0);
    this._set("selectedFile", s7);
  }
  _submitDeleteAttachment(e11, t3) {
    e11.preventDefault(), t3 && ("file" in t3 ? this.deleteFile(t3.file) : t3 && this.deleteAttachment(t3));
  }
  _submitAddAttachment(e11) {
    e11.preventDefault(), this.viewModel.filesEnabled ? this.addFile() : this.addAttachment();
  }
  _submitUpdateAttachment(e11, t3) {
    e11.preventDefault(), t3 && "file" in t3 ? this.updateFile() : this.updateAttachment();
  }
  _startEditAttachment(e11) {
    const { viewModel: t3 } = this;
    t3.activeFileInfo = null, t3.activeAttachmentInfo = e11, t3.mode = "edit";
  }
  _startEditFile(e11) {
    const { viewModel: t3 } = this;
    t3.activeAttachmentInfo = null, t3.activeFileInfo = e11, t3.mode = "edit";
  }
  _startAddAttachment() {
    this.viewModel.mode = "add";
  }
  _cancelForm(e11) {
    e11.preventDefault(), this.viewModel.mode = "view";
  }
  _getCSSTransform(e11) {
    const { orientationInfo: t3 } = e11;
    return !this._supportsImageOrientation && t3 ? [t3.rotation ? `rotate(${t3.rotation}deg)` : "", t3.mirrored ? "scaleX(-1)" : ""].join(" ") : "";
  }
};
r([m()], M2.prototype, "capabilities", null), r([m()], M2.prototype, "displayType", void 0), r([m({ readOnly: true })], M2.prototype, "effectiveDisplayType", null), r([m()], M2.prototype, "graphic", null), r([m()], M2.prototype, "icon", null), r([m()], M2.prototype, "label", null), r([m(), e3("esri/widgets/Attachments/t9n/Attachments")], M2.prototype, "messages", void 0), r([m(), e3("esri/core/t9n/Units")], M2.prototype, "messagesUnits", void 0), r([m({ readOnly: true })], M2.prototype, "selectedFile", void 0), r([m({ readOnly: true })], M2.prototype, "submitting", void 0), r([m({ readOnly: true })], M2.prototype, "error", void 0), r([m({ type: A2 })], M2.prototype, "viewModel", void 0), r([m()], M2.prototype, "visibleElements", void 0), r([s4("visibleElements")], M2.prototype, "castVisibleElements", null), M2 = r([a("esri.widgets.Attachments")], M2);
var I2 = M2;

// node_modules/@arcgis/core/widgets/Feature/FeatureAttachments/FeatureAttachmentsViewModel.js
var s6 = class extends A2 {
  constructor(t3) {
    super(t3), this.description = null, this.title = null;
  }
};
r([m()], s6.prototype, "description", void 0), r([m()], s6.prototype, "title", void 0), s6 = r([a("esri.widgets.Feature.FeatureAttachments.FeatureAttachmentsViewModel")], s6);
var c7 = s6;

// node_modules/@arcgis/core/widgets/Feature/support/FeatureElementInfo.js
var n6 = "esri-feature-element-info";
var p4 = { base: n6, title: `${n6}__title`, description: `${n6}__description` };
var c8 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this.description = null, this.headingLevel = 2, this.title = null;
  }
  render() {
    return n2("div", { class: p4.base }, this._renderTitle(), this._renderDescription());
  }
  _renderTitle() {
    const { title: e11 } = this;
    return e11 ? n2(e6, { class: p4.title, innerHTML: e11, level: this.headingLevel }) : null;
  }
  _renderDescription() {
    const { description: e11 } = this;
    return e11 ? n2("div", { class: p4.description, innerHTML: e11, key: "description" }) : null;
  }
};
r([m()], c8.prototype, "description", void 0), r([m()], c8.prototype, "headingLevel", void 0), r([m()], c8.prototype, "title", void 0), c8 = r([a("esri.widgets.Feature.support.FeatureElementInfo")], c8);
var l2 = c8;

// node_modules/@arcgis/core/widgets/Feature/FeatureAttachments.js
var d6 = { base: "esri-feature-attachments" };
var h2 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this._featureElementInfo = null, this.attachmentsWidget = new I2(), this.headingLevel = 2, this.viewModel = new c7();
  }
  initialize() {
    this._featureElementInfo = new l2(), this.addHandles([d3(() => [this.viewModel?.description, this.viewModel?.title, this.headingLevel], () => this._setupFeatureElementInfo(), P), d3(() => this.viewModel, (e11) => this.attachmentsWidget.viewModel = e11, P)]);
  }
  destroy() {
    this.attachmentsWidget.viewModel = null, this.attachmentsWidget.destroy(), this._featureElementInfo?.destroy();
  }
  get description() {
    return this.viewModel.description;
  }
  set description(e11) {
    this.viewModel.description = e11;
  }
  get displayType() {
    return this.attachmentsWidget.displayType;
  }
  set displayType(e11) {
    this.attachmentsWidget.displayType = e11;
  }
  get graphic() {
    return this.viewModel.graphic;
  }
  set graphic(e11) {
    this.viewModel.graphic = e11;
  }
  get title() {
    return this.viewModel.title;
  }
  set title(e11) {
    this.viewModel.title = e11;
  }
  render() {
    const { attachmentsWidget: e11 } = this;
    return n2("div", { class: d6.base }, this._featureElementInfo?.render(), e11?.render());
  }
  _setupFeatureElementInfo() {
    const { description: e11, title: t3, headingLevel: i6 } = this;
    this._featureElementInfo?.set({ description: e11, title: t3, headingLevel: i6 });
  }
};
r([m({ readOnly: true })], h2.prototype, "attachmentsWidget", void 0), r([m()], h2.prototype, "description", null), r([m()], h2.prototype, "displayType", null), r([m()], h2.prototype, "graphic", null), r([m()], h2.prototype, "headingLevel", void 0), r([m()], h2.prototype, "title", null), r([m({ type: c7 })], h2.prototype, "viewModel", void 0), h2 = r([a("esri.widgets.Feature.FeatureAttachments")], h2);
var c9 = h2;

// node_modules/@arcgis/core/widgets/Feature/FeatureContent/FeatureContentViewModel.js
var c10 = class extends g {
  constructor(t3) {
    super(t3), this._loadingPromise = null, this.created = null, this.creator = null, this.destroyer = null, this.graphic = null, this.addHandles(d3(() => this.creator, (t4) => {
      this._destroyContent(), this._createContent(t4);
    }, P));
  }
  destroy() {
    this._destroyContent();
  }
  get state() {
    return this._loadingPromise ? "loading" : "ready";
  }
  _destroyContent() {
    const { created: t3, graphic: e11, destroyer: r3 } = this;
    t3 && e11 && (q({ type: "content", value: r3, event: { graphic: e11 } }), this._set("created", null));
  }
  _createContent(t3) {
    return __async(this, null, function* () {
      const e11 = this.graphic;
      if (!e11 || !t3) return;
      const r3 = q({ type: "content", value: t3, event: { graphic: e11 } });
      this._loadingPromise = r3, this.notifyChange("state");
      const o3 = yield r3;
      r3 === this._loadingPromise && (this._loadingPromise = null, this.notifyChange("state"), this._set("created", o3));
    });
  }
};
r([m({ readOnly: true })], c10.prototype, "created", void 0), r([m()], c10.prototype, "creator", void 0), r([m()], c10.prototype, "destroyer", void 0), r([m({ type: b2 })], c10.prototype, "graphic", void 0), r([m({ readOnly: true })], c10.prototype, "state", null), c10 = r([a("esri.widgets.Feature.FeatureContent.FeatureContentViewModel")], c10);
var p5 = c10;

// node_modules/@arcgis/core/widgets/Feature/FeatureContent.js
var n7 = "esri-feature-content";
var c11 = { base: n7, loaderContainer: `${n7}__loader-container`, loader: `${n7}__loader` };
var l3 = class extends O {
  constructor(e11, r3) {
    super(e11, r3), this.viewModel = null, this._addTargetToAnchors = (e12) => {
      Array.from(e12.querySelectorAll("a")).forEach((e13) => {
        x2(e13.href) && !e13.hasAttribute("target") && e13.setAttribute("target", "_blank");
      });
    };
  }
  get creator() {
    return this.viewModel?.creator;
  }
  set creator(e11) {
    this.viewModel && (this.viewModel.creator = e11);
  }
  get graphic() {
    return this.viewModel?.graphic;
  }
  set graphic(e11) {
    this.viewModel && (this.viewModel.graphic = e11);
  }
  render() {
    const e11 = this.viewModel?.state;
    return n2("div", { class: c11.base }, "loading" === e11 ? this._renderLoading() : this._renderCreated());
  }
  _renderLoading() {
    return n2("div", { class: c11.loaderContainer, key: "loader" }, n2("div", { class: c11.loader }));
  }
  _renderCreated() {
    const e11 = this.viewModel?.created;
    return e11 ? e11 instanceof HTMLElement ? n2("div", { afterCreate: this._attachToNode, bind: e11, key: e11 }) : e7(e11) ? n2("div", { key: e11 }, !e11.destroyed && e11.render()) : n2("div", { afterCreate: this._addTargetToAnchors, innerHTML: e11, key: e11 }) : null;
  }
  _attachToNode(e11) {
    const r3 = this;
    e11.appendChild(r3);
  }
};
r([m()], l3.prototype, "creator", null), r([m()], l3.prototype, "graphic", null), r([m({ type: p5 })], l3.prototype, "viewModel", void 0), l3 = r([a("esri.widgets.Feature.FeatureContent")], l3);
var p6 = l3;

// node_modules/@arcgis/core/widgets/Feature/FeatureFields/FeatureFieldsViewModel.js
var l4 = class extends g {
  constructor(o3) {
    super(o3), this.attributes = null, this.expressionInfos = null, this.description = null, this.fieldInfos = null, this.title = null;
  }
  get formattedFieldInfos() {
    const { expressionInfos: o3, fieldInfos: e11 } = this, t3 = [];
    return e11?.forEach((e12) => {
      if (!(!e12.hasOwnProperty("visible") || e12.visible)) return;
      const s7 = e12.clone();
      s7.label = C(s7, o3), t3.push(s7);
    }), t3;
  }
};
r([m()], l4.prototype, "attributes", void 0), r([m({ type: [i2] })], l4.prototype, "expressionInfos", void 0), r([m()], l4.prototype, "description", void 0), r([m({ type: [n5] })], l4.prototype, "fieldInfos", void 0), r([m({ readOnly: true })], l4.prototype, "formattedFieldInfos", null), r([m()], l4.prototype, "title", void 0), l4 = r([a("esri.widgets.Feature.FeatureFields.FeatureFieldsViewModel")], l4);
var n8 = l4;

// node_modules/@arcgis/core/widgets/Feature/FeatureFields.js
var u3 = "esri-feature-fields";
var m3 = { base: u3, fieldHeader: `${u3}__field-header`, fieldData: `${u3}__field-data`, fieldDataDate: `${u3}__field-data--date` };
var c12 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this._featureElementInfo = null, this.viewModel = new n8(), this.messages = null, this.messagesURIUtils = null;
  }
  initialize() {
    this._featureElementInfo = new l2(), this.addHandles(d3(() => [this.viewModel?.description, this.viewModel?.title], () => this._setupFeatureElementInfo(), P));
  }
  destroy() {
    this._featureElementInfo?.destroy();
  }
  get attributes() {
    return this.viewModel.attributes;
  }
  set attributes(e11) {
    this.viewModel.attributes = e11;
  }
  get description() {
    return this.viewModel.description;
  }
  set description(e11) {
    this.viewModel.description = e11;
  }
  get expressionInfos() {
    return this.viewModel.expressionInfos;
  }
  set expressionInfos(e11) {
    this.viewModel.expressionInfos = e11;
  }
  get fieldInfos() {
    return this.viewModel.fieldInfos;
  }
  set fieldInfos(e11) {
    this.viewModel.fieldInfos = e11;
  }
  get title() {
    return this.viewModel.title;
  }
  set title(e11) {
    this.viewModel.title = e11;
  }
  render() {
    return n2("div", { class: m3.base }, this._featureElementInfo?.render(), this._renderFields());
  }
  _renderFieldInfo(e11, t3) {
    const { attributes: s7 } = this.viewModel, i6 = e11.fieldName || "", r3 = e11.label || i6, o3 = s7 ? null == s7[i6] ? "" : s7[i6] : "", l6 = !!e11.format?.dateFormat, n10 = "number" == typeof o3 && !l6 ? this._forceLTR(o3) : a4(this.messagesURIUtils, o3), d9 = { [m3.fieldDataDate]: l6 };
    return n2("tr", { key: `fields-element-info-row-${i6}-${t3}` }, n2("th", { class: m3.fieldHeader, innerHTML: r3, key: `fields-element-info-row-header-${i6}-${t3}` }), n2("td", { class: this.classes(m3.fieldData, d9), innerHTML: n10, key: `fields-element-info-row-data-${i6}-${t3}` }));
  }
  _renderFields() {
    const { formattedFieldInfos: e11 } = this.viewModel;
    return e11?.length ? n2("table", { class: e5.table, summary: this.messages.fieldsSummary }, n2("tbody", null, e11.map((e12, t3) => this._renderFieldInfo(e12, t3)))) : null;
  }
  _setupFeatureElementInfo() {
    const { description: e11, title: t3 } = this;
    this._featureElementInfo?.set({ description: e11, title: t3 });
  }
  _forceLTR(e11) {
    return `&lrm;${e11}`;
  }
};
r([m()], c12.prototype, "attributes", null), r([m()], c12.prototype, "description", null), r([m()], c12.prototype, "expressionInfos", null), r([m()], c12.prototype, "fieldInfos", null), r([m()], c12.prototype, "title", null), r([m({ type: n8, nonNullable: true })], c12.prototype, "viewModel", void 0), r([m(), e3("esri/widgets/Feature/t9n/Feature")], c12.prototype, "messages", void 0), r([m(), e3("esri/widgets/support/t9n/uriUtils")], c12.prototype, "messagesURIUtils", void 0), c12 = r([a("esri.widgets.Feature.FeatureFields")], c12);
var h3 = c12;

// node_modules/@arcgis/core/widgets/Feature/support/relatedFeatureUtils.js
var d7 = "esri.widgets.Feature.support.relatedFeatureUtils";
var p7 = () => n.getLogger(d7);
var m4 = /* @__PURE__ */ new Map();
function h4(e11) {
  if (!pe(e11)) return null;
  const [t3, r3] = e11.split("/").slice(1);
  return { layerId: t3, fieldName: r3 };
}
function y4(e11, t3) {
  if (!t3.relationships) return null;
  let r3 = null;
  const { relationships: i6 } = t3;
  return i6.some((t4) => t4.id === parseInt(e11, 10) && (r3 = t4, true)), r3;
}
function I3({ originRelationship: e11, relationships: t3, layerId: r3 }) {
  return t3.find(({ relatedTableId: t4, id: i6 }) => `${t4}` === r3 && i6 === e11?.id) ?? null;
}
function F2(e11, t3) {
  const r3 = t3.toLowerCase();
  for (const i6 in e11) if (i6.toLowerCase() === r3) return e11[i6];
  return null;
}
function g4(e11, t3) {
  const r3 = y4(e11, t3);
  if (!r3) return;
  return { url: `${t3.url}/${r3.relatedTableId}`, sourceSpatialReference: t3.spatialReference, relation: r3, relatedFields: [], outStatistics: [] };
}
function S(e11, t3) {
  if (!t3) return;
  if (!e11) return;
  const { features: r3, statsFeatures: i6 } = e11, o3 = r3?.value;
  t3.relatedFeatures = o3 ? o3.features : [];
  const s7 = i6?.value;
  t3.relatedStatsFeatures = s7 ? s7.features : [];
}
function b4(e11, t3, r3, i6) {
  const o3 = new d5();
  return o3.outFields = ["*"], o3.relationshipId = "number" == typeof t3.id ? t3.id : parseInt(t3.id, 10), o3.objectIds = [e11.attributes[r3.objectIdField]], o3.gdbVersion = r3.gdbVersion ?? null, o3.historicMoment = r3.historicMoment ?? null, r3.queryRelatedFeatures?.(o3, i6) ?? Promise.resolve({});
}
function w4(e11, t3, r3) {
  let i6 = 0;
  const o3 = [];
  for (; i6 < t3.length; ) o3.push(`${e11} IN (${t3.slice(i6, r3 + i6)})`), i6 += r3;
  return o3.join(" OR ");
}
function j2(e11) {
  return e11 ? c(e11) : void 0;
}
function R2(e11) {
  return e11 ? c(e11, (e12, t3) => JSON.stringify(e12.toJSON()) === JSON.stringify(t3.toJSON())) : void 0;
}
function $(e11, t3, r3, i6) {
  return __async(this, null, function* () {
    const o3 = r3.layerId.toString(), { layerInfo: u6, relation: c14, relatedFields: f5, outStatistics: d9, url: p9, sourceSpatialReference: m8 } = t3, h7 = j2(f5), y9 = R2(d9);
    if (!u6 || !c14) return null;
    const g10 = I3({ originRelationship: c14, relationships: u6.relationships, layerId: o3 });
    if (g10?.relationshipTableId && g10.keyFieldInRelationshipTable) {
      const t4 = (yield b4(e11, g10, r3, i6))[e11.attributes[r3.objectIdField]];
      if (!t4) return null;
      const o4 = t4.features.map((e12) => e12.attributes[u6.objectIdField]);
      if (y9?.length && u6.supportsStatistics) {
        const e12 = new b3();
        e12.where = w4(u6.objectIdField, o4, 1e3), e12.outFields = h7, e12.outStatistics = y9, e12.sourceSpatialReference = m8;
        const r4 = { features: Promise.resolve(t4), statsFeatures: s5(p9, e12) };
        return y(r4);
      }
    }
    const S2 = g10?.keyField;
    if (S2) {
      const t4 = ge(L2(u6.fields, S2)), o4 = F2(e11.attributes, c14.keyField), f6 = t4 ? `${S2}=${o4}` : `${S2}='${o4}'`, d10 = r3.historicMoment, I7 = r3.gdbVersion, g11 = s5(p9, new b3({ where: f6, outFields: h7, sourceSpatialReference: m8, historicMoment: d10, gdbVersion: I7 }), i6), b9 = !!y9?.length && u6.supportsStatistics ? s5(p9, new b3({ where: f6, outFields: h7, outStatistics: y9, sourceSpatialReference: m8 }), i6) : null, w8 = { features: g11 };
      return b9 && (w8.statsFeatures = b9), y(w8);
    }
    return null;
  });
}
function N(t3, r3) {
  return P2(t3, { query: { f: "json" }, signal: r3?.signal });
}
function v2({ relatedInfos: e11, layer: t3 }, i6) {
  const n10 = {};
  return e11.forEach((e12, i7) => {
    const { relation: o3 } = e12;
    if (!o3) {
      const e13 = new s("relation-required", "A relation is required on a layer to retrieve related records.");
      throw p7().error(e13), e13;
    }
    const { relatedTableId: s7 } = o3;
    if ("number" != typeof s7) {
      const e13 = new s("A related table ID is required on a layer to retrieve related records.");
      throw p7().error(e13), e13;
    }
    const l6 = `${t3.url}/${s7}`, a5 = m4.get(l6), u6 = a5 ?? N(l6);
    a5 || m4.set(l6, u6), n10[i7] = u6;
  }), h(y(n10), i6);
}
function T2({ graphic: e11, relatedInfos: t3, layer: r3 }, i6) {
  const o3 = {};
  return t3.forEach((t4, s7) => {
    t4.layerInfo && (o3[s7] = $(e11, t4, r3, i6));
  }), y(o3);
}
function q2({ relatedInfo: e11, fieldName: t3, fieldInfo: r3 }) {
  if (e11.relatedFields?.push(t3), r3.statisticType) {
    const i6 = new m2({ statisticType: r3.statisticType, onStatisticField: t3, outStatisticFieldName: t3 });
    e11.outStatistics?.push(i6);
  }
}
function L2(e11, t3) {
  if (null != e11) {
    t3 = t3.toLowerCase();
    for (const r3 of e11) if (r3 && r3.name.toLowerCase() === t3) return r3;
  }
  return null;
}

// node_modules/@arcgis/core/widgets/Feature/FeatureMedia/FeatureMediaViewModel.js
var I4 = { chartAnimation: true };
var v3 = class extends g {
  constructor(t3) {
    super(t3), this.abilities = __spreadValues({}, I4), this.activeMediaInfoIndex = 0, this.attributes = null, this.description = null, this.fieldInfoMap = null, this.formattedAttributes = null, this.expressionAttributes = null, this.isAggregate = false, this.layer = null, this.mediaInfos = null, this.popupTemplate = null, this.relatedInfos = null, this.title = null;
  }
  castAbilities(t3) {
    return __spreadValues(__spreadValues({}, I4), t3);
  }
  get activeMediaInfo() {
    return this.formattedMediaInfos[this.activeMediaInfoIndex] || null;
  }
  get formattedMediaInfos() {
    return this._formatMediaInfos() || [];
  }
  get formattedMediaInfoCount() {
    return this.formattedMediaInfos.length;
  }
  setActiveMedia(t3) {
    this._setContentElementMedia(t3);
  }
  next() {
    this._pageContentElementMedia(1);
  }
  previous() {
    this._pageContentElementMedia(-1);
  }
  _setContentElementMedia(t3) {
    const { formattedMediaInfoCount: e11 } = this, i6 = (t3 + e11) % e11;
    this.activeMediaInfoIndex = i6;
  }
  _pageContentElementMedia(t3) {
    const { activeMediaInfoIndex: e11 } = this, i6 = e11 + t3;
    this._setContentElementMedia(i6);
  }
  _formatMediaInfos() {
    const { mediaInfos: t3, layer: e11 } = this, o3 = this.attributes ?? {}, r3 = this.formattedAttributes ?? {}, a5 = this.expressionAttributes ?? {}, s7 = this.fieldInfoMap ?? /* @__PURE__ */ new Map();
    return t3?.map((t4) => {
      const i6 = t4?.clone();
      if (!i6) return null;
      if (i6.title = D({ attributes: o3, fieldInfoMap: s7, globalAttributes: r3, expressionAttributes: a5, layer: e11, text: i6.title }), i6.caption = D({ attributes: o3, fieldInfoMap: s7, globalAttributes: r3, expressionAttributes: a5, layer: e11, text: i6.caption }), i6.altText = D({ attributes: o3, fieldInfoMap: s7, globalAttributes: r3, expressionAttributes: a5, layer: e11, text: i6.altText }), "image" === i6.type) {
        if (!i6.value) return;
        return this._setImageValue({ value: i6.value, formattedAttributes: r3, layer: e11 }), i6.value.sourceURL ? i6 : void 0;
      }
      if ("pie-chart" === i6.type || "line-chart" === i6.type || "column-chart" === i6.type || "bar-chart" === i6.type) {
        if (!i6.value) return;
        return this._setChartValue({ value: i6.value, chartType: i6.type, attributes: o3, formattedAttributes: r3, layer: e11, expressionAttributes: a5 }), i6;
      }
      return null;
    }).filter(G) ?? [];
  }
  _setImageValue(t3) {
    const e11 = this.fieldInfoMap ?? /* @__PURE__ */ new Map(), { value: i6, formattedAttributes: o3, layer: r3 } = t3, { linkURL: a5, sourceURL: s7 } = i6;
    if (s7) {
      const t4 = Q(s7, r3);
      i6.sourceURL = O2({ formattedAttributes: o3, template: t4, fieldInfoMap: e11 });
    }
    if (a5) {
      const t4 = Q(a5, r3);
      i6.linkURL = O2({ formattedAttributes: o3, template: t4, fieldInfoMap: e11 });
    }
  }
  _setChartValue(t3) {
    const { value: e11, attributes: i6, formattedAttributes: o3, chartType: r3, layer: a5, expressionAttributes: s7 } = t3, { popupTemplate: l6, relatedInfos: n10 } = this, { fields: p9, normalizeField: d9 } = e11, m8 = a5;
    e11.fields = R(p9, m8), d9 && (e11.normalizeField = M(d9, m8));
    if (!p9.some((t4) => !!(null != o3[t4] || pe(t4) && n10?.size))) return;
    const h7 = l6?.fieldInfos ?? [];
    p9.forEach((t4, a6) => {
      const l7 = e11.colors?.[a6];
      if (pe(t4)) return void (e11.series = [...e11.series, ...this._getRelatedChartInfos({ fieldInfos: h7, fieldName: t4, formattedAttributes: o3, chartType: r3, value: e11, color: l7 })]);
      const n11 = this._getChartOption({ value: e11, attributes: i6, chartType: r3, formattedAttributes: o3, expressionAttributes: s7, fieldName: t4, fieldInfos: h7, color: l7 });
      e11.series.push(n11);
    });
  }
  _getRelatedChartInfos(t3) {
    const { fieldInfos: e11, fieldName: i6, formattedAttributes: o3, chartType: r3, value: a5, color: s7 } = t3, l6 = [], n10 = h4(i6), p9 = n10 && this.relatedInfos?.get(n10.layerId.toString());
    if (!p9) return l6;
    const { relatedFeatures: d9, relation: u6 } = p9;
    if (!u6 || !d9) return l6;
    const { cardinality: f5 } = u6;
    d9.forEach((t4) => {
      const { attributes: p10 } = t4;
      p10 && Object.keys(p10).forEach((t5) => {
        t5 === n10.fieldName && l6.push(this._getChartOption({ value: a5, attributes: p10, formattedAttributes: o3, fieldName: i6, chartType: r3, relatedFieldName: t5, hasMultipleRelatedFeatures: d9?.length > 1, fieldInfos: e11, color: s7 }));
      });
    });
    return "one-to-many" === f5 || "many-to-many" === f5 ? l6 : [l6[0]];
  }
  _getTooltip({ label: t3, value: e11, chartType: i6 }) {
    return "pie-chart" === i6 ? `${t3}` : `${t3}: ${e11}`;
  }
  _getChartOption(t3) {
    const { value: e11, attributes: i6, formattedAttributes: o3, expressionAttributes: r3, fieldName: a5, relatedFieldName: n10, fieldInfos: p9, chartType: d9, hasMultipleRelatedFeatures: u6, color: I7 } = t3, v7 = this.layer, M6 = this.fieldInfoMap ?? /* @__PURE__ */ new Map(), { normalizeField: A5, tooltipField: g10 } = e11, x6 = A5 ? pe(A5) ? i6[h4(A5).fieldName] : i6[A5] : null, _3 = E(a5) && r3 && void 0 !== r3[a5] ? r3[a5] : n10 && void 0 !== i6[n10] ? i6[n10] : void 0 !== i6[a5] ? i6[a5] : o3[a5], C4 = new p2({ fieldName: a5, color: I7, value: void 0 === _3 ? null : _3 && x6 ? _3 / x6 : _3 });
    if (pe(a5)) {
      const t4 = M6.get(a5.toLowerCase()), e12 = g10 && M6.get(g10.toLowerCase()), r4 = t4?.fieldName ?? a5, s7 = u6 && g10 ? h4(g10).fieldName : e12?.fieldName ?? g10, l6 = u6 && s7 ? i6[s7] : o3[s7] ?? t4?.label ?? t4?.fieldName ?? n10, p10 = u6 && n10 ? i6[n10] : o3[r4];
      return C4.tooltip = this._getTooltip({ label: l6, value: p10, chartType: d9 }), C4;
    }
    const T4 = ee(p9, a5), N2 = M(a5, v7), F6 = g10 && void 0 !== o3[g10] ? o3[g10] : C(T4 || new n5({ fieldName: N2 }), this.popupTemplate?.expressionInfos), j4 = o3[N2];
    return C4.tooltip = this._getTooltip({ label: F6, value: j4, chartType: d9 }), C4;
  }
};
r([m()], v3.prototype, "abilities", void 0), r([s4("abilities")], v3.prototype, "castAbilities", null), r([m()], v3.prototype, "activeMediaInfoIndex", void 0), r([m({ readOnly: true })], v3.prototype, "activeMediaInfo", null), r([m()], v3.prototype, "attributes", void 0), r([m()], v3.prototype, "description", void 0), r([m()], v3.prototype, "fieldInfoMap", void 0), r([m()], v3.prototype, "formattedAttributes", void 0), r([m()], v3.prototype, "expressionAttributes", void 0), r([m({ readOnly: true })], v3.prototype, "formattedMediaInfos", null), r([m()], v3.prototype, "isAggregate", void 0), r([m()], v3.prototype, "layer", void 0), r([m({ readOnly: true })], v3.prototype, "formattedMediaInfoCount", null), r([m()], v3.prototype, "mediaInfos", void 0), r([m()], v3.prototype, "popupTemplate", void 0), r([m()], v3.prototype, "relatedInfos", void 0), r([m()], v3.prototype, "title", void 0), v3 = r([a("esri.widgets.Feature.FeatureMedia.FeatureMediaViewModel")], v3);
var M3 = v3;

// node_modules/@arcgis/core/widgets/Feature/FeatureMedia.js
var g5 = "esri-feature-media";
var v4 = { base: g5, mediaContainer: `${g5}__container`, mediaItemContainer: `${g5}__item-container`, mediaItem: `${g5}__item`, mediaItemText: `${g5}__item-text`, mediaItemTitle: `${g5}__item-title`, mediaItemCaption: `${g5}__item-caption`, mediaNavigation: `${g5}__item-navigation`, mediaPagination: `${g5}__pagination`, mediaPaginationText: `${g5}__pagination-text`, mediaPrevious: `${g5}__previous`, mediaPreviousIconLTR: `${g5}__previous-icon`, mediaPreviousIconRTL: `${g5}__previous-icon--rtl`, mediaNext: `${g5}__next`, mediaNextIconLTR: `${g5}__next-icon`, mediaNextIconRTL: `${g5}__next-icon--rtl`, mediaChart: `${g5}__chart`, mediaPaginationButton: `${g5}__pagination-button`, mediaPaginationIcon: `${g5}__pagination-icon`, mediaChartRendered: `${g5}__chart--rendered` };
var M4 = 15;
var w5 = "category";
var A4 = "value";
var I5 = "rgba(50, 50, 50, 1)";
var C2 = 250;
var y5 = 500;
var x4 = 200;
var T3 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this._refreshTimer = null, this._refreshIntervalInfo = null, this._featureElementInfo = null, this._chartRootMap = /* @__PURE__ */ new WeakMap(), this.viewModel = new M3(), this.messages = null, this._disposeChart = (e12) => {
      this._chartRootMap.get(e12)?.dispose(), this._chartRootMap.delete(e12);
    }, this._createChart = (e12) => __async(this, null, function* () {
      const { destroyed: t4, viewModel: i6 } = this;
      if (t4 || !i6 || !e12) return;
      const { createRoot: r3 } = yield import("./chartUtilsAm5-RBTI7YES.js"), a5 = yield r3(e12);
      this._chartRootMap.set(e12, a5), this._renderChart({ mediaInfo: i6.activeMediaInfo, root: a5 });
    });
  }
  initialize() {
    this._featureElementInfo = new l2(), this.addHandles([d3(() => [this.viewModel?.activeMediaInfo, this.viewModel?.activeMediaInfoIndex], () => this._setupMediaRefreshTimer(), P), d3(() => [this.viewModel?.description, this.viewModel?.title], () => this._setupFeatureElementInfo(), P)]);
  }
  loadDependencies() {
    return c3({ icon: () => import("./calcite-icon-TH7JL242.js") });
  }
  destroy() {
    this._clearMediaRefreshTimer(), this._featureElementInfo?.destroy();
  }
  get attributes() {
    return this.viewModel.attributes;
  }
  set attributes(e11) {
    this.viewModel.attributes = e11;
  }
  get activeMediaInfoIndex() {
    return this.viewModel.activeMediaInfoIndex;
  }
  set activeMediaInfoIndex(e11) {
    this.viewModel.activeMediaInfoIndex = e11;
  }
  get description() {
    return this.viewModel.description;
  }
  set description(e11) {
    this.viewModel.description = e11;
  }
  get fieldInfoMap() {
    return this.viewModel.fieldInfoMap;
  }
  set fieldInfoMap(e11) {
    this.viewModel.fieldInfoMap = e11;
  }
  get layer() {
    return this.viewModel.layer;
  }
  set layer(e11) {
    this.viewModel.layer = e11;
  }
  get mediaInfos() {
    return this.viewModel.mediaInfos;
  }
  set mediaInfos(e11) {
    this.viewModel.mediaInfos = e11;
  }
  get popupTemplate() {
    return this.viewModel.popupTemplate;
  }
  set popupTemplate(e11) {
    this.viewModel.popupTemplate = e11;
  }
  get relatedInfos() {
    return this.viewModel.relatedInfos;
  }
  set relatedInfos(e11) {
    this.viewModel.relatedInfos = e11;
  }
  get title() {
    return this.viewModel.title;
  }
  set title(e11) {
    this.viewModel.title = e11;
  }
  render() {
    return n2("div", { bind: this, class: v4.base, onkeyup: this._handleMediaKeyup }, this._featureElementInfo?.render(), this._renderMedia());
  }
  _renderMedia() {
    const { formattedMediaInfoCount: e11, activeMediaInfoIndex: t3 } = this.viewModel, i6 = this._renderMediaText();
    return e11 ? n2("div", { class: v4.mediaContainer, key: "media-element-container" }, this._renderMediaInfo(), n2("div", { class: v4.mediaNavigation }, i6, e11 > 1 ? n2("div", { class: v4.mediaPagination }, this._renderMediaPageButton("previous"), n2("span", { class: v4.mediaPaginationText }, s3(this.messages.pageText, { index: t3 + 1, total: e11 })), this._renderMediaPageButton("next")) : null)) : null;
  }
  _renderMediaText() {
    const { activeMediaInfo: e11 } = this.viewModel;
    if (!e11) return null;
    const t3 = e11 && e11.title ? n2("div", { class: v4.mediaItemTitle, innerHTML: e11.title, key: "media-title" }) : null, i6 = e11 && e11.caption ? n2("div", { class: v4.mediaItemCaption, innerHTML: e11.caption, key: "media-caption" }) : null;
    return t3 || i6 ? n2("div", { class: v4.mediaItemText, key: "media-text" }, t3, i6) : null;
  }
  _renderImageMediaInfo(e11) {
    if (!e11.value) return null;
    const { _refreshIntervalInfo: t3 } = this, { activeMediaInfoIndex: i6, formattedMediaInfoCount: r3 } = this.viewModel, { value: a5, refreshInterval: o3, altText: s7, title: n10, type: l6 } = e11, { sourceURL: d9, linkURL: c14 } = a5, p9 = x2(c14 ?? void 0) ? "_blank" : "_self", h7 = "_blank" === p9 ? "noreferrer" : "", f5 = o3 ? t3 : null, _3 = f5 ? f5.timestamp : 0, g10 = f5 ? f5.sourceURL : d9, v7 = n2("img", { alt: s7 || n10, key: `media-${l6}-${i6}-${r3}-${_3}`, src: g10 ?? void 0 });
    return (c14 ? n2("a", { href: c14, rel: h7, target: p9, title: n10 }, v7) : null) ?? v7;
  }
  _renderChartMediaInfo(e11) {
    const { activeMediaInfoIndex: t3, formattedMediaInfoCount: i6 } = this.viewModel;
    return n2("div", { afterCreate: this._createChart, afterRemoved: this._disposeChart, bind: this, class: v4.mediaChart, key: `media-${e11.type}-${t3}-${i6}` });
  }
  _renderMediaInfoType() {
    const { activeMediaInfo: e11 } = this.viewModel;
    return e11 ? "image" === e11.type ? this._renderImageMediaInfo(e11) : e11.type.includes("chart") ? this._renderChartMediaInfo(e11) : null : null;
  }
  _renderMediaInfo() {
    const { activeMediaInfo: e11 } = this.viewModel;
    return e11 ? n2("div", { class: v4.mediaItemContainer, key: "media-container" }, n2("div", { class: v4.mediaItem, key: "media-item-container" }, this._renderMediaInfoType())) : null;
  }
  _renderMediaPageButton(e11) {
    if (this.viewModel.formattedMediaInfoCount < 2) return null;
    const t3 = "previous" === e11, i6 = t3 ? this.messages.previous : this.messages.next, r3 = t3 ? "chevron-left" : "chevron-right", a5 = t3 ? "media-previous" : "media-next", o3 = t3 ? this._previous : this._next;
    return n2("button", { "aria-label": i6, bind: this, class: v4.mediaPaginationButton, key: a5, onclick: o3, tabIndex: 0, title: i6, type: "button" }, n2("calcite-icon", { class: v4.mediaPaginationIcon, icon: r3, scale: "s" }));
  }
  _setupFeatureElementInfo() {
    const { description: e11, title: t3 } = this;
    this._featureElementInfo?.set({ description: e11, title: t3 });
  }
  _next() {
    this.viewModel.next();
  }
  _previous() {
    this.viewModel.previous();
  }
  _getRenderer() {
    if (!this.viewModel) return;
    const { isAggregate: e11, layer: t3 } = this.viewModel;
    return e11 && t3?.featureReduction && "renderer" in t3.featureReduction ? t3.featureReduction.renderer : t3?.renderer;
  }
  _getSeriesColors(e11) {
    return __async(this, null, function* () {
      const { colorAm5: t3 } = yield import("./chartCommon-M6B4PDLF.js"), i6 = /* @__PURE__ */ new Map();
      return e11.forEach((e12) => {
        e12.color && i6.set(e12, t3(e12.color.toCss(true)));
      }), i6;
    });
  }
  _getRendererColors() {
    return __async(this, null, function* () {
      const { colorAm5: e11 } = yield import("./chartCommon-M6B4PDLF.js"), t3 = /* @__PURE__ */ new Map(), i6 = this._getRenderer(), r3 = "default";
      if (!i6) return t3;
      const a5 = yield x3(i6);
      a5.delete(r3);
      return Array.from(a5.values()).every((e12) => 1 === e12?.length) ? (Array.from(a5.keys()).forEach((i7) => {
        const r4 = a5.get(i7)?.[0]?.toCss(true);
        r4 && t3.set(i7, e11(r4));
      }), t3) : t3;
    });
  }
  _handleMediaKeyup(e11) {
    const { key: t3 } = e11;
    "ArrowLeft" === t3 && (e11.stopPropagation(), this.viewModel.previous()), "ArrowRight" === t3 && (e11.stopPropagation(), this.viewModel.next());
  }
  _canAnimateChart() {
    return !!this.viewModel && (!!this.viewModel.abilities.chartAnimation && !o());
  }
  _getChartAnimationMS() {
    return this._canAnimateChart() ? C2 : 0;
  }
  _getChartSeriesAnimationMS() {
    return this._canAnimateChart() ? y5 : 0;
  }
  _renderChart(e11) {
    return __async(this, null, function* () {
      const { root: t3, mediaInfo: i6 } = e11, { value: r3, type: a5 } = i6, { ResponsiveThemeAm5: o3, DarkThemeAm5: s7, AnimatedThemeAm5: n10, ColorSetAm5: l6, ThemeAm5: d9, esriChartColorSet: m8 } = yield import("./chartCommon-M6B4PDLF.js"), c14 = d9.new(t3);
      c14.rule("ColorSet").set("colors", m8), c14.rule("ColorSet").set("reuse", true);
      const p9 = [o3.new(t3), c14];
      r2() && p9.push(s7.new(t3)), this._canAnimateChart() && p9.push(n10.new(t3)), t3.setThemes(p9);
      const h7 = yield this._getRendererColors(), u6 = yield this._getSeriesColors(r3.series), _3 = l6.new(t3, {}), g10 = u6.get(r3.series[0]), v7 = g10 ? { lineSettings: { stroke: g10 } } : void 0, M6 = r3.series.map((e12, t4) => {
        const i7 = u6.get(e12) || h7.get(e12.fieldName) || _3.getIndex(t4);
        return __spreadValues({ [w5]: e12.tooltip, [A4]: e12.value, columnSettings: { fill: i7, stroke: i7 } }, v7);
      }).filter((e12) => "pie-chart" !== a5 || null != e12.value && e12.value > 0);
      "pie-chart" === a5 ? this._createPieChart(e11, M6) : this._createXYChart(e11, M6);
    });
  }
  _getDirection() {
    return g2(this.container) ? "rtl" : "ltr";
  }
  _customizeChartTooltip(e11, t3 = "horizontal") {
    return __async(this, null, function* () {
      const { colorAm5: i6 } = yield import("./chartCommon-M6B4PDLF.js");
      e11.setAll({ pointerOrientation: t3 }), e11.get("background")?.setAll({ stroke: i6(I5) }), e11.label.setAll({ direction: this._getDirection(), oversizedBehavior: "wrap", maxWidth: x4 });
    });
  }
  _createPieChart(e11, t3) {
    return __async(this, null, function* () {
      const { TooltipAm5: i6 } = yield import("./chartCommon-M6B4PDLF.js"), { PieChartAm5: r3, PieSeriesAm5: a5 } = yield import("./pieChart-VZQXQYJM.js"), { mediaInfo: o3, root: s7 } = e11, { title: n10 } = o3, l6 = 5, d9 = o3?.altText || o3?.title || "", m8 = s7.container.children.push(r3.new(s7, { ariaLabel: d9, focusable: true, paddingBottom: l6, paddingTop: l6, paddingLeft: l6, paddingRight: l6 })), c14 = "{category}: {valuePercentTotal.formatNumber('0.00')}%\n ({value})", p9 = i6.new(s7, { labelText: c14 }), h7 = m8.series.push(a5.new(s7, { name: n10, valueField: A4, categoryField: w5, tooltip: p9 }));
      h7.ticks.template.set("forceHidden", true), h7.labels.template.set("forceHidden", true), h7.slices.template.states.create("active", { shiftRadius: l6 }), this._customizeChartTooltip(p9), h7.slices.template.setAll({ ariaLabel: c14, focusable: true, templateField: "columnSettings" }), h7.data.setAll(t3), h7.appear(this._getChartSeriesAnimationMS()), m8.appear(this._getChartAnimationMS()), m8.root.dom.classList.toggle(v4.mediaChartRendered, true);
    });
  }
  _getMinSeriesValue(e11) {
    let t3 = 0;
    return e11.forEach((e12) => t3 = Math.min(e12.value, t3)), t3;
  }
  _createColumnChart(e11, t3, i6) {
    return __async(this, null, function* () {
      const { TooltipAm5: r3, ScrollbarAm5: a5 } = yield import("./chartCommon-M6B4PDLF.js"), { CategoryAxisAm5: o3, AxisRendererXAm5: s7, ValueAxisAm5: n10, AxisRendererYAm5: l6, ColumnSeriesAm5: d9 } = yield import("./xyChart-WUFGQA7D.js"), { mediaInfo: m8, root: c14 } = t3, { value: h7, title: u6 } = m8;
      e11.setAll({ wheelX: "panX", wheelY: "zoomX" });
      const f5 = e11.xAxes.push(o3.new(c14, { renderer: s7.new(c14, { inversed: g2(this.container) }), categoryField: w5 }));
      f5.get("renderer").labels.template.setAll({ forceHidden: true });
      const _3 = e11.yAxes.push(n10.new(c14, { renderer: l6.new(c14, { inside: false }), min: this._getMinSeriesValue(h7.series) }));
      _3.get("renderer").labels.template.setAll({ direction: this._getDirection() });
      const g10 = "{categoryX}", v7 = r3.new(c14, { labelText: g10 }), I7 = e11.series.push(d9.new(c14, { name: u6, xAxis: f5, yAxis: _3, valueYField: A4, categoryXField: w5, tooltip: v7 }));
      this._customizeChartTooltip(v7), I7.columns.template.setAll({ ariaLabel: g10, focusable: true, templateField: "columnSettings" }), h7.series.length > M4 && e11.set("scrollbarX", a5.new(c14, { orientation: "horizontal" })), f5.data.setAll(i6), I7.data.setAll(i6), I7.appear(this._getChartSeriesAnimationMS()), e11.appear(this._getChartAnimationMS());
    });
  }
  _createBarChart(e11, t3, i6) {
    return __async(this, null, function* () {
      const { TooltipAm5: r3, ScrollbarAm5: a5 } = yield import("./chartCommon-M6B4PDLF.js"), { CategoryAxisAm5: o3, AxisRendererXAm5: s7, ValueAxisAm5: n10, AxisRendererYAm5: l6, ColumnSeriesAm5: d9 } = yield import("./xyChart-WUFGQA7D.js"), { mediaInfo: m8, root: c14 } = t3, { value: h7, title: u6 } = m8;
      e11.setAll({ wheelX: "panY", wheelY: "zoomY" });
      const f5 = e11.yAxes.push(o3.new(c14, { renderer: l6.new(c14, { inversed: true }), categoryField: w5 }));
      f5.get("renderer").labels.template.setAll({ forceHidden: true });
      const _3 = e11.xAxes.push(n10.new(c14, { renderer: s7.new(c14, { inside: false, inversed: g2(this.container) }), min: this._getMinSeriesValue(h7.series) }));
      _3.get("renderer").labels.template.setAll({ direction: this._getDirection() });
      const g10 = "{categoryY}", v7 = r3.new(c14, { labelText: g10 }), I7 = e11.series.push(d9.new(c14, { name: u6, xAxis: _3, yAxis: f5, valueXField: A4, categoryYField: w5, tooltip: v7 }));
      this._customizeChartTooltip(v7, "vertical"), I7.columns.template.setAll({ ariaLabel: g10, focusable: true, templateField: "columnSettings" }), h7.series.length > M4 && e11.set("scrollbarY", a5.new(c14, { orientation: "vertical" })), f5.data.setAll(i6), I7.data.setAll(i6), I7.appear(this._getChartSeriesAnimationMS()), e11.appear(this._getChartAnimationMS());
    });
  }
  _createLineChart(e11, t3, i6) {
    return __async(this, null, function* () {
      const { TooltipAm5: r3, ScrollbarAm5: a5 } = yield import("./chartCommon-M6B4PDLF.js"), { CategoryAxisAm5: o3, AxisRendererXAm5: s7, ValueAxisAm5: n10, AxisRendererYAm5: l6, LineSeriesAm5: d9 } = yield import("./xyChart-WUFGQA7D.js"), { root: m8, mediaInfo: c14 } = t3, { value: h7, title: u6 } = c14;
      e11.setAll({ wheelX: "panX", wheelY: "zoomX" });
      const f5 = e11.xAxes.push(o3.new(m8, { renderer: s7.new(m8, { inversed: g2(this.container) }), categoryField: w5 }));
      f5.get("renderer").labels.template.setAll({ forceHidden: true });
      const _3 = e11.yAxes.push(n10.new(m8, { renderer: l6.new(m8, { inside: false }), min: this._getMinSeriesValue(h7.series) }));
      _3.get("renderer").labels.template.setAll({ direction: this._getDirection() });
      const g10 = "{categoryX}", v7 = i6[0]?.lineSettings?.stroke, I7 = r3.new(m8, { getFillFromSprite: !v7, labelText: g10 });
      v7 && I7.get("background")?.setAll({ fill: v7 });
      const C4 = e11.series.push(d9.new(m8, { name: u6, xAxis: f5, yAxis: _3, valueYField: A4, categoryXField: w5, tooltip: I7 }));
      C4.strokes.template.setAll({ templateField: "lineSettings" }), this._customizeChartTooltip(I7, "vertical"), h7.series.length > M4 && e11.set("scrollbarX", a5.new(m8, { orientation: "horizontal" })), f5.data.setAll(i6), C4.data.setAll(i6), C4.appear(this._getChartSeriesAnimationMS()), e11.appear(this._getChartAnimationMS());
    });
  }
  _createXYChart(e11, t3) {
    return __async(this, null, function* () {
      const { XYChartAm5: i6, XYCursorAm5: r3 } = yield import("./xyChart-WUFGQA7D.js"), { root: a5, mediaInfo: o3 } = e11, { type: s7 } = o3, n10 = o3?.altText || o3?.title || "", l6 = a5.container.children.push(i6.new(a5, { ariaLabel: n10, focusable: true, panX: true, panY: true }));
      l6.set("cursor", r3.new(a5, {})), "column-chart" === s7 && (yield this._createColumnChart(l6, e11, t3)), "bar-chart" === s7 && (yield this._createBarChart(l6, e11, t3)), "line-chart" === s7 && (yield this._createLineChart(l6, e11, t3)), l6.root.dom.classList.toggle(v4.mediaChartRendered, true);
    });
  }
  _clearMediaRefreshTimer() {
    const { _refreshTimer: e11 } = this;
    e11 && (clearTimeout(e11), this._refreshTimer = null);
  }
  _updateMediaInfoTimestamp(e11) {
    const t3 = Date.now();
    this._refreshIntervalInfo = { timestamp: t3, sourceURL: e11 && this._getImageSource(e11, t3) };
  }
  _setupMediaRefreshTimer() {
    this._clearMediaRefreshTimer();
    const { activeMediaInfo: e11 } = this.viewModel;
    "image" === e11?.type && e11?.refreshInterval > 0 && this._setRefreshTimeout(e11);
  }
  _setRefreshTimeout(e11) {
    const { refreshInterval: t3, value: i6 } = e11, r3 = 6e4 * t3;
    this._updateMediaInfoTimestamp(i6.sourceURL);
    const a5 = setInterval(() => {
      this._updateMediaInfoTimestamp(i6.sourceURL);
    }, r3);
    this._refreshTimer = a5;
  }
  _getImageSource(e11, t3) {
    const i6 = e11.includes("?") ? "&" : "?", [r3, a5 = ""] = e11.split("#");
    return `${r3}${i6}timestamp=${t3}${a5 ? "#" : ""}${a5}`;
  }
};
r([m()], T3.prototype, "_refreshIntervalInfo", void 0), r([m()], T3.prototype, "attributes", null), r([m()], T3.prototype, "activeMediaInfoIndex", null), r([m()], T3.prototype, "description", null), r([m()], T3.prototype, "fieldInfoMap", null), r([m()], T3.prototype, "layer", null), r([m()], T3.prototype, "mediaInfos", null), r([m()], T3.prototype, "popupTemplate", null), r([m()], T3.prototype, "relatedInfos", null), r([m()], T3.prototype, "title", null), r([m({ type: M3 })], T3.prototype, "viewModel", void 0), r([m(), e3("esri/widgets/Feature/t9n/Feature")], T3.prototype, "messages", void 0), T3 = r([a("esri.widgets.Feature.FeatureMedia")], T3);
var b5 = T3;

// node_modules/@arcgis/core/core/throttle.js
function e8(e11, t3, l6, n10) {
  let o3 = null, p9 = 1e3;
  "number" == typeof t3 ? (p9 = t3, n10 = l6) : (o3 = t3 ?? null, p9 = l6);
  let r3, u6 = 0;
  const a5 = () => {
    u6 = 0, e11.apply(n10, r3);
  }, c14 = (...e12) => {
    o3 && o3.apply(n10, e12), r3 = e12, p9 ? u6 || (u6 = setTimeout(a5, p9)) : a5();
  };
  return c14.remove = () => {
    u6 && (clearTimeout(u6), u6 = 0);
  }, c14.forceUpdate = () => {
    u6 && (clearTimeout(u6), a5());
  }, c14.hasPendingUpdates = () => !!u6, c14;
}

// node_modules/@arcgis/core/widgets/Feature/support/arcadeFeatureUtils.js
var o2 = "esri.widgets.Feature.support.arcadeFeatureUtils";
var i5 = () => n.getLogger(o2);
function c13(e11) {
  return "string" == typeof e11 ? le(ae(e11)) : Array.isArray(e11) ? p8(e11) : "esri.arcade.Dictionary" === e11?.declaredClass ? u4(e11) : e11;
}
function p8(e11) {
  return `<ul class="esri-widget__list">${e11.map((e12) => `<li>${"string" == typeof e12 ? le(ae(e12)) : e12}</li>`).join("")}</ul>`;
}
function u4(e11) {
  const r3 = e11.keys().map((r4) => {
    const t3 = e11.field(r4);
    return `<tr><th>${r4}</th><td>${"string" == typeof t3 ? le(ae(t3)) : t3}</td></tr>`;
  }).join("");
  return `<table class="${e5.table}">${r3}</table>`;
}
function l5() {
  return __async(this, null, function* () {
    const [e11, r3] = yield Promise.all([import("./arcade-VKG6PHKM.js"), import("./arcade-ZT27QWND.js")]);
    return { executor: e11, syntaxUtils: r3 };
  });
}
function d8(e11) {
  return "createQuery" in e11 && "queryFeatures" in e11;
}
function y6(_0) {
  return __async(this, arguments, function* ({ graphic: e11, view: r3, options: t3 }) {
    const { isAggregate: a5, layer: n10 } = e11;
    if (!a5 || !n10 || "2d" !== r3?.type) return [];
    const s7 = yield r3.whenLayerView(n10);
    if (!d8(s7)) return [];
    const o3 = s7.createQuery(), i6 = e11.getObjectId();
    o3.aggregateIds = null != i6 ? [i6] : [];
    const { features: c14 } = yield s7.queryFeatures(o3, t3);
    return c14;
  });
}
function f2({ layer: e11, aggregatedFeatures: r3, interceptor: a5 }) {
  const { fields: n10, objectIdField: s7, geometryType: o3, spatialReference: i6, displayField: c14 } = e11;
  return new Ye(__spreadProps(__spreadValues({ fields: n10, objectIdField: s7, geometryType: o3, spatialReference: i6, displayField: c14, interceptor: a5 }, "feature" === e11.type ? { templates: e11.templates, typeIdField: e11.typeIdField, types: e11.types } : null), { source: r3 }));
}
function g6(e11) {
  const r3 = "esri.views.3d.layers.VoxelGraphic" === e11.declaredClass;
  return e11.isAggregate ? "popup-feature-reduction" : r3 ? "popup-voxel" : "popup";
}
function w6(e11) {
  return { scale: e11?.scale, timeProperties: { currentStart: e11?.timeExtent?.start, currentEnd: e11?.timeExtent?.end, startIncluded: true, endIncluded: true } };
}
function m5(e11) {
  return { $voxel: e11 };
}
function x5(e11, r3, t3, a5, n10) {
  return __async(this, null, function* () {
    let s7 = null;
    if (n10.has("$aggregatedfeatures")) {
      const n11 = yield y6({ graphic: e11, view: r3, options: t3 }), o3 = e11.sourceLayer || e11.layer;
      s7 = f2({ layer: o3, aggregatedFeatures: n11, interceptor: a5 });
    }
    return { vars: { $feature: e11, $aggregatedFeatures: s7, $view: w6(r3) }, [Symbol.dispose]: () => s7?.[Symbol.dispose]() };
  });
}
function v5(r3, t3, a5, n10) {
  const s7 = (r3.sourceLayer || r3.layer) ?? void 0;
  return { $feature: r3, $layer: null != s7 && x(s7) ? s7 : "scene" === s7?.type && null != s7.associatedLayer ? s7.associatedLayer : void 0, $map: t3, $datastore: s7?.url, $userInput: a5, $graph: "knowledge-graph-sublayer" === s7?.type ? s7?.parentCompositeLayer?.knowledgeGraph : void 0, $view: w6(n10) };
}
function h5(_0, _1) {
  return __async(this, arguments, function* (e11, { graphic: r3, map: t3, location: a5, view: n10, options: s7, interceptor: o3, arcadeExecutor: i6 }) {
    switch (e11) {
      case "popup":
        return { vars: v5(r3, t3, a5, n10), [Symbol.dispose]() {
        } };
      case "popup-feature-reduction": {
        const e12 = new Set(i6.variablesUsed);
        return yield x5(r3, n10, s7, o3, e12);
      }
      case "popup-voxel":
        return { vars: m5(r3), [Symbol.dispose]() {
        } };
      default:
        throw new Error(`Unexpected profile name ${e11}`);
    }
  });
}
function $2(_0) {
  return __async(this, arguments, function* ({ expressionInfo: e11, arcade: { executor: r3, syntaxUtils: t3 }, graphic: a5 }) {
    const n10 = e11?.expression;
    if (!n10) return null;
    const s7 = g6(a5), o3 = r3.createArcadeProfile(s7);
    let c14;
    try {
      c14 = yield r3.createArcadeExecutor(n10, o3);
    } catch (u6) {
      return i5().error("arcade-executor-error", { error: u6, expressionInfo: e11 }), null;
    }
    const p9 = /* @__PURE__ */ new Set();
    return c14.variablesUsed.includes("$view") && (t3.scriptUsesViewProperties(c14.syntaxTree, ["scale"]) && p9.add("view-scale"), t3.scriptUsesViewProperties(c14.syntaxTree, ["timeProperties"]) && p9.add("view-time-extent")), { dependencies: p9, evaluate(_02) {
      return __async(this, arguments, function* ({ graphic: r4, interceptor: t4, location: a6, map: n11, options: o4, spatialReference: p10, view: l6 }) {
        const d9 = yield h5(s7, { graphic: r4, map: n11, location: a6, view: l6, options: o4, interceptor: t4, arcadeExecutor: c14 }), y9 = { abortSignal: o4?.signal ?? void 0, interceptor: t4 ?? void 0, rawOutput: true, spatialReference: p10 ?? void 0, timeZone: l6?.timeZone, console(...e12) {
          i5().info(...e12);
        } };
        try {
          return yield c14.executeAsync(d9.vars, y9);
        } catch (u6) {
          return void i5().error("arcade-execution-error", { error: u6, graphic: r4, expressionInfo: e11 });
        } finally {
          d9[Symbol.dispose]();
        }
      });
    } };
  });
}
function b6(e11, r3) {
  return __async(this, null, function* () {
    if (!e11?.length) return { dependencies: /* @__PURE__ */ new Set(), expressions: /* @__PURE__ */ new Map() };
    const t3 = yield l5(), a5 = /* @__PURE__ */ new Set(), n10 = /* @__PURE__ */ new Map();
    for (const s7 of e11) {
      const e12 = yield $2({ expressionInfo: s7, arcade: t3, graphic: r3 });
      n10.set(`expression/${s7.name}`, e12), e12?.dependencies.forEach((e13) => a5.add(e13));
    }
    return { dependencies: a5, expressions: n10 };
  });
}

// node_modules/@arcgis/core/widgets/Feature/FeatureExpression/FeatureExpressionViewModel.js
var k3 = 1;
var g7 = class extends g {
  constructor(t3) {
    super(t3), this._compileTask = null, this._evaluateTask = null, this.expressionInfo = null, this.graphic = null, this.contentElementViewModel = null, this.interceptor = null, this.location = null, this.view = null, this._createVM = () => {
      const t4 = this.contentElement?.type;
      this.contentElementViewModel?.destroy();
      const e11 = "fields" === t4 ? new n8() : "media" === t4 ? new M3() : "text" === t4 ? new p5() : null;
      this._set("contentElementViewModel", e11);
    }, this._compileThrottled = e8(this._startCompile, () => this.notifyChange("state"), k3, this), this._evaluateThrottled = e8(this._startEvaluate, () => this.notifyChange("state"), k3, this), this.addHandles([d3(() => [this.expressionInfo, this.graphic], () => this._compileThrottled(), P), d3(() => [this.contentElement], () => this._createVM(), P), p(() => {
      if (!this._compileTask?.finished) return null;
      const t4 = this._compileTask.value, e11 = t4?.dependencies;
      return [t4, this.spatialReference, this.map, this.view, e11?.has("view-scale") ? this.view?.scale : null, e11?.has("view-time-extent") ? this.view?.timeExtent?.start : null, e11?.has("view-time-extent") ? this.view?.timeExtent?.end : null];
    }, ([t4]) => this._evaluateThrottled(t4))]);
  }
  initialize() {
    this.addHandles([this._compileThrottled, this._evaluateThrottled]);
  }
  destroy() {
    this._compileTask = e(this._compileTask), this._evaluateTask = e(this._evaluateTask), this.contentElementViewModel?.destroy(), this._set("contentElementViewModel", null);
  }
  get contentElement() {
    return this._evaluateTask?.value;
  }
  get spatialReference() {
    return this.view?.spatialReference ?? null;
  }
  set spatialReference(t3) {
    this._override("spatialReference", t3);
  }
  get state() {
    const { contentElement: t3, contentElementViewModel: e11 } = this;
    return this._compileThrottled.hasPendingUpdates() || this._evaluateThrottled.hasPendingUpdates() || !this._compileTask?.finished || !this._evaluateTask?.finished ? "loading" : t3 || e11 ? "ready" : "disabled";
  }
  get map() {
    return this.view?.map ?? null;
  }
  set map(t3) {
    this._override("map", t3);
  }
  _startCompile() {
    this._evaluateTask = e(this._evaluateTask), this._compileTask = e(this._compileTask), this._compileTask = d2((t3) => __async(this, null, function* () {
      const { expressionInfo: e11, graphic: o3 } = this;
      if (!e11 || !o3) return null;
      const s7 = yield l5();
      s2(t3);
      const i6 = yield $2({ expressionInfo: e11, arcade: s7, graphic: o3 });
      return s2(t3), i6;
    }));
  }
  _startEvaluate(t3) {
    this._evaluateTask = e(this._evaluateTask), this._evaluateTask = d2((e11) => __async(this, null, function* () {
      const { graphic: o3 } = this;
      if (!t3 || !o3) return null;
      const { interceptor: s7, spatialReference: i6, map: r3, location: a5, view: l6 } = this, p9 = yield t3.evaluate({ graphic: o3, interceptor: s7, location: a5, map: r3, options: { signal: e11 }, spatialReference: i6, view: l6 });
      s2(e11);
      const c14 = p9;
      if (!c14 || "esri.arcade.Dictionary" !== c14.declaredClass) return null;
      const m8 = yield c14.castAsJsonAsync(e11);
      s2(e11);
      const h7 = m8?.type, v7 = "media" === h7 ? I.fromJSON(m8) : "text" === h7 ? c4.fromJSON(m8) : "fields" === h7 ? d4.fromJSON(m8) : null;
      return "media" === v7.type && !v7.mediaInfos || "fields" === v7.type && !v7.fieldInfos || "text" === v7.type && !v7.text ? null : v7;
    }));
  }
};
r([m()], g7.prototype, "_compileTask", void 0), r([m()], g7.prototype, "_evaluateTask", void 0), r([m({ type: i })], g7.prototype, "expressionInfo", void 0), r([m({ type: b2 })], g7.prototype, "graphic", void 0), r([m({ readOnly: true })], g7.prototype, "contentElement", null), r([m({ readOnly: true })], g7.prototype, "contentElementViewModel", void 0), r([m()], g7.prototype, "interceptor", void 0), r([m({ type: j })], g7.prototype, "location", void 0), r([m()], g7.prototype, "spatialReference", null), r([m({ readOnly: true })], g7.prototype, "state", null), r([m()], g7.prototype, "map", null), r([m()], g7.prototype, "view", void 0), g7 = r([a("esri.widgets.Feature.FeatureExpression.FeatureExpressionViewModel")], g7);
var E2 = g7;

// node_modules/@arcgis/core/widgets/Feature/FeatureExpression.js
var m6 = "esri-feature";
var u5 = { base: `${m6}-expression`, loadingSpinnerContainer: `${m6}__loading-container` };
var g8 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this._contentWidget = null, this.viewModel = new E2();
  }
  initialize() {
    this.addHandles(d3(() => this.viewModel?.contentElementViewModel, () => this._setupExpressionWidget(), P));
  }
  loadDependencies() {
    return c3({ loader: () => import("./calcite-loader-Z6UVHYMG.js") });
  }
  destroy() {
    this._destroyContentWidget();
  }
  render() {
    const { state: e11 } = this.viewModel;
    return n2("div", { class: u5.base }, "loading" === e11 ? this._renderLoading() : "disabled" === e11 ? null : this._contentWidget?.render());
  }
  _renderLoading() {
    return n2("div", { class: u5.loadingSpinnerContainer, key: "loading-container" }, n2("calcite-loader", { inline: true, label: "" }));
  }
  _destroyContentWidget() {
    const { _contentWidget: e11 } = this;
    e11 && (e11.viewModel = null, e11.destroy()), this._contentWidget = null;
  }
  _setupExpressionWidget() {
    const { contentElementViewModel: e11, contentElement: t3 } = this.viewModel, o3 = t3?.type;
    this._destroyContentWidget();
    const s7 = e11 ? "fields" === o3 ? new h3({ viewModel: e11 }) : "media" === o3 ? new b5({ viewModel: e11 }) : "text" === o3 ? new p6({ viewModel: e11 }) : null : null;
    this._contentWidget = s7, this.scheduleRender();
  }
};
r([m({ type: E2 })], g8.prototype, "viewModel", void 0), g8 = r([a("esri.widgets.Feature.FeatureExpression")], g8);
var h6 = g8;

// node_modules/@arcgis/core/widgets/Feature/FeatureRelationship/FeatureRelationshipViewModel.js
var F3 = 100;
var _2 = class extends a2.ClonableMixin(n3.IdentifiableMixin(g)) {
  constructor(e11) {
    super(e11), this._loaded = false, this._queryAbortController = null, this._queryPageAbortController = null, this._queryFeatureCountAbortController = null, this.featuresPerPage = 10, this.activeCategory = null, this.allCategories = null, this.description = null, this.graphic = null, this.layer = null, this.map = null, this.orderByFields = null, this.featureCount = 0, this.relationshipId = null, this.showAllEnabled = false, this.title = null, this._cancelQuery = () => {
      const { _queryAbortController: e12 } = this;
      e12 && e12.abort(), this._queryAbortController = null;
    }, this._cancelQueryFeatureCount = () => {
      const { _queryFeatureCountAbortController: e12 } = this;
      e12 && e12.abort(), this._queryFeatureCountAbortController = null;
    }, this._cancelQueryPage = () => {
      const { _queryPageAbortController: e12 } = this;
      e12 && e12.abort(), this._queryPageAbortController = null;
    }, this._queryController = () => __async(this, null, function* () {
      this._cancelQuery();
      const e12 = new AbortController();
      this._queryAbortController = e12, yield d(this._query()), this._queryAbortController === e12 && (this._queryAbortController = null);
    }), this._queryFeatureCountController = () => __async(this, null, function* () {
      this._loaded = false, this._cancelQueryFeatureCount();
      const e12 = new AbortController();
      this._queryFeatureCountAbortController = e12, yield d(this._queryFeatureCount()), this._queryFeatureCountAbortController === e12 && (this._queryFeatureCountAbortController = null), this._loaded = true;
    }), this._queryPageController = () => __async(this, null, function* () {
      const e12 = new AbortController();
      this._queryPageAbortController = e12, yield d(this._queryPage()), this._queryPageAbortController === e12 && (this._queryPageAbortController = null);
    }), this._queryDebounced = k(this._queryController, F3), this._queryFeatureCountDebounced = k(this._queryFeatureCountController, F3), this._queryPageDebounced = k(this._queryPageController, F3), this._query = () => __async(this, null, function* () {
      const { _queryAbortController: e12, relatedFeatures: t3 } = this;
      this.featureCount && ("subtype-group" !== this.relatedLayer?.type || this.activeCategory) && (this._destroyRelatedFeatureViewModels(), this.featurePage = 1, t3.destroyAll(), this.destroyed || t3.addMany(this._sliceFeatures(yield this._queryRelatedFeatures({ signal: e12?.signal }))));
    }), this.addHandles([d3(() => [this.displayCount, this.graphic, this.layer, this.layer?.loaded, this.map, this.orderByFields, this.relationshipId, this.featuresPerPage, this.showAllEnabled, this.canQuery, this.featureCount, this.activeCategory], () => this._queryDebounced(), P), d3(() => [this.featurePage, this.showAllEnabled], () => this._queryPageDebounced()), d3(() => [this.layer, this.relationshipId, this.objectId, this.canQuery, this.activeCategory], () => this._queryFeatureCountDebounced())]);
  }
  destroy() {
    this._destroyRelatedFeatureViewModels(), this.relatedFeatures.destroyAll(), this._cancelQuery(), this._cancelQueryFeatureCount(), this._cancelQueryPage();
  }
  set featurePage(e11) {
    const { featuresPerPage: t3, featureCount: r3 } = this, o3 = 1, l6 = Math.ceil(r3 / t3) || 1;
    this._set("featurePage", Math.min(Math.max(e11, o3), l6));
  }
  get featurePage() {
    return this._get("featurePage");
  }
  get orderByFieldsFixedCasing() {
    const { orderByFields: e11, relatedLayer: t3 } = this;
    return e11 && t3?.loaded ? e11.map((e12) => {
      const r3 = e12.clone();
      return r3.field = M(e12.field, t3), r3;
    }) : e11 ?? [];
  }
  get supportsCacheHint() {
    return !!this.layer?.capabilities?.queryRelated?.supportsCacheHint;
  }
  get canLoad() {
    return !!this.map && null != this.relationshipId && "number" == typeof this.objectId;
  }
  get canQuery() {
    const e11 = this.layer?.capabilities?.queryRelated;
    return !!(this.relatedLayer && this.relationship && null != this.relationshipId && null != this.objectId && e11?.supportsCount && e11?.supportsPagination);
  }
  get allCategoriesCount() {
    return this.allCategories?.length ?? 0;
  }
  get categories() {
    const { allCategories: e11 } = this;
    return this.showAllEnabled ? e11 : e11?.slice(0, this.displayCount) ?? null;
  }
  set displayCount(e11) {
    const t3 = 0, r3 = 10, o3 = 3;
    this._set("displayCount", Math.min(Math.max(e11 ?? o3, t3), r3));
  }
  get displayCount() {
    return this._get("displayCount");
  }
  get itemDescriptionFieldName() {
    return this.orderByFieldsFixedCasing[0]?.field || null;
  }
  get objectId() {
    return (this.objectIdField && this.graphic?.attributes?.[this.objectIdField]) ?? null;
  }
  get objectIdField() {
    return this.layer?.objectIdField || null;
  }
  get relatedFeatures() {
    return this._get("relatedFeatures") || new V();
  }
  get relatedLayer() {
    const { layer: e11, map: t3, relationship: r3 } = this;
    if (!e11?.loaded || !t3 || !r3) return null;
    const o3 = "subtype-sublayer" === e11.type && e11.parent && J(e11.parent) ? e11.parent : e11;
    return Te(t3, o3, r3) ?? null;
  }
  get relatedLayerKeyField() {
    const { relatedLayer: e11, relationshipId: t3 } = this;
    return e11?.loaded && null != t3 ? e11.relationships?.find((e12) => e12.id === t3)?.keyField : null;
  }
  get relatedLayerKeyFields() {
    const { relatedLayer: e11 } = this;
    return e11?.loaded ? e11.relationships?.map((e12) => e12.keyField).filter(G) ?? [] : [];
  }
  get relationship() {
    const { relationshipId: e11, layer: t3 } = this;
    return null != e11 && t3?.loaded ? t3.relationships?.find(({ id: t4 }) => t4 === e11) ?? null : null;
  }
  get relationshipKey() {
    const { relationshipKeyField: e11 } = this;
    return (e11 && this.graphic?.attributes?.[e11]) ?? null;
  }
  get relationshipKeyField() {
    return this.relationship?.keyField || null;
  }
  get relatedFeatureViewModels() {
    return this._get("relatedFeatureViewModels") || new V();
  }
  get state() {
    const { _queryAbortController: e11, _queryFeatureCountAbortController: t3, _queryPageAbortController: r3, canQuery: o3, _loaded: l6, canLoad: a5 } = this;
    return t3 || a5 && !l6 ? "loading" : e11 || r3 ? "querying" : o3 ? "ready" : "disabled";
  }
  getRelatedFeatureByObjectId(e11) {
    return this.relatedFeatures.find((t3) => t3.getObjectId() === e11);
  }
  refresh() {
    this._queryFeatureCountDebounced();
  }
  _destroyRelatedFeatureViewModels() {
    this.relatedFeatureViewModels?.destroyAll();
  }
  _queryFeatureCount() {
    return __async(this, null, function* () {
      const { layer: e11, relatedLayer: t3 } = this;
      yield e11?.load(), yield t3?.load();
      const { _queryFeatureCountAbortController: r3, activeCategory: l6, canQuery: a5, objectId: i6, relatedLayerKeyField: s7, relationshipId: n10, relationshipKey: u6, supportsCacheHint: d9 } = this;
      if (!a5 || !e11 || !t3 || null == i6) return this._set("featureCount", 0), void this._set("allCategories", null);
      if ("subtype-group" === t3?.type && !l6) {
        if (this._set("featureCount", 0), this._destroyRelatedFeatureViewModels(), this.featurePage = 1, this.relatedFeatures.destroyAll(), s7 && null != u6) {
          const { default: e12 } = yield import("./uniqueValues-KZESDK7Z.js"), { uniqueValueInfos: l7 } = yield e12({ layer: t3, sqlWhere: `${s7} = '${u6}'`, field: t3.subtypeField, signal: r3?.signal }), a6 = l7.map(({ count: e13, value: r4 }) => {
            const o3 = t3.subtypes?.find((e14) => e14.code === r4)?.name;
            return null != r4 && o3 ? { count: e13, value: r4, name: o3 } : void 0;
          }).filter(G);
          this._set("allCategories", a6);
        }
        return;
      }
      const { historicMoment: y9, gdbVersion: h7 } = e11, c14 = new d5({ cacheHint: d9, gdbVersion: h7, historicMoment: y9, relationshipId: n10, returnGeometry: false, objectIds: [i6], where: this._getRelationshipWhereClause(t3) }), g10 = yield e11.queryRelatedFeaturesCount(c14, { signal: r3?.signal });
      this._set("allCategories", null), this._set("featureCount", g10[i6] || 0);
    });
  }
  _getRelationshipWhereClause(e11) {
    const { activeCategory: t3 } = this, r3 = e11.createQuery(), o3 = "subtypeField" in e11 ? e11.subtypeField : void 0, l6 = t3 && o3 ? `${o3} = ${t3.value}` : void 0, a5 = r3.where;
    return a5 && l6 ? `(${a5}) AND (${l6})` : a5 ?? l6;
  }
  _sliceFeatures(e11) {
    const { showAllEnabled: t3, displayCount: r3 } = this;
    return t3 ? e11 : r3 ? e11.slice(0, r3) : [];
  }
  _queryPage() {
    return __async(this, null, function* () {
      const { relatedFeatures: e11, featurePage: t3, showAllEnabled: r3, _queryPageAbortController: o3, featureCount: l6 } = this;
      !r3 || t3 < 2 || !l6 || "subtype-group" === this.relatedLayer?.type && !this.activeCategory || e11.addMany(yield this._queryRelatedFeatures({ signal: o3?.signal }));
    });
  }
  _queryRelatedFeatures(e11) {
    return __async(this, null, function* () {
      const { displayCount: t3, featureCount: r3, featurePage: o3, featuresPerPage: l6, layer: a5, orderByFieldsFixedCasing: i6, relatedLayer: s7, relatedLayerKeyFields: n10, relationshipId: u6, showAllEnabled: d9, supportsCacheHint: y9 } = this, { canQuery: h7, objectId: c14 } = this;
      if (!h7 || !a5 || !s7 || null == c14) return [];
      const g10 = d9 ? ((o3 - 1) * l6 + r3) % r3 : 0, C4 = d9 ? l6 : t3, F6 = s7.objectIdField, _3 = "subtypeField" in s7 ? s7.subtypeField : void 0, m8 = [...i6.map((e12) => e12.field), ...K2(s7), ...n10, F6, _3].filter(f3), q3 = i6.map((e12) => `${e12.field} ${e12.order}`), { historicMoment: A5, gdbVersion: w8 } = a5, P3 = new d5({ orderByFields: q3, start: g10, num: C4, outFields: m8, cacheHint: y9, historicMoment: A5, gdbVersion: w8, relationshipId: u6, returnGeometry: false, objectIds: [c14], where: this._getRelationshipWhereClause(s7) }), v7 = yield a5.queryRelatedFeatures(P3, { signal: e11?.signal }), j4 = v7[c14]?.features || [];
      return "subtype-group" === s7.type && _3 ? j4.forEach((e12) => {
        const t4 = e12.attributes[_3], r4 = s7.findSublayerForSubtypeCode?.(t4);
        e12.sourceLayer = r4, e12.layer = r4;
      }) : j4.forEach((e12) => {
        e12.sourceLayer = s7, e12.layer = s7;
      }), j4;
    });
  }
};
function f3(e11) {
  return null != e11 && "" !== e11;
}
r([m()], _2.prototype, "_loaded", void 0), r([m()], _2.prototype, "_queryAbortController", void 0), r([m()], _2.prototype, "_queryPageAbortController", void 0), r([m()], _2.prototype, "_queryFeatureCountAbortController", void 0), r([m({ value: 1 })], _2.prototype, "featurePage", null), r([m()], _2.prototype, "featuresPerPage", void 0), r([m({ readOnly: true })], _2.prototype, "orderByFieldsFixedCasing", null), r([m({ readOnly: true })], _2.prototype, "supportsCacheHint", null), r([m({ readOnly: true })], _2.prototype, "canLoad", null), r([m({ readOnly: true })], _2.prototype, "canQuery", null), r([m()], _2.prototype, "activeCategory", void 0), r([m({ readOnly: true })], _2.prototype, "allCategories", void 0), r([m({ readOnly: true })], _2.prototype, "allCategoriesCount", null), r([m({ readOnly: true })], _2.prototype, "categories", null), r([m()], _2.prototype, "description", void 0), r([m({ value: 3 })], _2.prototype, "displayCount", null), r([m({ type: b2 })], _2.prototype, "graphic", void 0), r([m({ readOnly: true })], _2.prototype, "itemDescriptionFieldName", null), r([m()], _2.prototype, "layer", void 0), r([m()], _2.prototype, "map", void 0), r([m({ readOnly: true })], _2.prototype, "objectId", null), r([m({ readOnly: true })], _2.prototype, "objectIdField", null), r([m()], _2.prototype, "orderByFields", void 0), r([m({ readOnly: true })], _2.prototype, "relatedFeatures", null), r([m({ readOnly: true })], _2.prototype, "relatedLayer", null), r([m({ readOnly: true })], _2.prototype, "relatedLayerKeyField", null), r([m({ readOnly: true })], _2.prototype, "relatedLayerKeyFields", null), r([m({ readOnly: true })], _2.prototype, "relationship", null), r([m({ readOnly: true })], _2.prototype, "relationshipKey", null), r([m({ readOnly: true })], _2.prototype, "relationshipKeyField", null), r([m({ readOnly: true })], _2.prototype, "featureCount", void 0), r([m({ readOnly: true })], _2.prototype, "relatedFeatureViewModels", null), r([m()], _2.prototype, "relationshipId", void 0), r([m()], _2.prototype, "showAllEnabled", void 0), r([m()], _2.prototype, "state", null), r([m()], _2.prototype, "title", void 0), _2 = r([a("esri.widgets.Feature.FeatureRelationship.FeatureRelationshipViewModel")], _2);
var m7 = _2;

// node_modules/@arcgis/core/widgets/Feature/FeatureRelationship.js
var b7;
var y7 = "esri-feature";
var I6 = `${y7}-relationship`;
var F4 = { base: I6, listContainer: `${I6}__list`, listItem: `${I6}__list-item`, listItemHidden: `${I6}__list-item--hidden`, listContainerQuerying: `${I6}__list--querying`, featureObserver: `${y7}__feature-observer`, stickySpinnerContainer: `${y7}__sticky-loading-container`, loadingSpinnerContainer: `${y7}__loading-container` };
var C3 = { title: true, description: true };
var M5 = b7 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this._featureElementInfo = null, this._relatedFeatureIntersectionObserverNode = null, this._relatedFeatureIntersectionObserver = new IntersectionObserver(([e12]) => {
      e12?.isIntersecting && this._increaseFeaturePage();
    }, { root: window.document }), this.flowItems = null, this.flowType = "feature-relationship", this.headingLevel = 2, this.viewModel = new m7(), this.messages = null, this.messagesCommon = null, this.visibleElements = __spreadValues({}, C3), this._increaseFeaturePage = () => {
      const { state: e12, showAllEnabled: t4, relatedFeatures: s7, featuresPerPage: i6, featurePage: r3 } = this.viewModel;
      "ready" === e12 && t4 && s7.length >= i6 * r3 && this.viewModel.featurePage++;
    };
  }
  initialize() {
    this._featureElementInfo = new l2(), this.addHandles([d3(() => [this.viewModel.description, this.viewModel.title, this.headingLevel], () => this._setupFeatureElementInfo(), P), d3(() => [this.viewModel.state, this.viewModel.showAllEnabled, this._relatedFeatureIntersectionObserverNode], () => this._handleRelatedFeatureObserverChange()), v(() => this.viewModel.relatedFeatureViewModels, "change", () => this._setupRelatedFeatureViewModels())]);
  }
  loadDependencies() {
    return c3({ chip: () => import("./calcite-chip-ECXAKG34.js"), icon: () => import("./calcite-icon-TH7JL242.js"), list: () => import("./calcite-list-W42EHRHD.js"), "list-item": () => import("./calcite-list-item-6HCBKBPX.js"), loader: () => import("./calcite-loader-Z6UVHYMG.js"), notice: () => import("./calcite-notice-X7K5RWS6.js") });
  }
  destroy() {
    this._unobserveRelatedFeatureObserver(), this._featureElementInfo = u(this._featureElementInfo);
  }
  get displayShowAllButton() {
    const { showAllEnabled: e11, featureCount: t3, displayCount: s7, state: i6, allCategoriesCount: r3 } = this.viewModel;
    return !e11 && "ready" === i6 && (!!r3 && (r3 > s7 || 0 === s7) || !!t3 && (t3 > s7 || 0 === s7));
  }
  get displayListItems() {
    const { relatedFeatureViewModels: e11, allCategoriesCount: t3 } = this.viewModel;
    return this.displayShowAllButton || !!e11.length || !!t3;
  }
  get allItemsDescription() {
    const { messages: e11 } = this, { featureCount: t3, allCategories: s7, allCategoriesCount: i6 } = this.viewModel;
    return s3(e11?.numberRecords, { number: l(s7 ? i6 : t3) });
  }
  get description() {
    return this.viewModel.description;
  }
  set description(e11) {
    this.viewModel.description = e11;
  }
  get title() {
    const { activeCategory: e11, title: t3 } = this.viewModel;
    return e11?.name ?? t3;
  }
  set title(e11) {
    this.viewModel.title = e11;
  }
  castVisibleElements(e11) {
    return __spreadValues(__spreadValues({}, C3), e11);
  }
  render() {
    const { state: e11 } = this.viewModel;
    return n2("div", { class: this.classes(F4.base, e5.widget) }, this._featureElementInfo?.render(), "loading" === e11 ? this._renderLoading() : "disabled" === e11 ? this._renderRelationshipNotFound() : this._renderRelatedFeatures());
  }
  _selectCategory(e11) {
    return __async(this, null, function* () {
      const { flowItems: t3, featureVisibleElements: s7, viewModel: i6 } = this;
      t3 && (i6.activeCategory = e11, i6.showAllEnabled = true, t3.push(new b7({ flowItems: t3, featureVisibleElements: s7, visibleElements: { title: false, description: false }, viewModel: i6 })));
    });
  }
  _selectRecord(e11) {
    return __async(this, null, function* () {
      const { flowItems: t3, featureVisibleElements: s7 } = this;
      if (!t3) return;
      e11.abilities = { relationshipContent: true };
      const { default: i6 } = yield import("./Feature-XD5V3J4E.js");
      t3.push(new i6({ flowItems: t3, flowType: this.flowType, viewModel: e11, visibleElements: s7 }));
    });
  }
  _showAllRecords() {
    const { flowItems: e11 } = this;
    if (!e11) return;
    const { viewModel: t3, featureVisibleElements: s7 } = this;
    t3.showAllEnabled = true;
    const i6 = new b7({ flowItems: e11, featureVisibleElements: s7, visibleElements: { title: false, description: false }, viewModel: t3 });
    e11.push(i6);
  }
  _renderStickyLoading() {
    return "querying" === this.viewModel.state ? n2("div", { class: F4.stickySpinnerContainer, key: "sticky-loader" }, this._renderLoadingIcon()) : null;
  }
  _renderLoadingIcon() {
    return n2("calcite-loader", { inline: true, label: "" });
  }
  _renderLoading() {
    return n2("div", { class: F4.loadingSpinnerContainer, key: "loading-container" }, this._renderLoadingIcon());
  }
  _renderShowAllIconNode() {
    return n2("calcite-icon", { icon: "list", scale: "s", slot: "content-end" });
  }
  _renderChevronIconNode() {
    const e11 = g2(this.container) ? "chevron-left" : "chevron-right";
    return n2("calcite-icon", { icon: e11, scale: "s", slot: "content-end" });
  }
  _renderCategory(e11) {
    const { count: t3, name: s7, value: i6 } = e11, r3 = l(t3);
    return n2("calcite-list-item", { class: F4.listItem, disabled: !t3, key: i6, label: s7, onCalciteListItemSelect: () => this._selectCategory(e11) }, n2("calcite-chip", { label: r3, scale: "s", slot: "content-end" }, r3), this._renderChevronIconNode());
  }
  _renderRelatedFeature(e11) {
    const { itemDescriptionFieldName: t3 } = this.viewModel, s7 = e11.title;
    e11.description = t3 && e11.formattedAttributes?.global[t3];
    const i6 = "loading" === e11.state;
    return n2("calcite-list-item", { class: this.classes(F4.listItem, { [F4.listItemHidden]: i6 }), description: c2(e11.description ?? ""), key: e11.uid, label: c2(s7), onCalciteListItemSelect: () => this._selectRecord(e11) }, this._renderChevronIconNode());
  }
  _renderShowAllListItem() {
    return this.displayShowAllButton ? n2("calcite-list-item", { description: this.allItemsDescription, key: "show-all-item", label: this.messages?.showAll, onCalciteListItemSelect: () => this._showAllRecords() }, this._renderShowAllIconNode()) : null;
  }
  _renderNoRelatedFeaturesMessage() {
    return n2("calcite-notice", { icon: "information", key: "no-related-features-message", kind: "brand", open: true, scale: "s", width: "full" }, n2("div", { slot: "message" }, this.messages?.noRelatedFeatures));
  }
  _renderFeatureObserver() {
    return n2("div", { afterCreate: this._relatedFeatureIntersectionObserverCreated, bind: this, class: F4.featureObserver, key: "feature-observer" });
  }
  _renderList() {
    const { relatedFeatureViewModels: e11, categories: t3 } = this.viewModel;
    return n2("calcite-list", { displayMode: "flat", label: this.messages?.relatedFeaturesList }, t3?.map((e12) => this._renderCategory(e12)) ?? e11.toArray().map((e12) => this._renderRelatedFeature(e12)), this._renderShowAllListItem());
  }
  _renderRelatedFeatures() {
    const { displayListItems: e11 } = this, { state: t3 } = this.viewModel;
    return n2("div", { class: this.classes(F4.listContainer, { [F4.listContainerQuerying]: "querying" === t3 }), key: "list-container" }, e11 ? this._renderList() : "ready" === t3 ? this._renderNoRelatedFeaturesMessage() : null, this._renderStickyLoading(), this._renderFeatureObserver());
  }
  _renderRelationshipNotFound() {
    return n2("calcite-notice", { icon: "exclamation-mark-triangle", key: "relationship-not-found", kind: "danger", open: true, scale: "s", width: "full" }, n2("div", { slot: "message" }, this.messages?.relationshipNotFound));
  }
  _setupRelatedFeatureViewModels() {
    const { relatedFeatureViewModels: e11 } = this.viewModel, t3 = "related-feature-viewmodels";
    this.removeHandles(t3), e11?.forEach((e12) => {
      this.addHandles(d3(() => [e12.title, e12.state], () => this.scheduleRender(), P), t3);
    }), this.scheduleRender();
  }
  _setupFeatureElementInfo() {
    const { headingLevel: e11, visibleElements: t3 } = this, s7 = t3.description && this.description, i6 = t3.title && this.title;
    this._featureElementInfo?.set({ description: s7, title: i6, headingLevel: e11 });
  }
  _handleRelatedFeatureObserverChange() {
    return __async(this, null, function* () {
      this._unobserveRelatedFeatureObserver();
      const { state: e11, showAllEnabled: t3 } = this.viewModel;
      yield A(0), this._relatedFeatureIntersectionObserverNode && "ready" === e11 && t3 && this._relatedFeatureIntersectionObserver.observe(this._relatedFeatureIntersectionObserverNode);
    });
  }
  _relatedFeatureIntersectionObserverCreated(e11) {
    this._relatedFeatureIntersectionObserverNode = e11;
  }
  _unobserveRelatedFeatureObserver() {
    this._relatedFeatureIntersectionObserverNode && this._relatedFeatureIntersectionObserver.unobserve(this._relatedFeatureIntersectionObserverNode);
  }
};
r([m()], M5.prototype, "_relatedFeatureIntersectionObserverNode", void 0), r([m({ readOnly: true })], M5.prototype, "displayShowAllButton", null), r([m({ readOnly: true })], M5.prototype, "displayListItems", null), r([m({ readOnly: true })], M5.prototype, "allItemsDescription", null), r([m()], M5.prototype, "description", null), r([m()], M5.prototype, "featureVisibleElements", void 0), r([m()], M5.prototype, "flowItems", void 0), r([m()], M5.prototype, "flowType", void 0), r([m()], M5.prototype, "headingLevel", void 0), r([m()], M5.prototype, "title", null), r([m({ type: m7 })], M5.prototype, "viewModel", void 0), r([m(), e3("esri/widgets/Feature/t9n/Feature")], M5.prototype, "messages", void 0), r([m(), e3("esri/t9n/common")], M5.prototype, "messagesCommon", void 0), r([m()], M5.prototype, "visibleElements", void 0), r([s4("visibleElements")], M5.prototype, "castVisibleElements", null), M5 = b7 = r([a("esri.widgets.Feature.FeatureRelationship")], M5);
var E3 = M5;

// node_modules/@arcgis/core/widgets/Feature/FeatureUtilityNetworkAssociations.js
var y8 = "esri-feature-utility-network-associations";
var g9 = `${y8}__loading-container`;
var v6 = { base: y8, listContainer: `${y8}__list`, loadingContainer: g9, loadingContainerSticky: `${g9}--sticky` };
var f4 = class extends O {
  constructor(e11, t3) {
    super(e11, t3), this._featureElementInfo = null, this.onSelectAssociationType = () => {
    }, this.flowType = "feature-utility-network-associations", this.flowItems = null, this.parentFeatureViewModel = null, this.headingLevel = 5, this.viewModel = new _(), this.messages = null, this.messagesCommon = null, this.visibleElements = new i3();
  }
  initialize() {
    this._featureElementInfo = new l2(), this.addHandles([d3(() => [this.viewModel.description, this.viewModel.title, this.headingLevel], () => this._setupFeatureElementInfo(), P)]);
  }
  loadDependencies() {
    return c3({ icon: () => import("./calcite-icon-TH7JL242.js"), list: () => import("./calcite-list-W42EHRHD.js"), "list-item": () => import("./calcite-list-item-6HCBKBPX.js"), loader: () => import("./calcite-loader-Z6UVHYMG.js"), notice: () => import("./calcite-notice-X7K5RWS6.js") });
  }
  destroy() {
    this._featureElementInfo = u(this._featureElementInfo);
  }
  get description() {
    return this.viewModel.description;
  }
  set description(e11) {
    this.viewModel.description = e11;
  }
  get title() {
    return this.viewModel.title;
  }
  set title(e11) {
    this.viewModel.title = e11;
  }
  render() {
    const { state: e11 } = this.viewModel;
    return n2("div", { class: this.classes(v6.base, e5.widget) }, this._featureElementInfo?.render(), "loading" === e11 ? this._renderLoading() : "disabled" === e11 ? this._renderAssociationNotFound() : this._renderContent());
  }
  _renderStickyLoading() {
    return "querying" === this.viewModel.state ? n2("div", { class: v6.loadingContainerSticky, key: "sticky-loader" }, this._renderLoadingIcon()) : null;
  }
  _renderLoadingIcon() {
    return n2("calcite-loader", { inline: true, label: this.messagesCommon.loading });
  }
  _renderLoading() {
    return n2("div", { class: v6.loadingContainer, key: "loading-container" }, this._renderLoadingIcon());
  }
  _renderAssociationNotFound() {
    return n2("calcite-notice", { icon: "exclamation-mark-triangle", key: "association-not-found", kind: "danger", open: true, scale: "s", width: "full" }, n2("div", { slot: "message" }, this.messages?.noAssociations));
  }
  _renderAssociationType(e11) {
    const { viewModel: t3 } = this, i6 = this._getAssociationTypeTitle(e11);
    return n2("calcite-list-item", { description: c2(e11.description), key: `association-type-${e11.type}`, label: c2(i6), value: e11.type, onCalciteListItemSelect: () => this.onSelectAssociationType({ viewModel: t3, listType: e11, title: i6 }) }, n2("calcite-icon", { flipRtl: true, icon: "chevron-right", scale: "s", slot: "content-end" }));
  }
  _renderAssociations(e11) {
    const { viewModel: t3 } = this;
    return "featureForm" === t3.source || t3.getFeatureCountForAssociationType(e11.type) > 0 ? this._renderAssociationType(e11) : void 0;
  }
  _renderContent() {
    const { messages: e11, viewModel: t3 } = this, { state: i6, associationTypes: o3 } = t3;
    return n2("div", { class: v6.listContainer, key: "list-container" }, "ready" === i6 ? n2("div", null, n2("calcite-list", { displayMode: "flat", label: e11?.associationsList }, o3.map((e12) => this._renderAssociations(e12)))) : null, this._renderStickyLoading());
  }
  _getAssociationTypeTitle(e11) {
    const { messages: t3 } = this;
    if (e11.title) return e11.title;
    switch (e11.type) {
      case "attachment":
        return t3.associationsAttachments;
      case "connectivity":
        return t3.associationsConnectivity;
      case "structure":
        return t3.associationsStructure;
      case "content":
        return t3.associationsContents;
      case "container":
        return t3.associationsContainer;
    }
  }
  _setupFeatureElementInfo() {
    const { headingLevel: e11, visibleElements: t3 } = this, i6 = t3.description && this.description, o3 = t3.title && this.title;
    this._featureElementInfo?.set({ description: i6, title: o3, headingLevel: e11 });
  }
};
r([m({ constructOnly: true })], f4.prototype, "onSelectAssociationType", void 0), r([m()], f4.prototype, "flowType", void 0), r([m()], f4.prototype, "flowItems", void 0), r([m()], f4.prototype, "parentFeatureViewModel", void 0), r([m()], f4.prototype, "featureVisibleElements", void 0), r([m()], f4.prototype, "description", null), r([m()], f4.prototype, "headingLevel", void 0), r([m()], f4.prototype, "title", null), r([m({ type: _ })], f4.prototype, "viewModel", void 0), r([m(), e3("esri/widgets/Feature/t9n/Feature")], f4.prototype, "messages", void 0), r([m(), e3("esri/t9n/common")], f4.prototype, "messagesCommon", void 0), r([m({ type: i3, nonNullable: true })], f4.prototype, "visibleElements", void 0), f4 = r([a("esri.widgets.Feature.FeatureUtilityNetworkAssociations")], f4);
var w7 = f4;

// node_modules/@arcgis/core/arcade/featureset/support/FeatureSetQueryInterceptor.js
var e9 = class {
  constructor(e11, a5) {
    this.preLayerQueryCallback = e11, this.preRequestCallback = a5, this.preLayerQueryCallback || (this.preLayerQueryCallback = (e12) => {
    }), this.preRequestCallback || (this.preLayerQueryCallback = (e12) => {
    });
  }
};

// node_modules/@arcgis/core/widgets/Feature/FeatureViewModel.js
var se2;
var oe2 = 1;
var re2 = "content-view-models";
var ae2 = "relationship-view-models";
var ne = "association-view-models";
var le2 = { attachmentsContent: true, chartAnimation: true, customContent: true, expressionContent: true, fieldsContent: true, mediaContent: true, textContent: true, relationshipContent: true, utilityNetworkAssociationsContent: true };
var pe2 = se2 = class extends n3.IdentifiableMixin(g) {
  constructor(e11) {
    super(e11), this._error = null, this._graphicChangedTask = null, this._evaluateExpressionAttributesTask = null, this._associationVMAbortController = null, this._expressionAttributes = null, this._graphicExpressionAttributes = null, this.abilities = __spreadValues({}, le2), this.content = null, this.contentViewModels = [], this.description = null, this.defaultPopupTemplateEnabled = false, this.formattedAttributes = null, this.lastEditInfo = null, this.location = null, this.relatedInfos = /* @__PURE__ */ new Map(), this.title = "", this.view = null, this._graphicChangedThrottled = e8(this._graphicChanged, () => this.notifyChange("waitingForContent"), oe2, this), this._isAllowedContentType = (e12) => {
      const { abilities: t3 } = this;
      return "attachments" === e12.type && !!t3.attachmentsContent || "custom" === e12.type && !!t3.customContent || "fields" === e12.type && !!t3.fieldsContent || "media" === e12.type && !!t3.mediaContent || "text" === e12.type && !!t3.textContent || "expression" === e12.type && !!t3.expressionContent || "relationship" === e12.type && !!t3.relationshipContent || "utility-network-associations" === e12.type && !!t3.utilityNetworkAssociationsContent;
    }, this._evaluateExpressionAttributesThrottled = e8(this._evaluateExpressionAttributes, () => this.notifyChange("waitingForContent"), oe2, this), this.addHandles([d3(() => [this.graphic, this._effectivePopupTemplate, this.abilities, this.timeZone], () => this._graphicChangedThrottled(), P), p(() => {
      if (!this._graphicChangedTask?.finished || null == this._graphicChangedTask.value) return null;
      const e12 = this._graphicChangedTask.value, t3 = e12?.expressionInfos?.dependencies;
      return [e12, t3?.has("view-scale") ? this.view?.scale : null, t3?.has("view-time-extent") ? this.view?.timeExtent?.start : null, t3?.has("view-time-extent") ? this.view?.timeExtent?.end : null];
    }, ([e12]) => this._evaluateExpressionAttributesThrottled(e12))]);
  }
  initialize() {
    this.addHandles([this._graphicChangedThrottled, this._evaluateExpressionAttributesThrottled]);
  }
  destroy() {
    this._clear(), this._graphicChangedTask = e(this._graphicChangedTask), this._evaluateExpressionAttributesTask = e(this._evaluateExpressionAttributesTask), this._error = null, this.graphic = null, this._destroyContentViewModels(), this.relatedInfos.clear();
  }
  get _effectivePopupTemplate() {
    return null != this.graphic ? this.graphic.getEffectivePopupTemplate(this.defaultPopupTemplateEnabled) : null;
  }
  get _fieldInfoMap() {
    return ie(oe(this._effectivePopupTemplate), this._sourceLayer);
  }
  get _sourceLayer() {
    return L(this.graphic);
  }
  castAbilities(e11) {
    return __spreadValues(__spreadValues({}, le2), e11);
  }
  get isTable() {
    return this._sourceLayer?.isTable || false;
  }
  get state() {
    return this.graphic ? this._error ? "error" : this.waitingForContent ? "loading" : "ready" : "disabled";
  }
  set graphic(e11) {
    this._set("graphic", e11?.clone() ?? null);
  }
  get spatialReference() {
    return this.view?.spatialReference ?? null;
  }
  set spatialReference(e11) {
    this._override("spatialReference", e11);
  }
  get timeZone() {
    return this.view?.timeZone ?? e2;
  }
  set timeZone(e11) {
    this._overrideIfSome("timeZone", e11);
  }
  get map() {
    return this.view?.map || null;
  }
  set map(e11) {
    this._override("map", e11);
  }
  get waitingForContent() {
    const { _graphicChangedThrottled: e11, _evaluateExpressionAttributesThrottled: t3, _graphicChangedTask: i6, _evaluateExpressionAttributesTask: s7, _associationVMAbortController: o3 } = this;
    return e11.hasPendingUpdates() || t3.hasPendingUpdates() || null != i6 && !i6.finished || null != s7 && !s7.finished || !!o3;
  }
  setActiveMedia(e11, t3) {
    const i6 = this.contentViewModels[e11];
    i6 instanceof M3 && i6.setActiveMedia(t3);
  }
  nextMedia(e11) {
    const t3 = this.contentViewModels[e11];
    t3 instanceof M3 && t3.next();
  }
  previousMedia(e11) {
    const t3 = this.contentViewModels[e11];
    t3 instanceof M3 && t3.previous();
  }
  updateGeometry() {
    return __async(this, null, function* () {
      const { graphic: e11, spatialReference: t3, _sourceLayer: i6 } = this;
      yield i6?.load();
      const s7 = i6?.objectIdField;
      if (!s7 || !e11 || !i6) return;
      const o3 = e11?.attributes?.[s7];
      if (null == o3) return;
      const r3 = [o3];
      if (!e11.geometry) {
        const s8 = yield fe({ layer: i6, graphic: e11, outFields: [], objectIds: r3, returnGeometry: true, spatialReference: t3 }), o4 = s8?.geometry;
        o4 && (e11.geometry = o4);
      }
    });
  }
  _clear() {
    this._set("title", ""), this._set("content", null), this._set("formattedAttributes", null);
  }
  _graphicChanged() {
    this._evaluateExpressionAttributesTask = e(this._evaluateExpressionAttributesTask), this._graphicChangedTask = e(this._graphicChangedTask), this._graphicChangedTask = d2((e11) => __async(this, null, function* () {
      this._error = null, this._clear();
      const { graphic: t3 } = this;
      try {
        if (!t3) return null;
        const { _sourceLayer: i6, _effectivePopupTemplate: s7 } = this, o3 = this.spatialReference;
        yield de({ graphic: t3, popupTemplate: s7, layer: i6, spatialReference: o3 }, { signal: e11 });
        const [{ value: r3 }, { value: a5 }] = yield y([this._getContent(), this._getTitle()]), [, { value: n10 }] = yield y([this._checkForRelatedFeatures({ signal: e11 }), b6(s7?.expressionInfos, t3)]);
        return { expressionInfos: n10, content: r3, title: a5 };
      } catch (i6) {
        throw b(i6) || (this._error = i6, n.getLogger(this).error("error", "The popupTemplate could not be displayed for this feature.", { error: i6, graphic: t3, popupTemplate: this._effectivePopupTemplate })), i6;
      }
    }));
  }
  _compileContentElement(e11, t3) {
    return "attachments" === e11.type ? this._compileAttachments(e11, t3) : "custom" === e11.type ? this._compileCustom(e11, t3) : "fields" === e11.type ? this._compileFields(e11, t3) : "media" === e11.type ? this._compileMedia(e11, t3) : "text" === e11.type ? this._compileText(e11, t3) : "expression" === e11.type ? this._compileExpression(e11, t3) : "relationship" === e11.type ? this._compileRelationship(e11, t3) : "utility-network-associations" === e11.type ? this._compileUtilityNetworkAssociation(e11, t3) : void 0;
  }
  _compileContent(e11) {
    if (this._destroyContentViewModels(), this.graphic) return Array.isArray(e11) ? e11.filter(this._isAllowedContentType).map((e12, t3) => this._compileContentElement(e12, t3)).filter(G) : "string" == typeof e11 ? this._compileText(new c4({ text: e11 }), 0).text : e11;
  }
  _destroyContentViewModels() {
    this.removeHandles(ae2), this.removeHandles(re2), this.contentViewModels.forEach((e11) => e11 && !e11.destroyed && e11.destroy()), this._set("contentViewModels", []);
  }
  _matchesFeature(e11, t3) {
    const i6 = e11?.graphic?.getObjectId(), s7 = t3?.getObjectId();
    return null != i6 && null != s7 && i6 === s7;
  }
  _setRelatedFeaturesViewModels({ relatedFeatureViewModels: e11, relatedFeatures: t3, map: i6 }) {
    const { view: s7, spatialReference: o3, timeZone: r3 } = this;
    t3?.filter(Boolean).forEach((t4) => {
      e11.some((e12) => this._matchesFeature(e12, t4)) || e11.add(new se2({ abilities: { relationshipContent: false }, map: i6, view: s7, spatialReference: o3, timeZone: r3, graphic: t4 }));
    }), e11.forEach((i7) => {
      const s8 = t3?.find((e12) => this._matchesFeature(i7, e12));
      s8 || e11.remove(i7);
    });
  }
  _setExpressionContentVM(e11, t3) {
    const i6 = this.formattedAttributes, { contentElement: s7, contentElementViewModel: o3 } = e11, r3 = s7?.type;
    o3 && r3 && ("fields" === r3 && (this._createFieldsFormattedAttributes({ contentElement: s7, contentElementIndex: t3, formattedAttributes: i6 }), o3.set(this._createFieldsVMParams(s7, t3))), "media" === r3 && (this._createMediaFormattedAttributes({ contentElement: s7, contentElementIndex: t3, formattedAttributes: i6 }), o3.set(this._createMediaVMParams(s7, t3))), "text" === r3 && o3.set(this._createTextVMParams(s7)));
  }
  _compileRelationship(e11, t3) {
    const { displayCount: i6, orderByFields: s7, relationshipId: o3, title: r3, description: a5 } = e11, { _sourceLayer: n10, graphic: l6, map: p9 } = this;
    if (!J(n10)) return;
    const c14 = new m7(__spreadValues({ displayCount: i6, graphic: l6, orderByFields: s7, relationshipId: o3, layer: n10, map: p9 }, this._compileTitleAndDesc({ title: r3, description: a5 })));
    return this.contentViewModels[t3] = c14, this.addHandles(v(() => c14.relatedFeatures, "change", () => this._setRelatedFeaturesViewModels(c14)), ae2), e11;
  }
  _matchesGlobalFeature(e11, t3) {
    const i6 = e11?.association.globalId, s7 = t3?.association.globalId;
    return null != i6 && null != s7 && i6 === s7;
  }
  _setUpUtilityNetworkAssociationsViewModels(e11, t3, i6) {
    return __async(this, null, function* () {
      const { view: s7, spatialReference: o3, timeZone: r3 } = this;
      e11.forEach((i7, s8) => {
        const o4 = t3.get(s8);
        o4 ? i7.forEach((t4) => {
          o4.find((e12) => this._matchesGlobalFeature(t4, e12)) || (i7.remove(t4), 0 === i7.length && e11.delete(s8));
        }) : (i7.removeAll(), e11.delete(s8));
      }), t3.forEach((t4, n11) => {
        const l6 = e11.get(n11) || new V();
        t4?.filter(Boolean).forEach((e12) => {
          l6.some((t5) => this._matchesGlobalFeature(t5, e12)) || l6.add({ association: e12.association, featureViewModel: new se2({ abilities: { utilityNetworkAssociationsContent: false }, map: i6, view: s7, spatialReference: o3, timeZone: r3, graphic: e12.feature }), terminalName: e12.terminalName });
        }), e11.set(n11, l6);
      });
      const n10 = new AbortController();
      this._associationVMAbortController = n10, yield this._sortListObjectsByTitle(e11, { signal: n10.signal }), this._associationVMAbortController === n10 && (this._associationVMAbortController = null);
    });
  }
  _sortListObjectsByTitle(e11, t3) {
    return __async(this, null, function* () {
      for (const i6 of e11.values()) {
        const e12 = i6.map((e13) => w(() => "ready" === e13.featureViewModel.state, t3?.signal));
        yield Promise.all(e12), i6.sort(this._compareByFeatureTitle);
      }
    });
  }
  _compareByFeatureTitle(e11, t3) {
    const i6 = c6(e11.featureViewModel), s7 = c6(t3.featureViewModel);
    return i6.localeCompare(s7, void 0, { numeric: true });
  }
  _compileUtilityNetworkAssociation(e11, t3) {
    const { displayCount: i6, title: s7, description: o3, associationTypes: r3 } = e11, { _sourceLayer: a5, graphic: n10, map: l6 } = this;
    if (!K(a5)) return;
    const p9 = new _(__spreadValues({ graphic: n10, displayCount: i6, associationTypes: r3, layer: a5, map: l6 }, this._compileTitleAndDesc({ title: s7, description: o3 })));
    return this.contentViewModels[t3] = p9, this.addHandles([d3(() => p9.associationFeatures.values(), () => this._setUpUtilityNetworkAssociationsViewModels(p9.associationViewModels, p9.associationFeatures, p9.map))], ne), e11;
  }
  _compileExpression(e11, t3) {
    const { expressionInfo: i6 } = e11, { graphic: s7, map: o3, spatialReference: r3, view: a5, location: n10 } = this, l6 = new E2({ expressionInfo: i6, graphic: s7, interceptor: se2.interceptor, map: o3, spatialReference: r3, view: a5, location: n10 });
    return this.contentViewModels[t3] = l6, this.addHandles(d3(() => l6.contentElementViewModel, () => this._setExpressionContentVM(l6, t3), P), re2), e11;
  }
  _compileAttachments(e11, t3) {
    const { graphic: i6 } = this, { description: s7, title: o3, orderByFields: r3 } = e11;
    return this.contentViewModels[t3] = new c7(__spreadValues({ graphic: i6, orderByFields: r3 }, this._compileTitleAndDesc({ title: o3, description: s7 }))), e11;
  }
  _compileCustom(e11, t3) {
    const { graphic: i6 } = this, { creator: s7, destroyer: o3 } = e11;
    return this.contentViewModels[t3] = new p5({ graphic: i6, creator: s7, destroyer: o3 }), e11;
  }
  _compileTitleAndDesc({ title: e11, description: t3 }) {
    const { _fieldInfoMap: i6, _sourceLayer: s7, graphic: o3, formattedAttributes: r3 } = this, a5 = o3?.attributes, n10 = this._expressionAttributes, l6 = r3.global;
    return { title: D({ attributes: a5, fieldInfoMap: i6, globalAttributes: l6, expressionAttributes: n10, layer: s7, text: e11 }), description: D({ attributes: a5, fieldInfoMap: i6, globalAttributes: l6, expressionAttributes: n10, layer: s7, text: t3 }) };
  }
  _createFieldsVMParams(e11, t3) {
    const i6 = this._effectivePopupTemplate, s7 = this.formattedAttributes, o3 = __spreadValues(__spreadValues({}, s7?.global), s7?.content[t3]), r3 = e11?.fieldInfos || i6?.fieldInfos, a5 = r3?.filter(({ fieldName: e12 }) => !!e12 && (E(e12) || pe(e12) || o3.hasOwnProperty(e12))), n10 = i6?.expressionInfos, { description: l6, title: p9 } = e11;
    return __spreadValues({ attributes: o3, expressionInfos: n10, fieldInfos: a5 }, this._compileTitleAndDesc({ title: p9, description: l6 }));
  }
  _compileFields(e11, t3) {
    const i6 = e11.clone(), s7 = new n8(this._createFieldsVMParams(e11, t3));
    return this.contentViewModels[t3] = s7, i6.fieldInfos = s7.formattedFieldInfos.slice(), i6;
  }
  _createMediaVMParams(e11, t3) {
    const { abilities: i6, graphic: s7, _fieldInfoMap: o3, _effectivePopupTemplate: r3, relatedInfos: a5, _sourceLayer: n10, _expressionAttributes: l6 } = this, p9 = this.formattedAttributes, c14 = s7?.attributes ?? {}, { description: d9, mediaInfos: h7, title: u6 } = e11;
    return __spreadValues({ abilities: { chartAnimation: i6.chartAnimation }, activeMediaInfoIndex: e11.activeMediaInfoIndex || 0, attributes: c14, isAggregate: s7?.isAggregate, layer: n10, fieldInfoMap: o3, formattedAttributes: __spreadValues(__spreadValues({}, p9?.global), p9?.content[t3]), expressionAttributes: l6, mediaInfos: h7, popupTemplate: r3, relatedInfos: a5 }, this._compileTitleAndDesc({ title: u6, description: d9 }));
  }
  _compileMedia(e11, t3) {
    const i6 = e11.clone(), s7 = new M3(this._createMediaVMParams(e11, t3));
    return i6.mediaInfos = s7.formattedMediaInfos.slice(), this.contentViewModels[t3] = s7, i6;
  }
  _createTextVMParams(e11) {
    const { graphic: t3, _fieldInfoMap: i6, _sourceLayer: s7, _expressionAttributes: o3 } = this;
    if (e11 && e11.text) {
      const r3 = t3?.attributes ?? {}, a5 = this.formattedAttributes?.global ?? {};
      e11.text = D({ attributes: r3, fieldInfoMap: i6, globalAttributes: a5, expressionAttributes: o3, layer: s7, text: e11.text });
    }
    return { graphic: t3, creator: e11.text };
  }
  _compileText(e11, t3) {
    const i6 = e11.clone();
    return this.contentViewModels[t3] = new p5(this._createTextVMParams(i6)), i6;
  }
  _compileLastEditInfo() {
    const { _effectivePopupTemplate: e11, _sourceLayer: t3, graphic: i6, timeZone: s7 } = this;
    if (!e11) return;
    const { lastEditInfoEnabled: o3 } = e11, r3 = t3?.editFieldsInfo;
    return o3 && r3 ? re(r3, i6?.attributes, s7, t3) : void 0;
  }
  _compileTitle(e11) {
    const { _fieldInfoMap: t3, _sourceLayer: i6, graphic: s7, _expressionAttributes: o3 } = this, r3 = s7?.attributes ?? {}, a5 = this.formattedAttributes?.global ?? {};
    return D({ attributes: r3, fieldInfoMap: t3, globalAttributes: a5, expressionAttributes: o3, layer: i6, text: e11 });
  }
  _getTitle() {
    return __async(this, null, function* () {
      const { _effectivePopupTemplate: e11, graphic: t3 } = this;
      return t3 ? q({ type: "title", value: e11?.title, event: { graphic: t3 } }) : null;
    });
  }
  _getContent() {
    return __async(this, null, function* () {
      const { _effectivePopupTemplate: e11, graphic: t3 } = this;
      return t3 ? q({ type: "content", value: e11?.content, event: { graphic: t3 } }) : null;
    });
  }
  _evaluateExpressionAttributes({ title: e11, content: t3, expressionInfos: i6 }) {
    this._evaluateExpressionAttributesTask = e(this._evaluateExpressionAttributesTask), this._evaluateExpressionAttributesTask = d2((s7) => __async(this, null, function* () {
      const { graphic: o3, map: r3, view: a5, spatialReference: n10, location: p9 } = this;
      try {
        if (!o3) return;
        let l6;
        if (null != i6) {
          const e12 = [];
          for (const [t4, l7] of i6.expressions.entries()) null != l7 ? e12.push(l7.evaluate({ graphic: o3, interceptor: se2.interceptor, location: p9, map: r3, options: { signal: s7 }, spatialReference: n10, view: a5 }).then((e13) => [t4, c13(e13)]).catch(() => [t4, void 0])) : e12.push(Promise.resolve([t4, void 0]));
          l6 = Object.fromEntries(yield Promise.all(e12)), s2(s7);
        }
        this._expressionAttributes = l6, this._graphicExpressionAttributes = __spreadValues(__spreadValues({}, o3.attributes), l6), this._set("formattedAttributes", this._createFormattedAttributes(t3)), this._set("title", this._compileTitle(e11)), this._set("lastEditInfo", this._compileLastEditInfo() || null), this._set("content", this._compileContent(t3) || null);
      } catch (c14) {
        b(c14) || (this._error = c14, n.getLogger(this).error("error", "The popupTemplate could not be displayed for this feature.", { error: c14, graphic: o3, popupTemplate: this._effectivePopupTemplate }));
      }
    }));
  }
  _createMediaFormattedAttributes({ contentElement: e11, contentElementIndex: t3, formattedAttributes: i6 }) {
    const { _effectivePopupTemplate: s7, graphic: o3, relatedInfos: r3, _sourceLayer: a5, _fieldInfoMap: n10, _graphicExpressionAttributes: l6, timeZone: p9 } = this;
    i6.content[t3] = se({ fieldInfos: s7?.fieldInfos, graphic: o3, attributes: __spreadValues(__spreadValues({}, l6), e11.attributes), layer: a5, fieldInfoMap: n10, relatedInfos: r3, timeZone: p9 });
  }
  _createFieldsFormattedAttributes({ contentElement: e11, contentElementIndex: t3, formattedAttributes: i6 }) {
    if (e11.fieldInfos) {
      const { graphic: s7, relatedInfos: o3, _sourceLayer: r3, _fieldInfoMap: a5, _graphicExpressionAttributes: n10, timeZone: l6 } = this;
      i6.content[t3] = se({ fieldInfos: e11.fieldInfos, graphic: s7, attributes: __spreadValues(__spreadValues({}, n10), e11.attributes), layer: r3, fieldInfoMap: a5, relatedInfos: o3, timeZone: l6 });
    }
  }
  _createFormattedAttributes(e11) {
    const { _effectivePopupTemplate: t3, graphic: i6, relatedInfos: s7, _sourceLayer: o3, _fieldInfoMap: r3, _graphicExpressionAttributes: a5, timeZone: n10 } = this, l6 = t3?.fieldInfos, p9 = { global: se({ fieldInfos: l6, graphic: i6, attributes: a5, layer: o3, fieldInfoMap: r3, relatedInfos: s7, timeZone: n10 }), content: [] };
    return Array.isArray(e11) && e11.forEach((e12, t4) => {
      "fields" === e12.type && this._createFieldsFormattedAttributes({ contentElement: e12, contentElementIndex: t4, formattedAttributes: p9 }), "media" === e12.type && this._createMediaFormattedAttributes({ contentElement: e12, contentElementIndex: t4, formattedAttributes: p9 });
    }), p9;
  }
  _checkForRelatedFeatures(e11) {
    const { graphic: t3, _effectivePopupTemplate: i6 } = this;
    return this._queryRelatedInfos(t3, oe(i6), e11);
  }
  _queryRelatedInfos(e11, t3, i6) {
    return __async(this, null, function* () {
      const { relatedInfos: s7, _sourceLayer: o3 } = this;
      s7.clear();
      const r3 = null != o3?.associatedLayer ? yield o3?.associatedLayer.load(i6) : o3;
      if (!r3 || !e11) return;
      const a5 = t3.filter((e12) => !!e12.fieldName && pe(e12.fieldName));
      if (!a5?.length) return;
      t3.forEach((e12) => this._configureRelatedInfo(e12, r3));
      const n10 = yield v2({ relatedInfos: s7, layer: r3 }, i6);
      Object.keys(n10).forEach((e12) => {
        const t4 = s7.get(e12.toString()), i7 = n10[e12]?.value;
        t4 && i7 && (t4.layerInfo = i7.data);
      });
      const l6 = yield T2({ graphic: e11, relatedInfos: s7, layer: r3 }, i6);
      Object.keys(l6).forEach((e12) => {
        S(l6[e12]?.value, s7.get(e12.toString()));
      });
    });
  }
  _configureRelatedInfo(e11, t3) {
    const { relatedInfos: i6 } = this, s7 = h4(e11.fieldName || "");
    if (!s7) return;
    const { layerId: o3, fieldName: r3 } = s7;
    if (!o3) return;
    const a5 = i6.get(o3.toString()) || g4(o3, t3);
    a5 && (q2({ relatedInfo: a5, fieldName: r3, fieldInfo: e11 }), this.relatedInfos.set(o3, a5));
  }
};
pe2.interceptor = new e9(he, we), r([m()], pe2.prototype, "_error", void 0), r([m()], pe2.prototype, "_graphicChangedTask", void 0), r([m()], pe2.prototype, "_evaluateExpressionAttributesTask", void 0), r([m()], pe2.prototype, "_associationVMAbortController", void 0), r([m({ readOnly: true })], pe2.prototype, "_effectivePopupTemplate", null), r([m({ readOnly: true })], pe2.prototype, "_fieldInfoMap", null), r([m({ readOnly: true })], pe2.prototype, "_sourceLayer", null), r([m()], pe2.prototype, "abilities", void 0), r([s4("abilities")], pe2.prototype, "castAbilities", null), r([m({ readOnly: true })], pe2.prototype, "content", void 0), r([m({ readOnly: true })], pe2.prototype, "contentViewModels", void 0), r([m()], pe2.prototype, "description", void 0), r([m({ type: Boolean })], pe2.prototype, "defaultPopupTemplateEnabled", void 0), r([m({ readOnly: true })], pe2.prototype, "isTable", null), r([m({ readOnly: true })], pe2.prototype, "state", null), r([m({ readOnly: true })], pe2.prototype, "formattedAttributes", void 0), r([m({ type: b2, value: null })], pe2.prototype, "graphic", null), r([m({ readOnly: true })], pe2.prototype, "lastEditInfo", void 0), r([m({ type: j })], pe2.prototype, "location", void 0), r([m({ readOnly: true })], pe2.prototype, "relatedInfos", void 0), r([m({ type: g3 })], pe2.prototype, "spatialReference", null), r([m()], pe2.prototype, "timeZone", null), r([m({ readOnly: true })], pe2.prototype, "title", void 0), r([m()], pe2.prototype, "map", null), r([m({ readOnly: true })], pe2.prototype, "waitingForContent", null), r([m()], pe2.prototype, "view", void 0), pe2 = se2 = r([a("esri.widgets.Feature.FeatureViewModel")], pe2);
var ce = pe2;

// node_modules/@arcgis/core/widgets/Feature/resources.js
var e10 = "esri-feature";
var t2 = { base: e10, container: `${e10}__size-container`, title: `${e10}__title`, main: `${e10}__main-container`, btn: `${e10}__button`, icon: `${e10}__icon`, content: `${e10}__content`, contentNode: `${e10}__content-node`, contentNodeText: `${e10}__content-node--text`, contentElement: `${e10}__content-element`, text: `${e10}__text`, lastEditedInfo: `${e10}__last-edited-info`, fields: `${e10}__fields`, fieldHeader: `${e10}__field-header`, fieldData: `${e10}__field-data`, fieldDataDate: `${e10}__field-data--date`, loadingSpinnerContainer: `${e10}__loading-container` };

// node_modules/@arcgis/core/widgets/Feature/support/FeatureContentMixin.js
var n9 = (n10) => {
  let i6 = class extends n10 {
    constructor() {
      super(...arguments), this.renderNodeContent = (e11) => e7(e11) && !e11.destroyed ? n2("div", { class: t2.contentNode, key: e11 }, e11.render()) : e11 instanceof HTMLElement ? n2("div", { afterCreate: this._attachToNode, bind: e11, class: t2.contentNode, key: e11 }) : t(e11) ? n2("div", { afterCreate: this._attachToNode, bind: e11.domNode, class: t2.contentNode, key: e11 }) : null;
    }
    _attachToNode(e11) {
      const o3 = this;
      e11.appendChild(o3);
    }
  };
  return i6 = r([a("esri.widgets.Feature.support.FeatureContentMixin")], i6), i6;
};

// node_modules/@arcgis/core/widgets/Feature.js
var b8 = { title: true, content: true, lastEditedInfo: true };
var F5 = class extends n9(O) {
  constructor(e11, t3) {
    super(e11, t3), this._contentWidgets = [], this.flowType = "feature", this.flowItems = null, this.headingLevel = 2, this.messages = null, this.messagesCommon = null, this.visibleElements = __spreadValues({}, b8), this.viewModel = new ce();
  }
  initialize() {
    this.addHandles(d3(() => this.viewModel?.contentViewModels, () => this._setupContentWidgets(), P));
  }
  loadDependencies() {
    return c3({ notice: () => import("./calcite-notice-X7K5RWS6.js"), loader: () => import("./calcite-loader-Z6UVHYMG.js") });
  }
  destroy() {
    this._destroyContentWidgets();
  }
  get graphic() {
    return this.viewModel.graphic;
  }
  set graphic(e11) {
    this.viewModel.graphic = e11;
  }
  get defaultPopupTemplateEnabled() {
    return this.viewModel.defaultPopupTemplateEnabled;
  }
  set defaultPopupTemplateEnabled(e11) {
    this.viewModel.defaultPopupTemplateEnabled = e11;
  }
  get isTable() {
    return this.viewModel.isTable;
  }
  get icon() {
    return "polygon";
  }
  set icon(e11) {
    this._overrideIfSome("icon", e11);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e11) {
    this._overrideIfSome("label", e11);
  }
  get location() {
    return this.viewModel.location;
  }
  set location(e11) {
    this.viewModel.location = e11;
  }
  get spatialReference() {
    return this.viewModel.spatialReference;
  }
  set spatialReference(e11) {
    this.viewModel.spatialReference = e11;
  }
  get timeZone() {
    return this.viewModel.timeZone;
  }
  set timeZone(e11) {
    this.viewModel.timeZone = e11;
  }
  get title() {
    return this.viewModel.title;
  }
  castVisibleElements(e11) {
    return __spreadValues(__spreadValues({}, b8), e11);
  }
  get map() {
    return this.viewModel.map;
  }
  set map(e11) {
    this.viewModel.map = e11;
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e11) {
    this.viewModel.view = e11;
  }
  setActiveMedia(e11, t3) {
    return this.viewModel.setActiveMedia(e11, t3);
  }
  nextMedia(e11) {
    return this.viewModel.nextMedia(e11);
  }
  previousMedia(e11) {
    return this.viewModel.previousMedia(e11);
  }
  render() {
    const { state: e11 } = this.viewModel, t3 = n2("div", { class: t2.container, key: "container" }, this._renderTitle(), "error" === e11 ? this._renderError() : "loading" === e11 ? this._renderLoading() : this._renderContentContainer());
    return n2("div", { class: this.classes(t2.base, e5.widget) }, t3);
  }
  _renderError() {
    const { messagesCommon: e11, messages: t3, visibleElements: s7 } = this;
    return n2("calcite-notice", { icon: "exclamation-mark-circle", kind: "danger", open: true, scale: "s" }, s7.title ? n2("div", { key: "error-title", slot: "title" }, e11.errorMessage) : null, n2("div", { key: "error-message", slot: "message" }, t3.loadingError));
  }
  _renderLoading() {
    return n2("div", { class: t2.loadingSpinnerContainer, key: "loading-container" }, n2("calcite-loader", { inline: true, label: "" }));
  }
  _renderContentContainer() {
    const { visibleElements: e11 } = this;
    return e11.content ? n2("div", { class: t2.main }, [this._renderContent(), this._renderLastEditInfo()]) : null;
  }
  _renderTitle() {
    const { visibleElements: e11, title: t3 } = this;
    return e11.title ? n2(e6, { class: t2.title, innerHTML: t3, level: this.headingLevel }) : null;
  }
  _renderContent() {
    const e11 = this.viewModel.content, t3 = "content";
    if (!e11) return null;
    if (Array.isArray(e11)) return e11.length ? n2("div", { class: t2.contentNode, key: `${t3}-content-elements` }, e11.map(this._renderContentElement, this)) : null;
    if ("string" == typeof e11) {
      const e12 = this._contentWidgets[0];
      return !e12 || e12.destroyed ? null : n2("div", { class: this.classes(t2.contentNode, t2.contentNodeText), key: `${t3}-content` }, e12.render());
    }
    return this.renderNodeContent(e11);
  }
  _renderContentElement(e11, t3) {
    const { visibleElements: s7 } = this;
    if ("boolean" != typeof s7.content && !s7.content?.[e11.type]) return null;
    switch (e11.type) {
      case "attachments":
        return this._renderAttachments(t3);
      case "custom":
        return this._renderCustom(e11, t3);
      case "fields":
        return this._renderFields(t3);
      case "media":
        return this._renderMedia(t3);
      case "text":
        return this._renderText(e11, t3);
      case "expression":
        return this._renderExpression(t3);
      case "relationship":
        return this._renderRelationship(t3);
      case "utility-network-associations":
        return this._renderAssociation(t3);
      default:
        return null;
    }
  }
  _renderAttachments(e11) {
    const t3 = this._contentWidgets[e11];
    if (!t3 || t3.destroyed) return null;
    const { state: s7, attachmentInfos: i6 } = t3.viewModel;
    return "loading" === s7 || i6.length > 0 ? n2("div", { class: this.classes(t2.contentElement), key: this._buildKey("attachments-element", e11) }, t3.render()) : null;
  }
  _renderRelationship(e11) {
    const t3 = this._contentWidgets[e11];
    return t3 && !t3.destroyed && this.flowItems ? n2("div", { class: t2.contentElement, key: this._buildKey("relationship-element", e11) }, t3.render()) : null;
  }
  _renderAssociation(e11) {
    const t3 = this._contentWidgets[e11];
    return t3 && !t3.destroyed && this.flowItems ? n2("div", { class: t2.contentElement, key: this._buildKey("utility-network-association-element", e11) }, t3.render()) : null;
  }
  _renderExpression(e11) {
    const t3 = this._contentWidgets[e11];
    return t3 && !t3.destroyed && t3.viewModel.contentElement ? n2("div", { class: t2.contentElement, key: this._buildKey("expression-element", e11) }, t3.render()) : null;
  }
  _renderCustom(e11, t3) {
    const { creator: s7 } = e11, i6 = this._contentWidgets[t3];
    return !i6 || i6.destroyed ? null : s7 ? n2("div", { class: t2.contentElement, key: this._buildKey("custom-element", t3) }, i6.render()) : null;
  }
  _renderFields(e11) {
    const t3 = this._contentWidgets[e11];
    return !t3 || t3.destroyed ? null : n2("div", { class: t2.contentElement, key: this._buildKey("fields-element", e11) }, t3.render());
  }
  _renderMedia(e11) {
    const t3 = this._contentWidgets[e11];
    return !t3 || t3.destroyed ? null : n2("div", { class: t2.contentElement, key: this._buildKey("media-element", e11) }, t3.render());
  }
  _renderLastEditInfo() {
    const { visibleElements: e11, messages: t3 } = this, { lastEditInfo: s7 } = this.viewModel;
    if (!s7 || !e11.lastEditedInfo) return null;
    const { date: i6, user: n10 } = s7, o3 = "edit" === s7.type ? n10 ? t3.lastEditedByUser : t3.lastEdited : n10 ? t3.lastCreatedByUser : t3.lastCreated, r3 = s3(o3, { date: i6, user: n10 });
    return n2("div", { class: this.classes(t2.lastEditedInfo, t2.contentElement), key: "edit-info-element" }, r3);
  }
  _renderText(e11, t3) {
    const s7 = e11.text, i6 = this._contentWidgets[t3];
    return !i6 || i6.destroyed ? null : s7 ? n2("div", { class: this.classes(t2.contentElement, t2.text), key: this._buildKey("text-element", t3) }, i6.render()) : null;
  }
  _buildKey(e11, ...t3) {
    return `${e11}__${this.viewModel?.graphic?.uid || "0"}-${t3.join("-")}`;
  }
  _destroyContentWidget(e11) {
    e11 && (e11.viewModel = null, !e11.destroyed && e11.destroy());
  }
  _destroyContentWidgets() {
    this._contentWidgets.forEach((e11) => this._destroyContentWidget(e11)), this._contentWidgets = [];
  }
  _setupContentWidgets() {
    this._destroyContentWidgets();
    const { headingLevel: e11, visibleElements: t3, flowItems: s7, viewModel: i6 } = this, n10 = i6?.content, { contentViewModels: o3 } = i6;
    if (Array.isArray(n10)) n10.forEach((n11, r3) => {
      if ("attachments" === n11.type && (this._contentWidgets[r3] = new c9({ displayType: n11.displayType, headingLevel: t3.title && e11 < 6 ? e11 + 1 : e11, viewModel: o3[r3] })), "fields" === n11.type && (this._contentWidgets[r3] = new h3({ viewModel: o3[r3] })), "media" === n11.type && (this._contentWidgets[r3] = new b5({ viewModel: o3[r3] })), "text" === n11.type && (this._contentWidgets[r3] = new p6({ viewModel: o3[r3] })), "custom" === n11.type && (this._contentWidgets[r3] = new p6({ viewModel: o3[r3] })), "expression" === n11.type && (this._contentWidgets[r3] = new h6({ viewModel: o3[r3] })), "relationship" === n11.type) {
        const e12 = new E3({ flowItems: s7, featureVisibleElements: t3, viewModel: o3[r3] });
        this._contentWidgets[r3] = e12;
      }
      if ("utility-network-associations" === n11.type) {
        const e12 = (e13) => __async(this, null, function* () {
          const { viewModel: n13, listType: o4, title: r4 } = e13;
          if (!s7) return;
          n13.activeAssociationType = o4;
          const { default: l6 } = yield import("./FeatureUtilityNetworkAssociationList-VIAWMZWE.js"), d9 = new l6({ viewModel: n13, parentFeatureViewModel: i6, listType: o4, title: r4, featureVisibleElements: t3, description: i6.title, flowItems: s7 });
          s7.push(d9);
        }), n12 = new w7({ flowItems: s7, onSelectAssociationType: e12, parentFeatureViewModel: i6, featureVisibleElements: t3, viewModel: o3[r3] });
        this._contentWidgets[r3] = n12;
      }
    }, this);
    else {
      const e12 = o3[0];
      e12 && !e12.destroyed && (this._contentWidgets[0] = new p6({ viewModel: e12 }));
    }
    this.scheduleRender();
  }
};
r([m()], F5.prototype, "flowType", void 0), r([m()], F5.prototype, "graphic", null), r([m()], F5.prototype, "defaultPopupTemplateEnabled", null), r([m()], F5.prototype, "flowItems", void 0), r([m()], F5.prototype, "headingLevel", void 0), r([m({ readOnly: true })], F5.prototype, "isTable", null), r([m()], F5.prototype, "icon", null), r([m()], F5.prototype, "label", null), r([m()], F5.prototype, "location", null), r([m(), e3("esri/widgets/Feature/t9n/Feature")], F5.prototype, "messages", void 0), r([m(), e3("esri/t9n/common")], F5.prototype, "messagesCommon", void 0), r([m()], F5.prototype, "spatialReference", null), r([m()], F5.prototype, "timeZone", null), r([m({ readOnly: true })], F5.prototype, "title", null), r([m()], F5.prototype, "visibleElements", void 0), r([s4("visibleElements")], F5.prototype, "castVisibleElements", null), r([m()], F5.prototype, "map", null), r([m()], F5.prototype, "view", null), r([m({ type: ce })], F5.prototype, "viewModel", void 0), F5 = r([a("esri.widgets.Feature")], F5);
var j3 = F5;

export {
  e8 as e,
  i4 as i,
  ce,
  t2 as t,
  n9 as n,
  j3 as j
};
//# sourceMappingURL=chunk-4RDSO3HQ.js.map
