import {
  n as n2
} from "./chunk-NHQG7442.js";
import {
  n
} from "./chunk-NKR2RDLV.js";
import {
  gt
} from "./chunk-DE32Y63I.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/interactive/snapping/candidates/VertexSnappingCandidate.js
var r = class extends n2 {
  constructor(n3) {
    super(__spreadProps(__spreadValues({}, n3), { constraint: new gt(n3.targetPoint) }));
  }
  get hints() {
    return [new n(this.targetPoint, this.isDraped, this.domain)];
  }
};

export {
  r
};
//# sourceMappingURL=chunk-3LAPJDBF.js.map
