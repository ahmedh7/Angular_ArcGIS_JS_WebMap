import {
  de
} from "./chunk-M4AN7OP4.js";
import "./chunk-OH6OSXKN.js";
import "./chunk-DNEDDVKD.js";
import "./chunk-YQO7GWC5.js";
import "./chunk-EXHXC722.js";
import "./chunk-TRNOGPKA.js";
import "./chunk-7U65WB7R.js";
import "./chunk-VGYZO5HJ.js";
import "./chunk-O4NL4QZF.js";
import "./chunk-TDZIOYA4.js";
import "./chunk-YPRFDORJ.js";
import "./chunk-YDLYZSD6.js";
import "./chunk-KEKYRYUA.js";
import "./chunk-533JJUXT.js";
import "./chunk-ZCMIPKW3.js";
import "./chunk-X6T5VEW7.js";
import "./chunk-EVW7H5NJ.js";
import "./chunk-J3U7APHK.js";
import "./chunk-ZC4RADQE.js";
import "./chunk-E4HJHXVP.js";
import "./chunk-RQ6IQ4BT.js";
import "./chunk-5D234OR6.js";
import "./chunk-4XQ6HIDT.js";
import "./chunk-3KYOSJE7.js";
import "./chunk-CNXZGF3Y.js";
import "./chunk-KJHYC7BN.js";
import "./chunk-NMUQNQHB.js";
import "./chunk-56WSBGZV.js";
import "./chunk-TYAFRNDR.js";
import "./chunk-WBSQXEJL.js";
import "./chunk-QMWFG3RP.js";
import "./chunk-ERJ4P4XU.js";
import "./chunk-OJJ7RDNK.js";
import "./chunk-MAGZONKR.js";
import "./chunk-J27IB6CR.js";
import "./chunk-4G6QLHLE.js";
import "./chunk-HK6ZY4DB.js";
import "./chunk-6BUGRELN.js";
import "./chunk-KATWIIRQ.js";
import "./chunk-OQS7WWFI.js";
import "./chunk-CLYBQCLI.js";
import "./chunk-5W6AKKT7.js";
import "./chunk-P7U5GMBX.js";
import "./chunk-LMRFTBDK.js";
import "./chunk-CYBG545K.js";
import "./chunk-YUTTVJPP.js";
import "./chunk-MAJ7IL5K.js";
import "./chunk-5JVPNPMF.js";
import "./chunk-WE5LNMLZ.js";
import "./chunk-Y4LJQHLE.js";
import "./chunk-BIUKECJ2.js";
import "./chunk-CEREZWZ6.js";
import "./chunk-WA3XXJQ5.js";
import "./chunk-5BGQWKMP.js";
import "./chunk-DZRJWV5H.js";
import "./chunk-ILKILLWA.js";
import "./chunk-SQ26WZ7J.js";
import "./chunk-PAXNBAQG.js";
import "./chunk-LYJYKR5U.js";
import "./chunk-YPWSYT7S.js";
import "./chunk-UF7FRKBZ.js";
import "./chunk-N3UNX5HB.js";
import "./chunk-H2P3UBJX.js";
import "./chunk-UQISDG6Y.js";
import "./chunk-VACYGDXY.js";
import "./chunk-77RFUTEK.js";
import "./chunk-L3LR7QC5.js";
import "./chunk-MKDJERJR.js";
import "./chunk-O3P5XPEU.js";
import "./chunk-UPSWNHFU.js";
import "./chunk-EDBHW3EG.js";
import "./chunk-3RDPSSYB.js";
import "./chunk-SZIT3IYE.js";
import "./chunk-CVMQJ2BZ.js";
import "./chunk-UX6MBXX3.js";
import "./chunk-BF5XGRKQ.js";
import "./chunk-ZFPFQ4J4.js";
import "./chunk-P5BI27MR.js";
import "./chunk-DTRN4OOH.js";
import "./chunk-3P3SZYCX.js";
import "./chunk-4VNKTESB.js";
import "./chunk-KVZR5ILN.js";
import "./chunk-BOHQCAJM.js";
import "./chunk-KK6BHWJD.js";
import "./chunk-KJXL4KHH.js";
import "./chunk-B4CSKOTH.js";
import "./chunk-37VXXTCK.js";
import "./chunk-XHRVMHQV.js";
import "./chunk-XAJHU5YA.js";
import "./chunk-6AFIGCYY.js";
import "./chunk-OPMACZPA.js";
import "./chunk-G72JIG3C.js";
import "./chunk-B6TLVNFQ.js";
import "./chunk-DNKL4VLK.js";
import "./chunk-JA6WVUX5.js";
import "./chunk-HLUCHGW6.js";
import "./chunk-5ZLWOYXQ.js";
import "./chunk-LMKW53EF.js";
import "./chunk-245OSL56.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-G4JWBWXC.js";
import "./chunk-TX7HQE3N.js";
import "./chunk-O4PT2W5W.js";
import "./chunk-VDUPOWSD.js";
import "./chunk-PCY7U2ND.js";
import "./chunk-WFMHAEPG.js";
import "./chunk-JTVRCNJE.js";
import "./chunk-KD5GWDMJ.js";
import "./chunk-AV2MJVRY.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-5MM6JTK5.js";
import "./chunk-EMGBZTFR.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import "./chunk-NEOVY6GP.js";
import "./chunk-ELAKODAU.js";
import "./chunk-CMPLJJCX.js";
import "./chunk-JHB4QD5T.js";
import "./chunk-XWFSWJ3K.js";
import "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import "./chunk-7OZN72PM.js";
import "./chunk-Z4ITP2HY.js";
import "./chunk-WOVS7CNY.js";
import "./chunk-4VQUNH2Z.js";
import "./chunk-7SLET7NM.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import "./chunk-DSFF7UA2.js";
import "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import "./chunk-S4BA7TJA.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-2K433C2G.js";
import "./chunk-EOJGN7NW.js";
import "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import "./chunk-VYI6FOKY.js";
import "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/layers/CatalogFootprintLayerView.js
var t = (t3) => {
  let s = class extends t3 {
    constructor(...e) {
      super(...e);
    }
    get updateSuspended() {
      const e = this.parent?.dynamicGroupLayerView;
      return this.suspended && (!e || true === e.suspended);
    }
    queryAttributeBins() {
      throw new Error("Not implemented");
    }
    queryAggregates() {
      throw new Error("Not implemented");
    }
  };
  return r([m()], s.prototype, "layer", void 0), r([m()], s.prototype, "parent", void 0), r([m()], s.prototype, "highlightOptions", void 0), r([m()], s.prototype, "updateSuspended", null), s = r([a("esri.views.layers.CatalogFootprintLayerView")], s), s;
};

// node_modules/@arcgis/core/views/2d/layers/CatalogFootprintLayerView2D.js
var t2 = class extends t(de) {
};
t2 = r([a("esri.views.2d.layers.CatalogFootprintLayerView2D")], t2);
var a2 = t2;
export {
  a2 as default
};
//# sourceMappingURL=CatalogFootprintLayerView2D-NG7OVUS2.js.map
