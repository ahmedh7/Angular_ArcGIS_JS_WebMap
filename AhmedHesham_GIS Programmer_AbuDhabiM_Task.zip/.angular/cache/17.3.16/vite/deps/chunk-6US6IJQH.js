import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/Float3DrawUniform.js
var o = class extends i {
  constructor(e, o2) {
    super(e, "vec3", a.Draw, (r, s, t, m) => r.setUniform3fv(e, o2(s, t, m)));
  }
};

export {
  o
};
//# sourceMappingURL=chunk-6US6IJQH.js.map
