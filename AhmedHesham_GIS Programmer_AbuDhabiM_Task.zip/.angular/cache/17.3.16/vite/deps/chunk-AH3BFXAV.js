// node_modules/@arcgis/core/views/support/selectionUtils.js
function e(e2) {
  return !!(null != e2 && "object" == typeof e2 && "createQuery" in e2 && e2.createQuery && "on" in e2 && e2.on);
}

export {
  e
};
//# sourceMappingURL=chunk-AH3BFXAV.js.map
