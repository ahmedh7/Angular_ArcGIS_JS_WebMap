import {
  A,
  d
} from "./chunk-VYI6FOKY.js";
import {
  e
} from "./chunk-VT56RVNM.js";

// node_modules/@arcgis/core/layers/catalog/catalogUtils.js
var n = /* @__PURE__ */ new WeakMap();
function a(o) {
  return !o.destroyed && (n.has(o) || o.addHandles([d(() => {
    const e2 = o.parent;
    return !(!e2 || !("type" in e2)) && ("catalog-dynamic-group" === e2.type || a(e2));
  }, (e2) => n.set(o, e2), A), e(() => n.delete(o))]), n.get(o));
}
function i(e2, t) {
  const r = e2.parent, n2 = e2.layer;
  if ("map-image" !== n2?.type || !n2.sourceJSON || !r) return false;
  const a2 = n2.sourceJSON.layers;
  if (!a2) return false;
  const o = a2.find((t2) => e2.id === t2.id), i2 = "footprints" === t ? "Feature Layer" : "Catalog Dynamic Group Layer";
  return o?.type === i2 && "Catalog Layer" === a2.find((e3) => e3.id === r.id)?.type;
}

export {
  a,
  i
};
//# sourceMappingURL=chunk-723TUEOK.js.map
