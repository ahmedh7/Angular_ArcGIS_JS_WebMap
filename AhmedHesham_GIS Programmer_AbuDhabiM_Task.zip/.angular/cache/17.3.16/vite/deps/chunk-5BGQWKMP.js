import {
  d
} from "./chunk-V6AHEXFE.js";
import {
  e,
  t
} from "./chunk-QWS2NSQP.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a,
  n2 as n
} from "./chunk-JB56QM27.js";
import {
  has
} from "./chunk-D5RIMQ7U.js";

// node_modules/@arcgis/core/layers/effects/EffectView.js
var l = -1;
var a3 = class extends g {
  constructor(t2) {
    super(t2), this._from = null, this._to = null, this._final = null, this._current = [], this._time = 0, this.duration = has("mapview-transitions-duration"), this.effects = [];
  }
  set effect(t2) {
    if (this._get("effect") !== (t2 = t2 || "")) {
      this._set("effect", t2);
      try {
        this._transitionTo(h(t2));
      } catch (e2) {
        this._transitionTo([]), n.getLogger(this).warn("Invalid Effect", { effect: t2, error: e2 });
      }
    }
  }
  get final() {
    return this._final;
  }
  get hasEffects() {
    return this.transitioning || !!this.effects.length;
  }
  set scale(t2) {
    this._updateForScale(t2);
  }
  get transitioning() {
    return null !== this._to;
  }
  canTransitionTo(t2) {
    try {
      return this.scale > 0 && u(this._current, h(t2), this.scale);
    } catch {
      return false;
    }
  }
  transitionStep(t2, e2) {
    this._applyTimeTransition(t2), this._updateForScale(e2);
  }
  endTransition() {
    this._applyTimeTransition(this.duration);
  }
  _transitionTo(t2) {
    this.scale > 0 && u(this._current, t2, this.scale) ? (this._final = t2, this._to = a(t2), _(this._current, this._to, this.scale), this._from = a(this._current), this._time = 0) : (this._from = this._to = this._final = null, this._current = t2), this._set("effects", this._current[0] ? a(this._current[0].effects) : []);
  }
  _applyTimeTransition(t2) {
    if (!(this._to && this._from && this._current && this._final)) return;
    this._time += t2;
    const e2 = Math.min(1, this._time / this.duration);
    for (let s = 0; s < this._current.length; s++) {
      const t3 = this._current[s], r2 = this._from[s], i = this._to[s];
      t3.scale = p(r2.scale, i.scale, e2);
      for (let s2 = 0; s2 < t3.effects.length; s2++) {
        const n2 = t3.effects[s2], c = r2.effects[s2], o = i.effects[s2];
        n2.interpolate(c, o, e2);
      }
    }
    1 === e2 && (this._current = this._final, this._set("effects", this._current[0] ? a(this._current[0].effects) : []), this._from = this._to = this._final = null);
  }
  _updateForScale(t2) {
    if (this._set("scale", t2), 0 === this._current.length) return;
    const e2 = this._current, s = this._current.length - 1;
    let r2, i, n2 = 1;
    if (1 === e2.length || t2 >= e2[0].scale) i = r2 = e2[0].effects;
    else if (t2 <= e2[s].scale) i = r2 = e2[s].effects;
    else for (let c = 0; c < s; c++) {
      const s2 = e2[c], o = e2[c + 1];
      if (s2.scale >= t2 && o.scale <= t2) {
        n2 = (t2 - s2.scale) / (o.scale - s2.scale), r2 = s2.effects, i = o.effects;
        break;
      }
    }
    for (let c = 0; c < this.effects.length; c++) {
      this.effects[c].interpolate(r2[c], i[c], n2);
    }
  }
};
function h(t2) {
  const e2 = d(t2) || [];
  return m2(e2) ? [{ scale: l, effects: e2 }] : e2;
}
function u(t2, e2, s) {
  if (!t2[0]?.effects || !e2[0]?.effects) return true;
  return !((t2[0]?.scale === l || e2[0]?.scale === l) && (t2.length > 1 || e2.length > 1) && s <= 0) && t(t2[0].effects, e2[0].effects);
}
function _(t2, e2, s) {
  const r2 = t2.length > e2.length ? t2 : e2, i = t2.length > e2.length ? e2 : t2, n2 = i[i.length - 1], c = n2?.scale ?? s, o = n2?.effects ?? [];
  for (let f = i.length; f < r2.length; f++) i.push({ scale: c, effects: [...o] });
  for (let a4 = 0; a4 < r2.length; a4++) i[a4].scale = i[a4].scale === l ? s : i[a4].scale, r2[a4].scale = r2[a4].scale === l ? s : r2[a4].scale, e(i[a4].effects, r2[a4].effects);
}
function p(t2, e2, s) {
  return t2 + (e2 - t2) * s;
}
function m2(t2) {
  const e2 = t2[0];
  return !!e2 && "type" in e2;
}
r([m()], a3.prototype, "_to", void 0), r([m()], a3.prototype, "duration", void 0), r([m({ value: "" })], a3.prototype, "effect", null), r([m({ readOnly: true })], a3.prototype, "effects", void 0), r([m({ readOnly: true })], a3.prototype, "final", null), r([m({ readOnly: true })], a3.prototype, "hasEffects", null), r([m({ value: 0 })], a3.prototype, "scale", null), r([m({ readOnly: true })], a3.prototype, "transitioning", null), a3 = r([a2("esri.layers.effects.EffectView")], a3);

export {
  a3 as a
};
//# sourceMappingURL=chunk-5BGQWKMP.js.map
