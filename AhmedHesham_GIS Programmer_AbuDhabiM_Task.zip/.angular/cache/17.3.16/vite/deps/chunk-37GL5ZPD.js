// node_modules/@arcgis/core/libs/basisu/TextureFormat.js
var _;
!function(_2) {
  _2[_2.ETC1_RGB = 0] = "ETC1_RGB", _2[_2.ETC2_RGBA = 1] = "ETC2_RGBA", _2[_2.BC1_RGB = 2] = "BC1_RGB", _2[_2.BC3_RGBA = 3] = "BC3_RGBA", _2[_2.BC4_R = 4] = "BC4_R", _2[_2.BC5_RG = 5] = "BC5_RG", _2[_2.BC7_M6_RGB = 6] = "BC7_M6_RGB", _2[_2.BC7_M5_RGBA = 7] = "BC7_M5_RGBA", _2[_2.PVRTC1_4_RGB = 8] = "PVRTC1_4_RGB", _2[_2.PVRTC1_4_RGBA = 9] = "PVRTC1_4_RGBA", _2[_2.ASTC_4x4_RGBA = 10] = "ASTC_4x4_RGBA", _2[_2.ATC_RGB = 11] = "ATC_RGB", _2[_2.ATC_RGBA = 12] = "ATC_RGBA", _2[_2.FXT1_RGB = 17] = "FXT1_RGB", _2[_2.PVRTC2_4_RGB = 18] = "PVRTC2_4_RGB", _2[_2.PVRTC2_4_RGBA = 19] = "PVRTC2_4_RGBA", _2[_2.ETC2_EAC_R11 = 20] = "ETC2_EAC_R11", _2[_2.ETC2_EAC_RG11 = 21] = "ETC2_EAC_RG11", _2[_2.RGBA32 = 13] = "RGBA32", _2[_2.RGB565 = 14] = "RGB565", _2[_2.BGR565 = 15] = "BGR565", _2[_2.RGBA4444 = 16] = "RGBA4444";
}(_ || (_ = {}));

export {
  _
};
//# sourceMappingURL=chunk-37GL5ZPD.js.map
