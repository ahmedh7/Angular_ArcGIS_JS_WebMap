// node_modules/@esri/calcite-components/dist/chunks/key.js
function t(n) {
  return n === "Enter" || n === " ";
}
var e = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

export {
  t,
  e
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/key.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-7BYAEWQF.js.map
