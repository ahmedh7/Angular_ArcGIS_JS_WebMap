import {
  O as O2
} from "./chunk-4JZKYSSB.js";
import {
  I,
  N,
  f,
  i as i2,
  s as s2,
  t,
  u
} from "./chunk-GTVPP55O.js";
import "./chunk-OFAEEHL4.js";
import {
  s
} from "./chunk-3P3SZYCX.js";
import "./chunk-YHKJPCKF.js";
import "./chunk-JYALIYUG.js";
import {
  e as e3
} from "./chunk-HL6SQA2H.js";
import "./chunk-ECG7JDDX.js";
import "./chunk-NE6ESLWJ.js";
import {
  e as e2
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c,
  e
} from "./chunk-PPAPRIQT.js";
import {
  n2 as n
} from "./chunk-L7IGKLK6.js";
import {
  T
} from "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import "./chunk-723TUEOK.js";
import {
  n as n2
} from "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import {
  P,
  d,
  v
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  i
} from "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/CatalogLayerList/CatalogLayerListViewModel.js
var m2 = { layerListMode: "layer-list-mode" };
var n3 = "hide";
var h = V.ofType(O2);
var p = class extends i.EventedAccessor {
  constructor(t3) {
    super(t3), this.catalogItems = new h(), this.checkPublishStatusEnabled = false, this.catalogLayer = null, this.listItemCreatedFunction = null, this.listModeDisabled = false, this.view = null;
  }
  initialize() {
    this.addHandles([d(() => [this.catalogLayer?.loaded, this.view?.ready], () => this._compileList(), P), v(() => this.catalogLayer?.dynamicGroupLayer.layers, "change", () => this._compileList()), d(() => [this.listItemCreatedFunction, this.checkPublishStatusEnabled, this.listModeDisabled], () => this._recompileList())]);
  }
  destroy() {
    this.view = null, this.catalogItems.removeAll();
  }
  get state() {
    const { view: t3, catalogLayer: e5 } = this;
    return t3?.ready && e5?.loaded ? "ready" : t3 && e5 ? "loading" : "disabled";
  }
  get totalItems() {
    return this.catalogItems.flatten((t3) => t3.children).length;
  }
  triggerAction(t3, e5) {
    t3 && !t3.disabled && this.emit("trigger-action", { action: t3, item: e5 });
  }
  _createListItem(t3) {
    const { view: e5, listItemCreatedFunction: s4, checkPublishStatusEnabled: i4, listModeDisabled: o } = this;
    return new O2({ checkPublishStatusEnabled: i4, listModeDisabled: o, layer: t3, listItemCreatedFunction: s4, view: e5 });
  }
  _removeAllItems() {
    this.catalogItems.removeAll();
  }
  _getViewableLayers(t3) {
    return t3 ? this.listModeDisabled ? t3 : t3.filter((t4) => u(t4) !== n3) : void 0;
  }
  _watchLayersListMode(t3) {
    this.removeHandles(m2.layerListMode), t3 && !this.listModeDisabled && this.addHandles(d(() => t3.filter((t4) => "listMode" in t4).map((t4) => t4.listMode).toArray(), () => this._compileList()), m2.layerListMode);
  }
  _compileList() {
    const { catalogLayer: t3 } = this;
    if (!t3?.loaded) return;
    const e5 = t3?.dynamicGroupLayer.layers;
    this._watchLayersListMode(e5);
    const s4 = this._getViewableLayers(e5);
    s4?.length ? (this._createNewItems(s4), this._removeItems(s4), this._sortItems(s4)) : this._removeAllItems();
  }
  _createNewItems(t3) {
    const { catalogItems: e5 } = this;
    t3.forEach((t4) => {
      e5.some((e6) => e6.layer === t4) || e5.add(this._createListItem(t4));
    });
  }
  _removeItems(t3) {
    const { catalogItems: e5 } = this, s4 = [];
    e5.forEach((e6) => {
      e6 && t3?.includes(e6.layer) || s4.push(e6);
    }), e5.removeMany(s4);
  }
  _sortItems(t3) {
    const { catalogItems: e5 } = this;
    e5.sort((e6, s4) => {
      const i4 = t3.indexOf(e6.layer), o = t3.indexOf(s4.layer);
      return i4 > o ? -1 : i4 < o ? 1 : 0;
    });
  }
  _recompileList() {
    this._removeAllItems(), this._compileList();
  }
};
r([m({ type: h })], p.prototype, "catalogItems", void 0), r([m()], p.prototype, "checkPublishStatusEnabled", void 0), r([m()], p.prototype, "catalogLayer", void 0), r([m()], p.prototype, "listItemCreatedFunction", void 0), r([m({ nonNullable: true })], p.prototype, "listModeDisabled", void 0), r([m({ readOnly: true })], p.prototype, "state", null), r([m()], p.prototype, "totalItems", null), r([m()], p.prototype, "view", void 0), p = r([a("esri.widgets.CatalogLayerList.CatalogLayerListViewModel")], p);
var y = p;

// node_modules/@arcgis/core/widgets/CatalogLayerList/CatalogLayerListVisibleElements.js
var s3 = class extends g {
  constructor() {
    super(...arguments), this.closeButton = false, this.collapseButton = false, this.errors = false, this.filter = false, this.flow = true, this.heading = false, this.statusIndicators = true, this.temporaryLayerIndicators = false;
  }
};
r([m({ type: Boolean, nonNullable: true })], s3.prototype, "closeButton", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "collapseButton", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "errors", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "filter", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "flow", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "heading", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "statusIndicators", void 0), r([m({ type: Boolean, nonNullable: true })], s3.prototype, "temporaryLayerIndicators", void 0), s3 = r([a("esri.widgets.CatalogLayerList.CatalogLayerListVisibleElements")], s3);
var l = s3;

// node_modules/@arcgis/core/widgets/CatalogLayerList/css.js
var t2 = "esri-catalog-layer-list";
var i3 = `${t2}__item`;
var e4 = { base: t2, actionMenu: `${t2}__action-menu`, actionGroup: `${t2}__action-group`, filterNoResults: `${t2}__filter-no-results`, item: i3, itemActive: `${i3}--active`, itemContentBottom: `${i3}-content-bottom`, itemMessage: `${i3}-message`, itemActionIcon: `${i3}-action-icon`, itemActionImage: `${i3}-action-image`, itemTemporaryIcon: `${i3}-temporary-icon`, itemTableIcon: `${i3}-table-icon`, statusIndicator: `${t2}__status-indicator`, publishing: `${t2}__publishing`, updating: `${t2}__updating`, connectionStatus: `${t2}__connection-status`, connectionStatusConnected: `${t2}__connection-status--connected`, visibleToggle: `${t2}__visible-toggle`, visibleIcon: `${t2}__visible-icon` };

// node_modules/@arcgis/core/widgets/CatalogLayerList.js
var M;
var O3 = V.ofType(O2);
var T2 = "nested";
var P2 = M = class extends n2.IdentifiableMixin(O) {
  constructor(e5, o) {
    super(e5, o), this._rootListEl = null, this._activeItem = null, this._tooltipReferenceMap = new s(), this._focusRootFlowItem = false, this._focusPanelFlowItem = false, this._focusLayerFlowItem = null, this._layerListMap = new s(), this._rootGroupUid = `operational-${this.uid}`, this._openedLayersController = null, this.catalogLayerList = null, this.catalogOptions = null, this.collapsed = false, this.filterPlaceholder = "", this.filterPredicate = null, this.filterText = "", this.headingLevel = 2, this.knowledgeGraphOptions = null, this.layerTablesEnabled = new V(["knowledge-graph"]), this.mapImageOptions = null, this.messages = null, this.messagesCommon = null, this.minFilterItems = i2, this.openedLayers = new V(), this.openedLayerLists = new V(), this.selectedItems = new O3(), this.selectionMode = "none", this.tableList = null, this.tileOptions = null, this.viewModel = new y(), this.visibilityAppearance = "default", this.visibleElements = new l(), this._onTablesOpen = (e6) => {
      this.onTablesOpen ? this.onTablesOpen(e6) : (this.openedLayers.push(e6.layer), this._focusLayerFlowItem = e6.layer?.uid);
    }, this._onCatalogOpen = (e6) => {
      this.onCatalogOpen ? this.onCatalogOpen(e6) : (this.openedLayers.push(e6.layer?.parent), this._focusLayerFlowItem = e6.layer?.uid);
    }, this._onPanelOpen = () => {
      this._focusPanelFlowItem = true;
    }, this._onTooltipReferenceChange = (e6, t3) => {
      t3 ? this._tooltipReferenceMap.set(e6, t3) : this._tooltipReferenceMap.delete(e6);
    }, this._onTriggerAction = (e6, t3) => {
      this.triggerAction(e6, t3);
    }, this._clearActiveItem = () => {
      this._activeItem = null;
    }, this._setActiveItem = (e6) => {
      if ("default" !== this.visibilityAppearance) return;
      const t3 = Array.from(e6.composedPath()).find((e7) => e7.classList?.contains(e4.item));
      this._activeItem = N(t3);
    };
  }
  initialize() {
    this.addHandles([v(() => this.openedLayers, "change", () => this._handleOpenedLayersChange(), P), v(() => this.viewModel.catalogItems, "change", () => s2(this.selectedItems), P), d(() => [this.filterPredicate, this._rootListEl], () => f(this._rootListEl, this.filterPredicate))]);
  }
  loadDependencies() {
    return c({ button: () => import("./calcite-button-FV2OB3GT.js"), flow: () => import("./calcite-flow-WJTOGM45.js"), "flow-item": () => import("./calcite-flow-item-VOEDA3NN.js"), list: () => import("./calcite-list-W42EHRHD.js"), notice: () => import("./calcite-notice-X7K5RWS6.js"), tooltip: () => import("./calcite-tooltip-ZEJ36TWO.js") });
  }
  destroy() {
    this._destroyOpenedLayerLists(), this._tooltipReferenceMap.clear();
  }
  get _filterEnabled() {
    return this.viewModel.totalItems >= this.minFilterItems && this.visibleElements.filter;
  }
  get _visibleItems() {
    return this.catalogItems?.filter((e5) => !e5.hidden && (this.visibleElements.errors || !e5.error));
  }
  get _openedPanelItems() {
    return this._visibleItems.flatten((e5) => e5.children).filter(({ hidden: e5, panel: t3 }) => !e5 && t3?.open && !t3.disabled && t3.flowEnabled);
  }
  get _renderedOpenLayerFlowItems() {
    const { openedLayers: e5 } = this;
    return e5.toArray().map((t3, o) => this._renderLayerFlowItem(t3, o === e5.length - 1));
  }
  get catalogItems() {
    return this.viewModel.catalogItems;
  }
  set catalogItems(e5) {
    this.viewModel.catalogItems = e5;
  }
  get catalogLayer() {
    return this.viewModel.catalogLayer;
  }
  set catalogLayer(e5) {
    this.viewModel.catalogLayer = e5;
  }
  get icon() {
    return "catalog-dataset";
  }
  set icon(e5) {
    this._overrideIfSome("icon", e5);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e5) {
    this._overrideIfSome("label", e5);
  }
  get listItemCreatedFunction() {
    return this.viewModel.listItemCreatedFunction;
  }
  set listItemCreatedFunction(e5) {
    this.viewModel.listItemCreatedFunction = e5;
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e5) {
    this.viewModel.view = e5;
  }
  triggerAction(e5, t3) {
    return this.viewModel.triggerAction(e5, t3);
  }
  render() {
    const e5 = this.viewModel?.state, { _visibleItems: t3 } = this, o = { [e2.hidden]: "loading" === e5, [e2.disabled]: "disabled" === e5 };
    return n("div", { class: this.classes(e4.base, e2.widget, e2.panel, o) }, t3?.length ? [this._renderItemTooltips(), this._renderItems()] : this._renderNoItems());
  }
  _createFlowList(e5, t3) {
    return __async(this, null, function* () {
      const { _layerListMap: o } = this, i4 = o.get(e5);
      if (i4) return i4;
      const s4 = "catalog" === e5.type ? yield this._createCatalogLayerList(e5) : yield this._createTableList(e5);
      return t3.aborted || o.set(e5, s4), s4;
    });
  }
  _handleOpenedLayersChange() {
    return __async(this, null, function* () {
      const { _layerListMap: e5, openedLayers: t3, openedLayerLists: o } = this;
      this._openedLayersController?.abort();
      const i4 = new AbortController(), { signal: s4 } = i4;
      this._openedLayersController = i4, e5.forEach((o2, i5) => {
        t3.includes(i5) || (o2.destroy(), e5.delete(i5));
      });
      const l2 = yield Promise.all(t3.map((e6) => this._createFlowList(e6, s4)));
      if (s4.aborted) return;
      o.removeAll(), o.addMany(l2);
      const r2 = o.at(-1);
      r2 ? "catalogLayer" in r2 ? (this._set("catalogLayerList", r2), this._set("tableList", null)) : (this._set("catalogLayerList", null), this._set("tableList", r2)) : (this._set("catalogLayerList", null), this._set("tableList", null));
    });
  }
  _destroyOpenedLayerLists() {
    this.openedLayerLists.destroyAll(), this.openedLayers.removeAll(), this._layerListMap.clear();
  }
  _renderItemTooltip(e5) {
    const { _tooltipReferenceMap: t3, messages: o } = this;
    return e5?.layer ? n("calcite-tooltip", { key: `tooltip-${e5.layer.uid}`, overlayPositioning: "fixed", referenceElement: t3.get(e5.layer.uid) }, o.layerIncompatibleTooltip) : null;
  }
  _renderItemTooltipNodes(e5) {
    return e5.incompatible ? this._renderItemTooltip(e5) : e5.children?.filter((e6) => !e6.hidden).toArray().map((e6) => this._renderItemTooltipNodes(e6));
  }
  _renderItemTooltips() {
    return this._visibleItems?.toArray().map((e5) => this._renderItemTooltipNodes(e5));
  }
  _renderNoItemsMessage() {
    return n("div", { slot: "message" }, this.messages.noItemsToDisplay);
  }
  _renderNoItems() {
    return n("div", { class: e4.itemMessage, key: "esri-layer-list__no-items" }, n("calcite-notice", { icon: "information", kind: "info", open: true, width: "full" }, this._renderNoItemsMessage()));
  }
  _renderPanelFlowItems() {
    const { _openedPanelItems: e5, openedLayers: t3 } = this;
    return e5.toArray().map(({ title: o, panel: i4 }, s4) => {
      const l2 = () => this._handlePanelFlowItemBack(i4);
      return n("calcite-flow-item", { afterCreate: this._focusPanelFlowItemNode, afterUpdate: this._focusPanelFlowItemNode, bind: this, description: o, heading: i4.title, headingLevel: this.headingLevel, key: `flow-panel-${i4.uid}`, selected: !t3.length && s4 === e5.length - 1, onCalciteFlowItemBack: (e6) => {
        e6.preventDefault(), l2();
      } }, i4.render(), n("calcite-button", { appearance: "transparent", onclick: l2, slot: "footer-actions", width: "full" }, this.messagesCommon.back));
    });
  }
  _handlePanelFlowItemBack(e5) {
    e5.open = false, this._focusRootFlowItem = true;
  }
  _focusRootFlowItemNode(e5) {
    this._focusRootFlowItem && (this._focusRootFlowItem = false, T(e5));
  }
  _focusPanelFlowItemNode(e5) {
    this._focusPanelFlowItem && (this._focusPanelFlowItem = false, T(e5));
  }
  _renderItems() {
    const { visible: e5, collapsed: t3, _visibleItems: o, _filterEnabled: i4, _rootGroupUid: s4, visibleElements: { closeButton: l2, collapseButton: r2, heading: a2, flow: n4 }, selectionMode: p2, filterText: d2, filterPlaceholder: c2, messages: h2, openedLayers: y2, _openedPanelItems: u2 } = this, g2 = [n("calcite-flow-item", { afterCreate: this._focusRootFlowItemNode, afterUpdate: this._focusRootFlowItemNode, bind: this, closable: l2, closed: !e5, collapsed: t3, collapsible: r2, heading: a2 ? h2.widgetLabel : void 0, headingLevel: this.headingLevel, key: "root-flow-item", selected: !y2.length && !u2.length, onCalciteFlowItemClose: () => this.visible = false }, n("calcite-list", { afterCreate: (e6) => {
      this._rootListEl = e6, e6.addEventListener("focusin", this._setActiveItem), e6.addEventListener("focusout", this._clearActiveItem);
    }, afterRemoved: (e6) => {
      this._rootListEl = null, e6.removeEventListener("focusin", this._setActiveItem), e6.removeEventListener("focusout", this._clearActiveItem);
    }, "data-layer-type": s4, displayMode: T2, filterEnabled: i4, filterPlaceholder: c2, filterProps: t, filterText: i4 ? d2 : "", group: s4, key: "root-list", label: h2.widgetLabel, onmouseleave: this._clearActiveItem, onmouseover: this._setActiveItem, selectionAppearance: "border", selectionMode: p2, onCalciteListChange: (e6) => this._handleCalciteListChange(e6), onCalciteListFilter: (e6) => this.filterText = e6.currentTarget?.filterText ?? "" }, o?.toArray().map((e6) => this._renderItem(e6)), o?.length && i4 ? n("div", { class: e4.filterNoResults, slot: "filter-no-results" }, n("calcite-notice", { kind: "info", open: true, width: "full" }, this._renderNoItemsMessage())) : null)), this._renderPanelFlowItems(), this._renderedOpenLayerFlowItems];
    return e5 ? n4 ? n("calcite-flow", { key: "root-flow" }, g2) : g2 : null;
  }
  _focusLayerFlowItemNode(e5) {
    this._focusLayerFlowItem === e5.dataset.layerUid && (this._focusLayerFlowItem = null, T(e5));
  }
  _renderLayerFlowItem(e5, t3) {
    const { messages: o, openedLayers: i4 } = this, s4 = e5.title || this.messages.untitledLayer;
    return n("calcite-flow-item", { afterCreate: this._focusLayerFlowItemNode, afterUpdate: this._focusLayerFlowItemNode, bind: this, "data-layer-uid": e5.uid, description: s4, heading: o["catalog" === e5.type ? "catalogLayers" : "tables"], headingLevel: this.headingLevel, key: `flow-layer-list-${e5.uid}`, selected: t3, onCalciteFlowItemBack: (e6) => {
      e6.preventDefault(), i4.pop();
      const t4 = i4.at(-1);
      t4 ? this._focusLayerFlowItem = t4.uid : this._focusRootFlowItem = true;
    } }, this._layerListMap.get(e5)?.render());
  }
  _createCatalogLayerList(e5) {
    return __async(this, null, function* () {
      const { headingLevel: t3, catalogOptions: o, view: i4, filterPlaceholder: s4, listItemCreatedFunction: l2, minFilterItems: r2, selectionMode: a2, visibilityAppearance: n4, onCatalogOpen: p2, onTablesOpen: d2 } = this;
      return new M(__spreadProps(__spreadValues({ headingLevel: t3, view: i4, filterPlaceholder: s4, listItemCreatedFunction: l2, minFilterItems: r2, selectionMode: a2, visibilityAppearance: n4 }, o), { catalogLayer: e5, onCatalogOpen: p2, onTablesOpen: d2 }));
    });
  }
  _getTableListParams(e5) {
    switch (e5.type) {
      case "knowledge-graph":
        return __spreadProps(__spreadValues({}, this.knowledgeGraphOptions), { tables: e5.tables });
      case "map-image":
        return __spreadProps(__spreadValues({}, this.mapImageOptions), { tables: e5.subtables });
      case "tile":
        return __spreadProps(__spreadValues({}, this.tileOptions), { tables: e5.subtables });
      default:
        return null;
    }
  }
  _createTableList(e5) {
    return __async(this, null, function* () {
      const { default: t3 } = yield import("./TableList-HVTMVBZ6.js"), { headingLevel: o, selectionMode: i4 } = this;
      return new t3(__spreadValues({ headingLevel: o, selectionMode: i4 }, this._getTableListParams(e5)));
    });
  }
  _renderItem(e5, t3, o) {
    return n(I, { activeItem: this._activeItem, css: e4, displayMode: T2, dragEnabled: false, item: e5, key: `layerListItem-${e5.layer?.uid}`, layerTablesEnabled: this.layerTablesEnabled, listModeDisabled: this.viewModel.listModeDisabled, messages: this.messages, messagesCommon: this.messagesCommon, parent: t3, parentTitles: o, rootGroupUid: this._rootGroupUid, selectedItems: this.selectedItems, selectionMode: this.selectionMode, visibilityAppearance: this.visibilityAppearance, visibleElements: this.visibleElements, onAction: this._onTriggerAction, onCatalogOpen: this._onCatalogOpen, onPanelOpen: this._onPanelOpen, onTablesOpen: this._onTablesOpen, onTooltipReferenceChange: this._onTooltipReferenceChange });
  }
  _handleCalciteListChange(e5) {
    const { selectionMode: t3, selectedItems: o } = this;
    if ("none" === t3) return;
    const i4 = e5.target.selectedItems.map((e6) => N(e6)).filter(Boolean);
    o.removeAll(), o.addMany(i4);
  }
};
r([m()], P2.prototype, "_rootListEl", void 0), r([m()], P2.prototype, "_activeItem", void 0), r([m()], P2.prototype, "_tooltipReferenceMap", void 0), r([m()], P2.prototype, "_focusRootFlowItem", void 0), r([m()], P2.prototype, "_focusPanelFlowItem", void 0), r([m()], P2.prototype, "_focusLayerFlowItem", void 0), r([m()], P2.prototype, "_layerListMap", void 0), r([m()], P2.prototype, "_filterEnabled", null), r([m()], P2.prototype, "_visibleItems", null), r([m()], P2.prototype, "_openedPanelItems", null), r([m()], P2.prototype, "_renderedOpenLayerFlowItems", null), r([m()], P2.prototype, "catalogItems", null), r([m()], P2.prototype, "catalogLayer", null), r([m({ readOnly: true })], P2.prototype, "catalogLayerList", void 0), r([m()], P2.prototype, "catalogOptions", void 0), r([m()], P2.prototype, "collapsed", void 0), r([m()], P2.prototype, "filterPlaceholder", void 0), r([m()], P2.prototype, "filterPredicate", void 0), r([m()], P2.prototype, "filterText", void 0), r([m()], P2.prototype, "headingLevel", void 0), r([m()], P2.prototype, "icon", null), r([m()], P2.prototype, "knowledgeGraphOptions", void 0), r([m()], P2.prototype, "label", null), r([m()], P2.prototype, "layerTablesEnabled", void 0), r([m()], P2.prototype, "listItemCreatedFunction", null), r([m()], P2.prototype, "mapImageOptions", void 0), r([m(), e("esri/widgets/CatalogLayerList/t9n/CatalogLayerList")], P2.prototype, "messages", void 0), r([m(), e("esri/t9n/common")], P2.prototype, "messagesCommon", void 0), r([m()], P2.prototype, "minFilterItems", void 0), r([m({ readOnly: true })], P2.prototype, "openedLayers", void 0), r([m({ readOnly: true })], P2.prototype, "openedLayerLists", void 0), r([m()], P2.prototype, "onCatalogOpen", void 0), r([m()], P2.prototype, "onTablesOpen", void 0), r([m({ type: O3 })], P2.prototype, "selectedItems", void 0), r([m()], P2.prototype, "selectionMode", void 0), r([m({ readOnly: true })], P2.prototype, "tableList", void 0), r([m()], P2.prototype, "tileOptions", void 0), r([m()], P2.prototype, "view", null), r([e3("trigger-action"), m({ type: y })], P2.prototype, "viewModel", void 0), r([m()], P2.prototype, "visibilityAppearance", void 0), r([m({ type: l, nonNullable: true })], P2.prototype, "visibleElements", void 0), P2 = M = r([a("esri.widgets.CatalogLayerList")], P2);
var A = P2;
export {
  A as default
};
//# sourceMappingURL=CatalogLayerList-YGQZHYPT.js.map
