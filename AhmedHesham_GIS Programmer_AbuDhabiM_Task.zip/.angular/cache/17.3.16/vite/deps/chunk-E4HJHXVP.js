// node_modules/@arcgis/core/views/2d/engine/webgl/shaderGraph/techniques/TechniqueType.js
var e;
!function(e2) {
  e2[e2.AnimatedMarker = 0] = "AnimatedMarker", e2[e2.Blend = 1] = "Blend", e2[e2.ComplexFill = 2] = "ComplexFill", e2[e2.ComplexOutlineFill = 3] = "ComplexOutlineFill", e2[e2.DotDensity = 4] = "DotDensity", e2[e2.Fill = 5] = "Fill", e2[e2.GradientFill = 6] = "GradientFill", e2[e2.GradientStroke = 7] = "GradientStroke", e2[e2.Grid = 8] = "Grid", e2[e2.Heatmap = 9] = "Heatmap", e2[e2.Label = 10] = "Label", e2[e2.Line = 11] = "Line", e2[e2.Magnifier = 12] = "Magnifier", e2[e2.Marker = 13] = "Marker", e2[e2.OutlineFill = 14] = "OutlineFill", e2[e2.Overlay = 15] = "Overlay", e2[e2.PatternFill = 16] = "PatternFill", e2[e2.PatternOutlineFill = 17] = "PatternOutlineFill", e2[e2.PieChart = 18] = "PieChart", e2[e2.Test = 19] = "Test", e2[e2.Text = 20] = "Text", e2[e2.TexturedLine = 21] = "TexturedLine", e2[e2.Bitmap = 22] = "Bitmap";
}(e || (e = {}));

export {
  e
};
//# sourceMappingURL=chunk-E4HJHXVP.js.map
