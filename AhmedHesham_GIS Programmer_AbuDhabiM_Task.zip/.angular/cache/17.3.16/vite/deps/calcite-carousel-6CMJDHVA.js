import {
  c
} from "./chunk-7VMBLUPM.js";
import "./chunk-PLIPJIB6.js";
import {
  o
} from "./chunk-TZZB63K4.js";
import "./chunk-RABWWKP5.js";
import {
  m,
  p
} from "./chunk-JP6NVURN.js";
import {
  m as m2
} from "./chunk-JNDPOHLO.js";
import "./chunk-3EHTPQND.js";
import "./chunk-4OCBID5S.js";
import {
  ref
} from "./chunk-LPETJQKI.js";
import {
  s
} from "./chunk-FJ5QMW6O.js";
import {
  b
} from "./chunk-U3H4S3UY.js";
import {
  Dt,
  gt,
  ut,
  xt
} from "./chunk-67TGT3ZY.js";
import {
  i
} from "./chunk-LPID7LVC.js";
import {
  Directive,
  LitElement2 as LitElement,
  PartType,
  S,
  createEvent,
  css,
  directive,
  getCommittedValue,
  html,
  insertPart,
  noChange,
  nothing,
  removePart,
  safeClassMap,
  setChildPartValue,
  setCommittedValue
} from "./chunk-NMBGL4CC.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/lit-html/development/directives/repeat.js
var generateMap = (list, start, end) => {
  const map = /* @__PURE__ */ new Map();
  for (let i2 = start; i2 <= end; i2++) {
    map.set(list[i2], i2);
  }
  return map;
};
var RepeatDirective = class extends Directive {
  constructor(partInfo) {
    super(partInfo);
    if (partInfo.type !== PartType.CHILD) {
      throw new Error("repeat() can only be used in text expressions");
    }
  }
  _getValuesAndKeys(items, keyFnOrTemplate, template) {
    let keyFn;
    if (template === void 0) {
      template = keyFnOrTemplate;
    } else if (keyFnOrTemplate !== void 0) {
      keyFn = keyFnOrTemplate;
    }
    const keys = [];
    const values = [];
    let index = 0;
    for (const item of items) {
      keys[index] = keyFn ? keyFn(item, index) : index;
      values[index] = template(item, index);
      index++;
    }
    return {
      values,
      keys
    };
  }
  render(items, keyFnOrTemplate, template) {
    return this._getValuesAndKeys(items, keyFnOrTemplate, template).values;
  }
  update(containerPart, [items, keyFnOrTemplate, template]) {
    const oldParts = getCommittedValue(containerPart);
    const { values: newValues, keys: newKeys } = this._getValuesAndKeys(items, keyFnOrTemplate, template);
    if (!Array.isArray(oldParts)) {
      this._itemKeys = newKeys;
      return newValues;
    }
    const oldKeys = this._itemKeys ??= [];
    const newParts = [];
    let newKeyToIndexMap;
    let oldKeyToIndexMap;
    let oldHead = 0;
    let oldTail = oldParts.length - 1;
    let newHead = 0;
    let newTail = newValues.length - 1;
    while (oldHead <= oldTail && newHead <= newTail) {
      if (oldParts[oldHead] === null) {
        oldHead++;
      } else if (oldParts[oldTail] === null) {
        oldTail--;
      } else if (oldKeys[oldHead] === newKeys[newHead]) {
        newParts[newHead] = setChildPartValue(oldParts[oldHead], newValues[newHead]);
        oldHead++;
        newHead++;
      } else if (oldKeys[oldTail] === newKeys[newTail]) {
        newParts[newTail] = setChildPartValue(oldParts[oldTail], newValues[newTail]);
        oldTail--;
        newTail--;
      } else if (oldKeys[oldHead] === newKeys[newTail]) {
        newParts[newTail] = setChildPartValue(oldParts[oldHead], newValues[newTail]);
        insertPart(containerPart, newParts[newTail + 1], oldParts[oldHead]);
        oldHead++;
        newTail--;
      } else if (oldKeys[oldTail] === newKeys[newHead]) {
        newParts[newHead] = setChildPartValue(oldParts[oldTail], newValues[newHead]);
        insertPart(containerPart, oldParts[oldHead], oldParts[oldTail]);
        oldTail--;
        newHead++;
      } else {
        if (newKeyToIndexMap === void 0) {
          newKeyToIndexMap = generateMap(newKeys, newHead, newTail);
          oldKeyToIndexMap = generateMap(oldKeys, oldHead, oldTail);
        }
        if (!newKeyToIndexMap.has(oldKeys[oldHead])) {
          removePart(oldParts[oldHead]);
          oldHead++;
        } else if (!newKeyToIndexMap.has(oldKeys[oldTail])) {
          removePart(oldParts[oldTail]);
          oldTail--;
        } else {
          const oldIndex = oldKeyToIndexMap.get(newKeys[newHead]);
          const oldPart = oldIndex !== void 0 ? oldParts[oldIndex] : null;
          if (oldPart === null) {
            const newPart = insertPart(containerPart, oldParts[oldHead]);
            setChildPartValue(newPart, newValues[newHead]);
            newParts[newHead] = newPart;
          } else {
            newParts[newHead] = setChildPartValue(oldPart, newValues[newHead]);
            insertPart(containerPart, oldParts[oldHead], oldPart);
            oldParts[oldIndex] = null;
          }
          newHead++;
        }
      }
    }
    while (newHead <= newTail) {
      const newPart = insertPart(containerPart, newParts[newTail + 1]);
      setChildPartValue(newPart, newValues[newHead]);
      newParts[newHead++] = newPart;
    }
    while (oldHead <= oldTail) {
      const oldPart = oldParts[oldHead++];
      if (oldPart !== null) {
        removePart(oldPart);
      }
    }
    this._itemKeys = newKeys;
    setCommittedValue(containerPart, newParts);
    return noChange;
  }
};
var repeat = directive(RepeatDirective);

// node_modules/@esri/calcite-components/dist/components/calcite-carousel/customElement.js
var V = 6e3;
var a = {
  container: "container",
  containerOverlaid: "container--overlaid",
  containerEdged: "container--edged",
  itemContainer: "item-container",
  itemContainerForward: "item-container--forward",
  itemContainerBackward: "item-container--backward",
  pagination: "pagination",
  paginationItems: "pagination-items",
  paginationItem: "pagination-item",
  paginationItemIndividual: "pagination-item--individual",
  paginationItemVisible: "pagination-item--visible",
  paginationItemOutOfRange: "pagination-item--out-of-range",
  paginationItemSelected: "pagination-item--selected",
  paginationItemRangeEdge: "pagination-item--range-edge",
  pageNext: "page-next",
  pagePrevious: "page-previous",
  autoplayControl: "autoplay-control",
  autoplayProgress: "autoplay-progress"
};
var p2 = {
  chevronLeft: "chevron-left",
  chevronRight: "chevron-right",
  inactive: "bullet-point",
  active: "bullet-point-large",
  pause: "pause-f",
  play: "play-f"
};
var g = {
  medium: 7,
  small: 5,
  xsmall: 3,
  xxsmall: 1
};
var G = css`:host([disabled]){cursor:default;-webkit-user-select:none;user-select:none;opacity:var(--calcite-opacity-disabled)}:host([disabled]) *,:host([disabled]) ::slotted(*){pointer-events:none}:host{display:flex;inline-size:100%;--calcite-internal-internal-carousel-item-space: 1.5rem;--calcite-internal-internal-carousel-item-space-wide: 3.5rem;--calcite-internal-internal-carousel-item-background-color: var( --calcite-internal-carousel-item-background-color, var(--calcite-color-foreground-1) );--calcite-internal-internal-carousel-item-background-color-hover: var( --calcite-internal-carousel-item-background-color-hover, var(--calcite-color-foreground-2) );--calcite-internal-internal-carousel-item-background-color-active: var( --calcite-internal-carousel-item-background-color-active, var(--calcite-color-foreground-2) );--calcite-internal-internal-carousel-item-background-color-selected: var( --calcite-internal-carousel-item-background-color-selected, var(--calcite-color-foreground-1) );--calcite-internal-internal-carousel-item-icon-color-hover: var( --calcite-internal-carousel-item-icon-color-hover, var(--calcite-color-text-1) );--calcite-internal-internal-carousel-item-icon-color: var( --calcite-internal-carousel-item-icon-color, var(--calcite-color-border-1) );--calcite-internal-internal-carousel-item-icon-color-selected: var( --calcite-internal-carousel-item-icon-color-selected, var(--calcite-color-brand) );--calcite-internal-internal-carousel-control-color-hover: var( --calcite-internal-carousel-control-color-hover, var(--calcite-color-text-1) );--calcite-internal-internal-carousel-control-color: var( --calcite-internal-carousel-item-icon-color, var(--calcite-color-text-3) );--calcite-internal-internal-carousel-autoplay-progress-background-color: var( --calcite-internal-carousel-autoplay-progress-background-color, var(--calcite-color-border-3) );--calcite-internal-internal-carousel-autoplay-progress-fill-color: var( --calcite-internal-carousel-autoplay-progress-fill-color, var(--calcite-color-brand) )}.container{position:relative;display:flex;inline-size:100%;flex-direction:column;overflow:hidden;font-size:var(--calcite-font-size--1);line-height:1rem;color:var(--calcite-color-text-2);outline-color:transparent}.container:focus{outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(-2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))))}.container--edged:not(.container--overlaid){padding-inline:var(--calcite-internal-internal-carousel-item-space-wide);inline-size:calc(100% - var(--calcite-internal-internal-carousel-item-space-wide) * 2)}.item-container{display:flex;flex:1 1 auto;align-items:flex-start;justify-content:center;overflow:auto;padding:.25rem;animation-name:none;animation-duration:var(--calcite-animation-timing)}.container--overlaid .item-container{padding:0}.item-container--forward{animation-name:item-forward}.item-container--backward{animation-name:item-backward}calcite-carousel-item:not([selected]){opacity:0}.pagination{margin:.75rem;display:flex;flex-direction:row;align-items:center;justify-content:center;inline-size:auto}.pagination-items{display:flex;flex-direction:row;align-items:center}.container--overlaid .pagination{position:absolute}.pagination-item.page-next,.pagination-item.page-previous{color:var(--calcite-internal-internal-carousel-control-color)}.pagination-item.page-next:hover,.pagination-item.page-previous:hover{color:var(--calcite-internal-internal-carousel-control-color-hover)}.container--edged .page-next,.container--edged .page-previous{block-size:3rem;inline-size:3rem;position:absolute;inset-block-start:50%;transform:translateY(-50%)}.container--edged .page-next{inset-inline-end:0}.container--edged .page-previous{inset-inline-start:0}.container--overlaid .pagination{inset-block-start:unset;inset-block-end:0;inset-inline:0}.pagination-item.autoplay-control{position:relative;color:var(--calcite-internal-internal-carousel-control-color);--calcite-progress-fill-color: var(--calcite-internal-internal-carousel-autoplay-progress-fill-color);--calcite-progress-background-color: var(--calcite-internal-internal-carousel-autoplay-progress-background-color)}.autoplay-control:focus .autoplay-progress{inset-block-end:4px;inset-inline:2px;inline-size:calc(100% - 4px)}.autoplay-progress{position:absolute;inset-block-end:2px;inset-inline:0;inline-size:100%}.pagination-item{margin:0;block-size:2rem;inline-size:2rem;cursor:pointer;align-items:center;border-style:none;background-color:transparent;outline-color:transparent;transition-property:background-color,block-size,border-color,box-shadow,color,inset-block-end,inset-block-start,inset-inline-end,inset-inline-start,inset-size,opacity,outline-color,transform;transition-duration:var(--calcite-animation-timing);transition-timing-function:ease-in-out;-webkit-appearance:none;display:flex;align-content:center;justify-content:center;--calcite-color-foreground-1: var(--calcite-internal-internal-carousel-item-background-color);color:var(--calcite-internal-internal-carousel-item-icon-color)}.pagination-item:hover{background-color:var(--calcite-internal-internal-carousel-item-background-color-hover);color:var(--calcite-internal-internal-carousel-item-icon-color-hover)}.pagination-item:focus{background-color:var(--calcite-internal-internal-carousel-item-background-color-active);outline:2px solid var(--calcite-color-focus, var(--calcite-ui-focus-color, var(--calcite-color-brand)));outline-offset:calc(-2px*(1 - (2*clamp(0,var(--calcite-offset-invert-focus),1))))}.pagination-item:active{background-color:var(--calcite-internal-internal-carousel-item-background-color-active);color:var(--calcite-internal-internal-carousel-item-icon-color-hover)}.pagination-item calcite-icon{color:inherit;pointer-events:none}.pagination-item.pagination-item--selected{--calcite-color-foreground-1: var(--calcite-internal-internal-carousel-item-background-color-selected);--calcite-color-foreground-3: var(--calcite-internal-internal-carousel-item-background-color-selected);color:var(--calcite-internal-internal-carousel-item-icon-color-selected)}.pagination-item--individual{pointer-events:none;inline-size:0px;padding:0;opacity:0;visibility:hidden;transition:var(--calcite-animation-timing) ease-in-out inline-size,var(--calcite-animation-timing) ease-in-out padding,var(--calcite-animation-timing) ease-in-out opacity}.pagination-item--individual.pagination-item--visible{pointer-events:auto;inline-size:2rem;opacity:1;visibility:visible}.pagination-item--range-edge calcite-icon{scale:.75;transition:var(--calcite-animation-timing) ease-in-out scale}.container--overlaid .pagination-item{background-color:var(--calcite-internal-internal-carousel-item-background-color)}.container--overlaid .pagination-item:hover{background-color:var(--calcite-internal-internal-carousel-item-background-color-hover)}.container--overlaid .pagination-item:focus{background-color:var(--calcite-internal-internal-carousel-item-background-color-active)}.container--overlaid .pagination-item:active{background-color:var(--calcite-internal-internal-carousel-item-background-color-active)}@keyframes item-forward{0%{transform:translate3d(100px,0,0)}to{transform:translateZ(0)}}@keyframes item-backward{0%{transform:translate3d(-100px,0,0)}to{transform:translateZ(0)}}:host([disabled]) ::slotted([calcite-hydrated][disabled]),:host([disabled]) [calcite-hydrated][disabled]{opacity:1}.interaction-container{display:contents}:host([hidden]){display:none}[hidden]{display:none}`;
var Z = class extends LitElement {
  constructor() {
    super(...arguments), this.autoplayHandler = () => {
      this.clearIntervals(), this.slideDurationInterval = setInterval(this.timer, this.autoplayDuration / 100);
    }, this.containerId = `calcite-carousel-container-${i()}`, this.resizeHandler = ({ contentRect: { width: e } }) => {
      this.setMaxItemsToBreakpoint(e);
    }, this.resizeObserver = b("resize", (e) => e.forEach(this.resizeHandler)), this.slideDurationInterval = null, this.slideInterval = null, this.timer = () => {
      let e = this.slideDurationRemaining;
      (!this.suspendedDueToFocus && !this.suspendedDueToHover || this.userPreventsSuspend) && (e <= 0.01 ? (e = 1, this.direction = "forward", this.nextItem(false)) : e = e - 0.01), e > 0 && (this.slideDurationRemaining = e);
    }, this.direction = "standby", this.items = [], this.maxItems = g.xxsmall, this.playing = false, this.slideDurationRemaining = 1, this.suspendedDueToFocus = false, this.suspendedDueToHover = false, this.suspendedSlideDurationRemaining = 1, this.userPreventsSuspend = false, this.arrowType = "inline", this.autoplay = false, this.autoplayDuration = V, this.controlOverlay = false, this.disabled = false, this.messages = s(), this.calciteCarouselChange = createEvent({ cancelable: false }), this.calciteCarouselPause = createEvent({ cancelable: false }), this.calciteCarouselPlay = createEvent({ cancelable: false }), this.calciteCarouselResume = createEvent({ cancelable: false }), this.calciteCarouselStop = createEvent({ cancelable: false });
  }
  static {
    this.properties = { direction: 16, items: 16, maxItems: 16, playing: 16, selectedIndex: 16, slideDurationRemaining: 16, suspendedDueToFocus: 16, suspendedDueToHover: 16, suspendedSlideDurationRemaining: 16, userPreventsSuspend: 16, arrowType: 3, autoplay: 3, autoplayDuration: 11, controlOverlay: 7, disabled: 7, label: 1, messageOverrides: 0, paused: 5, selectedItem: 0 };
  }
  static {
    this.styles = G;
  }
  // #endregion
  // #region Public Methods
  /** Play the carousel. If `autoplay` is not enabled (initialized either to `true` or `"paused"`), these methods will have no effect. */
  play() {
    return __async(this, null, function* () {
      this.playing || this.autoplay !== "" && !this.autoplay && this.autoplay !== "paused" || this.handlePlay(true);
    });
  }
  /** Sets focus on the component. */
  setFocus() {
    return __async(this, null, function* () {
      yield m2(this), this.container?.focus();
    });
  }
  /** Stop the carousel. If `autoplay` is not enabled (initialized either to `true` or `"paused"`), these methods will have no effect. */
  stop() {
    return __async(this, null, function* () {
      this.playing && this.handlePause(true);
    });
  }
  // #endregion
  // #region Lifecycle
  connectedCallback() {
    super.connectedCallback(), this.resizeObserver?.observe(this.el);
  }
  load() {
    return __async(this, null, function* () {
      (this.autoplay === "" || this.autoplay) && this.autoplay !== "paused" ? this.handlePlay(false) : this.autoplay === "paused" && (this.paused = true);
    });
  }
  willUpdate(e) {
    e.has("autoplay") && this.hasUpdated && this.autoplayWatcher(this.autoplay), e.has("direction") && (this.hasUpdated || this.direction !== "standby") && this.directionWatcher(this.direction), e.has("playing") && (this.hasUpdated || this.playing !== false) && (this.paused = !this.playing), (e.has("suspendedDueToFocus") && (this.hasUpdated || this.suspendedDueToFocus !== false) || e.has("suspendedDueToHover") && (this.hasUpdated || this.suspendedDueToHover !== false)) && this.suspendWatcher();
  }
  updated() {
    m(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.clearIntervals(), this.resizeObserver?.disconnect();
  }
  // #endregion
  // #region Private Methods
  autoplayWatcher(e) {
    e || this.handlePause(false);
  }
  directionWatcher(e) {
    return __async(this, null, function* () {
      e !== "standby" && (yield Dt(this.itemContainer, e === "forward" ? "item-forward" : "item-backward"), this.direction = "standby");
    });
  }
  suspendWatcher() {
    !this.suspendedDueToFocus && !this.suspendedDueToHover ? this.suspendEnd() : this.suspendStart();
  }
  setMaxItemsToBreakpoint(e) {
    if (e) {
      if (e >= c.width.small) {
        this.maxItems = g.medium;
        return;
      }
      if (e >= c.width.xsmall) {
        this.maxItems = g.small;
        return;
      }
      if (e >= c.width.xxsmall) {
        this.maxItems = g.xsmall;
        return;
      }
      this.maxItems = g.xxsmall;
    }
  }
  clearIntervals() {
    clearInterval(this.slideDurationInterval), clearInterval(this.slideInterval);
  }
  nextItem(e) {
    this.playing && e && (this.playing = false);
    const t = o(this.selectedIndex + 1, this.items.length);
    this.setSelectedItem(t, e);
  }
  previousItem() {
    this.playing = false;
    const e = o(Math.max(this.selectedIndex - 1, -1), this.items.length);
    this.setSelectedItem(e, true);
  }
  handlePlay(e) {
    this.playing = true, this.autoplayHandler(), this.slideInterval = setInterval(this.autoplayHandler, this.autoplayDuration), e && this.calciteCarouselPlay.emit();
  }
  handlePause(e) {
    this.playing = false, this.clearIntervals(), this.slideDurationRemaining = 1, this.suspendedSlideDurationRemaining = 1, e && this.calciteCarouselStop.emit();
  }
  suspendStart() {
    this.suspendedSlideDurationRemaining = this.slideDurationRemaining;
  }
  suspendEnd() {
    this.slideDurationRemaining = this.suspendedSlideDurationRemaining;
  }
  handleSlotChange(e) {
    const t = ut(e);
    if (t.length < 1)
      return;
    const i2 = t.findIndex((s2) => s2.selected), r = i2 > -1 ? i2 : 0;
    this.items = t, this.setSelectedItem(r, false);
  }
  setSelectedItem(e, t) {
    const i2 = this.selectedIndex;
    this.items.forEach((r, s2) => {
      const o2 = e === s2;
      r.selected = o2, o2 && (this.selectedItem = r, this.selectedIndex = s2);
    }), t && (this.playing = false, i2 !== this.selectedIndex && this.calciteCarouselChange.emit());
  }
  handleArrowClick(e) {
    const t = e.target.dataset.direction;
    this.playing && this.handlePause(true), t === "next" ? (this.direction = "forward", this.nextItem(true)) : t === "previous" && (this.direction = "backward", this.previousItem());
  }
  handleItemSelection(e) {
    const t = e.target, i2 = parseInt(t.dataset.index);
    i2 !== this.selectedIndex && (this.playing && this.handlePause(true), this.direction = i2 > this.selectedIndex ? "forward" : "backward", this.setSelectedItem(i2, true));
  }
  toggleRotation() {
    this.userPreventsSuspend = true, this.playing ? this.handlePause(true) : this.handlePlay(true);
  }
  handleFocusIn() {
    const e = this.playing;
    e && (this.suspendedDueToFocus = true), (!this.suspendedDueToFocus || !this.suspendedDueToHover) && e && this.calciteCarouselPause.emit();
  }
  handleMouseIn() {
    const e = this.playing;
    e && (this.suspendedDueToHover = true), (!this.suspendedDueToFocus || !this.suspendedDueToHover) && e && this.calciteCarouselPause.emit();
  }
  handleMouseOut(e) {
    const t = !this.el.contains(e.relatedTarget), i2 = this.playing;
    t && i2 && (this.suspendedDueToHover = false), t && i2 && !this.suspendedDueToFocus && (this.userPreventsSuspend = false, this.calciteCarouselResume.emit());
  }
  handleFocusOut(e) {
    const t = !e.composedPath().includes(e.relatedTarget), i2 = this.playing;
    t && i2 && (this.suspendedDueToFocus = false), t && i2 && !this.suspendedDueToHover && (this.userPreventsSuspend = false, this.calciteCarouselResume.emit());
  }
  containerKeyDownHandler(e) {
    if (e.target !== this.container)
      return;
    const t = this.items.length - 1;
    switch (e.key) {
      case " ":
      case "Enter":
        e.preventDefault(), (this.autoplay === "" || this.autoplay || this.autoplay === "paused") && this.toggleRotation();
        break;
      case "ArrowRight":
        e.preventDefault(), this.direction = "forward", this.nextItem(true);
        break;
      case "ArrowLeft":
        e.preventDefault(), this.direction = "backward", this.previousItem();
        break;
      case "Home":
        if (e.preventDefault(), this.selectedIndex === 0)
          return;
        this.direction = "backward", this.setSelectedItem(0, true);
        break;
      case "End":
        if (e.preventDefault(), this.selectedIndex === t)
          return;
        this.direction = "forward", this.setSelectedItem(t, true);
        break;
    }
  }
  tabListKeyDownHandler(e) {
    const t = Array(...this.tabList.querySelectorAll(`button:not(.${a.paginationItemOutOfRange})`)), i2 = e.target;
    switch (e.key) {
      case "ArrowRight":
        xt(t, i2, "next");
        break;
      case "ArrowLeft":
        xt(t, i2, "previous");
        break;
      case "Home":
        e.preventDefault(), xt(t, i2, "first");
        break;
      case "End":
        e.preventDefault(), xt(t, i2, "last");
        break;
    }
  }
  storeTabListRef(e) {
    this.tabList = e;
  }
  storeContainerRef(e) {
    this.container = e;
  }
  storeItemContainerRef(e) {
    this.itemContainer = e;
  }
  // #endregion
  // #region Rendering
  renderRotationControl() {
    const e = this.playing ? this.messages.pause : this.messages.play, t = this.slideDurationRemaining * 100;
    return html`<button .ariaLabel=${e} class=${safeClassMap({
      [a.paginationItem]: true,
      [a.autoplayControl]: true
    })} @click=${this.toggleRotation} title=${e ?? nothing}><calcite-icon .icon=${this.playing ? p2.pause : p2.play} scale=s></calcite-icon>${this.playing && html`<calcite-progress class=${safeClassMap(a.autoplayProgress)} .label=${this.messages.carouselItemProgress} .value=${t}></calcite-progress>` || ""}</button>`;
  }
  renderPaginationArea() {
    return html`<div class=${safeClassMap({
      [a.pagination]: true,
      [a.containerOverlaid]: this.controlOverlay
    })} @keydown=${this.tabListKeyDownHandler} ${ref(this.storeTabListRef)}>${(this.playing || this.autoplay === "" || this.autoplay || this.autoplay === "paused") && this.renderRotationControl() || ""}${this.arrowType === "inline" && this.renderArrow("previous") || ""}${this.renderPaginationItems()}${this.arrowType === "inline" && this.renderArrow("next") || ""}</div>`;
  }
  renderPaginationItems() {
    const { selectedIndex: e, maxItems: t, items: i2, label: r, handleItemSelection: s2 } = this;
    return html`<div .ariaLabel=${r} class=${safeClassMap(a.paginationItems)} role=tablist>${repeat(i2, (o2) => o2.id, (o2, n) => {
      const h = i2.length, u = n === e, S2 = n === 0, P = n === h - 1, I = h - t - 1, f = e < t, k = e >= I, x = f ? 0 : e - Math.floor(t / 2), T = k ? h : x + t, w = f ? 0 : k ? I : x, D = f ? t + 1 : T, z = !S2 && !P && !u && (n === w - 1 || n === D), $ = u || n <= D && n >= w - 1, C = h - 1 <= t, O = u ? p2.active : p2.inactive;
      return html`<button aria-controls=${(u ? void 0 : o2.id) ?? nothing} .ariaSelected=${u} class=${safeClassMap({
        [a.paginationItem]: true,
        [a.paginationItemIndividual]: true,
        [a.paginationItemSelected]: u,
        [a.paginationItemRangeEdge]: h - 1 > t && z,
        [a.paginationItemOutOfRange]: !(C || $),
        [a.paginationItemVisible]: C || $
      })} data-index=${n ?? nothing} @click=${s2} role=tab title=${o2.label ?? nothing}><calcite-icon .icon=${O} scale=l></calcite-icon></button>`;
    })}</div>`;
  }
  renderArrow(e) {
    const t = e === "previous", i2 = gt(this.el), r = this.arrowType === "edge" ? "m" : "s", s2 = t ? a.pagePrevious : a.pageNext, o2 = t ? this.messages.previous : this.messages.next, n = t ? p2.chevronLeft : p2.chevronRight;
    return html`<button aria-controls=${this.containerId ?? nothing} class=${safeClassMap({ [a.paginationItem]: true, [s2]: true })} data-direction=${e ?? nothing} @click=${this.handleArrowClick} title=${o2 ?? nothing}><calcite-icon .flipRtl=${i2 === "rtl"} .icon=${n} .scale=${r}></calcite-icon></button>`;
  }
  render() {
    const { direction: e } = this;
    return p({ disabled: this.disabled, children: html`<div .ariaLabel=${this.label} .ariaLive=${this.playing ? "off" : "polite"} .ariaRoleDescription=${this.messages.carousel} class=${safeClassMap({
      [a.container]: true,
      [a.containerOverlaid]: this.controlOverlay,
      [a.containerEdged]: this.arrowType === "edge"
    })} @focusin=${this.handleFocusIn} @focusout=${this.handleFocusOut} @keydown=${this.containerKeyDownHandler} @mouseenter=${this.handleMouseIn} @mouseleave=${this.handleMouseOut} role=group tabindex=0 ${ref(this.storeContainerRef)}><section class=${safeClassMap({
      [a.itemContainer]: true,
      [a.itemContainerForward]: e === "forward",
      [a.itemContainerBackward]: e === "backward"
    })} id=${this.containerId ?? nothing} ${ref(this.storeItemContainerRef)}><slot @slotchange=${this.handleSlotChange}></slot></section>${this.items.length > 1 && this.renderPaginationArea() || ""}${this.arrowType === "edge" && this.renderArrow("previous") || ""}${this.arrowType === "edge" && this.renderArrow("next") || ""}</div>` });
  }
};
S("calcite-carousel", Z);
export {
  Z as Carousel
};
/*! Bundled license information:

lit-html/development/directives/repeat.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@esri/calcite-components/dist/components/calcite-carousel/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=calcite-carousel-6CMJDHVA.js.map
