// node_modules/@esri/calcite-components/dist/chunks/resources4.js
var n = {
  brand: "lightbulb",
  danger: "exclamationMarkTriangle",
  info: "information",
  success: "checkCircle",
  warning: "exclamationMarkTriangle"
};

export {
  n
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/resources4.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-GE4XPRDF.js.map
