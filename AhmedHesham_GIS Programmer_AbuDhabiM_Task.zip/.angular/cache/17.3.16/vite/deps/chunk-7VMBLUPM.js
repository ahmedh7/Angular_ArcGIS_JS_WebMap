import {
  a,
  c,
  i,
  t
} from "./chunk-PLIPJIB6.js";

// node_modules/@esri/calcite-components/dist/chunks/responsive.js
var c2 = {
  width: {
    medium: a2(t.max),
    small: a2(i.max),
    xsmall: a2(a.max),
    xxsmall: a2(c.max)
  }
};
function a2(i2) {
  return parseInt(i2);
}

export {
  c2 as c
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/responsive.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-7VMBLUPM.js.map
