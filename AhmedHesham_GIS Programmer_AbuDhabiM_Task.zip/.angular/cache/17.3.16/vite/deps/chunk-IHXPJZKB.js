import {
  a as a2
} from "./chunk-J3AJBXLW.js";
import {
  o
} from "./chunk-TAT7XC7M.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";

// node_modules/@arcgis/core/layers/support/FeatureTemplate.js
var l = new o({ esriFeatureEditToolAutoCompletePolygon: "auto-complete-polygon", esriFeatureEditToolCircle: "circle", esriFeatureEditToolEllipse: "ellipse", esriFeatureEditToolFreehand: "freehand", esriFeatureEditToolLine: "line", esriFeatureEditToolNone: "none", esriFeatureEditToolPoint: "point", esriFeatureEditToolPolygon: "polygon", esriFeatureEditToolRectangle: "rectangle", esriFeatureEditToolArrow: "arrow", esriFeatureEditToolTriangle: "triangle", esriFeatureEditToolLeftArrow: "left-arrow", esriFeatureEditToolRightArrow: "right-arrow", esriFeatureEditToolUpArrow: "up-arrow", esriFeatureEditToolDownArrow: "down-arrow" });
var a3 = class extends a2.ClonableMixin(S) {
  constructor(o2) {
    super(o2), this.name = null, this.description = null, this.drawingTool = null, this.prototype = null, this.thumbnail = null;
  }
};
r([m({ json: { write: true } })], a3.prototype, "name", void 0), r([m({ json: { write: true } })], a3.prototype, "description", void 0), r([m({ json: { read: l.read, write: l.write } })], a3.prototype, "drawingTool", void 0), r([m({ json: { write: true } })], a3.prototype, "prototype", void 0), r([m({ json: { write: true } })], a3.prototype, "thumbnail", void 0), a3 = r([a("esri.layers.support.FeatureTemplate")], a3);
var n = a3;

export {
  n
};
//# sourceMappingURL=chunk-IHXPJZKB.js.map
