import {
  i,
  t
} from "./chunk-7T344KIW.js";
import {
  s
} from "./chunk-LAT3FERZ.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/support/LayerLoadContext.js
var e = class {
  constructor() {
    this._serviceMetadatas = /* @__PURE__ */ new Map(), this._itemDatas = /* @__PURE__ */ new Map();
  }
  fetchServiceMetadata(e2, a2) {
    return __async(this, null, function* () {
      const s3 = this._serviceMetadatas.get(e2);
      if (s3) return s3;
      const r = yield t(e2, a2);
      return this._serviceMetadatas.set(e2, r), r;
    });
  }
  fetchItemData(t3) {
    return __async(this, null, function* () {
      const { id: e2 } = t3;
      if (!e2) return null;
      const { _itemDatas: a2 } = this;
      if (a2.has(e2)) return a2.get(e2);
      const s3 = yield t3.fetchData();
      return a2.set(e2, s3), s3;
    });
  }
  fetchCustomParameters(t3, e2) {
    return __async(this, null, function* () {
      const a2 = yield this.fetchItemData(t3);
      return a2 && "object" == typeof a2 && (e2 ? e2(a2) : a2.customParameters) || null;
    });
  }
};

// node_modules/@arcgis/core/portal/support/loadUtils.js
function t2(e2) {
  const t3 = { id: e2.id, name: e2.name }, a2 = i(e2.type);
  return "FeatureLayer" !== a2 && (t3.layerType = a2), t3;
}
function a(e2, r, a2) {
  return __async(this, null, function* () {
    if (null == e2?.layers || null == e2?.tables) {
      const s3 = yield a2.fetchServiceMetadata(r, { customParameters: l(e2)?.customParameters });
      (e2 = e2 || {}).layers = e2.layers || s3?.layers?.map(t2), e2.tables = e2.tables || s3?.tables?.map(t2);
    }
    return e2;
  });
}
function l(e2) {
  if (!e2) return null;
  const { layers: r, tables: t3 } = e2;
  return r?.length ? r[0] : t3?.length ? t3[0] : null;
}
function s2(e2, r) {
  if (null == r) return null;
  return [...e2.layers || [], ...e2.tables || []].find((e3) => e3.id === r);
}
function n(e2, r) {
  return [...e2.layers || [], ...e2.tables || []].filter(({ layerType: e3 }) => e3 ? r.includes(e3) : r.includes("ArcGISFeatureLayer"));
}
function u(e2) {
  return (e2?.layers?.length ?? 0) + (e2?.tables?.length ?? 0);
}
function c(e2) {
  switch (e2) {
    case "catalog":
      return ["CatalogLayer"];
    case "feature":
      return ["ArcGISFeatureLayer"];
    case "oriented-imagery":
      return ["OrientedImageryLayer"];
    case "subtype-group":
      return ["SubtypeGroupLayer", "SubtypeGroupTable"];
  }
  return null;
}
function i2(e2) {
  switch (e2) {
    case "CatalogLayer":
      return "CatalogLayer";
    case "OrientedImageryLayer":
      return "OrientedImageryLayer";
    case "SubtypeGroupLayer":
    case "SubtypeGroupTable":
      return "SubtypeGroupLayer";
  }
  return "FeatureLayer";
}
function o(r, a2, s3) {
  return __async(this, null, function* () {
    if (!r?.url) return a2 ?? {};
    if (a2 ??= {}, !a2.layers) {
      const e2 = yield s3.fetchServiceMetadata(r.url);
      a2.layers = e2.layers?.map(t2);
    }
    const { serverUrl: n2, portalItem: u2 } = yield s(r.url, { sceneLayerItem: r, customParameters: l(a2)?.customParameters }).catch(() => ({ serverUrl: null, portalItem: null }));
    if (null == n2) return a2.tables = [], a2;
    if (!a2.tables && u2) {
      const e2 = yield u2.fetchData().catch(() => null);
      if (e2?.tables) a2.tables = e2.tables.map(t2);
      else {
        const r2 = yield s3.fetchServiceMetadata(n2, { customParameters: l(e2)?.customParameters }).catch(() => null);
        a2.tables = r2?.tables?.map(t2);
      }
    }
    if (a2.tables) for (const e2 of a2.tables) e2.url = `${n2}/${e2.id}`;
    return a2;
  });
}

export {
  e,
  t2 as t,
  a,
  l,
  s2 as s,
  n,
  u,
  c,
  i2 as i,
  o
};
//# sourceMappingURL=chunk-GMENKQYM.js.map
