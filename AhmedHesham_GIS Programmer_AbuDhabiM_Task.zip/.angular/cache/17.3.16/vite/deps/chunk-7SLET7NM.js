import {
  o
} from "./chunk-TAT7XC7M.js";

// node_modules/@arcgis/core/layers/support/fieldType.js
var i = new o({ esriFieldTypeSmallInteger: "small-integer", esriFieldTypeInteger: "integer", esriFieldTypeSingle: "single", esriFieldTypeDouble: "double", esriFieldTypeLong: "long", esriFieldTypeString: "string", esriFieldTypeDate: "date", esriFieldTypeOID: "oid", esriFieldTypeGeometry: "geometry", esriFieldTypeBlob: "blob", esriFieldTypeRaster: "raster", esriFieldTypeGUID: "guid", esriFieldTypeGlobalID: "global-id", esriFieldTypeXML: "xml", esriFieldTypeBigInteger: "big-integer", esriFieldTypeDateOnly: "date-only", esriFieldTypeTimeOnly: "time-only", esriFieldTypeTimestampOffset: "timestamp-offset" });

export {
  i
};
//# sourceMappingURL=chunk-7SLET7NM.js.map
