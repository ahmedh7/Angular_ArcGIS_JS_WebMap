import {
  has
} from "./chunk-D5RIMQ7U.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/effects/geometry/olidUtils.js
function e() {
  return !!has("enable-feature:objectAndLayerId-rendering");
}

export {
  e
};
//# sourceMappingURL=chunk-DJYXUXWN.js.map
