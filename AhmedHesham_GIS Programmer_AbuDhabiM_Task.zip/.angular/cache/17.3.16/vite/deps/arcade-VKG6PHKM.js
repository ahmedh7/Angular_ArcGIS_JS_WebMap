import {
  t
} from "./chunk-J52V5ETQ.js";
import {
  i,
  r
} from "./chunk-32NTBLRT.js";
import {
  Ye
} from "./chunk-TBHNOGW4.js";
import "./chunk-3YJA3KQW.js";
import "./chunk-NUQRT7CB.js";
import "./chunk-RF3IXNCL.js";
import "./chunk-XKCP3CZJ.js";
import "./chunk-6DIVLKMU.js";
import "./chunk-TVC5ICZ6.js";
import "./chunk-VY7ME65R.js";
import "./chunk-ZL7AFA5U.js";
import "./chunk-DWHZIVJ2.js";
import "./chunk-NNQGBMH4.js";
import "./chunk-KZONSPL6.js";
import "./chunk-TATHLUT3.js";
import "./chunk-Y5JUDCDZ.js";
import "./chunk-OR23LWBA.js";
import "./chunk-BOHQCAJM.js";
import "./chunk-KK6BHWJD.js";
import "./chunk-O27NRO2R.js";
import "./chunk-ZFKMGP62.js";
import "./chunk-IHXPJZKB.js";
import "./chunk-EYGV7DRM.js";
import "./chunk-KJXL4KHH.js";
import "./chunk-B4CSKOTH.js";
import "./chunk-37VXXTCK.js";
import "./chunk-DGGGA4EB.js";
import "./chunk-VOLYE23O.js";
import "./chunk-M56COCZM.js";
import "./chunk-H3Z5HDTB.js";
import "./chunk-YJNQBYCY.js";
import {
  d
} from "./chunk-XHRVMHQV.js";
import "./chunk-6KBNYSOO.js";
import "./chunk-YVZV2JQ2.js";
import "./chunk-WIUOZ2QR.js";
import "./chunk-SMUEPEJK.js";
import "./chunk-WKCMSQJ3.js";
import "./chunk-5I7JTSAL.js";
import "./chunk-SWTEWHKX.js";
import "./chunk-CLCRCQS5.js";
import "./chunk-YLFWLXHD.js";
import "./chunk-AOJUXBCS.js";
import "./chunk-HZVZN4QC.js";
import "./chunk-ARKMS27Q.js";
import "./chunk-DEBJAVLQ.js";
import "./chunk-PEKG77YQ.js";
import "./chunk-M43HSGJE.js";
import "./chunk-2MPRPDUR.js";
import "./chunk-7T32KOGA.js";
import "./chunk-XAJHU5YA.js";
import "./chunk-6AFIGCYY.js";
import "./chunk-OPMACZPA.js";
import "./chunk-7C4YASO2.js";
import "./chunk-SHZ6V3A6.js";
import "./chunk-G72JIG3C.js";
import "./chunk-QUH6IF3C.js";
import "./chunk-6JLNBB4A.js";
import "./chunk-B6TLVNFQ.js";
import "./chunk-HCOIDKPJ.js";
import "./chunk-RI3APACQ.js";
import "./chunk-DNKL4VLK.js";
import "./chunk-JA6WVUX5.js";
import "./chunk-HLUCHGW6.js";
import "./chunk-5ZLWOYXQ.js";
import "./chunk-LMKW53EF.js";
import "./chunk-245OSL56.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-WJF6G6DB.js";
import "./chunk-VDBD7USS.js";
import "./chunk-G4JWBWXC.js";
import "./chunk-TX7HQE3N.js";
import "./chunk-O4PT2W5W.js";
import "./chunk-VDUPOWSD.js";
import "./chunk-PCY7U2ND.js";
import "./chunk-WFMHAEPG.js";
import "./chunk-JTVRCNJE.js";
import "./chunk-KD5GWDMJ.js";
import "./chunk-AV2MJVRY.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-5MM6JTK5.js";
import "./chunk-EMGBZTFR.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import "./chunk-NEOVY6GP.js";
import "./chunk-ELAKODAU.js";
import "./chunk-RY6EUXME.js";
import "./chunk-CMPLJJCX.js";
import "./chunk-JHB4QD5T.js";
import {
  b
} from "./chunk-XWFSWJ3K.js";
import "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import {
  o
} from "./chunk-ULISRLN2.js";
import "./chunk-R4NJFVU4.js";
import {
  m
} from "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import "./chunk-7OZN72PM.js";
import "./chunk-Z4ITP2HY.js";
import "./chunk-WOVS7CNY.js";
import "./chunk-4VQUNH2Z.js";
import "./chunk-7SLET7NM.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import "./chunk-WJEG23O3.js";
import "./chunk-RQUVK4YL.js";
import "./chunk-OCQCW564.js";
import "./chunk-SYHV5BPK.js";
import "./chunk-S4BA7TJA.js";
import "./chunk-GYDLT2MD.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import "./chunk-CYXXOYR3.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import "./chunk-2K433C2G.js";
import {
  C
} from "./chunk-EOJGN7NW.js";
import "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import "./chunk-4MEW2QUW.js";
import "./chunk-GMGPROHW.js";
import "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import "./chunk-VYI6FOKY.js";
import "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  p
} from "./chunk-UNFSMTII.js";
import "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import "./chunk-DPYVIPSF.js";
import {
  a,
  n2 as n,
  s2 as s
} from "./chunk-JB56QM27.js";
import "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/arcade.js
var y = null;
function f(e, t2, a2, n2 = {}) {
  const o2 = t2.elementType, c = "value", i2 = "array" === o2.type ? [{ name: c, type: o2.type, elementType: o2.elementType }] : "dictionary" === o2.type ? [{ name: c, type: o2.type, properties: o2.properties }] : [{ name: c, type: o2.type }];
  return new t(e.map((e2) => {
    const t3 = {};
    return g(t3, i2, { [c]: e2 }, a2, n2), t3[c];
  }));
}
function d2(e, t2, r2 = {}) {
  const a2 = e instanceof d ? new Ye({ source: e.features, geometryType: e.geometryType, fields: e.fields, spatialReference: e.spatialReference }) : e;
  return t2.constructFeatureSet(a2, r2.spatialReference, null, true, r2.lruCache, r2.interceptor);
}
function b2(e, t2, r2 = {}) {
  const { spatialReference: a2, interceptor: n2, lruCache: o2 } = r2;
  return "string" == typeof e ? t2.createFeatureSetCollectionFromService(e, a2, o2, n2) : t2.createFeatureSetCollectionFromMap(e, a2, o2, n2);
}
function v(e, t2, r2, a2 = {}) {
  const n2 = {};
  return g(n2, t2.properties, e, r2, a2), new y.Dictionary(n2);
}
function g(e, r2, a2, n2, o2 = {}) {
  const c = {};
  for (const t2 of Object.keys(a2)) c[t2.toLowerCase()] = a2[t2];
  for (const s2 of r2) {
    const r3 = s2.name.toLowerCase();
    if (o2.variablesPreProcessed) e[r3] = c[r3];
    else switch (s2.type) {
      case "array": {
        const t2 = c[r3];
        e[r3] = null == t2 ? null : f(t2, s2, n2, o2);
        break;
      }
      case "feature": {
        const t2 = c[r3];
        e[r3] = null == t2 ? null : y.Feature.createFromGraphic(t2, o2?.timeZone);
        break;
      }
      case "featureSet": {
        const t2 = c[r3];
        e[r3] = null == t2 ? null : n2 ? d2(t2, n2, o2) : null;
        break;
      }
      case "featureSetCollection": {
        const t2 = c[r3];
        e[r3] = null == t2 ? null : n2 ? b2(t2, n2, o2) : null;
        break;
      }
      case "dictionary": {
        const t2 = c[r3];
        e[r3] = null == t2 ? null : v(t2, s2, n2, o2);
        break;
      }
      case "date": {
        const a3 = c[r3];
        e[r3] = a3 ? a3 instanceof m ? a3 : o2?.timeZone ? m.dateJSAndZoneToArcadeDate(a3, o2?.timeZone) : m.dateJSToArcadeDate(a3) : null;
        break;
      }
      case "dateOnly": {
        const t2 = c[r3];
        e[r3] = t2 ? t2 instanceof i ? t2 : i.fromReader(t2) : null;
        break;
      }
      case "time": {
        const t2 = c[r3];
        e[r3] = t2 ? t2 instanceof r ? t2 : r.fromReader(t2) : null;
        break;
      }
      case "knowledgeGraph":
      case "geometry":
      case "boolean":
      case "text":
      case "number":
        e[r3] = c[r3];
        break;
      case "voxel": {
        const t2 = c[r3];
        e[r3] = null == t2 ? null : new y.Voxel(t2, o2?.timeZone);
        break;
      }
    }
  }
}
function S(e, t2) {
  for (const r2 of e) t2.push(r2), "dictionary" === r2.type && S(r2.properties, t2);
  return t2;
}
function w(e, t2, r2, a2, n2) {
  const { spatialReference: o2, interceptor: c, lruCache: i2, console: p2, abortSignal: s2, timeZone: l, services: m2 = { portal: C.getDefault() } } = r2, y2 = { vars: {}, spatialReference: o2, interceptor: c, timeZone: l, lrucache: i2, useAsync: n2, services: m2, console: p2, abortSignal: s2 };
  return t2 ? (g(y2.vars, e.variables, t2, a2, r2), y2) : y2;
}
function $(t2, r2) {
  switch (r2.getArcadeType(t2)) {
    case "number":
    case "text":
    case "boolean":
    case "point":
    case "polygon":
    case "polyline":
    case "multipoint":
    case "extent":
      return t2;
    case "date":
      return t2.toJSDate();
    case "time":
    case "dateOnly":
      return t2.toString();
    case "feature": {
      const r3 = (t2.type, t2), a2 = "geometry" in r3 ? r3.geometry() : null, n2 = "readAttributes" in r3 ? r3.readAttributes() : r3.attributes;
      return new b({ geometry: a2, attributes: n2 });
    }
    case "dictionary": {
      const e = t2, a2 = e.attributes, n2 = {};
      for (const t3 of Object.keys(a2)) n2[t3] = $(e.field(t3), r2);
      return n2;
    }
    case "array":
      return ("toArray" in t2 ? t2.toArray() : t2).map((e) => $(e, r2));
  }
  return t2;
}
var h = { variables: [{ name: "$feature", type: "feature" }, { name: "$layer", type: "featureSet" }, { name: "$datastore", type: "featureSetCollection" }, { name: "$map", type: "featureSetCollection" }, { name: "$userInput", type: "geometry" }, { name: "$graph", type: "knowledgeGraph" }, { name: "$view", type: "dictionary", properties: [{ name: "scale", type: "number" }, { name: "timeProperties", type: "dictionary", properties: [{ name: "currentStart", type: "date" }, { name: "currentEnd", type: "date" }, { name: "startIncluded", type: "boolean" }, { name: "endIncluded", type: "boolean" }] }] }] };
var C2 = { variables: [{ name: "$feature", type: "feature" }, { name: "$aggregatedFeatures", type: "featureSet" }, { name: "$view", type: "dictionary", properties: [{ name: "scale", type: "number" }, { name: "timeProperties", type: "dictionary", properties: [{ name: "currentStart", type: "date" }, { name: "currentEnd", type: "date" }, { name: "startIncluded", type: "boolean" }, { name: "endIncluded", type: "boolean" }] }] }] };
var x = { variables: [{ name: "$voxel", type: "voxel" }] };
var j = /* @__PURE__ */ new Map([["aggregate-field", { variables: [{ name: "$feature", type: "feature" }] }], ["form-constraint", { variables: [{ name: "$feature", type: "feature" }] }], ["feature-z", { variables: [{ name: "$feature", type: "feature" }] }], ["field-calculation", { variables: [{ name: "$feature", type: "feature" }, { name: "$datastore", type: "featureSetCollection" }] }], ["form-calculation", { variables: [{ name: "$feature", type: "feature" }, { name: "$originalFeature", type: "feature" }, { name: "$layer", type: "featureSet" }, { name: "$featureSet", type: "featureSet" }, { name: "$datastore", type: "featureSetCollection" }, { name: "$map", type: "featureSetCollection" }, { name: "$editContext", type: "dictionary", properties: [{ name: "editType", type: "text" }] }] }], ["labeling", { variables: [{ name: "$feature", type: "feature" }, { name: "$view", type: "dictionary", properties: [{ name: "scale", type: "number" }, { name: "timeProperties", type: "dictionary", properties: [{ name: "currentStart", type: "date" }, { name: "currentEnd", type: "date" }, { name: "startIncluded", type: "boolean" }, { name: "endIncluded", type: "boolean" }] }] }] }], ["popup", h], ["popup-element", h], ["popup-feature-reduction", C2], ["popup-element-feature-reduction", C2], ["visualization", { variables: [{ name: "$feature", type: "feature" }, { name: "$view", type: "dictionary", properties: [{ name: "scale", type: "number" }, { name: "timeProperties", type: "dictionary", properties: [{ name: "currentStart", type: "date" }, { name: "currentEnd", type: "date" }, { name: "startIncluded", type: "boolean" }, { name: "endIncluded", type: "boolean" }] }] }] }], ["popup-voxel", x], ["popup-element-voxel", x]]);
function A(e) {
  "feature-reduction-popup" === e ? (p(n.getLogger("esri.arcade"), 'profile name: "feature-reduction-popup"', { replacement: '"popup-feature-reduction"', version: "4.32", warnOnce: true }), e = "popup-feature-reduction") : "feature-reduction-popup-element" === e && (p(n.getLogger("esri.arcade"), 'profile name: "feature-reduction-popup-element"', { replacement: '"popup-element-feature-reduction"', version: "4.32", warnOnce: true }), e = "popup-element-feature-reduction");
  const t2 = j.get(e);
  if (!t2) {
    const t3 = Array.from(j.keys()).map((e2) => `'${e2}'`).join(", ");
    throw new s("createArcadeProfile:invalid-profile-name", `Invalid profile name '${e}'. You must specify one of the following values: ${t3}`);
  }
  return a(t2);
}
function k(_0, _1) {
  return __async(this, arguments, function* (e, t2, r2 = {}) {
    y || (y = yield o());
    const { arcade: a2, arcadeUtils: o2 } = y, { loadScriptDependencies: c, referencesMember: i2, scriptIsAsync: p2 } = a2, s2 = S(t2.variables, []), u = s2.filter((e2) => "featureSet" === e2.type || "featureSetCollection" === e2.type).map((e2) => e2.name.toLowerCase()), l = a2.parseScript(e, u);
    if (!l) throw new s("arcade:invalid-script", "Unable to create SyntaxTree");
    const f2 = o2.extractFieldNames(l), d3 = a2.scriptTouchesGeometry(l), b3 = s2.map((e2) => e2.name.toLowerCase()).filter((e2) => i2(l, e2)), v2 = p2(l, u);
    yield c(l, v2, u);
    const g2 = { vars: {}, spatialReference: null, useAsync: v2 };
    for (const n2 of b3) g2.vars[n2] = "any";
    const { lruCache: h2 } = r2, C3 = a2.compileScript(l, g2), x2 = a2.featureSetUtils(), { services: j2 } = r2;
    return { execute: (e2, r3 = {}) => {
      if (v2) throw new s("arcade:invalid-execution-mode", "Cannot execute the script in synchronous mode");
      const a3 = C3(w(t2, e2, __spreadValues({ lruCache: h2 }, r3), x2, v2));
      return r3.rawOutput ? a3 : $(a3, o2);
    }, executeAsync: (_02, ..._12) => __async(this, [_02, ..._12], function* (e2, r3 = {}) {
      const a3 = yield C3(w(t2, e2, __spreadValues({ lruCache: h2, services: j2 }, r3), x2, v2));
      return r3.rawOutput ? a3 : $(a3, o2);
    }), isAsync: v2, variablesUsed: b3, fieldsUsed: f2, geometryUsed: d3, syntaxTree: l };
  });
}
export {
  k as createArcadeExecutor,
  A as createArcadeProfile
};
//# sourceMappingURL=arcade-VKG6PHKM.js.map
