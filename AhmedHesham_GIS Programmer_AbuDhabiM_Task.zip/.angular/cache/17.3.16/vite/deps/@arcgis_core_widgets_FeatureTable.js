import {
  $ as $2,
  C as C2,
  D,
  E,
  H as H2,
  J as J3,
  N,
  R,
  T as T3,
  V as V2,
  X,
  a as a4,
  a2 as a5,
  a3 as a6,
  b as b2,
  c as c6,
  e as e4,
  g as g3,
  h as h3,
  i as i5,
  k as k2,
  p2 as p5,
  s as s8,
  w as w2,
  x
} from "./chunk-KLEGUCFX.js";
import {
  T as T2
} from "./chunk-BUKXCG5D.js";
import "./chunk-FOU3TQ4S.js";
import "./chunk-ZOQURDQK.js";
import {
  n as n7
} from "./chunk-CEREZWZ6.js";
import {
  J
} from "./chunk-246FW4WO.js";
import {
  $
} from "./chunk-5V6LISMP.js";
import {
  e as e9
} from "./chunk-AH3BFXAV.js";
import {
  c as c5,
  m as m2
} from "./chunk-DTRN4OOH.js";
import "./chunk-ZENTKHGR.js";
import {
  s as s6
} from "./chunk-3P3SZYCX.js";
import {
  c as c3
} from "./chunk-2MPRPDUR.js";
import {
  g as g2
} from "./chunk-7T32KOGA.js";
import {
  G as G2,
  c as c4
} from "./chunk-XAJHU5YA.js";
import "./chunk-6AFIGCYY.js";
import {
  d as d3
} from "./chunk-OPMACZPA.js";
import {
  a as a3,
  f as f3,
  j as j2,
  p as p3,
  p2 as p4
} from "./chunk-7C4YASO2.js";
import "./chunk-G4JWBWXC.js";
import "./chunk-TX7HQE3N.js";
import "./chunk-O4PT2W5W.js";
import "./chunk-VDUPOWSD.js";
import "./chunk-PCY7U2ND.js";
import "./chunk-WFMHAEPG.js";
import "./chunk-JTVRCNJE.js";
import "./chunk-KD5GWDMJ.js";
import "./chunk-AV2MJVRY.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-5MM6JTK5.js";
import "./chunk-EMGBZTFR.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import {
  b
} from "./chunk-XWFSWJ3K.js";
import "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import {
  $e,
  B,
  Fe,
  H2 as H,
  Ie,
  J as J2,
  M,
  Se,
  be,
  f2,
  ge,
  we,
  xe,
  y as y2,
  ye
} from "./chunk-3SPX7DOW.js";
import "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import {
  n as n4
} from "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import "./chunk-7OZN72PM.js";
import "./chunk-Z4ITP2HY.js";
import "./chunk-WOVS7CNY.js";
import {
  i as i4,
  n as n5,
  y as y3
} from "./chunk-4VQUNH2Z.js";
import "./chunk-7SLET7NM.js";
import {
  l as l2
} from "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import {
  e as e6
} from "./chunk-OWFGHE2Q.js";
import {
  e as e7
} from "./chunk-HL6SQA2H.js";
import {
  e as e5
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c,
  e as e3
} from "./chunk-PPAPRIQT.js";
import {
  n2 as n3
} from "./chunk-L7IGKLK6.js";
import {
  A as A2,
  T,
  w,
  y
} from "./chunk-2NHACHL3.js";
import {
  CSSResult,
  LitElement,
  adoptStyles,
  css
} from "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import {
  e as e8
} from "./chunk-RQSCVY76.js";
import {
  a as a7
} from "./chunk-723TUEOK.js";
import "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import {
  p as p2
} from "./chunk-TAW5EJHA.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import "./chunk-JCECTBEZ.js";
import "./chunk-YFQQ5MRE.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import {
  n as n6
} from "./chunk-7NHDAECT.js";
import "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import {
  O as O2,
  P as P2,
  c as c2,
  l as l3,
  s as s7
} from "./chunk-2K433C2G.js";
import "./chunk-EOJGN7NW.js";
import "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import {
  s as s4
} from "./chunk-4MEW2QUW.js";
import {
  i as i3,
  l
} from "./chunk-GMGPROHW.js";
import {
  f
} from "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import {
  C,
  P,
  d as d2,
  p,
  v
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  i as i2
} from "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import {
  j
} from "./chunk-EHGO3SHH.js";
import {
  e as e2,
  h as h2
} from "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import {
  h
} from "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import {
  s as s5
} from "./chunk-REZDV4AU.js";
import "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import "./chunk-ADRG7ORV.js";
import {
  ct,
  st
} from "./chunk-4LJTFP6V.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  g,
  i,
  m,
  r2
} from "./chunk-UNFSMTII.js";
import {
  a3 as a2
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  A,
  L,
  d,
  e2 as e,
  k,
  n as n2,
  o4 as o,
  s as s3
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a,
  n2 as n,
  s2
} from "./chunk-JB56QM27.js";
import {
  G,
  s
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __objRest,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/support/iconUtils.js
var n8 = { danger: "exclamation-mark-circle", info: "information", success: "check", warning: "exclamation-mark-triangle", brand: void 0, neutral: void 0, inverse: void 0 };

// node_modules/@arcgis/core/widgets/Editor/components/Prompt.js
var c7 = "esri-editor__prompt";
var n9 = { base: c7, header: `${c7}__header`, heading: `${c7}__header__heading`, message: `${c7}__message`, divider: `${c7}__divider`, actions: `${c7}__actions`, halfWidthButton: `${c7}__half-width-button` };
var s9 = () => c({ button: () => import("./calcite-button-FV2OB3GT.js"), icon: () => import("./calcite-icon-TH7JL242.js"), scrim: () => import("./calcite-scrim-BY7HE4HI.js"), label: () => import("./calcite-label-MCJS3SWR.js"), "radio-button": () => import("./calcite-radio-button-6BXHCEBJ.js"), "radio-button-group": () => import("./calcite-radio-button-group-BHJ23EIS.js") });
function r3(_a) {
  var _b = _a, { actions: t3, context: c13, headingLevel: s18, message: r10, title: d6 } = _b, p14 = __objRest(_b, ["actions", "context", "headingLevel", "message", "title"]);
  const { primary: m8, secondary: u5 } = t3;
  let b5;
  switch (c13) {
    case "danger":
      b5 = "danger";
      break;
    case "info":
      b5 = "brand";
      break;
    default:
      b5 = "neutral";
  }
  const h8 = n3("calcite-button", { afterCreate: (t4) => T(t4), appearance: "solid", classes: { [n9.halfWidthButton]: !!u5 }, "data-testid": "primary-prompt-button", key: "prompt-primary-button", kind: b5, onclick: m8.action, width: "full" }, m8.label), g6 = u5 && n3("calcite-button", { appearance: "outline", class: n9.halfWidthButton, "data-testid": "secondary-prompt-button", key: "prompt-secondary-button", kind: b5, onclick: u5.action, width: "full" }, u5.label);
  return n3("calcite-scrim", { "data-testid": "prompt", key: "prompt" }, n3("div", { class: `${n9.base}--${c13}` }, n3("div", { class: n9.header }, n3("calcite-icon", { icon: n8.warning }), n3(e6, { class: n9.heading, level: s18 }, d6)), n3("div", { class: n9.message }, r10), l4(p14) ?? n3("div", { class: n9.divider }), n3("div", { class: n9.actions }, g6, h8)));
}
function l4({ radios: t3, onRadioSelection: e13, defaultRadioSelection: o5 }) {
  return t3?.length ? n3("calcite-radio-button-group", { name: "PromptChoiceList" }, t3.map((t4) => n3("calcite-label", { layout: "inline" }, n3("calcite-radio-button", { checked: t4.value === o5, value: t4.value, onCalciteRadioButtonChange: () => e13?.(t4.value) }), t4.label))) : void 0;
}

// node_modules/@arcgis/core/widgets/FeatureTable/ColumnMenuVisibleElements.js
var t = class extends g {
  constructor(o5) {
    super(o5), this.sortAscending = true, this.sortDescending = true;
  }
};
r([m({ type: Boolean, nonNullable: true })], t.prototype, "sortAscending", void 0), r([m({ type: Boolean, nonNullable: true })], t.prototype, "sortDescending", void 0), t = r([a2("esri.widgets.FeatureTable.ColumnMenuVisibleElements")], t);
var c8 = t;

// node_modules/@arcgis/core/widgets/FeatureTable/Grid/ColumnCSS.js
var e10 = "esri-column";
var n10 = { contentFull: `${e10}__content--full`, sorter: `${e10}__sorter`, headerContent: `${e10}__header-content`, headerDescription: `${e10}__header-description`, headerLabel: `${e10}__header-label`, headerMenuIcon: `${e10}__header-menu-icon` };

// node_modules/@arcgis/core/widgets/FeatureTable/support/columnUtils.js
function n11(n17) {
  return null != n17 && "object" == typeof n17 && "type" in n17 && null !== n17.type && ("column" === n17.type || "field" === n17.type || "group" === n17.type || "attachment" === n17.type || "relationship" === n17.type);
}
function t2(n17) {
  return !(!n17 || !("field" in n17));
}
function e11(n17) {
  return !(!n17 || !("columns" in n17));
}
function i6(n17) {
  return !(!n17 || !("relationshipId" in n17));
}
function o2(n17) {
  return !(!n17 || !("onShowAttachments" in n17));
}

// node_modules/@arcgis/core/widgets/FeatureTable/support/tableUtils.js
var n12 = { action: "EsriFeatureTableActionColumn", attachments: "EsriFeatureTableAttachmentsColumn", relationship: "EsriFeatureTableRelationshipColumn" };
var i7 = () => c({ action: () => import("./calcite-action-QPIDLQ7A.js"), button: () => import("./calcite-button-FV2OB3GT.js"), dropdown: () => import("./calcite-dropdown-G3BRMDWP.js"), "dropdown-item": () => import("./calcite-dropdown-item-TAJST3BD.js"), "dropdown-group": () => import("./calcite-dropdown-group-KHQP6LCC.js"), icon: () => import("./calcite-icon-TH7JL242.js") });
var o3 = () => Promise.all([c({ input: () => import("./calcite-input-O4CBS4EF.js"), option: () => import("./calcite-option-GLHQWQBO.js"), select: () => import("./calcite-select-UVBIOANH.js"), "input-date-picker": () => import("./calcite-input-date-picker-SKUVNMAY.js"), "input-time-picker": () => import("./calcite-input-time-picker-5HBZ2UVE.js") }), i7()]);
var r4 = () => Promise.all([c({ "action-bar": () => import("./calcite-action-bar-ENGXQHJA.js") }), o3()]);
function c9(e13) {
  return null != e13 && "object" == typeof e13 && "createQuery" in e13 && "getField" in e13 && "queryFeatureCount" in e13 && "queryFeatures" in e13 && "queryObjectIds" in e13 && "capabilities" in e13 && "fields" in e13 && "fieldsIndex" in e13 && "id" in e13 && "load" in e13 && "objectIdField" in e13 && "type" in e13 && "when" in e13;
}
function s10(e13) {
  return c9(e13) && "queryAttachments" in e13;
}
function a8(e13) {
  return s10(e13) && "addAttachment" in e13 && "deleteAttachments" in e13 && "updateAttachment" in e13;
}
function l5(e13) {
  return c9(e13) && "editingEnabled" in e13 && "applyEdits" in e13;
}
function p6(e13) {
  return c9(e13) && "relationships" in e13 && "queryRelatedFeatures" in e13 && "queryRelatedFeaturesCount" in e13;
}
function u(e13) {
  return null != e13 && "object" == typeof e13 && "type" in e13 && "map-image" === e13.type;
}
function m3(e13, t3, n17) {
  if (t3?.map) return d4(e13, [...t3.map.allLayers, ...t3.map.allTables], n17);
}
function d4(e13, t3, { relatedTableId: n17 }) {
  const i11 = "scene" === e13.type && e13.associatedLayer ? e13.associatedLayer.url : e13.url, o5 = (t4) => !(!p6(t4) || t4 === e13) && ("sublayer" === t4.type && t4.layer?.url === e13.url ? t4.id === n17 : i11 === t4.url && t4.layerId === n17);
  if ("sublayer" === e13.type && u(e13.parent)) {
    const t4 = (t5) => p6(t5) && t5 !== e13 && t5.id === n17, i12 = e13.parent, o6 = i12.sublayers?.find(t4) || i12.subtables?.find(t4);
    if (p6(o6)) return o6;
  }
  let r10 = null;
  for (const c13 of t3) if (u(c13)) {
    const e14 = c13.sublayers?.find(o5) || c13.subtables?.find(o5);
    if (e14) {
      r10 = e14;
      break;
    }
  } else if (o5(c13)) {
    r10 = c13;
    break;
  }
  if (p6(r10)) return r10;
}
function f4(e13, t3) {
  return null != e13 && Number.isInteger(e13) && e13 > -1 && e13 < t3;
}
function y4(e13) {
  return null == e13 || 0 === e13.trim().length;
}
function b3(e13, t3) {
  return (e13.relationships ?? []).filter((e14) => !(e14.id === t3 && "one-to-one" === e14.cardinality)).map(({ id: e14 }) => ({ relationshipId: e14 }));
}
function h4(e13, t3) {
  return e13.relationships?.find(({ id: e14 }) => e14 === t3);
}
function w3(e13, t3) {
  return null == t3 ? null : e13?.fields?.find((e14) => t3.toLowerCase() === e14.name?.toLowerCase());
}
function g4(t3, n17) {
  return n17?.some((n18) => !(!e11(n18) || !g4(t3, n18.columns)) || n18.fieldName === t3) ?? false;
}
function C3(e13, t3) {
  return `${e13.id}-${t3}`;
}
function I(e13) {
  return e13.isTable ? "table" : "feature" === e13.type ? "feature-layer" : "layer";
}

// node_modules/@arcgis/core/widgets/FeatureTable/Grid/Column.js
var u2 = class extends g {
  constructor(e13) {
    super(e13), this._menuIsOpen = false, this.autoWidth = false, this.cellValueFormatFunction = ({ root: e14, rowData: t3, value: i11 }) => {
      const { formatFunction: n17 } = this, o5 = A2.sanitize(i11);
      if (n17 && t3) {
        const { index: i12, item: { attachments: s18, feature: r10, relatedRecords: l10 } } = t3;
        return n17({ attachments: s18, column: this, feature: r10, index: i12, relatedRecords: l10, value: o5, virtualIndex: this.getVirtualRowIndex(e14) });
      }
      return o5;
    }, this.description = null, this.direction = null, this.fieldName = null, this.flexGrow = 1, this.footerRenderFunction = null, this.formatFunction = null, this.frozen = false, this.frozenToEnd = false, this.grid = null, this.headerRenderFunction = (e14) => {
      const { root: t3 } = e14, i11 = this.createHeaderContent();
      this.removeCellContent(t3), t3.appendChild(i11);
    }, this.hidden = false, this.icon = null, this.iconText = null, this.initialSortPriority = null, this.label = null, this.menuConfig = null, this.messages = null, this.messagesCommon = null, this.messagesURIUtils = null, this.renderFunction = ({ root: e14, rowData: t3 }) => {
      const i11 = this.getCellValue(t3), n17 = this.cellValueFormatFunction({ root: e14, rowData: t3, value: i11 });
      let o5 = null;
      if (o5 = n17 instanceof HTMLElement ? n17 : a5(this.messagesURIUtils, n17), this.removeCellContent(e14), o5 instanceof HTMLElement) e14.removeAttribute("title"), e14.appendChild(o5);
      else if (null != o5) {
        const t4 = o5.toString();
        e14.innerHTML = t4, e14.title = t4;
      }
    }, this.resizable = true, this.sortable = false, this.store = null, this.tableTimeZone = null, this.textAlign = "start", this.textWrap = false, this.timeZone = null, this.visibleElements = null, this.width = 200;
  }
  initialize() {
    const { fieldName: e13 } = this;
    this._set("sortElement", this.createSortElement()), this.sortElement.setAttribute("path", e13), this.addHandles([d2(() => this.direction, (e14) => {
      const { sortElement: t3 } = this;
      this.sortable && t3 && (e14 ? this.sortElement.direction !== e14 && t3.setAttribute("direction", e14) : t3.removeAttribute("direction"));
    }), p(() => this.grid?.isReady && this.sortElement, () => {
      const { direction: e14, grid: t3, hidden: i11, sortElement: n17 } = this;
      i11 && e14 && n17 && t3 && !t3.hasSorter(n17) && t3.addSorter(n17);
    }, P), d2(() => [this.timeZone, this.icon, this.iconText], () => this.grid?.requestContentUpdate()), d2(() => this.hidden, () => this.closeMenu()), d2(() => this.fieldName, (e14) => {
      const { sortElement: t3 } = this;
      t3 && t3.path !== e14 && t3.setAttribute("path", e14);
    }), d2(() => this.effectiveLabel, (e14) => {
      const { sortElement: t3 } = this;
      t3 && t3.textContent !== e14 && (t3.setAttribute("title", e14), t3.textContent = e14);
    })]);
  }
  get _headerRequiresTextContainer() {
    return !(!this.sortable && "" === this.effectiveLabel && null == this.effectiveDescription);
  }
  get customMenuItems() {
    return this.menuConfig?.items?.map(({ disabled: e13, hidden: t3, icon: i11, iconClass: n17, label: o5, selected: s18, clickFunction: r10 }) => this.createCalciteDropdownItem({ disabled: e13, hidden: t3, iconClass: n17, iconStart: i11, selected: s18, textContent: o5, onclick: (e14) => r10(e14) })) ?? [];
  }
  get defaultMenuItems() {
    if (!this.sortable) return [];
    const e13 = this.messages, t3 = [], i11 = this.visibleElements?.columnMenuItems;
    if (false !== i11?.sortAscending) {
      const i12 = this.createCalciteDropdownItem({ iconStart: "sort-ascending-arrow", textContent: e13?.sortAsc, onclick: () => this.direction = "asc" });
      t3.push(i12);
    }
    if (false !== i11?.sortDescending) {
      const i12 = this.createCalciteDropdownItem({ iconStart: "sort-descending-arrow", textContent: e13?.sortDesc, onclick: () => this.direction = "desc" });
      t3.push(i12);
    }
    return t3;
  }
  get effectiveDescription() {
    const { description: e13 } = this;
    return y4(e13) ? null : A2.sanitize(e13);
  }
  get effectiveLabel() {
    return A2.sanitize(this.label || this.fieldName);
  }
  get iconNode() {
    const { icon: e13, iconText: t3 } = this, i11 = t3 ? A2.sanitize(t3) : void 0;
    return e13 ? this.createCalciteIcon({ icon: e13, textLabel: i11 }) : null;
  }
  set invalid(e13) {
    this._set("invalid", e13), this.grid?.generateCellPartNames();
  }
  get invalid() {
    return this._get("invalid") ?? false;
  }
  get menu() {
    const { customMenuItems: e13, defaultMenuItems: t3, menuConfig: i11 } = this, n17 = !!i11?.open, o5 = this.createCalciteAction({ icon: i11?.icon ?? "ellipsis", text: this.messages?.menu ?? "", slot: "trigger" }), s18 = document.createElement("calcite-dropdown");
    if (s18.maxItems = i11?.maxItems ?? 4, s18.placement = "top-end", s18.overlayPositioning = "fixed", s18.scale = i11?.scale ?? "m", n17 && (s18.open = n17, this._menuIsOpen = true), s18.appendChild(o5), s18.addEventListener("calciteDropdownOpen", () => this._menuIsOpen = true), s18.addEventListener("calciteDropdownClose", () => this._menuIsOpen = false), s18.onkeydown = this._stopPropagationOnSelect, s18.addEventListener("mousewheel", (e14) => {
      e14.stopPropagation();
    }), t3.length) {
      const e14 = s18.appendChild(document.createElement("calcite-dropdown-group"));
      e14.selectionMode = "none", e14.append(...t3);
    }
    if (e13.length) {
      const t4 = s18.appendChild(document.createElement("calcite-dropdown-group"));
      t4.selectionMode = i11?.selectionMode ?? "none", t4.append(...e13);
    }
    return s18;
  }
  get menuItems() {
    return [...this.defaultMenuItems, ...this.customMenuItems];
  }
  get menuIsOpen() {
    return this._menuIsOpen;
  }
  get menuIsVisible() {
    return !(false === this.visibleElements?.columnMenus || !this.menuItems.length);
  }
  closeMenu() {
    this.menu.open = false;
  }
  createSortElement() {
    const { effectiveLabel: e13, direction: t3, fieldName: i11, initialSortPriority: n17 } = this, o5 = document.createElement("vaadin-grid-sorter");
    return o5.classList.add(n10.sorter), o5.setAttribute("path", i11), o5.setAttribute("title", e13), o5.textContent = e13, t3 && o5.setAttribute("direction", t3), null != n17 && (o5._initialOrder = n17), o5.addEventListener("direction-changed", () => {
      this.direction !== o5.direction && this._set("direction", o5.direction);
    }), o5;
  }
  createCalciteAction(e13) {
    const t3 = document.createElement("calcite-action"), { alignment: i11, appearance: n17, className: o5, disabled: s18, icon: r10, label: l10, scale: a17, slot: c13, text: d6, textEnabled: p14, onclick: u5 } = e13;
    return t3.alignment = i11 ?? "center", t3.appearance = n17 ?? "transparent", t3.className = o5 ?? "", t3.disabled = !!s18, t3.icon = r10 ?? "", t3.label = l10 ?? "", t3.scale = a17 ?? "s", t3.slot = c13 ?? "", t3.text = t3.title = d6 ?? "", t3.textEnabled = !!p14, t3.onclick = u5 ?? null, t3;
  }
  createCalciteButton(e13) {
    const t3 = document.createElement("calcite-button"), { alignment: i11, appearance: n17, className: o5, disabled: s18, iconEnd: r10, iconFlipRtl: l10, kind: a17, loading: c13, onclick: d6, scale: p14, textContent: u5, title: m8, width: h8 } = e13;
    return t3.alignment = i11 ?? "center", t3.className = o5 ?? "", t3.scale = p14 ?? "s", t3.appearance = n17 ?? "transparent", t3.disabled = !!s18, t3.iconEnd = r10 ?? "", l10 && (t3.iconFlipRtl = l10), t3.kind = a17 ?? "brand", t3.loading = !!c13, t3.textContent = u5 ?? "", m8 && (t3.title = m8), t3.width = h8 ?? "auto", t3.onclick = d6 ?? null, t3;
  }
  createCalciteDropdownItem(e13) {
    const t3 = document.createElement("calcite-dropdown-item"), { disabled: i11, hidden: n17, iconClass: o5, iconStart: s18, textContent: r10, onclick: a17, selected: c13 } = e13, d6 = r10 ?? "";
    if (o5 && !s18) {
      const e14 = document.createElement("span"), i12 = document.createElement("span");
      i12.classList.add(n10.headerMenuIcon, o5), e14.textContent = e14.title = d6, e14.insertBefore(i12, e14.firstChild), t3.appendChild(e14);
    } else t3.iconStart = s18 ?? "", t3.textContent = t3.title = d6;
    return t3.disabled = !!i11, t3.hidden = "function" == typeof n17 ? n17() : !!n17, t3.selected = !!c13, a17 && (t3.addEventListener("calciteDropdownItemSelect", a17), t3.onkeydown = this._stopPropagationOnSelect), t3;
  }
  createCalciteIcon(e13) {
    const { effectiveLabel: t3 } = this, { icon: i11, scale: n17, textLabel: o5 } = e13, s18 = document.createElement("calcite-icon"), r10 = o5 ?? t3;
    return s18.icon = i11, s18.scale = n17 ?? "s", s18.textLabel = r10, s18.title = r10, s18;
  }
  createHeaderContent() {
    const { effectiveDescription: e13, effectiveLabel: t3, iconNode: i11 } = this, n17 = document.createElement("div");
    if (n17.classList.add(n10.headerContent), i11 && n17.appendChild(i11), !this._headerRequiresTextContainer) return n17;
    const o5 = n17.appendChild(document.createElement("div"));
    return this.sortable ? o5.appendChild(this.sortElement) : "" !== t3 && o5.appendChild(this._createHeaderTextElement(t3, n10.headerLabel)), null != e13 && false !== this.visibleElements?.columnDescriptions && o5.appendChild(this._createHeaderTextElement(e13, n10.headerDescription)), this.menuIsVisible && n17.appendChild(this.menu), n17;
  }
  getCellValue(e13) {
    return e13?.item.feature.attributes?.[this.fieldName];
  }
  getVirtualRowIndex(e13) {
    const t3 = this.grid?.getRowContainingNode(e13);
    return t3?.parentElement ? [...t3.parentElement.children].indexOf(t3) : -1;
  }
  removeCellContent(e13) {
    if (e13 && e13.firstChild) try {
      for (; e13?.firstChild; ) e13?.removeChild(e13.firstChild);
    } catch (t3) {
    }
  }
  openMenu() {
    this.menuIsVisible && (this.menu.open = true, T(this.menuItems[0]));
  }
  sort() {
    this.sortable && this.sortElement?.click();
  }
  _stopPropagationOnSelect(e13) {
    "Enter" !== e13.key && " " !== e13.key || e13.stopPropagation();
  }
  _createHeaderTextElement(e13, t3) {
    const i11 = document.createElement("span"), n17 = e13 ?? "";
    i11.classList.add(t3);
    const o5 = i11.appendChild(document.createElement("span"));
    return o5.textContent = n17, o5.setAttribute("title", n17), i11;
  }
};
r([m()], u2.prototype, "_headerRequiresTextContainer", null), r([m()], u2.prototype, "_menuIsOpen", void 0), r([m()], u2.prototype, "autoWidth", void 0), r([m()], u2.prototype, "cellValueFormatFunction", void 0), r([m()], u2.prototype, "customMenuItems", null), r([m()], u2.prototype, "defaultMenuItems", null), r([m()], u2.prototype, "description", void 0), r([m()], u2.prototype, "direction", void 0), r([m()], u2.prototype, "effectiveDescription", null), r([m()], u2.prototype, "effectiveLabel", null), r([m({ constructOnly: true })], u2.prototype, "fieldName", void 0), r([m()], u2.prototype, "flexGrow", void 0), r([m()], u2.prototype, "footerRenderFunction", void 0), r([m()], u2.prototype, "formatFunction", void 0), r([m()], u2.prototype, "frozen", void 0), r([m()], u2.prototype, "frozenToEnd", void 0), r([m()], u2.prototype, "grid", void 0), r([m()], u2.prototype, "iconNode", null), r([m()], u2.prototype, "invalid", null), r([m()], u2.prototype, "headerRenderFunction", void 0), r([m()], u2.prototype, "hidden", void 0), r([m()], u2.prototype, "icon", void 0), r([m()], u2.prototype, "iconText", void 0), r([m({ constructOnly: true })], u2.prototype, "initialSortPriority", void 0), r([m()], u2.prototype, "label", void 0), r([m()], u2.prototype, "menu", null), r([m()], u2.prototype, "menuItems", null), r([m()], u2.prototype, "menuConfig", void 0), r([m()], u2.prototype, "menuIsOpen", null), r([m()], u2.prototype, "menuIsVisible", null), r([m()], u2.prototype, "messages", void 0), r([m()], u2.prototype, "messagesCommon", void 0), r([m()], u2.prototype, "messagesURIUtils", void 0), r([m()], u2.prototype, "renderFunction", void 0), r([m()], u2.prototype, "resizable", void 0), r([m()], u2.prototype, "sortable", void 0), r([m({ readOnly: true })], u2.prototype, "sortElement", void 0), r([m()], u2.prototype, "store", void 0), r([m()], u2.prototype, "tableTimeZone", void 0), r([m()], u2.prototype, "textAlign", void 0), r([m()], u2.prototype, "textWrap", void 0), r([m()], u2.prototype, "timeZone", void 0), r([m()], u2.prototype, "visibleElements", void 0), r([m()], u2.prototype, "width", void 0), u2 = r([a2("esri.widgets.FeatureTable.Grid.Column")], u2);
var m4 = u2;

// node_modules/@arcgis/core/widgets/FeatureTable/ActionColumn.js
var n13 = { action: "esri-column__action" };
var a9 = class extends m4 {
  constructor(o5) {
    super(o5), this.autoWidth = false, this.callback = () => {
    }, this.fieldName = n12.action, this.flexGrow = 0, this.frozenToEnd = true, this.disabled = null, this.headerRenderFunction = () => {
    }, this.icon = "pencil", this.renderFunction = ({ root: o6, rowData: t3 }) => {
      if (!t3) return;
      const { index: e13, item: { feature: i11 } } = t3, { callback: s18, disabled: a17, icon: d6, effectiveLabel: c13 } = this, l10 = a17 instanceof Function ? a17({ feature: i11, index: e13 }) : !!a17, p14 = (o7) => {
        o7.stopPropagation(), s18({ index: e13, feature: i11, native: o7 });
      };
      if (o6.firstChild) {
        const t4 = o6.firstChild;
        return t4.disabled = l10, t4.icon = d6, t4.text = c13, void (t4.onclick = p14);
      }
      const u5 = this.createCalciteAction({ alignment: "center", className: `${n13.action} ${n10.contentFull}`, disabled: l10, icon: d6, text: c13, onclick: p14 });
      this.removeCellContent(o6), o6.appendChild(u5);
    }, this.resizable = false, this.sortable = false, this.width = "50px";
  }
};
r([m({ readOnly: true })], a9.prototype, "autoWidth", void 0), r([m()], a9.prototype, "callback", void 0), r([m({ readOnly: true })], a9.prototype, "fieldName", void 0), r([m({ readOnly: true })], a9.prototype, "flexGrow", void 0), r([m()], a9.prototype, "frozenToEnd", void 0), r([m()], a9.prototype, "disabled", void 0), r([m()], a9.prototype, "headerRenderFunction", void 0), r([m()], a9.prototype, "icon", void 0), r([m()], a9.prototype, "renderFunction", void 0), r([m({ readOnly: true })], a9.prototype, "resizable", void 0), r([m({ readOnly: true })], a9.prototype, "sortable", void 0), r([m({ readOnly: true })], a9.prototype, "width", void 0), a9 = r([a2("esri.widgets.FeatureTable.ActionColumn")], a9);
var d5 = a9;

// node_modules/@arcgis/core/widgets/FeatureTable/AttachmentsColumn.js
var c10 = "esri-attachments-column";
var h5 = { contentContainer: `${c10}__content`, showAttachmentsButton: `${c10}__button` };
var m5 = class extends m4 {
  constructor(t3) {
    super(t3), this._buttonElements = new s6(), this._thumbnailElements = new s6(), this.attachmentsViewEnabled = true, this.cellValueFormatFunction = ({ root: t4, rowData: e13 }) => {
      const { _showAttachmentsViewEnabled: n17, formatFunction: o5 } = this, s18 = this.getCellValue(e13);
      if (o5 && e13) {
        const { index: n18, item: { attachments: a18, feature: i12, relatedRecords: r11 } } = e13;
        return o5({ attachments: a18, column: this, feature: i12, index: n18, relatedRecords: r11, value: s18, virtualIndex: this.getVirtualRowIndex(t4) });
      }
      if (!e13) return s18;
      const { index: a17, item: { attachments: i11, objectId: r10 } } = e13, l10 = `(${s18})`;
      if (!this.thumbnailsEnabled && !n17) return s18;
      const c13 = document.createElement("span");
      c13.textContent = c13.title = l10;
      let m8 = null;
      if (this.thumbnailsEnabled && (m8 = this._createOrSyncThumbnails(r10, i11 ?? [])), this._showAttachmentsViewEnabled) {
        const t5 = document.createElement("div");
        m8 && t5.appendChild(m8), t5.appendChild(c13);
        const e14 = this._createOrSyncShowAttachmentsButton(r10, a17);
        return e14.appendChild(t5), e14;
      }
      const u5 = document.createElement("div");
      return u5.classList.add(h5.contentContainer), m8 && u5.appendChild(m8), u5.appendChild(c13), u5;
    }, this.icon = "attachment", this.layer = null, this.onShowAttachments = null, this.sortable = false, this.store = null, this.textAlign = "center", this.thumbnailAppearance = "image", this.thumbnailCount = 8, this.thumbnailIconScale = "m", this.thumbnailsEnabled = true;
  }
  get _showAttachmentsViewEnabled() {
    return !(!this.attachmentsViewEnabled || !this.onShowAttachments);
  }
  get _supportsResize() {
    return !!this.store?.supportsResizeAttachments;
  }
  get effectiveLabel() {
    return A2.sanitize(this.label ?? (this.messages?.attachments || this.fieldName));
  }
  getCellValue(t3) {
    return t3?.item?.attachments?.length ?? 0;
  }
  _createOrSyncThumbnails(t3, e13) {
    const n17 = document.createElement("div"), o5 = this._thumbnailElements.get(t3);
    return o5?.length && o5.length === e13.length ? o5.forEach((t4) => n17.appendChild(t4)) : this._thumbnailElements.set(t3, this._createThumbnailElements(e13, n17)), n17;
  }
  _createOrSyncShowAttachmentsButton(t3, e13) {
    const n17 = this._buttonElements.get(t3);
    if (n17) return n17.textContent = "", n17.onclick = (n18) => this._onShowAttachmentsClick({ index: e13, objectId: t3, event: n18 }), n17;
    const o5 = this.createCalciteButton({ alignment: "icon-end-space-between", className: `${h5.showAttachmentsButton} ${n10.contentFull}`, iconEnd: "chevron-right", iconFlipRtl: "both", scale: this.thumbnailIconScale, textContent: "", title: this.messages?.viewAttachments, width: "full", onclick: (n18) => this._onShowAttachmentsClick({ index: e13, objectId: t3, event: n18 }) });
    return this._buttonElements.set(t3, o5), o5;
  }
  _createThumbnailAnchor({ name: t3, url: e13 }, n17) {
    const o5 = document.createElement("a");
    return o5.href = `${e13}`, o5.download = t3, o5.rel = "noreferrer", o5.target = "_blank", o5.appendChild(n17), o5;
  }
  _createThumbnailElements(t3, e13) {
    const { thumbnailAppearance: n17, thumbnailCount: o5, thumbnailIconScale: i11 } = this, r10 = [], l10 = Math.min(o5, t3.length), c13 = !this.onShowAttachments, h8 = "image" === n17 && !!this.store?.supportsResizeAttachments;
    for (let m8 = 0; m8 < l10; m8++) {
      const n18 = t3[m8], { name: o6, contentType: l11 } = n18, u5 = e4(l11) && h8 ? this._createThumbnailImage(n18) : this.createCalciteIcon({ icon: a4(l11), scale: i11, textLabel: o6 }), p14 = c13 ? this._createThumbnailAnchor(n18, u5) : u5;
      e13 && e13.appendChild(p14), r10.push(p14);
    }
    return r10;
  }
  _createThumbnailImage(t3) {
    const { name: e13, size: n17, url: o5 } = t3, s18 = document.createElement("img"), a17 = `${o5}${o5?.includes("?") ? "&" : "?"}${this._supportsResize ? "w=24" : ""}&fs=${n17}`;
    return s18.alt = this.messages?.attachmentThumbnail ?? e13, s18.src = a17, s18.title = e13, s18;
  }
  _onShowAttachmentsClick({ index: t3, objectId: e13, event: n17 }) {
    n17.preventDefault(), n17.stopPropagation(), this.onShowAttachments?.({ index: t3, objectId: e13 });
  }
};
r([m()], m5.prototype, "_showAttachmentsViewEnabled", null), r([m()], m5.prototype, "_buttonElements", void 0), r([m()], m5.prototype, "_supportsResize", null), r([m()], m5.prototype, "_thumbnailElements", void 0), r([m()], m5.prototype, "attachmentsViewEnabled", void 0), r([m()], m5.prototype, "cellValueFormatFunction", void 0), r([m()], m5.prototype, "effectiveLabel", null), r([m()], m5.prototype, "icon", void 0), r([m()], m5.prototype, "layer", void 0), r([m()], m5.prototype, "onShowAttachments", void 0), r([m({ readOnly: true })], m5.prototype, "sortable", void 0), r([m()], m5.prototype, "store", void 0), r([m()], m5.prototype, "textAlign", void 0), r([m()], m5.prototype, "thumbnailAppearance", void 0), r([m()], m5.prototype, "thumbnailCount", void 0), r([m()], m5.prototype, "thumbnailIconScale", void 0), r([m()], m5.prototype, "thumbnailsEnabled", void 0), m5 = r([a2("esri.widgets.FeatureTable.AttachmentsColumn")], m5);
var u3 = m5;

// node_modules/@arcgis/core/widgets/FeatureForm/InputBase.js
var s11 = class extends g {
  constructor(e13) {
    super(e13), this.element = null, this.feature = null, this.layer = null, this.timeZone = null, this.type = null, this.visibilityExpressionExecutor = null;
  }
  get description() {
    return this.getFormattedLabel(this.element?.description);
  }
  get evaluatedVisibilityExpression() {
    const { visibilityExpressionExecutor: e13 } = this;
    return null != e13 ? !!e13.lastEvaluatedValue : null;
  }
  get label() {
    return this.getFormattedLabel(this.element?.label);
  }
  get updating() {
    return false;
  }
  get visible() {
    return null != this.evaluatedVisibilityExpression ? this.evaluatedVisibilityExpression : null != this.element;
  }
  getFormattedLabel(e13) {
    const { feature: t3, layer: r10, timeZone: i11 } = this;
    return null == r10 || null == e13 ? e13 : D({ label: e13, attributes: t3.attributes, fieldsIndex: r10.fieldsIndex, timeZone: i11 });
  }
};
r([m({ readOnly: true })], s11.prototype, "description", null), r([m({ constructOnly: true })], s11.prototype, "element", void 0), r([m()], s11.prototype, "evaluatedVisibilityExpression", null), r([m()], s11.prototype, "feature", void 0), r([m()], s11.prototype, "label", null), r([m()], s11.prototype, "layer", void 0), r([m()], s11.prototype, "timeZone", void 0), r([m()], s11.prototype, "type", void 0), r([m()], s11.prototype, "updating", null), r([m()], s11.prototype, "visible", null), r([m()], s11.prototype, "visibilityExpressionExecutor", void 0), s11 = r([a2("esri.widgets.FeatureForm.InputBase")], s11);
var l6 = s11;

// node_modules/@arcgis/core/widgets/FeatureForm/EditableInput.js
var l7 = class extends l6 {
  constructor(t3) {
    super(t3), this.arcadeEditType = "NA", this.editableExpressionExecutor = null;
  }
  get editable() {
    return !!this.layerAllowsEdits && (this.evaluatedEditableExpression ?? true);
  }
  get evaluatedEditableExpression() {
    const { editableExpressionExecutor: t3 } = this;
    return null != t3 ? !!t3.lastEvaluatedValue : null;
  }
  get layerAllowsEdits() {
    const { layer: t3 } = this;
    if (!t3) return false;
    const e13 = O2(t3), r10 = e13?.operations.supportsEditing, o5 = a6(e13, this.arcadeEditType);
    return !(!r10 || !o5);
  }
};
r([m()], l7.prototype, "arcadeEditType", void 0), r([m()], l7.prototype, "editable", null), r([m()], l7.prototype, "editableExpressionExecutor", void 0), r([m()], l7.prototype, "evaluatedEditableExpression", null), r([m()], l7.prototype, "layerAllowsEdits", null), l7 = r([a2("esri.widgets.FeatureForm.EditableInput")], l7);
var a10 = l7;

// node_modules/@arcgis/core/widgets/FeatureForm/FieldInput.js
var M2 = class extends a10 {
  constructor(e13) {
    super(e13), this._storedValue = null, this.error = null, this.preservesValueWhenHidden = true, this.field = null, this.group = null, this.requiredExpressionExecutor = null, this.type = "field", this._fieldInputWasVisibleDuringLifetime = false, this.valueExpressionExecutor = null;
  }
  initialize() {
    this.addHandles(d2(() => this.feature, () => this._fieldInputWasVisibleDuringLifetime = false, C));
  }
  get _dateFormRange() {
    const { element: e13, field: t3 } = this;
    if ("date" !== this.dataType) return {};
    const i11 = e13?.domain ? f2(t3, e13.domain) : null;
    if (!e13?.input) return i11 ?? {};
    const l10 = e13.input, { type: n17 } = l10;
    let r10 = {};
    if ("date-picker" !== n17 && "time-picker" !== n17 && "datetimeoffset-picker" !== n17 || (r10 = M(t3, l10.max, l10.min)), "datetime-picker" === n17) {
      const { max: e14, min: t4 } = l10;
      r10 = { max: null != e14 && h3(e14) ? e14.getTime() : null, min: null != t4 && h3(t4) ? t4.getTime() : null };
    }
    const { max: a17, min: o5 } = r10;
    if (i11) {
      const { max: e14, min: t4 } = i11, l11 = n4(e14) && (null == a17 || null != a17 && e14 < a17), n18 = n4(t4) && (null == o5 || null != o5 && t4 > o5);
      return { max: l11 ? e14 : a17 ?? null, min: n18 ? t4 : o5 ?? null, rawMax: l11 ? i11.rawMax : r10?.rawMax ?? null, rawMin: n18 ? i11.rawMin : r10?.rawMin ?? null };
    }
    return { min: o5, max: a17, rawMax: r10?.rawMax ?? null, rawMin: r10?.rawMin ?? null };
  }
  get _dateRange() {
    const { _dateFormRange: e13, field: t3 } = this;
    if ("date" !== this.dataType) return {};
    const i11 = f2(t3);
    if (!i11) return e13;
    const { max: l10, min: n17, rawMax: r10, rawMin: u5 } = e13;
    if ("date" === t3.type) {
      const { max: e14, min: t4 } = i11;
      return { max: n4(l10) && (null === e14 || null != e14 && l10 < e14) ? l10 : e14 ?? null, min: n4(n17) && (null === t4 || null != t4 && n17 > t4) ? n17 : t4 ?? null };
    }
    if ("date-only" === t3.type || "time-only" === t3.type || "timestamp-offset" === t3.type) {
      const { max: e14, min: t4, rawMax: s18, rawMin: a17 } = i11, o5 = n4(l10) && r10 && (null == e14 || l10 < e14), p14 = n4(n17) && u5 && (null == t4 || n17 > t4);
      return { max: o5 ? l10 : e14, min: p14 ? n17 : t4, rawMax: o5 ? r10 : s18, rawMin: p14 ? u5 : a17 };
    }
    return { max: null, min: null };
  }
  get _configAllowsEdits() {
    const { element: e13, layer: t3, name: i11 } = this;
    if (null != e13) return e13.editableExpression ? !!this.evaluatedEditableExpression : false !== e13.editable;
    if (t3?.userHasUpdateItemPrivileges) return true;
    const l10 = t3 && "popupTemplate" in t3 ? t3?.popupTemplate?.fieldInfos?.find(({ fieldName: e14 }) => e14 === i11) : null;
    return l10?.isEditable ?? true;
  }
  get _layerAndFieldAllowEdits() {
    return this.layerAllowsEdits && this.field?.editable;
  }
  get _isVisibleByDefault() {
    const { field: e13, layer: t3 } = this;
    return !!e13?.visible && H(e13, t3);
  }
  get _isEditTrackingField() {
    return J2(this.layer).includes(this.name?.toLowerCase());
  }
  get _shouldUseValueExpression() {
    return this._layerAndFieldAllowEdits && !this._configAllowsEdits && null != this.valueExpressionExecutor && this.valueExpressionExecutor.initialExecutionComplete;
  }
  get isSubtypeField() {
    const { layer: e13 } = this;
    if (e13 && "subtypeField" in e13) {
      const { subtypeField: t3, fieldsIndex: i11 } = e13;
      return (i11.get(t3)?.name ?? t3) === this.name;
    }
    return false;
  }
  get valueIsOutOfDomain() {
    const { domain: e13, value: t3, field: i11 } = this;
    return !(!e13 || null == t3) && null !== y2(i11, t3, e13);
  }
  get dataType() {
    const { field: e13 } = this;
    return ge(e13) ? i5.Number : Fe(e13) ? i5.Text : $(e13) || xe(e13) ? i5.Date : i5.Unsupported;
  }
  get dateDataType() {
    if (this.dataType === i5.Date) return "date" !== this.field.type ? "string" : "number";
  }
  get domain() {
    const { layer: e13, feature: t3, name: i11, element: l10 } = this, n17 = l10?.domain;
    return null != n17 && this._isDomainCompatible(n17) ? n17 : e13.getFieldDomain(i11, { feature: t3 });
  }
  get editable() {
    return !!this._layerAndFieldAllowEdits && (this.evaluatedEditableExpression ?? this._configAllowsEdits);
  }
  get evaluatedRequiredExpression() {
    const { requiredExpressionExecutor: e13 } = this;
    return null != e13 ? !!e13.lastEvaluatedValue : null;
  }
  get evaluatedValueExpression() {
    const { valueExpressionExecutor: e13 } = this;
    return null != e13 ? e13.lastEvaluatedValue : null;
  }
  get hint() {
    return this.element?.hint;
  }
  get includeDate() {
    return !(this.dataType !== i5.Date || "time-only" === this.field.type);
  }
  get includeTime() {
    const { element: e13, field: t3 } = this;
    if (this.dataType !== i5.Date) return false;
    if ("time-only" === t3.type) return true;
    if ("date-only" === t3.type) return false;
    const i11 = "datetime-picker" === e13?.input?.type ? e13.input.includeTime : void 0;
    return void 0 === i11 || i11;
  }
  get includeTimeOffset() {
    if ("timestamp-offset" !== this.field.type) return false;
    const e13 = this.element?.input;
    return !e13 || "datetimeoffset-picker" === e13.type && e13.includeTimeOffset;
  }
  set initialFeature(e13) {
    this._set("initialFeature", e13), this.notifyChange("valid");
  }
  get inputType() {
    return this.element?.input?.type;
  }
  get hasInvalidSwitchValue() {
    const { element: e13 } = this, t3 = w2(e13, "switch") ? e13.input : null;
    return !t3 || X(this.value, t3);
  }
  get isRelationshipKeyField() {
    const { field: e13, layer: t3 } = this;
    return J(t3) && !!t3.relationships?.some((t4) => t4.keyField === e13.name);
  }
  get label() {
    const { field: e13 } = this;
    return this.getFormattedLabel(this.element?.label) ?? e13.alias ?? e13.name;
  }
  get maxLength() {
    return p5({ dataType: this.dataType, field: this.field, input: this.element?.input });
  }
  get minLength() {
    return c6({ dataType: this.dataType, field: this.field, input: this.element?.input });
  }
  get name() {
    return this.field?.name;
  }
  get range() {
    const { domain: e13, element: t3, field: i11 } = this;
    if ("date" === this.dataType) return this._dateRange;
    const l10 = f2(i11, e13) || $e(i11, e13), n17 = l10?.max === Number.MAX_VALUE ? null : l10?.max ?? null, r10 = l10?.min === -Number.MAX_VALUE ? null : l10?.min ?? null;
    if (!t3?.domain || "range" !== t3.domain.type) return { max: n17, min: r10 };
    const { max: u5, min: a17 } = f2(i11) || {};
    return { max: null != u5 && (null === n17 || null != n17 && u5 < n17) ? u5 : n17, min: null != a17 && (null === r10 || null != r10 && a17 > r10) ? a17 : r10 };
  }
  get required() {
    const { editable: e13, evaluatedRequiredExpression: t3, field: i11, visible: l10, isSubtypeField: n17 } = this;
    if (!e13) return false;
    if (false === i11?.nullable) return true;
    if (n17) return true;
    return !(!l10 || false === this.group?.visible || null == t3) && t3;
  }
  set required(e13) {
    this._overrideIfSome("required", e13);
  }
  get showNoValueOptionEnabled() {
    const { element: e13 } = this;
    return !this.required && (!$2(e13) || e13.input.showNoValueOption);
  }
  get showNoValueLabel() {
    const { element: e13 } = this;
    return $2(e13) ? e13.input.noValueOptionLabel : null;
  }
  get submittable() {
    const { field: e13, required: t3, valid: i11, value: l10 } = this;
    return (!t3 || null != l10) && (!!i11 || this.initialFeature.getAttribute(e13.name) === l10);
  }
  get timeResolution() {
    const e13 = this.element?.input;
    if (e13 && ("datetimeoffset-picker" === e13.type || "time-picker" === e13.type)) return e13.timeResolution ?? "minutes";
  }
  get timeStep() {
    return null != this.timeResolution ? g3.get(this.timeResolution) : void 0;
  }
  get updating() {
    const { editableExpressionExecutor: e13, valueExpressionExecutor: t3, visibilityExpressionExecutor: i11, preservesValueWhenHidden: l10 } = this;
    return null != t3 && t3.updating || null != e13 && e13.updating || false === l10 && null != i11 && i11.updating;
  }
  get valid() {
    const e13 = this.editable ? this._validate() : null;
    return this._set("error", e13), null === e13;
  }
  get value() {
    if (this._fieldInputWasVisibleDuringLifetime = this._fieldInputWasVisibleDuringLifetime || this.visible && false !== this.group?.visible, false === this.preservesValueWhenHidden && this._fieldInputWasVisibleDuringLifetime && (false === this.visibilityExpressionExecutor?.lastEvaluatedValue || false === this.group?.visibilityExpressionExecutor?.lastEvaluatedValue)) return null !== this._storedValue && this.set("_storedValue", null), null;
    if (this._shouldUseValueExpression) {
      const e13 = this.evaluatedValueExpression;
      return this.dataType === i5.Date ? this._arcadeOutputToDateFieldValue(e13) : null != e13 && "object" == typeof e13 ? `${e13}` : e13;
    }
    return this._storedValue;
  }
  set value(e13) {
    this.notifyChange("evaluatedVisibilityExpression"), this.set("_storedValue", e13), this.notifyChange("value"), this.notifyChange("valid");
  }
  get visible() {
    return !this._isEditTrackingField && (null != this.evaluatedVisibilityExpression ? this.evaluatedVisibilityExpression : null != this.element && false !== this.field?.visible || this._isVisibleByDefault);
  }
  _arcadeOutputToDateFieldValue(e13) {
    const i11 = this.field.type;
    try {
      if ("object" == typeof e13) {
        if (null === e13) return null;
        if (J3(e13)) return H2(e13, i11);
        if ("getTime" in e13 && "function" == typeof e13.getTime && "date" === i11) return parseInt(e13.getTime(), 10);
        if ("date-only" === i11 || "time-only" === i11 || "timestamp-offset" === i11) return e13.toString();
      } else {
        if ("string" == typeof e13) return "date" === i11 ? parseInt(e13, 10) : e13;
        if ("number" == typeof e13 && "date" === i11) return e13;
      }
      throw new s2("feature-form:invalid-date-value");
    } catch {
      return "date" === i11 ? NaN : "";
    }
  }
  _isDomainCompatible(e13) {
    const { field: t3 } = this;
    if ("coded-value" === e13?.type) {
      const i11 = typeof e13.codedValues[0].code;
      if ("string" === i11 && Fe(t3) || "number" === i11 && ge(t3)) return true;
    }
    return !!("range" === e13?.type && ge(t3) || $(t3) || xe(t3));
  }
  _validate() {
    const { dataType: e13, domain: t3, field: i11, minLength: l10, range: n17, required: r10, value: s18, maxLength: u5 } = this;
    return s8(s18, { dataType: e13, domain: t3, field: i11, maxLength: u5, minLength: l10, range: n17, required: r10 });
  }
};
r([m()], M2.prototype, "_dateFormRange", null), r([m()], M2.prototype, "_dateRange", null), r([m()], M2.prototype, "_storedValue", void 0), r([m()], M2.prototype, "_configAllowsEdits", null), r([m()], M2.prototype, "_layerAndFieldAllowEdits", null), r([m()], M2.prototype, "_isVisibleByDefault", null), r([m()], M2.prototype, "_isEditTrackingField", null), r([m()], M2.prototype, "_shouldUseValueExpression", null), r([m()], M2.prototype, "isSubtypeField", null), r([m()], M2.prototype, "valueIsOutOfDomain", null), r([m()], M2.prototype, "dataType", null), r([m()], M2.prototype, "dateDataType", null), r([m()], M2.prototype, "domain", null), r([m()], M2.prototype, "editable", null), r([m({ readOnly: true })], M2.prototype, "error", void 0), r([m({ constructOnly: true })], M2.prototype, "preservesValueWhenHidden", void 0), r([m()], M2.prototype, "evaluatedRequiredExpression", null), r([m()], M2.prototype, "evaluatedValueExpression", null), r([m()], M2.prototype, "field", void 0), r([m()], M2.prototype, "group", void 0), r([m({ readOnly: true })], M2.prototype, "hint", null), r([m()], M2.prototype, "includeDate", null), r([m()], M2.prototype, "includeTime", null), r([m()], M2.prototype, "includeTimeOffset", null), r([m()], M2.prototype, "initialFeature", null), r([m({ readOnly: true })], M2.prototype, "inputType", null), r([m()], M2.prototype, "hasInvalidSwitchValue", null), r([m()], M2.prototype, "isRelationshipKeyField", null), r([m()], M2.prototype, "label", null), r([m()], M2.prototype, "maxLength", null), r([m()], M2.prototype, "minLength", null), r([m({ readOnly: true })], M2.prototype, "name", null), r([m()], M2.prototype, "range", null), r([m()], M2.prototype, "required", null), r([m()], M2.prototype, "requiredExpressionExecutor", void 0), r([m()], M2.prototype, "showNoValueOptionEnabled", null), r([m()], M2.prototype, "submittable", null), r([m()], M2.prototype, "timeResolution", null), r([m()], M2.prototype, "timeStep", null), r([m({ readOnly: true })], M2.prototype, "type", void 0), r([m()], M2.prototype, "updating", null), r([m()], M2.prototype, "valid", null), r([m({ value: null })], M2.prototype, "value", null), r([m()], M2.prototype, "valueExpressionExecutor", void 0), r([m()], M2.prototype, "visible", null), M2 = r([a2("esri.widgets.FeatureForm.FieldInput")], M2);
var O3 = M2;

// node_modules/@arcgis/core/widgets/FeatureTable/Grid/EditorColumn.js
var l8 = { showInput: "Enter", hideInput: "Escape" };
var r5 = class extends m4 {
  constructor(t3) {
    super(t3), this.editInfo = null, this.cellValueValidatorFunction = ({ oldValue: t4, value: e13 }) => t4 !== e13, this.editable = true, this.headerRenderFunction = (t4) => {
      const { root: e13 } = t4, n17 = this.createHeaderContent();
      this.tableEditingEnabled && !this.effectiveEditable && n17.prepend(this._lockIconNode), this.removeCellContent(e13), e13.appendChild(n17);
    }, this.inputRenderFunction = ({ root: t4, column: e13, rowData: n17 }) => {
      if (this.editInfo || !this.effectiveEditable || !n17) return;
      const o5 = this.getCellValue(n17), i11 = this.createInputElement({ value: o5 });
      this._set("editInfo", { column: e13, inputs: [i11], root: t4, rowData: n17, oldValue: o5 });
      const l10 = document.createElement("div");
      l10.appendChild(i11), this.removeCellContent(t4), t4.appendChild(l10), i11.focus(), i11 instanceof HTMLInputElement && i11.select();
    }, this.loadingMessage = "", this.inputType = "text", this.maxLength = null, this.onShowPromptCallback = () => {
    }, this.parseInputValueFunction = ({ inputs: t4 }) => t4?.length || 1 !== t4.length || Array.isArray(t4[0].value) ? null : t4[0].value, this.renderFunction = (t4) => {
      const { root: e13, rowData: n17 } = t4, { editInfo: o5 } = this;
      if (o5) return;
      const r10 = this.getCellValue(n17), s18 = this.cellValueFormatFunction({ root: e13, rowData: n17, value: r10 });
      let a17 = null;
      e13.onclick = () => e13.focus(), e13.ondblclick = () => this.inputRenderFunction(t4), e13.ontouchend = () => this.inputRenderFunction(t4);
      const c13 = this.grid?.getSlotElementByName(e13.slot), u5 = c13?.parentElement;
      u5 && !u5.onkeydown && (u5.onkeydown = (e14) => {
        e14.key !== l8.showInput || this.editInfo || this.inputRenderFunction(t4), e14.key === l8.hideInput && this.editInfo && this.cancel();
      }), null != r10 && null != s18 ? e13.title = s18.toString() : e13.title && e13.removeAttribute("title"), a17 = s18 instanceof HTMLElement ? s18 : a5(this.messagesURIUtils, s18), this.removeCellContent(e13), a17 instanceof HTMLElement ? e13.appendChild(a17) : null != a17 && (e13.innerHTML = a17.toString());
    }, this.required = false, this.tableEditingEnabled = false;
  }
  get _lockIconNode() {
    return this.createCalciteIcon({ icon: "lock", textLabel: this.messages?.editingPreventedColumn });
  }
  get effectiveEditable() {
    return this.tableEditingEnabled && this.editable;
  }
  get effectiveRequired() {
    return this.required;
  }
  get editing() {
    return !!this.editInfo;
  }
  get shouldShowPrompt() {
    return false;
  }
  cancel() {
    const { editInfo: t3 } = this;
    if (!t3) return;
    const { column: e13, root: n17, rowData: o5 } = t3;
    this.onEditComplete(), this.renderFunction({ column: e13, root: n17, rowData: o5 });
  }
  createCalciteOption(t3, e13, n17 = false) {
    const o5 = document.createElement("calcite-option");
    return o5.label = t3, o5.value = `${e13}`, o5.selected = n17, o5;
  }
  createCalciteSelect(t3, e13) {
    const { effectiveRequired: n17, messages: o5 } = this;
    let i11 = false;
    const l10 = e13.map(({ name: e14, value: n18 }) => {
      const o6 = n18 === t3;
      return o6 && (i11 = true), this.createCalciteOption(e14, n18, o6);
    });
    if (null != t3 && "" !== t3 && !i11) {
      const e14 = t3.toString(), n18 = this.createCalciteOption(e14, e14);
      l10.unshift(n18);
    }
    n17 || l10.unshift(this.createCalciteOption(`<${o5?.noValue}>`, ""));
    const r10 = document.createElement("calcite-select");
    return l10.forEach((t4) => r10.appendChild(t4)), r10;
  }
  createInputElement({ value: t3 }) {
    const { effectiveRequired: e13, maxLength: n17 } = this, o5 = document.createElement("calcite-input");
    return null != n17 && (o5.maxLength = n17), o5.required = e13, o5.value = t3, o5.addEventListener("calciteInputChange", () => this.onInputBlur(o5)), o5.onkeydown = (t4) => {
      t4.key === l8.hideInput && this.onInputBlur(o5, true);
    }, o5.onblur = () => this.onInputBlur(o5), o5;
  }
  createDateComponent() {
    const t3 = document.createElement("calcite-input-date-picker");
    return t3.focusTrapDisabled = true, t3.overlayPositioning = "fixed", t3;
  }
  createTimeComponent() {
    const t3 = document.createElement("calcite-input-time-picker");
    return t3.overlayPositioning = "fixed", t3.placement = "auto-start", t3.step = 1, t3;
  }
  createTimeZoneComponent() {
    const t3 = document.createElement("calcite-input-time-zone");
    return t3.maxItems = 4, t3.overlayPositioning = "fixed", t3;
  }
  onEditComplete() {
    this._set("editInfo", null), this.grid?.generateCellPartNames();
  }
  onInputBlur(t3, e13 = false) {
    t3.onblur = null, e13 ? this.cancel() : this.submit();
  }
  submit() {
    return __async(this, null, function* () {
      const { editInfo: t3 } = this;
      if (!t3) return void this.cancel();
      const { inputs: e13, rowData: n17, oldValue: o5 } = t3, i11 = this.parseInputValueFunction({ inputs: e13 });
      if (!this.cellValueValidatorFunction({ value: i11, oldValue: o5 })) return void this.cancel();
      const { root: l10 } = t3, r10 = n17.item.objectId, { fieldName: s18 } = this;
      l10.textContent = this.loadingMessage, this.shouldShowPrompt ? this.onShowPromptCallback({ column: this, objectId: r10, oldValue: o5, value: i11 }) : yield this.updateItems({ objectId: r10, updates: [{ fieldName: s18, value: i11 }] });
    });
  }
  updateItems(t3) {
    return __async(this, null, function* () {
      const { store: e13 } = this;
      if (e13) try {
        yield e13.updateItem(t3), this.onEditComplete();
      } catch {
        this.cancel();
      }
      else this.cancel();
    });
  }
};
r([m()], r5.prototype, "_lockIconNode", null), r([m({ readOnly: true })], r5.prototype, "editInfo", void 0), r([m()], r5.prototype, "cellValueValidatorFunction", void 0), r([m()], r5.prototype, "editable", void 0), r([m()], r5.prototype, "effectiveEditable", null), r([m()], r5.prototype, "effectiveRequired", null), r([m()], r5.prototype, "editing", null), r([m()], r5.prototype, "headerRenderFunction", void 0), r([m()], r5.prototype, "inputRenderFunction", void 0), r([m({ constructOnly: true })], r5.prototype, "loadingMessage", void 0), r([m()], r5.prototype, "inputType", void 0), r([m()], r5.prototype, "maxLength", void 0), r([m()], r5.prototype, "onShowPromptCallback", void 0), r([m()], r5.prototype, "parseInputValueFunction", void 0), r([m()], r5.prototype, "renderFunction", void 0), r([m()], r5.prototype, "required", void 0), r([m()], r5.prototype, "shouldShowPrompt", null), r([m()], r5.prototype, "tableEditingEnabled", void 0), r5 = r([a2("esri.widgets.FeatureTable.Grid.EditorColumn")], r5);
var s12 = r5;

// node_modules/@arcgis/core/widgets/FeatureTable/FieldColumn.js
var S2 = { cancelEdit: "Escape" };
var N2 = "esri-column";
var A3 = { input: `${N2}__cell-input`, inputContainer: `${N2}__cell__input-container` };
var U = j("short-date-short-time");
var q = j("short-date");
var k3 = { useGrouping: true, maximumFractionDigits: 20 };
var z = class extends s12 {
  constructor(e13) {
    super(e13), this._activeFieldInput = null, this.cellValueFormatFunction = ({ root: e14, rowData: t3, value: i11 }) => {
      const { formatFunction: n17 } = this;
      if (n17 && t3) {
        const { index: o6, item: { attachments: l10, feature: r10, relatedRecords: a18 } } = t3;
        return n17({ attachments: l10, column: this, feature: r10, field: this.field, index: o6, relatedRecords: a18, value: A2.sanitize(i11), virtualIndex: this.getVirtualRowIndex(e14) });
      }
      if (null === i11) return "&nbsp;";
      const { field: o5 } = this, a17 = this._getDomainForFeature(t3?.item?.feature);
      if (a17) {
        const e15 = this._getComputedDomain(i11, a17);
        if ("date" === o5.type && "range" === a17.type) return this._formatDateValueForDisplay(o5, e15);
        if (this._isNumericField && "range" === a17.type) {
          const e16 = this.template?.format, t4 = e16 ? i3(e16) : k3;
          return l(parseFloat(i11), t4);
        }
        return x.has(o5.type) ? "range" === a17.type ? A2.sanitize(T3(o5, e15)) : A2.sanitize(e15) : e15;
      }
      if ("date" === o5.type || x.has(o5.type)) return this._formatDateValueForDisplay(o5, i11);
      if (this._isNumericField) {
        const e15 = this.template?.format, t4 = e15 ? i3(e15) : k3;
        return l(parseFloat(i11), t4);
      }
      return A2.sanitize(i11);
    }, this.cellValueValidatorFunction = ({ oldValue: e14, value: i11 }) => {
      const { _effectiveRange: n17, field: o5 } = this, { max: l10, min: r10 } = n17;
      if (this.effectiveRequired && (null == i11 || "" === i11)) return false;
      if (this._isNumericField && (Se(o5, i11) || !k2({ max: l10, min: r10, value: i11 }))) return n.getLogger(this).warn("value-exceeds-valid-range", "Field value exceeds valid range. Attempted edit was rejected."), false;
      if (this._isAnyDateOrTimeField) {
        const e15 = o5.type;
        if (!R({ type: e15, range: n17, value: i11 })) return false;
      }
      return e14 !== i11;
    }, this.field = null, this.formatFunction = null, this.inputRenderFunction = (_0) => __async(this, [_0], function* ({ root: e14, column: i11, rowData: n17 }) {
      if (this.editInfo || !this.effectiveEditable) return;
      const o5 = this.getCellValue(n17), { field: l10 } = this;
      if ("big-integer" === l10.type && Se(l10, o5)) return void n.getLogger(this).warn("value-exceeds-valid-range", "Field value is beyond supported limit. Editing is disabled for this field value.");
      const r10 = n17?.item.feature;
      if (!r10) return;
      this._activeFieldInput = this._setUpFieldInput(r10, o5);
      const a17 = document.createElement("div");
      a17.classList.add(A3.inputContainer);
      const s18 = [], u5 = "coded-value" === this._effectiveDomain?.type;
      if (this._isAnyDateOrTimeField && !u5) {
        const e15 = document.createElement("div"), t3 = this._setUpDateComponents(o5), i12 = this._setUpDateActionBar();
        t3.forEach((t4) => e15.appendChild(t4)), a17.appendChild(e15), a17.appendChild(i12), s18.push(...t3);
      } else {
        const e15 = this.createInputElement({ value: o5 });
        a17.appendChild(e15), s18.push(e15);
      }
      this._set("editInfo", { column: i11, inputs: s18, root: e14, rowData: n17, oldValue: o5 }), this.removeCellContent(e14), e14.appendChild(a17), this._syncRowEditingState(e14, true), this.grid?.generateCellPartNames();
      const d6 = s18[0];
      yield T(d6), "selectText" in d6 && (yield d6.selectText());
    }), this.layer = null, this.parseInputValueFunction = ({ inputs: e14 }) => {
      const { editInfo: t3, field: i11, includeTime: n17 } = this;
      if (!t3 || !e14.length) return null;
      const o5 = e14[0];
      if (this._isAnyDateOrTimeField) {
        if ("coded-value" === this._effectiveDomain?.type) {
          if (null == o5.value) return null;
          const e15 = String(o5.value);
          return Ie(i11) ? parseFloat(e15) : e15;
        }
        const { timeZone: l11 } = this.effectiveTimeZoneOptions, r11 = t3.oldValue ?? void 0;
        switch (i11.type) {
          case "date-only": {
            const e15 = o5.value;
            return "" !== e15 ? e15 : null;
          }
          case "time-only": {
            const e15 = E(o5.value);
            return "" !== e15 ? e15 : null;
          }
          case "timestamp-offset": {
            const t4 = n17 ? e14[1] : void 0, i12 = e14.at(-1);
            return b2({ oldValue: r11, dateComponent: o5, timeComponent: t4, timeZoneComponent: i12, defaultTimeZone: l11 });
          }
          case "date": {
            const { max: t4, min: i12 } = this._effectiveRange;
            return N({ oldValue: r11, dateComponent: o5, timeComponent: e14[1], timeZone: l11, max: t4, min: i12 });
          }
        }
        return null;
      }
      const l10 = o5.value, { effectiveRequired: r10 } = this;
      return r10 || null != l10 && "" !== l10 ? this._isNumericField ? parseFloat(l10) : this._isStringField ? l10.trim() : l10 : null;
    }, this.sortable = true, this.store = null, this.template = null, this.view = null;
  }
  get _effectiveDomain() {
    const e13 = this._activeFieldInput?.feature;
    return e13 ? this._getDomainForFeature(e13) : null;
  }
  get _effectiveRange() {
    return this._activeFieldInput?.range ?? { max: null, min: null };
  }
  get _isAnyDateOrTimeField() {
    const { field: e13 } = this;
    return $(e13) || xe(e13);
  }
  get _isIntegerField() {
    return ye(this.field);
  }
  get _isNumericField() {
    return ge(this.field);
  }
  get _isStringField() {
    return Fe(this.field);
  }
  get _isSubtypeField() {
    const { layer: e13 } = this;
    if (e13?.subtypeField) {
      const { subtypeField: t3, fieldsIndex: i11 } = e13;
      return (i11.get(t3)?.name ?? t3) === this.fieldName;
    }
    return false;
  }
  get alias() {
    return this.field?.alias;
  }
  get defaultValue() {
    return this.field?.defaultValue;
  }
  get effectiveDescription() {
    const { description: e13, field: t3 } = this, i11 = t3.description, n17 = y4(e13) ? y4(i11) ? null : i11 : e13;
    return null == n17 ? null : A2.sanitize(n17);
  }
  get effectiveEditable() {
    const { editable: e13, field: t3, layer: i11, tableEditingEnabled: n17 } = this;
    if (!t3 || !i11) return false;
    const o5 = e8(i11), l10 = i11.effectiveCapabilities ?? i11.capabilities, r10 = l10?.operations?.supportsUpdate;
    return !!(t3.editable && o5 && r10 && "oid" !== t3.type && n17) && e13;
  }
  get effectiveLabel() {
    return A2.sanitize(this.label || this.alias || this.fieldName);
  }
  get effectiveRequired() {
    return !this.nullable || this._isSubtypeField || this._activeFieldInput?.required || this.required;
  }
  get effectiveTimeZoneOptions() {
    const { layer: e13, field: t3 } = this;
    if (!e13 || "date" !== t3?.type && "timestamp-offset" !== t3?.type) return { timeZone: void 0, timeZoneName: void 0 };
    const { tableTimeZone: i11, timeZone: n17, view: l10 } = this;
    return h2(e13.preferredTimeZone || null, !!e13.datesInUnknownTimezone, n17 ?? i11 ?? l10?.timeZone ?? e2, j("short-time"), t3.type);
  }
  get includeTime() {
    const { field: e13, template: t3 } = this;
    return "time-only" === e13.type || "date-only" !== e13.type && (!t3?.input || "includeTime" in t3.input && false !== t3.input.includeTime);
  }
  get loadingMessage() {
    return this.messages?.loading || "...";
  }
  get maxLength() {
    const { field: e13, template: t3 } = this, i11 = e13?.length ?? -1, n17 = t3?.input && "maxLength" in t3.input ? t3.input.maxLength : null;
    return null != n17 && !isNaN(n17) && n17 >= -1 && (-1 === i11 || n17 <= i11) ? n17 : i11;
  }
  get minLength() {
    const { template: e13, maxLength: t3 } = this, i11 = e13?.input && "minLength" in e13.input ? e13.input.minLength : null;
    return t3 && i11 <= t3 ? i11 : null;
  }
  get name() {
    return this.field?.name;
  }
  get nullable() {
    return false !== this.field.nullable;
  }
  get shouldShowPrompt() {
    return this._isSubtypeField;
  }
  createInputElement({ value: e13 }) {
    const { _effectiveDomain: t3, maxLength: i11, minLength: n17, effectiveRequired: o5 } = this;
    let l10;
    if ("coded-value" === t3?.type) l10 = this.createCalciteSelect(e13, t3.codedValues.map(({ code: e14, name: t4 }) => ({ value: e14, name: t4 }))), l10.addEventListener("calciteSelectChange", () => this.onInputBlur(l10));
    else if (this._isNumericField) {
      const { _effectiveRange: { max: t4, min: i12 } } = this;
      l10 = document.createElement("calcite-input"), l10.type = "number", this._isIntegerField && (l10.step = 1), null != t4 && (l10.max = t4), null != i12 && (l10.min = i12), l10.status = k2({ max: t4, min: i12, value: e13 }) ? "idle" : "invalid";
    } else l10 = document.createElement("calcite-input"), l10.addEventListener("calciteInputChange", () => this.onInputBlur(l10)), i11 > -1 && (l10.maxLength = i11), n17 > 0 && (l10.minLength = n17);
    return l10.classList.add(A3.input), l10.required = o5, l10.value = null != e13 ? e13.toString() : "", l10.onkeydown = (e14) => {
      e14.key === S2.cancelEdit && this.onInputBlur(l10, true);
    }, l10.onblur = () => this.onInputBlur(l10), l10;
  }
  onEditComplete() {
    const e13 = this.editInfo?.root;
    e13 && this._syncRowEditingState(e13, false), this._activeFieldInput = null, super.onEditComplete();
  }
  _clearActiveEditValues() {
    this.editInfo?.inputs?.forEach((e13) => e13.value = "");
  }
  _setUpDateActionBar() {
    const { messagesCommon: e13 } = this, t3 = e13?.cancel ?? "", i11 = e13?.clear ?? "", n17 = e13?.save ?? "", o5 = document.createElement("calcite-action-bar");
    return o5.expandDisabled = true, o5.layout = "horizontal", o5.appendChild(this.createCalciteAction({ text: n17, icon: "save", onclick: () => this.submit() })), this.effectiveRequired || o5.appendChild(this.createCalciteAction({ text: i11, icon: "trash", onclick: () => {
      this._clearActiveEditValues(), this.submit();
    } })), o5.appendChild(this.createCalciteAction({ text: t3, icon: "x", onclick: () => this.cancel() })), o5;
  }
  _formatDateValueForDisplay(e13, t3) {
    const { timeZone: i11, timeZoneName: n17 } = this.effectiveTimeZoneOptions;
    return null != t3 ? T3(e13, t3, __spreadProps(__spreadValues({}, this._getDateFormatOptions()), { timeZone: i11, timeZoneName: n17 })) : null;
  }
  _setUpDateComponents(e13) {
    const { _effectiveRange: { max: t3, min: i11, rawMax: n17, rawMin: o5 }, field: l10, effectiveRequired: r10 } = this, a17 = this._getDateFieldValuesForComponents(l10, e13), s18 = [];
    if ($(l10)) {
      const e14 = this.createDateComponent(), u5 = be(l10) || we(l10) ? n17 : t3, p14 = be(l10) || we(l10) ? o5 : i11, d6 = this._getDateFieldValuesForComponents(l10, u5 ?? null), c13 = this._getDateFieldValuesForComponents(l10, p14 ?? null);
      e14.value = a17.date ?? "", e14.max = d6.date ?? "", e14.min = c13.date ?? "", e14.required = r10, e14.addEventListener("calciteInputDatePickerOpen", () => this._onDateComponentOpen(e14)), s18.push(e14);
    }
    if (this.includeTime) {
      const e14 = this.createTimeComponent();
      e14.value = a17.time ?? "", e14.required = r10, e14.addEventListener("calciteInputTimePickerOpen", () => this._onDateComponentOpen(e14)), s18.push(e14);
    }
    if ("timestamp-offset" === l10.type) {
      const e14 = this.createTimeZoneComponent();
      e14.value = a17.timeZoneOffset ?? "0", e14.addEventListener("calciteInputTimeZoneOpen", () => this._onDateComponentOpen(e14)), s18.push(e14);
    }
    return s18;
  }
  _onDateComponentOpen(e13) {
    this.editInfo?.inputs.forEach((t3) => {
      t3 !== e13 && "open" in t3 && (t3.open = false);
    });
  }
  _syncRowEditingState(e13, t3 = false) {
    const i11 = this.grid?.getRowContainingNode(e13);
    i11 && (t3 ? i11.setAttribute("editing", "true") : i11.removeAttribute("editing"));
  }
  _getDateFieldValuesForComponents(e13, t3) {
    switch (e13.type) {
      case "date":
        return C2(t3, this.effectiveTimeZoneOptions.timeZone);
      case "date-only":
        return { date: t3 };
      case "time-only":
        return { time: t3 };
      case "timestamp-offset":
        return V2(t3);
      default:
        return {};
    }
  }
  _setUpFieldInput(e13, t3) {
    const { field: i11, layer: n17, effectiveTimeZoneOptions: { timeZone: o5 } } = this, l10 = new O3({ feature: e13, field: i11, initialFeature: e13.clone(), layer: n17, timeZone: o5 });
    return l10.set("value", t3), l10;
  }
  _isDomainCompatible(e13) {
    if (!e13) return false;
    const { _isNumericField: t3, _isStringField: i11 } = this, { type: n17 } = e13;
    if ("coded-value" === n17) {
      const n18 = typeof e13.codedValues[0].code;
      if ("string" === n18 && i11 || "number" === n18 && t3) return true;
    }
    return !("range" !== n17 || !t3);
  }
  _getDomainForFeature(e13) {
    const { fieldName: t3, layer: i11, template: n17 } = this;
    if (!e13 || !i11?.getFieldDomain) return null;
    if ("wfs" === i11.type || "geojson" === i11.type || "csv" === i11.type || "knowledge-graph-sublayer" === i11.type) return null;
    if (n17?.domain && this._isDomainCompatible(n17.domain)) return n17.domain;
    if ("feature" !== i11.type && "subtype-group" !== i11.type && null == i11.getField(t3)?.domain) {
      const e14 = G2(i11, t3);
      if (e14) return e14;
    }
    return i11.getFieldDomain(t3, { feature: e13 });
  }
  _getComputedDomain(e13, t3) {
    if (!t3) return null;
    if ("range" === t3.type) return e13;
    if ("coded-value" === t3.type) {
      const i11 = t3.codedValues.filter((t4) => t4.hasOwnProperty("code") && t4.code === e13);
      return i11 && i11.length ? i11[0].name : e13;
    }
    return null;
  }
  _getDateFormatOptions() {
    const { template: e13 } = this, t3 = e13?.format?.dateFormat;
    return t3 ? j(t3) : e13?.input && "includeTime" in e13.input && false === e13.input.includeTime ? q : U;
  }
};
r([m()], z.prototype, "_effectiveDomain", null), r([m()], z.prototype, "_activeFieldInput", void 0), r([m()], z.prototype, "_effectiveRange", null), r([m()], z.prototype, "_isAnyDateOrTimeField", null), r([m()], z.prototype, "_isIntegerField", null), r([m()], z.prototype, "_isNumericField", null), r([m()], z.prototype, "_isStringField", null), r([m()], z.prototype, "_isSubtypeField", null), r([m({ readOnly: true })], z.prototype, "alias", null), r([m()], z.prototype, "cellValueFormatFunction", void 0), r([m()], z.prototype, "cellValueValidatorFunction", void 0), r([m({ readOnly: true })], z.prototype, "defaultValue", null), r([m()], z.prototype, "effectiveDescription", null), r([m()], z.prototype, "effectiveEditable", null), r([m()], z.prototype, "effectiveLabel", null), r([m()], z.prototype, "effectiveRequired", null), r([m()], z.prototype, "effectiveTimeZoneOptions", null), r([m({ type: y3 })], z.prototype, "field", void 0), r([m()], z.prototype, "formatFunction", void 0), r([m()], z.prototype, "includeTime", null), r([m()], z.prototype, "inputRenderFunction", void 0), r([m()], z.prototype, "layer", void 0), r([m({ readOnly: true })], z.prototype, "loadingMessage", null), r([m()], z.prototype, "maxLength", null), r([m()], z.prototype, "minLength", null), r([m({ readOnly: true })], z.prototype, "name", null), r([m({ readOnly: true })], z.prototype, "nullable", null), r([m()], z.prototype, "parseInputValueFunction", void 0), r([m()], z.prototype, "shouldShowPrompt", null), r([m()], z.prototype, "sortable", void 0), r([m()], z.prototype, "store", void 0), r([m()], z.prototype, "template", void 0), r([m()], z.prototype, "view", void 0), z = r([a2("esri.widgets.FeatureTable.FieldColumn")], z);
var B2 = z;

// node_modules/@arcgis/core/widgets/FeatureTable/RelationshipColumn.js
var a11 = { showRecordsButton: "esri-column__show-related-records-button" };
var p7 = class extends m4 {
  constructor(t3) {
    super(t3), this.flexGrow = 1, this.icon = "link", this.layer = null, this.relatedLayer = null, this.relationshipId = null, this.renderFunction = ({ root: t4, rowData: e13 }) => {
      if (!e13) return;
      const o5 = e13.item, { layer: r10, relatedLayer: n17 } = this;
      if (!o5?.feature || !p6(r10) || !p6(n17)) return;
      const { messages: p14 } = this, { index: c13 } = e13, { feature: d6, objectId: h8 } = o5, { collapsed: u5, showRelatedTableCallback: b5, relationshipId: m8 } = this, y5 = o5.relatedRecords, f7 = y5?.find((t5) => t5.relationshipId === m8)?.count ?? 0, C5 = !u5 && b5 && p14?.recordsCount ? s4(p14.recordsCount, { count: f7 }) : `${f7}`, g6 = (t5) => {
        t5.preventDefault(), u5 || this.showRelatedTableCallback?.({ feature: d6, index: c13, layer: r10, objectId: h8, relatedLayer: n17, relationshipId: m8 });
      }, w5 = u5 ? "" : "chevron-right";
      if (t4.firstChild) {
        const e14 = t4.firstChild;
        return e14.textContent = C5, e14.onclick = g6, void (e14.iconEnd = w5);
      }
      const v3 = this.createCalciteButton({ className: `${a11.showRecordsButton} ${n10.contentFull}`, iconEnd: w5, iconFlipRtl: "both", scale: "m", textContent: C5, title: C5, onclick: g6 });
      this.removeCellContent(t4), t4.appendChild(v3);
    }, this.resizable = true, this.showRelatedTableCallback = null, this.textAlign = "center", this.width = "200px";
  }
  get _relationshipLabel() {
    return this.label || this.originRelationship?.name || this.layer.title || "";
  }
  get collapsed() {
    return this._get("collapsed") || false;
  }
  set collapsed(t3) {
    t3 ? this.set({ flexGrow: 0, resizable: false, width: "80px" }) : this.set({ flexGrow: 1, resizable: true, width: "200px" }), this._set("collapsed", t3);
  }
  get effectiveLabel() {
    return this.collapsed ? "" : this._relationshipLabel;
  }
  get iconNode() {
    const { icon: t3 } = this;
    return t3 ? this.createCalciteIcon({ icon: t3, textLabel: this._relationshipLabel }) : null;
  }
  get originRelationship() {
    const t3 = this.relationshipId;
    return this.relatedLayer.relationships?.find(({ id: e13 }) => e13 === t3);
  }
  get relationship() {
    return h4(this.layer, this.relationshipId);
  }
};
r([m()], p7.prototype, "_relationshipLabel", null), r([m()], p7.prototype, "collapsed", null), r([m()], p7.prototype, "effectiveLabel", null), r([m()], p7.prototype, "flexGrow", void 0), r([m()], p7.prototype, "icon", void 0), r([m()], p7.prototype, "iconNode", null), r([m()], p7.prototype, "layer", void 0), r([m()], p7.prototype, "originRelationship", null), r([m()], p7.prototype, "relatedLayer", void 0), r([m()], p7.prototype, "relationship", null), r([m()], p7.prototype, "relationshipId", void 0), r([m()], p7.prototype, "renderFunction", void 0), r([m()], p7.prototype, "resizable", void 0), r([m()], p7.prototype, "showRelatedTableCallback", void 0), r([m()], p7.prototype, "textAlign", void 0), r([m()], p7.prototype, "width", void 0), p7 = r([a2("esri.widgets.FeatureTable.RelationshipColumn")], p7);
var c11 = p7;

// node_modules/@vaadin/component-base/src/define.js
window.Vaadin ||= {};
window.Vaadin.featureFlags ||= {};
function dashToCamelCase(dash) {
  return dash.replace(/-[a-z]/gu, (m8) => m8[1].toUpperCase());
}
var experimentalMap = {};
function defineCustomElement(CustomElement, version2 = "24.6.9") {
  Object.defineProperty(CustomElement, "version", {
    get() {
      return version2;
    }
  });
  if (CustomElement.experimental) {
    const featureFlagKey = typeof CustomElement.experimental === "string" ? CustomElement.experimental : `${dashToCamelCase(CustomElement.is.split("-").slice(1).join("-"))}Component`;
    if (!window.Vaadin.featureFlags[featureFlagKey] && !experimentalMap[featureFlagKey]) {
      experimentalMap[featureFlagKey] = /* @__PURE__ */ new Set();
      experimentalMap[featureFlagKey].add(CustomElement);
      Object.defineProperty(window.Vaadin.featureFlags, featureFlagKey, {
        get() {
          return experimentalMap[featureFlagKey].size === 0;
        },
        set(value) {
          if (!!value && experimentalMap[featureFlagKey].size > 0) {
            experimentalMap[featureFlagKey].forEach((elementClass) => {
              customElements.define(elementClass.is, elementClass);
            });
            experimentalMap[featureFlagKey].clear();
          }
        }
      });
      return;
    } else if (experimentalMap[featureFlagKey]) {
      experimentalMap[featureFlagKey].add(CustomElement);
      return;
    }
  }
  const defined = customElements.get(CustomElement.is);
  if (!defined) {
    customElements.define(CustomElement.is, CustomElement);
  } else {
    const definedVersion = defined.version;
    if (definedVersion && CustomElement.version && definedVersion === CustomElement.version) {
      console.warn(`The component ${CustomElement.is} has been loaded twice`);
    } else {
      console.error(
        `Tried to define ${CustomElement.is} version ${CustomElement.version} when version ${defined.version} is already in use. Something will probably break.`
      );
    }
  }
}

// node_modules/@vaadin/vaadin-lumo-styles/version.js
var Lumo = class extends HTMLElement {
  static get is() {
    return "vaadin-lumo-styles";
  }
};
defineCustomElement(Lumo);

// node_modules/@vaadin/vaadin-themable-mixin/vaadin-theme-property-mixin.js
var ThemePropertyMixin = (superClass) => class VaadinThemePropertyMixin extends superClass {
  static get properties() {
    return {
      /**
       * Helper property with theme attribute value facilitating propagation
       * in shadow DOM.
       *
       * Enables the component implementation to propagate the `theme`
       * attribute value to the sub-components in Shadow DOM by binding
       * the sub-component's "theme" attribute to the `theme` property of
       * the host.
       *
       * **NOTE:** Extending the mixin only provides the property for binding,
       * and does not make the propagation alone.
       *
       * See [Styling Components: Sub-components](https://vaadin.com/docs/latest/styling/styling-components/#sub-components).
       * page for more information.
       *
       * @protected
       */
      _theme: {
        type: String,
        readOnly: true
      }
    };
  }
  static get observedAttributes() {
    return [...super.observedAttributes, "theme"];
  }
  /** @protected */
  attributeChangedCallback(name, oldValue, newValue) {
    super.attributeChangedCallback(name, oldValue, newValue);
    if (name === "theme") {
      this._set_theme(newValue);
    }
  }
};

// node_modules/@vaadin/vaadin-themable-mixin/vaadin-themable-mixin.js
var themeRegistry = [];
var themableInstances = /* @__PURE__ */ new Set();
var themableTagNames = /* @__PURE__ */ new Set();
function classHasThemes(elementClass) {
  return elementClass && Object.prototype.hasOwnProperty.call(elementClass, "__themes");
}
function hasThemes(tagName) {
  return classHasThemes(customElements.get(tagName));
}
function flattenStyles(styles = []) {
  return [styles].flat(Infinity).filter((style2) => {
    if (style2 instanceof CSSResult) {
      return true;
    }
    console.warn("An item in styles is not of type CSSResult. Use `unsafeCSS` or `css`.");
    return false;
  });
}
function matchesThemeFor(themeFor, tagName) {
  return (themeFor || "").split(" ").some((themeForToken) => {
    return new RegExp(`^${themeForToken.split("*").join(".*")}$`, "u").test(tagName);
  });
}
function getCssText(styles) {
  return styles.map((style2) => style2.cssText).join("\n");
}
var STYLE_ID = "vaadin-themable-mixin-style";
function addStylesToTemplate(styles, template2) {
  const styleEl = document.createElement("style");
  styleEl.id = STYLE_ID;
  styleEl.textContent = getCssText(styles);
  template2.content.appendChild(styleEl);
}
function updateInstanceStyles(instance) {
  if (!instance.shadowRoot) {
    return;
  }
  const componentClass = instance.constructor;
  if (instance instanceof LitElement) {
    [...instance.shadowRoot.querySelectorAll("style")].forEach((style2) => style2.remove());
    adoptStyles(instance.shadowRoot, componentClass.elementStyles);
  } else {
    const style2 = instance.shadowRoot.getElementById(STYLE_ID);
    const template2 = componentClass.prototype._template;
    style2.textContent = template2.content.getElementById(STYLE_ID).textContent;
  }
}
function updateInstanceStylesOfType(componentClass) {
  themableInstances.forEach((ref) => {
    const instance = ref.deref();
    if (instance instanceof componentClass) {
      updateInstanceStyles(instance);
    } else if (!instance) {
      themableInstances.delete(ref);
    }
  });
}
function updateComponentStyles(componentClass) {
  if (componentClass.prototype instanceof LitElement) {
    componentClass.elementStyles = componentClass.finalizeStyles(componentClass.styles);
  } else {
    const template2 = componentClass.prototype._template;
    template2.content.getElementById(STYLE_ID).textContent = getCssText(componentClass.getStylesForThis());
  }
  themableTagNames.forEach((inheritingTagName) => {
    const inheritingClass = customElements.get(inheritingTagName);
    if (inheritingClass !== componentClass && inheritingClass.prototype instanceof componentClass) {
      updateComponentStyles(inheritingClass);
    }
  });
}
function hasMatchingStyle(componentClass, styles) {
  const themes = componentClass.__themes;
  if (!themes || !styles) {
    return false;
  }
  return themes.some(
    (theme) => theme.styles.some((themeStyle) => styles.some((style2) => style2.cssText === themeStyle.cssText))
  );
}
function registerStyles(themeFor, styles, options = {}) {
  styles = flattenStyles(styles);
  if (window.Vaadin && window.Vaadin.styleModules) {
    window.Vaadin.styleModules.registerStyles(themeFor, styles, options);
  } else {
    themeRegistry.push({
      themeFor,
      styles,
      include: options.include,
      moduleId: options.moduleId
    });
  }
  if (themeFor) {
    themableTagNames.forEach((tagName) => {
      if (matchesThemeFor(themeFor, tagName) && hasThemes(tagName)) {
        const componentClass = customElements.get(tagName);
        if (hasMatchingStyle(componentClass, styles)) {
          console.warn(`Registering styles that already exist for ${tagName}`);
        } else if (!window.Vaadin || !window.Vaadin.suppressPostFinalizeStylesWarning) {
          console.warn(
            `The custom element definition for "${tagName}" was finalized before a style module was registered. Ideally, import component specific style modules before importing the corresponding custom element. This warning can be suppressed by setting "window.Vaadin.suppressPostFinalizeStylesWarning = true".`
          );
        }
        updateComponentStyles(componentClass);
        updateInstanceStylesOfType(componentClass);
      }
    });
  }
}
function getAllThemes() {
  if (window.Vaadin && window.Vaadin.styleModules) {
    return window.Vaadin.styleModules.getAllThemes();
  }
  return themeRegistry;
}
function getIncludePriority(moduleName = "") {
  let includePriority = 0;
  if (moduleName.startsWith("lumo-") || moduleName.startsWith("material-")) {
    includePriority = 1;
  } else if (moduleName.startsWith("vaadin-")) {
    includePriority = 2;
  }
  return includePriority;
}
function getIncludedStyles(theme) {
  const includedStyles = [];
  if (theme.include) {
    [].concat(theme.include).forEach((includeModuleId) => {
      const includedTheme = getAllThemes().find((s18) => s18.moduleId === includeModuleId);
      if (includedTheme) {
        includedStyles.push(...getIncludedStyles(includedTheme), ...includedTheme.styles);
      } else {
        console.warn(`Included moduleId ${includeModuleId} not found in style registry`);
      }
    }, theme.styles);
  }
  return includedStyles;
}
function getThemes(tagName) {
  const defaultModuleName = `${tagName}-default-theme`;
  const themes = getAllThemes().filter((theme) => theme.moduleId !== defaultModuleName && matchesThemeFor(theme.themeFor, tagName)).map((theme) => __spreadProps(__spreadValues({}, theme), {
    // Prepend styles from included themes
    styles: [...getIncludedStyles(theme), ...theme.styles],
    // Map moduleId to includePriority
    includePriority: getIncludePriority(theme.moduleId)
  })).sort((themeA, themeB) => themeB.includePriority - themeA.includePriority);
  if (themes.length > 0) {
    return themes;
  }
  return getAllThemes().filter((theme) => theme.moduleId === defaultModuleName);
}
var ThemableMixin = (superClass) => class VaadinThemableMixin extends ThemePropertyMixin(superClass) {
  constructor() {
    super();
    themableInstances.add(new WeakRef(this));
  }
  /**
   * Covers PolymerElement based component styling
   * @protected
   */
  static finalize() {
    super.finalize();
    if (this.is) {
      themableTagNames.add(this.is);
    }
    if (this.elementStyles) {
      return;
    }
    const template2 = this.prototype._template;
    if (!template2 || classHasThemes(this)) {
      return;
    }
    addStylesToTemplate(this.getStylesForThis(), template2);
  }
  /**
   * Covers LitElement based component styling
   *
   * @protected
   */
  static finalizeStyles(styles) {
    const themeStyles = this.getStylesForThis();
    return styles ? [...[styles].flat(Infinity), ...themeStyles] : themeStyles;
  }
  /**
   * Get styles for the component type
   *
   * @private
   */
  static getStylesForThis() {
    const superClassThemes = superClass.__themes || [];
    const parent = Object.getPrototypeOf(this.prototype);
    const inheritedThemes = (parent ? parent.constructor.__themes : []) || [];
    this.__themes = [...superClassThemes, ...inheritedThemes, ...getThemes(this.is)];
    const themeStyles = this.__themes.flatMap((theme) => theme.styles);
    return themeStyles.filter((style2, index) => index === themeStyles.lastIndexOf(style2));
  }
};

// node_modules/@vaadin/vaadin-themable-mixin/register-styles.js
var addGlobalThemeStyles = (id, ...styles) => {
  const styleTag = document.createElement("style");
  styleTag.id = id;
  styleTag.textContent = styles.map((style2) => style2.toString()).join("\n").replace(":host", "html");
  document.head.insertAdjacentElement("afterbegin", styleTag);
};

// node_modules/@vaadin/vaadin-lumo-styles/global.js
var addLumoGlobalStyles = (id, ...styles) => {
  addGlobalThemeStyles(`lumo-${id}`, styles);
};

// node_modules/@vaadin/vaadin-lumo-styles/color.js
var colorBase = css`
  :host {
    /* Base (background) */
    --lumo-base-color: #fff;

    /* Tint */
    --lumo-tint-5pct: hsla(0, 0%, 100%, 0.3);
    --lumo-tint-10pct: hsla(0, 0%, 100%, 0.37);
    --lumo-tint-20pct: hsla(0, 0%, 100%, 0.44);
    --lumo-tint-30pct: hsla(0, 0%, 100%, 0.5);
    --lumo-tint-40pct: hsla(0, 0%, 100%, 0.57);
    --lumo-tint-50pct: hsla(0, 0%, 100%, 0.64);
    --lumo-tint-60pct: hsla(0, 0%, 100%, 0.7);
    --lumo-tint-70pct: hsla(0, 0%, 100%, 0.77);
    --lumo-tint-80pct: hsla(0, 0%, 100%, 0.84);
    --lumo-tint-90pct: hsla(0, 0%, 100%, 0.9);
    --lumo-tint: #fff;

    /* Shade */
    --lumo-shade-5pct: hsla(214, 61%, 25%, 0.05);
    --lumo-shade-10pct: hsla(214, 57%, 24%, 0.1);
    --lumo-shade-20pct: hsla(214, 53%, 23%, 0.16);
    --lumo-shade-30pct: hsla(214, 50%, 22%, 0.26);
    --lumo-shade-40pct: hsla(214, 47%, 21%, 0.38);
    --lumo-shade-50pct: hsla(214, 45%, 20%, 0.52);
    --lumo-shade-60pct: hsla(214, 43%, 19%, 0.6);
    --lumo-shade-70pct: hsla(214, 42%, 18%, 0.69);
    --lumo-shade-80pct: hsla(214, 41%, 17%, 0.83);
    --lumo-shade-90pct: hsla(214, 40%, 16%, 0.94);
    --lumo-shade: hsl(214, 35%, 15%);

    /* Contrast */
    --lumo-contrast-5pct: var(--lumo-shade-5pct);
    --lumo-contrast-10pct: var(--lumo-shade-10pct);
    --lumo-contrast-20pct: var(--lumo-shade-20pct);
    --lumo-contrast-30pct: var(--lumo-shade-30pct);
    --lumo-contrast-40pct: var(--lumo-shade-40pct);
    --lumo-contrast-50pct: var(--lumo-shade-50pct);
    --lumo-contrast-60pct: var(--lumo-shade-60pct);
    --lumo-contrast-70pct: var(--lumo-shade-70pct);
    --lumo-contrast-80pct: var(--lumo-shade-80pct);
    --lumo-contrast-90pct: var(--lumo-shade-90pct);
    --lumo-contrast: var(--lumo-shade);

    /* Text */
    --lumo-header-text-color: var(--lumo-contrast);
    --lumo-body-text-color: var(--lumo-contrast-90pct);
    --lumo-secondary-text-color: var(--lumo-contrast-70pct);
    --lumo-tertiary-text-color: var(--lumo-contrast-50pct);
    --lumo-disabled-text-color: var(--lumo-contrast-30pct);

    /* Primary */
    --lumo-primary-color: hsl(214, 100%, 48%);
    --lumo-primary-color-50pct: hsla(214, 100%, 49%, 0.76);
    --lumo-primary-color-10pct: hsla(214, 100%, 60%, 0.13);
    --lumo-primary-text-color: hsl(214, 100%, 43%);
    --lumo-primary-contrast-color: #fff;

    /* Error */
    --lumo-error-color: hsl(3, 85%, 48%);
    --lumo-error-color-50pct: hsla(3, 85%, 49%, 0.5);
    --lumo-error-color-10pct: hsla(3, 85%, 49%, 0.1);
    --lumo-error-text-color: hsl(3, 89%, 42%);
    --lumo-error-contrast-color: #fff;

    /* Success */
    --lumo-success-color: hsl(145, 72%, 30%);
    --lumo-success-color-50pct: hsla(145, 72%, 31%, 0.5);
    --lumo-success-color-10pct: hsla(145, 72%, 31%, 0.1);
    --lumo-success-text-color: hsl(145, 85%, 25%);
    --lumo-success-contrast-color: #fff;

    /* Warning */
    --lumo-warning-color: hsl(48, 100%, 50%);
    --lumo-warning-color-10pct: hsla(48, 100%, 50%, 0.25);
    --lumo-warning-text-color: hsl(32, 100%, 30%);
    --lumo-warning-contrast-color: var(--lumo-shade-90pct);
  }

  /* forced-colors mode adjustments */
  @media (forced-colors: active) {
    html {
      --lumo-disabled-text-color: GrayText;
    }
  }
`;
addLumoGlobalStyles("color-props", colorBase);
var color = css`
  [theme~='dark'] {
    /* Base (background) */
    --lumo-base-color: hsl(214, 35%, 21%);

    /* Tint */
    --lumo-tint-5pct: hsla(214, 65%, 85%, 0.06);
    --lumo-tint-10pct: hsla(214, 60%, 80%, 0.14);
    --lumo-tint-20pct: hsla(214, 64%, 82%, 0.23);
    --lumo-tint-30pct: hsla(214, 69%, 84%, 0.32);
    --lumo-tint-40pct: hsla(214, 73%, 86%, 0.41);
    --lumo-tint-50pct: hsla(214, 78%, 88%, 0.5);
    --lumo-tint-60pct: hsla(214, 82%, 90%, 0.58);
    --lumo-tint-70pct: hsla(214, 87%, 92%, 0.69);
    --lumo-tint-80pct: hsla(214, 91%, 94%, 0.8);
    --lumo-tint-90pct: hsla(214, 96%, 96%, 0.9);
    --lumo-tint: hsl(214, 100%, 98%);

    /* Shade */
    --lumo-shade-5pct: hsla(214, 0%, 0%, 0.07);
    --lumo-shade-10pct: hsla(214, 4%, 2%, 0.15);
    --lumo-shade-20pct: hsla(214, 8%, 4%, 0.23);
    --lumo-shade-30pct: hsla(214, 12%, 6%, 0.32);
    --lumo-shade-40pct: hsla(214, 16%, 8%, 0.41);
    --lumo-shade-50pct: hsla(214, 20%, 10%, 0.5);
    --lumo-shade-60pct: hsla(214, 24%, 12%, 0.6);
    --lumo-shade-70pct: hsla(214, 28%, 13%, 0.7);
    --lumo-shade-80pct: hsla(214, 32%, 13%, 0.8);
    --lumo-shade-90pct: hsla(214, 33%, 13%, 0.9);
    --lumo-shade: hsl(214, 33%, 13%);

    /* Contrast */
    --lumo-contrast-5pct: var(--lumo-tint-5pct);
    --lumo-contrast-10pct: var(--lumo-tint-10pct);
    --lumo-contrast-20pct: var(--lumo-tint-20pct);
    --lumo-contrast-30pct: var(--lumo-tint-30pct);
    --lumo-contrast-40pct: var(--lumo-tint-40pct);
    --lumo-contrast-50pct: var(--lumo-tint-50pct);
    --lumo-contrast-60pct: var(--lumo-tint-60pct);
    --lumo-contrast-70pct: var(--lumo-tint-70pct);
    --lumo-contrast-80pct: var(--lumo-tint-80pct);
    --lumo-contrast-90pct: var(--lumo-tint-90pct);
    --lumo-contrast: var(--lumo-tint);

    /* Text */
    --lumo-header-text-color: var(--lumo-contrast);
    --lumo-body-text-color: var(--lumo-contrast-90pct);
    --lumo-secondary-text-color: var(--lumo-contrast-70pct);
    --lumo-tertiary-text-color: var(--lumo-contrast-50pct);
    --lumo-disabled-text-color: var(--lumo-contrast-30pct);

    /* Primary */
    --lumo-primary-color: hsl(214, 90%, 48%);
    --lumo-primary-color-50pct: hsla(214, 90%, 70%, 0.69);
    --lumo-primary-color-10pct: hsla(214, 90%, 55%, 0.13);
    --lumo-primary-text-color: hsl(214, 90%, 77%);
    --lumo-primary-contrast-color: #fff;

    /* Error */
    --lumo-error-color: hsl(3, 79%, 49%);
    --lumo-error-color-50pct: hsla(3, 75%, 62%, 0.5);
    --lumo-error-color-10pct: hsla(3, 75%, 62%, 0.14);
    --lumo-error-text-color: hsl(3, 100%, 80%);

    /* Success */
    --lumo-success-color: hsl(145, 72%, 30%);
    --lumo-success-color-50pct: hsla(145, 92%, 51%, 0.5);
    --lumo-success-color-10pct: hsla(145, 92%, 51%, 0.1);
    --lumo-success-text-color: hsl(145, 85%, 46%);

    /* Warning */
    --lumo-warning-color: hsl(43, 100%, 48%);
    --lumo-warning-color-10pct: hsla(40, 100%, 50%, 0.2);
    --lumo-warning-text-color: hsl(45, 100%, 60%);
    --lumo-warning-contrast-color: var(--lumo-shade-90pct);
  }

  html {
    color: var(--lumo-body-text-color);
    background-color: var(--lumo-base-color);
    color-scheme: light;
  }

  [theme~='dark'] {
    color: var(--lumo-body-text-color);
    background-color: var(--lumo-base-color);
    color-scheme: dark;
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    color: var(--lumo-header-text-color);
  }

  a:where(:any-link) {
    color: var(--lumo-primary-text-color);
  }

  a:not(:any-link) {
    color: var(--lumo-disabled-text-color);
  }

  blockquote {
    color: var(--lumo-secondary-text-color);
  }

  code,
  pre {
    background-color: var(--lumo-contrast-10pct);
    border-radius: var(--lumo-border-radius-m);
  }
  pre code {
    background: transparent;
  }
`;
registerStyles("", color, { moduleId: "lumo-color" });

// node_modules/@vaadin/vaadin-lumo-styles/font-icons.js
var fontIcons = css`
  @font-face {
    font-family: 'lumo-icons';
    src: url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAABHAAAsAAAAAI6AAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADsAAABUIIslek9TLzIAAAFEAAAAQwAAAFZAIUuNY21hcAAAAYgAAAD+AAADymne8hxnbHlmAAACiAAAC+gAABioIzlOlWhlYWQAAA5wAAAAMAAAADZa/6SsaGhlYQAADqAAAAAdAAAAJAbpA4BobXR4AAAOwAAAABAAAAC0q+AAAGxvY2EAAA7QAAAAXAAAAFyF7o1GbWF4cAAADywAAAAfAAAAIAFMAXBuYW1lAAAPTAAAATEAAAIuUUJZCHBvc3QAABCAAAABPQAAAgfdkltveJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBmg4gCACY7BUgAeJxjYGS+xDiBgZWBgamKaQ8DA0MPhGZ8wGDIyAQUZWBlZsAKAtJcUxgcXjG+0mEO+p/FEMUcxDANKMwIkgMABvgMMAB4nO3SV26EMABF0UsZpjG9d6Y3FpgF5StLYxMTP16WEUvHV1gGIQzQAJKgDFKIfojQ+A6rUb2e0KnXU77qPanWq/LzCXOkOVyn9RyHvWl4YkaTFu1wX5ecHn0GDBkxZsKUGXMWLFmxZsOWHXsOFBw5cebClRt3Hjx58dZ7RRn/I9cUF39Xpb691acRG2piOtUqNZ1P1TCdeJUZatNQW4baNtSO6U+ouoaam96u6hlq31AHhjo01JGhjg11YqhTQ50Z6txQF4a6NNSVoa4NdWOoW0PdGereUA+GWhjq0VBPhno21IuhXg31Zqh3Q30Y6tNQX4b6NtTSKH8BOIRpQQAAeJy1WH1sW9UVv+fG9vPz+7Bf/N6zHcd2/J04jbP6s0lap4kDpB9JWzUUCqxNgaHxpTI6hNhUNLVr17HSISb2D2iAJrWb6FTWahNQdQxRvmHamAR0qibE1E18CG3QaVNFvJ17n+3YIf1AiMQ679x77j3v3HPPPed3H7ER/OsYpw8TmQRIiuQJ8RZK+WjO1B3xaCzla21orY10a+OQ6aHTHtP0zB31mBs1GZ6RNU2uXc7oPL+xdRS9R9X1oK4fVfijdsBqvqF6vd1eLzPrYrYZ57WteF7bPDIc5+ZcJnta+S9i2Vfhs4MaMwZNQmO0Vv7gF/MZcNsCcJp4sJFSwYyAmRuFCmTBDRBUkwGqnlViyjmVBpLqaXhNpt0J5V1JOqMkuqn8WkMHvZX+iOlImiqkBiFVYDrCqINulmkwKb8ry2fkZBBn7FcTlk4ZdfpRZ9MOesLSAakKt0N3g4p2jAL8eIEOOqom/U0lgQRXUl8LtXM7HFkojUIpF0ErVBhcZC1vtyjtpsqr83a8RVcSH+ool8LgcIMjNohmVCACuDs506BdO6WIQeXjUsh1XKZGRNpp9piv3+Givoh00OU6KEV81HUHTLtN093Q+YGlE3wLHWRtMNy9XWqdLm2HKbaNsGzhu+41eswFOjE6WKSk2/1Wpt+qHeM6phbohmVmj3GvpdcVkiy9zbXfzHVqKuDB0IR2P6ZpF+D7dy6YC/9svGmBE5hKB9+X2+hh4iYRMkhGyTqyFc9APmeGQHf043tWQKHkizmwaY5AroTNVJzJDc2SFzUu92kOLsdmKu77vByb8/IjtxmhkMFISRBFISO4XMLJlj4XgGuRXtaHw2FLyHifdSOpisIhJjgkiPBAyJh7lfXTkhEadwk1mUngrOC6MazX7mASeEAPV1FyjEumBOaEDu4DP/ogRDKkiLEV1woVyMeLLKJCEM+FwdCwL4XLcRgdbfkhbzS8BNvXDKzNQiAWgOzagTXF1Eyq+Ci6/TPm/JrNY/59p1epKN4jQFGe0fx+LTMwNVCrAU2VSqnaKYzIiGmWe2Rvp9KDJhncrjLaFce8VCUbyQ1kB9lNfkJ+To6R58mfyd/Ip9ABXohDHqqwEW7A2Mij1ehntLu+h8xMtocjUJcYwoLdtYafv/1Vjy8vjLaLtBfOt3/B931Rexa24e5zstgnyqvZHs69zuhq3vFgRpQVJyN7FuE++RLSeW4xMi+t6Zeo5sIK6S5dlGVRD2hWnGoB3j7OV3lesvNLic8tOnLRSRfRdOna63VJp/1WbYs5dFZjy1AqpGICQEWKmNI+CZNoVTJ7pNop+IZkRrBHgnEmqr3TrEsfw1Gi8LqE+S1aV0SNNwXVVVvuUoU3ld6TLwmditIpvKTU50zSzWwO1h0rL8awnulwTXMYrGDT4aQ1fb4GPkyv5vMEh5Vec6yw0AMXnfcx1l/rfVZaKLDi0W4j/HfeyGZuHOf1IUGW1udizU2leXY0OmLpVDpVKJfKpZzPRKHgEBzpXAUKWYipoIeBdl3JfLZVBizEqWun1i4ZGFiyduq3DebayXsmJ+95gBG4+Urm1a2SdpKV57lP2wZyZqI+FAlfUtO+NCmgdWhMOS1gDY+jHWnBhwjBQLMEXxmLbx6t9JXTWDLtsSxgisfErqvQMbbBoywZmeyLeWe8OWNydFDxzMx4lMGRtX0xN3YFJkeW+O0bascGNwwObtjCCOzrzAVWjSwN2K9cpyn9o5cZOXMmkAuM85EbNHnJyHhfLLCnPhxJYw9eoIMkyC3l+4ZuY5ig7lW2oYUynDgg+Xrk+++Xe3zSgRYetnyuy+KbfjiB+GAAtZ8HHXmtijZfFFgrujhmOs2qkXvuSV6WqA1WLYqhPHOfsa26rklKFqbAGL2dOIlGurB6LWFVFd/KoBBaYTFYVBs93hZRFlrG5Ex4NVFIJguJVvqnBW2kNNvFGx90YUcSEvyZSMDeZjc0xYlEYy8+hHcWx9YrZOaPPyCGepP5Q34aXnGBr8d1QhSf4yjtiebZqNJfEYl4SY6dDRb8WSguLZW9ZQtBpoW4hX0QMyB2KmsYcOh8HMQxBn288oZ6BXV0GOq/ClKsC6T8g9X3OFKZNkJrYkOx2lEk+KNDy953+wGHXuGGzhGZ+uLK8FVrQkbtKBv+9EztU2sgTCNpvXMdJjqJ4tkdw+x00dPKkZ1QR254x7GQoFmvfakSnL3gCc5nREly2mN2pyTLMacMipNT7YInGU7JzlN2p9N+yinXTirOKEvPUafSWMNDmCf9pIQYaG19DSxKGqvAQ+xg60iabEm5MheUU2n+HxO4TDDbjnw6xxK8QzfhbHXq8pWVqanKysun9s6ztdt7sivGqruqYyuyPS6Hw9XehGt6q+l0dT0jvaFMZjiTuTHo7+vdtHJTb58/2ML+IxHt9/n9vv5owiWKrrbWD+sakKxhKoYzxF5f7y9INxki42QNuYrVFDPfvqxyY83xWNMV+ZxPSMWb62W+wPSCJwkDDl1WZOGW84nAEo4A7HjB/uWmOdayRFnKjazi668u/ajJlUd87aPk048Crlu4j1Oh9gxdL3Z1inNPIt2xvKNlsU4hn54Z5Y6YbTDu9hHOvkcFAb35fU6hNovKOrtQmcvbNV9/Ntfv5xf4atDWOOTX6CSHZ08xujhPs51+f9zvf1YLIGoPPKvxVh0TSLAXzzUBFiXs7GJVB7vH5/PAXznd4+vx4a95h3qI/oYIpIdMkA1kC7kVLS3GhWI5bwj1fIaVKG/Ei5gXWOjhtcJbzFthaMQrwIcIRj0ppvO6yV95icu9j/YPDNySWp7w+kOr95R1RfGpfVlDVhS/2geJ5Umv2mn0rkxBvzvgdisndJXaVF1X5z5jdHGe2n/QnYo8+b2uaMivhowgjYcLnVqnrEpQezsieyVZ6ooETbdJO6ip+cORLpes6BL82/qg8VHbo45B/vch/YQeJX28QvEANR3sQhxh+TcMCEd4l8BKF7uID7KM05tRYlIHHXY63YIi2fXQyj5XSBbcMeewKLpttkJ2Syz33YJfDdJdSYkqHbYb3VHRJgTV8c0TAy67YHeK7htwOKWax5co7Do8Pfh1tKdx1g5j9o6TZeQyMo27FuW3vbYsbY/Op3AG06DMKionRlpgHzCEeMmLU5opRrCyS670RzppZeW5p/iT3jL3lB4O63QS6dzzh8SAtOqwGJK3bv+lGJTWbr++471wsVKMRJCEK5H+cLg/Qp+IDsdqs7HhKD7hMXyyrD/Li8RjRqimHhI7HP2vSDZn9brplySb0L9dgpURSwmSiBFhilrwB8OA9gZ29NkRO/669parW9e7XZDxwvgRu+SE7zgl+xG5p/HtRqJ3cdwSZwsbwTA1WT3jEdyPN0sWxvDGy+xovIzHosnwc9LePf9tywun0fMkWaFYZbB4oovRq8VyKYUBkMVXqVhBHSylQ0wanvla3+rQ1XbR8ZzstYOo2Mf7vjk8ftcGDWxdSdXx0cAVveHg1TZFtEOn8ntBBFs11V++vuLUQ5qz+U6d/oUjpGIdNjOQhJXNqn5YCS1Yy5PofLGEs6Js2yOKe2yyOLxtaGjbt7cNIURCEDdWfaQ6lurtRYbePCuItv1iUNxvE4Vdw2zQ0LZhdv2fxjHp5uAmdlBpopHXoJGU8e6BRc0yi+PztkaHTRRrW1m2hcfFLlEUzzD+DGczjEVCg9jEQZhFcdAL2DjD+DPiSWQzjM2I89g5RXdxfECS+CIWy1hTGmFs6EIbkv/pbtkfU3aPrZ+4c2Lizn07qufym/L5TTdtyuU2/We3HPeDsjtb3bGPSSfW31aX3LQpX/d9sL7fWYpRJPBbCJavYjrFjj0rT2GWCZjf6Ytffr8beXl/HYeyGwJiIK8FLDHbfo65xGz7YCSRqCQSkbbHI5eUU5X4sjj+zrU9aHnRlEnrd7YGptd0x2Jf/RbH9PAiovadckSnEsJ661OgPFuH9B4O6e202vIN0h9xHXSJh1wRP5Vqv1uI6Wn9Gxmrwzqrii1gqhEscJanuAlGas+s2/uzvetgS72NpHZ6aHbZstmh/wPq1seEeJxjYGRgYADi31ySEvH8Nl8ZuJlfAEUYalQ3NCLo/6+ZpzLdAnI5GJhAogAiBgraeJxjYGRgYA76nwUkXzAAAfNUBkYGVKALAFb4A3EAAAB4nGNgYGBgfjG0MAAMzihlAAAAAABOAJoA6AEKASwBTgFwAZoBxAHuAhoCnALoBJoEvATWBPIFDgUqBXoF0AX+BkQGlga4BwgHagfiCGoIpAi8CVAJmAoQCiwKVgqQCtYLGAtOC4gL6AwuDFR4nGNgZGBg0GVMYRBlAAEmIOYCQgaG/2A+AwAYygG+AHicbZE9TsMwGIbf9A/RSggEYmHxAgtq+jN2ZGj3Dt3T1GlTOXHkuBW9AyfgEByCgTNwCA7BW/NJlVBtyd/jx+8XKwmAa3whwnFE6Ib1OBq44O6Pm6Qb4Rb5QbiNHh6FO/RD4S6eMRHu4RaaT4halzR3eBVu4Apvwk36d+EW+UO4jXt8Cnfov4W7WOBHuIen6MXsCtvPU1vWc73emcSdxIkW2tW5LdUoHp7kTJfaJV6v1PKg6v167H2mMmcLNbWl18ZYVTm71amPN95Xk8EgEx+ntoDBDgUs+siRspaoMef7rukNEriziXNuwS7Hmoe9wggxv+e55IzJMqQTeNYV00scuNbY8+YxrUfGfcaMZb/CNPQe04bT0lThbEuT0sfYhK6K/23Amf3Lx+H24hcj4GScAAAAeJxtjuduwzAMhH2NnTqOk+6993TfSZFY24giGZTVon36eiRFf5SAiO/A05HBWtBXEvxfGdYwQIgIQ6wjxggJxkgxwRQb2MQWtrGDXexhHwc4xBGOcYJTnOEcF7jEFa5xg1vc4R4PeMQTnvGCV2R4C1Khy9xkkkxNnPRC03s97pHLvKgTYXJNmbKfZom9o8POEffsq0Qw28+ltcPe2uHS2rGvRjPBmSwE1+GMtI6l0GSU4JEsSM4XgudpQx9sTRf3K9rAyUr0962UryKprZwPpM0jyda5uP2qrVBjxSLPCmGUplixrdpBSKqsI2oO4gF9Udq8TJVOzDSpcEHGR4vSeJdaVsSkMl26OqoKa6jttQ0rLb6a5l3YjO2QqV01YXLlNy2XDR0JlkXojbJTb/5GDX3V+kPviIPgB9AUks0AAAA=)
      format('woff');
    font-weight: normal;
    font-style: normal;
  }

  html {
    --lumo-icons-align-center: '\\ea01';
    --lumo-icons-align-left: '\\ea02';
    --lumo-icons-align-right: '\\ea03';
    --lumo-icons-angle-down: '\\ea04';
    --lumo-icons-angle-left: '\\ea05';
    --lumo-icons-angle-right: '\\ea06';
    --lumo-icons-angle-up: '\\ea07';
    --lumo-icons-arrow-down: '\\ea08';
    --lumo-icons-arrow-left: '\\ea09';
    --lumo-icons-arrow-right: '\\ea0a';
    --lumo-icons-arrow-up: '\\ea0b';
    --lumo-icons-bar-chart: '\\ea0c';
    --lumo-icons-bell: '\\ea0d';
    --lumo-icons-calendar: '\\ea0e';
    --lumo-icons-checkmark: '\\ea0f';
    --lumo-icons-chevron-down: '\\ea10';
    --lumo-icons-chevron-left: '\\ea11';
    --lumo-icons-chevron-right: '\\ea12';
    --lumo-icons-chevron-up: '\\ea13';
    --lumo-icons-clock: '\\ea14';
    --lumo-icons-cog: '\\ea15';
    --lumo-icons-cross: '\\ea16';
    --lumo-icons-download: '\\ea17';
    --lumo-icons-drag-handle: '\\ea18';
    --lumo-icons-dropdown: '\\ea19';
    --lumo-icons-edit: '\\ea1a';
    --lumo-icons-error: '\\ea1b';
    --lumo-icons-eye: '\\ea1c';
    --lumo-icons-eye-disabled: '\\ea1d';
    --lumo-icons-menu: '\\ea1e';
    --lumo-icons-minus: '\\ea1f';
    --lumo-icons-ordered-list: '\\ea20';
    --lumo-icons-phone: '\\ea21';
    --lumo-icons-photo: '\\ea22';
    --lumo-icons-play: '\\ea23';
    --lumo-icons-plus: '\\ea24';
    --lumo-icons-redo: '\\ea25';
    --lumo-icons-reload: '\\ea26';
    --lumo-icons-resize-handle: '\\ea27';
    --lumo-icons-search: '\\ea28';
    --lumo-icons-undo: '\\ea29';
    --lumo-icons-unordered-list: '\\ea2a';
    --lumo-icons-upload: '\\ea2b';
    --lumo-icons-user: '\\ea2c';
  }
`;
addLumoGlobalStyles("font-icons", fontIcons);

// node_modules/@vaadin/vaadin-lumo-styles/sizing.js
var sizing = css`
  :host {
    --lumo-size-xs: 1.625rem;
    --lumo-size-s: 1.875rem;
    --lumo-size-m: 2.25rem;
    --lumo-size-l: 2.75rem;
    --lumo-size-xl: 3.5rem;

    /* Icons */
    --lumo-icon-size-s: 1.25em;
    --lumo-icon-size-m: 1.5em;
    --lumo-icon-size-l: 2.25em;
    /* For backwards compatibility */
    --lumo-icon-size: var(--lumo-icon-size-m);
  }
`;
addLumoGlobalStyles("sizing-props", sizing);

// node_modules/@vaadin/vaadin-lumo-styles/spacing.js
var spacing = css`
  :host {
    /* Square */
    --lumo-space-xs: 0.25rem;
    --lumo-space-s: 0.5rem;
    --lumo-space-m: 1rem;
    --lumo-space-l: 1.5rem;
    --lumo-space-xl: 2.5rem;

    /* Wide */
    --lumo-space-wide-xs: calc(var(--lumo-space-xs) / 2) var(--lumo-space-xs);
    --lumo-space-wide-s: calc(var(--lumo-space-s) / 2) var(--lumo-space-s);
    --lumo-space-wide-m: calc(var(--lumo-space-m) / 2) var(--lumo-space-m);
    --lumo-space-wide-l: calc(var(--lumo-space-l) / 2) var(--lumo-space-l);
    --lumo-space-wide-xl: calc(var(--lumo-space-xl) / 2) var(--lumo-space-xl);

    /* Tall */
    --lumo-space-tall-xs: var(--lumo-space-xs) calc(var(--lumo-space-xs) / 2);
    --lumo-space-tall-s: var(--lumo-space-s) calc(var(--lumo-space-s) / 2);
    --lumo-space-tall-m: var(--lumo-space-m) calc(var(--lumo-space-m) / 2);
    --lumo-space-tall-l: var(--lumo-space-l) calc(var(--lumo-space-l) / 2);
    --lumo-space-tall-xl: var(--lumo-space-xl) calc(var(--lumo-space-xl) / 2);
  }
`;
addLumoGlobalStyles("spacing-props", spacing);

// node_modules/@vaadin/vaadin-lumo-styles/style.js
var style = css`
  :host {
    /* Border radius */
    --lumo-border-radius-s: 0.25em; /* Checkbox, badge, date-picker year indicator, etc */
    --lumo-border-radius-m: var(--lumo-border-radius, 0.25em); /* Button, text field, menu overlay, etc */
    --lumo-border-radius-l: 0.5em; /* Dialog, notification, etc */

    /* Shadow */
    --lumo-box-shadow-xs: 0 1px 4px -1px var(--lumo-shade-50pct);
    --lumo-box-shadow-s: 0 2px 4px -1px var(--lumo-shade-20pct), 0 3px 12px -1px var(--lumo-shade-30pct);
    --lumo-box-shadow-m: 0 2px 6px -1px var(--lumo-shade-20pct), 0 8px 24px -4px var(--lumo-shade-40pct);
    --lumo-box-shadow-l: 0 3px 18px -2px var(--lumo-shade-20pct), 0 12px 48px -6px var(--lumo-shade-40pct);
    --lumo-box-shadow-xl: 0 4px 24px -3px var(--lumo-shade-20pct), 0 18px 64px -8px var(--lumo-shade-40pct);

    /* Clickable element cursor */
    --lumo-clickable-cursor: default;
  }
`;
var globals = css`
  html {
    /* Button */
    --vaadin-button-background: var(--lumo-contrast-5pct);
    --vaadin-button-border: none;
    --vaadin-button-border-radius: var(--lumo-border-radius-m);
    --vaadin-button-font-size: var(--lumo-font-size-m);
    --vaadin-button-font-weight: 500;
    --vaadin-button-height: var(--lumo-size-m);
    --vaadin-button-margin: var(--lumo-space-xs) 0;
    --vaadin-button-min-width: calc(var(--vaadin-button-height) * 2);
    --vaadin-button-padding: 0 calc(var(--vaadin-button-height) / 3 + var(--lumo-border-radius-m) / 2);
    --vaadin-button-text-color: var(--lumo-primary-text-color);
    --vaadin-button-primary-background: var(--lumo-primary-color);
    --vaadin-button-primary-border: none;
    --vaadin-button-primary-font-weight: 600;
    --vaadin-button-primary-text-color: var(--lumo-primary-contrast-color);
    --vaadin-button-tertiary-background: transparent !important;
    --vaadin-button-tertiary-text-color: var(--lumo-primary-text-color);
    --vaadin-button-tertiary-font-weight: 500;
    --vaadin-button-tertiary-padding: 0 calc(var(--vaadin-button-height) / 6);
    /* Checkbox */
    --vaadin-checkbox-background: var(--lumo-contrast-20pct);
    --vaadin-checkbox-background-hover: var(--lumo-contrast-30pct);
    --vaadin-checkbox-border-radius: var(--lumo-border-radius-s);
    --vaadin-checkbox-checkmark-char: var(--lumo-icons-checkmark);
    --vaadin-checkbox-checkmark-char-indeterminate: '';
    --vaadin-checkbox-checkmark-color: var(--lumo-primary-contrast-color);
    --vaadin-checkbox-checkmark-size: calc(var(--vaadin-checkbox-size) + 2px);
    --vaadin-checkbox-label-color: var(--lumo-body-text-color);
    --vaadin-checkbox-label-font-size: var(--lumo-font-size-m);
    --vaadin-checkbox-label-padding: var(--lumo-space-xs) var(--lumo-space-s) var(--lumo-space-xs) var(--lumo-space-xs);
    --vaadin-checkbox-size: calc(var(--lumo-size-m) / 2);
    --vaadin-checkbox-disabled-checkmark-color: var(--lumo-contrast-30pct);
    --vaadin-checkbox-disabled-background: var(--lumo-contrast-10pct);
    /* Radio button */
    --vaadin-radio-button-background: var(--lumo-contrast-20pct);
    --vaadin-radio-button-background-hover: var(--lumo-contrast-30pct);
    --vaadin-radio-button-dot-color: var(--lumo-primary-contrast-color);
    --vaadin-radio-button-dot-size: 3px;
    --vaadin-radio-button-label-color: var(--lumo-body-text-color);
    --vaadin-radio-button-label-font-size: var(--lumo-font-size-m);
    --vaadin-radio-button-label-padding: var(--lumo-space-xs) var(--lumo-space-s) var(--lumo-space-xs)
      var(--lumo-space-xs);
    --vaadin-radio-button-size: calc(var(--lumo-size-m) / 2);
    --vaadin-radio-button-disabled-background: var(--lumo-contrast-10pct);
    --vaadin-radio-button-disabled-dot-color: var(--lumo-contrast-30pct);
    --vaadin-selection-color: var(--lumo-primary-color);
    --vaadin-selection-color-text: var(--lumo-primary-text-color);
    --vaadin-input-field-border-radius: var(--lumo-border-radius-m);
    --vaadin-focus-ring-color: var(--lumo-primary-color-50pct);
    --vaadin-focus-ring-width: 2px;
    /* Label */
    --vaadin-input-field-label-color: var(--lumo-secondary-text-color);
    --vaadin-input-field-focused-label-color: var(--lumo-primary-text-color);
    --vaadin-input-field-hovered-label-color: var(--lumo-body-text-color);
    --vaadin-input-field-label-font-size: var(--lumo-font-size-s);
    --vaadin-input-field-label-font-weight: 500;
    /* Helper */
    --vaadin-input-field-helper-color: var(--lumo-secondary-text-color);
    --vaadin-input-field-helper-font-size: var(--lumo-font-size-xs);
    --vaadin-input-field-helper-font-weight: 400;
    --vaadin-input-field-helper-spacing: 0.4em;
    /* Error message */
    --vaadin-input-field-error-color: var(--lumo-error-text-color);
    --vaadin-input-field-error-font-size: var(--lumo-font-size-xs);
    --vaadin-input-field-error-font-weight: 400;
    /* Input field */
    --vaadin-input-field-background: var(--lumo-contrast-10pct);
    --vaadin-input-field-icon-color: var(--lumo-contrast-60pct);
    --vaadin-input-field-icon-size: var(--lumo-icon-size-m);
    --vaadin-input-field-invalid-background: var(--lumo-error-color-10pct);
    --vaadin-input-field-invalid-hover-highlight: var(--lumo-error-color-50pct);
    --vaadin-input-field-disabled-background: var(--lumo-contrast-5pct);
    --vaadin-input-field-disabled-value-color: var(--lumo-disabled-text-color);
    --vaadin-input-field-height: var(--lumo-size-m);
    --vaadin-input-field-hover-highlight: var(--lumo-contrast-50pct);
    --vaadin-input-field-placeholder-color: var(--lumo-secondary-text-color);
    --vaadin-input-field-readonly-border: 1px dashed var(--lumo-contrast-30pct);
    --vaadin-input-field-value-color: var(--lumo-body-text-color);
    --vaadin-input-field-value-font-size: var(--lumo-font-size-m);
    --vaadin-input-field-value-font-weight: 500;
  }
`;
addLumoGlobalStyles("style-props", style);

// node_modules/@vaadin/vaadin-lumo-styles/typography.js
var font = css`
  :host {
    /* prettier-ignore */
    --lumo-font-family: -apple-system, BlinkMacSystemFont, 'Roboto', 'Segoe UI', Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol';

    /* Font sizes */
    --lumo-font-size-xxs: 0.75rem;
    --lumo-font-size-xs: 0.8125rem;
    --lumo-font-size-s: 0.875rem;
    --lumo-font-size-m: 1rem;
    --lumo-font-size-l: 1.125rem;
    --lumo-font-size-xl: 1.375rem;
    --lumo-font-size-xxl: 1.75rem;
    --lumo-font-size-xxxl: 2.5rem;

    /* Line heights */
    --lumo-line-height-xs: 1.25;
    --lumo-line-height-s: 1.375;
    --lumo-line-height-m: 1.625;
  }
`;
var typography = css`
  body,
  :host {
    font-family: var(--lumo-font-family);
    font-size: var(--lumo-font-size-m);
    line-height: var(--lumo-line-height-m);
    -webkit-text-size-adjust: 100%;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  small,
  [theme~='font-size-s'] {
    font-size: var(--lumo-font-size-s);
    line-height: var(--lumo-line-height-s);
  }

  [theme~='font-size-xs'] {
    font-size: var(--lumo-font-size-xs);
    line-height: var(--lumo-line-height-xs);
  }

  :where(h1, h2, h3, h4, h5, h6) {
    font-weight: 600;
    line-height: var(--lumo-line-height-xs);
    margin-block: 0;
  }

  :where(h1) {
    font-size: var(--lumo-font-size-xxxl);
  }

  :where(h2) {
    font-size: var(--lumo-font-size-xxl);
  }

  :where(h3) {
    font-size: var(--lumo-font-size-xl);
  }

  :where(h4) {
    font-size: var(--lumo-font-size-l);
  }

  :where(h5) {
    font-size: var(--lumo-font-size-m);
  }

  :where(h6) {
    font-size: var(--lumo-font-size-xs);
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }

  p,
  blockquote {
    margin-top: 0.5em;
    margin-bottom: 0.75em;
  }

  a {
    text-decoration: none;
  }

  a:where(:any-link):hover {
    text-decoration: underline;
  }

  hr {
    display: block;
    align-self: stretch;
    height: 1px;
    border: 0;
    padding: 0;
    margin: var(--lumo-space-s) calc(var(--lumo-border-radius-m) / 2);
    background-color: var(--lumo-contrast-10pct);
  }

  blockquote {
    border-left: 2px solid var(--lumo-contrast-30pct);
  }

  b,
  strong {
    font-weight: 600;
  }

  /* RTL specific styles */
  blockquote[dir='rtl'] {
    border-left: none;
    border-right: 2px solid var(--lumo-contrast-30pct);
  }
`;
registerStyles("", typography, { moduleId: "lumo-typography" });
addLumoGlobalStyles("typography-props", font);

// node_modules/@vaadin/grid/theme/lumo/vaadin-grid-styles.js
registerStyles(
  "vaadin-grid",
  css`
    :host {
      font-family: var(--lumo-font-family);
      font-size: var(--lumo-font-size-m);
      line-height: var(--lumo-line-height-s);
      color: var(--lumo-body-text-color);
      background-color: var(--lumo-base-color);
      box-sizing: border-box;
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      --_focus-ring-color: var(--vaadin-focus-ring-color, var(--lumo-primary-color-50pct));
      --_focus-ring-width: var(--vaadin-focus-ring-width, 2px);
      /* For internal use only */
      --_lumo-grid-border-color: var(--lumo-contrast-20pct);
      --_lumo-grid-secondary-border-color: var(--lumo-contrast-10pct);
      --_lumo-grid-border-width: 1px;
      --_lumo-grid-selected-row-color: var(--lumo-primary-color-10pct);
    }

    /* No (outer) border */

    :host(:not([theme~='no-border'])) {
      border: var(--_lumo-grid-border-width) solid var(--_lumo-grid-border-color);
    }

    :host([disabled]) {
      opacity: 0.7;
    }

    /* Cell styles */

    [part~='cell'] {
      min-height: var(--lumo-size-m);
      background-color: var(--vaadin-grid-cell-background, var(--lumo-base-color));
      cursor: default;
      --_cell-padding: var(--vaadin-grid-cell-padding, var(--_cell-default-padding));
      --_cell-default-padding: var(--lumo-space-xs) var(--lumo-space-m);
    }

    [part~='cell'] ::slotted(vaadin-grid-cell-content) {
      cursor: inherit;
      padding: var(--_cell-padding);
    }

    /* Apply row borders by default and introduce the "no-row-borders" variant */
    :host(:not([theme~='no-row-borders'])) [part~='cell']:not([part~='details-cell']) {
      border-top: var(--_lumo-grid-border-width) solid var(--_lumo-grid-secondary-border-color);
    }

    /* Hide first body row top border */
    :host(:not([theme~='no-row-borders'])) [part~='first-row'] [part~='cell']:not([part~='details-cell']) {
      border-top: 0;
      min-height: calc(var(--lumo-size-m) - var(--_lumo-grid-border-width));
    }

    /* Focus-ring */

    [part~='row'] {
      position: relative;
    }

    [part~='row']:focus,
    [part~='focused-cell']:focus {
      outline: none;
    }

    :host([navigating]) [part~='row']:focus::before,
    :host([navigating]) [part~='focused-cell']:focus::before {
      content: '';
      position: absolute;
      inset: 0;
      pointer-events: none;
      box-shadow: inset 0 0 0 var(--_focus-ring-width) var(--_focus-ring-color);
    }

    :host([navigating]) [part~='row']:focus::before {
      transform: translateX(calc(-1 * var(--_grid-horizontal-scroll-position)));
      z-index: 3;
    }

    /* Empty state */
    [part~='empty-state'] {
      padding: var(--lumo-space-m);
      color: var(--lumo-secondary-text-color);
    }

    /* Drag and Drop styles */
    :host([dragover])::after {
      content: '';
      position: absolute;
      z-index: 100;
      inset: 0;
      pointer-events: none;
      box-shadow: inset 0 0 0 var(--_focus-ring-width) var(--_focus-ring-color);
    }

    [part~='row'][dragover] {
      z-index: 100 !important;
    }

    [part~='row'][dragover] [part~='cell'] {
      overflow: visible;
    }

    [part~='row'][dragover] [part~='cell']::after {
      content: '';
      position: absolute;
      inset: 0;
      height: calc(var(--_lumo-grid-border-width) + 2px);
      pointer-events: none;
      background: var(--lumo-primary-color-50pct);
    }

    [part~='row'][dragover] [part~='cell'][last-frozen]::after {
      right: -1px;
    }

    :host([theme~='no-row-borders']) [dragover] [part~='cell']::after {
      height: 2px;
    }

    [part~='row'][dragover='below'] [part~='cell']::after {
      top: 100%;
      bottom: auto;
      margin-top: -1px;
    }

    :host([all-rows-visible]) [part~='last-row'][dragover='below'] [part~='cell']::after {
      height: 1px;
    }

    [part~='row'][dragover='above'] [part~='cell']::after {
      top: auto;
      bottom: 100%;
      margin-bottom: -1px;
    }

    [part~='row'][details-opened][dragover='below'] [part~='cell']:not([part~='details-cell'])::after,
    [part~='row'][details-opened][dragover='above'] [part~='details-cell']::after {
      display: none;
    }

    [part~='row'][dragover][dragover='on-top'] [part~='cell']::after {
      height: 100%;
      opacity: 0.5;
    }

    [part~='row'][dragstart] [part~='cell'] {
      border: none !important;
      box-shadow: none !important;
    }

    [part~='row'][dragstart] [part~='cell'][last-column] {
      border-radius: 0 var(--lumo-border-radius-s) var(--lumo-border-radius-s) 0;
    }

    [part~='row'][dragstart] [part~='cell'][first-column] {
      border-radius: var(--lumo-border-radius-s) 0 0 var(--lumo-border-radius-s);
    }

    #scroller [part~='row'][dragstart]:not([dragstart=''])::after {
      display: block;
      position: absolute;
      left: var(--_grid-drag-start-x);
      top: var(--_grid-drag-start-y);
      z-index: 100;
      content: attr(dragstart);
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
      padding: calc(var(--lumo-space-xs) * 0.8);
      color: var(--lumo-error-contrast-color);
      background-color: var(--lumo-error-color);
      border-radius: var(--lumo-border-radius-m);
      font-family: var(--lumo-font-family);
      font-size: var(--lumo-font-size-xxs);
      line-height: 1;
      font-weight: 500;
      text-transform: initial;
      letter-spacing: initial;
      min-width: calc(var(--lumo-size-s) * 0.7);
      text-align: center;
    }

    /* Headers and footers */

    [part~='header-cell'],
    [part~='footer-cell'],
    [part~='reorder-ghost'] {
      font-size: var(--lumo-font-size-s);
      font-weight: 500;
    }

    [part~='footer-cell'] {
      font-weight: 400;
    }

    [part~='row']:only-child [part~='header-cell'] {
      min-height: var(--lumo-size-xl);
    }

    /* Header borders */

    /* Hide first header row top border */
    :host(:not([theme~='no-row-borders'])) [part~='row']:first-child [part~='header-cell'] {
      border-top: 0;
    }

    /* Hide header row top border if previous row is hidden */
    [part~='row'][hidden] + [part~='row'] [part~='header-cell'] {
      border-top: 0;
    }

    [part~='row']:last-child [part~='header-cell'] {
      border-bottom: var(--_lumo-grid-border-width) solid transparent;
    }

    :host(:not([theme~='no-row-borders'])) [part~='row']:last-child [part~='header-cell'] {
      border-bottom-color: var(--_lumo-grid-secondary-border-color);
    }

    /* Overflow uses a stronger border color */
    :host([overflow~='top']) [part~='row']:last-child [part~='header-cell'] {
      border-bottom-color: var(--_lumo-grid-border-color);
    }

    /* Footer borders */

    [part~='row']:first-child [part~='footer-cell'] {
      border-top: var(--_lumo-grid-border-width) solid transparent;
    }

    :host(:not([theme~='no-row-borders'])) [part~='row']:first-child [part~='footer-cell'] {
      border-top-color: var(--_lumo-grid-secondary-border-color);
    }

    /* Overflow uses a stronger border color */
    :host([overflow~='bottom']) [part~='row']:first-child [part~='footer-cell'] {
      border-top-color: var(--_lumo-grid-border-color);
    }

    /* Column reordering */

    :host([reordering]) [part~='cell'] {
      background: linear-gradient(var(--lumo-shade-20pct), var(--lumo-shade-20pct)) var(--lumo-base-color);
    }

    :host([reordering]) [part~='cell'][reorder-status='allowed'] {
      background: var(--lumo-base-color);
    }

    :host([reordering]) [part~='cell'][reorder-status='dragging'] {
      background: linear-gradient(var(--lumo-contrast-5pct), var(--lumo-contrast-5pct)) var(--lumo-base-color);
    }

    [part~='reorder-ghost'] {
      opacity: 0.85;
      box-shadow: var(--lumo-box-shadow-s);
      /* TODO Use the same styles as for the cell element (reorder-ghost copies styles from the cell element) */
      padding: var(--lumo-space-s) var(--lumo-space-m) !important;
    }

    /* Column resizing */

    [part='resize-handle'] {
      --_resize-handle-width: 3px;
      width: var(--_resize-handle-width);
      background-color: var(--lumo-primary-color-50pct);
      opacity: 0;
      transition: opacity 0.2s;
    }

    [part='resize-handle']::before {
      transform: translateX(calc(-50% + var(--_resize-handle-width) / 2));
      width: var(--lumo-size-s);
    }

    :host(:not([reordering])) *:not([column-resizing]) [part~='cell']:hover [part='resize-handle'],
    [part='resize-handle']:active {
      opacity: 1;
      transition-delay: 0.15s;
    }

    /* Column borders */

    :host([theme~='column-borders']) [part~='cell']:not([last-column]):not([part~='details-cell']) {
      border-right: var(--_lumo-grid-border-width) solid var(--_lumo-grid-secondary-border-color);
    }

    /* Frozen columns */

    [last-frozen] {
      border-right: var(--_lumo-grid-border-width) solid transparent;
      overflow: hidden;
    }

    :host([overflow~='start']) [part~='cell'][last-frozen]:not([part~='details-cell']) {
      border-right-color: var(--_lumo-grid-border-color);
    }

    [first-frozen-to-end] {
      border-left: var(--_lumo-grid-border-width) solid transparent;
    }

    :host([overflow~='end']) [part~='cell'][first-frozen-to-end]:not([part~='details-cell']) {
      border-left-color: var(--_lumo-grid-border-color);
    }

    /* Row stripes */

    :host([theme~='row-stripes']) [part~='even-row'] [part~='body-cell'],
    :host([theme~='row-stripes']) [part~='even-row'] [part~='details-cell'] {
      background-image: linear-gradient(var(--lumo-contrast-5pct), var(--lumo-contrast-5pct));
      background-repeat: repeat-x;
    }

    /* Selected row */

    /* Raise the selected rows above unselected rows (so that box-shadow can cover unselected rows) */
    :host(:not([reordering])) [part~='row'][selected] {
      z-index: 1;
    }

    :host(:not([reordering])) [part~='row'][selected] [part~='body-cell']:not([part~='details-cell']) {
      background-image: linear-gradient(var(--_lumo-grid-selected-row-color), var(--_lumo-grid-selected-row-color));
      background-repeat: repeat;
    }

    /* Cover the border of an unselected row */
    :host(:not([theme~='no-row-borders'])) [part~='row'][selected] [part~='cell']:not([part~='details-cell']) {
      box-shadow: 0 var(--_lumo-grid-border-width) 0 0 var(--_lumo-grid-selected-row-color);
    }

    /* Compact */

    :host([theme~='compact']) [part~='row']:only-child [part~='header-cell'] {
      min-height: var(--lumo-size-m);
    }

    :host([theme~='compact']) [part~='cell'] {
      min-height: var(--lumo-size-s);
      --_cell-default-padding: var(--lumo-space-xs) var(--lumo-space-s);
    }

    :host([theme~='compact']) [part~='first-row'] [part~='cell']:not([part~='details-cell']) {
      min-height: calc(var(--lumo-size-s) - var(--_lumo-grid-border-width));
    }

    :host([theme~='compact']) [part~='empty-state'] {
      padding: var(--lumo-space-s);
    }

    /* Wrap cell contents */

    :host([theme~='wrap-cell-content']) [part~='cell'] ::slotted(vaadin-grid-cell-content) {
      white-space: normal;
    }

    /* RTL specific styles */

    :host([dir='rtl']) [part~='row'][dragstart] [part~='cell'][last-column] {
      border-radius: var(--lumo-border-radius-s) 0 0 var(--lumo-border-radius-s);
    }

    :host([dir='rtl']) [part~='row'][dragstart] [part~='cell'][first-column] {
      border-radius: 0 var(--lumo-border-radius-s) var(--lumo-border-radius-s) 0;
    }

    :host([dir='rtl'][theme~='column-borders']) [part~='cell']:not([last-column]):not([part~='details-cell']) {
      border-right: none;
      border-left: var(--_lumo-grid-border-width) solid var(--_lumo-grid-secondary-border-color);
    }

    :host([dir='rtl']) [last-frozen] {
      border-right: none;
      border-left: var(--_lumo-grid-border-width) solid transparent;
    }

    :host([dir='rtl']) [first-frozen-to-end] {
      border-left: none;
      border-right: var(--_lumo-grid-border-width) solid transparent;
    }

    :host([dir='rtl'][overflow~='start']) [part~='cell'][last-frozen]:not([part~='details-cell']) {
      border-left-color: var(--_lumo-grid-border-color);
    }

    :host([dir='rtl'][overflow~='end']) [part~='cell'][first-frozen-to-end]:not([part~='details-cell']) {
      border-right-color: var(--_lumo-grid-border-color);
    }
  `,
  { moduleId: "lumo-grid" }
);

// node_modules/@polymer/polymer/lib/utils/boot.js
window.JSCompiler_renameProperty = function(prop, obj) {
  return prop;
};

// node_modules/@polymer/polymer/lib/utils/resolve-url.js
var CSS_URL_RX = /(url\()([^)]*)(\))/g;
var ABS_URL = /(^\/[^\/])|(^#)|(^[\w-\d]*:)/;
var workingURL;
var resolveDoc;
function resolveUrl(url, baseURI) {
  if (url && ABS_URL.test(url)) {
    return url;
  }
  if (url === "//") {
    return url;
  }
  if (workingURL === void 0) {
    workingURL = false;
    try {
      const u5 = new URL("b", "http://a");
      u5.pathname = "c%20d";
      workingURL = u5.href === "http://a/c%20d";
    } catch (e13) {
    }
  }
  if (!baseURI) {
    baseURI = document.baseURI || window.location.href;
  }
  if (workingURL) {
    try {
      return new URL(url, baseURI).href;
    } catch (e13) {
      return url;
    }
  }
  if (!resolveDoc) {
    resolveDoc = document.implementation.createHTMLDocument("temp");
    resolveDoc.base = resolveDoc.createElement("base");
    resolveDoc.head.appendChild(resolveDoc.base);
    resolveDoc.anchor = resolveDoc.createElement("a");
    resolveDoc.body.appendChild(resolveDoc.anchor);
  }
  resolveDoc.base.href = baseURI;
  resolveDoc.anchor.href = url;
  return resolveDoc.anchor.href || url;
}
function resolveCss(cssText, baseURI) {
  return cssText.replace(CSS_URL_RX, function(m8, pre, url, post) {
    return pre + "'" + resolveUrl(url.replace(/["']/g, ""), baseURI) + "'" + post;
  });
}
function pathFromUrl(url) {
  return url.substring(0, url.lastIndexOf("/") + 1);
}

// node_modules/@polymer/polymer/lib/utils/settings.js
var useShadow = !window.ShadyDOM || !window.ShadyDOM.inUse;
var useNativeCSSProperties = Boolean(!window.ShadyCSS || window.ShadyCSS.nativeCss);
var useNativeCustomElements = !window.customElements.polyfillWrapFlushCallback;
var supportsAdoptingStyleSheets = useShadow && "adoptedStyleSheets" in Document.prototype && "replaceSync" in CSSStyleSheet.prototype && // Since spec may change, feature detect exact API we need
(() => {
  try {
    const sheet = new CSSStyleSheet();
    sheet.replaceSync("");
    const host = document.createElement("div");
    host.attachShadow({ mode: "open" });
    host.shadowRoot.adoptedStyleSheets = [sheet];
    return host.shadowRoot.adoptedStyleSheets[0] === sheet;
  } catch (e13) {
    return false;
  }
})();
var rootPath = window.Polymer && window.Polymer.rootPath || pathFromUrl(document.baseURI || window.location.href);
var sanitizeDOMValue = window.Polymer && window.Polymer.sanitizeDOMValue || void 0;
var passiveTouchGestures = window.Polymer && window.Polymer.setPassiveTouchGestures || false;
var strictTemplatePolicy = window.Polymer && window.Polymer.strictTemplatePolicy || false;
var allowTemplateFromDomModule = window.Polymer && window.Polymer.allowTemplateFromDomModule || false;
var legacyOptimizations = window.Polymer && window.Polymer.legacyOptimizations || false;
var legacyWarnings = window.Polymer && window.Polymer.legacyWarnings || false;
var syncInitialRender = window.Polymer && window.Polymer.syncInitialRender || false;
var legacyUndefined = window.Polymer && window.Polymer.legacyUndefined || false;
var orderedComputed = window.Polymer && window.Polymer.orderedComputed || false;
var cancelSyntheticClickEvents = true;
var setCancelSyntheticClickEvents = function(useCancelSyntheticClickEvents) {
  cancelSyntheticClickEvents = useCancelSyntheticClickEvents;
};
var removeNestedTemplates = window.Polymer && window.Polymer.removeNestedTemplates || false;
var fastDomIf = window.Polymer && window.Polymer.fastDomIf || false;
var suppressTemplateNotifications = window.Polymer && window.Polymer.suppressTemplateNotifications || false;
var legacyNoObservedAttributes = window.Polymer && window.Polymer.legacyNoObservedAttributes || false;
var useAdoptedStyleSheetsWithBuiltCSS = window.Polymer && window.Polymer.useAdoptedStyleSheetsWithBuiltCSS || false;

// node_modules/@polymer/polymer/lib/utils/mixin.js
var dedupeId = 0;
function MixinFunction() {
}
MixinFunction.prototype.__mixinApplications;
MixinFunction.prototype.__mixinSet;
var dedupingMixin = function(mixin) {
  let mixinApplications = (
    /** @type {!MixinFunction} */
    mixin.__mixinApplications
  );
  if (!mixinApplications) {
    mixinApplications = /* @__PURE__ */ new WeakMap();
    mixin.__mixinApplications = mixinApplications;
  }
  let mixinDedupeId = dedupeId++;
  function dedupingMixin2(base) {
    let baseSet = (
      /** @type {!MixinFunction} */
      base.__mixinSet
    );
    if (baseSet && baseSet[mixinDedupeId]) {
      return base;
    }
    let map = mixinApplications;
    let extended = map.get(base);
    if (!extended) {
      extended = /** @type {!Function} */
      mixin(base);
      map.set(base, extended);
      let mixinSet = Object.create(
        /** @type {!MixinFunction} */
        extended.__mixinSet || baseSet || null
      );
      mixinSet[mixinDedupeId] = true;
      extended.__mixinSet = mixinSet;
    }
    return extended;
  }
  return dedupingMixin2;
};

// node_modules/@polymer/polymer/lib/elements/dom-module.js
var modules = {};
var lcModules = {};
function setModule(id, module) {
  modules[id] = lcModules[id.toLowerCase()] = module;
}
function findModule(id) {
  return modules[id] || lcModules[id.toLowerCase()];
}
function styleOutsideTemplateCheck(inst) {
  if (inst.querySelector("style")) {
    console.warn("dom-module %s has style outside template", inst.id);
  }
}
var DomModule = class extends HTMLElement {
  /** @override */
  static get observedAttributes() {
    return ["id"];
  }
  /**
   * Retrieves the element specified by the css `selector` in the module
   * registered by `id`. For example, this.import('foo', 'img');
   * @param {string} id The id of the dom-module in which to search.
   * @param {string=} selector The css selector by which to find the element.
   * @return {Element} Returns the element which matches `selector` in the
   * module registered at the specified `id`.
   *
   * @export
   * @nocollapse Referred to indirectly in style-gather.js
   */
  static import(id, selector) {
    if (id) {
      let m8 = findModule(id);
      if (m8 && selector) {
        return m8.querySelector(selector);
      }
      return m8;
    }
    return null;
  }
  /* eslint-disable no-unused-vars */
  /**
   * @param {string} name Name of attribute.
   * @param {?string} old Old value of attribute.
   * @param {?string} value Current value of attribute.
   * @param {?string} namespace Attribute namespace.
   * @return {void}
   * @override
   */
  attributeChangedCallback(name, old, value, namespace) {
    if (old !== value) {
      this.register();
    }
  }
  /* eslint-enable no-unused-args */
  /**
   * The absolute URL of the original location of this `dom-module`.
   *
   * This value will differ from this element's `ownerDocument` in the
   * following ways:
   * - Takes into account any `assetpath` attribute added during bundling
   *   to indicate the original location relative to the bundled location
   * - Uses the HTMLImports polyfill's `importForElement` API to ensure
   *   the path is relative to the import document's location since
   *   `ownerDocument` is not currently polyfilled
   */
  get assetpath() {
    if (!this.__assetpath) {
      const owner = window.HTMLImports && HTMLImports.importForElement ? HTMLImports.importForElement(this) || document : this.ownerDocument;
      const url = resolveUrl(
        this.getAttribute("assetpath") || "",
        owner.baseURI
      );
      this.__assetpath = pathFromUrl(url);
    }
    return this.__assetpath;
  }
  /**
   * Registers the dom-module at a given id. This method should only be called
   * when a dom-module is imperatively created. For
   * example, `document.createElement('dom-module').register('foo')`.
   * @param {string=} id The id at which to register the dom-module.
   * @return {void}
   */
  register(id) {
    id = id || this.id;
    if (id) {
      if (strictTemplatePolicy && findModule(id) !== void 0) {
        setModule(id, null);
        throw new Error(`strictTemplatePolicy: dom-module ${id} re-registered`);
      }
      this.id = id;
      setModule(id, this);
      styleOutsideTemplateCheck(this);
    }
  }
};
DomModule.prototype["modules"] = modules;
customElements.define("dom-module", DomModule);

// node_modules/@polymer/polymer/lib/utils/style-gather.js
var MODULE_STYLE_LINK_SELECTOR = "link[rel=import][type~=css]";
var INCLUDE_ATTR = "include";
var SHADY_UNSCOPED_ATTR = "shady-unscoped";
function importModule(moduleId) {
  return (
    /** @type {?DomModule} */
    DomModule.import(moduleId)
  );
}
function styleForImport(importDoc) {
  let container = importDoc.body ? importDoc.body : importDoc;
  const importCss = resolveCss(
    container.textContent,
    importDoc.baseURI
  );
  const style2 = document.createElement("style");
  style2.textContent = importCss;
  return style2;
}
function stylesFromModules(moduleIds) {
  const modules2 = moduleIds.trim().split(/\s+/);
  const styles = [];
  for (let i11 = 0; i11 < modules2.length; i11++) {
    styles.push(...stylesFromModule(modules2[i11]));
  }
  return styles;
}
function stylesFromModule(moduleId) {
  const m8 = importModule(moduleId);
  if (!m8) {
    console.warn("Could not find style data in module named", moduleId);
    return [];
  }
  if (m8._styles === void 0) {
    const styles = [];
    styles.push(..._stylesFromModuleImports(m8));
    const template2 = (
      /** @type {?HTMLTemplateElement} */
      m8.querySelector("template")
    );
    if (template2) {
      styles.push(...stylesFromTemplate(
        template2,
        /** @type {templateWithAssetPath} */
        m8.assetpath
      ));
    }
    m8._styles = styles;
  }
  return m8._styles;
}
function stylesFromTemplate(template2, baseURI) {
  if (!template2._styles) {
    const styles = [];
    const e$ = template2.content.querySelectorAll("style");
    for (let i11 = 0; i11 < e$.length; i11++) {
      let e13 = e$[i11];
      let include = e13.getAttribute(INCLUDE_ATTR);
      if (include) {
        styles.push(...stylesFromModules(include).filter(function(item, index, self) {
          return self.indexOf(item) === index;
        }));
      }
      if (baseURI) {
        e13.textContent = resolveCss(
          e13.textContent,
          /** @type {string} */
          baseURI
        );
      }
      styles.push(e13);
    }
    template2._styles = styles;
  }
  return template2._styles;
}
function stylesFromModuleImports(moduleId) {
  let m8 = importModule(moduleId);
  return m8 ? _stylesFromModuleImports(m8) : [];
}
function _stylesFromModuleImports(module) {
  const styles = [];
  const p$ = module.querySelectorAll(MODULE_STYLE_LINK_SELECTOR);
  for (let i11 = 0; i11 < p$.length; i11++) {
    let p14 = p$[i11];
    if (p14.import) {
      const importDoc = p14.import;
      const unscoped = p14.hasAttribute(SHADY_UNSCOPED_ATTR);
      if (unscoped && !importDoc._unscopedStyle) {
        const style2 = styleForImport(importDoc);
        style2.setAttribute(SHADY_UNSCOPED_ATTR, "");
        importDoc._unscopedStyle = style2;
      } else if (!importDoc._style) {
        importDoc._style = styleForImport(importDoc);
      }
      styles.push(unscoped ? importDoc._unscopedStyle : importDoc._style);
    }
  }
  return styles;
}

// node_modules/@polymer/polymer/lib/utils/wrap.js
var wrap = window["ShadyDOM"] && window["ShadyDOM"]["noPatch"] && window["ShadyDOM"]["wrap"] ? window["ShadyDOM"]["wrap"] : window["ShadyDOM"] ? (n17) => ShadyDOM["patch"](n17) : (n17) => n17;

// node_modules/@polymer/polymer/lib/utils/path.js
function isPath(path) {
  return path.indexOf(".") >= 0;
}
function root(path) {
  let dotIndex = path.indexOf(".");
  if (dotIndex === -1) {
    return path;
  }
  return path.slice(0, dotIndex);
}
function isAncestor(base, path) {
  return base.indexOf(path + ".") === 0;
}
function isDescendant(base, path) {
  return path.indexOf(base + ".") === 0;
}
function translate(base, newBase, path) {
  return newBase + path.slice(base.length);
}
function normalize(path) {
  if (Array.isArray(path)) {
    let parts = [];
    for (let i11 = 0; i11 < path.length; i11++) {
      let args = path[i11].toString().split(".");
      for (let j4 = 0; j4 < args.length; j4++) {
        parts.push(args[j4]);
      }
    }
    return parts.join(".");
  } else {
    return path;
  }
}
function split(path) {
  if (Array.isArray(path)) {
    return normalize(path).split(".");
  }
  return path.toString().split(".");
}
function get(root2, path, info) {
  let prop = root2;
  let parts = split(path);
  for (let i11 = 0; i11 < parts.length; i11++) {
    if (!prop) {
      return;
    }
    let part = parts[i11];
    prop = prop[part];
  }
  if (info) {
    info.path = parts.join(".");
  }
  return prop;
}
function set(root2, path, value) {
  let prop = root2;
  let parts = split(path);
  let last = parts[parts.length - 1];
  if (parts.length > 1) {
    for (let i11 = 0; i11 < parts.length - 1; i11++) {
      let part = parts[i11];
      prop = prop[part];
      if (!prop) {
        return;
      }
    }
    prop[last] = value;
  } else {
    prop[path] = value;
  }
  return parts.join(".");
}

// node_modules/@polymer/polymer/lib/utils/case-map.js
var caseMap = {};
var DASH_TO_CAMEL = /-[a-z]/g;
var CAMEL_TO_DASH = /([A-Z])/g;
function dashToCamelCase2(dash) {
  return caseMap[dash] || (caseMap[dash] = dash.indexOf("-") < 0 ? dash : dash.replace(
    DASH_TO_CAMEL,
    (m8) => m8[1].toUpperCase()
  ));
}
function camelToDashCase(camel) {
  return caseMap[camel] || (caseMap[camel] = camel.replace(CAMEL_TO_DASH, "-$1").toLowerCase());
}

// node_modules/@polymer/polymer/lib/utils/async.js
var microtaskCurrHandle = 0;
var microtaskLastHandle = 0;
var microtaskCallbacks = [];
var microtaskNodeContent = 0;
var microtaskScheduled = false;
var microtaskNode = document.createTextNode("");
new window.MutationObserver(microtaskFlush).observe(microtaskNode, { characterData: true });
function microtaskFlush() {
  microtaskScheduled = false;
  const len = microtaskCallbacks.length;
  for (let i11 = 0; i11 < len; i11++) {
    let cb = microtaskCallbacks[i11];
    if (cb) {
      try {
        cb();
      } catch (e13) {
        setTimeout(() => {
          throw e13;
        });
      }
    }
  }
  microtaskCallbacks.splice(0, len);
  microtaskLastHandle += len;
}
var microTask = {
  /**
   * Enqueues a function called at microtask timing.
   *
   * @memberof microTask
   * @param {!Function=} callback Callback to run
   * @return {number} Handle used for canceling task
   */
  run(callback) {
    if (!microtaskScheduled) {
      microtaskScheduled = true;
      microtaskNode.textContent = microtaskNodeContent++;
    }
    microtaskCallbacks.push(callback);
    return microtaskCurrHandle++;
  },
  /**
   * Cancels a previously enqueued `microTask` callback.
   *
   * @memberof microTask
   * @param {number} handle Handle returned from `run` of callback to cancel
   * @return {void}
   */
  cancel(handle) {
    const idx = handle - microtaskLastHandle;
    if (idx >= 0) {
      if (!microtaskCallbacks[idx]) {
        throw new Error("invalid async handle: " + handle);
      }
      microtaskCallbacks[idx] = null;
    }
  }
};

// node_modules/@polymer/polymer/lib/mixins/properties-changed.js
var microtask = microTask;
var PropertiesChanged = dedupingMixin(
  /**
   * @template T
   * @param {function(new:T)} superClass Class to apply mixin to.
   * @return {function(new:T)} superClass with mixin applied.
   */
  (superClass) => {
    class PropertiesChanged2 extends superClass {
      /**
       * Creates property accessors for the given property names.
       * @param {!Object} props Object whose keys are names of accessors.
       * @return {void}
       * @protected
       * @nocollapse
       */
      static createProperties(props) {
        const proto2 = this.prototype;
        for (let prop in props) {
          if (!(prop in proto2)) {
            proto2._createPropertyAccessor(prop);
          }
        }
      }
      /**
       * Returns an attribute name that corresponds to the given property.
       * The attribute name is the lowercased property name. Override to
       * customize this mapping.
       * @param {string} property Property to convert
       * @return {string} Attribute name corresponding to the given property.
       *
       * @protected
       * @nocollapse
       */
      static attributeNameForProperty(property) {
        return property.toLowerCase();
      }
      /**
       * Override point to provide a type to which to deserialize a value to
       * a given property.
       * @param {string} name Name of property
       *
       * @protected
       * @nocollapse
       */
      static typeForProperty(name) {
      }
      //eslint-disable-line no-unused-vars
      /**
       * Creates a setter/getter pair for the named property with its own
       * local storage.  The getter returns the value in the local storage,
       * and the setter calls `_setProperty`, which updates the local storage
       * for the property and enqueues a `_propertiesChanged` callback.
       *
       * This method may be called on a prototype or an instance.  Calling
       * this method may overwrite a property value that already exists on
       * the prototype/instance by creating the accessor.
       *
       * @param {string} property Name of the property
       * @param {boolean=} readOnly When true, no setter is created; the
       *   protected `_setProperty` function must be used to set the property
       * @return {void}
       * @protected
       * @override
       */
      _createPropertyAccessor(property, readOnly) {
        this._addPropertyToAttributeMap(property);
        if (!this.hasOwnProperty(JSCompiler_renameProperty("__dataHasAccessor", this))) {
          this.__dataHasAccessor = Object.assign({}, this.__dataHasAccessor);
        }
        if (!this.__dataHasAccessor[property]) {
          this.__dataHasAccessor[property] = true;
          this._definePropertyAccessor(property, readOnly);
        }
      }
      /**
       * Adds the given `property` to a map matching attribute names
       * to property names, using `attributeNameForProperty`. This map is
       * used when deserializing attribute values to properties.
       *
       * @param {string} property Name of the property
       * @override
       */
      _addPropertyToAttributeMap(property) {
        if (!this.hasOwnProperty(JSCompiler_renameProperty("__dataAttributes", this))) {
          this.__dataAttributes = Object.assign({}, this.__dataAttributes);
        }
        let attr = this.__dataAttributes[property];
        if (!attr) {
          attr = this.constructor.attributeNameForProperty(property);
          this.__dataAttributes[attr] = property;
        }
        return attr;
      }
      /**
       * Defines a property accessor for the given property.
       * @param {string} property Name of the property
       * @param {boolean=} readOnly When true, no setter is created
       * @return {void}
       * @override
       */
      _definePropertyAccessor(property, readOnly) {
        Object.defineProperty(this, property, {
          /* eslint-disable valid-jsdoc */
          /** @this {PropertiesChanged} */
          get() {
            return this.__data[property];
          },
          /** @this {PropertiesChanged} */
          set: readOnly ? function() {
          } : function(value) {
            if (this._setPendingProperty(property, value, true)) {
              this._invalidateProperties();
            }
          }
          /* eslint-enable */
        });
      }
      constructor() {
        super();
        this.__dataEnabled = false;
        this.__dataReady = false;
        this.__dataInvalid = false;
        this.__data = {};
        this.__dataPending = null;
        this.__dataOld = null;
        this.__dataInstanceProps = null;
        this.__dataCounter = 0;
        this.__serializing = false;
        this._initializeProperties();
      }
      /**
       * Lifecycle callback called when properties are enabled via
       * `_enableProperties`.
       *
       * Users may override this function to implement behavior that is
       * dependent on the element having its property data initialized, e.g.
       * from defaults (initialized from `constructor`, `_initializeProperties`),
       * `attributeChangedCallback`, or values propagated from host e.g. via
       * bindings.  `super.ready()` must be called to ensure the data system
       * becomes enabled.
       *
       * @return {void}
       * @public
       * @override
       */
      ready() {
        this.__dataReady = true;
        this._flushProperties();
      }
      /**
       * Initializes the local storage for property accessors.
       *
       * Provided as an override point for performing any setup work prior
       * to initializing the property accessor system.
       *
       * @return {void}
       * @protected
       * @override
       */
      _initializeProperties() {
        for (let p14 in this.__dataHasAccessor) {
          if (this.hasOwnProperty(p14)) {
            this.__dataInstanceProps = this.__dataInstanceProps || {};
            this.__dataInstanceProps[p14] = this[p14];
            delete this[p14];
          }
        }
      }
      /**
       * Called at ready time with bag of instance properties that overwrote
       * accessors when the element upgraded.
       *
       * The default implementation sets these properties back into the
       * setter at ready time.  This method is provided as an override
       * point for customizing or providing more efficient initialization.
       *
       * @param {Object} props Bag of property values that were overwritten
       *   when creating property accessors.
       * @return {void}
       * @protected
       * @override
       */
      _initializeInstanceProperties(props) {
        Object.assign(this, props);
      }
      /**
       * Updates the local storage for a property (via `_setPendingProperty`)
       * and enqueues a `_proeprtiesChanged` callback.
       *
       * @param {string} property Name of the property
       * @param {*} value Value to set
       * @return {void}
       * @protected
       * @override
       */
      _setProperty(property, value) {
        if (this._setPendingProperty(property, value)) {
          this._invalidateProperties();
        }
      }
      /**
       * Returns the value for the given property.
       * @param {string} property Name of property
       * @return {*} Value for the given property
       * @protected
       * @override
       */
      _getProperty(property) {
        return this.__data[property];
      }
      /* eslint-disable no-unused-vars */
      /**
       * Updates the local storage for a property, records the previous value,
       * and adds it to the set of "pending changes" that will be passed to the
       * `_propertiesChanged` callback.  This method does not enqueue the
       * `_propertiesChanged` callback.
       *
       * @param {string} property Name of the property
       * @param {*} value Value to set
       * @param {boolean=} ext Not used here; affordance for closure
       * @return {boolean} Returns true if the property changed
       * @protected
       * @override
       */
      _setPendingProperty(property, value, ext) {
        let old = this.__data[property];
        let changed = this._shouldPropertyChange(property, value, old);
        if (changed) {
          if (!this.__dataPending) {
            this.__dataPending = {};
            this.__dataOld = {};
          }
          if (this.__dataOld && !(property in this.__dataOld)) {
            this.__dataOld[property] = old;
          }
          this.__data[property] = value;
          this.__dataPending[property] = value;
        }
        return changed;
      }
      /* eslint-enable */
      /**
       * @param {string} property Name of the property
       * @return {boolean} Returns true if the property is pending.
       */
      _isPropertyPending(property) {
        return !!(this.__dataPending && this.__dataPending.hasOwnProperty(property));
      }
      /**
       * Marks the properties as invalid, and enqueues an async
       * `_propertiesChanged` callback.
       *
       * @return {void}
       * @protected
       * @override
       */
      _invalidateProperties() {
        if (!this.__dataInvalid && this.__dataReady) {
          this.__dataInvalid = true;
          microtask.run(() => {
            if (this.__dataInvalid) {
              this.__dataInvalid = false;
              this._flushProperties();
            }
          });
        }
      }
      /**
       * Call to enable property accessor processing. Before this method is
       * called accessor values will be set but side effects are
       * queued. When called, any pending side effects occur immediately.
       * For elements, generally `connectedCallback` is a normal spot to do so.
       * It is safe to call this method multiple times as it only turns on
       * property accessors once.
       *
       * @return {void}
       * @protected
       * @override
       */
      _enableProperties() {
        if (!this.__dataEnabled) {
          this.__dataEnabled = true;
          if (this.__dataInstanceProps) {
            this._initializeInstanceProperties(this.__dataInstanceProps);
            this.__dataInstanceProps = null;
          }
          this.ready();
        }
      }
      /**
       * Calls the `_propertiesChanged` callback with the current set of
       * pending changes (and old values recorded when pending changes were
       * set), and resets the pending set of changes. Generally, this method
       * should not be called in user code.
       *
       * @return {void}
       * @protected
       * @override
       */
      _flushProperties() {
        this.__dataCounter++;
        const props = this.__data;
        const changedProps = this.__dataPending;
        const old = this.__dataOld;
        if (this._shouldPropertiesChange(props, changedProps, old)) {
          this.__dataPending = null;
          this.__dataOld = null;
          this._propertiesChanged(props, changedProps, old);
        }
        this.__dataCounter--;
      }
      /**
       * Called in `_flushProperties` to determine if `_propertiesChanged`
       * should be called. The default implementation returns true if
       * properties are pending. Override to customize when
       * `_propertiesChanged` is called.
       * @param {!Object} currentProps Bag of all current accessor values
       * @param {?Object} changedProps Bag of properties changed since the last
       *   call to `_propertiesChanged`
       * @param {?Object} oldProps Bag of previous values for each property
       *   in `changedProps`
       * @return {boolean} true if changedProps is truthy
       * @override
       */
      _shouldPropertiesChange(currentProps, changedProps, oldProps) {
        return Boolean(changedProps);
      }
      /**
       * Callback called when any properties with accessors created via
       * `_createPropertyAccessor` have been set.
       *
       * @param {!Object} currentProps Bag of all current accessor values
       * @param {?Object} changedProps Bag of properties changed since the last
       *   call to `_propertiesChanged`
       * @param {?Object} oldProps Bag of previous values for each property
       *   in `changedProps`
       * @return {void}
       * @protected
       * @override
       */
      _propertiesChanged(currentProps, changedProps, oldProps) {
      }
      /**
       * Method called to determine whether a property value should be
       * considered as a change and cause the `_propertiesChanged` callback
       * to be enqueued.
       *
       * The default implementation returns `true` if a strict equality
       * check fails. The method always returns false for `NaN`.
       *
       * Override this method to e.g. provide stricter checking for
       * Objects/Arrays when using immutable patterns.
       *
       * @param {string} property Property name
       * @param {*} value New property value
       * @param {*} old Previous property value
       * @return {boolean} Whether the property should be considered a change
       *   and enqueue a `_proeprtiesChanged` callback
       * @protected
       * @override
       */
      _shouldPropertyChange(property, value, old) {
        return (
          // Strict equality check
          old !== value && // This ensures (old==NaN, value==NaN) always returns false
          (old === old || value === value)
        );
      }
      /**
       * Implements native Custom Elements `attributeChangedCallback` to
       * set an attribute value to a property via `_attributeToProperty`.
       *
       * @param {string} name Name of attribute that changed
       * @param {?string} old Old attribute value
       * @param {?string} value New attribute value
       * @param {?string} namespace Attribute namespace.
       * @return {void}
       * @suppress {missingProperties} Super may or may not implement the callback
       * @override
       */
      attributeChangedCallback(name, old, value, namespace) {
        if (old !== value) {
          this._attributeToProperty(name, value);
        }
        if (super.attributeChangedCallback) {
          super.attributeChangedCallback(name, old, value, namespace);
        }
      }
      /**
       * Deserializes an attribute to its associated property.
       *
       * This method calls the `_deserializeValue` method to convert the string to
       * a typed value.
       *
       * @param {string} attribute Name of attribute to deserialize.
       * @param {?string} value of the attribute.
       * @param {*=} type type to deserialize to, defaults to the value
       * returned from `typeForProperty`
       * @return {void}
       * @override
       */
      _attributeToProperty(attribute, value, type) {
        if (!this.__serializing) {
          const map = this.__dataAttributes;
          const property = map && map[attribute] || attribute;
          this[property] = this._deserializeValue(value, type || this.constructor.typeForProperty(property));
        }
      }
      /**
       * Serializes a property to its associated attribute.
       *
       * @suppress {invalidCasts} Closure can't figure out `this` is an element.
       *
       * @param {string} property Property name to reflect.
       * @param {string=} attribute Attribute name to reflect to.
       * @param {*=} value Property value to refect.
       * @return {void}
       * @override
       */
      _propertyToAttribute(property, attribute, value) {
        this.__serializing = true;
        value = arguments.length < 3 ? this[property] : value;
        this._valueToNodeAttribute(
          /** @type {!HTMLElement} */
          this,
          value,
          attribute || this.constructor.attributeNameForProperty(property)
        );
        this.__serializing = false;
      }
      /**
       * Sets a typed value to an HTML attribute on a node.
       *
       * This method calls the `_serializeValue` method to convert the typed
       * value to a string.  If the `_serializeValue` method returns `undefined`,
       * the attribute will be removed (this is the default for boolean
       * type `false`).
       *
       * @param {Element} node Element to set attribute to.
       * @param {*} value Value to serialize.
       * @param {string} attribute Attribute name to serialize to.
       * @return {void}
       * @override
       */
      _valueToNodeAttribute(node, value, attribute) {
        const str = this._serializeValue(value);
        if (attribute === "class" || attribute === "name" || attribute === "slot") {
          node = /** @type {?Element} */
          wrap(node);
        }
        if (str === void 0) {
          node.removeAttribute(attribute);
        } else {
          node.setAttribute(
            attribute,
            // Closure's type for `setAttribute`'s second parameter incorrectly
            // excludes `TrustedScript`.
            str === "" && window.trustedTypes ? (
              /** @type {?} */
              window.trustedTypes.emptyScript
            ) : str
          );
        }
      }
      /**
       * Converts a typed JavaScript value to a string.
       *
       * This method is called when setting JS property values to
       * HTML attributes.  Users may override this method to provide
       * serialization for custom types.
       *
       * @param {*} value Property value to serialize.
       * @return {string | undefined} String serialized from the provided
       * property  value.
       * @override
       */
      _serializeValue(value) {
        switch (typeof value) {
          case "boolean":
            return value ? "" : void 0;
          default:
            return value != null ? value.toString() : void 0;
        }
      }
      /**
       * Converts a string to a typed JavaScript value.
       *
       * This method is called when reading HTML attribute values to
       * JS properties.  Users may override this method to provide
       * deserialization for custom `type`s. Types for `Boolean`, `String`,
       * and `Number` convert attributes to the expected types.
       *
       * @param {?string} value Value to deserialize.
       * @param {*=} type Type to deserialize the string to.
       * @return {*} Typed value deserialized from the provided string.
       * @override
       */
      _deserializeValue(value, type) {
        switch (type) {
          case Boolean:
            return value !== null;
          case Number:
            return Number(value);
          default:
            return value;
        }
      }
    }
    return PropertiesChanged2;
  }
);

// node_modules/@polymer/polymer/lib/mixins/property-accessors.js
var nativeProperties = {};
var proto = HTMLElement.prototype;
while (proto) {
  let props = Object.getOwnPropertyNames(proto);
  for (let i11 = 0; i11 < props.length; i11++) {
    nativeProperties[props[i11]] = true;
  }
  proto = Object.getPrototypeOf(proto);
}
var isTrustedType = (() => {
  if (!window.trustedTypes) {
    return () => false;
  }
  return (val) => trustedTypes.isHTML(val) || trustedTypes.isScript(val) || trustedTypes.isScriptURL(val);
})();
function saveAccessorValue(model, property) {
  if (!nativeProperties[property]) {
    let value = model[property];
    if (value !== void 0) {
      if (model.__data) {
        model._setPendingProperty(property, value);
      } else {
        if (!model.__dataProto) {
          model.__dataProto = {};
        } else if (!model.hasOwnProperty(JSCompiler_renameProperty("__dataProto", model))) {
          model.__dataProto = Object.create(model.__dataProto);
        }
        model.__dataProto[property] = value;
      }
    }
  }
}
var PropertyAccessors = dedupingMixin((superClass) => {
  const base = PropertiesChanged(superClass);
  class PropertyAccessors2 extends base {
    /**
     * Generates property accessors for all attributes in the standard
     * static `observedAttributes` array.
     *
     * Attribute names are mapped to property names using the `dash-case` to
     * `camelCase` convention
     *
     * @return {void}
     * @nocollapse
     */
    static createPropertiesForAttributes() {
      let a$ = (
        /** @type {?} */
        this.observedAttributes
      );
      for (let i11 = 0; i11 < a$.length; i11++) {
        this.prototype._createPropertyAccessor(dashToCamelCase2(a$[i11]));
      }
    }
    /**
     * Returns an attribute name that corresponds to the given property.
     * By default, converts camel to dash case, e.g. `fooBar` to `foo-bar`.
     * @param {string} property Property to convert
     * @return {string} Attribute name corresponding to the given property.
     *
     * @protected
     * @nocollapse
     */
    static attributeNameForProperty(property) {
      return camelToDashCase(property);
    }
    /**
     * Overrides PropertiesChanged implementation to initialize values for
     * accessors created for values that already existed on the element
     * prototype.
     *
     * @return {void}
     * @protected
     * @override
     */
    _initializeProperties() {
      if (this.__dataProto) {
        this._initializeProtoProperties(this.__dataProto);
        this.__dataProto = null;
      }
      super._initializeProperties();
    }
    /**
     * Called at instance time with bag of properties that were overwritten
     * by accessors on the prototype when accessors were created.
     *
     * The default implementation sets these properties back into the
     * setter at instance time.  This method is provided as an override
     * point for customizing or providing more efficient initialization.
     *
     * @param {Object} props Bag of property values that were overwritten
     *   when creating property accessors.
     * @return {void}
     * @protected
     * @override
     */
    _initializeProtoProperties(props) {
      for (let p14 in props) {
        this._setProperty(p14, props[p14]);
      }
    }
    /**
     * Ensures the element has the given attribute. If it does not,
     * assigns the given value to the attribute.
     *
     * @suppress {invalidCasts} Closure can't figure out `this` is infact an
     *     element
     *
     * @param {string} attribute Name of attribute to ensure is set.
     * @param {string} value of the attribute.
     * @return {void}
     * @override
     */
    _ensureAttribute(attribute, value) {
      const el = (
        /** @type {!HTMLElement} */
        this
      );
      if (!el.hasAttribute(attribute)) {
        this._valueToNodeAttribute(el, value, attribute);
      }
    }
    /**
     * Overrides PropertiesChanged implemention to serialize objects as JSON.
     *
     * @param {*} value Property value to serialize.
     * @return {string | undefined} String serialized from the provided property
     *     value.
     * @override
     */
    _serializeValue(value) {
      switch (typeof value) {
        case "object":
          if (value instanceof Date) {
            return value.toString();
          } else if (value) {
            if (isTrustedType(value)) {
              return (
                /** @type {?} */
                value
              );
            }
            try {
              return JSON.stringify(value);
            } catch (x2) {
              return "";
            }
          }
        default:
          return super._serializeValue(value);
      }
    }
    /**
     * Converts a string to a typed JavaScript value.
     *
     * This method is called by Polymer when reading HTML attribute values to
     * JS properties.  Users may override this method on Polymer element
     * prototypes to provide deserialization for custom `type`s.  Note,
     * the `type` argument is the value of the `type` field provided in the
     * `properties` configuration object for a given property, and is
     * by convention the constructor for the type to deserialize.
     *
     *
     * @param {?string} value Attribute value to deserialize.
     * @param {*=} type Type to deserialize the string to.
     * @return {*} Typed value deserialized from the provided string.
     * @override
     */
    _deserializeValue(value, type) {
      let outValue;
      switch (type) {
        case Object:
          try {
            outValue = JSON.parse(
              /** @type {string} */
              value
            );
          } catch (x2) {
            outValue = value;
          }
          break;
        case Array:
          try {
            outValue = JSON.parse(
              /** @type {string} */
              value
            );
          } catch (x2) {
            outValue = null;
            console.warn(`Polymer::Attributes: couldn't decode Array as JSON: ${value}`);
          }
          break;
        case Date:
          outValue = isNaN(value) ? String(value) : Number(value);
          outValue = new Date(outValue);
          break;
        default:
          outValue = super._deserializeValue(value, type);
          break;
      }
      return outValue;
    }
    /* eslint-enable no-fallthrough */
    /**
     * Overrides PropertiesChanged implementation to save existing prototype
     * property value so that it can be reset.
     * @param {string} property Name of the property
     * @param {boolean=} readOnly When true, no setter is created
     *
     * When calling on a prototype, any overwritten values are saved in
     * `__dataProto`, and it is up to the subclasser to decide how/when
     * to set those properties back into the accessor.  When calling on an
     * instance, the overwritten value is set via `_setPendingProperty`,
     * and the user should call `_invalidateProperties` or `_flushProperties`
     * for the values to take effect.
     * @protected
     * @return {void}
     * @override
     */
    _definePropertyAccessor(property, readOnly) {
      saveAccessorValue(this, property);
      super._definePropertyAccessor(property, readOnly);
    }
    /**
     * Returns true if this library created an accessor for the given property.
     *
     * @param {string} property Property name
     * @return {boolean} True if an accessor was created
     * @override
     */
    _hasAccessor(property) {
      return this.__dataHasAccessor && this.__dataHasAccessor[property];
    }
    /**
     * Returns true if the specified property has a pending change.
     *
     * @param {string} prop Property name
     * @return {boolean} True if property has a pending change
     * @protected
     * @override
     */
    _isPropertyPending(prop) {
      return Boolean(this.__dataPending && prop in this.__dataPending);
    }
  }
  return PropertyAccessors2;
});

// node_modules/@polymer/polymer/lib/mixins/template-stamp.js
var templateExtensions = {
  "dom-if": true,
  "dom-repeat": true
};
var placeholderBugDetect = false;
var placeholderBug = false;
function hasPlaceholderBug() {
  if (!placeholderBugDetect) {
    placeholderBugDetect = true;
    const t3 = document.createElement("textarea");
    t3.placeholder = "a";
    placeholderBug = t3.placeholder === t3.textContent;
  }
  return placeholderBug;
}
function fixPlaceholder(node) {
  if (hasPlaceholderBug() && node.localName === "textarea" && node.placeholder && node.placeholder === node.textContent) {
    node.textContent = null;
  }
}
var copyAttributeWithTemplateEventPolicy = (() => {
  const polymerTemplateEventAttributePolicy = window.trustedTypes && window.trustedTypes.createPolicy(
    "polymer-template-event-attribute-policy",
    {
      createScript: (x2) => x2
    }
  );
  return (dest, src, name) => {
    const value = src.getAttribute(name);
    if (polymerTemplateEventAttributePolicy && name.startsWith("on-")) {
      dest.setAttribute(
        name,
        polymerTemplateEventAttributePolicy.createScript(value, name)
      );
      return;
    }
    dest.setAttribute(name, value);
  };
})();
function wrapTemplateExtension(node) {
  let is = node.getAttribute("is");
  if (is && templateExtensions[is]) {
    let t3 = node;
    t3.removeAttribute("is");
    node = t3.ownerDocument.createElement(is);
    t3.parentNode.replaceChild(node, t3);
    node.appendChild(t3);
    while (t3.attributes.length) {
      const { name } = t3.attributes[0];
      copyAttributeWithTemplateEventPolicy(node, t3, name);
      t3.removeAttribute(name);
    }
  }
  return node;
}
function findTemplateNode(root2, nodeInfo) {
  let parent = nodeInfo.parentInfo && findTemplateNode(root2, nodeInfo.parentInfo);
  if (parent) {
    for (let n17 = parent.firstChild, i11 = 0; n17; n17 = n17.nextSibling) {
      if (nodeInfo.parentIndex === i11++) {
        return n17;
      }
    }
  } else {
    return root2;
  }
}
function applyIdToMap(inst, map, node, nodeInfo) {
  if (nodeInfo.id) {
    map[nodeInfo.id] = node;
  }
}
function applyEventListener(inst, node, nodeInfo) {
  if (nodeInfo.events && nodeInfo.events.length) {
    for (let j4 = 0, e$ = nodeInfo.events, e13; j4 < e$.length && (e13 = e$[j4]); j4++) {
      inst._addMethodEventListenerToNode(node, e13.name, e13.value, inst);
    }
  }
}
function applyTemplateInfo(inst, node, nodeInfo, parentTemplateInfo) {
  if (nodeInfo.templateInfo) {
    node._templateInfo = nodeInfo.templateInfo;
    node._parentTemplateInfo = parentTemplateInfo;
  }
}
function createNodeEventHandler(context, eventName, methodName) {
  context = context._methodHost || context;
  let handler = function(e13) {
    if (context[methodName]) {
      context[methodName](e13, e13.detail);
    } else {
      console.warn("listener method `" + methodName + "` not defined");
    }
  };
  return handler;
}
var TemplateStamp = dedupingMixin(
  /**
   * @template T
   * @param {function(new:T)} superClass Class to apply mixin to.
   * @return {function(new:T)} superClass with mixin applied.
   */
  (superClass) => {
    class TemplateStamp2 extends superClass {
      /**
       * Scans a template to produce template metadata.
       *
       * Template-specific metadata are stored in the object returned, and node-
       * specific metadata are stored in objects in its flattened `nodeInfoList`
       * array.  Only nodes in the template that were parsed as nodes of
       * interest contain an object in `nodeInfoList`.  Each `nodeInfo` object
       * contains an `index` (`childNodes` index in parent) and optionally
       * `parent`, which points to node info of its parent (including its index).
       *
       * The template metadata object returned from this method has the following
       * structure (many fields optional):
       *
       * ```js
       *   {
       *     // Flattened list of node metadata (for nodes that generated metadata)
       *     nodeInfoList: [
       *       {
       *         // `id` attribute for any nodes with id's for generating `$` map
       *         id: {string},
       *         // `on-event="handler"` metadata
       *         events: [
       *           {
       *             name: {string},   // event name
       *             value: {string},  // handler method name
       *           }, ...
       *         ],
       *         // Notes when the template contained a `<slot>` for shady DOM
       *         // optimization purposes
       *         hasInsertionPoint: {boolean},
       *         // For nested `<template>`` nodes, nested template metadata
       *         templateInfo: {object}, // nested template metadata
       *         // Metadata to allow efficient retrieval of instanced node
       *         // corresponding to this metadata
       *         parentInfo: {number},   // reference to parent nodeInfo>
       *         parentIndex: {number},  // index in parent's `childNodes` collection
       *         infoIndex: {number},    // index of this `nodeInfo` in `templateInfo.nodeInfoList`
       *       },
       *       ...
       *     ],
       *     // When true, the template had the `strip-whitespace` attribute
       *     // or was nested in a template with that setting
       *     stripWhitespace: {boolean},
       *     // For nested templates, nested template content is moved into
       *     // a document fragment stored here; this is an optimization to
       *     // avoid the cost of nested template cloning
       *     content: {DocumentFragment}
       *   }
       * ```
       *
       * This method kicks off a recursive treewalk as follows:
       *
       * ```
       *    _parseTemplate <---------------------+
       *      _parseTemplateContent              |
       *        _parseTemplateNode  <------------|--+
       *          _parseTemplateNestedTemplate --+  |
       *          _parseTemplateChildNodes ---------+
       *          _parseTemplateNodeAttributes
       *            _parseTemplateNodeAttribute
       *
       * ```
       *
       * These methods may be overridden to add custom metadata about templates
       * to either `templateInfo` or `nodeInfo`.
       *
       * Note that this method may be destructive to the template, in that
       * e.g. event annotations may be removed after being noted in the
       * template metadata.
       *
       * @param {!HTMLTemplateElement} template Template to parse
       * @param {TemplateInfo=} outerTemplateInfo Template metadata from the outer
       *   template, for parsing nested templates
       * @return {!TemplateInfo} Parsed template metadata
       * @nocollapse
       */
      static _parseTemplate(template2, outerTemplateInfo) {
        if (!template2._templateInfo) {
          let templateInfo = template2._templateInfo = {};
          templateInfo.nodeInfoList = [];
          templateInfo.nestedTemplate = Boolean(outerTemplateInfo);
          templateInfo.stripWhiteSpace = outerTemplateInfo && outerTemplateInfo.stripWhiteSpace || template2.hasAttribute && template2.hasAttribute("strip-whitespace");
          this._parseTemplateContent(
            template2,
            templateInfo,
            /** @type {?} */
            { parent: null }
          );
        }
        return template2._templateInfo;
      }
      /**
       * See docs for _parseTemplateNode.
       *
       * @param {!HTMLTemplateElement} template .
       * @param {!TemplateInfo} templateInfo .
       * @param {!NodeInfo} nodeInfo .
       * @return {boolean} .
       * @nocollapse
       */
      static _parseTemplateContent(template2, templateInfo, nodeInfo) {
        return this._parseTemplateNode(template2.content, templateInfo, nodeInfo);
      }
      /**
       * Parses template node and adds template and node metadata based on
       * the current node, and its `childNodes` and `attributes`.
       *
       * This method may be overridden to add custom node or template specific
       * metadata based on this node.
       *
       * @param {Node} node Node to parse
       * @param {!TemplateInfo} templateInfo Template metadata for current template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @nocollapse
       */
      static _parseTemplateNode(node, templateInfo, nodeInfo) {
        let noted = false;
        let element = (
          /** @type {!HTMLTemplateElement} */
          node
        );
        if (element.localName == "template" && !element.hasAttribute("preserve-content")) {
          noted = this._parseTemplateNestedTemplate(element, templateInfo, nodeInfo) || noted;
        } else if (element.localName === "slot") {
          templateInfo.hasInsertionPoint = true;
        }
        fixPlaceholder(element);
        if (element.firstChild) {
          this._parseTemplateChildNodes(element, templateInfo, nodeInfo);
        }
        if (element.hasAttributes && element.hasAttributes()) {
          noted = this._parseTemplateNodeAttributes(element, templateInfo, nodeInfo) || noted;
        }
        return noted || nodeInfo.noted;
      }
      /**
       * Parses template child nodes for the given root node.
       *
       * This method also wraps whitelisted legacy template extensions
       * (`is="dom-if"` and `is="dom-repeat"`) with their equivalent element
       * wrappers, collapses text nodes, and strips whitespace from the template
       * if the `templateInfo.stripWhitespace` setting was provided.
       *
       * @param {Node} root Root node whose `childNodes` will be parsed
       * @param {!TemplateInfo} templateInfo Template metadata for current template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {void}
       */
      static _parseTemplateChildNodes(root2, templateInfo, nodeInfo) {
        if (root2.localName === "script" || root2.localName === "style") {
          return;
        }
        for (let node = root2.firstChild, parentIndex = 0, next; node; node = next) {
          if (node.localName == "template") {
            node = wrapTemplateExtension(node);
          }
          next = node.nextSibling;
          if (node.nodeType === Node.TEXT_NODE) {
            let n17 = next;
            while (n17 && n17.nodeType === Node.TEXT_NODE) {
              node.textContent += n17.textContent;
              next = n17.nextSibling;
              root2.removeChild(n17);
              n17 = next;
            }
            if (templateInfo.stripWhiteSpace && !node.textContent.trim()) {
              root2.removeChild(node);
              continue;
            }
          }
          let childInfo = (
            /** @type {!NodeInfo} */
            { parentIndex, parentInfo: nodeInfo }
          );
          if (this._parseTemplateNode(node, templateInfo, childInfo)) {
            childInfo.infoIndex = templateInfo.nodeInfoList.push(childInfo) - 1;
          }
          if (node.parentNode) {
            parentIndex++;
          }
        }
      }
      /**
       * Parses template content for the given nested `<template>`.
       *
       * Nested template info is stored as `templateInfo` in the current node's
       * `nodeInfo`. `template.content` is removed and stored in `templateInfo`.
       * It will then be the responsibility of the host to set it back to the
       * template and for users stamping nested templates to use the
       * `_contentForTemplate` method to retrieve the content for this template
       * (an optimization to avoid the cost of cloning nested template content).
       *
       * @param {HTMLTemplateElement} node Node to parse (a <template>)
       * @param {TemplateInfo} outerTemplateInfo Template metadata for current template
       *   that includes the template `node`
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @nocollapse
       */
      static _parseTemplateNestedTemplate(node, outerTemplateInfo, nodeInfo) {
        let element = (
          /** @type {!HTMLTemplateElement} */
          node
        );
        let templateInfo = this._parseTemplate(element, outerTemplateInfo);
        let content = templateInfo.content = element.content.ownerDocument.createDocumentFragment();
        content.appendChild(element.content);
        nodeInfo.templateInfo = templateInfo;
        return true;
      }
      /**
       * Parses template node attributes and adds node metadata to `nodeInfo`
       * for nodes of interest.
       *
       * @param {Element} node Node to parse
       * @param {!TemplateInfo} templateInfo Template metadata for current
       *     template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @nocollapse
       */
      static _parseTemplateNodeAttributes(node, templateInfo, nodeInfo) {
        let noted = false;
        let attrs = Array.from(node.attributes);
        for (let i11 = attrs.length - 1, a17; a17 = attrs[i11]; i11--) {
          noted = this._parseTemplateNodeAttribute(node, templateInfo, nodeInfo, a17.name, a17.value) || noted;
        }
        return noted;
      }
      /**
       * Parses a single template node attribute and adds node metadata to
       * `nodeInfo` for attributes of interest.
       *
       * This implementation adds metadata for `on-event="handler"` attributes
       * and `id` attributes.
       *
       * @param {Element} node Node to parse
       * @param {!TemplateInfo} templateInfo Template metadata for current template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @param {string} name Attribute name
       * @param {string} value Attribute value
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @nocollapse
       */
      static _parseTemplateNodeAttribute(node, templateInfo, nodeInfo, name, value) {
        if (name.slice(0, 3) === "on-") {
          node.removeAttribute(name);
          nodeInfo.events = nodeInfo.events || [];
          nodeInfo.events.push({
            name: name.slice(3),
            value
          });
          return true;
        } else if (name === "id") {
          nodeInfo.id = value;
          return true;
        }
        return false;
      }
      /**
       * Returns the `content` document fragment for a given template.
       *
       * For nested templates, Polymer performs an optimization to cache nested
       * template content to avoid the cost of cloning deeply nested templates.
       * This method retrieves the cached content for a given template.
       *
       * @param {HTMLTemplateElement} template Template to retrieve `content` for
       * @return {DocumentFragment} Content fragment
       * @nocollapse
       */
      static _contentForTemplate(template2) {
        let templateInfo = (
          /** @type {HTMLTemplateElementWithInfo} */
          template2._templateInfo
        );
        return templateInfo && templateInfo.content || template2.content;
      }
      /**
       * Clones the provided template content and returns a document fragment
       * containing the cloned dom.
       *
       * The template is parsed (once and memoized) using this library's
       * template parsing features, and provides the following value-added
       * features:
       * * Adds declarative event listeners for `on-event="handler"` attributes
       * * Generates an "id map" for all nodes with id's under `$` on returned
       *   document fragment
       * * Passes template info including `content` back to templates as
       *   `_templateInfo` (a performance optimization to avoid deep template
       *   cloning)
       *
       * Note that the memoized template parsing process is destructive to the
       * template: attributes for bindings and declarative event listeners are
       * removed after being noted in notes, and any nested `<template>.content`
       * is removed and stored in notes as well.
       *
       * @param {!HTMLTemplateElement} template Template to stamp
       * @param {TemplateInfo=} templateInfo Optional template info associated
       *   with the template to be stamped; if omitted the template will be
       *   automatically parsed.
       * @return {!StampedTemplate} Cloned template content
       * @override
       */
      _stampTemplate(template2, templateInfo) {
        if (template2 && !template2.content && window.HTMLTemplateElement && HTMLTemplateElement.decorate) {
          HTMLTemplateElement.decorate(template2);
        }
        templateInfo = templateInfo || this.constructor._parseTemplate(template2);
        let nodeInfo = templateInfo.nodeInfoList;
        let content = templateInfo.content || template2.content;
        let dom = (
          /** @type {DocumentFragment} */
          document.importNode(content, true)
        );
        dom.__noInsertionPoint = !templateInfo.hasInsertionPoint;
        let nodes = dom.nodeList = new Array(nodeInfo.length);
        dom.$ = {};
        for (let i11 = 0, l10 = nodeInfo.length, info; i11 < l10 && (info = nodeInfo[i11]); i11++) {
          let node = nodes[i11] = findTemplateNode(dom, info);
          applyIdToMap(this, dom.$, node, info);
          applyTemplateInfo(this, node, info, templateInfo);
          applyEventListener(this, node, info);
        }
        dom = /** @type {!StampedTemplate} */
        dom;
        return dom;
      }
      /**
       * Adds an event listener by method name for the event provided.
       *
       * This method generates a handler function that looks up the method
       * name at handling time.
       *
       * @param {!EventTarget} node Node to add listener on
       * @param {string} eventName Name of event
       * @param {string} methodName Name of method
       * @param {*=} context Context the method will be called on (defaults
       *   to `node`)
       * @return {Function} Generated handler function
       * @override
       */
      _addMethodEventListenerToNode(node, eventName, methodName, context) {
        context = context || node;
        let handler = createNodeEventHandler(context, eventName, methodName);
        this._addEventListenerToNode(node, eventName, handler);
        return handler;
      }
      /**
       * Override point for adding custom or simulated event handling.
       *
       * @param {!EventTarget} node Node to add event listener to
       * @param {string} eventName Name of event
       * @param {function(!Event):void} handler Listener function to add
       * @return {void}
       * @override
       */
      _addEventListenerToNode(node, eventName, handler) {
        node.addEventListener(eventName, handler);
      }
      /**
       * Override point for adding custom or simulated event handling.
       *
       * @param {!EventTarget} node Node to remove event listener from
       * @param {string} eventName Name of event
       * @param {function(!Event):void} handler Listener function to remove
       * @return {void}
       * @override
       */
      _removeEventListenerFromNode(node, eventName, handler) {
        node.removeEventListener(eventName, handler);
      }
    }
    return TemplateStamp2;
  }
);

// node_modules/@polymer/polymer/lib/mixins/property-effects.js
var dedupeId2 = 0;
var NOOP = [];
var TYPES = {
  COMPUTE: "__computeEffects",
  REFLECT: "__reflectEffects",
  NOTIFY: "__notifyEffects",
  PROPAGATE: "__propagateEffects",
  OBSERVE: "__observeEffects",
  READ_ONLY: "__readOnly"
};
var COMPUTE_INFO = "__computeInfo";
var capitalAttributeRegex = /[A-Z]/;
function ensureOwnEffectMap(model, type, cloneArrays) {
  let effects = model[type];
  if (!effects) {
    effects = model[type] = {};
  } else if (!model.hasOwnProperty(type)) {
    effects = model[type] = Object.create(model[type]);
    if (cloneArrays) {
      for (let p14 in effects) {
        let protoFx = effects[p14];
        let instFx = effects[p14] = Array(protoFx.length);
        for (let i11 = 0; i11 < protoFx.length; i11++) {
          instFx[i11] = protoFx[i11];
        }
      }
    }
  }
  return effects;
}
function runEffects(inst, effects, props, oldProps, hasPaths, extraArgs) {
  if (effects) {
    let ran = false;
    const id = dedupeId2++;
    for (let prop in props) {
      let rootProperty = hasPaths ? root(prop) : prop;
      let fxs = effects[rootProperty];
      if (fxs) {
        for (let i11 = 0, l10 = fxs.length, fx; i11 < l10 && (fx = fxs[i11]); i11++) {
          if ((!fx.info || fx.info.lastRun !== id) && (!hasPaths || pathMatchesTrigger(prop, fx.trigger))) {
            if (fx.info) {
              fx.info.lastRun = id;
            }
            fx.fn(inst, prop, props, oldProps, fx.info, hasPaths, extraArgs);
            ran = true;
          }
        }
      }
    }
    return ran;
  }
  return false;
}
function runEffectsForProperty(inst, effects, dedupeId3, prop, props, oldProps, hasPaths, extraArgs) {
  let ran = false;
  let rootProperty = hasPaths ? root(prop) : prop;
  let fxs = effects[rootProperty];
  if (fxs) {
    for (let i11 = 0, l10 = fxs.length, fx; i11 < l10 && (fx = fxs[i11]); i11++) {
      if ((!fx.info || fx.info.lastRun !== dedupeId3) && (!hasPaths || pathMatchesTrigger(prop, fx.trigger))) {
        if (fx.info) {
          fx.info.lastRun = dedupeId3;
        }
        fx.fn(inst, prop, props, oldProps, fx.info, hasPaths, extraArgs);
        ran = true;
      }
    }
  }
  return ran;
}
function pathMatchesTrigger(path, trigger) {
  if (trigger) {
    let triggerPath = (
      /** @type {string} */
      trigger.name
    );
    return triggerPath == path || !!(trigger.structured && isAncestor(triggerPath, path)) || !!(trigger.wildcard && isDescendant(triggerPath, path));
  } else {
    return true;
  }
}
function runObserverEffect(inst, property, props, oldProps, info) {
  let fn = typeof info.method === "string" ? inst[info.method] : info.method;
  let changedProp = info.property;
  if (fn) {
    fn.call(inst, inst.__data[changedProp], oldProps[changedProp]);
  } else if (!info.dynamicFn) {
    console.warn("observer method `" + info.method + "` not defined");
  }
}
function runNotifyEffects(inst, notifyProps, props, oldProps, hasPaths) {
  let fxs = inst[TYPES.NOTIFY];
  let notified;
  let id = dedupeId2++;
  for (let prop in notifyProps) {
    if (notifyProps[prop]) {
      if (fxs && runEffectsForProperty(inst, fxs, id, prop, props, oldProps, hasPaths)) {
        notified = true;
      } else if (hasPaths && notifyPath(inst, prop, props)) {
        notified = true;
      }
    }
  }
  let host;
  if (notified && (host = inst.__dataHost) && host._invalidateProperties) {
    host._invalidateProperties();
  }
}
function notifyPath(inst, path, props) {
  let rootProperty = root(path);
  if (rootProperty !== path) {
    let eventName = camelToDashCase(rootProperty) + "-changed";
    dispatchNotifyEvent(inst, eventName, props[path], path);
    return true;
  }
  return false;
}
function dispatchNotifyEvent(inst, eventName, value, path) {
  let detail = {
    value,
    queueProperty: true
  };
  if (path) {
    detail.path = path;
  }
  wrap(
    /** @type {!HTMLElement} */
    inst
  ).dispatchEvent(new CustomEvent(eventName, { detail }));
}
function runNotifyEffect(inst, property, props, oldProps, info, hasPaths) {
  let rootProperty = hasPaths ? root(property) : property;
  let path = rootProperty != property ? property : null;
  let value = path ? get(inst, path) : inst.__data[property];
  if (path && value === void 0) {
    value = props[property];
  }
  dispatchNotifyEvent(inst, info.eventName, value, path);
}
function handleNotification(event, inst, fromProp, toPath, negate) {
  let value;
  let detail = (
    /** @type {Object} */
    event.detail
  );
  let fromPath = detail && detail.path;
  if (fromPath) {
    toPath = translate(fromProp, toPath, fromPath);
    value = detail && detail.value;
  } else {
    value = event.currentTarget[fromProp];
  }
  value = negate ? !value : value;
  if (!inst[TYPES.READ_ONLY] || !inst[TYPES.READ_ONLY][toPath]) {
    if (inst._setPendingPropertyOrPath(toPath, value, true, Boolean(fromPath)) && (!detail || !detail.queueProperty)) {
      inst._invalidateProperties();
    }
  }
}
function runReflectEffect(inst, property, props, oldProps, info) {
  let value = inst.__data[property];
  if (sanitizeDOMValue) {
    value = sanitizeDOMValue(
      value,
      info.attrName,
      "attribute",
      /** @type {Node} */
      inst
    );
  }
  inst._propertyToAttribute(property, info.attrName, value);
}
function runComputedEffects(inst, changedProps, oldProps, hasPaths) {
  let computeEffects = inst[TYPES.COMPUTE];
  if (computeEffects) {
    if (orderedComputed) {
      dedupeId2++;
      const order = getComputedOrder(inst);
      const queue = [];
      for (let p14 in changedProps) {
        enqueueEffectsFor(p14, computeEffects, queue, order, hasPaths);
      }
      let info;
      while (info = queue.shift()) {
        if (runComputedEffect(inst, "", changedProps, oldProps, info)) {
          enqueueEffectsFor(info.methodInfo, computeEffects, queue, order, hasPaths);
        }
      }
      Object.assign(
        /** @type {!Object} */
        oldProps,
        inst.__dataOld
      );
      Object.assign(
        /** @type {!Object} */
        changedProps,
        inst.__dataPending
      );
      inst.__dataPending = null;
    } else {
      let inputProps = changedProps;
      while (runEffects(inst, computeEffects, inputProps, oldProps, hasPaths)) {
        Object.assign(
          /** @type {!Object} */
          oldProps,
          inst.__dataOld
        );
        Object.assign(
          /** @type {!Object} */
          changedProps,
          inst.__dataPending
        );
        inputProps = inst.__dataPending;
        inst.__dataPending = null;
      }
    }
  }
}
var insertEffect = (info, queue, order) => {
  let start = 0;
  let end = queue.length - 1;
  let idx = -1;
  while (start <= end) {
    const mid = start + end >> 1;
    const cmp = order.get(queue[mid].methodInfo) - order.get(info.methodInfo);
    if (cmp < 0) {
      start = mid + 1;
    } else if (cmp > 0) {
      end = mid - 1;
    } else {
      idx = mid;
      break;
    }
  }
  if (idx < 0) {
    idx = end + 1;
  }
  queue.splice(idx, 0, info);
};
var enqueueEffectsFor = (prop, computeEffects, queue, order, hasPaths) => {
  const rootProperty = hasPaths ? root(prop) : prop;
  const fxs = computeEffects[rootProperty];
  if (fxs) {
    for (let i11 = 0; i11 < fxs.length; i11++) {
      const fx = fxs[i11];
      if (fx.info.lastRun !== dedupeId2 && (!hasPaths || pathMatchesTrigger(prop, fx.trigger))) {
        fx.info.lastRun = dedupeId2;
        insertEffect(fx.info, queue, order);
      }
    }
  }
};
function getComputedOrder(inst) {
  let ordered = inst.constructor.__orderedComputedDeps;
  if (!ordered) {
    ordered = /* @__PURE__ */ new Map();
    const effects = inst[TYPES.COMPUTE];
    let { counts, ready, total } = dependencyCounts(inst);
    let curr;
    while (curr = ready.shift()) {
      ordered.set(curr, ordered.size);
      const computedByCurr = effects[curr];
      if (computedByCurr) {
        computedByCurr.forEach((fx) => {
          const computedProp = fx.info.methodInfo;
          --total;
          if (--counts[computedProp] === 0) {
            ready.push(computedProp);
          }
        });
      }
    }
    if (total !== 0) {
      const el = (
        /** @type {HTMLElement} */
        inst
      );
      console.warn(`Computed graph for ${el.localName} incomplete; circular?`);
    }
    inst.constructor.__orderedComputedDeps = ordered;
  }
  return ordered;
}
function dependencyCounts(inst) {
  const infoForComputed = inst[COMPUTE_INFO];
  const counts = {};
  const computedDeps = inst[TYPES.COMPUTE];
  const ready = [];
  let total = 0;
  for (let p14 in infoForComputed) {
    const info = infoForComputed[p14];
    total += counts[p14] = info.args.filter((a17) => !a17.literal).length + (info.dynamicFn ? 1 : 0);
  }
  for (let p14 in computedDeps) {
    if (!infoForComputed[p14]) {
      ready.push(p14);
    }
  }
  return { counts, ready, total };
}
function runComputedEffect(inst, property, changedProps, oldProps, info) {
  let result = runMethodEffect(inst, property, changedProps, oldProps, info);
  if (result === NOOP) {
    return false;
  }
  let computedProp = info.methodInfo;
  if (inst.__dataHasAccessor && inst.__dataHasAccessor[computedProp]) {
    return inst._setPendingProperty(computedProp, result, true);
  } else {
    inst[computedProp] = result;
    return false;
  }
}
function computeLinkedPaths(inst, path, value) {
  let links = inst.__dataLinkedPaths;
  if (links) {
    let link;
    for (let a17 in links) {
      let b5 = links[a17];
      if (isDescendant(a17, path)) {
        link = translate(a17, b5, path);
        inst._setPendingPropertyOrPath(link, value, true, true);
      } else if (isDescendant(b5, path)) {
        link = translate(b5, a17, path);
        inst._setPendingPropertyOrPath(link, value, true, true);
      }
    }
  }
}
function addBinding(constructor, templateInfo, nodeInfo, kind, target, parts, literal) {
  nodeInfo.bindings = nodeInfo.bindings || [];
  let binding = { kind, target, parts, literal, isCompound: parts.length !== 1 };
  nodeInfo.bindings.push(binding);
  if (shouldAddListener(binding)) {
    let { event, negate } = binding.parts[0];
    binding.listenerEvent = event || camelToDashCase(target) + "-changed";
    binding.listenerNegate = negate;
  }
  let index = templateInfo.nodeInfoList.length;
  for (let i11 = 0; i11 < binding.parts.length; i11++) {
    let part = binding.parts[i11];
    part.compoundIndex = i11;
    addEffectForBindingPart(constructor, templateInfo, binding, part, index);
  }
}
function addEffectForBindingPart(constructor, templateInfo, binding, part, index) {
  if (!part.literal) {
    if (binding.kind === "attribute" && binding.target[0] === "-") {
      console.warn("Cannot set attribute " + binding.target + ' because "-" is not a valid attribute starting character');
    } else {
      let dependencies = part.dependencies;
      let info = { index, binding, part, evaluator: constructor };
      for (let j4 = 0; j4 < dependencies.length; j4++) {
        let trigger = dependencies[j4];
        if (typeof trigger == "string") {
          trigger = parseArg(trigger);
          trigger.wildcard = true;
        }
        constructor._addTemplatePropertyEffect(templateInfo, trigger.rootProperty, {
          fn: runBindingEffect,
          info,
          trigger
        });
      }
    }
  }
}
function runBindingEffect(inst, path, props, oldProps, info, hasPaths, nodeList) {
  let node = nodeList[info.index];
  let binding = info.binding;
  let part = info.part;
  if (hasPaths && part.source && path.length > part.source.length && binding.kind == "property" && !binding.isCompound && node.__isPropertyEffectsClient && node.__dataHasAccessor && node.__dataHasAccessor[binding.target]) {
    let value = props[path];
    path = translate(part.source, binding.target, path);
    if (node._setPendingPropertyOrPath(path, value, false, true)) {
      inst._enqueueClient(node);
    }
  } else {
    let value = info.evaluator._evaluateBinding(inst, part, path, props, oldProps, hasPaths);
    if (value !== NOOP) {
      applyBindingValue(inst, node, binding, part, value);
    }
  }
}
function applyBindingValue(inst, node, binding, part, value) {
  value = computeBindingValue(node, value, binding, part);
  if (sanitizeDOMValue) {
    value = sanitizeDOMValue(value, binding.target, binding.kind, node);
  }
  if (binding.kind == "attribute") {
    inst._valueToNodeAttribute(
      /** @type {Element} */
      node,
      value,
      binding.target
    );
  } else {
    let prop = binding.target;
    if (node.__isPropertyEffectsClient && node.__dataHasAccessor && node.__dataHasAccessor[prop]) {
      if (!node[TYPES.READ_ONLY] || !node[TYPES.READ_ONLY][prop]) {
        if (node._setPendingProperty(prop, value)) {
          inst._enqueueClient(node);
        }
      }
    } else {
      inst._setUnmanagedPropertyToNode(node, prop, value);
    }
  }
}
function computeBindingValue(node, value, binding, part) {
  if (binding.isCompound) {
    let storage = node.__dataCompoundStorage[binding.target];
    storage[part.compoundIndex] = value;
    value = storage.join("");
  }
  if (binding.kind !== "attribute") {
    if (binding.target === "textContent" || binding.target === "value" && (node.localName === "input" || node.localName === "textarea")) {
      value = value == void 0 ? "" : value;
    }
  }
  return value;
}
function shouldAddListener(binding) {
  return Boolean(binding.target) && binding.kind != "attribute" && binding.kind != "text" && !binding.isCompound && binding.parts[0].mode === "{";
}
function setupBindings(inst, templateInfo) {
  let { nodeList, nodeInfoList } = templateInfo;
  if (nodeInfoList.length) {
    for (let i11 = 0; i11 < nodeInfoList.length; i11++) {
      let info = nodeInfoList[i11];
      let node = nodeList[i11];
      let bindings = info.bindings;
      if (bindings) {
        for (let i12 = 0; i12 < bindings.length; i12++) {
          let binding = bindings[i12];
          setupCompoundStorage(node, binding);
          addNotifyListener(node, inst, binding);
        }
      }
      node.__dataHost = inst;
    }
  }
}
function setupCompoundStorage(node, binding) {
  if (binding.isCompound) {
    let storage = node.__dataCompoundStorage || (node.__dataCompoundStorage = {});
    let parts = binding.parts;
    let literals = new Array(parts.length);
    for (let j4 = 0; j4 < parts.length; j4++) {
      literals[j4] = parts[j4].literal;
    }
    let target = binding.target;
    storage[target] = literals;
    if (binding.literal && binding.kind == "property") {
      if (target === "className") {
        node = wrap(node);
      }
      node[target] = binding.literal;
    }
  }
}
function addNotifyListener(node, inst, binding) {
  if (binding.listenerEvent) {
    let part = binding.parts[0];
    node.addEventListener(binding.listenerEvent, function(e13) {
      handleNotification(e13, inst, binding.target, part.source, part.negate);
    });
  }
}
function createMethodEffect(model, sig, type, effectFn, methodInfo, dynamicFn) {
  dynamicFn = sig.static || dynamicFn && (typeof dynamicFn !== "object" || dynamicFn[sig.methodName]);
  let info = {
    methodName: sig.methodName,
    args: sig.args,
    methodInfo,
    dynamicFn
  };
  for (let i11 = 0, arg; i11 < sig.args.length && (arg = sig.args[i11]); i11++) {
    if (!arg.literal) {
      model._addPropertyEffect(arg.rootProperty, type, {
        fn: effectFn,
        info,
        trigger: arg
      });
    }
  }
  if (dynamicFn) {
    model._addPropertyEffect(sig.methodName, type, {
      fn: effectFn,
      info
    });
  }
  return info;
}
function runMethodEffect(inst, property, props, oldProps, info) {
  let context = inst._methodHost || inst;
  let fn = context[info.methodName];
  if (fn) {
    let args = inst._marshalArgs(info.args, property, props);
    return args === NOOP ? NOOP : fn.apply(context, args);
  } else if (!info.dynamicFn) {
    console.warn("method `" + info.methodName + "` not defined");
  }
}
var emptyArray = [];
var IDENT = "(?:[a-zA-Z_$][\\w.:$\\-*]*)";
var NUMBER = "(?:[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)";
var SQUOTE_STRING = "(?:'(?:[^'\\\\]|\\\\.)*')";
var DQUOTE_STRING = '(?:"(?:[^"\\\\]|\\\\.)*")';
var STRING = "(?:" + SQUOTE_STRING + "|" + DQUOTE_STRING + ")";
var ARGUMENT = "(?:(" + IDENT + "|" + NUMBER + "|" + STRING + ")\\s*)";
var ARGUMENTS = "(?:" + ARGUMENT + "(?:,\\s*" + ARGUMENT + ")*)";
var ARGUMENT_LIST = "(?:\\(\\s*(?:" + ARGUMENTS + "?)\\)\\s*)";
var BINDING = "(" + IDENT + "\\s*" + ARGUMENT_LIST + "?)";
var OPEN_BRACKET = "(\\[\\[|{{)\\s*";
var CLOSE_BRACKET = "(?:]]|}})";
var NEGATE = "(?:(!)\\s*)?";
var EXPRESSION = OPEN_BRACKET + NEGATE + BINDING + CLOSE_BRACKET;
var bindingRegex = new RegExp(EXPRESSION, "g");
function literalFromParts(parts) {
  let s18 = "";
  for (let i11 = 0; i11 < parts.length; i11++) {
    let literal = parts[i11].literal;
    s18 += literal || "";
  }
  return s18;
}
function parseMethod(expression) {
  let m8 = expression.match(/([^\s]+?)\(([\s\S]*)\)/);
  if (m8) {
    let methodName = m8[1];
    let sig = { methodName, static: true, args: emptyArray };
    if (m8[2].trim()) {
      let args = m8[2].replace(/\\,/g, "&comma;").split(",");
      return parseArgs(args, sig);
    } else {
      return sig;
    }
  }
  return null;
}
function parseArgs(argList, sig) {
  sig.args = argList.map(function(rawArg) {
    let arg = parseArg(rawArg);
    if (!arg.literal) {
      sig.static = false;
    }
    return arg;
  }, this);
  return sig;
}
function parseArg(rawArg) {
  let arg = rawArg.trim().replace(/&comma;/g, ",").replace(/\\(.)/g, "$1");
  let a17 = {
    name: arg,
    value: "",
    literal: false
  };
  let fc = arg[0];
  if (fc === "-") {
    fc = arg[1];
  }
  if (fc >= "0" && fc <= "9") {
    fc = "#";
  }
  switch (fc) {
    case "'":
    case '"':
      a17.value = arg.slice(1, -1);
      a17.literal = true;
      break;
    case "#":
      a17.value = Number(arg);
      a17.literal = true;
      break;
  }
  if (!a17.literal) {
    a17.rootProperty = root(arg);
    a17.structured = isPath(arg);
    if (a17.structured) {
      a17.wildcard = arg.slice(-2) == ".*";
      if (a17.wildcard) {
        a17.name = arg.slice(0, -2);
      }
    }
  }
  return a17;
}
function getArgValue(data, props, path) {
  let value = get(data, path);
  if (value === void 0) {
    value = props[path];
  }
  return value;
}
function notifySplices(inst, array, path, splices) {
  const splicesData = { indexSplices: splices };
  if (legacyUndefined && !inst._overrideLegacyUndefined) {
    array.splices = splicesData;
  }
  inst.notifyPath(path + ".splices", splicesData);
  inst.notifyPath(path + ".length", array.length);
  if (legacyUndefined && !inst._overrideLegacyUndefined) {
    splicesData.indexSplices = [];
  }
}
function notifySplice(inst, array, path, index, addedCount, removed) {
  notifySplices(inst, array, path, [{
    index,
    addedCount,
    removed,
    object: array,
    type: "splice"
  }]);
}
function upper(name) {
  return name[0].toUpperCase() + name.substring(1);
}
var PropertyEffects = dedupingMixin((superClass) => {
  const propertyEffectsBase = TemplateStamp(PropertyAccessors(superClass));
  class PropertyEffects2 extends propertyEffectsBase {
    constructor() {
      super();
      this.__isPropertyEffectsClient = true;
      this.__dataClientsReady;
      this.__dataPendingClients;
      this.__dataToNotify;
      this.__dataLinkedPaths;
      this.__dataHasPaths;
      this.__dataCompoundStorage;
      this.__dataHost;
      this.__dataTemp;
      this.__dataClientsInitialized;
      this.__data;
      this.__dataPending;
      this.__dataOld;
      this.__computeEffects;
      this.__computeInfo;
      this.__reflectEffects;
      this.__notifyEffects;
      this.__propagateEffects;
      this.__observeEffects;
      this.__readOnly;
      this.__templateInfo;
      this._overrideLegacyUndefined;
    }
    get PROPERTY_EFFECT_TYPES() {
      return TYPES;
    }
    /**
     * @override
     * @return {void}
     */
    _initializeProperties() {
      super._initializeProperties();
      this._registerHost();
      this.__dataClientsReady = false;
      this.__dataPendingClients = null;
      this.__dataToNotify = null;
      this.__dataLinkedPaths = null;
      this.__dataHasPaths = false;
      this.__dataCompoundStorage = this.__dataCompoundStorage || null;
      this.__dataHost = this.__dataHost || null;
      this.__dataTemp = {};
      this.__dataClientsInitialized = false;
    }
    _registerHost() {
      if (hostStack.length) {
        let host = hostStack[hostStack.length - 1];
        host._enqueueClient(this);
        this.__dataHost = host;
      }
    }
    /**
     * Overrides `PropertyAccessors` implementation to provide a
     * more efficient implementation of initializing properties from
     * the prototype on the instance.
     *
     * @override
     * @param {Object} props Properties to initialize on the prototype
     * @return {void}
     */
    _initializeProtoProperties(props) {
      this.__data = Object.create(props);
      this.__dataPending = Object.create(props);
      this.__dataOld = {};
    }
    /**
     * Overrides `PropertyAccessors` implementation to avoid setting
     * `_setProperty`'s `shouldNotify: true`.
     *
     * @override
     * @param {Object} props Properties to initialize on the instance
     * @return {void}
     */
    _initializeInstanceProperties(props) {
      let readOnly = this[TYPES.READ_ONLY];
      for (let prop in props) {
        if (!readOnly || !readOnly[prop]) {
          this.__dataPending = this.__dataPending || {};
          this.__dataOld = this.__dataOld || {};
          this.__data[prop] = this.__dataPending[prop] = props[prop];
        }
      }
    }
    // Prototype setup ----------------------------------------
    /**
     * Equivalent to static `addPropertyEffect` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} property Property that should trigger the effect
     * @param {string} type Effect type, from this.PROPERTY_EFFECT_TYPES
     * @param {Object=} effect Effect metadata object
     * @return {void}
     * @protected
     */
    _addPropertyEffect(property, type, effect) {
      this._createPropertyAccessor(property, type == TYPES.READ_ONLY);
      let effects = ensureOwnEffectMap(this, type, true)[property];
      if (!effects) {
        effects = this[type][property] = [];
      }
      effects.push(effect);
    }
    /**
     * Removes the given property effect.
     *
     * @override
     * @param {string} property Property the effect was associated with
     * @param {string} type Effect type, from this.PROPERTY_EFFECT_TYPES
     * @param {Object=} effect Effect metadata object to remove
     * @return {void}
     */
    _removePropertyEffect(property, type, effect) {
      let effects = ensureOwnEffectMap(this, type, true)[property];
      let idx = effects.indexOf(effect);
      if (idx >= 0) {
        effects.splice(idx, 1);
      }
    }
    /**
     * Returns whether the current prototype/instance has a property effect
     * of a certain type.
     *
     * @override
     * @param {string} property Property name
     * @param {string=} type Effect type, from this.PROPERTY_EFFECT_TYPES
     * @return {boolean} True if the prototype/instance has an effect of this
     *     type
     * @protected
     */
    _hasPropertyEffect(property, type) {
      let effects = this[type];
      return Boolean(effects && effects[property]);
    }
    /**
     * Returns whether the current prototype/instance has a "read only"
     * accessor for the given property.
     *
     * @override
     * @param {string} property Property name
     * @return {boolean} True if the prototype/instance has an effect of this
     *     type
     * @protected
     */
    _hasReadOnlyEffect(property) {
      return this._hasPropertyEffect(property, TYPES.READ_ONLY);
    }
    /**
     * Returns whether the current prototype/instance has a "notify"
     * property effect for the given property.
     *
     * @override
     * @param {string} property Property name
     * @return {boolean} True if the prototype/instance has an effect of this
     *     type
     * @protected
     */
    _hasNotifyEffect(property) {
      return this._hasPropertyEffect(property, TYPES.NOTIFY);
    }
    /**
     * Returns whether the current prototype/instance has a "reflect to
     * attribute" property effect for the given property.
     *
     * @override
     * @param {string} property Property name
     * @return {boolean} True if the prototype/instance has an effect of this
     *     type
     * @protected
     */
    _hasReflectEffect(property) {
      return this._hasPropertyEffect(property, TYPES.REFLECT);
    }
    /**
     * Returns whether the current prototype/instance has a "computed"
     * property effect for the given property.
     *
     * @override
     * @param {string} property Property name
     * @return {boolean} True if the prototype/instance has an effect of this
     *     type
     * @protected
     */
    _hasComputedEffect(property) {
      return this._hasPropertyEffect(property, TYPES.COMPUTE);
    }
    // Runtime ----------------------------------------
    /**
     * Sets a pending property or path.  If the root property of the path in
     * question had no accessor, the path is set, otherwise it is enqueued
     * via `_setPendingProperty`.
     *
     * This function isolates relatively expensive functionality necessary
     * for the public API (`set`, `setProperties`, `notifyPath`, and property
     * change listeners via {{...}} bindings), such that it is only done
     * when paths enter the system, and not at every propagation step.  It
     * also sets a `__dataHasPaths` flag on the instance which is used to
     * fast-path slower path-matching code in the property effects host paths.
     *
     * `path` can be a path string or array of path parts as accepted by the
     * public API.
     *
     * @override
     * @param {string | !Array<number|string>} path Path to set
     * @param {*} value Value to set
     * @param {boolean=} shouldNotify Set to true if this change should
     *  cause a property notification event dispatch
     * @param {boolean=} isPathNotification If the path being set is a path
     *   notification of an already changed value, as opposed to a request
     *   to set and notify the change.  In the latter `false` case, a dirty
     *   check is performed and then the value is set to the path before
     *   enqueuing the pending property change.
     * @return {boolean} Returns true if the property/path was enqueued in
     *   the pending changes bag.
     * @protected
     */
    _setPendingPropertyOrPath(path, value, shouldNotify, isPathNotification) {
      if (isPathNotification || root(Array.isArray(path) ? path[0] : path) !== path) {
        if (!isPathNotification) {
          let old = get(this, path);
          path = /** @type {string} */
          set(this, path, value);
          if (!path || !super._shouldPropertyChange(path, value, old)) {
            return false;
          }
        }
        this.__dataHasPaths = true;
        if (this._setPendingProperty(
          /**@type{string}*/
          path,
          value,
          shouldNotify
        )) {
          computeLinkedPaths(
            this,
            /**@type{string}*/
            path,
            value
          );
          return true;
        }
      } else {
        if (this.__dataHasAccessor && this.__dataHasAccessor[path]) {
          return this._setPendingProperty(
            /**@type{string}*/
            path,
            value,
            shouldNotify
          );
        } else {
          this[path] = value;
        }
      }
      return false;
    }
    /**
     * Applies a value to a non-Polymer element/node's property.
     *
     * The implementation makes a best-effort at binding interop:
     * Some native element properties have side-effects when
     * re-setting the same value (e.g. setting `<input>.value` resets the
     * cursor position), so we do a dirty-check before setting the value.
     * However, for better interop with non-Polymer custom elements that
     * accept objects, we explicitly re-set object changes coming from the
     * Polymer world (which may include deep object changes without the
     * top reference changing), erring on the side of providing more
     * information.
     *
     * Users may override this method to provide alternate approaches.
     *
     * @override
     * @param {!Node} node The node to set a property on
     * @param {string} prop The property to set
     * @param {*} value The value to set
     * @return {void}
     * @protected
     */
    _setUnmanagedPropertyToNode(node, prop, value) {
      if (value !== node[prop] || typeof value == "object") {
        if (prop === "className") {
          node = /** @type {!Node} */
          wrap(node);
        }
        node[prop] = value;
      }
    }
    /**
     * Overrides the `PropertiesChanged` implementation to introduce special
     * dirty check logic depending on the property & value being set:
     *
     * 1. Any value set to a path (e.g. 'obj.prop': 42 or 'obj.prop': {...})
     *    Stored in `__dataTemp`, dirty checked against `__dataTemp`
     * 2. Object set to simple property (e.g. 'prop': {...})
     *    Stored in `__dataTemp` and `__data`, dirty checked against
     *    `__dataTemp` by default implementation of `_shouldPropertyChange`
     * 3. Primitive value set to simple property (e.g. 'prop': 42)
     *    Stored in `__data`, dirty checked against `__data`
     *
     * The dirty-check is important to prevent cycles due to two-way
     * notification, but paths and objects are only dirty checked against any
     * previous value set during this turn via a "temporary cache" that is
     * cleared when the last `_propertiesChanged` exits. This is so:
     * a. any cached array paths (e.g. 'array.3.prop') may be invalidated
     *    due to array mutations like shift/unshift/splice; this is fine
     *    since path changes are dirty-checked at user entry points like `set`
     * b. dirty-checking for objects only lasts one turn to allow the user
     *    to mutate the object in-place and re-set it with the same identity
     *    and have all sub-properties re-propagated in a subsequent turn.
     *
     * The temp cache is not necessarily sufficient to prevent invalid array
     * paths, since a splice can happen during the same turn (with pathological
     * user code); we could introduce a "fixup" for temporarily cached array
     * paths if needed: https://github.com/Polymer/polymer/issues/4227
     *
     * @override
     * @param {string} property Name of the property
     * @param {*} value Value to set
     * @param {boolean=} shouldNotify True if property should fire notification
     *   event (applies only for `notify: true` properties)
     * @return {boolean} Returns true if the property changed
     */
    _setPendingProperty(property, value, shouldNotify) {
      let propIsPath = this.__dataHasPaths && isPath(property);
      let prevProps = propIsPath ? this.__dataTemp : this.__data;
      if (this._shouldPropertyChange(property, value, prevProps[property])) {
        if (!this.__dataPending) {
          this.__dataPending = {};
          this.__dataOld = {};
        }
        if (!(property in this.__dataOld)) {
          this.__dataOld[property] = this.__data[property];
        }
        if (propIsPath) {
          this.__dataTemp[property] = value;
        } else {
          this.__data[property] = value;
        }
        this.__dataPending[property] = value;
        if (propIsPath || this[TYPES.NOTIFY] && this[TYPES.NOTIFY][property]) {
          this.__dataToNotify = this.__dataToNotify || {};
          this.__dataToNotify[property] = shouldNotify;
        }
        return true;
      }
      return false;
    }
    /**
     * Overrides base implementation to ensure all accessors set `shouldNotify`
     * to true, for per-property notification tracking.
     *
     * @override
     * @param {string} property Name of the property
     * @param {*} value Value to set
     * @return {void}
     */
    _setProperty(property, value) {
      if (this._setPendingProperty(property, value, true)) {
        this._invalidateProperties();
      }
    }
    /**
     * Overrides `PropertyAccessor`'s default async queuing of
     * `_propertiesChanged`: if `__dataReady` is false (has not yet been
     * manually flushed), the function no-ops; otherwise flushes
     * `_propertiesChanged` synchronously.
     *
     * @override
     * @return {void}
     */
    _invalidateProperties() {
      if (this.__dataReady) {
        this._flushProperties();
      }
    }
    /**
     * Enqueues the given client on a list of pending clients, whose
     * pending property changes can later be flushed via a call to
     * `_flushClients`.
     *
     * @override
     * @param {Object} client PropertyEffects client to enqueue
     * @return {void}
     * @protected
     */
    _enqueueClient(client) {
      this.__dataPendingClients = this.__dataPendingClients || [];
      if (client !== this) {
        this.__dataPendingClients.push(client);
      }
    }
    /**
     * Flushes any clients previously enqueued via `_enqueueClient`, causing
     * their `_flushProperties` method to run.
     *
     * @override
     * @return {void}
     * @protected
     */
    _flushClients() {
      if (!this.__dataClientsReady) {
        this.__dataClientsReady = true;
        this._readyClients();
        this.__dataReady = true;
      } else {
        this.__enableOrFlushClients();
      }
    }
    // NOTE: We ensure clients either enable or flush as appropriate. This
    // handles two corner cases:
    // (1) clients flush properly when connected/enabled before the host
    // enables; e.g.
    //   (a) Templatize stamps with no properties and does not flush and
    //   (b) the instance is inserted into dom and
    //   (c) then the instance flushes.
    // (2) clients enable properly when not connected/enabled when the host
    // flushes; e.g.
    //   (a) a template is runtime stamped and not yet connected/enabled
    //   (b) a host sets a property, causing stamped dom to flush
    //   (c) the stamped dom enables.
    __enableOrFlushClients() {
      let clients = this.__dataPendingClients;
      if (clients) {
        this.__dataPendingClients = null;
        for (let i11 = 0; i11 < clients.length; i11++) {
          let client = clients[i11];
          if (!client.__dataEnabled) {
            client._enableProperties();
          } else if (client.__dataPending) {
            client._flushProperties();
          }
        }
      }
    }
    /**
     * Perform any initial setup on client dom. Called before the first
     * `_flushProperties` call on client dom and before any element
     * observers are called.
     *
     * @override
     * @return {void}
     * @protected
     */
    _readyClients() {
      this.__enableOrFlushClients();
    }
    /**
     * Sets a bag of property changes to this instance, and
     * synchronously processes all effects of the properties as a batch.
     *
     * Property names must be simple properties, not paths.  Batched
     * path propagation is not supported.
     *
     * @override
     * @param {Object} props Bag of one or more key-value pairs whose key is
     *   a property and value is the new value to set for that property.
     * @param {boolean=} setReadOnly When true, any private values set in
     *   `props` will be set. By default, `setProperties` will not set
     *   `readOnly: true` root properties.
     * @return {void}
     * @public
     */
    setProperties(props, setReadOnly) {
      for (let path in props) {
        if (setReadOnly || !this[TYPES.READ_ONLY] || !this[TYPES.READ_ONLY][path]) {
          this._setPendingPropertyOrPath(path, props[path], true);
        }
      }
      this._invalidateProperties();
    }
    /**
     * Overrides `PropertyAccessors` so that property accessor
     * side effects are not enabled until after client dom is fully ready.
     * Also calls `_flushClients` callback to ensure client dom is enabled
     * that was not enabled as a result of flushing properties.
     *
     * @override
     * @return {void}
     */
    ready() {
      this._flushProperties();
      if (!this.__dataClientsReady) {
        this._flushClients();
      }
      if (this.__dataPending) {
        this._flushProperties();
      }
    }
    /**
     * Implements `PropertyAccessors`'s properties changed callback.
     *
     * Runs each class of effects for the batch of changed properties in
     * a specific order (compute, propagate, reflect, observe, notify).
     *
     * @override
     * @param {!Object} currentProps Bag of all current accessor values
     * @param {?Object} changedProps Bag of properties changed since the last
     *   call to `_propertiesChanged`
     * @param {?Object} oldProps Bag of previous values for each property
     *   in `changedProps`
     * @return {void}
     */
    _propertiesChanged(currentProps, changedProps, oldProps) {
      let hasPaths = this.__dataHasPaths;
      this.__dataHasPaths = false;
      let notifyProps;
      runComputedEffects(this, changedProps, oldProps, hasPaths);
      notifyProps = this.__dataToNotify;
      this.__dataToNotify = null;
      this._propagatePropertyChanges(changedProps, oldProps, hasPaths);
      this._flushClients();
      runEffects(this, this[TYPES.REFLECT], changedProps, oldProps, hasPaths);
      runEffects(this, this[TYPES.OBSERVE], changedProps, oldProps, hasPaths);
      if (notifyProps) {
        runNotifyEffects(this, notifyProps, changedProps, oldProps, hasPaths);
      }
      if (this.__dataCounter == 1) {
        this.__dataTemp = {};
      }
    }
    /**
     * Called to propagate any property changes to stamped template nodes
     * managed by this element.
     *
     * @override
     * @param {Object} changedProps Bag of changed properties
     * @param {Object} oldProps Bag of previous values for changed properties
     * @param {boolean} hasPaths True with `props` contains one or more paths
     * @return {void}
     * @protected
     */
    _propagatePropertyChanges(changedProps, oldProps, hasPaths) {
      if (this[TYPES.PROPAGATE]) {
        runEffects(this, this[TYPES.PROPAGATE], changedProps, oldProps, hasPaths);
      }
      if (this.__templateInfo) {
        this._runEffectsForTemplate(this.__templateInfo, changedProps, oldProps, hasPaths);
      }
    }
    _runEffectsForTemplate(templateInfo, changedProps, oldProps, hasPaths) {
      const baseRunEffects = (changedProps2, hasPaths2) => {
        runEffects(
          this,
          templateInfo.propertyEffects,
          changedProps2,
          oldProps,
          hasPaths2,
          templateInfo.nodeList
        );
        for (let info = templateInfo.firstChild; info; info = info.nextSibling) {
          this._runEffectsForTemplate(info, changedProps2, oldProps, hasPaths2);
        }
      };
      if (templateInfo.runEffects) {
        templateInfo.runEffects(baseRunEffects, changedProps, hasPaths);
      } else {
        baseRunEffects(changedProps, hasPaths);
      }
    }
    /**
     * Aliases one data path as another, such that path notifications from one
     * are routed to the other.
     *
     * @override
     * @param {string | !Array<string|number>} to Target path to link.
     * @param {string | !Array<string|number>} from Source path to link.
     * @return {void}
     * @public
     */
    linkPaths(to, from) {
      to = normalize(to);
      from = normalize(from);
      this.__dataLinkedPaths = this.__dataLinkedPaths || {};
      this.__dataLinkedPaths[to] = from;
    }
    /**
     * Removes a data path alias previously established with `_linkPaths`.
     *
     * Note, the path to unlink should be the target (`to`) used when
     * linking the paths.
     *
     * @override
     * @param {string | !Array<string|number>} path Target path to unlink.
     * @return {void}
     * @public
     */
    unlinkPaths(path) {
      path = normalize(path);
      if (this.__dataLinkedPaths) {
        delete this.__dataLinkedPaths[path];
      }
    }
    /**
     * Notify that an array has changed.
     *
     * Example:
     *
     *     this.items = [ {name: 'Jim'}, {name: 'Todd'}, {name: 'Bill'} ];
     *     ...
     *     this.items.splice(1, 1, {name: 'Sam'});
     *     this.items.push({name: 'Bob'});
     *     this.notifySplices('items', [
     *       { index: 1, removed: [{name: 'Todd'}], addedCount: 1,
     *         object: this.items, type: 'splice' },
     *       { index: 3, removed: [], addedCount: 1,
     *         object: this.items, type: 'splice'}
     *     ]);
     *
     * @param {string} path Path that should be notified.
     * @param {Array} splices Array of splice records indicating ordered
     *   changes that occurred to the array. Each record should have the
     *   following fields:
     *    * index: index at which the change occurred
     *    * removed: array of items that were removed from this index
     *    * addedCount: number of new items added at this index
     *    * object: a reference to the array in question
     *    * type: the string literal 'splice'
     *
     *   Note that splice records _must_ be normalized such that they are
     *   reported in index order (raw results from `Object.observe` are not
     *   ordered and must be normalized/merged before notifying).
     *
     * @override
     * @return {void}
     * @public
     */
    notifySplices(path, splices) {
      let info = { path: "" };
      let array = (
        /** @type {Array} */
        get(this, path, info)
      );
      notifySplices(this, array, info.path, splices);
    }
    /**
     * Convenience method for reading a value from a path.
     *
     * Note, if any part in the path is undefined, this method returns
     * `undefined` (this method does not throw when dereferencing undefined
     * paths).
     *
     * @override
     * @param {(string|!Array<(string|number)>)} path Path to the value
     *   to read.  The path may be specified as a string (e.g. `foo.bar.baz`)
     *   or an array of path parts (e.g. `['foo.bar', 'baz']`).  Note that
     *   bracketed expressions are not supported; string-based path parts
     *   *must* be separated by dots.  Note that when dereferencing array
     *   indices, the index may be used as a dotted part directly
     *   (e.g. `users.12.name` or `['users', 12, 'name']`).
     * @param {Object=} root Root object from which the path is evaluated.
     * @return {*} Value at the path, or `undefined` if any part of the path
     *   is undefined.
     * @public
     */
    get(path, root2) {
      return get(root2 || this, path);
    }
    /**
     * Convenience method for setting a value to a path and notifying any
     * elements bound to the same path.
     *
     * Note, if any part in the path except for the last is undefined,
     * this method does nothing (this method does not throw when
     * dereferencing undefined paths).
     *
     * @override
     * @param {(string|!Array<(string|number)>)} path Path to the value
     *   to write.  The path may be specified as a string (e.g. `'foo.bar.baz'`)
     *   or an array of path parts (e.g. `['foo.bar', 'baz']`).  Note that
     *   bracketed expressions are not supported; string-based path parts
     *   *must* be separated by dots.  Note that when dereferencing array
     *   indices, the index may be used as a dotted part directly
     *   (e.g. `'users.12.name'` or `['users', 12, 'name']`).
     * @param {*} value Value to set at the specified path.
     * @param {Object=} root Root object from which the path is evaluated.
     *   When specified, no notification will occur.
     * @return {void}
     * @public
     */
    set(path, value, root2) {
      if (root2) {
        set(root2, path, value);
      } else {
        if (!this[TYPES.READ_ONLY] || !this[TYPES.READ_ONLY][
          /** @type {string} */
          path
        ]) {
          if (this._setPendingPropertyOrPath(path, value, true)) {
            this._invalidateProperties();
          }
        }
      }
    }
    /**
     * Adds items onto the end of the array at the path specified.
     *
     * The arguments after `path` and return value match that of
     * `Array.prototype.push`.
     *
     * This method notifies other paths to the same array that a
     * splice occurred to the array.
     *
     * @override
     * @param {string | !Array<string|number>} path Path to array.
     * @param {...*} items Items to push onto array
     * @return {number} New length of the array.
     * @public
     */
    push(path, ...items) {
      let info = { path: "" };
      let array = (
        /** @type {Array}*/
        get(this, path, info)
      );
      let len = array.length;
      let ret = array.push(...items);
      if (items.length) {
        notifySplice(this, array, info.path, len, items.length, []);
      }
      return ret;
    }
    /**
     * Removes an item from the end of array at the path specified.
     *
     * The arguments after `path` and return value match that of
     * `Array.prototype.pop`.
     *
     * This method notifies other paths to the same array that a
     * splice occurred to the array.
     *
     * @override
     * @param {string | !Array<string|number>} path Path to array.
     * @return {*} Item that was removed.
     * @public
     */
    pop(path) {
      let info = { path: "" };
      let array = (
        /** @type {Array} */
        get(this, path, info)
      );
      let hadLength = Boolean(array.length);
      let ret = array.pop();
      if (hadLength) {
        notifySplice(this, array, info.path, array.length, 0, [ret]);
      }
      return ret;
    }
    /**
     * Starting from the start index specified, removes 0 or more items
     * from the array and inserts 0 or more new items in their place.
     *
     * The arguments after `path` and return value match that of
     * `Array.prototype.splice`.
     *
     * This method notifies other paths to the same array that a
     * splice occurred to the array.
     *
     * @override
     * @param {string | !Array<string|number>} path Path to array.
     * @param {number} start Index from which to start removing/inserting.
     * @param {number=} deleteCount Number of items to remove.
     * @param {...*} items Items to insert into array.
     * @return {!Array} Array of removed items.
     * @public
     */
    splice(path, start, deleteCount, ...items) {
      let info = { path: "" };
      let array = (
        /** @type {Array} */
        get(this, path, info)
      );
      if (start < 0) {
        start = array.length - Math.floor(-start);
      } else if (start) {
        start = Math.floor(start);
      }
      let ret;
      if (arguments.length === 2) {
        ret = array.splice(start);
      } else {
        ret = array.splice(start, deleteCount, ...items);
      }
      if (items.length || ret.length) {
        notifySplice(this, array, info.path, start, items.length, ret);
      }
      return ret;
    }
    /**
     * Removes an item from the beginning of array at the path specified.
     *
     * The arguments after `path` and return value match that of
     * `Array.prototype.pop`.
     *
     * This method notifies other paths to the same array that a
     * splice occurred to the array.
     *
     * @override
     * @param {string | !Array<string|number>} path Path to array.
     * @return {*} Item that was removed.
     * @public
     */
    shift(path) {
      let info = { path: "" };
      let array = (
        /** @type {Array} */
        get(this, path, info)
      );
      let hadLength = Boolean(array.length);
      let ret = array.shift();
      if (hadLength) {
        notifySplice(this, array, info.path, 0, 0, [ret]);
      }
      return ret;
    }
    /**
     * Adds items onto the beginning of the array at the path specified.
     *
     * The arguments after `path` and return value match that of
     * `Array.prototype.push`.
     *
     * This method notifies other paths to the same array that a
     * splice occurred to the array.
     *
     * @override
     * @param {string | !Array<string|number>} path Path to array.
     * @param {...*} items Items to insert info array
     * @return {number} New length of the array.
     * @public
     */
    unshift(path, ...items) {
      let info = { path: "" };
      let array = (
        /** @type {Array} */
        get(this, path, info)
      );
      let ret = array.unshift(...items);
      if (items.length) {
        notifySplice(this, array, info.path, 0, items.length, []);
      }
      return ret;
    }
    /**
     * Notify that a path has changed.
     *
     * Example:
     *
     *     this.item.user.name = 'Bob';
     *     this.notifyPath('item.user.name');
     *
     * @override
     * @param {string} path Path that should be notified.
     * @param {*=} value Value at the path (optional).
     * @return {void}
     * @public
     */
    notifyPath(path, value) {
      let propPath;
      if (arguments.length == 1) {
        let info = { path: "" };
        value = get(this, path, info);
        propPath = info.path;
      } else if (Array.isArray(path)) {
        propPath = normalize(path);
      } else {
        propPath = /** @type{string} */
        path;
      }
      if (this._setPendingPropertyOrPath(propPath, value, true, true)) {
        this._invalidateProperties();
      }
    }
    /**
     * Equivalent to static `createReadOnlyProperty` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} property Property name
     * @param {boolean=} protectedSetter Creates a custom protected setter
     *   when `true`.
     * @return {void}
     * @protected
     */
    _createReadOnlyProperty(property, protectedSetter) {
      this._addPropertyEffect(property, TYPES.READ_ONLY);
      if (protectedSetter) {
        this["_set" + upper(property)] = /** @this {PropertyEffects} */
        function(value) {
          this._setProperty(property, value);
        };
      }
    }
    /**
     * Equivalent to static `createPropertyObserver` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} property Property name
     * @param {string|function(*,*)} method Function or name of observer method
     *     to call
     * @param {boolean=} dynamicFn Whether the method name should be included as
     *   a dependency to the effect.
     * @return {void}
     * @protected
     */
    _createPropertyObserver(property, method, dynamicFn) {
      let info = { property, method, dynamicFn: Boolean(dynamicFn) };
      this._addPropertyEffect(property, TYPES.OBSERVE, {
        fn: runObserverEffect,
        info,
        trigger: { name: property }
      });
      if (dynamicFn) {
        this._addPropertyEffect(
          /** @type {string} */
          method,
          TYPES.OBSERVE,
          {
            fn: runObserverEffect,
            info,
            trigger: { name: method }
          }
        );
      }
    }
    /**
     * Equivalent to static `createMethodObserver` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} expression Method expression
     * @param {boolean|Object=} dynamicFn Boolean or object map indicating
     *   whether method names should be included as a dependency to the effect.
     * @return {void}
     * @protected
     */
    _createMethodObserver(expression, dynamicFn) {
      let sig = parseMethod(expression);
      if (!sig) {
        throw new Error("Malformed observer expression '" + expression + "'");
      }
      createMethodEffect(this, sig, TYPES.OBSERVE, runMethodEffect, null, dynamicFn);
    }
    /**
     * Equivalent to static `createNotifyingProperty` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} property Property name
     * @return {void}
     * @protected
     */
    _createNotifyingProperty(property) {
      this._addPropertyEffect(property, TYPES.NOTIFY, {
        fn: runNotifyEffect,
        info: {
          eventName: camelToDashCase(property) + "-changed",
          property
        }
      });
    }
    /**
     * Equivalent to static `createReflectedProperty` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} property Property name
     * @return {void}
     * @protected
     * @suppress {missingProperties} go/missingfnprops
     */
    _createReflectedProperty(property) {
      let attr = this.constructor.attributeNameForProperty(property);
      if (attr[0] === "-") {
        console.warn("Property " + property + " cannot be reflected to attribute " + attr + ' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.');
      } else {
        this._addPropertyEffect(property, TYPES.REFLECT, {
          fn: runReflectEffect,
          info: {
            attrName: attr
          }
        });
      }
    }
    /**
     * Equivalent to static `createComputedProperty` API but can be called on
     * an instance to add effects at runtime.  See that method for
     * full API docs.
     *
     * @override
     * @param {string} property Name of computed property to set
     * @param {string} expression Method expression
     * @param {boolean|Object=} dynamicFn Boolean or object map indicating
     *   whether method names should be included as a dependency to the effect.
     * @return {void}
     * @protected
     */
    _createComputedProperty(property, expression, dynamicFn) {
      let sig = parseMethod(expression);
      if (!sig) {
        throw new Error("Malformed computed expression '" + expression + "'");
      }
      const info = createMethodEffect(this, sig, TYPES.COMPUTE, runComputedEffect, property, dynamicFn);
      ensureOwnEffectMap(this, COMPUTE_INFO)[property] = info;
    }
    /**
     * Gather the argument values for a method specified in the provided array
     * of argument metadata.
     *
     * The `path` and `value` arguments are used to fill in wildcard descriptor
     * when the method is being called as a result of a path notification.
     *
     * @param {!Array<!MethodArg>} args Array of argument metadata
     * @param {string} path Property/path name that triggered the method effect
     * @param {Object} props Bag of current property changes
     * @return {!Array<*>} Array of argument values
     * @private
     */
    _marshalArgs(args, path, props) {
      const data = this.__data;
      const values = [];
      for (let i11 = 0, l10 = args.length; i11 < l10; i11++) {
        let { name, structured, wildcard, value, literal } = args[i11];
        if (!literal) {
          if (wildcard) {
            const matches = isDescendant(name, path);
            const pathValue = getArgValue(data, props, matches ? path : name);
            value = {
              path: matches ? path : name,
              value: pathValue,
              base: matches ? get(data, name) : pathValue
            };
          } else {
            value = structured ? getArgValue(data, props, name) : data[name];
          }
        }
        if (legacyUndefined && !this._overrideLegacyUndefined && value === void 0 && args.length > 1) {
          return NOOP;
        }
        values[i11] = value;
      }
      return values;
    }
    // -- static class methods ------------
    /**
     * Ensures an accessor exists for the specified property, and adds
     * to a list of "property effects" that will run when the accessor for
     * the specified property is set.  Effects are grouped by "type", which
     * roughly corresponds to a phase in effect processing.  The effect
     * metadata should be in the following form:
     *
     *     {
     *       fn: effectFunction, // Reference to function to call to perform effect
     *       info: { ... }       // Effect metadata passed to function
     *       trigger: {          // Optional triggering metadata; if not provided
     *         name: string      // the property is treated as a wildcard
     *         structured: boolean
     *         wildcard: boolean
     *       }
     *     }
     *
     * Effects are called from `_propertiesChanged` in the following order by
     * type:
     *
     * 1. COMPUTE
     * 2. PROPAGATE
     * 3. REFLECT
     * 4. OBSERVE
     * 5. NOTIFY
     *
     * Effect functions are called with the following signature:
     *
     *     effectFunction(inst, path, props, oldProps, info, hasPaths)
     *
     * @param {string} property Property that should trigger the effect
     * @param {string} type Effect type, from this.PROPERTY_EFFECT_TYPES
     * @param {Object=} effect Effect metadata object
     * @return {void}
     * @protected
     * @nocollapse
     */
    static addPropertyEffect(property, type, effect) {
      this.prototype._addPropertyEffect(property, type, effect);
    }
    /**
     * Creates a single-property observer for the given property.
     *
     * @param {string} property Property name
     * @param {string|function(*,*)} method Function or name of observer method to call
     * @param {boolean=} dynamicFn Whether the method name should be included as
     *   a dependency to the effect.
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createPropertyObserver(property, method, dynamicFn) {
      this.prototype._createPropertyObserver(property, method, dynamicFn);
    }
    /**
     * Creates a multi-property "method observer" based on the provided
     * expression, which should be a string in the form of a normal JavaScript
     * function signature: `'methodName(arg1, [..., argn])'`.  Each argument
     * should correspond to a property or path in the context of this
     * prototype (or instance), or may be a literal string or number.
     *
     * @param {string} expression Method expression
     * @param {boolean|Object=} dynamicFn Boolean or object map indicating
     * @return {void}
     *   whether method names should be included as a dependency to the effect.
     * @protected
     * @nocollapse
     */
    static createMethodObserver(expression, dynamicFn) {
      this.prototype._createMethodObserver(expression, dynamicFn);
    }
    /**
     * Causes the setter for the given property to dispatch `<property>-changed`
     * events to notify of changes to the property.
     *
     * @param {string} property Property name
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createNotifyingProperty(property) {
      this.prototype._createNotifyingProperty(property);
    }
    /**
     * Creates a read-only accessor for the given property.
     *
     * To set the property, use the protected `_setProperty` API.
     * To create a custom protected setter (e.g. `_setMyProp()` for
     * property `myProp`), pass `true` for `protectedSetter`.
     *
     * Note, if the property will have other property effects, this method
     * should be called first, before adding other effects.
     *
     * @param {string} property Property name
     * @param {boolean=} protectedSetter Creates a custom protected setter
     *   when `true`.
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createReadOnlyProperty(property, protectedSetter) {
      this.prototype._createReadOnlyProperty(property, protectedSetter);
    }
    /**
     * Causes the setter for the given property to reflect the property value
     * to a (dash-cased) attribute of the same name.
     *
     * @param {string} property Property name
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createReflectedProperty(property) {
      this.prototype._createReflectedProperty(property);
    }
    /**
     * Creates a computed property whose value is set to the result of the
     * method described by the given `expression` each time one or more
     * arguments to the method changes.  The expression should be a string
     * in the form of a normal JavaScript function signature:
     * `'methodName(arg1, [..., argn])'`
     *
     * @param {string} property Name of computed property to set
     * @param {string} expression Method expression
     * @param {boolean|Object=} dynamicFn Boolean or object map indicating whether
     *   method names should be included as a dependency to the effect.
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createComputedProperty(property, expression, dynamicFn) {
      this.prototype._createComputedProperty(property, expression, dynamicFn);
    }
    /**
     * Parses the provided template to ensure binding effects are created
     * for them, and then ensures property accessors are created for any
     * dependent properties in the template.  Binding effects for bound
     * templates are stored in a linked list on the instance so that
     * templates can be efficiently stamped and unstamped.
     *
     * @param {!HTMLTemplateElement} template Template containing binding
     *   bindings
     * @return {!TemplateInfo} Template metadata object
     * @protected
     * @nocollapse
     */
    static bindTemplate(template2) {
      return this.prototype._bindTemplate(template2);
    }
    // -- binding ----------------------------------------------
    /*
     * Overview of binding flow:
     *
     * During finalization (`instanceBinding==false`, `wasPreBound==false`):
     *  `_bindTemplate(t, false)` called directly during finalization - parses
     *  the template (for the first time), and then assigns that _prototypical_
     *  template info to `__preboundTemplateInfo` _on the prototype_; note in
     *  this case `wasPreBound` is false; this is the first time we're binding
     *  it, thus we create accessors.
     *
     * During first stamping (`instanceBinding==true`, `wasPreBound==true`):
     *   `_stampTemplate` calls `_bindTemplate(t, true)`: the `templateInfo`
     *   returned matches the prebound one, and so this is `wasPreBound == true`
     *   state; thus we _skip_ creating accessors, but _do_ create an instance
     *   of the template info to serve as the start of our linked list (needs to
     *   be an instance, not the prototypical one, so that we can add `nodeList`
     *   to it to contain the `nodeInfo`-ordered list of instance nodes for
     *   bindings, and so we can chain runtime-stamped template infos off of
     *   it). At this point, the call to `_stampTemplate` calls
     *   `applyTemplateInfo` for each nested `<template>` found during parsing
     *   to hand prototypical `_templateInfo` to them; we also pass the _parent_
     *   `templateInfo` to the `<template>` so that we have the instance-time
     *   parent to link the `templateInfo` under in the case it was
     *   runtime-stamped.
     *
     * During subsequent runtime stamping (`instanceBinding==true`,
     *   `wasPreBound==false`): `_stampTemplate` calls `_bindTemplate(t, true)`
     *   - here `templateInfo` is guaranteed to _not_ match the prebound one,
     *   because it was either a different template altogether, or even if it
     *   was the same template, the step above created a instance of the info;
     *   in this case `wasPreBound == false`, so we _do_ create accessors, _and_
     *   link a instance into the linked list.
     */
    /**
     * Equivalent to static `bindTemplate` API but can be called on an instance
     * to add effects at runtime.  See that method for full API docs.
     *
     * This method may be called on the prototype (for prototypical template
     * binding, to avoid creating accessors every instance) once per prototype,
     * and will be called with `runtimeBinding: true` by `_stampTemplate` to
     * create and link an instance of the template metadata associated with a
     * particular stamping.
     *
     * @override
     * @param {!HTMLTemplateElement} template Template containing binding
     * bindings
     * @param {boolean=} instanceBinding When false (default), performs
     * "prototypical" binding of the template and overwrites any previously
     * bound template for the class. When true (as passed from
     * `_stampTemplate`), the template info is instanced and linked into the
     * list of bound templates.
     * @return {!TemplateInfo} Template metadata object; for `runtimeBinding`,
     * this is an instance of the prototypical template info
     * @protected
     * @suppress {missingProperties} go/missingfnprops
     */
    _bindTemplate(template2, instanceBinding) {
      let templateInfo = this.constructor._parseTemplate(template2);
      let wasPreBound = this.__preBoundTemplateInfo == templateInfo;
      if (!wasPreBound) {
        for (let prop in templateInfo.propertyEffects) {
          this._createPropertyAccessor(prop);
        }
      }
      if (instanceBinding) {
        templateInfo = /** @type {!TemplateInfo} */
        Object.create(templateInfo);
        templateInfo.wasPreBound = wasPreBound;
        if (!this.__templateInfo) {
          this.__templateInfo = templateInfo;
        } else {
          const parent = template2._parentTemplateInfo || this.__templateInfo;
          const previous = parent.lastChild;
          templateInfo.parent = parent;
          parent.lastChild = templateInfo;
          templateInfo.previousSibling = previous;
          if (previous) {
            previous.nextSibling = templateInfo;
          } else {
            parent.firstChild = templateInfo;
          }
        }
      } else {
        this.__preBoundTemplateInfo = templateInfo;
      }
      return templateInfo;
    }
    /**
     * Adds a property effect to the given template metadata, which is run
     * at the "propagate" stage of `_propertiesChanged` when the template
     * has been bound to the element via `_bindTemplate`.
     *
     * The `effect` object should match the format in `_addPropertyEffect`.
     *
     * @param {Object} templateInfo Template metadata to add effect to
     * @param {string} prop Property that should trigger the effect
     * @param {Object=} effect Effect metadata object
     * @return {void}
     * @protected
     * @nocollapse
     */
    static _addTemplatePropertyEffect(templateInfo, prop, effect) {
      let hostProps = templateInfo.hostProps = templateInfo.hostProps || {};
      hostProps[prop] = true;
      let effects = templateInfo.propertyEffects = templateInfo.propertyEffects || {};
      let propEffects = effects[prop] = effects[prop] || [];
      propEffects.push(effect);
    }
    /**
     * Stamps the provided template and performs instance-time setup for
     * Polymer template features, including data bindings, declarative event
     * listeners, and the `this.$` map of `id`'s to nodes.  A document fragment
     * is returned containing the stamped DOM, ready for insertion into the
     * DOM.
     *
     * This method may be called more than once; however note that due to
     * `shadycss` polyfill limitations, only styles from templates prepared
     * using `ShadyCSS.prepareTemplate` will be correctly polyfilled (scoped
     * to the shadow root and support CSS custom properties), and note that
     * `ShadyCSS.prepareTemplate` may only be called once per element. As such,
     * any styles required by in runtime-stamped templates must be included
     * in the main element template.
     *
     * @param {!HTMLTemplateElement} template Template to stamp
     * @param {TemplateInfo=} templateInfo Optional bound template info associated
     *   with the template to be stamped; if omitted the template will be
     *   automatically bound.
     * @return {!StampedTemplate} Cloned template content
     * @override
     * @protected
     */
    _stampTemplate(template2, templateInfo) {
      templateInfo = templateInfo || /** @type {!TemplateInfo} */
      this._bindTemplate(template2, true);
      hostStack.push(this);
      let dom = super._stampTemplate(template2, templateInfo);
      hostStack.pop();
      templateInfo.nodeList = dom.nodeList;
      if (!templateInfo.wasPreBound) {
        let nodes = templateInfo.childNodes = [];
        for (let n17 = dom.firstChild; n17; n17 = n17.nextSibling) {
          nodes.push(n17);
        }
      }
      dom.templateInfo = templateInfo;
      setupBindings(this, templateInfo);
      if (this.__dataClientsReady) {
        this._runEffectsForTemplate(templateInfo, this.__data, null, false);
        this._flushClients();
      }
      return dom;
    }
    /**
     * Removes and unbinds the nodes previously contained in the provided
     * DocumentFragment returned from `_stampTemplate`.
     *
     * @override
     * @param {!StampedTemplate} dom DocumentFragment previously returned
     *   from `_stampTemplate` associated with the nodes to be removed
     * @return {void}
     * @protected
     */
    _removeBoundDom(dom) {
      const templateInfo = dom.templateInfo;
      const { previousSibling, nextSibling, parent } = templateInfo;
      if (previousSibling) {
        previousSibling.nextSibling = nextSibling;
      } else if (parent) {
        parent.firstChild = nextSibling;
      }
      if (nextSibling) {
        nextSibling.previousSibling = previousSibling;
      } else if (parent) {
        parent.lastChild = previousSibling;
      }
      templateInfo.nextSibling = templateInfo.previousSibling = null;
      let nodes = templateInfo.childNodes;
      for (let i11 = 0; i11 < nodes.length; i11++) {
        let node = nodes[i11];
        wrap(wrap(node).parentNode).removeChild(node);
      }
    }
    /**
     * Overrides default `TemplateStamp` implementation to add support for
     * parsing bindings from `TextNode`'s' `textContent`.  A `bindings`
     * array is added to `nodeInfo` and populated with binding metadata
     * with information capturing the binding target, and a `parts` array
     * with one or more metadata objects capturing the source(s) of the
     * binding.
     *
     * @param {Node} node Node to parse
     * @param {TemplateInfo} templateInfo Template metadata for current template
     * @param {NodeInfo} nodeInfo Node metadata for current template node
     * @return {boolean} `true` if the visited node added node-specific
     *   metadata to `nodeInfo`
     * @protected
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static _parseTemplateNode(node, templateInfo, nodeInfo) {
      let noted = propertyEffectsBase._parseTemplateNode.call(
        this,
        node,
        templateInfo,
        nodeInfo
      );
      if (node.nodeType === Node.TEXT_NODE) {
        let parts = this._parseBindings(node.textContent, templateInfo);
        if (parts) {
          node.textContent = literalFromParts(parts) || " ";
          addBinding(this, templateInfo, nodeInfo, "text", "textContent", parts);
          noted = true;
        }
      }
      return noted;
    }
    /**
     * Overrides default `TemplateStamp` implementation to add support for
     * parsing bindings from attributes.  A `bindings`
     * array is added to `nodeInfo` and populated with binding metadata
     * with information capturing the binding target, and a `parts` array
     * with one or more metadata objects capturing the source(s) of the
     * binding.
     *
     * @param {Element} node Node to parse
     * @param {TemplateInfo} templateInfo Template metadata for current template
     * @param {NodeInfo} nodeInfo Node metadata for current template node
     * @param {string} name Attribute name
     * @param {string} value Attribute value
     * @return {boolean} `true` if the visited node added node-specific
     *   metadata to `nodeInfo`
     * @protected
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static _parseTemplateNodeAttribute(node, templateInfo, nodeInfo, name, value) {
      let parts = this._parseBindings(value, templateInfo);
      if (parts) {
        let origName = name;
        let kind = "property";
        if (capitalAttributeRegex.test(name)) {
          kind = "attribute";
        } else if (name[name.length - 1] == "$") {
          name = name.slice(0, -1);
          kind = "attribute";
        }
        let literal = literalFromParts(parts);
        if (literal && kind == "attribute") {
          if (name == "class" && node.hasAttribute("class")) {
            literal += " " + node.getAttribute(name);
          }
          node.setAttribute(name, literal);
        }
        if (kind == "attribute" && origName == "disable-upgrade$") {
          node.setAttribute(name, "");
        }
        if (node.localName === "input" && origName === "value") {
          node.setAttribute(origName, "");
        }
        node.removeAttribute(origName);
        if (kind === "property") {
          name = dashToCamelCase2(name);
        }
        addBinding(this, templateInfo, nodeInfo, kind, name, parts, literal);
        return true;
      } else {
        return propertyEffectsBase._parseTemplateNodeAttribute.call(
          this,
          node,
          templateInfo,
          nodeInfo,
          name,
          value
        );
      }
    }
    /**
     * Overrides default `TemplateStamp` implementation to add support for
     * binding the properties that a nested template depends on to the template
     * as `_host_<property>`.
     *
     * @param {Node} node Node to parse
     * @param {TemplateInfo} templateInfo Template metadata for current template
     * @param {NodeInfo} nodeInfo Node metadata for current template node
     * @return {boolean} `true` if the visited node added node-specific
     *   metadata to `nodeInfo`
     * @protected
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static _parseTemplateNestedTemplate(node, templateInfo, nodeInfo) {
      let noted = propertyEffectsBase._parseTemplateNestedTemplate.call(
        this,
        node,
        templateInfo,
        nodeInfo
      );
      const parent = node.parentNode;
      const nestedTemplateInfo = nodeInfo.templateInfo;
      const isDomIf = parent.localName === "dom-if";
      const isDomRepeat = parent.localName === "dom-repeat";
      if (removeNestedTemplates && (isDomIf || isDomRepeat)) {
        parent.removeChild(node);
        nodeInfo = nodeInfo.parentInfo;
        nodeInfo.templateInfo = nestedTemplateInfo;
        nodeInfo.noted = true;
        noted = false;
      }
      let hostProps = nestedTemplateInfo.hostProps;
      if (fastDomIf && isDomIf) {
        if (hostProps) {
          templateInfo.hostProps = Object.assign(templateInfo.hostProps || {}, hostProps);
          if (!removeNestedTemplates) {
            nodeInfo.parentInfo.noted = true;
          }
        }
      } else {
        let mode = "{";
        for (let source in hostProps) {
          let parts = [{ mode, source, dependencies: [source], hostProp: true }];
          addBinding(this, templateInfo, nodeInfo, "property", "_host_" + source, parts);
        }
      }
      return noted;
    }
    /**
     * Called to parse text in a template (either attribute values or
     * textContent) into binding metadata.
     *
     * Any overrides of this method should return an array of binding part
     * metadata  representing one or more bindings found in the provided text
     * and any "literal" text in between.  Any non-literal parts will be passed
     * to `_evaluateBinding` when any dependencies change.  The only required
     * fields of each "part" in the returned array are as follows:
     *
     * - `dependencies` - Array containing trigger metadata for each property
     *   that should trigger the binding to update
     * - `literal` - String containing text if the part represents a literal;
     *   in this case no `dependencies` are needed
     *
     * Additional metadata for use by `_evaluateBinding` may be provided in
     * each part object as needed.
     *
     * The default implementation handles the following types of bindings
     * (one or more may be intermixed with literal strings):
     * - Property binding: `[[prop]]`
     * - Path binding: `[[object.prop]]`
     * - Negated property or path bindings: `[[!prop]]` or `[[!object.prop]]`
     * - Two-way property or path bindings (supports negation):
     *   `{{prop}}`, `{{object.prop}}`, `{{!prop}}` or `{{!object.prop}}`
     * - Inline computed method (supports negation):
     *   `[[compute(a, 'literal', b)]]`, `[[!compute(a, 'literal', b)]]`
     *
     * The default implementation uses a regular expression for best
     * performance. However, the regular expression uses a white-list of
     * allowed characters in a data-binding, which causes problems for
     * data-bindings that do use characters not in this white-list.
     *
     * Instead of updating the white-list with all allowed characters,
     * there is a StrictBindingParser (see lib/mixins/strict-binding-parser)
     * that uses a state machine instead. This state machine is able to handle
     * all characters. However, it is slightly less performant, therefore we
     * extracted it into a separate optional mixin.
     *
     * @param {string} text Text to parse from attribute or textContent
     * @param {Object} templateInfo Current template metadata
     * @return {Array<!BindingPart>} Array of binding part metadata
     * @protected
     * @nocollapse
     */
    static _parseBindings(text, templateInfo) {
      let parts = [];
      let lastIndex = 0;
      let m8;
      while ((m8 = bindingRegex.exec(text)) !== null) {
        if (m8.index > lastIndex) {
          parts.push({ literal: text.slice(lastIndex, m8.index) });
        }
        let mode = m8[1][0];
        let negate = Boolean(m8[2]);
        let source = m8[3].trim();
        let customEvent = false, notifyEvent = "", colon = -1;
        if (mode == "{" && (colon = source.indexOf("::")) > 0) {
          notifyEvent = source.substring(colon + 2);
          source = source.substring(0, colon);
          customEvent = true;
        }
        let signature = parseMethod(source);
        let dependencies = [];
        if (signature) {
          let { args, methodName } = signature;
          for (let i11 = 0; i11 < args.length; i11++) {
            let arg = args[i11];
            if (!arg.literal) {
              dependencies.push(arg);
            }
          }
          let dynamicFns = templateInfo.dynamicFns;
          if (dynamicFns && dynamicFns[methodName] || signature.static) {
            dependencies.push(methodName);
            signature.dynamicFn = true;
          }
        } else {
          dependencies.push(source);
        }
        parts.push({
          source,
          mode,
          negate,
          customEvent,
          signature,
          dependencies,
          event: notifyEvent
        });
        lastIndex = bindingRegex.lastIndex;
      }
      if (lastIndex && lastIndex < text.length) {
        let literal = text.substring(lastIndex);
        if (literal) {
          parts.push({
            literal
          });
        }
      }
      if (parts.length) {
        return parts;
      } else {
        return null;
      }
    }
    /**
     * Called to evaluate a previously parsed binding part based on a set of
     * one or more changed dependencies.
     *
     * @param {!Polymer_PropertyEffects} inst Element that should be used as
     *     scope for binding dependencies
     * @param {BindingPart} part Binding part metadata
     * @param {string} path Property/path that triggered this effect
     * @param {Object} props Bag of current property changes
     * @param {Object} oldProps Bag of previous values for changed properties
     * @param {boolean} hasPaths True with `props` contains one or more paths
     * @return {*} Value the binding part evaluated to
     * @protected
     * @nocollapse
     */
    static _evaluateBinding(inst, part, path, props, oldProps, hasPaths) {
      let value;
      if (part.signature) {
        value = runMethodEffect(inst, path, props, oldProps, part.signature);
      } else if (path != part.source) {
        value = get(inst, part.source);
      } else {
        if (hasPaths && isPath(path)) {
          value = get(inst, path);
        } else {
          value = inst.__data[path];
        }
      }
      if (part.negate) {
        value = !value;
      }
      return value;
    }
  }
  return PropertyEffects2;
});
var hostStack = [];

// node_modules/@polymer/polymer/lib/utils/telemetry.js
var instanceCount = 0;
function incrementInstanceCount() {
  instanceCount++;
}
var registrations = [];
function register(prototype) {
  registrations.push(prototype);
}

// node_modules/@polymer/polymer/lib/mixins/properties-mixin.js
function normalizeProperties(props) {
  const output = {};
  for (let p14 in props) {
    const o5 = props[p14];
    output[p14] = typeof o5 === "function" ? { type: o5 } : o5;
  }
  return output;
}
var PropertiesMixin = dedupingMixin((superClass) => {
  const base = PropertiesChanged(superClass);
  function superPropertiesClass(constructor) {
    const superCtor = Object.getPrototypeOf(constructor);
    return superCtor.prototype instanceof PropertiesMixin2 ? (
      /** @type {!PropertiesMixinConstructor} */
      superCtor
    ) : null;
  }
  function ownProperties(constructor) {
    if (!constructor.hasOwnProperty(JSCompiler_renameProperty("__ownProperties", constructor))) {
      let props = null;
      if (constructor.hasOwnProperty(JSCompiler_renameProperty("properties", constructor))) {
        const properties = constructor.properties;
        if (properties) {
          props = normalizeProperties(properties);
        }
      }
      constructor.__ownProperties = props;
    }
    return constructor.__ownProperties;
  }
  class PropertiesMixin2 extends base {
    /**
     * Implements standard custom elements getter to observes the attributes
     * listed in `properties`.
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static get observedAttributes() {
      if (!this.hasOwnProperty(JSCompiler_renameProperty("__observedAttributes", this))) {
        register(this.prototype);
        const props = this._properties;
        this.__observedAttributes = props ? Object.keys(props).map((p14) => this.prototype._addPropertyToAttributeMap(p14)) : [];
      }
      return this.__observedAttributes;
    }
    /**
     * Finalizes an element definition, including ensuring any super classes
     * are also finalized. This includes ensuring property
     * accessors exist on the element prototype. This method calls
     * `_finalizeClass` to finalize each constructor in the prototype chain.
     * @return {void}
     * @nocollapse
     */
    static finalize() {
      if (!this.hasOwnProperty(JSCompiler_renameProperty("__finalized", this))) {
        const superCtor = superPropertiesClass(
          /** @type {!PropertiesMixinConstructor} */
          this
        );
        if (superCtor) {
          superCtor.finalize();
        }
        this.__finalized = true;
        this._finalizeClass();
      }
    }
    /**
     * Finalize an element class. This includes ensuring property
     * accessors exist on the element prototype. This method is called by
     * `finalize` and finalizes the class constructor.
     *
     * @protected
     * @nocollapse
     */
    static _finalizeClass() {
      const props = ownProperties(
        /** @type {!PropertiesMixinConstructor} */
        this
      );
      if (props) {
        this.createProperties(props);
      }
    }
    /**
     * Returns a memoized version of all properties, including those inherited
     * from super classes. Properties not in object format are converted to
     * at least {type}.
     *
     * @return {Object} Object containing properties for this class
     * @protected
     * @nocollapse
     */
    static get _properties() {
      if (!this.hasOwnProperty(
        JSCompiler_renameProperty("__properties", this)
      )) {
        const superCtor = superPropertiesClass(
          /** @type {!PropertiesMixinConstructor} */
          this
        );
        this.__properties = Object.assign(
          {},
          superCtor && superCtor._properties,
          ownProperties(
            /** @type {PropertiesMixinConstructor} */
            this
          )
        );
      }
      return this.__properties;
    }
    /**
     * Overrides `PropertiesChanged` method to return type specified in the
     * static `properties` object for the given property.
     * @param {string} name Name of property
     * @return {*} Type to which to deserialize attribute
     *
     * @protected
     * @nocollapse
     */
    static typeForProperty(name) {
      const info = this._properties[name];
      return info && info.type;
    }
    /**
     * Overrides `PropertiesChanged` method and adds a call to
     * `finalize` which lazily configures the element's property accessors.
     * @override
     * @return {void}
     */
    _initializeProperties() {
      incrementInstanceCount();
      this.constructor.finalize();
      super._initializeProperties();
    }
    /**
     * Called when the element is added to a document.
     * Calls `_enableProperties` to turn on property system from
     * `PropertiesChanged`.
     * @suppress {missingProperties} Super may or may not implement the callback
     * @return {void}
     * @override
     */
    connectedCallback() {
      if (super.connectedCallback) {
        super.connectedCallback();
      }
      this._enableProperties();
    }
    /**
     * Called when the element is removed from a document
     * @suppress {missingProperties} Super may or may not implement the callback
     * @return {void}
     * @override
     */
    disconnectedCallback() {
      if (super.disconnectedCallback) {
        super.disconnectedCallback();
      }
    }
  }
  return PropertiesMixin2;
});

// node_modules/@polymer/polymer/lib/mixins/element-mixin.js
var version = "3.5.2";
var builtCSS = window.ShadyCSS && window.ShadyCSS["cssBuild"];
var ElementMixin = dedupingMixin((base) => {
  const polymerElementBase = PropertiesMixin(PropertyEffects(base));
  function propertyDefaults(constructor) {
    if (!constructor.hasOwnProperty(
      JSCompiler_renameProperty("__propertyDefaults", constructor)
    )) {
      constructor.__propertyDefaults = null;
      let props = constructor._properties;
      for (let p14 in props) {
        let info = props[p14];
        if ("value" in info) {
          constructor.__propertyDefaults = constructor.__propertyDefaults || {};
          constructor.__propertyDefaults[p14] = info;
        }
      }
    }
    return constructor.__propertyDefaults;
  }
  function ownObservers(constructor) {
    if (!constructor.hasOwnProperty(
      JSCompiler_renameProperty("__ownObservers", constructor)
    )) {
      constructor.__ownObservers = constructor.hasOwnProperty(
        JSCompiler_renameProperty("observers", constructor)
      ) ? (
        /** @type {PolymerElementConstructor} */
        constructor.observers
      ) : null;
    }
    return constructor.__ownObservers;
  }
  function createPropertyFromConfig(proto2, name, info, allProps) {
    if (info.computed) {
      info.readOnly = true;
    }
    if (info.computed) {
      if (proto2._hasReadOnlyEffect(name)) {
        console.warn(`Cannot redefine computed property '${name}'.`);
      } else {
        proto2._createComputedProperty(name, info.computed, allProps);
      }
    }
    if (info.readOnly && !proto2._hasReadOnlyEffect(name)) {
      proto2._createReadOnlyProperty(name, !info.computed);
    } else if (info.readOnly === false && proto2._hasReadOnlyEffect(name)) {
      console.warn(`Cannot make readOnly property '${name}' non-readOnly.`);
    }
    if (info.reflectToAttribute && !proto2._hasReflectEffect(name)) {
      proto2._createReflectedProperty(name);
    } else if (info.reflectToAttribute === false && proto2._hasReflectEffect(name)) {
      console.warn(`Cannot make reflected property '${name}' non-reflected.`);
    }
    if (info.notify && !proto2._hasNotifyEffect(name)) {
      proto2._createNotifyingProperty(name);
    } else if (info.notify === false && proto2._hasNotifyEffect(name)) {
      console.warn(`Cannot make notify property '${name}' non-notify.`);
    }
    if (info.observer) {
      proto2._createPropertyObserver(name, info.observer, allProps[info.observer]);
    }
    proto2._addPropertyToAttributeMap(name);
  }
  function processElementStyles(klass, template2, is, baseURI) {
    if (!builtCSS) {
      const templateStyles = template2.content.querySelectorAll("style");
      const stylesWithImports = stylesFromTemplate(template2);
      const linkedStyles = stylesFromModuleImports(is);
      const firstTemplateChild = template2.content.firstElementChild;
      for (let idx = 0; idx < linkedStyles.length; idx++) {
        let s18 = linkedStyles[idx];
        s18.textContent = klass._processStyleText(s18.textContent, baseURI);
        template2.content.insertBefore(s18, firstTemplateChild);
      }
      let templateStyleIndex = 0;
      for (let i11 = 0; i11 < stylesWithImports.length; i11++) {
        let s18 = stylesWithImports[i11];
        let templateStyle = templateStyles[templateStyleIndex];
        if (templateStyle !== s18) {
          s18 = s18.cloneNode(true);
          templateStyle.parentNode.insertBefore(s18, templateStyle);
        } else {
          templateStyleIndex++;
        }
        s18.textContent = klass._processStyleText(s18.textContent, baseURI);
      }
    }
    if (window.ShadyCSS) {
      window.ShadyCSS.prepareTemplate(template2, is);
    }
    if (useAdoptedStyleSheetsWithBuiltCSS && builtCSS && supportsAdoptingStyleSheets) {
      const styles = template2.content.querySelectorAll("style");
      if (styles) {
        let css2 = "";
        Array.from(styles).forEach((s18) => {
          css2 += s18.textContent;
          s18.parentNode.removeChild(s18);
        });
        klass._styleSheet = new CSSStyleSheet();
        klass._styleSheet.replaceSync(css2);
      }
    }
  }
  function getTemplateFromDomModule(is) {
    let template2 = null;
    if (is && (!strictTemplatePolicy || allowTemplateFromDomModule)) {
      template2 = /** @type {?HTMLTemplateElement} */
      DomModule.import(is, "template");
      if (strictTemplatePolicy && !template2) {
        throw new Error(`strictTemplatePolicy: expecting dom-module or null template for ${is}`);
      }
    }
    return template2;
  }
  class PolymerElement2 extends polymerElementBase {
    /**
     * Current Polymer version in Semver notation.
     * @type {string} Semver notation of the current version of Polymer.
     * @nocollapse
     */
    static get polymerElementVersion() {
      return version;
    }
    /**
     * Override of PropertiesMixin _finalizeClass to create observers and
     * find the template.
     * @return {void}
     * @protected
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static _finalizeClass() {
      polymerElementBase._finalizeClass.call(this);
      const observers = ownObservers(this);
      if (observers) {
        this.createObservers(observers, this._properties);
      }
      this._prepareTemplate();
    }
    /** @nocollapse */
    static _prepareTemplate() {
      let template2 = (
        /** @type {PolymerElementConstructor} */
        this.template
      );
      if (template2) {
        if (typeof template2 === "string") {
          console.error("template getter must return HTMLTemplateElement");
          template2 = null;
        } else if (!legacyOptimizations) {
          template2 = template2.cloneNode(true);
        }
      }
      this.prototype._template = template2;
    }
    /**
     * Override of PropertiesChanged createProperties to create accessors
     * and property effects for all of the properties.
     * @param {!Object} props .
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createProperties(props) {
      for (let p14 in props) {
        createPropertyFromConfig(
          /** @type {?} */
          this.prototype,
          p14,
          props[p14],
          props
        );
      }
    }
    /**
     * Creates observers for the given `observers` array.
     * Leverages `PropertyEffects` to create observers.
     * @param {Object} observers Array of observer descriptors for
     *   this class
     * @param {Object} dynamicFns Object containing keys for any properties
     *   that are functions and should trigger the effect when the function
     *   reference is changed
     * @return {void}
     * @protected
     * @nocollapse
     */
    static createObservers(observers, dynamicFns) {
      const proto2 = this.prototype;
      for (let i11 = 0; i11 < observers.length; i11++) {
        proto2._createMethodObserver(observers[i11], dynamicFns);
      }
    }
    /**
     * Returns the template that will be stamped into this element's shadow root.
     *
     * If a `static get is()` getter is defined, the default implementation will
     * return the first `<template>` in a `dom-module` whose `id` matches this
     * element's `is` (note that a `_template` property on the class prototype
     * takes precedence over the `dom-module` template, to maintain legacy
     * element semantics; a subclass will subsequently fall back to its super
     * class template if neither a `prototype._template` or a `dom-module` for
     * the class's `is` was found).
     *
     * Users may override this getter to return an arbitrary template
     * (in which case the `is` getter is unnecessary). The template returned
     * must be an `HTMLTemplateElement`.
     *
     * Note that when subclassing, if the super class overrode the default
     * implementation and the subclass would like to provide an alternate
     * template via a `dom-module`, it should override this getter and
     * return `DomModule.import(this.is, 'template')`.
     *
     * If a subclass would like to modify the super class template, it should
     * clone it rather than modify it in place.  If the getter does expensive
     * work such as cloning/modifying a template, it should memoize the
     * template for maximum performance:
     *
     *   let memoizedTemplate;
     *   class MySubClass extends MySuperClass {
     *     static get template() {
     *       if (!memoizedTemplate) {
     *         memoizedTemplate = super.template.cloneNode(true);
     *         let subContent = document.createElement('div');
     *         subContent.textContent = 'This came from MySubClass';
     *         memoizedTemplate.content.appendChild(subContent);
     *       }
     *       return memoizedTemplate;
     *     }
     *   }
     *
     * @return {!HTMLTemplateElement|string} Template to be stamped
     * @nocollapse
     */
    static get template() {
      if (!this.hasOwnProperty(JSCompiler_renameProperty("_template", this))) {
        let protoTemplate = this.prototype.hasOwnProperty(
          JSCompiler_renameProperty("_template", this.prototype)
        ) ? this.prototype._template : void 0;
        if (typeof protoTemplate === "function") {
          protoTemplate = protoTemplate();
        }
        this._template = // If user has put template on prototype (e.g. in legacy via registered
        // callback or info object), prefer that first. Note that `null` is
        // used as a sentinel to indicate "no template" and can be used to
        // override a super template, whereas `undefined` is used as a
        // sentinel to mean "fall-back to default template lookup" via
        // dom-module and/or super.template.
        protoTemplate !== void 0 ? protoTemplate : (
          // Look in dom-module associated with this element's is
          this.hasOwnProperty(JSCompiler_renameProperty("is", this)) && getTemplateFromDomModule(
            /** @type {PolymerElementConstructor}*/
            this.is
          ) || // Next look for superclass template (call the super impl this
          // way so that `this` points to the superclass)
          Object.getPrototypeOf(
            /** @type {PolymerElementConstructor}*/
            this.prototype
          ).constructor.template
        );
      }
      return this._template;
    }
    /**
     * Set the template.
     *
     * @param {!HTMLTemplateElement|string} value Template to set.
     * @nocollapse
     */
    static set template(value) {
      this._template = value;
    }
    /**
     * Path matching the url from which the element was imported.
     *
     * This path is used to resolve url's in template style cssText.
     * The `importPath` property is also set on element instances and can be
     * used to create bindings relative to the import path.
     *
     * For elements defined in ES modules, users should implement
     * `static get importMeta() { return import.meta; }`, and the default
     * implementation of `importPath` will  return `import.meta.url`'s path.
     * For elements defined in HTML imports, this getter will return the path
     * to the document containing a `dom-module` element matching this
     * element's static `is` property.
     *
     * Note, this path should contain a trailing `/`.
     *
     * @return {string} The import path for this element class
     * @suppress {missingProperties}
     * @nocollapse
     */
    static get importPath() {
      if (!this.hasOwnProperty(JSCompiler_renameProperty("_importPath", this))) {
        const meta = this.importMeta;
        if (meta) {
          this._importPath = pathFromUrl(meta.url);
        } else {
          const module = DomModule.import(
            /** @type {PolymerElementConstructor} */
            this.is
          );
          this._importPath = module && module.assetpath || Object.getPrototypeOf(
            /** @type {PolymerElementConstructor}*/
            this.prototype
          ).constructor.importPath;
        }
      }
      return this._importPath;
    }
    constructor() {
      super();
      this._template;
      this._importPath;
      this.rootPath;
      this.importPath;
      this.root;
      this.$;
    }
    /**
     * Overrides the default `PropertyAccessors` to ensure class
     * metaprogramming related to property accessors and effects has
     * completed (calls `finalize`).
     *
     * It also initializes any property defaults provided via `value` in
     * `properties` metadata.
     *
     * @return {void}
     * @override
     * @suppress {invalidCasts,missingProperties} go/missingfnprops
     */
    _initializeProperties() {
      this.constructor.finalize();
      this.constructor._finalizeTemplate(
        /** @type {!HTMLElement} */
        this.localName
      );
      super._initializeProperties();
      this.rootPath = rootPath;
      this.importPath = this.constructor.importPath;
      let p$ = propertyDefaults(this.constructor);
      if (!p$) {
        return;
      }
      for (let p14 in p$) {
        let info = p$[p14];
        if (this._canApplyPropertyDefault(p14)) {
          let value = typeof info.value == "function" ? info.value.call(this) : info.value;
          if (this._hasAccessor(p14)) {
            this._setPendingProperty(p14, value, true);
          } else {
            this[p14] = value;
          }
        }
      }
    }
    /**
     * Determines if a property dfeault can be applied. For example, this
     * prevents a default from being applied when a property that has no
     * accessor is overridden by its host before upgrade (e.g. via a binding).
     * @override
     * @param {string} property Name of the property
     * @return {boolean} Returns true if the property default can be applied.
     */
    _canApplyPropertyDefault(property) {
      return !this.hasOwnProperty(property);
    }
    /**
     * Gather style text for a style element in the template.
     *
     * @param {string} cssText Text containing styling to process
     * @param {string} baseURI Base URI to rebase CSS paths against
     * @return {string} The processed CSS text
     * @protected
     * @nocollapse
     */
    static _processStyleText(cssText, baseURI) {
      return resolveCss(cssText, baseURI);
    }
    /**
    * Configures an element `proto` to function with a given `template`.
    * The element name `is` and extends `ext` must be specified for ShadyCSS
    * style scoping.
    *
    * @param {string} is Tag name (or type extension name) for this element
    * @return {void}
    * @protected
    * @nocollapse
    */
    static _finalizeTemplate(is) {
      const template2 = this.prototype._template;
      if (template2 && !template2.__polymerFinalized) {
        template2.__polymerFinalized = true;
        const importPath = this.importPath;
        const baseURI = importPath ? resolveUrl(importPath) : "";
        processElementStyles(this, template2, is, baseURI);
        this.prototype._bindTemplate(template2);
      }
    }
    /**
     * Provides a default implementation of the standard Custom Elements
     * `connectedCallback`.
     *
     * The default implementation enables the property effects system and
     * flushes any pending properties, and updates shimmed CSS properties
     * when using the ShadyCSS scoping/custom properties polyfill.
     *
     * @override
     * @suppress {missingProperties, invalidCasts} Super may or may not
     *     implement the callback
     * @return {void}
     */
    connectedCallback() {
      if (window.ShadyCSS && this._template) {
        window.ShadyCSS.styleElement(
          /** @type {!HTMLElement} */
          this
        );
      }
      super.connectedCallback();
    }
    /**
     * Stamps the element template.
     *
     * @return {void}
     * @override
     */
    ready() {
      if (this._template) {
        this.root = this._stampTemplate(this._template);
        this.$ = this.root.$;
      }
      super.ready();
    }
    /**
     * Implements `PropertyEffects`'s `_readyClients` call. Attaches
     * element dom by calling `_attachDom` with the dom stamped from the
     * element's template via `_stampTemplate`. Note that this allows
     * client dom to be attached to the element prior to any observers
     * running.
     *
     * @return {void}
     * @override
     */
    _readyClients() {
      if (this._template) {
        this.root = this._attachDom(
          /** @type {StampedTemplate} */
          this.root
        );
      }
      super._readyClients();
    }
    /**
     * Attaches an element's stamped dom to itself. By default,
     * this method creates a `shadowRoot` and adds the dom to it.
     * However, this method may be overridden to allow an element
     * to put its dom in another location.
     *
     * @override
     * @throws {Error}
     * @suppress {missingReturn}
     * @param {StampedTemplate} dom to attach to the element.
     * @return {ShadowRoot} node to which the dom has been attached.
     */
    _attachDom(dom) {
      const n17 = wrap(this);
      if (n17.attachShadow) {
        if (dom) {
          if (!n17.shadowRoot) {
            n17.attachShadow({ mode: "open", shadyUpgradeFragment: dom });
            n17.shadowRoot.appendChild(dom);
            if (this.constructor._styleSheet) {
              n17.shadowRoot.adoptedStyleSheets = [this.constructor._styleSheet];
            }
          }
          if (syncInitialRender && window.ShadyDOM) {
            window.ShadyDOM.flushInitial(n17.shadowRoot);
          }
          return n17.shadowRoot;
        }
        return null;
      } else {
        throw new Error("ShadowDOM not available. PolymerElement can create dom as children instead of in ShadowDOM by setting `this.root = this;` before `ready`.");
      }
    }
    /**
     * When using the ShadyCSS scoping and custom property shim, causes all
     * shimmed styles in this element (and its subtree) to be updated
     * based on current custom property values.
     *
     * The optional parameter overrides inline custom property styles with an
     * object of properties where the keys are CSS properties, and the values
     * are strings.
     *
     * Example: `this.updateStyles({'--color': 'blue'})`
     *
     * These properties are retained unless a value of `null` is set.
     *
     * Note: This function does not support updating CSS mixins.
     * You can not dynamically change the value of an `@apply`.
     *
     * @override
     * @param {Object=} properties Bag of custom property key/values to
     *   apply to this element.
     * @return {void}
     * @suppress {invalidCasts}
     */
    updateStyles(properties) {
      if (window.ShadyCSS) {
        window.ShadyCSS.styleSubtree(
          /** @type {!HTMLElement} */
          this,
          properties
        );
      }
    }
    /**
     * Rewrites a given URL relative to a base URL. The base URL defaults to
     * the original location of the document containing the `dom-module` for
     * this element. This method will return the same URL before and after
     * bundling.
     *
     * Note that this function performs no resolution for URLs that start
     * with `/` (absolute URLs) or `#` (hash identifiers).  For general purpose
     * URL resolution, use `window.URL`.
     *
     * @override
     * @param {string} url URL to resolve.
     * @param {string=} base Optional base URL to resolve against, defaults
     * to the element's `importPath`
     * @return {string} Rewritten URL relative to base
     */
    resolveUrl(url, base2) {
      if (!base2 && this.importPath) {
        base2 = resolveUrl(this.importPath);
      }
      return resolveUrl(url, base2);
    }
    /**
     * Overrides `PropertyEffects` to add map of dynamic functions on
     * template info, for consumption by `PropertyEffects` template binding
     * code. This map determines which method templates should have accessors
     * created for them.
     *
     * @param {!HTMLTemplateElement} template Template
     * @param {!TemplateInfo} templateInfo Template metadata for current template
     * @param {!NodeInfo} nodeInfo Node metadata for current template.
     * @return {boolean} .
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static _parseTemplateContent(template2, templateInfo, nodeInfo) {
      templateInfo.dynamicFns = templateInfo.dynamicFns || this._properties;
      return polymerElementBase._parseTemplateContent.call(
        this,
        template2,
        templateInfo,
        nodeInfo
      );
    }
    /**
     * Overrides `PropertyEffects` to warn on use of undeclared properties in
     * template.
     *
     * @param {Object} templateInfo Template metadata to add effect to
     * @param {string} prop Property that should trigger the effect
     * @param {Object=} effect Effect metadata object
     * @return {void}
     * @protected
     * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
     * @nocollapse
     */
    static _addTemplatePropertyEffect(templateInfo, prop, effect) {
      if (legacyWarnings && !(prop in this._properties) && // Methods used in templates with no dependencies (or only literal
      // dependencies) become accessors with template effects; ignore these
      !(effect.info.part.signature && effect.info.part.signature.static) && // Warnings for bindings added to nested templates are handled by
      // templatizer so ignore both the host-to-template bindings
      // (`hostProp`) and TemplateInstance-to-child bindings
      // (`nestedTemplate`)
      !effect.info.part.hostProp && !templateInfo.nestedTemplate) {
        console.warn(`Property '${prop}' used in template but not declared in 'properties'; attribute will not be observed.`);
      }
      return polymerElementBase._addTemplatePropertyEffect.call(
        this,
        templateInfo,
        prop,
        effect
      );
    }
  }
  return PolymerElement2;
});

// node_modules/@polymer/polymer/lib/utils/html-tag.js
var policy = window.trustedTypes && trustedTypes.createPolicy("polymer-html-literal", { createHTML: (s18) => s18 });
var LiteralString = class {
  /**
   * @param {!ITemplateArray} strings Constant parts of tagged template literal
   * @param {!Array<*>} values Variable parts of tagged template literal
   */
  constructor(strings, values) {
    assertValidTemplateStringParameters(strings, values);
    const string = values.reduce(
      (acc, v3, idx) => acc + literalValue(v3) + strings[idx + 1],
      strings[0]
    );
    this.value = string.toString();
  }
  /**
   * @return {string} LiteralString string value
   * @override
   */
  toString() {
    return this.value;
  }
};
function literalValue(value) {
  if (value instanceof LiteralString) {
    return (
      /** @type {!LiteralString} */
      value.value
    );
  } else {
    throw new Error(
      `non-literal value passed to Polymer's htmlLiteral function: ${value}`
    );
  }
}
function htmlValue(value) {
  if (value instanceof HTMLTemplateElement) {
    return (
      /** @type {!HTMLTemplateElement } */
      value.innerHTML
    );
  } else if (value instanceof LiteralString) {
    return literalValue(value);
  } else {
    throw new Error(
      `non-template value passed to Polymer's html function: ${value}`
    );
  }
}
var html = function html2(strings, ...values) {
  assertValidTemplateStringParameters(strings, values);
  const template2 = (
    /** @type {!HTMLTemplateElement} */
    document.createElement("template")
  );
  let value = values.reduce(
    (acc, v3, idx) => acc + htmlValue(v3) + strings[idx + 1],
    strings[0]
  );
  if (policy) {
    value = policy.createHTML(value);
  }
  template2.innerHTML = value;
  return template2;
};
var assertValidTemplateStringParameters = (strings, values) => {
  if (!Array.isArray(strings) || !Array.isArray(strings.raw) || values.length !== strings.length - 1) {
    throw new TypeError("Invalid call to the html template tag");
  }
};

// node_modules/@polymer/polymer/polymer-element.js
var PolymerElement = ElementMixin(HTMLElement);

// node_modules/@vaadin/component-base/src/async.js
var microtaskCurrHandle2 = 0;
var microtaskLastHandle2 = 0;
var microtaskCallbacks2 = [];
var microtaskScheduled2 = false;
function microtaskFlush2() {
  microtaskScheduled2 = false;
  const len = microtaskCallbacks2.length;
  for (let i11 = 0; i11 < len; i11++) {
    const cb = microtaskCallbacks2[i11];
    if (cb) {
      try {
        cb();
      } catch (e13) {
        setTimeout(() => {
          throw e13;
        });
      }
    }
  }
  microtaskCallbacks2.splice(0, len);
  microtaskLastHandle2 += len;
}
var timeOut = {
  /**
   * Returns a sub-module with the async interface providing the provided
   * delay.
   *
   * @memberof timeOut
   * @param {number=} delay Time to wait before calling callbacks in ms
   * @return {!AsyncInterface} An async timeout interface
   */
  after(delay) {
    return {
      run(fn) {
        return window.setTimeout(fn, delay);
      },
      cancel(handle) {
        window.clearTimeout(handle);
      }
    };
  },
  /**
   * Enqueues a function called in the next task.
   *
   * @memberof timeOut
   * @param {!Function} fn Callback to run
   * @param {number=} delay Delay in milliseconds
   * @return {number} Handle used for canceling task
   */
  run(fn, delay) {
    return window.setTimeout(fn, delay);
  },
  /**
   * Cancels a previously enqueued `timeOut` callback.
   *
   * @memberof timeOut
   * @param {number} handle Handle returned from `run` of callback to cancel
   * @return {void}
   */
  cancel(handle) {
    window.clearTimeout(handle);
  }
};
var animationFrame = {
  /**
   * Enqueues a function called at `requestAnimationFrame` timing.
   *
   * @memberof animationFrame
   * @param {function(number):void} fn Callback to run
   * @return {number} Handle used for canceling task
   */
  run(fn) {
    return window.requestAnimationFrame(fn);
  },
  /**
   * Cancels a previously enqueued `animationFrame` callback.
   *
   * @memberof animationFrame
   * @param {number} handle Handle returned from `run` of callback to cancel
   * @return {void}
   */
  cancel(handle) {
    window.cancelAnimationFrame(handle);
  }
};
var idlePeriod = {
  /**
   * Enqueues a function called at `requestIdleCallback` timing.
   *
   * @memberof idlePeriod
   * @param {function(!IdleDeadline):void} fn Callback to run
   * @return {number} Handle used for canceling task
   */
  run(fn) {
    return window.requestIdleCallback ? window.requestIdleCallback(fn) : window.setTimeout(fn, 16);
  },
  /**
   * Cancels a previously enqueued `idlePeriod` callback.
   *
   * @memberof idlePeriod
   * @param {number} handle Handle returned from `run` of callback to cancel
   * @return {void}
   */
  cancel(handle) {
    if (window.cancelIdleCallback) {
      window.cancelIdleCallback(handle);
    } else {
      window.clearTimeout(handle);
    }
  }
};
var microTask2 = {
  /**
   * Enqueues a function called at microtask timing.
   *
   * @memberof microTask
   * @param {!Function=} callback Callback to run
   * @return {number} Handle used for canceling task
   */
  run(callback) {
    if (!microtaskScheduled2) {
      microtaskScheduled2 = true;
      queueMicrotask(() => microtaskFlush2());
    }
    microtaskCallbacks2.push(callback);
    const result = microtaskCurrHandle2;
    microtaskCurrHandle2 += 1;
    return result;
  },
  /**
   * Cancels a previously enqueued `microTask` callback.
   *
   * @memberof microTask
   * @param {number} handle Handle returned from `run` of callback to cancel
   * @return {void}
   */
  cancel(handle) {
    const idx = handle - microtaskLastHandle2;
    if (idx >= 0) {
      if (!microtaskCallbacks2[idx]) {
        throw new Error(`invalid async handle: ${handle}`);
      }
      microtaskCallbacks2[idx] = null;
    }
  }
};

// node_modules/@vaadin/component-base/src/debounce.js
var debouncerQueue = /* @__PURE__ */ new Set();
var Debouncer = class _Debouncer {
  /**
   * Creates a debouncer if no debouncer is passed as a parameter
   * or it cancels an active debouncer otherwise. The following
   * example shows how a debouncer can be called multiple times within a
   * microtask and "debounced" such that the provided callback function is
   * called once. Add this method to a custom element:
   *
   * ```js
   * import {microTask} from '@vaadin/component-base/src/async.js';
   * import {Debouncer} from '@vaadin/component-base/src/debounce.js';
   * // ...
   *
   * _debounceWork() {
   *   this._debounceJob = Debouncer.debounce(this._debounceJob,
   *       microTask, () => this._doWork());
   * }
   * ```
   *
   * If the `_debounceWork` method is called multiple times within the same
   * microtask, the `_doWork` function will be called only once at the next
   * microtask checkpoint.
   *
   * Note: In testing it is often convenient to avoid asynchrony. To accomplish
   * this with a debouncer, you can use `enqueueDebouncer` and
   * `flush`. For example, extend the above example by adding
   * `enqueueDebouncer(this._debounceJob)` at the end of the
   * `_debounceWork` method. Then in a test, call `flush` to ensure
   * the debouncer has completed.
   *
   * @param {Debouncer?} debouncer Debouncer object.
   * @param {!AsyncInterface} asyncModule Object with Async interface
   * @param {function()} callback Callback to run.
   * @return {!Debouncer} Returns a debouncer object.
   */
  static debounce(debouncer, asyncModule, callback) {
    if (debouncer instanceof _Debouncer) {
      debouncer._cancelAsync();
    } else {
      debouncer = new _Debouncer();
    }
    debouncer.setConfig(asyncModule, callback);
    return debouncer;
  }
  constructor() {
    this._asyncModule = null;
    this._callback = null;
    this._timer = null;
  }
  /**
   * Sets the scheduler; that is, a module with the Async interface,
   * a callback and optional arguments to be passed to the run function
   * from the async module.
   *
   * @param {!AsyncInterface} asyncModule Object with Async interface.
   * @param {function()} callback Callback to run.
   * @return {void}
   */
  setConfig(asyncModule, callback) {
    this._asyncModule = asyncModule;
    this._callback = callback;
    this._timer = this._asyncModule.run(() => {
      this._timer = null;
      debouncerQueue.delete(this);
      this._callback();
    });
  }
  /**
   * Cancels an active debouncer and returns a reference to itself.
   *
   * @return {void}
   */
  cancel() {
    if (this.isActive()) {
      this._cancelAsync();
      debouncerQueue.delete(this);
    }
  }
  /**
   * Cancels a debouncer's async callback.
   *
   * @return {void}
   */
  _cancelAsync() {
    if (this.isActive()) {
      this._asyncModule.cancel(
        /** @type {number} */
        this._timer
      );
      this._timer = null;
    }
  }
  /**
   * Flushes an active debouncer and returns a reference to itself.
   *
   * @return {void}
   */
  flush() {
    if (this.isActive()) {
      this.cancel();
      this._callback();
    }
  }
  /**
   * Returns true if the debouncer is active.
   *
   * @return {boolean} True if active.
   */
  isActive() {
    return this._timer != null;
  }
};
function enqueueDebouncer(debouncer) {
  debouncerQueue.add(debouncer);
}
function flushDebouncers() {
  const didFlush = Boolean(debouncerQueue.size);
  debouncerQueue.forEach((debouncer) => {
    try {
      debouncer.flush();
    } catch (e13) {
      setTimeout(() => {
        throw e13;
      });
    }
  });
  return didFlush;
}
var flush = () => {
  let debouncers;
  do {
    debouncers = flushDebouncers();
  } while (debouncers);
};

// node_modules/@vaadin/component-base/src/dir-mixin.js
var directionSubscribers = [];
function alignDirs(element, documentDir, elementDir = element.getAttribute("dir")) {
  if (documentDir) {
    element.setAttribute("dir", documentDir);
  } else if (elementDir != null) {
    element.removeAttribute("dir");
  }
}
function getDocumentDir() {
  return document.documentElement.getAttribute("dir");
}
function directionUpdater() {
  const documentDir = getDocumentDir();
  directionSubscribers.forEach((element) => {
    alignDirs(element, documentDir);
  });
}
var directionObserver = new MutationObserver(directionUpdater);
directionObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["dir"] });
var DirMixin = (superClass) => class VaadinDirMixin extends superClass {
  static get properties() {
    return {
      /**
       * @protected
       */
      dir: {
        type: String,
        value: "",
        reflectToAttribute: true,
        converter: {
          fromAttribute: (attr) => {
            return !attr ? "" : attr;
          },
          toAttribute: (prop) => {
            return prop === "" ? null : prop;
          }
        }
      }
    };
  }
  /**
   * @return {boolean}
   * @protected
   */
  get __isRTL() {
    return this.getAttribute("dir") === "rtl";
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    if (!this.hasAttribute("dir") || this.__restoreSubscription) {
      this.__subscribe();
      alignDirs(this, getDocumentDir(), null);
    }
  }
  /** @protected */
  attributeChangedCallback(name, oldValue, newValue) {
    super.attributeChangedCallback(name, oldValue, newValue);
    if (name !== "dir") {
      return;
    }
    const documentDir = getDocumentDir();
    const newValueEqlDocDir = newValue === documentDir && directionSubscribers.indexOf(this) === -1;
    const newValueEmptied = !newValue && oldValue && directionSubscribers.indexOf(this) === -1;
    const newDiffValue = newValue !== documentDir && oldValue === documentDir;
    if (newValueEqlDocDir || newValueEmptied) {
      this.__subscribe();
      alignDirs(this, documentDir, newValue);
    } else if (newDiffValue) {
      this.__unsubscribe();
    }
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    this.__restoreSubscription = directionSubscribers.includes(this);
    this.__unsubscribe();
  }
  /** @protected */
  _valueToNodeAttribute(node, value, attribute) {
    if (attribute === "dir" && value === "" && !node.hasAttribute("dir")) {
      return;
    }
    super._valueToNodeAttribute(node, value, attribute);
  }
  /** @protected */
  _attributeToProperty(attribute, value, type) {
    if (attribute === "dir" && !value) {
      this.dir = "";
    } else {
      super._attributeToProperty(attribute, value, type);
    }
  }
  /** @private */
  __subscribe() {
    if (!directionSubscribers.includes(this)) {
      directionSubscribers.push(this);
    }
  }
  /** @private */
  __unsubscribe() {
    if (directionSubscribers.includes(this)) {
      directionSubscribers.splice(directionSubscribers.indexOf(this), 1);
    }
  }
};

// node_modules/@vaadin/component-base/src/path-utils.js
function get2(path, object) {
  return path.split(".").reduce((obj, property) => obj ? obj[property] : void 0, object);
}

// node_modules/@vaadin/component-base/src/templates.js
function processTemplates(component) {
  if (window.Vaadin && window.Vaadin.templateRendererCallback) {
    window.Vaadin.templateRendererCallback(component);
    return;
  }
  if (component.querySelector("template")) {
    console.warn(
      `WARNING: <template> inside <${component.localName}> is no longer supported. Import @vaadin/polymer-legacy-adapter/template-renderer.js to enable compatibility.`
    );
  }
}

// node_modules/@vaadin/component-base/src/dom-utils.js
function getClosestElement(selector, node) {
  if (!node) {
    return null;
  }
  return node.closest(selector) || getClosestElement(selector, node.getRootNode().host);
}
function deserializeAttributeValue(value) {
  if (!value) {
    return /* @__PURE__ */ new Set();
  }
  return new Set(value.split(" "));
}
function serializeAttributeValue(values) {
  return values ? [...values].join(" ") : "";
}
function addValueToAttribute(element, attr, value) {
  const values = deserializeAttributeValue(element.getAttribute(attr));
  values.add(value);
  element.setAttribute(attr, serializeAttributeValue(values));
}
function removeValueFromAttribute(element, attr, value) {
  const values = deserializeAttributeValue(element.getAttribute(attr));
  values.delete(value);
  if (values.size === 0) {
    element.removeAttribute(attr);
    return;
  }
  element.setAttribute(attr, serializeAttributeValue(values));
}
function isEmptyTextNode(node) {
  return node.nodeType === Node.TEXT_NODE && node.textContent.trim() === "";
}

// node_modules/@vaadin/grid/src/vaadin-grid-helpers.js
function getBodyRowCells(row) {
  return row.__cells || Array.from(row.querySelectorAll('[part~="cell"]:not([part~="details-cell"])'));
}
function iterateChildren(container, callback) {
  [...container.children].forEach(callback);
}
function iterateRowCells(row, callback) {
  getBodyRowCells(row).forEach(callback);
  if (row.__detailsCell) {
    callback(row.__detailsCell);
  }
}
function updateColumnOrders(columns, scope, baseOrder) {
  let c13 = 1;
  columns.forEach((column) => {
    if (c13 % 10 === 0) {
      c13 += 1;
    }
    column._order = baseOrder + c13 * scope;
    c13 += 1;
  });
}
function updateState(element, attribute, value) {
  switch (typeof value) {
    case "boolean":
      element.toggleAttribute(attribute, value);
      break;
    case "string":
      element.setAttribute(attribute, value);
      break;
    default:
      element.removeAttribute(attribute);
      break;
  }
}
function updatePart(element, value, part) {
  if (value || value === "") {
    addValueToAttribute(element, "part", part);
  } else {
    removeValueFromAttribute(element, "part", part);
  }
}
function updateCellsPart(cells, part, value) {
  cells.forEach((cell) => {
    updatePart(cell, value, part);
  });
}
function updateBooleanRowStates(row, states) {
  const cells = getBodyRowCells(row);
  Object.entries(states).forEach(([state, value]) => {
    updateState(row, state, value);
    const rowPart = `${state}-row`;
    updatePart(row, value, rowPart);
    updateCellsPart(cells, `${rowPart}-cell`, value);
  });
}
function updateStringRowStates(row, states) {
  const cells = getBodyRowCells(row);
  Object.entries(states).forEach(([state, value]) => {
    const prevValue = row.getAttribute(state);
    updateState(row, state, value);
    if (prevValue) {
      const prevRowPart = `${state}-${prevValue}-row`;
      updatePart(row, false, prevRowPart);
      updateCellsPart(cells, `${prevRowPart}-cell`, false);
    }
    if (value) {
      const rowPart = `${state}-${value}-row`;
      updatePart(row, value, rowPart);
      updateCellsPart(cells, `${rowPart}-cell`, value);
    }
  });
}
function updateCellState(cell, attribute, value, part, oldPart) {
  updateState(cell, attribute, value);
  if (oldPart) {
    updatePart(cell, false, oldPart);
  }
  updatePart(cell, value, part || `${attribute}-cell`);
}
var ColumnObserver = class _ColumnObserver {
  constructor(host, callback) {
    this.__host = host;
    this.__callback = callback;
    this.__currentSlots = [];
    this.__onMutation = this.__onMutation.bind(this);
    this.__observer = new MutationObserver(this.__onMutation);
    this.__observer.observe(host, {
      childList: true
    });
    this.__initialCallDebouncer = Debouncer.debounce(this.__initialCallDebouncer, microTask2, () => this.__onMutation());
  }
  disconnect() {
    this.__observer.disconnect();
    this.__initialCallDebouncer.cancel();
    this.__toggleSlotChangeListeners(false);
  }
  flush() {
    this.__onMutation();
  }
  __toggleSlotChangeListeners(add) {
    this.__currentSlots.forEach((slot) => {
      if (add) {
        slot.addEventListener("slotchange", this.__onMutation);
      } else {
        slot.removeEventListener("slotchange", this.__onMutation);
      }
    });
  }
  __onMutation() {
    const initialCall = !this.__currentColumns;
    this.__currentColumns ||= [];
    const columns = _ColumnObserver.getColumns(this.__host);
    const addedColumns = columns.filter((column) => !this.__currentColumns.includes(column));
    const removedColumns = this.__currentColumns.filter((column) => !columns.includes(column));
    const orderChanged = this.__currentColumns.some((column, index) => column !== columns[index]);
    this.__currentColumns = columns;
    this.__toggleSlotChangeListeners(false);
    this.__currentSlots = [...this.__host.children].filter((child) => child instanceof HTMLSlotElement);
    this.__toggleSlotChangeListeners(true);
    const invokeCallback = initialCall || addedColumns.length || removedColumns.length || orderChanged;
    if (invokeCallback) {
      this.__callback(addedColumns, removedColumns);
    }
  }
  /**
   * Default filter for column elements.
   */
  static __isColumnElement(node) {
    return node.nodeType === Node.ELEMENT_NODE && /\bcolumn\b/u.test(node.localName);
  }
  static getColumns(host) {
    const columns = [];
    const isColumnElement = host._isColumnElement || _ColumnObserver.__isColumnElement;
    [...host.children].forEach((child) => {
      if (isColumnElement(child)) {
        columns.push(child);
      } else if (child instanceof HTMLSlotElement) {
        [...child.assignedElements({ flatten: true })].filter((assignedElement) => isColumnElement(assignedElement)).forEach((assignedElement) => columns.push(assignedElement));
      }
    });
    return columns;
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-column-mixin.js
var ColumnBaseMixin = (superClass) => class ColumnBaseMixin extends superClass {
  static get properties() {
    return {
      /**
       * When set to true, the column is user-resizable.
       * @default false
       */
      resizable: {
        type: Boolean,
        sync: true,
        value() {
          if (this.localName === "vaadin-grid-column-group") {
            return;
          }
          const parent = this.parentNode;
          if (parent && parent.localName === "vaadin-grid-column-group") {
            return parent.resizable || false;
          }
          return false;
        }
      },
      /**
       * When true, the column is frozen. When a column inside of a column group is frozen,
       * all of the sibling columns inside the group will get frozen also.
       * @type {boolean}
       */
      frozen: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * When true, the column is frozen to end of grid.
       *
       * When a column inside of a column group is frozen to end, all of the sibling columns
       * inside the group will get frozen to end also.
       *
       * Column can not be set as `frozen` and `frozenToEnd` at the same time.
       * @attr {boolean} frozen-to-end
       * @type {boolean}
       */
      frozenToEnd: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * When true, the cells for this column will be rendered with the `role` attribute
       * set as `rowheader`, instead of the `gridcell` role value used by default.
       *
       * When a column is set as row header, its cells will be announced by screen readers
       * while navigating to help user identify the current row as uniquely as possible.
       *
       * @attr {boolean} row-header
       * @type {boolean}
       */
      rowHeader: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * When set to true, the cells for this column are hidden.
       */
      hidden: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * Text content to display in the header cell of the column.
       */
      header: {
        type: String,
        sync: true
      },
      /**
       * Aligns the columns cell content horizontally.
       * Supported values: "start", "center" and "end".
       * @attr {start|center|end} text-align
       * @type {GridColumnTextAlign | null | undefined}
       */
      textAlign: {
        type: String,
        sync: true
      },
      /**
       * Custom part name for the header cell.
       *
       * @attr {string} header-part-name
       */
      headerPartName: {
        type: String,
        sync: true
      },
      /**
       * Custom part name for the footer cell.
       *
       * @attr {string} footer-part-name
       */
      footerPartName: {
        type: String,
        sync: true
      },
      /**
       * @type {boolean}
       * @protected
       */
      _lastFrozen: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * @type {boolean}
       * @protected
       */
      _bodyContentHidden: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * @type {boolean}
       * @protected
       */
      _firstFrozenToEnd: {
        type: Boolean,
        value: false,
        sync: true
      },
      /** @protected */
      _order: {
        type: Number,
        sync: true
      },
      /** @private */
      _reorderStatus: {
        type: Boolean,
        sync: true
      },
      /**
       * @type {Array<!HTMLElement>}
       * @protected
       */
      _emptyCells: Array,
      /** @private */
      _headerCell: Object,
      /** @private */
      _footerCell: Object,
      /** @protected */
      _grid: Object,
      /**
       * By default, the Polymer doesn't invoke the observer
       * during initialization if all of its dependencies are `undefined`.
       * This internal property can be used to force initial invocation of an observer
       * even the other dependencies of the observer are `undefined`.
       *
       * @private
       */
      __initialized: {
        type: Boolean,
        value: true
      },
      /**
       * Custom function for rendering the header content.
       * Receives two arguments:
       *
       * - `root` The header cell content DOM element. Append your content to it.
       * - `column` The `<vaadin-grid-column>` element.
       *
       * @type {GridHeaderFooterRenderer | null | undefined}
       */
      headerRenderer: {
        type: Function,
        sync: true
      },
      /**
       * Represents the final header renderer computed on the set of observable arguments.
       * It is supposed to be used internally when rendering the header cell content.
       *
       * @protected
       * @type {GridHeaderFooterRenderer | undefined}
       */
      _headerRenderer: {
        type: Function,
        computed: "_computeHeaderRenderer(headerRenderer, header, __initialized)",
        sync: true
      },
      /**
       * Custom function for rendering the footer content.
       * Receives two arguments:
       *
       * - `root` The footer cell content DOM element. Append your content to it.
       * - `column` The `<vaadin-grid-column>` element.
       *
       * @type {GridHeaderFooterRenderer | null | undefined}
       */
      footerRenderer: {
        type: Function,
        sync: true
      },
      /**
       * Represents the final footer renderer computed on the set of observable arguments.
       * It is supposed to be used internally when rendering the footer cell content.
       *
       * @protected
       * @type {GridHeaderFooterRenderer | undefined}
       */
      _footerRenderer: {
        type: Function,
        computed: "_computeFooterRenderer(footerRenderer, __initialized)",
        sync: true
      },
      /**
       * An internal property that is mainly used by `vaadin-template-renderer`
       * to identify grid column elements.
       *
       * @private
       */
      __gridColumnElement: {
        type: Boolean,
        value: true
      }
    };
  }
  static get observers() {
    return [
      "_widthChanged(width, _headerCell, _footerCell, _cells)",
      "_frozenChanged(frozen, _headerCell, _footerCell, _cells)",
      "_frozenToEndChanged(frozenToEnd, _headerCell, _footerCell, _cells)",
      "_flexGrowChanged(flexGrow, _headerCell, _footerCell, _cells)",
      "_textAlignChanged(textAlign, _cells, _headerCell, _footerCell)",
      "_orderChanged(_order, _headerCell, _footerCell, _cells)",
      "_lastFrozenChanged(_lastFrozen)",
      "_firstFrozenToEndChanged(_firstFrozenToEnd)",
      "_onRendererOrBindingChanged(_renderer, _cells, _bodyContentHidden, path)",
      "_onHeaderRendererOrBindingChanged(_headerRenderer, _headerCell, path, header)",
      "_onFooterRendererOrBindingChanged(_footerRenderer, _footerCell)",
      "_resizableChanged(resizable, _headerCell)",
      "_reorderStatusChanged(_reorderStatus, _headerCell, _footerCell, _cells)",
      "_hiddenChanged(hidden, _headerCell, _footerCell, _cells)",
      "_rowHeaderChanged(rowHeader, _cells)",
      "__headerFooterPartNameChanged(_headerCell, _footerCell, headerPartName, footerPartName)"
    ];
  }
  /**
   * @return {!Grid | undefined}
   * @protected
   */
  get _grid() {
    if (!this._gridValue) {
      this._gridValue = this._findHostGrid();
    }
    return this._gridValue;
  }
  /**
   * @return {!Array<!HTMLElement>}
   * @protected
   */
  get _allCells() {
    return [].concat(this._cells || []).concat(this._emptyCells || []).concat(this._headerCell).concat(this._footerCell).filter((cell) => cell);
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    requestAnimationFrame(() => {
      if (!this._grid) {
        return;
      }
      this._allCells.forEach((cell) => {
        if (!cell._content.parentNode) {
          this._grid.appendChild(cell._content);
        }
      });
    });
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    requestAnimationFrame(() => {
      if (this._grid) {
        return;
      }
      this._allCells.forEach((cell) => {
        if (cell._content.parentNode) {
          cell._content.parentNode.removeChild(cell._content);
        }
      });
    });
    this._gridValue = void 0;
  }
  /** @protected */
  ready() {
    super.ready();
    processTemplates(this);
  }
  /**
   * @return {!Grid | undefined}
   * @protected
   */
  _findHostGrid() {
    let el = this;
    while (el && !/^vaadin.*grid(-pro)?$/u.test(el.localName)) {
      el = el.assignedSlot ? el.assignedSlot.parentNode : el.parentNode;
    }
    return el || void 0;
  }
  /** @protected */
  _renderHeaderAndFooter() {
    this._renderHeaderCellContent(this._headerRenderer, this._headerCell);
    this._renderFooterCellContent(this._footerRenderer, this._footerCell);
  }
  /** @private */
  _flexGrowChanged(flexGrow) {
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._columnPropChanged("flexGrow");
    }
    this._allCells.forEach((cell) => {
      cell.style.flexGrow = flexGrow;
    });
  }
  /** @private */
  _orderChanged(order) {
    this._allCells.forEach((cell) => {
      cell.style.order = order;
    });
  }
  /** @private */
  _widthChanged(width) {
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._columnPropChanged("width");
    }
    this._allCells.forEach((cell) => {
      cell.style.width = width;
    });
  }
  /** @private */
  _frozenChanged(frozen) {
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._columnPropChanged("frozen", frozen);
    }
    this._allCells.forEach((cell) => {
      updateCellState(cell, "frozen", frozen);
    });
    if (this._grid && this._grid._frozenCellsChanged) {
      this._grid._frozenCellsChanged();
    }
  }
  /** @private */
  _frozenToEndChanged(frozenToEnd) {
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._columnPropChanged("frozenToEnd", frozenToEnd);
    }
    this._allCells.forEach((cell) => {
      if (this._grid && cell.parentElement === this._grid.$.sizer) {
        return;
      }
      updateCellState(cell, "frozen-to-end", frozenToEnd);
    });
    if (this._grid && this._grid._frozenCellsChanged) {
      this._grid._frozenCellsChanged();
    }
  }
  /** @private */
  _lastFrozenChanged(lastFrozen) {
    this._allCells.forEach((cell) => {
      updateCellState(cell, "last-frozen", lastFrozen);
    });
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._lastFrozen = lastFrozen;
    }
  }
  /** @private */
  _firstFrozenToEndChanged(firstFrozenToEnd) {
    this._allCells.forEach((cell) => {
      if (this._grid && cell.parentElement === this._grid.$.sizer) {
        return;
      }
      updateCellState(cell, "first-frozen-to-end", firstFrozenToEnd);
    });
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._firstFrozenToEnd = firstFrozenToEnd;
    }
  }
  /** @private */
  _rowHeaderChanged(rowHeader, cells) {
    if (!cells) {
      return;
    }
    cells.forEach((cell) => {
      cell.setAttribute("role", rowHeader ? "rowheader" : "gridcell");
    });
  }
  /**
   * @param {string} path
   * @return {string}
   * @protected
   */
  _generateHeader(path) {
    return path.substr(path.lastIndexOf(".") + 1).replace(/([A-Z])/gu, "-$1").toLowerCase().replace(/-/gu, " ").replace(/^./u, (match) => match.toUpperCase());
  }
  /** @private */
  _reorderStatusChanged(reorderStatus) {
    const prevStatus = this.__previousReorderStatus;
    const oldPart = prevStatus ? `reorder-${prevStatus}-cell` : "";
    const newPart = `reorder-${reorderStatus}-cell`;
    this._allCells.forEach((cell) => {
      updateCellState(cell, "reorder-status", reorderStatus, newPart, oldPart);
    });
    this.__previousReorderStatus = reorderStatus;
  }
  /** @private */
  _resizableChanged(resizable, headerCell) {
    if (resizable === void 0 || headerCell === void 0) {
      return;
    }
    if (headerCell) {
      [headerCell].concat(this._emptyCells).forEach((cell) => {
        if (cell) {
          const existingHandle = cell.querySelector('[part~="resize-handle"]');
          if (existingHandle) {
            cell.removeChild(existingHandle);
          }
          if (resizable) {
            const handle = document.createElement("div");
            handle.setAttribute("part", "resize-handle");
            cell.appendChild(handle);
          }
        }
      });
    }
  }
  /** @private */
  _textAlignChanged(textAlign) {
    if (textAlign === void 0 || this._grid === void 0) {
      return;
    }
    if (["start", "end", "center"].indexOf(textAlign) === -1) {
      console.warn('textAlign can only be set as "start", "end" or "center"');
      return;
    }
    let textAlignFallback;
    if (getComputedStyle(this._grid).direction === "ltr") {
      if (textAlign === "start") {
        textAlignFallback = "left";
      } else if (textAlign === "end") {
        textAlignFallback = "right";
      }
    } else if (textAlign === "start") {
      textAlignFallback = "right";
    } else if (textAlign === "end") {
      textAlignFallback = "left";
    }
    this._allCells.forEach((cell) => {
      cell._content.style.textAlign = textAlign;
      if (getComputedStyle(cell._content).textAlign !== textAlign) {
        cell._content.style.textAlign = textAlignFallback;
      }
    });
  }
  /** @private */
  _hiddenChanged(hidden) {
    if (this.parentElement && this.parentElement._columnPropChanged) {
      this.parentElement._columnPropChanged("hidden", hidden);
    }
    if (!!hidden !== !!this._previousHidden && this._grid) {
      if (hidden === true) {
        this._allCells.forEach((cell) => {
          if (cell._content.parentNode) {
            cell._content.parentNode.removeChild(cell._content);
          }
        });
      }
      this._grid._debouncerHiddenChanged = Debouncer.debounce(
        this._grid._debouncerHiddenChanged,
        animationFrame,
        () => {
          if (this._grid && this._grid._renderColumnTree) {
            this._grid._renderColumnTree(this._grid._columnTree);
          }
        }
      );
      if (this._grid._debounceUpdateFrozenColumn) {
        this._grid._debounceUpdateFrozenColumn();
      }
      if (this._grid._resetKeyboardNavigation) {
        this._grid._resetKeyboardNavigation();
      }
    }
    this._previousHidden = hidden;
  }
  /** @protected */
  _runRenderer(renderer, cell, model) {
    const isVisibleBodyCell = model && model.item && !cell.parentElement.hidden;
    const shouldRender = isVisibleBodyCell || renderer === this._headerRenderer || renderer === this._footerRenderer;
    if (!shouldRender) {
      return;
    }
    const args = [cell._content, this];
    if (isVisibleBodyCell) {
      args.push(model);
    }
    renderer.apply(this, args);
  }
  /**
   * Renders the content to the given cells using a renderer.
   *
   * @private
   */
  __renderCellsContent(renderer, cells) {
    if (this.hidden || !this._grid) {
      return;
    }
    cells.forEach((cell) => {
      if (!cell.parentElement) {
        return;
      }
      const model = this._grid.__getRowModel(cell.parentElement);
      if (!renderer) {
        return;
      }
      if (cell._renderer !== renderer) {
        this._clearCellContent(cell);
      }
      cell._renderer = renderer;
      this._runRenderer(renderer, cell, model);
    });
  }
  /**
   * Clears the content of a cell.
   *
   * @protected
   */
  _clearCellContent(cell) {
    cell._content.innerHTML = "";
    delete cell._content._$litPart$;
  }
  /**
   * Renders the header cell content using a renderer,
   * and then updates the visibility of the parent row depending on
   * whether all its children cells are empty or not.
   *
   * @protected
   */
  _renderHeaderCellContent(headerRenderer, headerCell) {
    if (!headerCell || !headerRenderer) {
      return;
    }
    this.__renderCellsContent(headerRenderer, [headerCell]);
    if (this._grid && headerCell.parentElement) {
      this._grid.__debounceUpdateHeaderFooterRowVisibility(headerCell.parentElement);
    }
  }
  /** @protected */
  _onHeaderRendererOrBindingChanged(headerRenderer, headerCell, ..._bindings) {
    this._renderHeaderCellContent(headerRenderer, headerCell);
  }
  /** @private */
  __headerFooterPartNameChanged(headerCell, footerCell, headerPartName, footerPartName) {
    [
      { cell: headerCell, partName: headerPartName },
      { cell: footerCell, partName: footerPartName }
    ].forEach(({ cell, partName }) => {
      if (cell) {
        const customParts = cell.__customParts || [];
        cell.part.remove(...customParts);
        cell.__customParts = partName ? partName.trim().split(" ") : [];
        cell.part.add(...cell.__customParts);
      }
    });
  }
  /**
   * Renders the content of body cells using a renderer.
   *
   * @protected
   */
  _renderBodyCellsContent(renderer, cells) {
    if (!cells || !renderer) {
      return;
    }
    this.__renderCellsContent(renderer, cells);
  }
  /** @protected */
  _onRendererOrBindingChanged(renderer, cells, ..._bindings) {
    this._renderBodyCellsContent(renderer, cells);
  }
  /**
   * Renders the footer cell content using a renderer
   * and then updates the visibility of the parent row depending on
   * whether all its children cells are empty or not.
   *
   * @protected
   */
  _renderFooterCellContent(footerRenderer, footerCell) {
    if (!footerCell || !footerRenderer) {
      return;
    }
    this.__renderCellsContent(footerRenderer, [footerCell]);
    if (this._grid && footerCell.parentElement) {
      this._grid.__debounceUpdateHeaderFooterRowVisibility(footerCell.parentElement);
    }
  }
  /** @protected */
  _onFooterRendererOrBindingChanged(footerRenderer, footerCell) {
    this._renderFooterCellContent(footerRenderer, footerCell);
  }
  /** @private */
  __setTextContent(node, textContent) {
    if (node.textContent !== textContent) {
      node.textContent = textContent;
    }
  }
  /**
   * Renders the text header to the header cell.
   *
   * @private
   */
  __textHeaderRenderer() {
    this.__setTextContent(this._headerCell._content, this.header);
  }
  /**
   * Computes the property name based on the path and renders it to the header cell.
   * If the path is not defined, then nothing is rendered.
   *
   * @protected
   */
  _defaultHeaderRenderer() {
    if (!this.path) {
      return;
    }
    this.__setTextContent(this._headerCell._content, this._generateHeader(this.path));
  }
  /**
   * Computes the item property value based on the path and renders it to the body cell.
   * If the path is not defined, then nothing is rendered.
   *
   * @protected
   */
  _defaultRenderer(root2, _owner, { item }) {
    if (!this.path) {
      return;
    }
    this.__setTextContent(root2, get2(this.path, item));
  }
  /**
   * By default, nothing is rendered to the footer cell.
   *
   * @protected
   */
  _defaultFooterRenderer() {
  }
  /**
   * Computes the final header renderer for the `_headerRenderer` computed property.
   * All the arguments are observable by the Polymer, it re-calls the method
   * once an argument is changed to update the property value.
   *
   * @protected
   * @return {GridHeaderFooterRenderer | undefined}
   */
  _computeHeaderRenderer(headerRenderer, header) {
    if (headerRenderer) {
      return headerRenderer;
    }
    if (header !== void 0 && header !== null) {
      return this.__textHeaderRenderer;
    }
    return this._defaultHeaderRenderer;
  }
  /**
   * Computes the final renderer for the `_renderer` property.
   * All the arguments are observable by the Polymer, it re-calls the method
   * once an argument is changed to update the property value.
   *
   * @protected
   * @return {GridBodyRenderer | undefined}
   */
  _computeRenderer(renderer) {
    if (renderer) {
      return renderer;
    }
    return this._defaultRenderer;
  }
  /**
   * Computes the final footer renderer for the `_footerRenderer` property.
   * All the arguments are observable by the Polymer, it re-calls the method
   * once an argument is changed to update the property value.
   *
   * @protected
   * @return {GridHeaderFooterRenderer | undefined}
   */
  _computeFooterRenderer(footerRenderer) {
    if (footerRenderer) {
      return footerRenderer;
    }
    return this._defaultFooterRenderer;
  }
};
var GridColumnMixin = (superClass) => class extends ColumnBaseMixin(DirMixin(superClass)) {
  static get properties() {
    return {
      /**
       * Width of the cells for this column.
       *
       * Please note that using the `em` length unit is discouraged as
       * it might lead to misalignment issues if the header, body, and footer
       * cells have different font sizes. Instead, use `rem` if you need
       * a length unit relative to the font size.
       */
      width: {
        type: String,
        value: "100px",
        sync: true
      },
      /**
       * Flex grow ratio for the cell widths. When set to 0, cell width is fixed.
       * @attr {number} flex-grow
       * @type {number}
       */
      flexGrow: {
        type: Number,
        value: 1,
        sync: true
      },
      /**
       * Custom function for rendering the cell content.
       * Receives three arguments:
       *
       * - `root` The cell content DOM element. Append your content to it.
       * - `column` The `<vaadin-grid-column>` element.
       * - `model` The object with the properties related with
       *   the rendered item, contains:
       *   - `model.index` The index of the item.
       *   - `model.item` The item.
       *   - `model.expanded` Sublevel toggle state.
       *   - `model.level` Level of the tree represented with a horizontal offset of the toggle button.
       *   - `model.selected` Selected state.
       *   - `model.detailsOpened` Details opened state.
       *
       * @type {GridBodyRenderer | null | undefined}
       */
      renderer: {
        type: Function,
        sync: true
      },
      /**
       * Represents the final renderer computed on the set of observable arguments.
       * It is supposed to be used internally when rendering the content of a body cell.
       *
       * @protected
       * @type {GridBodyRenderer | undefined}
       */
      _renderer: {
        type: Function,
        computed: "_computeRenderer(renderer, __initialized)",
        sync: true
      },
      /**
       * Path to an item sub-property whose value gets displayed in the column body cells.
       * The property name is also shown in the column header if an explicit header or renderer isn't defined.
       */
      path: {
        type: String,
        sync: true
      },
      /**
       * Automatically sets the width of the column based on the column contents when this is set to `true`.
       *
       * For performance reasons the column width is calculated automatically only once when the grid items
       * are rendered for the first time and the calculation only considers the rows which are currently
       * rendered in DOM (a bit more than what is currently visible). If the grid is scrolled, or the cell
       * content changes, the column width might not match the contents anymore.
       *
       * Hidden columns are ignored in the calculation and their widths are not automatically updated when
       * you show a column that was initially hidden.
       *
       * You can manually trigger the auto sizing behavior again by calling `grid.recalculateColumnWidths()`.
       *
       * The column width may still grow larger when `flexGrow` is not 0.
       * @attr {boolean} auto-width
       * @type {boolean}
       */
      autoWidth: {
        type: Boolean,
        value: false
      },
      /**
       * When true, wraps the cell's slot into an element with role="button", and sets
       * the tabindex attribute on the button element, instead of the cell itself.
       * This is needed to keep focus in sync with VoiceOver cursor when navigating
       * with Control + Option + arrow keys: focusing the `<td>` element does not fire
       * a focus event, but focusing an element with role="button" inside a cell fires it.
       * @protected
       */
      _focusButtonMode: {
        type: Boolean,
        value: false
      },
      /**
       * @type {Array<!HTMLElement>}
       * @protected
       */
      _cells: {
        type: Array,
        sync: true
      }
    };
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-column.js
var GridColumn = class extends GridColumnMixin(PolymerElement) {
  static get is() {
    return "vaadin-grid-column";
  }
};
defineCustomElement(GridColumn);

// node_modules/@vaadin/component-base/src/controller-mixin.js
var ControllerMixin = dedupingMixin((superClass) => {
  if (typeof superClass.prototype.addController === "function") {
    return superClass;
  }
  return class ControllerMixinClass extends superClass {
    constructor() {
      super();
      this.__controllers = /* @__PURE__ */ new Set();
    }
    /** @protected */
    connectedCallback() {
      super.connectedCallback();
      this.__controllers.forEach((c13) => {
        if (c13.hostConnected) {
          c13.hostConnected();
        }
      });
    }
    /** @protected */
    disconnectedCallback() {
      super.disconnectedCallback();
      this.__controllers.forEach((c13) => {
        if (c13.hostDisconnected) {
          c13.hostDisconnected();
        }
      });
    }
    /**
     * Registers a controller to participate in the element update cycle.
     *
     * @param {ReactiveController} controller
     * @protected
     */
    addController(controller) {
      this.__controllers.add(controller);
      if (this.$ !== void 0 && this.isConnected && controller.hostConnected) {
        controller.hostConnected();
      }
    }
    /**
     * Removes a controller from the element.
     *
     * @param {ReactiveController} controller
     * @protected
     */
    removeController(controller) {
      this.__controllers.delete(controller);
    }
  };
});

// node_modules/@vaadin/vaadin-development-mode-detector/vaadin-development-mode-detector.js
var DEV_MODE_CODE_REGEXP = /\/\*[\*!]\s+vaadin-dev-mode:start([\s\S]*)vaadin-dev-mode:end\s+\*\*\//i;
var FlowClients = window.Vaadin && window.Vaadin.Flow && window.Vaadin.Flow.clients;
function isMinified() {
  function test() {
    return true;
  }
  return uncommentAndRun(test);
}
function isDevelopmentMode() {
  try {
    if (isForcedDevelopmentMode()) {
      return true;
    }
    if (!isLocalhost()) {
      return false;
    }
    if (FlowClients) {
      return !isFlowProductionMode();
    }
    return !isMinified();
  } catch (e13) {
    return false;
  }
}
function isForcedDevelopmentMode() {
  return localStorage.getItem("vaadin.developmentmode.force");
}
function isLocalhost() {
  return ["localhost", "127.0.0.1"].indexOf(window.location.hostname) >= 0;
}
function isFlowProductionMode() {
  if (FlowClients) {
    const productionModeApps = Object.keys(FlowClients).map((key) => FlowClients[key]).filter((client) => client.productionMode);
    if (productionModeApps.length > 0) {
      return true;
    }
  }
  return false;
}
function uncommentAndRun(callback, args) {
  if (typeof callback !== "function") {
    return;
  }
  const match = DEV_MODE_CODE_REGEXP.exec(callback.toString());
  if (match) {
    try {
      callback = new Function(match[1]);
    } catch (e13) {
      console.log("vaadin-development-mode-detector: uncommentAndRun() failed", e13);
    }
  }
  return callback(args);
}
window["Vaadin"] = window["Vaadin"] || {};
var runIfDevelopmentMode = function(callback, args) {
  if (window.Vaadin.developmentMode) {
    return uncommentAndRun(callback, args);
  }
};
if (window.Vaadin.developmentMode === void 0) {
  window.Vaadin.developmentMode = isDevelopmentMode();
}

// node_modules/@vaadin/vaadin-usage-statistics/vaadin-usage-statistics-collect.js
function maybeGatherAndSendStats() {
}
var usageStatistics = function() {
  if (typeof runIfDevelopmentMode === "function") {
    return runIfDevelopmentMode(maybeGatherAndSendStats);
  }
};

// node_modules/@vaadin/component-base/src/element-mixin.js
setCancelSyntheticClickEvents(false);
if (!window.Vaadin) {
  window.Vaadin = {};
}
if (!window.Vaadin.registrations) {
  window.Vaadin.registrations = [];
}
if (!window.Vaadin.developmentModeCallback) {
  window.Vaadin.developmentModeCallback = {};
}
window.Vaadin.developmentModeCallback["vaadin-usage-statistics"] = function() {
  usageStatistics();
};
var statsJob;
var registered = /* @__PURE__ */ new Set();
var ElementMixin2 = (superClass) => class VaadinElementMixin extends DirMixin(superClass) {
  /** @protected */
  static finalize() {
    super.finalize();
    const { is } = this;
    if (is && !registered.has(is)) {
      window.Vaadin.registrations.push(this);
      registered.add(is);
      if (window.Vaadin.developmentModeCallback) {
        statsJob = Debouncer.debounce(statsJob, idlePeriod, () => {
          window.Vaadin.developmentModeCallback["vaadin-usage-statistics"]();
        });
        enqueueDebouncer(statsJob);
      }
    }
  }
  constructor() {
    super();
    if (document.doctype === null) {
      console.warn(
        'Vaadin components require the "standards mode" declaration. Please add <!DOCTYPE html> to the HTML document.'
      );
    }
  }
};

// node_modules/@vaadin/a11y-base/src/focus-utils.js
var keyboardActive = false;
window.addEventListener(
  "keydown",
  () => {
    keyboardActive = true;
  },
  { capture: true }
);
window.addEventListener(
  "mousedown",
  () => {
    keyboardActive = false;
  },
  { capture: true }
);
function isKeyboardActive() {
  return keyboardActive;
}
function isElementHiddenDirectly(element) {
  const style2 = element.style;
  if (style2.visibility === "hidden" || style2.display === "none") {
    return true;
  }
  const computedStyle = window.getComputedStyle(element);
  if (computedStyle.visibility === "hidden" || computedStyle.display === "none") {
    return true;
  }
  return false;
}
function isElementHidden(element) {
  if (element.offsetParent === null && element.clientWidth === 0 && element.clientHeight === 0) {
    return true;
  }
  return isElementHiddenDirectly(element);
}
function isElementFocusable(element) {
  if (element.matches('[tabindex="-1"]')) {
    return false;
  }
  if (element.matches("input, select, textarea, button, object")) {
    return element.matches(":not([disabled])");
  }
  return element.matches("a[href], area[href], iframe, [tabindex], [contentEditable]");
}

// node_modules/@vaadin/a11y-base/src/disabled-mixin.js
var DisabledMixin = dedupingMixin(
  (superclass) => class DisabledMixinClass extends superclass {
    static get properties() {
      return {
        /**
         * If true, the user cannot interact with this element.
         */
        disabled: {
          type: Boolean,
          value: false,
          observer: "_disabledChanged",
          reflectToAttribute: true,
          sync: true
        }
      };
    }
    /**
     * @param {boolean} disabled
     * @protected
     */
    _disabledChanged(disabled) {
      this._setAriaDisabled(disabled);
    }
    /**
     * @param {boolean} disabled
     * @protected
     */
    _setAriaDisabled(disabled) {
      if (disabled) {
        this.setAttribute("aria-disabled", "true");
      } else {
        this.removeAttribute("aria-disabled");
      }
    }
    /**
     * Overrides the default element `click` method in order to prevent
     * firing the `click` event when the element is disabled.
     * @protected
     * @override
     */
    click() {
      if (!this.disabled) {
        super.click();
      }
    }
  }
);

// node_modules/@vaadin/a11y-base/src/tabindex-mixin.js
var TabindexMixin = (superclass) => class TabindexMixinClass extends DisabledMixin(superclass) {
  static get properties() {
    return {
      /**
       * Indicates whether the element can be focused and where it participates in sequential keyboard navigation.
       *
       * @protected
       */
      tabindex: {
        type: Number,
        reflectToAttribute: true,
        observer: "_tabindexChanged"
      },
      /**
       * Stores the last known tabindex since the element has been disabled.
       *
       * @protected
       */
      _lastTabIndex: {
        type: Number
      }
    };
  }
  /**
   * When the element gets disabled, the observer saves the last known tabindex
   * and makes the element not focusable by setting tabindex to -1.
   * As soon as the element gets enabled, the observer restores the last known tabindex
   * so that the element can be focusable again.
   *
   * @protected
   * @override
   */
  _disabledChanged(disabled, oldDisabled) {
    super._disabledChanged(disabled, oldDisabled);
    if (disabled) {
      if (this.tabindex !== void 0) {
        this._lastTabIndex = this.tabindex;
      }
      this.tabindex = -1;
    } else if (oldDisabled) {
      this.tabindex = this._lastTabIndex;
    }
  }
  /**
   * When the user has changed tabindex while the element is disabled,
   * the observer reverts tabindex to -1 and rather saves the new tabindex value to apply it later.
   * The new value will be applied as soon as the element becomes enabled.
   *
   * @protected
   */
  _tabindexChanged(tabindex) {
    if (this.disabled && tabindex !== -1) {
      this._lastTabIndex = tabindex;
      this.tabindex = -1;
    }
  }
};

// node_modules/@vaadin/component-base/src/browser-utils.js
var testUserAgent = (regexp) => regexp.test(navigator.userAgent);
var testPlatform = (regexp) => regexp.test(navigator.platform);
var testVendor = (regexp) => regexp.test(navigator.vendor);
var isAndroid = testUserAgent(/Android/u);
var isChrome = testUserAgent(/Chrome/u) && testVendor(/Google Inc/u);
var isFirefox = testUserAgent(/Firefox/u);
var isIPad = testPlatform(/^iPad/u) || testPlatform(/^Mac/u) && navigator.maxTouchPoints > 1;
var isIPhone = testPlatform(/^iPhone/u);
var isIOS = isIPhone || isIPad;
var isSafari = testUserAgent(/^((?!chrome|android).)*safari/iu);
var isTouch = (() => {
  try {
    document.createEvent("TouchEvent");
    return true;
  } catch (_2) {
    return false;
  }
})();
var supportsAdoptingStyleSheets2 = window.ShadowRoot && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype;

// node_modules/@vaadin/component-base/src/slot-observer.js
var SlotObserver = class {
  constructor(slot, callback) {
    this.slot = slot;
    this.callback = callback;
    this._storedNodes = [];
    this._connected = false;
    this._scheduled = false;
    this._boundSchedule = () => {
      this._schedule();
    };
    this.connect();
    this._schedule();
  }
  /**
   * Activates an observer. This method is automatically called when
   * a `SlotObserver` is created. It should only be called to  re-activate
   * an observer that has been deactivated via the `disconnect` method.
   */
  connect() {
    this.slot.addEventListener("slotchange", this._boundSchedule);
    this._connected = true;
  }
  /**
   * Deactivates the observer. After calling this method the observer callback
   * will not be called when changes to slotted nodes occur. The `connect` method
   * may be subsequently called to reactivate the observer.
   */
  disconnect() {
    this.slot.removeEventListener("slotchange", this._boundSchedule);
    this._connected = false;
  }
  /** @private */
  _schedule() {
    if (!this._scheduled) {
      this._scheduled = true;
      queueMicrotask(() => {
        this.flush();
      });
    }
  }
  /**
   * Run the observer callback synchronously.
   */
  flush() {
    if (!this._connected) {
      return;
    }
    this._scheduled = false;
    this._processNodes();
  }
  /** @private */
  _processNodes() {
    const currentNodes = this.slot.assignedNodes({ flatten: true });
    let addedNodes = [];
    const removedNodes = [];
    const movedNodes = [];
    if (currentNodes.length) {
      addedNodes = currentNodes.filter((node) => !this._storedNodes.includes(node));
    }
    if (this._storedNodes.length) {
      this._storedNodes.forEach((node, index) => {
        const idx = currentNodes.indexOf(node);
        if (idx === -1) {
          removedNodes.push(node);
        } else if (idx !== index) {
          movedNodes.push(node);
        }
      });
    }
    if (addedNodes.length || removedNodes.length || movedNodes.length) {
      this.callback({ addedNodes, currentNodes, movedNodes, removedNodes });
    }
    this._storedNodes = currentNodes;
  }
};

// node_modules/@vaadin/component-base/src/unique-id-utils.js
var uniqueId = 0;
function generateUniqueId() {
  return uniqueId++;
}

// node_modules/@vaadin/component-base/src/slot-controller.js
var SlotController = class extends EventTarget {
  /**
   * Ensure that every instance has unique ID.
   *
   * @param {HTMLElement} host
   * @param {string} slotName
   * @return {string}
   * @protected
   */
  static generateId(host, prefix = "default") {
    return `${prefix}-${host.localName}-${generateUniqueId()}`;
  }
  constructor(host, slotName, tagName, config = {}) {
    super();
    const { initializer, multiple, observe, useUniqueId, uniqueIdPrefix } = config;
    this.host = host;
    this.slotName = slotName;
    this.tagName = tagName;
    this.observe = typeof observe === "boolean" ? observe : true;
    this.multiple = typeof multiple === "boolean" ? multiple : false;
    this.slotInitializer = initializer;
    if (multiple) {
      this.nodes = [];
    }
    if (useUniqueId) {
      this.defaultId = this.constructor.generateId(host, uniqueIdPrefix || slotName);
    }
  }
  hostConnected() {
    if (!this.initialized) {
      if (this.multiple) {
        this.initMultiple();
      } else {
        this.initSingle();
      }
      if (this.observe) {
        this.observeSlot();
      }
      this.initialized = true;
    }
  }
  /** @protected */
  initSingle() {
    let node = this.getSlotChild();
    if (!node) {
      node = this.attachDefaultNode();
      this.initNode(node);
    } else {
      this.node = node;
      this.initAddedNode(node);
    }
  }
  /** @protected */
  initMultiple() {
    const children = this.getSlotChildren();
    if (children.length === 0) {
      const defaultNode = this.attachDefaultNode();
      if (defaultNode) {
        this.nodes = [defaultNode];
        this.initNode(defaultNode);
      }
    } else {
      this.nodes = children;
      children.forEach((node) => {
        this.initAddedNode(node);
      });
    }
  }
  /**
   * Create and attach default node using the provided tag name, if any.
   * @return {Node | undefined}
   * @protected
   */
  attachDefaultNode() {
    const { host, slotName, tagName } = this;
    let node = this.defaultNode;
    if (!node && tagName) {
      node = document.createElement(tagName);
      if (node instanceof Element) {
        if (slotName !== "") {
          node.setAttribute("slot", slotName);
        }
        this.defaultNode = node;
      }
    }
    if (node) {
      this.node = node;
      host.appendChild(node);
    }
    return node;
  }
  /**
   * Return the list of nodes matching the slot managed by the controller.
   * @return {Node}
   */
  getSlotChildren() {
    const { slotName } = this;
    return Array.from(this.host.childNodes).filter((node) => {
      return node.nodeType === Node.ELEMENT_NODE && node.slot === slotName || node.nodeType === Node.TEXT_NODE && node.textContent.trim() && slotName === "";
    });
  }
  /**
   * Return a reference to the node managed by the controller.
   * @return {Node}
   */
  getSlotChild() {
    return this.getSlotChildren()[0];
  }
  /**
   * Run `slotInitializer` for the node managed by the controller.
   *
   * @param {Node} node
   * @protected
   */
  initNode(node) {
    const { slotInitializer } = this;
    if (slotInitializer) {
      slotInitializer(node, this.host);
    }
  }
  /**
   * Override to initialize the newly added custom node.
   *
   * @param {Node} _node
   * @protected
   */
  initCustomNode(_node) {
  }
  /**
   * Override to teardown slotted node when it's removed.
   *
   * @param {Node} _node
   * @protected
   */
  teardownNode(_node) {
  }
  /**
   * Run both `initCustomNode` and `initNode` for a custom slotted node.
   *
   * @param {Node} node
   * @protected
   */
  initAddedNode(node) {
    if (node !== this.defaultNode) {
      this.initCustomNode(node);
      this.initNode(node);
    }
  }
  /**
   * Setup the observer to manage slot content changes.
   * @protected
   */
  observeSlot() {
    const { slotName } = this;
    const selector = slotName === "" ? "slot:not([name])" : `slot[name=${slotName}]`;
    const slot = this.host.shadowRoot.querySelector(selector);
    this.__slotObserver = new SlotObserver(slot, ({ addedNodes, removedNodes }) => {
      const current = this.multiple ? this.nodes : [this.node];
      const newNodes = addedNodes.filter((node) => !isEmptyTextNode(node) && !current.includes(node));
      if (removedNodes.length) {
        this.nodes = current.filter((node) => !removedNodes.includes(node));
        removedNodes.forEach((node) => {
          this.teardownNode(node);
        });
      }
      if (newNodes && newNodes.length > 0) {
        if (this.multiple) {
          if (this.defaultNode) {
            this.defaultNode.remove();
          }
          this.nodes = [...current, ...newNodes].filter((node) => node !== this.defaultNode);
          newNodes.forEach((node) => {
            this.initAddedNode(node);
          });
        } else {
          if (this.node) {
            this.node.remove();
          }
          this.node = newNodes[0];
          this.initAddedNode(this.node);
        }
      }
    });
  }
};

// node_modules/@vaadin/component-base/src/tooltip-controller.js
var TooltipController = class extends SlotController {
  constructor(host) {
    super(host, "tooltip");
    this.setTarget(host);
  }
  /**
   * Override to initialize the newly added custom tooltip.
   *
   * @param {Node} tooltipNode
   * @protected
   * @override
   */
  initCustomNode(tooltipNode) {
    tooltipNode.target = this.target;
    if (this.ariaTarget !== void 0) {
      tooltipNode.ariaTarget = this.ariaTarget;
    }
    if (this.context !== void 0) {
      tooltipNode.context = this.context;
    }
    if (this.manual !== void 0) {
      tooltipNode.manual = this.manual;
    }
    if (this.opened !== void 0) {
      tooltipNode.opened = this.opened;
    }
    if (this.position !== void 0) {
      tooltipNode._position = this.position;
    }
    if (this.shouldShow !== void 0) {
      tooltipNode.shouldShow = this.shouldShow;
    }
    this.__notifyChange();
  }
  /**
   * Override to notify the host when the tooltip is removed.
   *
   * @param {Node} tooltipNode
   * @protected
   * @override
   */
  teardownNode() {
    this.__notifyChange();
  }
  /**
   * Set an HTML element for linking with the tooltip overlay
   * via `aria-describedby` attribute used by screen readers.
   * @param {HTMLElement} ariaTarget
   */
  setAriaTarget(ariaTarget) {
    this.ariaTarget = ariaTarget;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode.ariaTarget = ariaTarget;
    }
  }
  /**
   * Set a context object to be used by generator.
   * @param {object} context
   */
  setContext(context) {
    this.context = context;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode.context = context;
    }
  }
  /**
   * Toggle manual state on the slotted tooltip.
   * @param {boolean} manual
   */
  setManual(manual) {
    this.manual = manual;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode.manual = manual;
    }
  }
  /**
   * Toggle opened state on the slotted tooltip.
   * @param {boolean} opened
   */
  setOpened(opened) {
    this.opened = opened;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode.opened = opened;
    }
  }
  /**
   * Set default position for the slotted tooltip.
   * This can be overridden by setting the position
   * using corresponding property or attribute.
   * @param {string} position
   */
  setPosition(position) {
    this.position = position;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode._position = position;
    }
  }
  /**
   * Set function used to detect whether to show
   * the tooltip based on a condition.
   * @param {Function} shouldShow
   */
  setShouldShow(shouldShow) {
    this.shouldShow = shouldShow;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode.shouldShow = shouldShow;
    }
  }
  /**
   * Set an HTML element to attach the tooltip to.
   * @param {HTMLElement} target
   */
  setTarget(target) {
    this.target = target;
    const tooltipNode = this.node;
    if (tooltipNode) {
      tooltipNode.target = target;
    }
  }
  /** @private */
  __notifyChange() {
    this.dispatchEvent(new CustomEvent("tooltip-changed", { detail: { node: this.node } }));
  }
};

// node_modules/@vaadin/component-base/src/iron-list-core.js
var IOS = navigator.userAgent.match(/iP(?:hone|ad;(?: U;)? CPU) OS (\d+)/u);
var IOS_TOUCH_SCROLLING = IOS && IOS[1] >= 8;
var DEFAULT_PHYSICAL_COUNT = 3;
var ironList = {
  /**
   * The ratio of hidden tiles that should remain in the scroll direction.
   * Recommended value ~0.5, so it will distribute tiles evenly in both
   * directions.
   */
  _ratio: 0.5,
  /**
   * The padding-top value for the list.
   */
  _scrollerPaddingTop: 0,
  /**
   * This value is a cached value of `scrollTop` from the last `scroll` event.
   */
  _scrollPosition: 0,
  /**
   * The sum of the heights of all the tiles in the DOM.
   */
  _physicalSize: 0,
  /**
   * The average `offsetHeight` of the tiles observed till now.
   */
  _physicalAverage: 0,
  /**
   * The number of tiles which `offsetHeight` > 0 observed until now.
   */
  _physicalAverageCount: 0,
  /**
   * The Y position of the item rendered in the `_physicalStart`
   * tile relative to the scrolling list.
   */
  _physicalTop: 0,
  /**
   * The number of items in the list.
   */
  _virtualCount: 0,
  /**
   * The estimated scroll height based on `_physicalAverage`
   */
  _estScrollHeight: 0,
  /**
   * The scroll height of the dom node
   */
  _scrollHeight: 0,
  /**
   * The height of the list. This is referred as the viewport in the context of
   * list.
   */
  _viewportHeight: 0,
  /**
   * The width of the list. This is referred as the viewport in the context of
   * list.
   */
  _viewportWidth: 0,
  /**
   * An array of DOM nodes that are currently in the tree
   * @type {?Array<!HTMLElement>}
   */
  _physicalItems: null,
  /**
   * An array of heights for each item in `_physicalItems`
   * @type {?Array<number>}
   */
  _physicalSizes: null,
  /**
   * A cached value for the first visible index.
   * See `firstVisibleIndex`
   * @type {?number}
   */
  _firstVisibleIndexVal: null,
  /**
   * A cached value for the last visible index.
   * See `lastVisibleIndex`
   * @type {?number}
   */
  _lastVisibleIndexVal: null,
  /**
   * The max number of pages to render. One page is equivalent to the height of
   * the list.
   */
  _maxPages: 2,
  /**
   * The cost of stamping a template in ms.
   */
  _templateCost: 0,
  /**
   * The bottom of the physical content.
   */
  get _physicalBottom() {
    return this._physicalTop + this._physicalSize;
  },
  /**
   * The bottom of the scroll.
   */
  get _scrollBottom() {
    return this._scrollPosition + this._viewportHeight;
  },
  /**
   * The n-th item rendered in the last physical item.
   */
  get _virtualEnd() {
    return this._virtualStart + this._physicalCount - 1;
  },
  /**
   * The height of the physical content that isn't on the screen.
   */
  get _hiddenContentSize() {
    return this._physicalSize - this._viewportHeight;
  },
  /**
   * The maximum scroll top value.
   */
  get _maxScrollTop() {
    return this._estScrollHeight - this._viewportHeight + this._scrollOffset;
  },
  /**
   * The largest n-th value for an item such that it can be rendered in
   * `_physicalStart`.
   */
  get _maxVirtualStart() {
    const virtualCount = this._virtualCount;
    return Math.max(0, virtualCount - this._physicalCount);
  },
  get _virtualStart() {
    return this._virtualStartVal || 0;
  },
  set _virtualStart(val) {
    val = this._clamp(val, 0, this._maxVirtualStart);
    this._virtualStartVal = val;
  },
  get _physicalStart() {
    return this._physicalStartVal || 0;
  },
  /**
   * The k-th tile that is at the top of the scrolling list.
   */
  set _physicalStart(val) {
    val %= this._physicalCount;
    if (val < 0) {
      val = this._physicalCount + val;
    }
    this._physicalStartVal = val;
  },
  /**
   * The k-th tile that is at the bottom of the scrolling list.
   */
  get _physicalEnd() {
    return (this._physicalStart + this._physicalCount - 1) % this._physicalCount;
  },
  get _physicalCount() {
    return this._physicalCountVal || 0;
  },
  set _physicalCount(val) {
    this._physicalCountVal = val;
  },
  /**
   * An optimal physical size such that we will have enough physical items
   * to fill up the viewport and recycle when the user scrolls.
   *
   * This default value assumes that we will at least have the equivalent
   * to a viewport of physical items above and below the user's viewport.
   */
  get _optPhysicalSize() {
    return this._viewportHeight === 0 ? Infinity : this._viewportHeight * this._maxPages;
  },
  /**
   * True if the current list is visible.
   */
  get _isVisible() {
    return Boolean(this.offsetWidth || this.offsetHeight);
  },
  /**
   * Gets the index of the first visible item in the viewport.
   *
   * @type {number}
   */
  get firstVisibleIndex() {
    let idx = this._firstVisibleIndexVal;
    if (idx == null) {
      let physicalOffset = this._physicalTop + this._scrollOffset;
      idx = this._iterateItems((pidx, vidx) => {
        physicalOffset += this._getPhysicalSizeIncrement(pidx);
        if (physicalOffset > this._scrollPosition) {
          return vidx;
        }
      }) || 0;
      this._firstVisibleIndexVal = idx;
    }
    return idx;
  },
  /**
   * Gets the index of the last visible item in the viewport.
   *
   * @type {number}
   */
  get lastVisibleIndex() {
    let idx = this._lastVisibleIndexVal;
    if (idx == null) {
      let physicalOffset = this._physicalTop + this._scrollOffset;
      this._iterateItems((pidx, vidx) => {
        if (physicalOffset < this._scrollBottom) {
          idx = vidx;
        }
        physicalOffset += this._getPhysicalSizeIncrement(pidx);
      });
      this._lastVisibleIndexVal = idx;
    }
    return idx;
  },
  get _scrollOffset() {
    return this._scrollerPaddingTop + this.scrollOffset;
  },
  /**
   * Recycles the physical items when needed.
   */
  _scrollHandler() {
    const scrollTop = Math.max(0, Math.min(this._maxScrollTop, this._scrollTop));
    let delta = scrollTop - this._scrollPosition;
    const isScrollingDown = delta >= 0;
    this._scrollPosition = scrollTop;
    this._firstVisibleIndexVal = null;
    this._lastVisibleIndexVal = null;
    if (Math.abs(delta) > this._physicalSize && this._physicalSize > 0) {
      delta -= this._scrollOffset;
      const idxAdjustment = Math.round(delta / this._physicalAverage);
      this._virtualStart += idxAdjustment;
      this._physicalStart += idxAdjustment;
      this._physicalTop = Math.min(Math.floor(this._virtualStart) * this._physicalAverage, this._scrollPosition);
      this._update();
    } else if (this._physicalCount > 0) {
      const reusables = this._getReusables(isScrollingDown);
      if (isScrollingDown) {
        this._physicalTop = reusables.physicalTop;
        this._virtualStart += reusables.indexes.length;
        this._physicalStart += reusables.indexes.length;
      } else {
        this._virtualStart -= reusables.indexes.length;
        this._physicalStart -= reusables.indexes.length;
      }
      this._update(reusables.indexes, isScrollingDown ? null : reusables.indexes);
      this._debounce("_increasePoolIfNeeded", this._increasePoolIfNeeded.bind(this, 0), microTask2);
    }
  },
  /**
   * Returns an object that contains the indexes of the physical items
   * that might be reused and the physicalTop.
   *
   * @param {boolean} fromTop If the potential reusable items are above the scrolling region.
   */
  _getReusables(fromTop) {
    let ith, offsetContent, physicalItemHeight;
    const idxs = [];
    const protectedOffsetContent = this._hiddenContentSize * this._ratio;
    const virtualStart = this._virtualStart;
    const virtualEnd = this._virtualEnd;
    const physicalCount = this._physicalCount;
    let top = this._physicalTop + this._scrollOffset;
    const bottom = this._physicalBottom + this._scrollOffset;
    const scrollTop = this._scrollPosition;
    const scrollBottom = this._scrollBottom;
    if (fromTop) {
      ith = this._physicalStart;
      offsetContent = scrollTop - top;
    } else {
      ith = this._physicalEnd;
      offsetContent = bottom - scrollBottom;
    }
    while (true) {
      physicalItemHeight = this._getPhysicalSizeIncrement(ith);
      offsetContent -= physicalItemHeight;
      if (idxs.length >= physicalCount || offsetContent <= protectedOffsetContent) {
        break;
      }
      if (fromTop) {
        if (virtualEnd + idxs.length + 1 >= this._virtualCount) {
          break;
        }
        if (top + physicalItemHeight >= scrollTop - this._scrollOffset) {
          break;
        }
        idxs.push(ith);
        top += physicalItemHeight;
        ith = (ith + 1) % physicalCount;
      } else {
        if (virtualStart - idxs.length <= 0) {
          break;
        }
        if (top + this._physicalSize - physicalItemHeight <= scrollBottom) {
          break;
        }
        idxs.push(ith);
        top -= physicalItemHeight;
        ith = ith === 0 ? physicalCount - 1 : ith - 1;
      }
    }
    return { indexes: idxs, physicalTop: top - this._scrollOffset };
  },
  /**
   * Update the list of items, starting from the `_virtualStart` item.
   * @param {!Array<number>=} itemSet
   * @param {!Array<number>=} movingUp
   */
  _update(itemSet, movingUp) {
    if (itemSet && itemSet.length === 0 || this._physicalCount === 0) {
      return;
    }
    this._assignModels(itemSet);
    this._updateMetrics(itemSet);
    if (movingUp) {
      while (movingUp.length) {
        const idx = movingUp.pop();
        this._physicalTop -= this._getPhysicalSizeIncrement(idx);
      }
    }
    this._positionItems();
    this._updateScrollerSize();
  },
  _isClientFull() {
    return this._scrollBottom !== 0 && this._physicalBottom - 1 >= this._scrollBottom && this._physicalTop <= this._scrollPosition;
  },
  /**
   * Increases the pool size.
   */
  _increasePoolIfNeeded(count) {
    const nextPhysicalCount = this._clamp(
      this._physicalCount + count,
      DEFAULT_PHYSICAL_COUNT,
      this._virtualCount - this._virtualStart
    );
    const delta = nextPhysicalCount - this._physicalCount;
    let nextIncrease = Math.round(this._physicalCount * 0.5);
    if (delta < 0) {
      return;
    }
    if (delta > 0) {
      const ts = window.performance.now();
      [].push.apply(this._physicalItems, this._createPool(delta));
      for (let i11 = 0; i11 < delta; i11++) {
        this._physicalSizes.push(0);
      }
      this._physicalCount += delta;
      if (this._physicalStart > this._physicalEnd && this._isIndexRendered(this._focusedVirtualIndex) && this._getPhysicalIndex(this._focusedVirtualIndex) < this._physicalEnd) {
        this._physicalStart += delta;
      }
      this._update();
      this._templateCost = (window.performance.now() - ts) / delta;
      nextIncrease = Math.round(this._physicalCount * 0.5);
    }
    if (this._virtualEnd >= this._virtualCount - 1 || nextIncrease === 0) {
    } else if (!this._isClientFull()) {
      this._debounce("_increasePoolIfNeeded", this._increasePoolIfNeeded.bind(this, nextIncrease), microTask2);
    } else if (this._physicalSize < this._optPhysicalSize) {
      this._debounce(
        "_increasePoolIfNeeded",
        this._increasePoolIfNeeded.bind(this, this._clamp(Math.round(50 / this._templateCost), 1, nextIncrease)),
        idlePeriod
      );
    }
  },
  /**
   * Renders the a new list.
   */
  _render() {
    if (!this.isAttached || !this._isVisible) {
      return;
    }
    if (this._physicalCount !== 0) {
      const reusables = this._getReusables(true);
      this._physicalTop = reusables.physicalTop;
      this._virtualStart += reusables.indexes.length;
      this._physicalStart += reusables.indexes.length;
      this._update(reusables.indexes);
      this._update();
      this._increasePoolIfNeeded(0);
    } else if (this._virtualCount > 0) {
      this.updateViewportBoundaries();
      this._increasePoolIfNeeded(DEFAULT_PHYSICAL_COUNT);
    }
  },
  /**
   * Called when the items have changed. That is, reassignments
   * to `items`, splices or updates to a single item.
   */
  _itemsChanged(change) {
    if (change.path === "items") {
      this._virtualStart = 0;
      this._physicalTop = 0;
      this._virtualCount = this.items ? this.items.length : 0;
      this._physicalIndexForKey = {};
      this._firstVisibleIndexVal = null;
      this._lastVisibleIndexVal = null;
      if (!this._physicalItems) {
        this._physicalItems = [];
      }
      if (!this._physicalSizes) {
        this._physicalSizes = [];
      }
      this._physicalStart = 0;
      if (this._scrollTop > this._scrollOffset) {
        this._resetScrollPosition(0);
      }
      this._debounce("_render", this._render, animationFrame);
    }
  },
  /**
   * Executes a provided function per every physical index in `itemSet`
   * `itemSet` default value is equivalent to the entire set of physical
   * indexes.
   *
   * @param {!function(number, number)} fn
   * @param {!Array<number>=} itemSet
   */
  _iterateItems(fn, itemSet) {
    let pidx, vidx, rtn, i11;
    if (arguments.length === 2 && itemSet) {
      for (i11 = 0; i11 < itemSet.length; i11++) {
        pidx = itemSet[i11];
        vidx = this._computeVidx(pidx);
        if ((rtn = fn.call(this, pidx, vidx)) != null) {
          return rtn;
        }
      }
    } else {
      pidx = this._physicalStart;
      vidx = this._virtualStart;
      for (; pidx < this._physicalCount; pidx++, vidx++) {
        if ((rtn = fn.call(this, pidx, vidx)) != null) {
          return rtn;
        }
      }
      for (pidx = 0; pidx < this._physicalStart; pidx++, vidx++) {
        if ((rtn = fn.call(this, pidx, vidx)) != null) {
          return rtn;
        }
      }
    }
  },
  /**
   * Returns the virtual index for a given physical index
   *
   * @param {number} pidx Physical index
   * @return {number}
   */
  _computeVidx(pidx) {
    if (pidx >= this._physicalStart) {
      return this._virtualStart + (pidx - this._physicalStart);
    }
    return this._virtualStart + (this._physicalCount - this._physicalStart) + pidx;
  },
  /**
   * Updates the position of the physical items.
   */
  _positionItems() {
    this._adjustScrollPosition();
    let y5 = this._physicalTop;
    this._iterateItems((pidx) => {
      this.translate3d(0, `${y5}px`, 0, this._physicalItems[pidx]);
      y5 += this._physicalSizes[pidx];
    });
  },
  _getPhysicalSizeIncrement(pidx) {
    return this._physicalSizes[pidx];
  },
  /**
   * Adjusts the scroll position when it was overestimated.
   */
  _adjustScrollPosition() {
    const deltaHeight = this._virtualStart === 0 ? this._physicalTop : Math.min(this._scrollPosition + this._physicalTop, 0);
    if (deltaHeight !== 0) {
      this._physicalTop -= deltaHeight;
      const scrollTop = this._scrollPosition;
      if (!IOS_TOUCH_SCROLLING && scrollTop > 0) {
        this._resetScrollPosition(scrollTop - deltaHeight);
      }
    }
  },
  /**
   * Sets the position of the scroll.
   */
  _resetScrollPosition(pos) {
    if (this.scrollTarget && pos >= 0) {
      this._scrollTop = pos;
      this._scrollPosition = this._scrollTop;
    }
  },
  /**
   * Sets the scroll height, that's the height of the content,
   *
   * @param {boolean=} forceUpdate If true, updates the height no matter what.
   */
  _updateScrollerSize(forceUpdate) {
    const estScrollHeight = this._physicalBottom + Math.max(this._virtualCount - this._physicalCount - this._virtualStart, 0) * this._physicalAverage;
    this._estScrollHeight = estScrollHeight;
    if (forceUpdate || this._scrollHeight === 0 || this._scrollPosition >= estScrollHeight - this._physicalSize || Math.abs(estScrollHeight - this._scrollHeight) >= this._viewportHeight) {
      this.$.items.style.height = `${estScrollHeight}px`;
      this._scrollHeight = estScrollHeight;
    }
  },
  /**
   * Scroll to a specific index in the virtual list regardless
   * of the physical items in the DOM tree.
   *
   * @method scrollToIndex
   * @param {number} idx The index of the item
   */
  scrollToIndex(idx) {
    if (typeof idx !== "number" || idx < 0 || idx > this.items.length - 1) {
      return;
    }
    flush();
    if (this._physicalCount === 0) {
      return;
    }
    idx = this._clamp(idx, 0, this._virtualCount - 1);
    if (!this._isIndexRendered(idx) || idx >= this._maxVirtualStart) {
      this._virtualStart = idx - 1;
    }
    this._assignModels();
    this._updateMetrics();
    this._physicalTop = this._virtualStart * this._physicalAverage;
    let currentTopItem = this._physicalStart;
    let currentVirtualItem = this._virtualStart;
    let targetOffsetTop = 0;
    const hiddenContentSize = this._hiddenContentSize;
    while (currentVirtualItem < idx && targetOffsetTop <= hiddenContentSize) {
      targetOffsetTop += this._getPhysicalSizeIncrement(currentTopItem);
      currentTopItem = (currentTopItem + 1) % this._physicalCount;
      currentVirtualItem += 1;
    }
    this._updateScrollerSize(true);
    this._positionItems();
    this._resetScrollPosition(this._physicalTop + this._scrollOffset + targetOffsetTop);
    this._increasePoolIfNeeded(0);
    this._firstVisibleIndexVal = null;
    this._lastVisibleIndexVal = null;
  },
  /**
   * Reset the physical average and the average count.
   */
  _resetAverage() {
    this._physicalAverage = 0;
    this._physicalAverageCount = 0;
  },
  /**
   * A handler for the `iron-resize` event triggered by `IronResizableBehavior`
   * when the element is resized.
   */
  _resizeHandler() {
    this._debounce(
      "_render",
      () => {
        this._firstVisibleIndexVal = null;
        this._lastVisibleIndexVal = null;
        if (this._isVisible) {
          this.updateViewportBoundaries();
          this.toggleScrollListener(true);
          this._resetAverage();
          this._render();
        } else {
          this.toggleScrollListener(false);
        }
      },
      animationFrame
    );
  },
  _isIndexRendered(idx) {
    return idx >= this._virtualStart && idx <= this._virtualEnd;
  },
  _getPhysicalIndex(vidx) {
    return (this._physicalStart + (vidx - this._virtualStart)) % this._physicalCount;
  },
  _clamp(v3, min, max) {
    return Math.min(max, Math.max(min, v3));
  },
  _debounce(name, cb, asyncModule) {
    if (!this._debouncers) {
      this._debouncers = {};
    }
    this._debouncers[name] = Debouncer.debounce(this._debouncers[name], asyncModule, cb.bind(this));
    enqueueDebouncer(this._debouncers[name]);
  }
};

// node_modules/@vaadin/component-base/src/virtualizer-iron-list-adapter.js
var MAX_VIRTUAL_COUNT = 1e5;
var OFFSET_ADJUST_MIN_THRESHOLD = 1e3;
var IronListAdapter = class {
  constructor({ createElements, updateElement, scrollTarget, scrollContainer, elementsContainer, reorderElements }) {
    this.isAttached = true;
    this._vidxOffset = 0;
    this.createElements = createElements;
    this.updateElement = updateElement;
    this.scrollTarget = scrollTarget;
    this.scrollContainer = scrollContainer;
    this.elementsContainer = elementsContainer || scrollContainer;
    this.reorderElements = reorderElements;
    this._maxPages = 1.3;
    this.__placeholderHeight = 200;
    this.__elementHeightQueue = Array(10);
    this.timeouts = {
      SCROLL_REORDER: 500,
      IGNORE_WHEEL: 500,
      FIX_INVALID_ITEM_POSITIONING: 100
    };
    this.__resizeObserver = new ResizeObserver(() => this._resizeHandler());
    if (getComputedStyle(this.scrollTarget).overflow === "visible") {
      this.scrollTarget.style.overflow = "auto";
    }
    if (getComputedStyle(this.scrollContainer).position === "static") {
      this.scrollContainer.style.position = "relative";
    }
    this.__resizeObserver.observe(this.scrollTarget);
    this.scrollTarget.addEventListener("scroll", () => this._scrollHandler());
    const attachObserver = new ResizeObserver(([{ contentRect }]) => {
      const isHidden = contentRect.width === 0 && contentRect.height === 0;
      if (!isHidden && this.__scrollTargetHidden && this.scrollTarget.scrollTop !== this._scrollPosition) {
        this.scrollTarget.scrollTop = this._scrollPosition;
      }
      this.__scrollTargetHidden = isHidden;
    });
    attachObserver.observe(this.scrollTarget);
    this._scrollLineHeight = this._getScrollLineHeight();
    this.scrollTarget.addEventListener("wheel", (e13) => this.__onWheel(e13));
    this.scrollTarget.addEventListener("virtualizer-element-focused", (e13) => this.__onElementFocused(e13));
    this.elementsContainer.addEventListener("focusin", () => {
      this.scrollTarget.dispatchEvent(
        new CustomEvent("virtualizer-element-focused", { detail: { element: this.__getFocusedElement() } })
      );
    });
    if (this.reorderElements) {
      this.scrollTarget.addEventListener("mousedown", () => {
        this.__mouseDown = true;
      });
      this.scrollTarget.addEventListener("mouseup", () => {
        this.__mouseDown = false;
        if (this.__pendingReorder) {
          this.__reorderElements();
        }
      });
    }
  }
  get scrollOffset() {
    return 0;
  }
  get adjustedFirstVisibleIndex() {
    return this.firstVisibleIndex + this._vidxOffset;
  }
  get adjustedLastVisibleIndex() {
    return this.lastVisibleIndex + this._vidxOffset;
  }
  get _maxVirtualIndexOffset() {
    return this.size - this._virtualCount;
  }
  __hasPlaceholders() {
    return this.__getVisibleElements().some((el) => el.__virtualizerPlaceholder);
  }
  scrollToIndex(index) {
    if (typeof index !== "number" || isNaN(index) || this.size === 0 || !this.scrollTarget.offsetHeight) {
      return;
    }
    delete this.__pendingScrollToIndex;
    if (this._physicalCount <= 3) {
      this.flush();
    }
    index = this._clamp(index, 0, this.size - 1);
    const visibleElementCount = this.__getVisibleElements().length;
    let targetVirtualIndex = Math.floor(index / this.size * this._virtualCount);
    if (this._virtualCount - targetVirtualIndex < visibleElementCount) {
      targetVirtualIndex = this._virtualCount - (this.size - index);
      this._vidxOffset = this._maxVirtualIndexOffset;
    } else if (targetVirtualIndex < visibleElementCount) {
      if (index < OFFSET_ADJUST_MIN_THRESHOLD) {
        targetVirtualIndex = index;
        this._vidxOffset = 0;
      } else {
        targetVirtualIndex = OFFSET_ADJUST_MIN_THRESHOLD;
        this._vidxOffset = index - targetVirtualIndex;
      }
    } else {
      this._vidxOffset = index - targetVirtualIndex;
    }
    this.__skipNextVirtualIndexAdjust = true;
    super.scrollToIndex(targetVirtualIndex);
    if (this.adjustedFirstVisibleIndex !== index && this._scrollTop < this._maxScrollTop && !this.grid) {
      this._scrollTop -= this.__getIndexScrollOffset(index) || 0;
    }
    this._scrollHandler();
    if (this.__hasPlaceholders()) {
      this.__pendingScrollToIndex = index;
    }
  }
  flush() {
    if (this.scrollTarget.offsetHeight === 0) {
      return;
    }
    this._resizeHandler();
    flush();
    this._scrollHandler();
    if (this.__fixInvalidItemPositioningDebouncer) {
      this.__fixInvalidItemPositioningDebouncer.flush();
    }
    if (this.__scrollReorderDebouncer) {
      this.__scrollReorderDebouncer.flush();
    }
    if (this.__debouncerWheelAnimationFrame) {
      this.__debouncerWheelAnimationFrame.flush();
    }
  }
  hostConnected() {
    if (this.scrollTarget.offsetParent && this.scrollTarget.scrollTop !== this._scrollPosition) {
      this.scrollTarget.scrollTop = this._scrollPosition;
    }
  }
  update(startIndex = 0, endIndex = this.size - 1) {
    const updatedElements = [];
    this.__getVisibleElements().forEach((el) => {
      if (el.__virtualIndex >= startIndex && el.__virtualIndex <= endIndex) {
        this.__updateElement(el, el.__virtualIndex, true);
        updatedElements.push(el);
      }
    });
    this.__afterElementsUpdated(updatedElements);
  }
  /**
   * Updates the height for a given set of items.
   *
   * @param {!Array<number>=} itemSet
   */
  _updateMetrics(itemSet) {
    flush();
    let newPhysicalSize = 0;
    let oldPhysicalSize = 0;
    const prevAvgCount = this._physicalAverageCount;
    const prevPhysicalAvg = this._physicalAverage;
    this._iterateItems((pidx, vidx) => {
      oldPhysicalSize += this._physicalSizes[pidx];
      this._physicalSizes[pidx] = Math.ceil(this.__getBorderBoxHeight(this._physicalItems[pidx]));
      newPhysicalSize += this._physicalSizes[pidx];
      this._physicalAverageCount += this._physicalSizes[pidx] ? 1 : 0;
    }, itemSet);
    this._physicalSize = this._physicalSize + newPhysicalSize - oldPhysicalSize;
    if (this._physicalAverageCount !== prevAvgCount) {
      this._physicalAverage = Math.round(
        (prevPhysicalAvg * prevAvgCount + newPhysicalSize) / this._physicalAverageCount
      );
    }
  }
  __getBorderBoxHeight(el) {
    const style2 = getComputedStyle(el);
    const itemHeight = parseFloat(style2.height) || 0;
    if (style2.boxSizing === "border-box") {
      return itemHeight;
    }
    const paddingBottom = parseFloat(style2.paddingBottom) || 0;
    const paddingTop = parseFloat(style2.paddingTop) || 0;
    const borderBottomWidth = parseFloat(style2.borderBottomWidth) || 0;
    const borderTopWidth = parseFloat(style2.borderTopWidth) || 0;
    return itemHeight + paddingBottom + paddingTop + borderBottomWidth + borderTopWidth;
  }
  __updateElement(el, index, forceSameIndexUpdates) {
    if (el.__virtualizerPlaceholder) {
      el.style.paddingTop = "";
      el.style.opacity = "";
      el.__virtualizerPlaceholder = false;
    }
    if (!this.__preventElementUpdates && (el.__lastUpdatedIndex !== index || forceSameIndexUpdates)) {
      this.updateElement(el, index);
      el.__lastUpdatedIndex = index;
    }
  }
  /**
   * Called synchronously right after elements have been updated.
   * This is a good place to do any post-update work.
   *
   * @param {!Array<!HTMLElement>} updatedElements
   */
  __afterElementsUpdated(updatedElements) {
    updatedElements.forEach((el) => {
      const elementHeight = el.offsetHeight;
      if (elementHeight === 0) {
        el.style.paddingTop = `${this.__placeholderHeight}px`;
        el.style.opacity = "0";
        el.__virtualizerPlaceholder = true;
        this.__placeholderClearDebouncer = Debouncer.debounce(
          this.__placeholderClearDebouncer,
          animationFrame,
          () => this._resizeHandler()
        );
      } else {
        this.__elementHeightQueue.push(elementHeight);
        this.__elementHeightQueue.shift();
        const filteredHeights = this.__elementHeightQueue.filter((h8) => h8 !== void 0);
        this.__placeholderHeight = Math.round(filteredHeights.reduce((a17, b5) => a17 + b5, 0) / filteredHeights.length);
      }
    });
    if (this.__pendingScrollToIndex !== void 0 && !this.__hasPlaceholders()) {
      this.scrollToIndex(this.__pendingScrollToIndex);
    }
  }
  __getIndexScrollOffset(index) {
    const element = this.__getVisibleElements().find((el) => el.__virtualIndex === index);
    return element ? this.scrollTarget.getBoundingClientRect().top - element.getBoundingClientRect().top : void 0;
  }
  get size() {
    return this.__size;
  }
  set size(size) {
    if (size === this.size) {
      return;
    }
    if (this.__fixInvalidItemPositioningDebouncer) {
      this.__fixInvalidItemPositioningDebouncer.cancel();
    }
    if (this._debouncers && this._debouncers._increasePoolIfNeeded) {
      this._debouncers._increasePoolIfNeeded.cancel();
    }
    this.__preventElementUpdates = true;
    let fvi;
    let fviOffsetBefore;
    if (size > 0) {
      fvi = this.adjustedFirstVisibleIndex;
      fviOffsetBefore = this.__getIndexScrollOffset(fvi);
    }
    this.__size = size;
    this._itemsChanged({
      path: "items"
    });
    flush();
    if (size > 0) {
      fvi = Math.min(fvi, size - 1);
      this.scrollToIndex(fvi);
      const fviOffsetAfter = this.__getIndexScrollOffset(fvi);
      if (fviOffsetBefore !== void 0 && fviOffsetAfter !== void 0) {
        this._scrollTop += fviOffsetBefore - fviOffsetAfter;
      }
    }
    this.__preventElementUpdates = false;
    if (!this._isVisible) {
      this._assignModels();
    }
    if (!this.elementsContainer.children.length) {
      requestAnimationFrame(() => this._resizeHandler());
    }
    this._resizeHandler();
    flush();
    this._debounce("_update", this._update, microTask2);
  }
  /** @private */
  get _scrollTop() {
    return this.scrollTarget.scrollTop;
  }
  /** @private */
  set _scrollTop(top) {
    this.scrollTarget.scrollTop = top;
  }
  /** @private */
  get items() {
    return {
      length: Math.min(this.size, MAX_VIRTUAL_COUNT)
    };
  }
  /** @private */
  get offsetHeight() {
    return this.scrollTarget.offsetHeight;
  }
  /** @private */
  get $() {
    return {
      items: this.scrollContainer
    };
  }
  /** @private */
  updateViewportBoundaries() {
    const styles = window.getComputedStyle(this.scrollTarget);
    this._scrollerPaddingTop = this.scrollTarget === this ? 0 : parseInt(styles["padding-top"], 10);
    this._isRTL = Boolean(styles.direction === "rtl");
    this._viewportWidth = this.elementsContainer.offsetWidth;
    this._viewportHeight = this.scrollTarget.offsetHeight;
    this._scrollPageHeight = this._viewportHeight - this._scrollLineHeight;
    if (this.grid) {
      this._updateGridMetrics();
    }
  }
  /** @private */
  setAttribute() {
  }
  /** @private */
  _createPool(size) {
    const physicalItems = this.createElements(size);
    const fragment = document.createDocumentFragment();
    physicalItems.forEach((el) => {
      el.style.position = "absolute";
      fragment.appendChild(el);
      this.__resizeObserver.observe(el);
    });
    this.elementsContainer.appendChild(fragment);
    return physicalItems;
  }
  /** @private */
  _assignModels(itemSet) {
    const updatedElements = [];
    this._iterateItems((pidx, vidx) => {
      const el = this._physicalItems[pidx];
      el.hidden = vidx >= this.size;
      if (!el.hidden) {
        el.__virtualIndex = vidx + (this._vidxOffset || 0);
        this.__updateElement(el, el.__virtualIndex);
        updatedElements.push(el);
      } else {
        delete el.__lastUpdatedIndex;
      }
    }, itemSet);
    this.__afterElementsUpdated(updatedElements);
  }
  /** @private */
  _isClientFull() {
    setTimeout(() => {
      this.__clientFull = true;
    });
    return this.__clientFull || super._isClientFull();
  }
  /** @private */
  translate3d(_x, y5, _z, el) {
    el.style.transform = `translateY(${y5})`;
  }
  /** @private */
  toggleScrollListener() {
  }
  /** @private */
  __getFocusedElement(visibleElements = this.__getVisibleElements()) {
    return visibleElements.find(
      (element) => element.contains(this.elementsContainer.getRootNode().activeElement) || element.contains(this.scrollTarget.getRootNode().activeElement)
    );
  }
  /** @private */
  __nextFocusableSiblingMissing(focusedElement, visibleElements) {
    return (
      // Check if focused element is the last visible DOM element
      visibleElements.indexOf(focusedElement) === visibleElements.length - 1 && // ...while there are more items available
      this.size > focusedElement.__virtualIndex + 1
    );
  }
  /** @private */
  __previousFocusableSiblingMissing(focusedElement, visibleElements) {
    return (
      // Check if focused element is the first visible DOM element
      visibleElements.indexOf(focusedElement) === 0 && // ...while there are preceding items available
      focusedElement.__virtualIndex > 0
    );
  }
  /** @private */
  __onElementFocused(e13) {
    if (!this.reorderElements) {
      return;
    }
    const focusedElement = e13.detail.element;
    if (!focusedElement) {
      return;
    }
    const visibleElements = this.__getVisibleElements();
    if (this.__previousFocusableSiblingMissing(focusedElement, visibleElements) || this.__nextFocusableSiblingMissing(focusedElement, visibleElements)) {
      this.flush();
    }
    const reorderedVisibleElements = this.__getVisibleElements();
    if (this.__nextFocusableSiblingMissing(focusedElement, reorderedVisibleElements)) {
      this._scrollTop += Math.ceil(focusedElement.getBoundingClientRect().bottom) - Math.floor(this.scrollTarget.getBoundingClientRect().bottom - 1);
      this.flush();
    } else if (this.__previousFocusableSiblingMissing(focusedElement, reorderedVisibleElements)) {
      this._scrollTop -= Math.ceil(this.scrollTarget.getBoundingClientRect().top + 1) - Math.floor(focusedElement.getBoundingClientRect().top);
      this.flush();
    }
  }
  _scrollHandler() {
    if (this.scrollTarget.offsetHeight === 0) {
      return;
    }
    this._adjustVirtualIndexOffset(this._scrollTop - (this.__previousScrollTop || 0));
    const delta = this.scrollTarget.scrollTop - this._scrollPosition;
    super._scrollHandler();
    if (this._physicalCount !== 0) {
      const isScrollingDown = delta >= 0;
      const reusables = this._getReusables(!isScrollingDown);
      if (reusables.indexes.length) {
        this._physicalTop = reusables.physicalTop;
        if (isScrollingDown) {
          this._virtualStart -= reusables.indexes.length;
          this._physicalStart -= reusables.indexes.length;
        } else {
          this._virtualStart += reusables.indexes.length;
          this._physicalStart += reusables.indexes.length;
        }
        this._resizeHandler();
      }
    }
    if (delta) {
      this.__fixInvalidItemPositioningDebouncer = Debouncer.debounce(
        this.__fixInvalidItemPositioningDebouncer,
        timeOut.after(this.timeouts.FIX_INVALID_ITEM_POSITIONING),
        () => this.__fixInvalidItemPositioning()
      );
    }
    if (this.reorderElements) {
      this.__scrollReorderDebouncer = Debouncer.debounce(
        this.__scrollReorderDebouncer,
        timeOut.after(this.timeouts.SCROLL_REORDER),
        () => this.__reorderElements()
      );
    }
    this.__previousScrollTop = this._scrollTop;
    if (this._scrollTop === 0 && this.firstVisibleIndex !== 0 && Math.abs(delta) > 0) {
      this.scrollToIndex(0);
    }
  }
  /**
   * Work around an iron-list issue with invalid item positioning.
   * See https://github.com/vaadin/flow-components/issues/4306
   * @private
   */
  __fixInvalidItemPositioning() {
    if (!this.scrollTarget.isConnected) {
      return;
    }
    const physicalTopBelowTop = this._physicalTop > this._scrollTop;
    const physicalBottomAboveBottom = this._physicalBottom < this._scrollBottom;
    const firstIndexVisible = this.adjustedFirstVisibleIndex === 0;
    const lastIndexVisible = this.adjustedLastVisibleIndex === this.size - 1;
    if (physicalTopBelowTop && !firstIndexVisible || physicalBottomAboveBottom && !lastIndexVisible) {
      const isScrollingDown = physicalBottomAboveBottom;
      const originalRatio = this._ratio;
      this._ratio = 0;
      this._scrollPosition = this._scrollTop + (isScrollingDown ? -1 : 1);
      this._scrollHandler();
      this._ratio = originalRatio;
    }
  }
  /** @private */
  __onWheel(e13) {
    if (e13.ctrlKey || this._hasScrolledAncestor(e13.target, e13.deltaX, e13.deltaY)) {
      return;
    }
    let deltaY = e13.deltaY;
    if (e13.deltaMode === WheelEvent.DOM_DELTA_LINE) {
      deltaY *= this._scrollLineHeight;
    } else if (e13.deltaMode === WheelEvent.DOM_DELTA_PAGE) {
      deltaY *= this._scrollPageHeight;
    }
    if (!this._deltaYAcc) {
      this._deltaYAcc = 0;
    }
    if (this._wheelAnimationFrame) {
      this._deltaYAcc += deltaY;
      e13.preventDefault();
      return;
    }
    deltaY += this._deltaYAcc;
    this._deltaYAcc = 0;
    this._wheelAnimationFrame = true;
    this.__debouncerWheelAnimationFrame = Debouncer.debounce(
      this.__debouncerWheelAnimationFrame,
      animationFrame,
      () => {
        this._wheelAnimationFrame = false;
      }
    );
    const momentum = Math.abs(e13.deltaX) + Math.abs(deltaY);
    if (this._canScroll(this.scrollTarget, e13.deltaX, deltaY)) {
      e13.preventDefault();
      this.scrollTarget.scrollTop += deltaY;
      this.scrollTarget.scrollLeft += e13.deltaX;
      this._hasResidualMomentum = true;
      this._ignoreNewWheel = true;
      this._debouncerIgnoreNewWheel = Debouncer.debounce(
        this._debouncerIgnoreNewWheel,
        timeOut.after(this.timeouts.IGNORE_WHEEL),
        () => {
          this._ignoreNewWheel = false;
        }
      );
    } else if (this._hasResidualMomentum && momentum <= this._previousMomentum || this._ignoreNewWheel) {
      e13.preventDefault();
    } else if (momentum > this._previousMomentum) {
      this._hasResidualMomentum = false;
    }
    this._previousMomentum = momentum;
  }
  /**
   * Determines if the element has an ancestor that handles the scroll delta prior to this
   *
   * @private
   */
  _hasScrolledAncestor(el, deltaX, deltaY) {
    if (el === this.scrollTarget || el === this.scrollTarget.getRootNode().host) {
      return false;
    } else if (this._canScroll(el, deltaX, deltaY) && ["auto", "scroll"].indexOf(getComputedStyle(el).overflow) !== -1) {
      return true;
    } else if (el !== this && el.parentElement) {
      return this._hasScrolledAncestor(el.parentElement, deltaX, deltaY);
    }
  }
  _canScroll(el, deltaX, deltaY) {
    return deltaY > 0 && el.scrollTop < el.scrollHeight - el.offsetHeight || deltaY < 0 && el.scrollTop > 0 || deltaX > 0 && el.scrollLeft < el.scrollWidth - el.offsetWidth || deltaX < 0 && el.scrollLeft > 0;
  }
  /**
   * Increases the pool size.
   * @override
   */
  _increasePoolIfNeeded(count) {
    if (this._physicalCount > 2 && count) {
      const totalItemCount = Math.ceil(this._optPhysicalSize / this._physicalAverage);
      const missingItemCount = totalItemCount - this._physicalCount;
      super._increasePoolIfNeeded(Math.max(count, Math.min(100, missingItemCount)));
    } else {
      super._increasePoolIfNeeded(count);
    }
  }
  /**
   * An optimal physical size such that we will have enough physical items
   * to fill up the viewport and recycle when the user scrolls.
   *
   * This default value assumes that we will at least have the equivalent
   * to a viewport of physical items above and below the user's viewport.
   * @override
   */
  get _optPhysicalSize() {
    const optPhysicalSize = super._optPhysicalSize;
    if (optPhysicalSize <= 0 || this.__hasPlaceholders()) {
      return optPhysicalSize;
    }
    return optPhysicalSize + this.__getItemHeightBuffer();
  }
  /**
   * Extra item height buffer used when calculating optimal physical size.
   *
   * The iron list core uses the optimal physical size when determining whether to increase the item pool.
   * For the cases where some items are much larger than the average, the iron list core might not increase item pool.
   * This can lead to the large item not being rendered.
   *
   * @returns {Number} - Extra item height buffer
   * @private
   */
  __getItemHeightBuffer() {
    if (this._physicalCount === 0) {
      return 0;
    }
    const bufferZoneHeight = Math.ceil(this._viewportHeight * (this._maxPages - 1) / 2);
    const maxItemHeight = Math.max(...this._physicalSizes);
    if (maxItemHeight > Math.min(...this._physicalSizes)) {
      return Math.max(0, maxItemHeight - bufferZoneHeight);
    }
    return 0;
  }
  /**
   * @returns {Number|undefined} - The browser's default font-size in pixels
   * @private
   */
  _getScrollLineHeight() {
    const el = document.createElement("div");
    el.style.fontSize = "initial";
    el.style.display = "none";
    document.body.appendChild(el);
    const fontSize = window.getComputedStyle(el).fontSize;
    document.body.removeChild(el);
    return fontSize ? window.parseInt(fontSize) : void 0;
  }
  __getVisibleElements() {
    return Array.from(this.elementsContainer.children).filter((element) => !element.hidden);
  }
  /** @private */
  __reorderElements() {
    if (this.__mouseDown) {
      this.__pendingReorder = true;
      return;
    }
    this.__pendingReorder = false;
    const adjustedVirtualStart = this._virtualStart + (this._vidxOffset || 0);
    const visibleElements = this.__getVisibleElements();
    const targetElement = this.__getFocusedElement(visibleElements) || visibleElements[0];
    if (!targetElement) {
      return;
    }
    const targetPhysicalIndex = targetElement.__virtualIndex - adjustedVirtualStart;
    const delta = visibleElements.indexOf(targetElement) - targetPhysicalIndex;
    if (delta > 0) {
      for (let i11 = 0; i11 < delta; i11++) {
        this.elementsContainer.appendChild(visibleElements[i11]);
      }
    } else if (delta < 0) {
      for (let i11 = visibleElements.length + delta; i11 < visibleElements.length; i11++) {
        this.elementsContainer.insertBefore(visibleElements[i11], visibleElements[0]);
      }
    }
    if (isSafari) {
      const { transform } = this.scrollTarget.style;
      this.scrollTarget.style.transform = "translateZ(0)";
      setTimeout(() => {
        this.scrollTarget.style.transform = transform;
      });
    }
  }
  /** @private */
  _adjustVirtualIndexOffset(delta) {
    const maxOffset = this._maxVirtualIndexOffset;
    if (this._virtualCount >= this.size) {
      this._vidxOffset = 0;
    } else if (this.__skipNextVirtualIndexAdjust) {
      this.__skipNextVirtualIndexAdjust = false;
    } else if (Math.abs(delta) > 1e4) {
      const scale = this._scrollTop / (this.scrollTarget.scrollHeight - this.scrollTarget.clientHeight);
      this._vidxOffset = Math.round(scale * maxOffset);
    } else {
      const oldOffset = this._vidxOffset;
      const threshold = OFFSET_ADJUST_MIN_THRESHOLD;
      const maxShift = 100;
      if (this._scrollTop === 0) {
        this._vidxOffset = 0;
        if (oldOffset !== this._vidxOffset) {
          super.scrollToIndex(0);
        }
      } else if (this.firstVisibleIndex < threshold && this._vidxOffset > 0) {
        this._vidxOffset -= Math.min(this._vidxOffset, maxShift);
        super.scrollToIndex(this.firstVisibleIndex + (oldOffset - this._vidxOffset));
      }
      if (this._scrollTop >= this._maxScrollTop && this._maxScrollTop > 0) {
        this._vidxOffset = maxOffset;
        if (oldOffset !== this._vidxOffset) {
          super.scrollToIndex(this._virtualCount - 1);
        }
      } else if (this.firstVisibleIndex > this._virtualCount - threshold && this._vidxOffset < maxOffset) {
        this._vidxOffset += Math.min(maxOffset - this._vidxOffset, maxShift);
        super.scrollToIndex(this.firstVisibleIndex - (this._vidxOffset - oldOffset));
      }
    }
  }
};
Object.setPrototypeOf(IronListAdapter.prototype, ironList);

// node_modules/@vaadin/component-base/src/virtualizer.js
var Virtualizer = class {
  /**
   * @typedef {Object} VirtualizerConfig
   * @property {Function} createElements Function that returns the given number of new elements
   * @property {Function} updateElement Function that updates the element at a specific index
   * @property {HTMLElement} scrollTarget Reference to the scrolling element
   * @property {HTMLElement} scrollContainer Reference to a wrapper for the item elements (or a slot) inside the scrollTarget
   * @property {HTMLElement | undefined} elementsContainer Reference to the container in which the item elements are placed, defaults to scrollContainer
   * @property {boolean | undefined} reorderElements Determines whether the physical item elements should be kept in order in the DOM
   * @param {VirtualizerConfig} config Configuration for the virtualizer
   */
  constructor(config) {
    this.__adapter = new IronListAdapter(config);
  }
  /**
   * Gets the index of the first visible item in the viewport.
   *
   * @return {number}
   */
  get firstVisibleIndex() {
    return this.__adapter.adjustedFirstVisibleIndex;
  }
  /**
   * Gets the index of the last visible item in the viewport.
   *
   * @return {number}
   */
  get lastVisibleIndex() {
    return this.__adapter.adjustedLastVisibleIndex;
  }
  /**
   * The size of the virtualizer
   * @return {number | undefined} The size of the virtualizer
   */
  get size() {
    return this.__adapter.size;
  }
  /**
   * The size of the virtualizer
   * @param {number} size The size of the virtualizer
   */
  set size(size) {
    this.__adapter.size = size;
  }
  /**
   * Scroll to a specific index in the virtual list
   *
   * @method scrollToIndex
   * @param {number} index The index of the item
   */
  scrollToIndex(index) {
    this.__adapter.scrollToIndex(index);
  }
  /**
   * Requests the virtualizer to re-render the item elements on an index range, if currently in the DOM
   *
   * @method update
   * @param {number | undefined} startIndex The start index of the range
   * @param {number | undefined} endIndex The end index of the range
   */
  update(startIndex = 0, endIndex = this.size - 1) {
    this.__adapter.update(startIndex, endIndex);
  }
  /**
   * Flushes active asynchronous tasks so that the component and the DOM end up in a stable state
   *
   * @method update
   * @param {number | undefined} startIndex The start index of the range
   * @param {number | undefined} endIndex The end index of the range
   */
  flush() {
    this.__adapter.flush();
  }
  /**
   * Notifies the virtualizer about its host element connected to the DOM.
   *
   * @method hostConnected
   */
  hostConnected() {
    this.__adapter.hostConnected();
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-a11y-mixin.js
var A11yMixin = (superClass) => class A11yMixin extends superClass {
  static get properties() {
    return {
      /**
       * String used to label the grid to screen reader users.
       * @attr {string} accessible-name
       */
      accessibleName: {
        type: String
      }
    };
  }
  static get observers() {
    return ["_a11yUpdateGridSize(size, _columnTree)"];
  }
  /** @private */
  _a11yGetHeaderRowCount(_columnTree) {
    return _columnTree.filter(
      (level) => level.some((col) => col.headerRenderer || col.path && col.header !== null || col.header)
    ).length;
  }
  /** @private */
  _a11yGetFooterRowCount(_columnTree) {
    return _columnTree.filter((level) => level.some((col) => col.headerRenderer)).length;
  }
  /** @private */
  _a11yUpdateGridSize(size, _columnTree) {
    if (size === void 0 || _columnTree === void 0) {
      return;
    }
    const bodyColumns = _columnTree[_columnTree.length - 1];
    this.$.table.setAttribute(
      "aria-rowcount",
      size + this._a11yGetHeaderRowCount(_columnTree) + this._a11yGetFooterRowCount(_columnTree)
    );
    this.$.table.setAttribute("aria-colcount", bodyColumns && bodyColumns.length || 0);
    this._a11yUpdateHeaderRows();
    this._a11yUpdateFooterRows();
  }
  /** @protected */
  _a11yUpdateHeaderRows() {
    iterateChildren(this.$.header, (headerRow, index) => {
      headerRow.setAttribute("aria-rowindex", index + 1);
    });
  }
  /** @protected */
  _a11yUpdateFooterRows() {
    iterateChildren(this.$.footer, (footerRow, index) => {
      footerRow.setAttribute("aria-rowindex", this._a11yGetHeaderRowCount(this._columnTree) + this.size + index + 1);
    });
  }
  /**
   * @param {!HTMLElement} row
   * @param {number} index
   * @protected
   */
  _a11yUpdateRowRowindex(row, index) {
    row.setAttribute("aria-rowindex", index + this._a11yGetHeaderRowCount(this._columnTree) + 1);
  }
  /**
   * @param {!HTMLElement} row
   * @param {boolean} selected
   * @protected
   */
  _a11yUpdateRowSelected(row, selected) {
    row.setAttribute("aria-selected", Boolean(selected));
    iterateRowCells(row, (cell) => {
      cell.setAttribute("aria-selected", Boolean(selected));
    });
  }
  /**
   * @param {!HTMLElement} row
   * @protected
   */
  _a11yUpdateRowExpanded(row) {
    if (this.__isRowExpandable(row)) {
      row.setAttribute("aria-expanded", "false");
    } else if (this.__isRowCollapsible(row)) {
      row.setAttribute("aria-expanded", "true");
    } else {
      row.removeAttribute("aria-expanded");
    }
  }
  /**
   * @param {!HTMLElement} row
   * @param {number} level
   * @protected
   */
  _a11yUpdateRowLevel(row, level) {
    if (level > 0 || this.__isRowCollapsible(row) || this.__isRowExpandable(row)) {
      row.setAttribute("aria-level", level + 1);
    } else {
      row.removeAttribute("aria-level");
    }
  }
  /**
   * @param {!HTMLElement} row
   * @param {!HTMLElement} detailsCell
   * @protected
   */
  _a11ySetRowDetailsCell(row, detailsCell) {
    iterateRowCells(row, (cell) => {
      if (cell !== detailsCell) {
        cell.setAttribute("aria-controls", detailsCell.id);
      }
    });
  }
  /**
   * @param {!HTMLElement} row
   * @param {number} colspan
   * @protected
   */
  _a11yUpdateCellColspan(cell, colspan) {
    cell.setAttribute("aria-colspan", Number(colspan));
  }
  /** @protected */
  _a11yUpdateSorters() {
    Array.from(this.querySelectorAll("vaadin-grid-sorter")).forEach((sorter) => {
      let cellContent = sorter.parentNode;
      while (cellContent && cellContent.localName !== "vaadin-grid-cell-content") {
        cellContent = cellContent.parentNode;
      }
      if (cellContent && cellContent.assignedSlot) {
        const cell = cellContent.assignedSlot.parentNode;
        cell.setAttribute(
          "aria-sort",
          {
            asc: "ascending",
            desc: "descending"
          }[String(sorter.direction)] || "none"
        );
      }
    });
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-active-item-mixin.js
var isFocusable = (target) => {
  return target.offsetParent && !target.part.contains("body-cell") && isElementFocusable(target) && getComputedStyle(target).visibility !== "hidden";
};
var ActiveItemMixin = (superClass) => class ActiveItemMixin extends superClass {
  static get properties() {
    return {
      /**
       * The item user has last interacted with. Turns to `null` after user deactivates
       * the item by re-interacting with the currently active item.
       * @type {GridItem}
       */
      activeItem: {
        type: Object,
        notify: true,
        value: null,
        sync: true
      }
    };
  }
  /** @protected */
  ready() {
    super.ready();
    this.$.scroller.addEventListener("click", this._onClick.bind(this));
    this.addEventListener("cell-activate", this._activateItem.bind(this));
    this.addEventListener("row-activate", this._activateItem.bind(this));
  }
  /** @private */
  _activateItem(e13) {
    const model = e13.detail.model;
    const clickedItem = model ? model.item : null;
    if (clickedItem) {
      this.activeItem = !this._itemsEqual(this.activeItem, clickedItem) ? clickedItem : null;
    }
  }
  /**
   * Checks whether the click event should not activate the cell on which it occurred.
   *
   * @protected
   */
  _shouldPreventCellActivationOnClick(e13) {
    const { cell } = this._getGridEventLocation(e13);
    return (
      // Something has handled this click already, e. g., <vaadin-grid-sorter>
      e13.defaultPrevented || // No clicked cell available
      !cell || // Cell is a details cell
      cell.getAttribute("part").includes("details-cell") || // Cell is the empty state cell
      cell === this.$.emptystatecell || // Cell content is focused
      cell._content.contains(this.getRootNode().activeElement) || // Clicked on a focusable element
      this._isFocusable(e13.target) || // Clicked on a label element
      e13.target instanceof HTMLLabelElement
    );
  }
  /**
   * @param {!MouseEvent} e
   * @protected
   */
  _onClick(e13) {
    if (this._shouldPreventCellActivationOnClick(e13)) {
      return;
    }
    const { cell } = this._getGridEventLocation(e13);
    if (cell) {
      this.dispatchEvent(
        new CustomEvent("cell-activate", {
          detail: {
            model: this.__getRowModel(cell.parentElement)
          }
        })
      );
    }
  }
  /**
   * @param {!Element} target
   * @return {boolean}
   * @protected
   */
  _isFocusable(target) {
    return isFocusable(target);
  }
  /**
   * Fired when the `activeItem` property changes.
   *
   * @event active-item-changed
   */
  /**
   * Fired when the cell is activated with click or keyboard.
   *
   * @event cell-activate
   */
};

// node_modules/@vaadin/grid/src/array-data-provider.js
function get3(path, object) {
  return path.split(".").reduce((obj, property) => obj[property], object);
}
function checkPaths(arrayToCheck, action, items) {
  if (items.length === 0) {
    return false;
  }
  let result = true;
  arrayToCheck.forEach(({ path }) => {
    if (!path || path.indexOf(".") === -1) {
      return;
    }
    const parentProperty = path.replace(/\.[^.]*$/u, "");
    if (get3(parentProperty, items[0]) === void 0) {
      console.warn(`Path "${path}" used for ${action} does not exist in all of the items, ${action} is disabled.`);
      result = false;
    }
  });
  return result;
}
function normalizeEmptyValue(value) {
  if ([void 0, null].indexOf(value) >= 0) {
    return "";
  } else if (isNaN(value)) {
    return value.toString();
  }
  return value;
}
function compare(a17, b5) {
  a17 = normalizeEmptyValue(a17);
  b5 = normalizeEmptyValue(b5);
  if (a17 < b5) {
    return -1;
  }
  if (a17 > b5) {
    return 1;
  }
  return 0;
}
function multiSort(items, sortOrders) {
  return items.sort((a17, b5) => {
    return sortOrders.map((sortOrder) => {
      if (sortOrder.direction === "asc") {
        return compare(get3(sortOrder.path, a17), get3(sortOrder.path, b5));
      } else if (sortOrder.direction === "desc") {
        return compare(get3(sortOrder.path, b5), get3(sortOrder.path, a17));
      }
      return 0;
    }).reduce((p14, n17) => {
      return p14 !== 0 ? p14 : n17;
    }, 0);
  });
}
function filter(items, filters) {
  return items.filter((item) => {
    return filters.every((filter2) => {
      const value = normalizeEmptyValue(get3(filter2.path, item));
      const filterValueLowercase = normalizeEmptyValue(filter2.value).toString().toLowerCase();
      return value.toString().toLowerCase().includes(filterValueLowercase);
    });
  });
}
var createArrayDataProvider = (allItems) => {
  return (params, callback) => {
    let items = allItems ? [...allItems] : [];
    if (params.filters && checkPaths(params.filters, "filtering", items)) {
      items = filter(items, params.filters);
    }
    if (Array.isArray(params.sortOrders) && params.sortOrders.length && checkPaths(params.sortOrders, "sorting", items)) {
      items = multiSort(items, params.sortOrders);
    }
    const count = Math.min(items.length, params.pageSize);
    const start = params.page * count;
    const end = start + count;
    const slice = items.slice(start, end);
    callback(slice, items.length);
  };
};

// node_modules/@vaadin/grid/src/vaadin-grid-array-data-provider-mixin.js
var ArrayDataProviderMixin = (superClass) => class ArrayDataProviderMixin extends superClass {
  static get properties() {
    return {
      /**
       * An array containing the items which will be passed to renderer functions.
       *
       * @type {Array<!GridItem> | undefined}
       */
      items: {
        type: Array,
        sync: true
      }
    };
  }
  static get observers() {
    return ["__dataProviderOrItemsChanged(dataProvider, items, isAttached, items.*)"];
  }
  /** @private */
  __setArrayDataProvider(items) {
    const arrayDataProvider = createArrayDataProvider(this.items, {});
    arrayDataProvider.__items = items;
    this._arrayDataProvider = arrayDataProvider;
    this.size = items.length;
    this.dataProvider = arrayDataProvider;
  }
  /**
   * @override
   * @protected
   */
  _onDataProviderPageReceived() {
    super._onDataProviderPageReceived();
    if (this._arrayDataProvider) {
      this.size = this._flatSize;
    }
  }
  /** @private */
  __dataProviderOrItemsChanged(dataProvider, items, isAttached) {
    if (!isAttached) {
      return;
    }
    if (this._arrayDataProvider) {
      if (dataProvider !== this._arrayDataProvider) {
        this._arrayDataProvider = void 0;
        this.items = void 0;
      } else if (!items) {
        this._arrayDataProvider = void 0;
        this.dataProvider = void 0;
        this.size = 0;
        this.clearCache();
      } else if (this._arrayDataProvider.__items === items) {
        this.clearCache();
      } else {
        this.__setArrayDataProvider(items);
      }
    } else if (items) {
      this.__setArrayDataProvider(items);
    }
  }
};

// node_modules/@vaadin/component-base/src/gestures.js
var passiveTouchGestures2 = false;
var wrap2 = (node) => node;
var HAS_NATIVE_TA = typeof document.head.style.touchAction === "string";
var GESTURE_KEY = "__polymerGestures";
var HANDLED_OBJ = "__polymerGesturesHandled";
var TOUCH_ACTION = "__polymerGesturesTouchAction";
var TAP_DISTANCE = 25;
var TRACK_DISTANCE = 5;
var TRACK_LENGTH = 2;
var MOUSE_EVENTS = ["mousedown", "mousemove", "mouseup", "click"];
var MOUSE_WHICH_TO_BUTTONS = [0, 1, 4, 2];
var MOUSE_HAS_BUTTONS = function() {
  try {
    return new MouseEvent("test", { buttons: 1 }).buttons === 1;
  } catch (_2) {
    return false;
  }
}();
function isMouseEvent(name) {
  return MOUSE_EVENTS.indexOf(name) > -1;
}
var supportsPassive = false;
(function() {
  try {
    const opts = Object.defineProperty({}, "passive", {
      // eslint-disable-next-line getter-return
      get() {
        supportsPassive = true;
      }
    });
    window.addEventListener("test", null, opts);
    window.removeEventListener("test", null, opts);
  } catch (_2) {
  }
})();
function PASSIVE_TOUCH(eventName) {
  if (isMouseEvent(eventName) || eventName === "touchend") {
    return;
  }
  if (HAS_NATIVE_TA && supportsPassive && passiveTouchGestures2) {
    return { passive: true };
  }
}
var IS_TOUCH_ONLY = navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/u);
var canBeDisabled = {
  button: true,
  command: true,
  fieldset: true,
  input: true,
  keygen: true,
  optgroup: true,
  option: true,
  select: true,
  textarea: true
};
function hasLeftMouseButton(ev) {
  const type = ev.type;
  if (!isMouseEvent(type)) {
    return false;
  }
  if (type === "mousemove") {
    let buttons = ev.buttons === void 0 ? 1 : ev.buttons;
    if (ev instanceof window.MouseEvent && !MOUSE_HAS_BUTTONS) {
      buttons = MOUSE_WHICH_TO_BUTTONS[ev.which] || 0;
    }
    return Boolean(buttons & 1);
  }
  const button = ev.button === void 0 ? 0 : ev.button;
  return button === 0;
}
function isSyntheticClick(ev) {
  if (ev.type === "click") {
    if (ev.detail === 0) {
      return true;
    }
    const t3 = _findOriginalTarget(ev);
    if (!t3.nodeType || /** @type {Element} */
    t3.nodeType !== Node.ELEMENT_NODE) {
      return true;
    }
    const bcr = (
      /** @type {Element} */
      t3.getBoundingClientRect()
    );
    const x2 = ev.pageX, y5 = ev.pageY;
    return !(x2 >= bcr.left && x2 <= bcr.right && y5 >= bcr.top && y5 <= bcr.bottom);
  }
  return false;
}
var POINTERSTATE = {
  mouse: {
    target: null,
    mouseIgnoreJob: null
  },
  touch: {
    x: 0,
    y: 0,
    id: -1,
    scrollDecided: false
  }
};
function firstTouchAction(ev) {
  let ta = "auto";
  const path = getComposedPath(ev);
  for (let i11 = 0, n17; i11 < path.length; i11++) {
    n17 = path[i11];
    if (n17[TOUCH_ACTION]) {
      ta = n17[TOUCH_ACTION];
      break;
    }
  }
  return ta;
}
function trackDocument(stateObj, movefn, upfn) {
  stateObj.movefn = movefn;
  stateObj.upfn = upfn;
  document.addEventListener("mousemove", movefn);
  document.addEventListener("mouseup", upfn);
}
function untrackDocument(stateObj) {
  document.removeEventListener("mousemove", stateObj.movefn);
  document.removeEventListener("mouseup", stateObj.upfn);
  stateObj.movefn = null;
  stateObj.upfn = null;
}
var getComposedPath = window.ShadyDOM && window.ShadyDOM.noPatch ? window.ShadyDOM.composedPath : (event) => event.composedPath && event.composedPath() || [];
var gestures = {};
var recognizers = [];
function deepTargetFind(x2, y5) {
  let node = document.elementFromPoint(x2, y5);
  let next = node;
  while (next && next.shadowRoot && !window.ShadyDOM) {
    const oldNext = next;
    next = next.shadowRoot.elementFromPoint(x2, y5);
    if (oldNext === next) {
      break;
    }
    if (next) {
      node = next;
    }
  }
  return node;
}
function _findOriginalTarget(ev) {
  const path = getComposedPath(
    /** @type {?Event} */
    ev
  );
  return path.length > 0 ? path[0] : ev.target;
}
function _handleNative(ev) {
  const type = ev.type;
  const node = ev.currentTarget;
  const gobj = node[GESTURE_KEY];
  if (!gobj) {
    return;
  }
  const gs = gobj[type];
  if (!gs) {
    return;
  }
  if (!ev[HANDLED_OBJ]) {
    ev[HANDLED_OBJ] = {};
    if (type.startsWith("touch")) {
      const t3 = ev.changedTouches[0];
      if (type === "touchstart") {
        if (ev.touches.length === 1) {
          POINTERSTATE.touch.id = t3.identifier;
        }
      }
      if (POINTERSTATE.touch.id !== t3.identifier) {
        return;
      }
      if (!HAS_NATIVE_TA) {
        if (type === "touchstart" || type === "touchmove") {
          _handleTouchAction(ev);
        }
      }
    }
  }
  const handled = ev[HANDLED_OBJ];
  if (handled.skip) {
    return;
  }
  for (let i11 = 0, r10; i11 < recognizers.length; i11++) {
    r10 = recognizers[i11];
    if (gs[r10.name] && !handled[r10.name]) {
      if (r10.flow && r10.flow.start.indexOf(ev.type) > -1 && r10.reset) {
        r10.reset();
      }
    }
  }
  for (let i11 = 0, r10; i11 < recognizers.length; i11++) {
    r10 = recognizers[i11];
    if (gs[r10.name] && !handled[r10.name]) {
      handled[r10.name] = true;
      r10[type](ev);
    }
  }
}
function _handleTouchAction(ev) {
  const t3 = ev.changedTouches[0];
  const type = ev.type;
  if (type === "touchstart") {
    POINTERSTATE.touch.x = t3.clientX;
    POINTERSTATE.touch.y = t3.clientY;
    POINTERSTATE.touch.scrollDecided = false;
  } else if (type === "touchmove") {
    if (POINTERSTATE.touch.scrollDecided) {
      return;
    }
    POINTERSTATE.touch.scrollDecided = true;
    const ta = firstTouchAction(ev);
    let shouldPrevent = false;
    const dx = Math.abs(POINTERSTATE.touch.x - t3.clientX);
    const dy = Math.abs(POINTERSTATE.touch.y - t3.clientY);
    if (!ev.cancelable) {
    } else if (ta === "none") {
      shouldPrevent = true;
    } else if (ta === "pan-x") {
      shouldPrevent = dy > dx;
    } else if (ta === "pan-y") {
      shouldPrevent = dx > dy;
    }
    if (shouldPrevent) {
      ev.preventDefault();
    } else {
      prevent("track");
    }
  }
}
function addListener(node, evType, handler) {
  if (gestures[evType]) {
    _add(node, evType, handler);
    return true;
  }
  return false;
}
function _add(node, evType, handler) {
  const recognizer = gestures[evType];
  const deps = recognizer.deps;
  const name = recognizer.name;
  let gobj = node[GESTURE_KEY];
  if (!gobj) {
    node[GESTURE_KEY] = gobj = {};
  }
  for (let i11 = 0, dep, gd; i11 < deps.length; i11++) {
    dep = deps[i11];
    if (IS_TOUCH_ONLY && isMouseEvent(dep) && dep !== "click") {
      continue;
    }
    gd = gobj[dep];
    if (!gd) {
      gobj[dep] = gd = { _count: 0 };
    }
    if (gd._count === 0) {
      node.addEventListener(dep, _handleNative, PASSIVE_TOUCH(dep));
    }
    gd[name] = (gd[name] || 0) + 1;
    gd._count = (gd._count || 0) + 1;
  }
  node.addEventListener(evType, handler);
  if (recognizer.touchAction) {
    setTouchAction(node, recognizer.touchAction);
  }
}
function register2(recog) {
  recognizers.push(recog);
  recog.emits.forEach((emit) => {
    gestures[emit] = recog;
  });
}
function _findRecognizerByEvent(evName) {
  for (let i11 = 0, r10; i11 < recognizers.length; i11++) {
    r10 = recognizers[i11];
    for (let j4 = 0, n17; j4 < r10.emits.length; j4++) {
      n17 = r10.emits[j4];
      if (n17 === evName) {
        return r10;
      }
    }
  }
  return null;
}
function setTouchAction(node, value) {
  if (HAS_NATIVE_TA && node instanceof HTMLElement) {
    microTask2.run(() => {
      node.style.touchAction = value;
    });
  }
  node[TOUCH_ACTION] = value;
}
function _fire(target, type, detail) {
  const ev = new Event(type, { bubbles: true, cancelable: true, composed: true });
  ev.detail = detail;
  wrap2(
    /** @type {!Node} */
    target
  ).dispatchEvent(ev);
  if (ev.defaultPrevented) {
    const preventer = detail.preventer || detail.sourceEvent;
    if (preventer && preventer.preventDefault) {
      preventer.preventDefault();
    }
  }
}
function prevent(evName) {
  const recognizer = _findRecognizerByEvent(evName);
  if (recognizer.info) {
    recognizer.info.prevent = true;
  }
}
register2({
  name: "downup",
  deps: ["mousedown", "touchstart", "touchend"],
  flow: {
    start: ["mousedown", "touchstart"],
    end: ["mouseup", "touchend"]
  },
  emits: ["down", "up"],
  info: {
    movefn: null,
    upfn: null
  },
  /**
   * @this {GestureRecognizer}
   * @return {void}
   */
  reset() {
    untrackDocument(this.info);
  },
  /**
   * @this {GestureRecognizer}
   * @param {MouseEvent} e
   * @return {void}
   */
  mousedown(e13) {
    if (!hasLeftMouseButton(e13)) {
      return;
    }
    const t3 = _findOriginalTarget(e13);
    const self = this;
    const movefn = (e14) => {
      if (!hasLeftMouseButton(e14)) {
        downupFire("up", t3, e14);
        untrackDocument(self.info);
      }
    };
    const upfn = (e14) => {
      if (hasLeftMouseButton(e14)) {
        downupFire("up", t3, e14);
      }
      untrackDocument(self.info);
    };
    trackDocument(this.info, movefn, upfn);
    downupFire("down", t3, e13);
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchstart(e13) {
    downupFire("down", _findOriginalTarget(e13), e13.changedTouches[0], e13);
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchend(e13) {
    downupFire("up", _findOriginalTarget(e13), e13.changedTouches[0], e13);
  }
});
function downupFire(type, target, event, preventer) {
  if (!target) {
    return;
  }
  _fire(target, type, {
    x: event.clientX,
    y: event.clientY,
    sourceEvent: event,
    preventer,
    prevent(e13) {
      return prevent(e13);
    }
  });
}
register2({
  name: "track",
  touchAction: "none",
  deps: ["mousedown", "touchstart", "touchmove", "touchend"],
  flow: {
    start: ["mousedown", "touchstart"],
    end: ["mouseup", "touchend"]
  },
  emits: ["track"],
  info: {
    x: 0,
    y: 0,
    state: "start",
    started: false,
    moves: [],
    /** @this {GestureInfo} */
    addMove(move) {
      if (this.moves.length > TRACK_LENGTH) {
        this.moves.shift();
      }
      this.moves.push(move);
    },
    movefn: null,
    upfn: null,
    prevent: false
  },
  /**
   * @this {GestureRecognizer}
   * @return {void}
   */
  reset() {
    this.info.state = "start";
    this.info.started = false;
    this.info.moves = [];
    this.info.x = 0;
    this.info.y = 0;
    this.info.prevent = false;
    untrackDocument(this.info);
  },
  /**
   * @this {GestureRecognizer}
   * @param {MouseEvent} e
   * @return {void}
   */
  mousedown(e13) {
    if (!hasLeftMouseButton(e13)) {
      return;
    }
    const t3 = _findOriginalTarget(e13);
    const self = this;
    const movefn = (e14) => {
      const x2 = e14.clientX, y5 = e14.clientY;
      if (trackHasMovedEnough(self.info, x2, y5)) {
        self.info.state = self.info.started ? e14.type === "mouseup" ? "end" : "track" : "start";
        if (self.info.state === "start") {
          prevent("tap");
        }
        self.info.addMove({ x: x2, y: y5 });
        if (!hasLeftMouseButton(e14)) {
          self.info.state = "end";
          untrackDocument(self.info);
        }
        if (t3) {
          trackFire(self.info, t3, e14);
        }
        self.info.started = true;
      }
    };
    const upfn = (e14) => {
      if (self.info.started) {
        movefn(e14);
      }
      untrackDocument(self.info);
    };
    trackDocument(this.info, movefn, upfn);
    this.info.x = e13.clientX;
    this.info.y = e13.clientY;
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchstart(e13) {
    const ct2 = e13.changedTouches[0];
    this.info.x = ct2.clientX;
    this.info.y = ct2.clientY;
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchmove(e13) {
    const t3 = _findOriginalTarget(e13);
    const ct2 = e13.changedTouches[0];
    const x2 = ct2.clientX, y5 = ct2.clientY;
    if (trackHasMovedEnough(this.info, x2, y5)) {
      if (this.info.state === "start") {
        prevent("tap");
      }
      this.info.addMove({ x: x2, y: y5 });
      trackFire(this.info, t3, ct2);
      this.info.state = "track";
      this.info.started = true;
    }
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchend(e13) {
    const t3 = _findOriginalTarget(e13);
    const ct2 = e13.changedTouches[0];
    if (this.info.started) {
      this.info.state = "end";
      this.info.addMove({ x: ct2.clientX, y: ct2.clientY });
      trackFire(this.info, t3, ct2);
    }
  }
});
function trackHasMovedEnough(info, x2, y5) {
  if (info.prevent) {
    return false;
  }
  if (info.started) {
    return true;
  }
  const dx = Math.abs(info.x - x2);
  const dy = Math.abs(info.y - y5);
  return dx >= TRACK_DISTANCE || dy >= TRACK_DISTANCE;
}
function trackFire(info, target, touch) {
  if (!target) {
    return;
  }
  const secondlast = info.moves[info.moves.length - 2];
  const lastmove = info.moves[info.moves.length - 1];
  const dx = lastmove.x - info.x;
  const dy = lastmove.y - info.y;
  let ddx, ddy = 0;
  if (secondlast) {
    ddx = lastmove.x - secondlast.x;
    ddy = lastmove.y - secondlast.y;
  }
  _fire(target, "track", {
    state: info.state,
    x: touch.clientX,
    y: touch.clientY,
    dx,
    dy,
    ddx,
    ddy,
    sourceEvent: touch,
    hover() {
      return deepTargetFind(touch.clientX, touch.clientY);
    }
  });
}
register2({
  name: "tap",
  deps: ["mousedown", "click", "touchstart", "touchend"],
  flow: {
    start: ["mousedown", "touchstart"],
    end: ["click", "touchend"]
  },
  emits: ["tap"],
  info: {
    x: NaN,
    y: NaN,
    prevent: false
  },
  /**
   * @this {GestureRecognizer}
   * @return {void}
   */
  reset() {
    this.info.x = NaN;
    this.info.y = NaN;
    this.info.prevent = false;
  },
  /**
   * @this {GestureRecognizer}
   * @param {MouseEvent} e
   * @return {void}
   */
  mousedown(e13) {
    if (hasLeftMouseButton(e13)) {
      this.info.x = e13.clientX;
      this.info.y = e13.clientY;
    }
  },
  /**
   * @this {GestureRecognizer}
   * @param {MouseEvent} e
   * @return {void}
   */
  click(e13) {
    if (hasLeftMouseButton(e13)) {
      trackForward(this.info, e13);
    }
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchstart(e13) {
    const touch = e13.changedTouches[0];
    this.info.x = touch.clientX;
    this.info.y = touch.clientY;
  },
  /**
   * @this {GestureRecognizer}
   * @param {TouchEvent} e
   * @return {void}
   */
  touchend(e13) {
    trackForward(this.info, e13.changedTouches[0], e13);
  }
});
function trackForward(info, e13, preventer) {
  const dx = Math.abs(e13.clientX - info.x);
  const dy = Math.abs(e13.clientY - info.y);
  const t3 = _findOriginalTarget(preventer || e13);
  if (!t3 || canBeDisabled[
    /** @type {!HTMLElement} */
    t3.localName
  ] && t3.hasAttribute("disabled")) {
    return;
  }
  if (isNaN(dx) || isNaN(dy) || dx <= TAP_DISTANCE && dy <= TAP_DISTANCE || isSyntheticClick(e13)) {
    if (!info.prevent) {
      _fire(t3, "tap", {
        x: e13.clientX,
        y: e13.clientY,
        sourceEvent: e13,
        preventer
      });
    }
  }
}

// node_modules/@vaadin/grid/src/vaadin-grid-column-reordering-mixin.js
var ColumnReorderingMixin = (superClass) => class ColumnReorderingMixin extends superClass {
  static get properties() {
    return {
      /**
       * Set to true to allow column reordering.
       * @attr {boolean} column-reordering-allowed
       * @type {boolean}
       */
      columnReorderingAllowed: {
        type: Boolean,
        value: false
      },
      /** @private */
      _orderBaseScope: {
        type: Number,
        value: 1e7
      }
    };
  }
  static get observers() {
    return ["_updateOrders(_columnTree)"];
  }
  /** @protected */
  ready() {
    super.ready();
    addListener(this, "track", this._onTrackEvent);
    this._reorderGhost = this.shadowRoot.querySelector('[part="reorder-ghost"]');
    this.addEventListener("touchstart", this._onTouchStart.bind(this));
    this.addEventListener("touchmove", this._onTouchMove.bind(this));
    this.addEventListener("touchend", this._onTouchEnd.bind(this));
    this.addEventListener("contextmenu", this._onContextMenu.bind(this));
  }
  /** @private */
  _onContextMenu(e13) {
    if (this.hasAttribute("reordering")) {
      e13.preventDefault();
      if (!isTouch) {
        this._onTrackEnd();
      }
    }
  }
  /** @private */
  _onTouchStart(e13) {
    this._startTouchReorderTimeout = setTimeout(() => {
      this._onTrackStart({
        detail: {
          x: e13.touches[0].clientX,
          y: e13.touches[0].clientY
        }
      });
    }, 100);
  }
  /** @private */
  _onTouchMove(e13) {
    if (this._draggedColumn) {
      e13.preventDefault();
    }
    clearTimeout(this._startTouchReorderTimeout);
  }
  /** @private */
  _onTouchEnd() {
    clearTimeout(this._startTouchReorderTimeout);
    this._onTrackEnd();
  }
  /** @private */
  _onTrackEvent(e13) {
    if (e13.detail.state === "start") {
      const path = e13.composedPath();
      const headerCell = path[path.indexOf(this.$.header) - 2];
      if (!headerCell || !headerCell._content) {
        return;
      }
      if (headerCell._content.contains(this.getRootNode().activeElement)) {
        return;
      }
      if (this.$.scroller.hasAttribute("column-resizing")) {
        return;
      }
      if (!this._touchDevice) {
        this._onTrackStart(e13);
      }
    } else if (e13.detail.state === "track") {
      this._onTrack(e13);
    } else if (e13.detail.state === "end") {
      this._onTrackEnd(e13);
    }
  }
  /** @private */
  _onTrackStart(e13) {
    if (!this.columnReorderingAllowed) {
      return;
    }
    const path = e13.composedPath && e13.composedPath();
    if (path && path.some((node) => node.hasAttribute && node.hasAttribute("draggable"))) {
      return;
    }
    const headerCell = this._cellFromPoint(e13.detail.x, e13.detail.y);
    if (!headerCell || !headerCell.getAttribute("part").includes("header-cell")) {
      return;
    }
    this.toggleAttribute("reordering", true);
    this._draggedColumn = headerCell._column;
    while (this._draggedColumn.parentElement.childElementCount === 1) {
      this._draggedColumn = this._draggedColumn.parentElement;
    }
    this._setSiblingsReorderStatus(this._draggedColumn, "allowed");
    this._draggedColumn._reorderStatus = "dragging";
    this._updateGhost(headerCell);
    this._reorderGhost.style.visibility = "visible";
    this._updateGhostPosition(e13.detail.x, this._touchDevice ? e13.detail.y - 50 : e13.detail.y);
    this._autoScroller();
  }
  /** @private */
  _onTrack(e13) {
    if (!this._draggedColumn) {
      return;
    }
    const targetCell = this._cellFromPoint(e13.detail.x, e13.detail.y);
    if (!targetCell) {
      return;
    }
    const targetColumn = this._getTargetColumn(targetCell, this._draggedColumn);
    if (this._isSwapAllowed(this._draggedColumn, targetColumn) && this._isSwappableByPosition(targetColumn, e13.detail.x)) {
      const columnTreeLevel = this._columnTree.findIndex((level) => level.includes(targetColumn));
      const levelColumnsInOrder = this._getColumnsInOrder(columnTreeLevel);
      const startIndex = levelColumnsInOrder.indexOf(this._draggedColumn);
      const endIndex = levelColumnsInOrder.indexOf(targetColumn);
      const direction = startIndex < endIndex ? 1 : -1;
      for (let i11 = startIndex; i11 !== endIndex; i11 += direction) {
        this._swapColumnOrders(this._draggedColumn, levelColumnsInOrder[i11 + direction]);
      }
    }
    this._updateGhostPosition(e13.detail.x, this._touchDevice ? e13.detail.y - 50 : e13.detail.y);
    this._lastDragClientX = e13.detail.x;
  }
  /** @private */
  _onTrackEnd() {
    if (!this._draggedColumn) {
      return;
    }
    this.toggleAttribute("reordering", false);
    this._draggedColumn._reorderStatus = "";
    this._setSiblingsReorderStatus(this._draggedColumn, "");
    this._draggedColumn = null;
    this._lastDragClientX = null;
    this._reorderGhost.style.visibility = "hidden";
    this.dispatchEvent(
      new CustomEvent("column-reorder", {
        detail: {
          columns: this._getColumnsInOrder()
        }
      })
    );
  }
  /**
   * Returns the columns (or column groups) on the specified header level in visual order.
   * By default, the bottom level is used.
   *
   * @return {!Array<!GridColumn>}
   * @protected
   */
  _getColumnsInOrder(headerLevel = this._columnTree.length - 1) {
    return this._columnTree[headerLevel].filter((c13) => !c13.hidden).sort((b5, a17) => b5._order - a17._order);
  }
  /**
   * @param {number} x
   * @param {number} y
   * @return {HTMLElement | undefined}
   * @protected
   */
  _cellFromPoint(x2 = 0, y5 = 0) {
    if (!this._draggedColumn) {
      this.$.scroller.toggleAttribute("no-content-pointer-events", true);
    }
    const elementFromPoint = this.shadowRoot.elementFromPoint(x2, y5);
    this.$.scroller.toggleAttribute("no-content-pointer-events", false);
    return this._getCellFromElement(elementFromPoint);
  }
  /** @private */
  _getCellFromElement(element) {
    if (element) {
      if (element._column) {
        return element;
      }
      const { parentElement } = element;
      if (parentElement && parentElement._focusButton === element) {
        return parentElement;
      }
    }
    return null;
  }
  /**
   * @param {number} eventClientX
   * @param {number} eventClientY
   * @protected
   */
  _updateGhostPosition(eventClientX, eventClientY) {
    const ghostRect = this._reorderGhost.getBoundingClientRect();
    const targetLeft = eventClientX - ghostRect.width / 2;
    const targetTop = eventClientY - ghostRect.height / 2;
    const _left = parseInt(this._reorderGhost._left || 0);
    const _top = parseInt(this._reorderGhost._top || 0);
    this._reorderGhost._left = _left - (ghostRect.left - targetLeft);
    this._reorderGhost._top = _top - (ghostRect.top - targetTop);
    this._reorderGhost.style.transform = `translate(${this._reorderGhost._left}px, ${this._reorderGhost._top}px)`;
  }
  /**
   * @param {!HTMLElement} cell
   * @return {!HTMLElement}
   * @protected
   */
  _updateGhost(cell) {
    const ghost = this._reorderGhost;
    ghost.textContent = cell._content.innerText;
    const style2 = window.getComputedStyle(cell);
    [
      "boxSizing",
      "display",
      "width",
      "height",
      "background",
      "alignItems",
      "padding",
      "border",
      "flex-direction",
      "overflow"
    ].forEach((propertyName) => {
      ghost.style[propertyName] = style2[propertyName];
    });
    return ghost;
  }
  /** @private */
  _updateOrders(columnTree) {
    if (columnTree === void 0) {
      return;
    }
    columnTree[0].forEach((column) => {
      column._order = 0;
    });
    updateColumnOrders(columnTree[0], this._orderBaseScope, 0);
  }
  /**
   * @param {!GridColumn} column
   * @param {string} status
   * @protected
   */
  _setSiblingsReorderStatus(column, status) {
    iterateChildren(column.parentNode, (sibling) => {
      if (/column/u.test(sibling.localName) && this._isSwapAllowed(sibling, column)) {
        sibling._reorderStatus = status;
      }
    });
  }
  /** @protected */
  _autoScroller() {
    if (this._lastDragClientX) {
      const rightDiff = this._lastDragClientX - this.getBoundingClientRect().right + 50;
      const leftDiff = this.getBoundingClientRect().left - this._lastDragClientX + 50;
      if (rightDiff > 0) {
        this.$.table.scrollLeft += rightDiff / 10;
      } else if (leftDiff > 0) {
        this.$.table.scrollLeft -= leftDiff / 10;
      }
    }
    if (this._draggedColumn) {
      setTimeout(() => this._autoScroller(), 10);
    }
  }
  /**
   * @param {GridColumn | undefined} column1
   * @param {GridColumn | undefined} column2
   * @return {boolean | undefined}
   * @protected
   */
  _isSwapAllowed(column1, column2) {
    if (column1 && column2) {
      const differentColumns = column1 !== column2;
      const sameParent = column1.parentElement === column2.parentElement;
      const sameFrozen = column1.frozen && column2.frozen || // Both columns are frozen
      column1.frozenToEnd && column2.frozenToEnd || // Both columns are frozen to end
      !column1.frozen && !column1.frozenToEnd && !column2.frozen && !column2.frozenToEnd;
      return differentColumns && sameParent && sameFrozen;
    }
  }
  /**
   * @param {!GridColumn} targetColumn
   * @param {number} clientX
   * @return {boolean}
   * @protected
   */
  _isSwappableByPosition(targetColumn, clientX) {
    const targetCell = Array.from(this.$.header.querySelectorAll('tr:not([hidden]) [part~="cell"]')).find(
      (cell) => targetColumn.contains(cell._column)
    );
    const sourceCellRect = this.$.header.querySelector("tr:not([hidden]) [reorder-status=dragging]").getBoundingClientRect();
    const targetRect = targetCell.getBoundingClientRect();
    if (targetRect.left > sourceCellRect.left) {
      return clientX > targetRect.right - sourceCellRect.width;
    }
    return clientX < targetRect.left + sourceCellRect.width;
  }
  /**
   * @param {!GridColumn} column1
   * @param {!GridColumn} column2
   * @protected
   */
  _swapColumnOrders(column1, column2) {
    [column1._order, column2._order] = [column2._order, column1._order];
    this._debounceUpdateFrozenColumn();
    this._updateFirstAndLastColumn();
  }
  /**
   * @param {HTMLElement | undefined} targetCell
   * @param {GridColumn} draggedColumn
   * @return {GridColumn | undefined}
   * @protected
   */
  _getTargetColumn(targetCell, draggedColumn) {
    if (targetCell && draggedColumn) {
      let candidate = targetCell._column;
      while (candidate.parentElement !== draggedColumn.parentElement && candidate !== this) {
        candidate = candidate.parentElement;
      }
      if (candidate.parentElement === draggedColumn.parentElement) {
        return candidate;
      }
      return targetCell._column;
    }
  }
  /**
   * Fired when the columns in the grid are reordered.
   *
   * @event column-reorder
   * @param {Object} detail
   * @param {Object} detail.columns the columns in the new order
   */
};

// node_modules/@vaadin/grid/src/vaadin-grid-column-resizing-mixin.js
var ColumnResizingMixin = (superClass) => class ColumnResizingMixin extends superClass {
  /** @protected */
  ready() {
    super.ready();
    const scroller = this.$.scroller;
    addListener(scroller, "track", this._onHeaderTrack.bind(this));
    scroller.addEventListener("touchmove", (e13) => scroller.hasAttribute("column-resizing") && e13.preventDefault());
    scroller.addEventListener(
      "contextmenu",
      (e13) => e13.target.getAttribute("part") === "resize-handle" && e13.preventDefault()
    );
    scroller.addEventListener(
      "mousedown",
      (e13) => e13.target.getAttribute("part") === "resize-handle" && e13.preventDefault()
    );
  }
  /** @private */
  _onHeaderTrack(e13) {
    const handle = e13.target;
    if (handle.getAttribute("part") === "resize-handle") {
      const cell = handle.parentElement;
      let column = cell._column;
      this.$.scroller.toggleAttribute("column-resizing", true);
      while (column.localName === "vaadin-grid-column-group") {
        column = column._childColumns.slice(0).sort((a17, b5) => a17._order - b5._order).filter((column2) => !column2.hidden).pop();
      }
      const isRTL = this.__isRTL;
      const eventX = e13.detail.x;
      const columnRowCells = Array.from(this.$.header.querySelectorAll('[part~="row"]:last-child [part~="cell"]'));
      const targetCell = columnRowCells.find((cell2) => cell2._column === column);
      if (targetCell.offsetWidth) {
        const style2 = getComputedStyle(targetCell._content);
        const minWidth = 10 + parseInt(style2.paddingLeft) + parseInt(style2.paddingRight) + parseInt(style2.borderLeftWidth) + parseInt(style2.borderRightWidth) + parseInt(style2.marginLeft) + parseInt(style2.marginRight);
        let maxWidth;
        const cellWidth = targetCell.offsetWidth;
        const cellRect = targetCell.getBoundingClientRect();
        if (targetCell.hasAttribute("frozen-to-end")) {
          maxWidth = cellWidth + (isRTL ? eventX - cellRect.right : cellRect.left - eventX);
        } else {
          maxWidth = cellWidth + (isRTL ? cellRect.left - eventX : eventX - cellRect.right);
        }
        column.width = `${Math.max(minWidth, maxWidth)}px`;
        column.flexGrow = 0;
      }
      columnRowCells.sort((a17, b5) => a17._column._order - b5._column._order).forEach((cell2, index, array) => {
        if (index < array.indexOf(targetCell)) {
          cell2._column.width = `${cell2.offsetWidth}px`;
          cell2._column.flexGrow = 0;
        }
      });
      const cellFrozenToEnd = this._frozenToEndCells[0];
      if (cellFrozenToEnd && this.$.table.scrollWidth > this.$.table.offsetWidth) {
        const frozenRect = cellFrozenToEnd.getBoundingClientRect();
        const offset = eventX - (isRTL ? frozenRect.right : frozenRect.left);
        if (isRTL && offset <= 0 || !isRTL && offset >= 0) {
          this.$.table.scrollLeft += offset;
        }
      }
      if (e13.detail.state === "end") {
        this.$.scroller.toggleAttribute("column-resizing", false);
        this.dispatchEvent(
          new CustomEvent("column-resize", {
            detail: { resizedColumn: column }
          })
        );
      }
      this._resizeHandler();
    }
  }
  /**
   * Fired when a column in the grid is resized by the user.
   *
   * @event column-resize
   * @param {Object} detail
   * @param {Object} detail.resizedColumn the column that was resized
   */
};

// node_modules/@vaadin/component-base/src/data-provider-controller/helpers.js
function getFlatIndexContext(cache, flatIndex, level = 0) {
  let levelIndex = flatIndex;
  for (const subCache of cache.subCaches) {
    const index = subCache.parentCacheIndex;
    if (levelIndex <= index) {
      break;
    } else if (levelIndex <= index + subCache.flatSize) {
      return getFlatIndexContext(subCache, levelIndex - index - 1, level + 1);
    }
    levelIndex -= subCache.flatSize;
  }
  return {
    cache,
    item: cache.items[levelIndex],
    index: levelIndex,
    page: Math.floor(levelIndex / cache.pageSize),
    level
  };
}
function getItemContext({ getItemId }, cache, targetItem, level = 0, levelFlatIndex = 0) {
  for (let index = 0; index < cache.items.length; index++) {
    const item = cache.items[index];
    if (!!item && getItemId(item) === getItemId(targetItem)) {
      return {
        cache,
        level,
        item,
        index,
        page: Math.floor(index / cache.pageSize),
        subCache: cache.getSubCache(index),
        flatIndex: levelFlatIndex + cache.getFlatIndex(index)
      };
    }
  }
  for (const subCache of cache.subCaches) {
    const parentItemFlatIndex = levelFlatIndex + cache.getFlatIndex(subCache.parentCacheIndex);
    const result = getItemContext({ getItemId }, subCache, targetItem, level + 1, parentItemFlatIndex + 1);
    if (result) {
      return result;
    }
  }
}
function getFlatIndexByPath(cache, [levelIndex, ...subIndexes], flatIndex = 0) {
  if (levelIndex === Infinity) {
    levelIndex = cache.size - 1;
  }
  const flatIndexOnLevel = cache.getFlatIndex(levelIndex);
  const subCache = cache.getSubCache(levelIndex);
  if (subCache && subCache.flatSize > 0 && subIndexes.length) {
    return getFlatIndexByPath(subCache, subIndexes, flatIndex + flatIndexOnLevel + 1);
  }
  return flatIndex + flatIndexOnLevel;
}

// node_modules/@vaadin/component-base/src/data-provider-controller/cache.js
var Cache = class _Cache {
  /**
   * A context object.
   *
   * @type {{ isExpanded: (item: unknown) => boolean }}
   */
  context;
  /**
   * The number of items to display per page.
   *
   * @type {number}
   */
  pageSize;
  /**
   * An array of cached items.
   *
   * @type {object[]}
   */
  items = [];
  /**
   * A map where the key is a requested page and the value is a callback
   * that will be called with data once the request is complete.
   *
   * @type {Record<number, Function>}
   */
  pendingRequests = {};
  /**
   * A map where the key is the index of an item in the `items` array
   * and the value is a sub-cache associated with that item.
   *
   * Note, it's intentionally defined as an object instead of a Map
   * to ensure that Object.entries() returns an array with keys sorted
   * in alphabetical order, rather than the order they were added.
   *
   * @type {Record<number, Cache>}
   * @private
   */
  __subCacheByIndex = {};
  /**
   * The number of items.
   *
   * @type {number}
   * @private
   */
  __size = 0;
  /**
   * The total number of items, including items from expanded sub-caches.
   *
   * @type {number}
   * @private
   */
  __flatSize = 0;
  /**
   * @param {Cache['context']} context
   * @param {number} pageSize
   * @param {number | undefined} size
   * @param {Cache | undefined} parentCache
   * @param {number | undefined} parentCacheIndex
   */
  constructor(context, pageSize, size, parentCache, parentCacheIndex) {
    this.context = context;
    this.pageSize = pageSize;
    this.size = size;
    this.parentCache = parentCache;
    this.parentCacheIndex = parentCacheIndex;
    this.__flatSize = size || 0;
  }
  /**
   * An item in the parent cache that the current cache is associated with.
   *
   * @return {object | undefined}
   */
  get parentItem() {
    return this.parentCache && this.parentCache.items[this.parentCacheIndex];
  }
  /**
   * An array of sub-caches sorted in the same order as their associated items
   * appear in the `items` array.
   *
   * @return {Cache[]}
   */
  get subCaches() {
    return Object.values(this.__subCacheByIndex);
  }
  /**
   * Whether the cache or any of its descendant caches have pending requests.
   *
   * @return {boolean}
   */
  get isLoading() {
    if (Object.keys(this.pendingRequests).length > 0) {
      return true;
    }
    return this.subCaches.some((subCache) => subCache.isLoading);
  }
  /**
   * The total number of items, including items from expanded sub-caches.
   *
   * @return {number}
   */
  get flatSize() {
    return this.__flatSize;
  }
  /**
   * The total number of items, including items from expanded sub-caches.
   *
   * @protected
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  get effectiveSize() {
    console.warn(
      "<vaadin-grid> The `effectiveSize` property of ItemCache is deprecated and will be removed in Vaadin 25."
    );
    return this.flatSize;
  }
  /**
   * The number of items.
   *
   * @return {number}
   */
  get size() {
    return this.__size;
  }
  /**
   * Sets the number of items.
   *
   * @param {number} size
   */
  set size(size) {
    const oldSize = this.__size;
    if (oldSize === size) {
      return;
    }
    this.__size = size;
    if (this.context.placeholder !== void 0) {
      this.items.length = size || 0;
      for (let i11 = 0; i11 < size || 0; i11++) {
        this.items[i11] ||= this.context.placeholder;
      }
    }
    Object.keys(this.pendingRequests).forEach((page) => {
      const startIndex = parseInt(page) * this.pageSize;
      if (startIndex >= this.size || 0) {
        delete this.pendingRequests[page];
      }
    });
  }
  /**
   * Recalculates the flattened size for the cache and its descendant caches recursively.
   */
  recalculateFlatSize() {
    this.__flatSize = !this.parentItem || this.context.isExpanded(this.parentItem) ? this.size + this.subCaches.reduce((total, subCache) => {
      subCache.recalculateFlatSize();
      return total + subCache.flatSize;
    }, 0) : 0;
  }
  /**
   * Adds an array of items corresponding to the given page
   * to the `items` array.
   *
   * @param {number} page
   * @param {object[]} items
   */
  setPage(page, items) {
    const startIndex = page * this.pageSize;
    items.forEach((item, i11) => {
      const itemIndex = startIndex + i11;
      if (this.size === void 0 || itemIndex < this.size) {
        this.items[itemIndex] = item;
      }
    });
  }
  /**
   * Retrieves the sub-cache associated with the item at the given index
   * in the `items` array.
   *
   * @param {number} index
   * @return {Cache | undefined}
   */
  getSubCache(index) {
    return this.__subCacheByIndex[index];
  }
  /**
   * Removes the sub-cache associated with the item at the given index
   * in the `items` array.
   *
   * @param {number} index
   */
  removeSubCache(index) {
    delete this.__subCacheByIndex[index];
  }
  /**
   * Removes all sub-caches.
   */
  removeSubCaches() {
    this.__subCacheByIndex = {};
  }
  /**
   * Creates and associates a sub-cache for the item at the given index
   * in the `items` array.
   *
   * @param {number} index
   * @return {Cache}
   */
  createSubCache(index) {
    const subCache = new _Cache(this.context, this.pageSize, 0, this, index);
    this.__subCacheByIndex[index] = subCache;
    return subCache;
  }
  /**
   * Retrieves the flattened index corresponding to the given index
   * of an item in the `items` array.
   *
   * @param {number} index
   * @return {number}
   */
  getFlatIndex(index) {
    const clampedIndex = Math.max(0, Math.min(this.size - 1, index));
    return this.subCaches.reduce((prev, subCache) => {
      const index2 = subCache.parentCacheIndex;
      return clampedIndex > index2 ? prev + subCache.flatSize : prev;
    }, clampedIndex);
  }
  /**
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  getItemForIndex(index) {
    console.warn(
      "<vaadin-grid> The `getItemForIndex` method of ItemCache is deprecated and will be removed in Vaadin 25."
    );
    const { item } = getFlatIndexContext(this, index);
    return item;
  }
  /**
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  getCacheAndIndex(index) {
    console.warn(
      "<vaadin-grid> The `getCacheAndIndex` method of ItemCache is deprecated and will be removed in Vaadin 25."
    );
    const { cache, index: scaledIndex } = getFlatIndexContext(this, index);
    return { cache, scaledIndex };
  }
  /**
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  updateSize() {
    console.warn("<vaadin-grid> The `updateSize` method of ItemCache is deprecated and will be removed in Vaadin 25.");
    this.recalculateFlatSize();
  }
  /**
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  ensureSubCacheForScaledIndex(scaledIndex) {
    console.warn(
      "<vaadin-grid> The `ensureSubCacheForScaledIndex` method of ItemCache is deprecated and will be removed in Vaadin 25."
    );
    if (!this.getSubCache(scaledIndex)) {
      const subCache = this.createSubCache(scaledIndex);
      this.context.__controller.__loadCachePage(subCache, 0);
    }
  }
  /**
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  get grid() {
    console.warn("<vaadin-grid> The `grid` property of ItemCache is deprecated and will be removed in Vaadin 25.");
    return this.context.__controller.host;
  }
  /**
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  get itemCaches() {
    console.warn(
      "<vaadin-grid> The `itemCaches` property of ItemCache is deprecated and will be removed in Vaadin 25."
    );
    return this.__subCacheByIndex;
  }
};

// node_modules/@vaadin/component-base/src/data-provider-controller/data-provider-controller.js
var DataProviderController = class extends EventTarget {
  /**
   * The controller host element.
   *
   * @param {HTMLElement}
   */
  host;
  /**
   * A callback that returns data based on the passed params such as
   * `page`, `pageSize`, `parentItem`, etc.
   */
  dataProvider;
  /**
   * A callback that returns additional params that need to be passed
   * to the data provider callback with every request.
   */
  dataProviderParams;
  /**
   * A number of items to display per page.
   *
   * @type {number}
   */
  pageSize;
  /**
   * A callback that returns whether the given item is expanded.
   *
   * @type {(item: unknown) => boolean}
   */
  isExpanded;
  /**
   * A callback that returns the id for the given item and that
   * is used when checking object items for equality.
   *
   * @type { (item: unknown) => unknown}
   */
  getItemId;
  /**
   * A reference to the root cache instance.
   *
   * @param {Cache}
   */
  rootCache;
  /**
   * A placeholder item that is used to indicate that the item is not loaded yet.
   *
   * @type {unknown}
   */
  placeholder;
  /**
   * A callback that returns whether the given item is a placeholder.
   *
   * @type {(item: unknown) => boolean}
   */
  isPlaceholder;
  constructor(host, { size, pageSize, isExpanded, getItemId, isPlaceholder, placeholder, dataProvider, dataProviderParams }) {
    super();
    this.host = host;
    this.pageSize = pageSize;
    this.getItemId = getItemId;
    this.isExpanded = isExpanded;
    this.placeholder = placeholder;
    this.isPlaceholder = isPlaceholder;
    this.dataProvider = dataProvider;
    this.dataProviderParams = dataProviderParams;
    this.rootCache = this.__createRootCache(size);
  }
  /**
   * The total number of items, including items from expanded sub-caches.
   */
  get flatSize() {
    return this.rootCache.flatSize;
  }
  /** @private */
  get __cacheContext() {
    return {
      isExpanded: this.isExpanded,
      placeholder: this.placeholder,
      // The controller instance is needed to ensure deprecated cache methods work.
      __controller: this
    };
  }
  /**
   * Whether the root cache or any of its decendant caches have pending requests.
   *
   * @return {boolean}
   */
  isLoading() {
    return this.rootCache.isLoading;
  }
  /**
   * Sets the page size and clears the cache.
   *
   * @param {number} pageSize
   */
  setPageSize(pageSize) {
    this.pageSize = pageSize;
    this.clearCache();
  }
  /**
   * Sets the data provider callback and clears the cache.
   *
   * @type {Function}
   */
  setDataProvider(dataProvider) {
    this.dataProvider = dataProvider;
    this.clearCache();
  }
  /**
   * Recalculates the flattened size.
   */
  recalculateFlatSize() {
    this.rootCache.recalculateFlatSize();
  }
  /**
   * Clears the cache.
   */
  clearCache() {
    this.rootCache = this.__createRootCache(this.rootCache.size);
  }
  /**
   * Returns context for the given flattened index, including:
   * - the corresponding cache
   * - the cache level
   * - the corresponding item (if loaded)
   * - the item's index in the cache's items array
   * - the page containing the item
   *
   * @param {number} flatIndex
   */
  getFlatIndexContext(flatIndex) {
    return getFlatIndexContext(this.rootCache, flatIndex);
  }
  /**
   * Returns context for the given item, including:
   * - the cache containing the item
   * - the cache level
   * - the item
   * - the item's index in the cache's items array
   * - the item's flattened index
   * - the item's sub-cache (if exists)
   * - the page containing the item
   *
   * If the item isn't found, the method returns undefined.
   */
  getItemContext(item) {
    return getItemContext({ getItemId: this.getItemId }, this.rootCache, item);
  }
  /**
   * Returns the flattened index for the item that the given indexes point to.
   * Each index in the path array points to a sub-item of the previous index.
   * Using `Infinity` as an index will point to the last item on the level.
   *
   * @param {number[]} path
   * @return {number}
   */
  getFlatIndexByPath(path) {
    return getFlatIndexByPath(this.rootCache, path);
  }
  /**
   * Requests the data provider to load the page with the item corresponding
   * to the given flattened index. If the item is already loaded, the method
   * returns immediatelly.
   *
   * @param {number} flatIndex
   */
  ensureFlatIndexLoaded(flatIndex) {
    const { cache, page, item } = this.getFlatIndexContext(flatIndex);
    if (!this.__isItemLoaded(item)) {
      this.__loadCachePage(cache, page);
    }
  }
  /**
   * Creates a sub-cache for the item corresponding to the given flattened index and
   * requests the data provider to load the first page into the created sub-cache.
   * If the sub-cache already exists, the method returns immediatelly.
   *
   * @param {number} flatIndex
   */
  ensureFlatIndexHierarchy(flatIndex) {
    const { cache, item, index } = this.getFlatIndexContext(flatIndex);
    if (this.__isItemLoaded(item) && this.isExpanded(item) && !cache.getSubCache(index)) {
      const subCache = cache.createSubCache(index);
      this.__loadCachePage(subCache, 0);
    }
  }
  /**
   * Loads the first page into the root cache.
   */
  loadFirstPage() {
    this.__loadCachePage(this.rootCache, 0);
  }
  /** @private */
  __createRootCache(size) {
    return new Cache(this.__cacheContext, this.pageSize, size);
  }
  /** @private */
  __loadCachePage(cache, page) {
    if (!this.dataProvider || cache.pendingRequests[page]) {
      return;
    }
    let params = {
      page,
      pageSize: this.pageSize,
      parentItem: cache.parentItem
    };
    if (this.dataProviderParams) {
      params = __spreadValues(__spreadValues({}, params), this.dataProviderParams());
    }
    const callback = (items, size) => {
      if (cache.pendingRequests[page] !== callback) {
        return;
      }
      if (size !== void 0) {
        cache.size = size;
      } else if (params.parentItem) {
        cache.size = items.length;
      }
      cache.setPage(page, items);
      this.recalculateFlatSize();
      this.dispatchEvent(new CustomEvent("page-received"));
      delete cache.pendingRequests[page];
      this.dispatchEvent(new CustomEvent("page-loaded"));
    };
    cache.pendingRequests[page] = callback;
    this.dispatchEvent(new CustomEvent("page-requested"));
    this.dataProvider(params, callback);
  }
  /** @private */
  __isItemLoaded(item) {
    if (this.isPlaceholder) {
      return !this.isPlaceholder(item);
    } else if (this.placeholder) {
      return item !== this.placeholder;
    }
    return !!item;
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-data-provider-mixin.js
var DataProviderMixin = (superClass) => class DataProviderMixin extends superClass {
  static get properties() {
    return {
      /**
       * The number of root-level items in the grid.
       * @attr {number} size
       * @type {number}
       */
      size: {
        type: Number,
        notify: true,
        sync: true
      },
      /**
       * @type {number}
       * @protected
       */
      _flatSize: {
        type: Number,
        sync: true
      },
      /**
       * Number of items fetched at a time from the dataprovider.
       * @attr {number} page-size
       * @type {number}
       */
      pageSize: {
        type: Number,
        value: 50,
        observer: "_pageSizeChanged",
        sync: true
      },
      /**
       * Function that provides items lazily. Receives arguments `params`, `callback`
       *
       * `params.page` Requested page index
       *
       * `params.pageSize` Current page size
       *
       * `params.filters` Currently applied filters
       *
       * `params.sortOrders` Currently applied sorting orders
       *
       * `params.parentItem` When tree is used, and sublevel items
       * are requested, reference to parent item of the requested sublevel.
       * Otherwise `undefined`.
       *
       * `callback(items, size)` Callback function with arguments:
       *   - `items` Current page of items
       *   - `size` Total number of items. When tree sublevel items
       *     are requested, total number of items in the requested sublevel.
       *     Optional when tree is not used, required for tree.
       *
       * @type {GridDataProvider | null | undefined}
       */
      dataProvider: {
        type: Object,
        notify: true,
        observer: "_dataProviderChanged",
        sync: true
      },
      /**
       * `true` while data is being requested from the data provider.
       */
      loading: {
        type: Boolean,
        notify: true,
        readOnly: true,
        reflectToAttribute: true
      },
      /**
       * @protected
       */
      _hasData: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * Path to an item sub-property that indicates whether the item has child items.
       * @attr {string} item-has-children-path
       */
      itemHasChildrenPath: {
        type: String,
        value: "children",
        observer: "__itemHasChildrenPathChanged",
        sync: true
      },
      /**
       * Path to an item sub-property that identifies the item.
       * @attr {string} item-id-path
       */
      itemIdPath: {
        type: String,
        value: null,
        sync: true
      },
      /**
       * An array that contains the expanded items.
       * @type {!Array<!GridItem>}
       */
      expandedItems: {
        type: Object,
        notify: true,
        value: () => [],
        sync: true
      },
      /**
       * @private
       */
      __expandedKeys: {
        type: Object,
        computed: "__computeExpandedKeys(itemIdPath, expandedItems)"
      }
    };
  }
  static get observers() {
    return ["_sizeChanged(size)", "_expandedItemsChanged(expandedItems)"];
  }
  constructor() {
    super();
    this._dataProviderController = new DataProviderController(this, {
      size: this.size || 0,
      pageSize: this.pageSize,
      getItemId: this.getItemId.bind(this),
      isExpanded: this._isExpanded.bind(this),
      dataProvider: this.dataProvider ? this.dataProvider.bind(this) : null,
      dataProviderParams: () => {
        return {
          sortOrders: this._mapSorters(),
          filters: this._mapFilters()
        };
      }
    });
    this._dataProviderController.addEventListener("page-requested", this._onDataProviderPageRequested.bind(this));
    this._dataProviderController.addEventListener("page-received", this._onDataProviderPageReceived.bind(this));
    this._dataProviderController.addEventListener("page-loaded", this._onDataProviderPageLoaded.bind(this));
  }
  /**
   * @protected
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  get _cache() {
    console.warn("<vaadin-grid> The `_cache` property is deprecated and will be removed in Vaadin 25.");
    return this._dataProviderController.rootCache;
  }
  /**
   * @protected
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  get _effectiveSize() {
    console.warn("<vaadin-grid> The `_effectiveSize` property is deprecated and will be removed in Vaadin 25.");
    return this._flatSize;
  }
  /** @private */
  _sizeChanged(size) {
    this._dataProviderController.rootCache.size = size;
    this._dataProviderController.recalculateFlatSize();
    this._flatSize = this._dataProviderController.flatSize;
  }
  /** @private */
  __itemHasChildrenPathChanged(value, oldValue) {
    if (!oldValue && value === "children") {
      return;
    }
    this.requestContentUpdate();
  }
  /**
   * @param {number} index
   * @param {HTMLElement} el
   * @protected
   */
  _getItem(index, el) {
    el.index = index;
    const { item } = this._dataProviderController.getFlatIndexContext(index);
    if (item) {
      this.__updateLoading(el, false);
      this._updateItem(el, item);
      if (this._isExpanded(item)) {
        this._dataProviderController.ensureFlatIndexHierarchy(index);
      }
    } else {
      this.__updateLoading(el, true);
      this._dataProviderController.ensureFlatIndexLoaded(index);
    }
  }
  /**
   * @param {!HTMLElement} row
   * @param {boolean} loading
   * @private
   */
  __updateLoading(row, loading) {
    const cells = getBodyRowCells(row);
    updateState(row, "loading", loading);
    updateCellsPart(cells, "loading-row-cell", loading);
    if (loading) {
      this._generateCellClassNames(row);
      this._generateCellPartNames(row);
    }
  }
  /**
   * Returns a value that identifies the item. Uses `itemIdPath` if available.
   * Can be customized by overriding.
   * @param {!GridItem} item
   * @return {!GridItem | !unknown}
   */
  getItemId(item) {
    return this.itemIdPath ? get2(this.itemIdPath, item) : item;
  }
  /**
   * @param {!GridItem} item
   * @return {boolean}
   * @protected
   */
  _isExpanded(item) {
    return this.__expandedKeys && this.__expandedKeys.has(this.getItemId(item));
  }
  /** @private */
  _expandedItemsChanged() {
    this._dataProviderController.recalculateFlatSize();
    this._flatSize = this._dataProviderController.flatSize;
    this.__updateVisibleRows();
  }
  /** @private */
  __computeExpandedKeys(_itemIdPath, expandedItems) {
    const expanded = expandedItems || [];
    const expandedKeys = /* @__PURE__ */ new Set();
    expanded.forEach((item) => {
      expandedKeys.add(this.getItemId(item));
    });
    return expandedKeys;
  }
  /**
   * Expands the given item tree.
   * @param {!GridItem} item
   */
  expandItem(item) {
    if (!this._isExpanded(item)) {
      this.expandedItems = [...this.expandedItems, item];
    }
  }
  /**
   * Collapses the given item tree.
   * @param {!GridItem} item
   */
  collapseItem(item) {
    if (this._isExpanded(item)) {
      this.expandedItems = this.expandedItems.filter((i11) => !this._itemsEqual(i11, item));
    }
  }
  /**
   * @param {number} index
   * @return {number}
   * @protected
   */
  _getIndexLevel(index = 0) {
    const { level } = this._dataProviderController.getFlatIndexContext(index);
    return level;
  }
  /**
   * @param {number} page
   * @param {ItemCache} cache
   * @protected
   * @deprecated since 24.3 and will be removed in Vaadin 25.
   */
  _loadPage(page, cache) {
    console.warn("<vaadin-grid> The `_loadPage` method is deprecated and will be removed in Vaadin 25.");
    this._dataProviderController.__loadCachePage(cache, page);
  }
  /** @protected */
  _onDataProviderPageRequested() {
    this._setLoading(true);
  }
  /** @protected */
  _onDataProviderPageReceived() {
    if (this._flatSize !== this._dataProviderController.flatSize) {
      this._shouldUpdateAllRenderedRowsAfterPageLoad = true;
      this._flatSize = this._dataProviderController.flatSize;
    }
    this._getRenderedRows().forEach((row) => {
      this._dataProviderController.ensureFlatIndexHierarchy(row.index);
    });
    this._hasData = true;
  }
  /** @protected */
  _onDataProviderPageLoaded() {
    this._debouncerApplyCachedData = Debouncer.debounce(this._debouncerApplyCachedData, timeOut.after(0), () => {
      this._setLoading(false);
      const shouldUpdateAllRenderedRowsAfterPageLoad = this._shouldUpdateAllRenderedRowsAfterPageLoad;
      this._shouldUpdateAllRenderedRowsAfterPageLoad = false;
      this._getRenderedRows().forEach((row) => {
        const { item } = this._dataProviderController.getFlatIndexContext(row.index);
        if (item || shouldUpdateAllRenderedRowsAfterPageLoad) {
          this._getItem(row.index, row);
        }
      });
      this.__scrollToPendingIndexes();
      this.__dispatchPendingBodyCellFocus();
    });
    if (!this._dataProviderController.isLoading()) {
      this._debouncerApplyCachedData.flush();
    }
  }
  /** @private */
  __debounceClearCache() {
    this.__clearCacheDebouncer = Debouncer.debounce(this.__clearCacheDebouncer, microTask2, () => this.clearCache());
  }
  /**
   * Clears the cached pages and reloads data from dataprovider when needed.
   */
  clearCache() {
    this._dataProviderController.clearCache();
    this._dataProviderController.rootCache.size = this.size || 0;
    this._dataProviderController.recalculateFlatSize();
    this._hasData = false;
    this.__updateVisibleRows();
    if (!this.__virtualizer || !this.__virtualizer.size) {
      this._dataProviderController.loadFirstPage();
    }
  }
  /** @private */
  _pageSizeChanged(pageSize, oldPageSize) {
    this._dataProviderController.setPageSize(pageSize);
    if (oldPageSize !== void 0 && pageSize !== oldPageSize) {
      this.clearCache();
    }
  }
  /** @protected */
  _checkSize() {
    if (this.size === void 0 && this._flatSize === 0) {
      console.warn(
        "The <vaadin-grid> needs the total number of items in order to display rows, which you can specify either by setting the `size` property, or by providing it to the second argument of the `dataProvider` function `callback` call."
      );
    }
  }
  /** @private */
  _dataProviderChanged(dataProvider, oldDataProvider) {
    this._dataProviderController.setDataProvider(dataProvider ? dataProvider.bind(this) : null);
    if (oldDataProvider !== void 0) {
      this.clearCache();
    }
    this._ensureFirstPageLoaded();
    this._debouncerCheckSize = Debouncer.debounce(
      this._debouncerCheckSize,
      timeOut.after(2e3),
      this._checkSize.bind(this)
    );
  }
  /** @protected */
  _ensureFirstPageLoaded() {
    if (!this._hasData) {
      this._dataProviderController.loadFirstPage();
    }
  }
  /**
   * @param {!GridItem} item1
   * @param {!GridItem} item2
   * @return {boolean}
   * @protected
   */
  _itemsEqual(item1, item2) {
    return this.getItemId(item1) === this.getItemId(item2);
  }
  /**
   * @param {!GridItem} item
   * @param {!Array<!GridItem>} array
   * @return {number}
   * @protected
   */
  _getItemIndexInArray(item, array) {
    let result = -1;
    array.forEach((i11, idx) => {
      if (this._itemsEqual(i11, item)) {
        result = idx;
      }
    });
    return result;
  }
  /**
   * Scroll to a specific row index in the virtual list. Note that the row index is
   * not always the same for any particular item. For example, sorting or filtering
   * items can affect the row index related to an item.
   *
   * The `indexes` parameter can be either a single number or multiple numbers.
   * The grid will first try to scroll to the item at the first index on the top level.
   * In case the item at the first index is expanded, the grid will then try scroll to the
   * item at the second index within the children of the expanded first item, and so on.
   * Each given index points to a child of the item at the previous index.
   *
   * Using `Infinity` as an index will point to the last item on the level.
   *
   * @param indexes {...number} Row indexes to scroll to
   */
  scrollToIndex(...indexes) {
    let targetIndex;
    while (targetIndex !== (targetIndex = this._dataProviderController.getFlatIndexByPath(indexes))) {
      this._scrollToFlatIndex(targetIndex);
    }
    if (this._dataProviderController.isLoading() || !this.clientHeight || !this._columnTree) {
      this.__pendingScrollToIndexes = indexes;
    }
  }
  /** @private */
  __scrollToPendingIndexes() {
    if (this.__pendingScrollToIndexes && this.$.items.children.length) {
      const indexes = this.__pendingScrollToIndexes;
      delete this.__pendingScrollToIndexes;
      this.scrollToIndex(...indexes);
    }
  }
  /**
   * Fired when the `expandedItems` property changes.
   *
   * @event expanded-items-changed
   */
  /**
   * Fired when the `loading` property changes.
   *
   * @event loading-changed
   */
};

// node_modules/@vaadin/grid/src/vaadin-grid-drag-and-drop-mixin.js
var DropMode = {
  BETWEEN: "between",
  ON_TOP: "on-top",
  ON_TOP_OR_BETWEEN: "on-top-or-between",
  ON_GRID: "on-grid"
};
var DropLocation = {
  ON_TOP: "on-top",
  ABOVE: "above",
  BELOW: "below",
  EMPTY: "empty"
};
var usesDnDPolyfill = !("draggable" in document.createElement("div"));
var DragAndDropMixin = (superClass) => class DragAndDropMixin extends superClass {
  static get properties() {
    return {
      /**
       * Defines the locations within the Grid row where an element can be dropped.
       *
       * Possible values are:
       * - `between`: The drop event can happen between Grid rows.
       * - `on-top`: The drop event can happen on top of Grid rows.
       * - `on-top-or-between`: The drop event can happen either on top of or between Grid rows.
       * - `on-grid`: The drop event will not happen on any specific row, it will show the drop target outline around the whole grid.
       * @attr {between|on-top|on-top-or-between|on-grid} drop-mode
       * @type {GridDropMode | null | undefined}
       */
      dropMode: {
        type: String,
        sync: true
      },
      /**
       * Marks the grid's rows to be available for dragging.
       * @attr {boolean} rows-draggable
       */
      rowsDraggable: {
        type: Boolean,
        sync: true
      },
      /**
       * A function that filters dragging of specific grid rows. The return value should be false
       * if dragging of the row should be disabled.
       *
       * Receives one argument:
       * - `model` The object with the properties related with
       *   the rendered item, contains:
       *   - `model.index` The index of the item.
       *   - `model.item` The item.
       *   - `model.expanded` Sublevel toggle state.
       *   - `model.level` Level of the tree represented with a horizontal offset of the toggle button.
       *   - `model.selected` Selected state.
       *
       * @type {GridDragAndDropFilter | null | undefined}
       */
      dragFilter: {
        type: Function,
        sync: true
      },
      /**
       * A function that filters dropping on specific grid rows. The return value should be false
       * if dropping on the row should be disabled.
       *
       * Receives one argument:
       * - `model` The object with the properties related with
       *   the rendered item, contains:
       *   - `model.index` The index of the item.
       *   - `model.item` The item.
       *   - `model.expanded` Sublevel toggle state.
       *   - `model.level` Level of the tree represented with a horizontal offset of the toggle button.
       *   - `model.selected` Selected state.
       *
       * @type {GridDragAndDropFilter | null | undefined}
       */
      dropFilter: {
        type: Function,
        sync: true
      },
      /** @private */
      __dndAutoScrollThreshold: {
        value: 50
      },
      /** @private  */
      __draggedItems: {
        value: () => []
      }
    };
  }
  static get observers() {
    return ["_dragDropAccessChanged(rowsDraggable, dropMode, dragFilter, dropFilter, loading)"];
  }
  constructor() {
    super();
    this.__onDocumentDragStart = this.__onDocumentDragStart.bind(this);
  }
  /** @protected */
  ready() {
    super.ready();
    this.$.table.addEventListener("dragstart", this._onDragStart.bind(this));
    this.$.table.addEventListener("dragend", this._onDragEnd.bind(this));
    this.$.table.addEventListener("dragover", this._onDragOver.bind(this));
    this.$.table.addEventListener("dragleave", this._onDragLeave.bind(this));
    this.$.table.addEventListener("drop", this._onDrop.bind(this));
    this.$.table.addEventListener("dragenter", (e13) => {
      if (this.dropMode) {
        e13.preventDefault();
        e13.stopPropagation();
      }
    });
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    document.addEventListener("dragstart", this.__onDocumentDragStart, { capture: true });
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    document.removeEventListener("dragstart", this.__onDocumentDragStart, { capture: true });
  }
  /** @private */
  _onDragStart(e13) {
    if (this.rowsDraggable) {
      let row = e13.target;
      if (row.localName === "vaadin-grid-cell-content") {
        row = row.assignedSlot.parentNode.parentNode;
      }
      if (row.parentNode !== this.$.items) {
        return;
      }
      e13.stopPropagation();
      this.toggleAttribute("dragging-rows", true);
      if (this._safari) {
        const transform = row.style.transform;
        row.style.top = /translateY\((.*)\)/u.exec(transform)[1];
        row.style.transform = "none";
        requestAnimationFrame(() => {
          row.style.top = "";
          row.style.transform = transform;
        });
      }
      const rowRect = row.getBoundingClientRect();
      if (usesDnDPolyfill) {
        e13.dataTransfer.setDragImage(row);
      } else {
        e13.dataTransfer.setDragImage(row, e13.clientX - rowRect.left, e13.clientY - rowRect.top);
      }
      let rows = [row];
      if (this._isSelected(row._item)) {
        rows = this.__getViewportRows().filter((row2) => this._isSelected(row2._item)).filter((row2) => !this.dragFilter || this.dragFilter(this.__getRowModel(row2)));
      }
      this.__draggedItems = rows.map((row2) => row2._item);
      e13.dataTransfer.setData("text", this.__formatDefaultTransferData(rows));
      updateBooleanRowStates(row, { dragstart: rows.length > 1 ? `${rows.length}` : "" });
      this.style.setProperty("--_grid-drag-start-x", `${e13.clientX - rowRect.left + 20}px`);
      this.style.setProperty("--_grid-drag-start-y", `${e13.clientY - rowRect.top + 10}px`);
      requestAnimationFrame(() => {
        updateBooleanRowStates(row, { dragstart: false });
        this.style.setProperty("--_grid-drag-start-x", "");
        this.style.setProperty("--_grid-drag-start-y", "");
        this.requestContentUpdate();
      });
      const event = new CustomEvent("grid-dragstart", {
        detail: {
          draggedItems: [...this.__draggedItems],
          setDragData: (type, data) => e13.dataTransfer.setData(type, data),
          setDraggedItemsCount: (count) => row.setAttribute("dragstart", count)
        }
      });
      event.originalEvent = e13;
      this.dispatchEvent(event);
    }
  }
  /** @private */
  _onDragEnd(e13) {
    this.toggleAttribute("dragging-rows", false);
    e13.stopPropagation();
    const event = new CustomEvent("grid-dragend");
    event.originalEvent = e13;
    this.dispatchEvent(event);
    this.__draggedItems = [];
    this.requestContentUpdate();
  }
  /** @private */
  _onDragLeave(e13) {
    if (!this.dropMode) {
      return;
    }
    e13.stopPropagation();
    this._clearDragStyles();
  }
  /** @private */
  _onDragOver(e13) {
    if (this.dropMode) {
      this._dropLocation = void 0;
      this._dragOverItem = void 0;
      if (this.__dndAutoScroll(e13.clientY)) {
        this._clearDragStyles();
        return;
      }
      let row = e13.composedPath().find((node) => node.localName === "tr");
      if (!this._flatSize || this.dropMode === DropMode.ON_GRID) {
        this._dropLocation = DropLocation.EMPTY;
      } else if (!row || row.parentNode !== this.$.items) {
        if (row) {
          return;
        } else if (this.dropMode === DropMode.BETWEEN || this.dropMode === DropMode.ON_TOP_OR_BETWEEN) {
          row = Array.from(this.$.items.children).filter((row2) => !row2.hidden).pop();
          this._dropLocation = DropLocation.BELOW;
        } else {
          return;
        }
      } else {
        const rowRect = row.getBoundingClientRect();
        this._dropLocation = DropLocation.ON_TOP;
        if (this.dropMode === DropMode.BETWEEN) {
          const dropAbove = e13.clientY - rowRect.top < rowRect.bottom - e13.clientY;
          this._dropLocation = dropAbove ? DropLocation.ABOVE : DropLocation.BELOW;
        } else if (this.dropMode === DropMode.ON_TOP_OR_BETWEEN) {
          if (e13.clientY - rowRect.top < rowRect.height / 3) {
            this._dropLocation = DropLocation.ABOVE;
          } else if (e13.clientY - rowRect.top > rowRect.height / 3 * 2) {
            this._dropLocation = DropLocation.BELOW;
          }
        }
      }
      if (row && row.hasAttribute("drop-disabled")) {
        this._dropLocation = void 0;
        return;
      }
      e13.stopPropagation();
      e13.preventDefault();
      if (this._dropLocation === DropLocation.EMPTY) {
        this.toggleAttribute("dragover", true);
      } else if (row) {
        this._dragOverItem = row._item;
        if (row.getAttribute("dragover") !== this._dropLocation) {
          updateStringRowStates(row, { dragover: this._dropLocation });
        }
      } else {
        this._clearDragStyles();
      }
    }
  }
  /**
   * Webkit-based browsers have issues with generating drag images
   * for elements that have children with massive heights. Chromium
   * browsers crash, while Safari experiences significant performance
   * issues. To mitigate these issues, we hide the scroller element
   * when drag starts to remove it from the drag image.
   *
   * Grids with fewer rows also have issues on Chromium and Safari
   * where the drag image is not properly clipped and may include
   * content outside the grid. Temporary inline styles are applied
   * to mitigate this issue.
   *
   * Related issues:
   * - https://github.com/vaadin/web-components/issues/7985
   * - https://issues.chromium.org/issues/383356871
   * - https://github.com/vaadin/web-components/issues/8386
   *
   * @private
   */
  __onDocumentDragStart(e13) {
    if (e13.target.contains(this)) {
      const elements = [e13.target, this.$.items, this.$.scroller];
      const originalInlineStyles = elements.map((element) => element.style.cssText);
      if (this.$.table.scrollHeight > 2e4) {
        this.$.scroller.style.display = "none";
      }
      if (isChrome) {
        e13.target.style.willChange = "transform";
      }
      if (isSafari) {
        this.$.items.style.flexShrink = 1;
      }
      requestAnimationFrame(() => {
        elements.forEach((element, index) => {
          element.style.cssText = originalInlineStyles[index];
        });
      });
    }
  }
  /** @private */
  __dndAutoScroll(clientY) {
    if (this.__dndAutoScrolling) {
      return true;
    }
    const headerBottom = this.$.header.getBoundingClientRect().bottom;
    const footerTop = this.$.footer.getBoundingClientRect().top;
    const topDiff = headerBottom - clientY + this.__dndAutoScrollThreshold;
    const bottomDiff = clientY - footerTop + this.__dndAutoScrollThreshold;
    let scrollTopDelta = 0;
    if (bottomDiff > 0) {
      scrollTopDelta = bottomDiff * 2;
    } else if (topDiff > 0) {
      scrollTopDelta = -topDiff * 2;
    }
    if (scrollTopDelta) {
      const scrollTop = this.$.table.scrollTop;
      this.$.table.scrollTop += scrollTopDelta;
      const scrollTopChanged = scrollTop !== this.$.table.scrollTop;
      if (scrollTopChanged) {
        this.__dndAutoScrolling = true;
        setTimeout(() => {
          this.__dndAutoScrolling = false;
        }, 20);
        return true;
      }
    }
  }
  /** @private */
  __getViewportRows() {
    const headerBottom = this.$.header.getBoundingClientRect().bottom;
    const footerTop = this.$.footer.getBoundingClientRect().top;
    return Array.from(this.$.items.children).filter((row) => {
      const rowRect = row.getBoundingClientRect();
      return rowRect.bottom > headerBottom && rowRect.top < footerTop;
    });
  }
  /** @protected */
  _clearDragStyles() {
    this.removeAttribute("dragover");
    iterateChildren(this.$.items, (row) => {
      updateStringRowStates(row, { dragover: null });
    });
  }
  /** @private */
  __updateDragSourceParts(row, model) {
    updateBooleanRowStates(row, { "drag-source": this.__draggedItems.includes(model.item) });
  }
  /** @private */
  _onDrop(e13) {
    if (this.dropMode) {
      e13.stopPropagation();
      e13.preventDefault();
      const dragData = e13.dataTransfer.types && Array.from(e13.dataTransfer.types).map((type) => {
        return {
          type,
          data: e13.dataTransfer.getData(type)
        };
      });
      this._clearDragStyles();
      const event = new CustomEvent("grid-drop", {
        bubbles: e13.bubbles,
        cancelable: e13.cancelable,
        detail: {
          dropTargetItem: this._dragOverItem,
          dropLocation: this._dropLocation,
          dragData
        }
      });
      event.originalEvent = e13;
      this.dispatchEvent(event);
    }
  }
  /** @private */
  __formatDefaultTransferData(rows) {
    return rows.map((row) => {
      return Array.from(row.children).filter((cell) => !cell.hidden && cell.getAttribute("part").indexOf("details-cell") === -1).sort((a17, b5) => {
        return a17._column._order > b5._column._order ? 1 : -1;
      }).map((cell) => cell._content.textContent.trim()).filter((content) => content).join("	");
    }).join("\n");
  }
  /** @private */
  _dragDropAccessChanged() {
    this.filterDragAndDrop();
  }
  /**
   * Runs the `dragFilter` and `dropFilter` hooks for the visible cells.
   * If the filter depends on varying conditions, you may need to
   * call this function manually in order to update the draggability when
   * the conditions change.
   */
  filterDragAndDrop() {
    iterateChildren(this.$.items, (row) => {
      if (!row.hidden) {
        this._filterDragAndDrop(row, this.__getRowModel(row));
      }
    });
  }
  /**
   * @param {!HTMLElement} row
   * @param {!GridItemModel} model
   * @protected
   */
  _filterDragAndDrop(row, model) {
    const loading = this.loading || row.hasAttribute("loading");
    const dragDisabled = !this.rowsDraggable || loading || this.dragFilter && !this.dragFilter(model);
    const dropDisabled = !this.dropMode || loading || this.dropFilter && !this.dropFilter(model);
    iterateRowCells(row, (cell) => {
      if (dragDisabled) {
        cell._content.removeAttribute("draggable");
      } else {
        cell._content.setAttribute("draggable", true);
      }
    });
    updateBooleanRowStates(row, {
      "drag-disabled": !!dragDisabled,
      "drop-disabled": !!dropDisabled
    });
  }
  /**
   * Fired when starting to drag grid rows.
   *
   * @event grid-dragstart
   * @param {Object} originalEvent The native dragstart event
   * @param {Object} detail
   * @param {Object} detail.draggedItems the items in the visible viewport that are dragged
   * @param {Function} detail.setDraggedItemsCount Overrides the default number shown in the drag image on multi row drag.
   * Parameter is of type number.
   * @param {Function} detail.setDragData Sets dataTransfer data for the drag operation.
   * Note that "text" is the only data type supported by all the browsers the grid currently supports (including IE11).
   * The function takes two parameters:
   * - type:string The type of the data
   * - data:string The data
   */
  /**
   * Fired when the dragging of the rows ends.
   *
   * @event grid-dragend
   * @param {Object} originalEvent The native dragend event
   */
  /**
   * Fired when a drop occurs on top of the grid.
   *
   * @event grid-drop
   * @param {Object} originalEvent The native drop event
   * @param {Object} detail
   * @param {Object} detail.dropTargetItem The item of the grid row on which the drop occurred.
   * @param {string} detail.dropLocation The position at which the drop event took place relative to a row.
   * Depending on the dropMode value, the drop location can be one of the following
   * - `on-top`: when the drop occurred on top of the row
   * - `above`: when the drop occurred above the row
   * - `below`: when the drop occurred below the row
   * - `empty`: when the drop occurred over the grid, not relative to any specific row
   * @param {string} detail.dragData An array of items with the payload as a string representation as the
   * `data` property and the type of the data as `type` property.
   */
};

// node_modules/@vaadin/grid/src/vaadin-grid-dynamic-columns-mixin.js
function arrayEquals(arr1, arr2) {
  if (!arr1 || !arr2 || arr1.length !== arr2.length) {
    return false;
  }
  for (let i11 = 0, l10 = arr1.length; i11 < l10; i11++) {
    if (arr1[i11] instanceof Array && arr2[i11] instanceof Array) {
      if (!arrayEquals(arr1[i11], arr2[i11])) {
        return false;
      }
    } else if (arr1[i11] !== arr2[i11]) {
      return false;
    }
  }
  return true;
}
var DynamicColumnsMixin = (superClass) => class DynamicColumnsMixin extends superClass {
  static get properties() {
    return {
      /**
       * @protected
       */
      _columnTree: Object
    };
  }
  /** @protected */
  ready() {
    super.ready();
    this._addNodeObserver();
  }
  /** @private */
  _hasColumnGroups(columns) {
    return columns.some((column) => column.localName === "vaadin-grid-column-group");
  }
  /**
   * @param {!GridColumnGroup} el
   * @return {!Array<!GridColumn>}
   * @protected
   */
  _getChildColumns(el) {
    return ColumnObserver.getColumns(el);
  }
  /** @private */
  _flattenColumnGroups(columns) {
    return columns.map((col) => {
      if (col.localName === "vaadin-grid-column-group") {
        return this._getChildColumns(col);
      }
      return [col];
    }).reduce((prev, curr) => {
      return prev.concat(curr);
    }, []);
  }
  /** @private */
  _getColumnTree() {
    const rootColumns = ColumnObserver.getColumns(this);
    const columnTree = [rootColumns];
    let c13 = rootColumns;
    while (this._hasColumnGroups(c13)) {
      c13 = this._flattenColumnGroups(c13);
      columnTree.push(c13);
    }
    return columnTree;
  }
  /** @protected */
  _debounceUpdateColumnTree() {
    this.__updateColumnTreeDebouncer = Debouncer.debounce(
      this.__updateColumnTreeDebouncer,
      microTask2,
      () => this._updateColumnTree()
    );
  }
  /** @protected */
  _updateColumnTree() {
    const columnTree = this._getColumnTree();
    if (!arrayEquals(columnTree, this._columnTree)) {
      columnTree.forEach((columnArray) => {
        columnArray.forEach((column) => {
          if (column.performUpdate) {
            column.performUpdate();
          }
        });
      });
      this._columnTree = columnTree;
    }
  }
  /** @private */
  _addNodeObserver() {
    this._observer = new ColumnObserver(this, (_addedColumns, removedColumns) => {
      const allRemovedCells = removedColumns.flatMap((c13) => c13._allCells);
      const filterNotConnected = (element) => allRemovedCells.filter((cell) => cell && cell._content.contains(element)).length;
      this.__removeSorters(this._sorters.filter(filterNotConnected));
      this.__removeFilters(this._filters.filter(filterNotConnected));
      this._debounceUpdateColumnTree();
      this._debouncerCheckImports = Debouncer.debounce(
        this._debouncerCheckImports,
        timeOut.after(2e3),
        this._checkImports.bind(this)
      );
      this._ensureFirstPageLoaded();
    });
  }
  /** @protected */
  _checkImports() {
    [
      "vaadin-grid-column-group",
      "vaadin-grid-filter",
      "vaadin-grid-filter-column",
      "vaadin-grid-tree-toggle",
      "vaadin-grid-selection-column",
      "vaadin-grid-sort-column",
      "vaadin-grid-sorter"
    ].forEach((elementName) => {
      const element = this.querySelector(elementName);
      if (element && !customElements.get(elementName)) {
        console.warn(`Make sure you have imported the required module for <${elementName}> element.`);
      }
    });
  }
  /** @protected */
  _updateFirstAndLastColumn() {
    Array.from(this.shadowRoot.querySelectorAll("tr")).forEach((row) => this._updateFirstAndLastColumnForRow(row));
  }
  /**
   * @param {!HTMLElement} row
   * @protected
   */
  _updateFirstAndLastColumnForRow(row) {
    Array.from(row.querySelectorAll('[part~="cell"]:not([part~="details-cell"])')).sort((a17, b5) => {
      return a17._column._order - b5._column._order;
    }).forEach((cell, cellIndex, children) => {
      updateCellState(cell, "first-column", cellIndex === 0);
      updateCellState(cell, "last-column", cellIndex === children.length - 1);
    });
  }
  /**
   * @param {!Node} node
   * @return {boolean}
   * @protected
   */
  _isColumnElement(node) {
    return node.nodeType === Node.ELEMENT_NODE && /\bcolumn\b/u.test(node.localName);
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-event-context-mixin.js
var EventContextMixin = (superClass) => class EventContextMixin extends superClass {
  /**
   * Returns an object with context information about the event target:
   * - `item`: the data object corresponding to the targeted row (not specified when targeting header or footer)
   * - `column`: the column element corresponding to the targeted cell (not specified when targeting row details)
   * - `section`: whether the event targeted the body, header, footer or details of the grid
   *
   * These additional properties are included when `item` is specified:
   * - `index`: the index of the item
   * - `selected`: the selected state of the item
   * - `detailsOpened`: whether the row details are open for the item
   * - `expanded`: the expanded state of the tree toggle
   * - `level`: the tree hierarchy level
   *
   * The returned object is populated only when a grid cell, header, footer or row details is found in `event.composedPath()`.
   * This means mostly mouse and keyboard events. If such a grid part is not found in the path, an empty object is returned.
   * This may be the case eg. if the event is fired on the `<vaadin-grid>` element and not any deeper in the DOM, or if
   * the event targets the empty part of the grid body.
   *
   * @param {!Event} event
   * @return {GridEventContext}
   */
  getEventContext(event) {
    const context = {};
    const { cell } = this._getGridEventLocation(event);
    if (!cell) {
      return context;
    }
    context.section = ["body", "header", "footer", "details"].find(
      (section) => cell.getAttribute("part").indexOf(section) > -1
    );
    if (cell._column) {
      context.column = cell._column;
    }
    if (context.section === "body" || context.section === "details") {
      Object.assign(context, this.__getRowModel(cell.parentElement));
    }
    return context;
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-filter-mixin.js
var FilterMixin = (superClass) => class FilterMixin extends superClass {
  static get properties() {
    return {
      /** @private */
      _filters: {
        type: Array,
        value: () => []
      }
    };
  }
  constructor() {
    super();
    this._filterChanged = this._filterChanged.bind(this);
    this.addEventListener("filter-changed", this._filterChanged);
  }
  /** @private */
  _filterChanged(e13) {
    e13.stopPropagation();
    this.__addFilter(e13.target);
    this.__applyFilters();
  }
  /** @private */
  __removeFilters(filtersToRemove) {
    if (filtersToRemove.length === 0) {
      return;
    }
    this._filters = this._filters.filter((filter2) => filtersToRemove.indexOf(filter2) < 0);
    this.__applyFilters();
  }
  /** @private */
  __addFilter(filter2) {
    const filterIndex = this._filters.indexOf(filter2);
    if (filterIndex === -1) {
      this._filters.push(filter2);
    }
  }
  /** @private */
  __applyFilters() {
    if (this.dataProvider && this.isAttached) {
      this.clearCache();
    }
  }
  /**
   * @return {!Array<!GridFilterDefinition>}
   * @protected
   */
  _mapFilters() {
    return this._filters.map((filter2) => {
      return {
        path: filter2.path,
        value: filter2.value
      };
    });
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-keyboard-navigation-mixin.js
function isRow(element) {
  return element instanceof HTMLTableRowElement;
}
function isCell(element) {
  return element instanceof HTMLTableCellElement;
}
function isDetailsCell(element) {
  return element.matches('[part~="details-cell"]');
}
var KeyboardNavigationMixin = (superClass) => class KeyboardNavigationMixin extends superClass {
  static get properties() {
    return {
      /** @private */
      _headerFocusable: {
        type: Object,
        observer: "_focusableChanged",
        sync: true
      },
      /**
       * @type {!HTMLElement | undefined}
       * @protected
       */
      _itemsFocusable: {
        type: Object,
        observer: "_focusableChanged",
        sync: true
      },
      /** @private */
      _footerFocusable: {
        type: Object,
        observer: "_focusableChanged",
        sync: true
      },
      /** @private */
      _navigatingIsHidden: Boolean,
      /**
       * @type {number}
       * @protected
       */
      _focusedItemIndex: {
        type: Number,
        value: 0
      },
      /** @private */
      _focusedColumnOrder: Number,
      /** @private */
      _focusedCell: {
        type: Object,
        observer: "_focusedCellChanged",
        sync: true
      },
      /**
       * Indicates whether the grid is currently in interaction mode.
       * In interaction mode the user is currently interacting with a control,
       * such as an input or a select, within a cell.
       * In interaction mode keyboard navigation between cells is disabled.
       * Interaction mode also prevents the focus target cell of that section of
       * the grid from receiving focus, allowing the user to switch focus to
       * controls in adjacent cells, rather than focussing the outer cell
       * itself.
       * @type {boolean}
       * @private
       */
      interacting: {
        type: Boolean,
        value: false,
        reflectToAttribute: true,
        readOnly: true,
        observer: "_interactingChanged"
      }
    };
  }
  /** @private */
  get __rowFocusMode() {
    return [this._headerFocusable, this._itemsFocusable, this._footerFocusable].some(isRow);
  }
  set __rowFocusMode(value) {
    ["_itemsFocusable", "_footerFocusable", "_headerFocusable"].forEach((prop) => {
      const focusable = this[prop];
      if (value) {
        const parent = focusable && focusable.parentElement;
        if (isCell(focusable)) {
          this[prop] = parent;
        } else if (isCell(parent)) {
          this[prop] = parent.parentElement;
        }
      } else if (!value && isRow(focusable)) {
        const cell = focusable.firstElementChild;
        this[prop] = cell._focusButton || cell;
      }
    });
  }
  /** @private */
  get _visibleItemsCount() {
    return this._lastVisibleIndex - this._firstVisibleIndex - 1;
  }
  /** @protected */
  ready() {
    super.ready();
    if (this._ios || this._android) {
      return;
    }
    this.addEventListener("keydown", this._onKeyDown);
    this.addEventListener("keyup", this._onKeyUp);
    this.addEventListener("focusin", this._onFocusIn);
    this.addEventListener("focusout", this._onFocusOut);
    this.$.table.addEventListener("focusin", this._onContentFocusIn.bind(this));
    this.addEventListener("mousedown", () => {
      this.toggleAttribute("navigating", false);
      this._isMousedown = true;
      this._focusedColumnOrder = void 0;
    });
    this.addEventListener("mouseup", () => {
      this._isMousedown = false;
    });
  }
  /** @private */
  _focusableChanged(focusable, oldFocusable) {
    if (oldFocusable) {
      oldFocusable.setAttribute("tabindex", "-1");
    }
    if (focusable) {
      this._updateGridSectionFocusTarget(focusable);
    }
  }
  /** @private */
  _focusedCellChanged(focusedCell, oldFocusedCell) {
    if (oldFocusedCell) {
      removeValueFromAttribute(oldFocusedCell, "part", "focused-cell");
    }
    if (focusedCell) {
      addValueToAttribute(focusedCell, "part", "focused-cell");
    }
  }
  /** @private */
  _interactingChanged() {
    this._updateGridSectionFocusTarget(this._headerFocusable);
    this._updateGridSectionFocusTarget(this._itemsFocusable);
    this._updateGridSectionFocusTarget(this._footerFocusable);
  }
  /**
   * Since the focused cell/row state is stored as an element reference, the reference may get
   * out of sync when the virtual indexes for elements update due to effective size change.
   * This function updates the reference to the correct element after a possible index change.
   * @private
   */
  __updateItemsFocusable() {
    if (!this._itemsFocusable) {
      return;
    }
    const wasFocused = this.shadowRoot.activeElement === this._itemsFocusable;
    this._getRenderedRows().forEach((row) => {
      if (row.index === this._focusedItemIndex) {
        if (this.__rowFocusMode) {
          this._itemsFocusable = row;
        } else {
          let parent = this._itemsFocusable.parentElement;
          let cell = this._itemsFocusable;
          if (parent) {
            if (isCell(parent)) {
              cell = parent;
              parent = parent.parentElement;
            }
            const cellIndex = [...parent.children].indexOf(cell);
            this._itemsFocusable = this.__getFocusable(row, row.children[cellIndex]);
          }
        }
      }
    });
    if (wasFocused) {
      this._itemsFocusable.focus();
    }
  }
  /**
   * @param {!KeyboardEvent} e
   * @protected
   */
  _onKeyDown(e13) {
    const key = e13.key;
    let keyGroup;
    switch (key) {
      case "ArrowUp":
      case "ArrowDown":
      case "ArrowLeft":
      case "ArrowRight":
      case "PageUp":
      case "PageDown":
      case "Home":
      case "End":
        keyGroup = "Navigation";
        break;
      case "Enter":
      case "Escape":
      case "F2":
        keyGroup = "Interaction";
        break;
      case "Tab":
        keyGroup = "Tab";
        break;
      case " ":
        keyGroup = "Space";
        break;
      default:
        break;
    }
    this._detectInteracting(e13);
    if (this.interacting && keyGroup !== "Interaction") {
      keyGroup = void 0;
    }
    if (keyGroup) {
      this[`_on${keyGroup}KeyDown`](e13, key);
    }
  }
  /** @private */
  __ensureFlatIndexInViewport(index) {
    const targetRowInDom = [...this.$.items.children].find((child) => child.index === index);
    if (!targetRowInDom) {
      this._scrollToFlatIndex(index);
    } else {
      this.__scrollIntoViewport(index);
    }
  }
  /** @private */
  __isRowExpandable(row) {
    if (this.itemHasChildrenPath) {
      const item = row._item;
      return !!(item && get2(this.itemHasChildrenPath, item) && !this._isExpanded(item));
    }
  }
  /** @private */
  __isRowCollapsible(row) {
    return this._isExpanded(row._item);
  }
  /** @private */
  _onNavigationKeyDown(e13, key) {
    e13.preventDefault();
    const isRTL = this.__isRTL;
    const activeRow = e13.composedPath().find(isRow);
    const activeCell = e13.composedPath().find(isCell);
    let dx = 0, dy = 0;
    switch (key) {
      case "ArrowRight":
        dx = isRTL ? -1 : 1;
        break;
      case "ArrowLeft":
        dx = isRTL ? 1 : -1;
        break;
      case "Home":
        if (this.__rowFocusMode) {
          dy = -Infinity;
        } else if (e13.ctrlKey) {
          dy = -Infinity;
        } else {
          dx = -Infinity;
        }
        break;
      case "End":
        if (this.__rowFocusMode) {
          dy = Infinity;
        } else if (e13.ctrlKey) {
          dy = Infinity;
        } else {
          dx = Infinity;
        }
        break;
      case "ArrowDown":
        dy = 1;
        break;
      case "ArrowUp":
        dy = -1;
        break;
      case "PageDown":
        if (this.$.items.contains(activeRow)) {
          const currentRowIndex = this.__getIndexInGroup(activeRow, this._focusedItemIndex);
          this._scrollToFlatIndex(currentRowIndex);
        }
        dy = this._visibleItemsCount;
        break;
      case "PageUp":
        dy = -this._visibleItemsCount;
        break;
      default:
        break;
    }
    if (this.__rowFocusMode && !activeRow || !this.__rowFocusMode && !activeCell) {
      return;
    }
    const forwardsKey = isRTL ? "ArrowLeft" : "ArrowRight";
    const backwardsKey = isRTL ? "ArrowRight" : "ArrowLeft";
    if (key === forwardsKey) {
      if (this.__rowFocusMode) {
        if (this.__isRowExpandable(activeRow)) {
          this.expandItem(activeRow._item);
          return;
        }
        this.__rowFocusMode = false;
        this._onCellNavigation(activeRow.firstElementChild, 0, 0);
        return;
      }
    } else if (key === backwardsKey) {
      if (this.__rowFocusMode) {
        if (this.__isRowCollapsible(activeRow)) {
          this.collapseItem(activeRow._item);
          return;
        }
      } else {
        const activeRowCells = [...activeRow.children].sort((a17, b5) => a17._order - b5._order);
        if (activeCell === activeRowCells[0] || isDetailsCell(activeCell)) {
          this.__rowFocusMode = true;
          this._onRowNavigation(activeRow, 0);
          return;
        }
      }
    }
    if (this.__rowFocusMode) {
      this._onRowNavigation(activeRow, dy);
    } else {
      this._onCellNavigation(activeCell, dx, dy);
    }
  }
  /**
   * Focuses the target row after navigating by the given dy offset.
   * If the row is not in the viewport, it is first scrolled to.
   * @private
   */
  _onRowNavigation(activeRow, dy) {
    const { dstRow } = this.__navigateRows(dy, activeRow);
    if (dstRow) {
      dstRow.focus();
    }
  }
  /** @private */
  __getIndexInGroup(row, bodyFallbackIndex) {
    const rowGroup = row.parentNode;
    if (rowGroup === this.$.items) {
      return bodyFallbackIndex !== void 0 ? bodyFallbackIndex : row.index;
    }
    return [...rowGroup.children].indexOf(row);
  }
  /**
   * Returns the target row after navigating by the given dy offset.
   * Also returns information whether the details cell should be the target on the target row.
   * If the row is not in the viewport, it is first scrolled to.
   * @private
   */
  __navigateRows(dy, activeRow, activeCell) {
    const currentRowIndex = this.__getIndexInGroup(activeRow, this._focusedItemIndex);
    const activeRowGroup = activeRow.parentNode;
    const maxRowIndex = (activeRowGroup === this.$.items ? this._flatSize : activeRowGroup.children.length) - 1;
    let dstRowIndex = Math.max(0, Math.min(currentRowIndex + dy, maxRowIndex));
    if (activeRowGroup !== this.$.items) {
      if (dstRowIndex > currentRowIndex) {
        while (dstRowIndex < maxRowIndex && activeRowGroup.children[dstRowIndex].hidden) {
          dstRowIndex += 1;
        }
      } else if (dstRowIndex < currentRowIndex) {
        while (dstRowIndex > 0 && activeRowGroup.children[dstRowIndex].hidden) {
          dstRowIndex -= 1;
        }
      }
      this.toggleAttribute("navigating", true);
      return { dstRow: activeRowGroup.children[dstRowIndex] };
    }
    let dstIsRowDetails = false;
    if (activeCell) {
      const isRowDetails = isDetailsCell(activeCell);
      if (activeRowGroup === this.$.items) {
        const item = activeRow._item;
        const { item: dstItem } = this._dataProviderController.getFlatIndexContext(dstRowIndex);
        if (isRowDetails) {
          dstIsRowDetails = dy === 0;
        } else {
          dstIsRowDetails = dy === 1 && this._isDetailsOpened(item) || dy === -1 && dstRowIndex !== currentRowIndex && this._isDetailsOpened(dstItem);
        }
        if (dstIsRowDetails !== isRowDetails && (dy === 1 && dstIsRowDetails || dy === -1 && !dstIsRowDetails)) {
          dstRowIndex = currentRowIndex;
        }
      }
    }
    this.__ensureFlatIndexInViewport(dstRowIndex);
    this._focusedItemIndex = dstRowIndex;
    this.toggleAttribute("navigating", true);
    return {
      dstRow: [...activeRowGroup.children].find((el) => !el.hidden && el.index === dstRowIndex),
      dstIsRowDetails
    };
  }
  /**
   * Focuses the target cell after navigating by the given dx and dy offset.
   * If the cell is not in the viewport, it is first scrolled to.
   * @private
   */
  _onCellNavigation(activeCell, dx, dy) {
    const activeRow = activeCell.parentNode;
    const { dstRow, dstIsRowDetails } = this.__navigateRows(dy, activeRow, activeCell);
    if (!dstRow) {
      return;
    }
    let columnIndex = [...activeRow.children].indexOf(activeCell);
    if (this.$.items.contains(activeCell)) {
      columnIndex = [...this.$.sizer.children].findIndex((sizerCell) => sizerCell._column === activeCell._column);
    }
    const isCurrentCellRowDetails = isDetailsCell(activeCell);
    const activeRowGroup = activeRow.parentNode;
    const currentRowIndex = this.__getIndexInGroup(activeRow, this._focusedItemIndex);
    if (this._focusedColumnOrder === void 0) {
      if (isCurrentCellRowDetails) {
        this._focusedColumnOrder = 0;
      } else {
        this._focusedColumnOrder = this._getColumns(activeRowGroup, currentRowIndex).filter((c13) => !c13.hidden)[columnIndex]._order;
      }
    }
    if (dstIsRowDetails) {
      const dstCell = [...dstRow.children].find(isDetailsCell);
      dstCell.focus();
    } else {
      const dstRowIndex = this.__getIndexInGroup(dstRow, this._focusedItemIndex);
      const dstColumns = this._getColumns(activeRowGroup, dstRowIndex).filter((c13) => !c13.hidden);
      const dstSortedColumnOrders = dstColumns.map((c13) => c13._order).sort((b5, a17) => b5 - a17);
      const maxOrderedColumnIndex = dstSortedColumnOrders.length - 1;
      const orderedColumnIndex = dstSortedColumnOrders.indexOf(
        dstSortedColumnOrders.slice(0).sort((b5, a17) => Math.abs(b5 - this._focusedColumnOrder) - Math.abs(a17 - this._focusedColumnOrder))[0]
      );
      const dstOrderedColumnIndex = dy === 0 && isCurrentCellRowDetails ? orderedColumnIndex : Math.max(0, Math.min(orderedColumnIndex + dx, maxOrderedColumnIndex));
      if (dstOrderedColumnIndex !== orderedColumnIndex) {
        this._focusedColumnOrder = void 0;
      }
      const columnIndexByOrder = dstColumns.reduce((acc, col, i11) => {
        acc[col._order] = i11;
        return acc;
      }, {});
      const dstColumnIndex = columnIndexByOrder[dstSortedColumnOrders[dstOrderedColumnIndex]];
      let dstCell;
      if (this.$.items.contains(activeCell)) {
        const dstSizerCell = this.$.sizer.children[dstColumnIndex];
        if (this._lazyColumns) {
          if (!this.__isColumnInViewport(dstSizerCell._column)) {
            dstSizerCell.scrollIntoView();
          }
          this.__updateColumnsBodyContentHidden();
          this.__updateHorizontalScrollPosition();
        }
        dstCell = [...dstRow.children].find((cell) => cell._column === dstSizerCell._column);
        this._scrollHorizontallyToCell(dstCell);
      } else {
        dstCell = dstRow.children[dstColumnIndex];
        this._scrollHorizontallyToCell(dstCell);
      }
      dstCell.focus();
    }
  }
  /** @private */
  _onInteractionKeyDown(e13, key) {
    const localTarget = e13.composedPath()[0];
    const localTargetIsTextInput = localTarget.localName === "input" && !/^(button|checkbox|color|file|image|radio|range|reset|submit)$/iu.test(localTarget.type);
    let wantInteracting;
    switch (key) {
      case "Enter":
        wantInteracting = this.interacting ? !localTargetIsTextInput : true;
        break;
      case "Escape":
        wantInteracting = false;
        break;
      case "F2":
        wantInteracting = !this.interacting;
        break;
      default:
        break;
    }
    const { cell } = this._getGridEventLocation(e13);
    if (this.interacting !== wantInteracting && cell !== null) {
      if (wantInteracting) {
        const focusTarget = cell._content.querySelector("[focus-target]") || // If a child element hasn't been explicitly marked as a focus target,
        // fall back to any focusable element inside the cell.
        [...cell._content.querySelectorAll("*")].find((node) => this._isFocusable(node));
        if (focusTarget) {
          e13.preventDefault();
          focusTarget.focus();
          this._setInteracting(true);
          this.toggleAttribute("navigating", false);
        }
      } else {
        e13.preventDefault();
        this._focusedColumnOrder = void 0;
        cell.focus();
        this._setInteracting(false);
        this.toggleAttribute("navigating", true);
      }
    }
    if (key === "Escape") {
      this._hideTooltip(true);
    }
  }
  /** @private */
  _predictFocusStepTarget(srcElement, step) {
    const tabOrder = [
      this.$.table,
      this._headerFocusable,
      this.__emptyState ? this.$.emptystatecell : this._itemsFocusable,
      this._footerFocusable,
      this.$.focusexit
    ];
    let index = tabOrder.indexOf(srcElement);
    index += step;
    while (index >= 0 && index <= tabOrder.length - 1) {
      let rowElement = tabOrder[index];
      if (rowElement && !this.__rowFocusMode) {
        rowElement = tabOrder[index].parentNode;
      }
      if (!rowElement || rowElement.hidden) {
        index += step;
      } else {
        break;
      }
    }
    let focusStepTarget = tabOrder[index];
    if (focusStepTarget && !this.__isHorizontallyInViewport(focusStepTarget)) {
      const firstVisibleColumn = this._getColumnsInOrder().find((column) => this.__isColumnInViewport(column));
      if (firstVisibleColumn) {
        if (focusStepTarget === this._headerFocusable) {
          focusStepTarget = firstVisibleColumn._headerCell;
        } else if (focusStepTarget === this._itemsFocusable) {
          const rowIndex = focusStepTarget._column._cells.indexOf(focusStepTarget);
          focusStepTarget = firstVisibleColumn._cells[rowIndex];
        } else if (focusStepTarget === this._footerFocusable) {
          focusStepTarget = firstVisibleColumn._footerCell;
        }
      }
    }
    return focusStepTarget;
  }
  /** @private */
  _onTabKeyDown(e13) {
    let focusTarget = this._predictFocusStepTarget(e13.composedPath()[0], e13.shiftKey ? -1 : 1);
    if (!focusTarget) {
      return;
    }
    e13.stopPropagation();
    if (focusTarget === this._itemsFocusable) {
      this.__ensureFlatIndexInViewport(this._focusedItemIndex);
      this.__updateItemsFocusable();
      focusTarget = this._itemsFocusable;
    }
    focusTarget.focus();
    if (focusTarget !== this.$.table && focusTarget !== this.$.focusexit) {
      e13.preventDefault();
    }
    this.toggleAttribute("navigating", true);
  }
  /** @private */
  _onSpaceKeyDown(e13) {
    e13.preventDefault();
    const element = e13.composedPath()[0];
    const isElementRow = isRow(element);
    if (isElementRow || !element._content || !element._content.firstElementChild) {
      this.dispatchEvent(
        new CustomEvent(isElementRow ? "row-activate" : "cell-activate", {
          detail: {
            model: this.__getRowModel(isElementRow ? element : element.parentElement)
          }
        })
      );
    }
  }
  /** @private */
  _onKeyUp(e13) {
    if (!/^( |SpaceBar)$/u.test(e13.key) || this.interacting) {
      return;
    }
    e13.preventDefault();
    const cell = e13.composedPath()[0];
    if (cell._content && cell._content.firstElementChild) {
      const wasNavigating = this.hasAttribute("navigating");
      cell._content.firstElementChild.dispatchEvent(
        new MouseEvent("click", {
          shiftKey: e13.shiftKey,
          bubbles: true,
          composed: true,
          cancelable: true
        })
      );
      this.toggleAttribute("navigating", wasNavigating);
    }
  }
  /**
   * @param {!FocusEvent} e
   * @protected
   */
  _onFocusIn(e13) {
    if (!this._isMousedown) {
      this.toggleAttribute("navigating", true);
    }
    const rootTarget = e13.composedPath()[0];
    if (rootTarget === this.$.table || rootTarget === this.$.focusexit) {
      if (!this._isMousedown) {
        this._predictFocusStepTarget(rootTarget, rootTarget === this.$.table ? 1 : -1).focus();
      }
      this._setInteracting(false);
    } else {
      this._detectInteracting(e13);
    }
  }
  /**
   * @param {!FocusEvent} e
   * @protected
   */
  _onFocusOut(e13) {
    this.toggleAttribute("navigating", false);
    this._detectInteracting(e13);
    this._hideTooltip();
    this._focusedCell = null;
  }
  /** @private */
  _onContentFocusIn(e13) {
    const { section, cell, row } = this._getGridEventLocation(e13);
    if (!cell && !this.__rowFocusMode) {
      return;
    }
    this._detectInteracting(e13);
    if (section && (cell || row)) {
      this._activeRowGroup = section;
      if (section === this.$.header) {
        this._headerFocusable = this.__getFocusable(row, cell);
      } else if (section === this.$.items) {
        this._itemsFocusable = this.__getFocusable(row, cell);
        this._focusedItemIndex = row.index;
      } else if (section === this.$.footer) {
        this._footerFocusable = this.__getFocusable(row, cell);
      }
      if (cell) {
        const context = this.getEventContext(e13);
        this.__pendingBodyCellFocus = this.loading && context.section === "body";
        if (!this.__pendingBodyCellFocus && cell !== this.$.emptystatecell) {
          cell.dispatchEvent(new CustomEvent("cell-focus", { bubbles: true, composed: true, detail: { context } }));
        }
        this._focusedCell = cell._focusButton || cell;
        if (isKeyboardActive() && e13.target === cell) {
          this._showTooltip(e13);
        }
      } else {
        this._focusedCell = null;
      }
    }
  }
  /**
   * @private
   */
  __dispatchPendingBodyCellFocus() {
    if (this.__pendingBodyCellFocus && this.shadowRoot.activeElement === this._itemsFocusable) {
      this._itemsFocusable.dispatchEvent(new Event("focusin", { bubbles: true, composed: true }));
    }
  }
  /**
   * Get the focusable element depending on the current focus mode.
   * It can be a row, a cell, or a focusable div inside a cell.
   *
   * @param {HTMLElement} row
   * @param {HTMLElement} cell
   * @return {HTMLElement}
   * @private
   */
  __getFocusable(row, cell) {
    return this.__rowFocusMode ? row : cell._focusButton || cell;
  }
  /**
   * Enables interaction mode if a cells descendant receives focus or keyboard
   * input. Disables it if the event is not related to cell content.
   * @param {!KeyboardEvent|!FocusEvent} e
   * @private
   */
  _detectInteracting(e13) {
    const isInteracting = e13.composedPath().some((el) => el.localName === "slot" && this.shadowRoot.contains(el));
    this._setInteracting(isInteracting);
    this.__updateHorizontalScrollPosition();
  }
  /**
   * Enables or disables the focus target of the containing section of the
   * grid from receiving focus, based on whether the user is interacting with
   * that section of the grid.
   * @param {HTMLElement} focusTarget
   * @private
   */
  _updateGridSectionFocusTarget(focusTarget) {
    if (!focusTarget) {
      return;
    }
    const section = this._getGridSectionFromFocusTarget(focusTarget);
    const isInteractingWithinActiveSection = this.interacting && section === this._activeRowGroup;
    focusTarget.tabIndex = isInteractingWithinActiveSection ? -1 : 0;
  }
  /** @protected */
  _preventScrollerRotatingCellFocus() {
    if (this._activeRowGroup !== this.$.items) {
      return;
    }
    this.__preventScrollerRotatingCellFocusDebouncer = Debouncer.debounce(
      this.__preventScrollerRotatingCellFocusDebouncer,
      animationFrame,
      () => {
        const isItemsRowGroupActive = this._activeRowGroup === this.$.items;
        const isFocusedItemRendered = this._getRenderedRows().some((row) => row.index === this._focusedItemIndex);
        if (isFocusedItemRendered) {
          this.__updateItemsFocusable();
          if (isItemsRowGroupActive && !this.__rowFocusMode) {
            this._focusedCell = this._itemsFocusable;
          }
          if (this._navigatingIsHidden) {
            this.toggleAttribute("navigating", true);
            this._navigatingIsHidden = false;
          }
        } else if (isItemsRowGroupActive) {
          this._focusedCell = null;
          if (this.hasAttribute("navigating")) {
            this._navigatingIsHidden = true;
            this.toggleAttribute("navigating", false);
          }
        }
      }
    );
  }
  /**
   * @param {HTMLTableSectionElement=} rowGroup
   * @param {number=} rowIndex
   * @return {!Array<!GridColumn>}
   * @protected
   */
  _getColumns(rowGroup, rowIndex) {
    let columnTreeLevel = this._columnTree.length - 1;
    if (rowGroup === this.$.header) {
      columnTreeLevel = rowIndex;
    } else if (rowGroup === this.$.footer) {
      columnTreeLevel = this._columnTree.length - 1 - rowIndex;
    }
    return this._columnTree[columnTreeLevel];
  }
  /** @private */
  __isValidFocusable(element) {
    return this.$.table.contains(element) && element.offsetHeight;
  }
  /** @protected */
  _resetKeyboardNavigation() {
    if (!this.$ && this.performUpdate) {
      this.performUpdate();
    }
    ["header", "footer"].forEach((section) => {
      if (!this.__isValidFocusable(this[`_${section}Focusable`])) {
        const firstVisibleRow = [...this.$[section].children].find((row) => row.offsetHeight);
        const firstVisibleCell = firstVisibleRow ? [...firstVisibleRow.children].find((cell) => !cell.hidden) : null;
        if (firstVisibleRow && firstVisibleCell) {
          this[`_${section}Focusable`] = this.__getFocusable(firstVisibleRow, firstVisibleCell);
        }
      }
    });
    if (!this.__isValidFocusable(this._itemsFocusable) && this.$.items.firstElementChild) {
      const firstVisibleRow = this.__getFirstVisibleItem();
      const firstVisibleCell = firstVisibleRow ? [...firstVisibleRow.children].find((cell) => !cell.hidden) : null;
      if (firstVisibleCell && firstVisibleRow) {
        this._focusedColumnOrder = void 0;
        this._itemsFocusable = this.__getFocusable(firstVisibleRow, firstVisibleCell);
      }
    } else {
      this.__updateItemsFocusable();
    }
  }
  /**
   * @param {!HTMLElement} dstCell
   * @protected
   */
  _scrollHorizontallyToCell(dstCell) {
    if (dstCell.hasAttribute("frozen") || dstCell.hasAttribute("frozen-to-end") || isDetailsCell(dstCell)) {
      return;
    }
    const dstCellRect = dstCell.getBoundingClientRect();
    const dstRow = dstCell.parentNode;
    const dstCellIndex = Array.from(dstRow.children).indexOf(dstCell);
    const tableRect = this.$.table.getBoundingClientRect();
    let leftBoundary = tableRect.left, rightBoundary = tableRect.right;
    for (let i11 = dstCellIndex - 1; i11 >= 0; i11--) {
      const cell = dstRow.children[i11];
      if (cell.hasAttribute("hidden") || isDetailsCell(cell)) {
        continue;
      }
      if (cell.hasAttribute("frozen") || cell.hasAttribute("frozen-to-end")) {
        leftBoundary = cell.getBoundingClientRect().right;
        break;
      }
    }
    for (let i11 = dstCellIndex + 1; i11 < dstRow.children.length; i11++) {
      const cell = dstRow.children[i11];
      if (cell.hasAttribute("hidden") || isDetailsCell(cell)) {
        continue;
      }
      if (cell.hasAttribute("frozen") || cell.hasAttribute("frozen-to-end")) {
        rightBoundary = cell.getBoundingClientRect().left;
        break;
      }
    }
    if (dstCellRect.left < leftBoundary) {
      this.$.table.scrollLeft += Math.round(dstCellRect.left - leftBoundary);
    }
    if (dstCellRect.right > rightBoundary) {
      this.$.table.scrollLeft += Math.round(dstCellRect.right - rightBoundary);
    }
  }
  /**
   * @typedef {Object} GridEventLocation
   * @property {HTMLTableSectionElement | null} section - The table section element that the event occurred in (header, body, or footer), or null if the event did not occur in a section
   * @property {HTMLTableRowElement | null} row - The row element that the event occurred in, or null if the event did not occur in a row
   * @property {HTMLTableCellElement | null} cell - The cell element that the event occurred in, or null if the event did not occur in a cell
   * @private
   */
  /**
   * Takes an event and returns a location object describing in which part of the grid the event occurred.
   * The event may either target table section, a row, a cell or contents of a cell.
   * @param {Event} e
   * @returns {GridEventLocation}
   * @protected
   */
  _getGridEventLocation(e13) {
    const path = e13.__composedPath || e13.composedPath();
    const tableIndex = path.indexOf(this.$.table);
    const section = tableIndex >= 1 ? path[tableIndex - 1] : null;
    const row = tableIndex >= 2 ? path[tableIndex - 2] : null;
    const cell = tableIndex >= 3 ? path[tableIndex - 3] : null;
    return {
      section,
      row,
      cell
    };
  }
  /**
   * Helper method that maps a focus target cell to the containing grid section
   * @param {HTMLElement} focusTarget
   * @returns {HTMLTableSectionElement | null}
   * @private
   */
  _getGridSectionFromFocusTarget(focusTarget) {
    if (focusTarget === this._headerFocusable) {
      return this.$.header;
    }
    if (focusTarget === this._itemsFocusable) {
      return this.$.items;
    }
    if (focusTarget === this._footerFocusable) {
      return this.$.footer;
    }
    return null;
  }
  /**
   * Fired when a cell is focused with click or keyboard navigation.
   *
   * Use context property of @see {@link GridCellFocusEvent} to get detail information about the event.
   *
   * @event cell-focus
   */
};

// node_modules/@vaadin/grid/src/vaadin-grid-row-details-mixin.js
var RowDetailsMixin = (superClass) => class RowDetailsMixin extends superClass {
  static get properties() {
    return {
      /**
       * An array containing references to items with open row details.
       * @type {!Array<!GridItem>}
       */
      detailsOpenedItems: {
        type: Array,
        value: () => [],
        sync: true
      },
      /**
       * Custom function for rendering the content of the row details.
       * Receives three arguments:
       *
       * - `root` The row details content DOM element. Append your content to it.
       * - `grid` The `<vaadin-grid>` element.
       * - `model` The object with the properties related with
       *   the rendered item, contains:
       *   - `model.index` The index of the item.
       *   - `model.item` The item.
       *   - `model.level` The number of the item's tree sublevel, starts from 0.
       *   - `model.expanded` True if the item's tree sublevel is expanded.
       *   - `model.selected` True if the item is selected.
       *
       * @type {GridRowDetailsRenderer | null | undefined}
       */
      rowDetailsRenderer: {
        type: Function,
        sync: true
      },
      /**
       * @type {!Array<!HTMLElement> | undefined}
       * @protected
       */
      _detailsCells: {
        type: Array
      }
    };
  }
  static get observers() {
    return [
      "_detailsOpenedItemsChanged(detailsOpenedItems, rowDetailsRenderer)",
      "_rowDetailsRendererChanged(rowDetailsRenderer)"
    ];
  }
  /** @protected */
  ready() {
    super.ready();
    this._detailsCellResizeObserver = new ResizeObserver((entries) => {
      entries.forEach(({ target: cell }) => {
        this._updateDetailsCellHeight(cell.parentElement);
      });
      this.__virtualizer.__adapter._resizeHandler();
    });
  }
  /** @private */
  _rowDetailsRendererChanged(rowDetailsRenderer) {
    if (!rowDetailsRenderer) {
      return;
    }
    if (this._columnTree) {
      iterateChildren(this.$.items, (row) => {
        if (!row.querySelector("[part~=details-cell]")) {
          this._updateRow(row, this._columnTree[this._columnTree.length - 1]);
          const isDetailsOpened = this._isDetailsOpened(row._item);
          this._toggleDetailsCell(row, isDetailsOpened);
        }
      });
    }
  }
  /** @private */
  _detailsOpenedItemsChanged(_detailsOpenedItems, rowDetailsRenderer) {
    iterateChildren(this.$.items, (row) => {
      if (row.hasAttribute("details-opened")) {
        this._updateItem(row, row._item);
        return;
      }
      if (rowDetailsRenderer && this._isDetailsOpened(row._item)) {
        this._updateItem(row, row._item);
      }
    });
  }
  /**
   * @param {!HTMLElement} cell
   * @protected
   */
  _configureDetailsCell(cell) {
    cell.setAttribute("part", "cell details-cell");
    cell.toggleAttribute("frozen", true);
    this._detailsCellResizeObserver.observe(cell);
  }
  /**
   * @param {!HTMLElement} row
   * @param {!GridItem} item
   * @protected
   */
  _toggleDetailsCell(row, detailsOpened) {
    const cell = row.querySelector('[part~="details-cell"]');
    if (!cell) {
      return;
    }
    cell.hidden = !detailsOpened;
    if (cell.hidden) {
      return;
    }
    if (this.rowDetailsRenderer) {
      cell._renderer = this.rowDetailsRenderer;
    }
  }
  /** @protected */
  _updateDetailsCellHeight(row) {
    const cell = row.querySelector('[part~="details-cell"]');
    if (!cell) {
      return;
    }
    this.__updateDetailsRowPadding(row, cell);
    requestAnimationFrame(() => this.__updateDetailsRowPadding(row, cell));
  }
  /** @private */
  __updateDetailsRowPadding(row, cell) {
    if (cell.hidden) {
      row.style.removeProperty("padding-bottom");
    } else {
      row.style.setProperty("padding-bottom", `${cell.offsetHeight}px`);
    }
  }
  /** @protected */
  _updateDetailsCellHeights() {
    iterateChildren(this.$.items, (row) => {
      this._updateDetailsCellHeight(row);
    });
  }
  /**
   * @param {!GridItem} item
   * @return {boolean}
   * @protected
   */
  _isDetailsOpened(item) {
    return this.detailsOpenedItems && this._getItemIndexInArray(item, this.detailsOpenedItems) !== -1;
  }
  /**
   * Open the details row of a given item.
   * @param {!GridItem} item
   */
  openItemDetails(item) {
    if (!this._isDetailsOpened(item)) {
      this.detailsOpenedItems = [...this.detailsOpenedItems, item];
    }
  }
  /**
   * Close the details row of a given item.
   * @param {!GridItem} item
   */
  closeItemDetails(item) {
    if (this._isDetailsOpened(item)) {
      this.detailsOpenedItems = this.detailsOpenedItems.filter((i11) => !this._itemsEqual(i11, item));
    }
  }
};

// node_modules/@vaadin/a11y-base/src/announce.js
var region = document.createElement("div");
region.style.position = "fixed";
region.style.clip = "rect(0px, 0px, 0px, 0px)";
region.setAttribute("aria-live", "polite");
document.body.appendChild(region);
var alertDebouncer;
function announce(text, options = {}) {
  const mode = options.mode || "polite";
  const timeout = options.timeout === void 0 ? 150 : options.timeout;
  if (mode === "alert") {
    region.removeAttribute("aria-live");
    region.removeAttribute("role");
    alertDebouncer = Debouncer.debounce(alertDebouncer, animationFrame, () => {
      region.setAttribute("role", "alert");
    });
  } else {
    if (alertDebouncer) {
      alertDebouncer.cancel();
    }
    region.removeAttribute("role");
    region.setAttribute("aria-live", mode);
  }
  region.textContent = "";
  setTimeout(() => {
    region.textContent = text;
  }, timeout);
}

// node_modules/@vaadin/a11y-base/src/keyboard-mixin.js
var KeyboardMixin = dedupingMixin(
  (superclass) => class KeyboardMixinClass extends superclass {
    /** @protected */
    ready() {
      super.ready();
      this.addEventListener("keydown", (event) => {
        this._onKeyDown(event);
      });
      this.addEventListener("keyup", (event) => {
        this._onKeyUp(event);
      });
    }
    /**
     * A handler for the `keydown` event. By default, it calls
     * separate methods for handling "Enter" and "Escape" keys.
     * Override the method to implement your own behavior.
     *
     * @param {KeyboardEvent} event
     * @protected
     */
    _onKeyDown(event) {
      switch (event.key) {
        case "Enter":
          this._onEnter(event);
          break;
        case "Escape":
          this._onEscape(event);
          break;
        default:
          break;
      }
    }
    /**
     * A handler for the `keyup` event. By default, it does nothing.
     * Override the method to implement your own behavior.
     *
     * @param {KeyboardEvent} _event
     * @protected
     */
    _onKeyUp(_event) {
    }
    /**
     * A handler for the "Enter" key. By default, it does nothing.
     * Override the method to implement your own behavior.
     *
     * @param {KeyboardEvent} _event
     * @protected
     */
    _onEnter(_event) {
    }
    /**
     * A handler for the "Escape" key. By default, it does nothing.
     * Override the method to implement your own behavior.
     *
     * @param {KeyboardEvent} _event
     * @protected
     */
    _onEscape(_event) {
    }
  }
);

// node_modules/@vaadin/a11y-base/src/active-mixin.js
var ActiveMixin = (superclass) => class ActiveMixinClass extends DisabledMixin(KeyboardMixin(superclass)) {
  /**
   * An array of activation keys.
   *
   * See possible values here:
   * https://developer.mozilla.org/ru/docs/Web/API/KeyboardEvent/key/Key_Values
   *
   * @protected
   * @return {!Array<!string>}
   */
  get _activeKeys() {
    return [" "];
  }
  /** @protected */
  ready() {
    super.ready();
    addListener(this, "down", (event) => {
      if (this._shouldSetActive(event)) {
        this._setActive(true);
      }
    });
    addListener(this, "up", () => {
      this._setActive(false);
    });
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    this._setActive(false);
  }
  /**
   * @param {KeyboardEvent | MouseEvent} _event
   * @protected
   */
  _shouldSetActive(_event) {
    return !this.disabled;
  }
  /**
   * Sets the `active` attribute on the element if an activation key is pressed.
   *
   * @param {KeyboardEvent} event
   * @protected
   * @override
   */
  _onKeyDown(event) {
    super._onKeyDown(event);
    if (this._shouldSetActive(event) && this._activeKeys.includes(event.key)) {
      this._setActive(true);
      document.addEventListener(
        "keyup",
        (e13) => {
          if (this._activeKeys.includes(e13.key)) {
            this._setActive(false);
          }
        },
        { once: true }
      );
    }
  }
  /**
   * Toggles the `active` attribute on the element.
   *
   * @param {boolean} active
   * @protected
   */
  _setActive(active) {
    this.toggleAttribute("active", active);
  }
};

// node_modules/@vaadin/a11y-base/src/focus-mixin.js
var FocusMixin = dedupingMixin(
  (superclass) => class FocusMixinClass extends superclass {
    /**
     * @protected
     * @return {boolean}
     */
    get _keyboardActive() {
      return isKeyboardActive();
    }
    /** @protected */
    ready() {
      this.addEventListener("focusin", (e13) => {
        if (this._shouldSetFocus(e13)) {
          this._setFocused(true);
        }
      });
      this.addEventListener("focusout", (e13) => {
        if (this._shouldRemoveFocus(e13)) {
          this._setFocused(false);
        }
      });
      super.ready();
    }
    /** @protected */
    disconnectedCallback() {
      super.disconnectedCallback();
      if (this.hasAttribute("focused")) {
        this._setFocused(false);
      }
    }
    /**
     * Override to change how focused and focus-ring attributes are set.
     *
     * @param {boolean} focused
     * @protected
     */
    _setFocused(focused) {
      this.toggleAttribute("focused", focused);
      this.toggleAttribute("focus-ring", focused && this._keyboardActive);
    }
    /**
     * Override to define if the field receives focus based on the event.
     *
     * @param {FocusEvent} _event
     * @return {boolean}
     * @protected
     */
    _shouldSetFocus(_event) {
      return true;
    }
    /**
     * Override to define if the field loses focus based on the event.
     *
     * @param {FocusEvent} _event
     * @return {boolean}
     * @protected
     */
    _shouldRemoveFocus(_event) {
      return true;
    }
  }
);

// node_modules/@vaadin/a11y-base/src/delegate-focus-mixin.js
var DelegateFocusMixin = dedupingMixin(
  (superclass) => class DelegateFocusMixinClass extends FocusMixin(TabindexMixin(superclass)) {
    static get properties() {
      return {
        /**
         * Specify that this control should have input focus when the page loads.
         */
        autofocus: {
          type: Boolean
        },
        /**
         * A reference to the focusable element controlled by the mixin.
         * It can be an input, textarea, button or any element with tabindex > -1.
         *
         * Any component implementing this mixin is expected to provide it
         * by using `this._setFocusElement(input)` Polymer API.
         *
         * Toggling `tabindex` attribute on the host element propagates its value to `focusElement`.
         *
         * @protected
         * @type {!HTMLElement}
         */
        focusElement: {
          type: Object,
          readOnly: true,
          observer: "_focusElementChanged"
        },
        /**
         * Override the property from `TabIndexMixin`
         * to ensure the `tabindex` attribute of the focus element
         * will be restored to `0` after re-enabling the element.
         *
         * @protected
         * @override
         */
        _lastTabIndex: {
          value: 0
        }
      };
    }
    constructor() {
      super();
      this._boundOnBlur = this._onBlur.bind(this);
      this._boundOnFocus = this._onFocus.bind(this);
    }
    /** @protected */
    ready() {
      super.ready();
      if (this.autofocus && !this.disabled) {
        requestAnimationFrame(() => {
          this.focus();
          this.setAttribute("focus-ring", "");
        });
      }
    }
    /**
     * @protected
     * @override
     */
    focus() {
      if (this.focusElement && !this.disabled) {
        this.focusElement.focus();
      }
    }
    /**
     * @protected
     * @override
     */
    blur() {
      if (this.focusElement) {
        this.focusElement.blur();
      }
    }
    /**
     * @protected
     * @override
     */
    click() {
      if (this.focusElement && !this.disabled) {
        this.focusElement.click();
      }
    }
    /** @protected */
    _focusElementChanged(element, oldElement) {
      if (element) {
        element.disabled = this.disabled;
        this._addFocusListeners(element);
        this.__forwardTabIndex(this.tabindex);
      } else if (oldElement) {
        this._removeFocusListeners(oldElement);
      }
    }
    /**
     * @param {HTMLElement} element
     * @protected
     */
    _addFocusListeners(element) {
      element.addEventListener("blur", this._boundOnBlur);
      element.addEventListener("focus", this._boundOnFocus);
    }
    /**
     * @param {HTMLElement} element
     * @protected
     */
    _removeFocusListeners(element) {
      element.removeEventListener("blur", this._boundOnBlur);
      element.removeEventListener("focus", this._boundOnFocus);
    }
    /**
     * Focus event does not bubble, so we dispatch it manually
     * on the host element to support adding focus listeners
     * when the focusable element is placed in light DOM.
     * @param {FocusEvent} event
     * @protected
     */
    _onFocus(event) {
      event.stopPropagation();
      this.dispatchEvent(new Event("focus"));
    }
    /**
     * Blur event does not bubble, so we dispatch it manually
     * on the host element to support adding blur listeners
     * when the focusable element is placed in light DOM.
     * @param {FocusEvent} event
     * @protected
     */
    _onBlur(event) {
      event.stopPropagation();
      this.dispatchEvent(new Event("blur"));
    }
    /**
     * @param {FocusEvent} event
     * @return {boolean}
     * @protected
     * @override
     */
    _shouldSetFocus(event) {
      return event.target === this.focusElement;
    }
    /**
     * @param {FocusEvent} event
     * @return {boolean}
     * @protected
     * @override
     */
    _shouldRemoveFocus(event) {
      return event.target === this.focusElement;
    }
    /**
     * @param {boolean} disabled
     * @param {boolean} oldDisabled
     * @protected
     * @override
     */
    _disabledChanged(disabled, oldDisabled) {
      super._disabledChanged(disabled, oldDisabled);
      if (this.focusElement) {
        this.focusElement.disabled = disabled;
      }
      if (disabled) {
        this.blur();
      }
    }
    /**
     * Override an observer from `TabindexMixin`.
     * Do not call super to remove tabindex attribute
     * from the host after it has been forwarded.
     * @param {string} tabindex
     * @protected
     * @override
     */
    _tabindexChanged(tabindex) {
      this.__forwardTabIndex(tabindex);
    }
    /** @private */
    __forwardTabIndex(tabindex) {
      if (tabindex !== void 0 && this.focusElement) {
        this.focusElement.tabIndex = tabindex;
        if (tabindex !== -1) {
          this.tabindex = void 0;
        }
      }
      if (this.disabled && tabindex) {
        if (tabindex !== -1) {
          this._lastTabIndex = tabindex;
        }
        this.tabindex = void 0;
      }
    }
  }
);

// node_modules/@vaadin/a11y-base/src/aria-id-reference.js
var attributeToTargets = /* @__PURE__ */ new Map();
function getAttrMap(attr) {
  if (!attributeToTargets.has(attr)) {
    attributeToTargets.set(attr, /* @__PURE__ */ new WeakMap());
  }
  return attributeToTargets.get(attr);
}
function cleanAriaIDReference(target, attr) {
  if (!target) {
    return;
  }
  target.removeAttribute(attr);
}
function storeAriaIDReference(target, attr) {
  if (!target || !attr) {
    return;
  }
  const attributeMap = getAttrMap(attr);
  if (attributeMap.has(target)) {
    return;
  }
  const values = deserializeAttributeValue(target.getAttribute(attr));
  attributeMap.set(target, new Set(values));
}
function restoreGeneratedAriaIDReference(target, attr) {
  if (!target || !attr) {
    return;
  }
  const attributeMap = getAttrMap(attr);
  const values = attributeMap.get(target);
  if (!values || values.size === 0) {
    target.removeAttribute(attr);
  } else {
    addValueToAttribute(target, attr, serializeAttributeValue(values));
  }
  attributeMap.delete(target);
}
function setAriaIDReference(target, attr, config = { newId: null, oldId: null, fromUser: false }) {
  if (!target || !attr) {
    return;
  }
  const { newId, oldId, fromUser } = config;
  const attributeMap = getAttrMap(attr);
  const storedValues = attributeMap.get(target);
  if (!fromUser && !!storedValues) {
    oldId && storedValues.delete(oldId);
    newId && storedValues.add(newId);
    return;
  }
  if (fromUser) {
    if (!storedValues) {
      storeAriaIDReference(target, attr);
    } else if (!newId) {
      attributeMap.delete(target);
    }
    cleanAriaIDReference(target, attr);
  }
  removeValueFromAttribute(target, attr, oldId);
  const attributeValue = !newId ? serializeAttributeValue(storedValues) : newId;
  if (attributeValue) {
    addValueToAttribute(target, attr, attributeValue);
  }
}
function removeAriaIDReference(target, attr) {
  storeAriaIDReference(target, attr);
  cleanAriaIDReference(target, attr);
}

// node_modules/@vaadin/a11y-base/src/field-aria-controller.js
var FieldAriaController = class {
  constructor(host) {
    this.host = host;
    this.__required = false;
  }
  /**
   * Sets a target element to which ARIA attributes are added.
   *
   * @param {HTMLElement} target
   */
  setTarget(target) {
    this.__target = target;
    this.__setAriaRequiredAttribute(this.__required);
    this.__setLabelIdToAriaAttribute(this.__labelId, this.__labelId);
    if (this.__labelIdFromUser != null) {
      this.__setLabelIdToAriaAttribute(this.__labelIdFromUser, this.__labelIdFromUser, true);
    }
    this.__setErrorIdToAriaAttribute(this.__errorId);
    this.__setHelperIdToAriaAttribute(this.__helperId);
    this.setAriaLabel(this.__label);
  }
  /**
   * Toggles the `aria-required` attribute on the target element
   * if the target is the host component (e.g. a field group).
   * Otherwise, it does nothing.
   *
   * @param {boolean} required
   */
  setRequired(required) {
    this.__setAriaRequiredAttribute(required);
    this.__required = required;
  }
  /**
   * Defines the `aria-label` attribute of the target element.
   *
   * To remove the attribute, pass `null` as `label`.
   *
   * @param {string | null | undefined} label
   */
  setAriaLabel(label) {
    this.__setAriaLabelToAttribute(label);
    this.__label = label;
  }
  /**
   * Links the target element with a slotted label element
   * via the target's attribute `aria-labelledby`.
   *
   * To unlink the previous slotted label element, pass `null` as `labelId`.
   *
   * @param {string | null} labelId
   */
  setLabelId(labelId, fromUser = false) {
    const oldLabelId = fromUser ? this.__labelIdFromUser : this.__labelId;
    this.__setLabelIdToAriaAttribute(labelId, oldLabelId, fromUser);
    if (fromUser) {
      this.__labelIdFromUser = labelId;
    } else {
      this.__labelId = labelId;
    }
  }
  /**
   * Links the target element with a slotted error element via the target's attribute:
   * - `aria-labelledby` if the target is the host component (e.g a field group).
   * - `aria-describedby` otherwise.
   *
   * To unlink the previous slotted error element, pass `null` as `errorId`.
   *
   * @param {string | null} errorId
   */
  setErrorId(errorId) {
    this.__setErrorIdToAriaAttribute(errorId, this.__errorId);
    this.__errorId = errorId;
  }
  /**
   * Links the target element with a slotted helper element via the target's attribute:
   * - `aria-labelledby` if the target is the host component (e.g a field group).
   * - `aria-describedby` otherwise.
   *
   * To unlink the previous slotted helper element, pass `null` as `helperId`.
   *
   * @param {string | null} helperId
   */
  setHelperId(helperId) {
    this.__setHelperIdToAriaAttribute(helperId, this.__helperId);
    this.__helperId = helperId;
  }
  /**
   * @param {string | null | undefined} label
   * @private
   * */
  __setAriaLabelToAttribute(label) {
    if (!this.__target) {
      return;
    }
    if (label) {
      removeAriaIDReference(this.__target, "aria-labelledby");
      this.__target.setAttribute("aria-label", label);
    } else if (this.__label) {
      restoreGeneratedAriaIDReference(this.__target, "aria-labelledby");
      this.__target.removeAttribute("aria-label");
    }
  }
  /**
   * @param {string | null | undefined} labelId
   * @param {string | null | undefined} oldLabelId
   * @param {boolean | null | undefined} fromUser
   * @private
   */
  __setLabelIdToAriaAttribute(labelId, oldLabelId, fromUser) {
    setAriaIDReference(this.__target, "aria-labelledby", { newId: labelId, oldId: oldLabelId, fromUser });
  }
  /**
   * @param {string | null | undefined} errorId
   * @param {string | null | undefined} oldErrorId
   * @private
   */
  __setErrorIdToAriaAttribute(errorId, oldErrorId) {
    setAriaIDReference(this.__target, "aria-describedby", { newId: errorId, oldId: oldErrorId, fromUser: false });
  }
  /**
   * @param {string | null | undefined} helperId
   * @param {string | null | undefined} oldHelperId
   * @private
   */
  __setHelperIdToAriaAttribute(helperId, oldHelperId) {
    setAriaIDReference(this.__target, "aria-describedby", { newId: helperId, oldId: oldHelperId, fromUser: false });
  }
  /**
   * @param {boolean} required
   * @private
   */
  __setAriaRequiredAttribute(required) {
    if (!this.__target) {
      return;
    }
    if (["input", "textarea"].includes(this.__target.localName)) {
      return;
    }
    if (required) {
      this.__target.setAttribute("aria-required", "true");
    } else {
      this.__target.removeAttribute("aria-required");
    }
  }
};

// node_modules/@vaadin/component-base/src/dir-utils.js
function getNormalizedScrollLeft(element, direction) {
  const { scrollLeft } = element;
  if (direction !== "rtl") {
    return scrollLeft;
  }
  return element.scrollWidth - element.clientWidth + scrollLeft;
}

// node_modules/@vaadin/component-base/src/resize-mixin.js
var observer = new ResizeObserver((entries) => {
  setTimeout(() => {
    entries.forEach((entry) => {
      if (entry.target.resizables) {
        entry.target.resizables.forEach((resizable) => {
          resizable._onResize(entry.contentRect);
        });
      } else {
        entry.target._onResize(entry.contentRect);
      }
    });
  });
});
var ResizeMixin = dedupingMixin(
  (superclass) => class ResizeMixinClass extends superclass {
    /**
     * When true, the parent element resize will be also observed.
     * Override this getter and return `true` to enable this.
     *
     * @protected
     */
    get _observeParent() {
      return false;
    }
    /** @protected */
    connectedCallback() {
      super.connectedCallback();
      observer.observe(this);
      if (this._observeParent) {
        const parent = this.parentNode instanceof ShadowRoot ? this.parentNode.host : this.parentNode;
        if (!parent.resizables) {
          parent.resizables = /* @__PURE__ */ new Set();
          observer.observe(parent);
        }
        parent.resizables.add(this);
        this.__parent = parent;
      }
    }
    /** @protected */
    disconnectedCallback() {
      super.disconnectedCallback();
      observer.unobserve(this);
      const parent = this.__parent;
      if (this._observeParent && parent) {
        const resizables = parent.resizables;
        if (resizables) {
          resizables.delete(this);
          if (resizables.size === 0) {
            observer.unobserve(parent);
          }
        }
        this.__parent = null;
      }
    }
    /**
     * A handler invoked on host resize. By default, it does nothing.
     * Override the method to implement your own behavior.
     *
     * @protected
     */
    _onResize(_contentRect) {
    }
  }
);

// node_modules/@vaadin/grid/src/vaadin-grid-scroll-mixin.js
var timeouts = {
  SCROLLING: 500,
  UPDATE_CONTENT_VISIBILITY: 100
};
var ScrollMixin = (superClass) => class ScrollMixin extends ResizeMixin(superClass) {
  static get properties() {
    return {
      /**
       * Allows you to choose between modes for rendering columns in the grid:
       *
       * "eager" (default): All columns are rendered upfront, regardless of their visibility within the viewport.
       * This mode should generally be preferred, as it avoids the limitations imposed by the "lazy" mode.
       * Use this mode unless the grid has a large number of columns and performance outweighs the limitations
       * in priority.
       *
       * "lazy": Optimizes the rendering of cells when there are multiple columns in the grid by virtualizing
       * horizontal scrolling. In this mode, body cells are rendered only when their corresponding columns are
       * inside the visible viewport.
       *
       * Using "lazy" rendering should be used only if you're dealing with a large number of columns and performance
       * is your highest priority. For most use cases, the default "eager" mode is recommended due to the
       * limitations imposed by the "lazy" mode.
       *
       * When using the "lazy" mode, keep the following limitations in mind:
       *
       * - Row Height: When only a number of columns are visible at once, the height of a row can only be that of
       * the highest cell currently visible on that row. Make sure each cell on a single row has the same height
       * as all other cells on that row. If row cells have different heights, users may experience jumpiness when
       * scrolling the grid horizontally as lazily rendered cells with different heights are scrolled into view.
       *
       * - Auto-width Columns: For the columns that are initially outside the visible viewport but still use auto-width,
       * only the header content is taken into account when calculating the column width because the body cells
       * of the columns outside the viewport are not initially rendered.
       *
       * - Screen Reader Compatibility: Screen readers may not be able to associate the focused cells with the correct
       * headers when only a subset of the body cells on a row is rendered.
       *
       * - Keyboard Navigation: Tabbing through focusable elements inside the grid body may not work as expected because
       * some of the columns that would include focusable elements in the body cells may be outside the visible viewport
       * and thus not rendered.
       *
       * @attr {eager|lazy} column-rendering
       * @type {!ColumnRendering}
       */
      columnRendering: {
        type: String,
        value: "eager",
        sync: true
      },
      /**
       * Cached array of frozen cells
       * @private
       */
      _frozenCells: {
        type: Array,
        value: () => []
      },
      /**
       * Cached array of cells frozen to end
       * @private
       */
      _frozenToEndCells: {
        type: Array,
        value: () => []
      }
    };
  }
  static get observers() {
    return ["__columnRenderingChanged(_columnTree, columnRendering)"];
  }
  /** @private */
  get _scrollLeft() {
    return this.$.table.scrollLeft;
  }
  /** @private */
  get _scrollTop() {
    return this.$.table.scrollTop;
  }
  /**
   * Override (from iron-scroll-target-behavior) to avoid document scroll
   * @private
   */
  set _scrollTop(top) {
    this.$.table.scrollTop = top;
  }
  /** @protected */
  get _lazyColumns() {
    return this.columnRendering === "lazy";
  }
  /** @protected */
  ready() {
    super.ready();
    this.scrollTarget = this.$.table;
    this.$.items.addEventListener("focusin", (e13) => {
      const composedPath = e13.composedPath();
      const row = composedPath[composedPath.indexOf(this.$.items) - 1];
      if (row) {
        if (!this._isMousedown) {
          this.__scrollIntoViewport(row.index);
        }
        if (!this.$.table.contains(e13.relatedTarget)) {
          this.$.table.dispatchEvent(new CustomEvent("virtualizer-element-focused", { detail: { element: row } }));
        }
      }
    });
    this.$.table.addEventListener("scroll", () => this._afterScroll());
  }
  /**
   * @protected
   * @override
   */
  _onResize() {
    this._updateOverflow();
    this.__updateHorizontalScrollPosition();
    if (this._firefox) {
      const isVisible = !isElementHidden(this);
      if (isVisible && this.__previousVisible === false) {
        this._scrollTop = this.__memorizedScrollTop || 0;
      }
      this.__previousVisible = isVisible;
    }
  }
  /**
   * Scroll to a flat index in the grid. The method doesn't take into account
   * the hierarchy of the items.
   *
   * @param {number} index Row index to scroll to
   * @protected
   */
  _scrollToFlatIndex(index) {
    index = Math.min(this._flatSize - 1, Math.max(0, index));
    this.__virtualizer.scrollToIndex(index);
    this.__scrollIntoViewport(index);
  }
  /**
   * Makes sure the row with the given index (if found in the DOM) is fully
   * inside the visible viewport, taking header/footer into account.
   * @private
   */
  __scrollIntoViewport(index) {
    const rowElement = [...this.$.items.children].find((child) => child.index === index);
    if (rowElement) {
      const dstRect = rowElement.getBoundingClientRect();
      const footerTop = this.$.footer.getBoundingClientRect().top;
      const headerBottom = this.$.header.getBoundingClientRect().bottom;
      if (dstRect.bottom > footerTop) {
        this.$.table.scrollTop += dstRect.bottom - footerTop;
      } else if (dstRect.top < headerBottom) {
        this.$.table.scrollTop -= headerBottom - dstRect.top;
      }
    }
  }
  /** @private */
  _scheduleScrolling() {
    if (!this._scrollingFrame) {
      this._scrollingFrame = requestAnimationFrame(() => this.$.scroller.toggleAttribute("scrolling", true));
    }
    this._debounceScrolling = Debouncer.debounce(this._debounceScrolling, timeOut.after(timeouts.SCROLLING), () => {
      cancelAnimationFrame(this._scrollingFrame);
      delete this._scrollingFrame;
      this.$.scroller.toggleAttribute("scrolling", false);
    });
  }
  /** @private */
  _afterScroll() {
    this.__updateHorizontalScrollPosition();
    if (!this.hasAttribute("reordering")) {
      this._scheduleScrolling();
    }
    if (!this.hasAttribute("navigating")) {
      this._hideTooltip(true);
    }
    this._updateOverflow();
    this._debounceColumnContentVisibility = Debouncer.debounce(
      this._debounceColumnContentVisibility,
      timeOut.after(timeouts.UPDATE_CONTENT_VISIBILITY),
      () => {
        if (this._lazyColumns && this.__cachedScrollLeft !== this._scrollLeft) {
          this.__cachedScrollLeft = this._scrollLeft;
          this.__updateColumnsBodyContentHidden();
        }
      }
    );
    if (this._firefox) {
      const isVisible = !isElementHidden(this);
      if (isVisible && this.__previousVisible !== false) {
        this.__memorizedScrollTop = this._scrollTop;
      }
    }
  }
  /** @private */
  __updateColumnsBodyContentHidden() {
    if (!this._columnTree || !this._areSizerCellsAssigned()) {
      return;
    }
    const columnsInOrder = this._getColumnsInOrder();
    let bodyContentHiddenChanged = false;
    columnsInOrder.forEach((column) => {
      const bodyContentHidden = this._lazyColumns && !this.__isColumnInViewport(column);
      if (column._bodyContentHidden !== bodyContentHidden) {
        bodyContentHiddenChanged = true;
        column._cells.forEach((cell) => {
          if (cell !== column._sizerCell) {
            if (bodyContentHidden) {
              cell.remove();
            } else if (cell.__parentRow) {
              const followingColumnCell = [...cell.__parentRow.children].find(
                (child) => columnsInOrder.indexOf(child._column) > columnsInOrder.indexOf(column)
              );
              cell.__parentRow.insertBefore(cell, followingColumnCell);
            }
          }
        });
      }
      column._bodyContentHidden = bodyContentHidden;
    });
    if (bodyContentHiddenChanged) {
      this._frozenCellsChanged();
    }
    if (this._lazyColumns) {
      const lastFrozenColumn = [...columnsInOrder].reverse().find((column) => column.frozen);
      const lastFrozenColumnEnd = this.__getColumnEnd(lastFrozenColumn);
      const firstVisibleColumn = columnsInOrder.find((column) => !column.frozen && !column._bodyContentHidden);
      this.__lazyColumnsStart = this.__getColumnStart(firstVisibleColumn) - lastFrozenColumnEnd;
      this.$.items.style.setProperty("--_grid-lazy-columns-start", `${this.__lazyColumnsStart}px`);
      this._resetKeyboardNavigation();
    }
  }
  /** @private */
  __getColumnEnd(column) {
    if (!column) {
      return this.__isRTL ? this.$.table.clientWidth : 0;
    }
    return column._sizerCell.offsetLeft + (this.__isRTL ? 0 : column._sizerCell.offsetWidth);
  }
  /** @private */
  __getColumnStart(column) {
    if (!column) {
      return this.__isRTL ? this.$.table.clientWidth : 0;
    }
    return column._sizerCell.offsetLeft + (this.__isRTL ? column._sizerCell.offsetWidth : 0);
  }
  /**
   * Returns true if the given column is horizontally inside the viewport.
   * @private
   */
  __isColumnInViewport(column) {
    if (column.frozen || column.frozenToEnd) {
      return true;
    }
    return this.__isHorizontallyInViewport(column._sizerCell);
  }
  /** @private */
  __isHorizontallyInViewport(element) {
    return element.offsetLeft + element.offsetWidth >= this._scrollLeft && element.offsetLeft <= this._scrollLeft + this.clientWidth;
  }
  /** @private */
  __columnRenderingChanged(_columnTree, columnRendering) {
    if (columnRendering === "eager") {
      this.$.scroller.removeAttribute("column-rendering");
    } else {
      this.$.scroller.setAttribute("column-rendering", columnRendering);
    }
    this.__updateColumnsBodyContentHidden();
  }
  /** @private */
  _updateOverflow() {
    this._debounceOverflow = Debouncer.debounce(this._debounceOverflow, animationFrame, () => {
      this.__doUpdateOverflow();
    });
  }
  /** @private */
  __doUpdateOverflow() {
    let overflow = "";
    const table = this.$.table;
    if (table.scrollTop < table.scrollHeight - table.clientHeight) {
      overflow += " bottom";
    }
    if (table.scrollTop > 0) {
      overflow += " top";
    }
    const scrollLeft = getNormalizedScrollLeft(table, this.getAttribute("dir"));
    if (scrollLeft > 0) {
      overflow += " start";
    }
    if (scrollLeft < table.scrollWidth - table.clientWidth) {
      overflow += " end";
    }
    if (this.__isRTL) {
      overflow = overflow.replace(/start|end/giu, (matched) => {
        return matched === "start" ? "end" : "start";
      });
    }
    if (table.scrollLeft < table.scrollWidth - table.clientWidth) {
      overflow += " right";
    }
    if (table.scrollLeft > 0) {
      overflow += " left";
    }
    const value = overflow.trim();
    if (value.length > 0 && this.getAttribute("overflow") !== value) {
      this.setAttribute("overflow", value);
    } else if (value.length === 0 && this.hasAttribute("overflow")) {
      this.removeAttribute("overflow");
    }
  }
  /** @protected */
  _frozenCellsChanged() {
    this._debouncerCacheElements = Debouncer.debounce(this._debouncerCacheElements, microTask2, () => {
      Array.from(this.shadowRoot.querySelectorAll('[part~="cell"]')).forEach((cell) => {
        cell.style.transform = "";
      });
      this._frozenCells = Array.prototype.slice.call(this.$.table.querySelectorAll("[frozen]"));
      this._frozenToEndCells = Array.prototype.slice.call(this.$.table.querySelectorAll("[frozen-to-end]"));
      this.__updateHorizontalScrollPosition();
    });
    this._debounceUpdateFrozenColumn();
  }
  /** @protected */
  _debounceUpdateFrozenColumn() {
    this.__debounceUpdateFrozenColumn = Debouncer.debounce(
      this.__debounceUpdateFrozenColumn,
      microTask2,
      () => this._updateFrozenColumn()
    );
  }
  /** @private */
  _updateFrozenColumn() {
    if (!this._columnTree) {
      return;
    }
    const columnsRow = this._columnTree[this._columnTree.length - 1].slice(0);
    columnsRow.sort((a17, b5) => {
      return a17._order - b5._order;
    });
    let lastFrozen;
    let firstFrozenToEnd;
    for (let i11 = 0; i11 < columnsRow.length; i11++) {
      const col = columnsRow[i11];
      col._lastFrozen = false;
      col._firstFrozenToEnd = false;
      if (firstFrozenToEnd === void 0 && col.frozenToEnd && !col.hidden) {
        firstFrozenToEnd = i11;
      }
      if (col.frozen && !col.hidden) {
        lastFrozen = i11;
      }
    }
    if (lastFrozen !== void 0) {
      columnsRow[lastFrozen]._lastFrozen = true;
    }
    if (firstFrozenToEnd !== void 0) {
      columnsRow[firstFrozenToEnd]._firstFrozenToEnd = true;
    }
    this.__updateColumnsBodyContentHidden();
  }
  /** @private */
  __updateHorizontalScrollPosition() {
    if (!this._columnTree) {
      return;
    }
    const scrollWidth = this.$.table.scrollWidth;
    const clientWidth = this.$.table.clientWidth;
    const scrollLeft = Math.max(0, this.$.table.scrollLeft);
    const normalizedScrollLeft = getNormalizedScrollLeft(this.$.table, this.getAttribute("dir"));
    const transform = `translate(${-scrollLeft}px, 0)`;
    this.$.header.style.transform = transform;
    this.$.footer.style.transform = transform;
    this.$.items.style.transform = transform;
    const x2 = this.__isRTL ? normalizedScrollLeft + clientWidth - scrollWidth : scrollLeft;
    const transformFrozen = `translate(${x2}px, 0)`;
    this._frozenCells.forEach((cell) => {
      cell.style.transform = transformFrozen;
    });
    const remaining = this.__isRTL ? normalizedScrollLeft : scrollLeft + clientWidth - scrollWidth;
    const transformFrozenToEnd = `translate(${remaining}px, 0)`;
    let transformFrozenToEndBody = transformFrozenToEnd;
    if (this._lazyColumns && this._areSizerCellsAssigned()) {
      const columnsInOrder = this._getColumnsInOrder();
      const lastVisibleColumn = [...columnsInOrder].reverse().find((column) => !column.frozenToEnd && !column._bodyContentHidden);
      const lastVisibleColumnEnd = this.__getColumnEnd(lastVisibleColumn);
      const firstFrozenToEndColumn = columnsInOrder.find((column) => column.frozenToEnd);
      const firstFrozenToEndColumnStart = this.__getColumnStart(firstFrozenToEndColumn);
      const translateX = remaining + (firstFrozenToEndColumnStart - lastVisibleColumnEnd) + this.__lazyColumnsStart;
      transformFrozenToEndBody = `translate(${translateX}px, 0)`;
    }
    this._frozenToEndCells.forEach((cell) => {
      if (this.$.items.contains(cell)) {
        cell.style.transform = transformFrozenToEndBody;
      } else {
        cell.style.transform = transformFrozenToEnd;
      }
    });
    if (this.hasAttribute("navigating") && this.__rowFocusMode) {
      this.$.table.style.setProperty("--_grid-horizontal-scroll-position", `${-x2}px`);
    }
  }
  /** @private */
  _areSizerCellsAssigned() {
    return this._getColumnsInOrder().every((column) => column._sizerCell);
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-selection-mixin.js
var SelectionMixin = (superClass) => class SelectionMixin extends superClass {
  static get properties() {
    return {
      /**
       * An array that contains the selected items.
       * @type {!Array<!GridItem>}
       */
      selectedItems: {
        type: Object,
        notify: true,
        value: () => [],
        sync: true
      },
      /**
       * A function to check whether a specific item in the grid may be
       * selected or deselected by the user. Used by the selection column to
       * conditionally enable to disable checkboxes for individual items. This
       * function does not prevent programmatic selection/deselection of
       * items. Changing the function does not modify the currently selected
       * items.
       *
       * Configuring this function hides the select all checkbox of the grid
       * selection column, which means users can not select or deselect all
       * items anymore, nor do they get feedback on whether all items are
       * selected or not.
       *
       * Receives an item instance and should return a boolean indicating
       * whether users may change the selection state of that item.
       *
       * @type {(item: !GridItem) => boolean}
       */
      isItemSelectable: {
        type: Function,
        notify: /* @__PURE__ */ (() => true)()
        // prevent Polymer analyzer from documenting a changed event
      },
      /**
       * Set of selected item ids
       * @private
       */
      __selectedKeys: {
        type: Object,
        computed: "__computeSelectedKeys(itemIdPath, selectedItems)"
      }
    };
  }
  static get observers() {
    return ["__selectedItemsChanged(itemIdPath, selectedItems, isItemSelectable)"];
  }
  /**
   * @param {!GridItem} item
   * @return {boolean}
   * @protected
   */
  _isSelected(item) {
    return this.__selectedKeys.has(this.getItemId(item));
  }
  /**
   * Determines whether the selection state of an item may be changed by the
   * user.
   *
   * @private
   */
  __isItemSelectable(item) {
    if (!this.isItemSelectable || !item) {
      return true;
    }
    return this.isItemSelectable(item);
  }
  /**
   * Selects the given item.
   *
   * @method selectItem
   * @param {!GridItem} item The item object
   */
  selectItem(item) {
    if (!this._isSelected(item)) {
      this.selectedItems = [...this.selectedItems, item];
    }
  }
  /**
   * Deselects the given item if it is already selected.
   *
   * @method deselect
   * @param {!GridItem} item The item object
   */
  deselectItem(item) {
    if (this._isSelected(item)) {
      this.selectedItems = this.selectedItems.filter((i11) => !this._itemsEqual(i11, item));
    }
  }
  /** @private */
  __selectedItemsChanged() {
    this.requestContentUpdate();
  }
  /** @private */
  __computeSelectedKeys(_itemIdPath, selectedItems) {
    const selected = selectedItems || [];
    const selectedKeys = /* @__PURE__ */ new Set();
    selected.forEach((item) => {
      selectedKeys.add(this.getItemId(item));
    });
    return selectedKeys;
  }
  /**
   * Fired when the `selectedItems` property changes.
   *
   * @event selected-items-changed
   */
};

// node_modules/@vaadin/grid/src/vaadin-grid-sort-mixin.js
var defaultMultiSortPriority = "prepend";
var SortMixin = (superClass) => class SortMixin extends superClass {
  static get properties() {
    return {
      /**
       * When `true`, all `<vaadin-grid-sorter>` are applied for sorting.
       * @attr {boolean} multi-sort
       * @type {boolean}
       */
      multiSort: {
        type: Boolean,
        value: false
      },
      /**
       * Controls how columns are added to the sort order when using multi-sort.
       * The sort order is visually indicated by numbers in grid sorters placed in column headers.
       *
       * By default, whenever an unsorted column is sorted, or the sort-direction of a column is
       * changed, that column gets sort priority 1, thus affecting the priority for all the other
       * sorted columns. This is identical to using `multi-sort-priority="prepend"`.
       *
       * Using this property allows to change this behavior so that sorting an unsorted column
       * would add it to the "end" of the sort, and changing column's sort direction would retain
       * it's previous priority. To set this, use `multi-sort-priority="append"`.
       *
       * @attr {string} multi-sort-priority
       */
      multiSortPriority: {
        type: String,
        value: () => defaultMultiSortPriority
      },
      /**
       * When `true`, Shift-clicking an unsorted column's sorter adds it to the multi-sort.
       * Shift + Space does the same action via keyboard. This property has precedence over the
       * `multiSort` property. If `multiSortOnShiftClick` is true, the multiSort property is effectively ignored.
       *
       * @attr {boolean} multi-sort-on-shift-click
       * @type {boolean}
       */
      multiSortOnShiftClick: {
        type: Boolean,
        value: false
      },
      /**
       * @type {!Array<!GridSorterDefinition>}
       * @protected
       */
      _sorters: {
        type: Array,
        value: () => []
      },
      /** @private */
      _previousSorters: {
        type: Array,
        value: () => []
      }
    };
  }
  /**
   * Sets the default multi-sort priority to use for all grid instances.
   * This method should be called before creating any grid instances.
   * Changing this setting does not affect the default for existing grids.
   *
   * @param {string} priority
   */
  static setDefaultMultiSortPriority(priority) {
    defaultMultiSortPriority = ["append", "prepend"].includes(priority) ? priority : "prepend";
  }
  /** @protected */
  ready() {
    super.ready();
    this.addEventListener("sorter-changed", this._onSorterChanged);
  }
  /** @private */
  _onSorterChanged(e13) {
    const sorter = e13.target;
    e13.stopPropagation();
    sorter._grid = this;
    this.__updateSorter(sorter, e13.detail.shiftClick, e13.detail.fromSorterClick);
    this.__applySorters();
  }
  /** @private */
  __removeSorters(sortersToRemove) {
    if (sortersToRemove.length === 0) {
      return;
    }
    this._sorters = this._sorters.filter((sorter) => !sortersToRemove.includes(sorter));
    this.__applySorters();
  }
  /** @private */
  __updateSortOrders() {
    this._sorters.forEach((sorter) => {
      sorter._order = null;
    });
    const activeSorters = this._getActiveSorters();
    if (activeSorters.length > 1) {
      activeSorters.forEach((sorter, index) => {
        sorter._order = index;
      });
    }
  }
  /** @private */
  __updateSorter(sorter, shiftClick, fromSorterClick) {
    if (!sorter.direction && !this._sorters.includes(sorter)) {
      return;
    }
    sorter._order = null;
    const restSorters = this._sorters.filter((s18) => s18 !== sorter);
    if (this.multiSort && (!this.multiSortOnShiftClick || !fromSorterClick) || this.multiSortOnShiftClick && shiftClick) {
      if (this.multiSortPriority === "append") {
        this._sorters = [...restSorters, sorter];
      } else {
        this._sorters = [sorter, ...restSorters];
      }
    } else if (sorter.direction || this.multiSortOnShiftClick) {
      this._sorters = sorter.direction ? [sorter] : [];
      restSorters.forEach((sorter2) => {
        sorter2._order = null;
        sorter2.direction = null;
      });
    }
  }
  /** @private */
  __applySorters() {
    this.__updateSortOrders();
    if (this.dataProvider && // No need to clear cache if sorters didn't change and grid is attached
    this.isAttached && JSON.stringify(this._previousSorters) !== JSON.stringify(this._mapSorters())) {
      this.__debounceClearCache();
    }
    this._a11yUpdateSorters();
    this._previousSorters = this._mapSorters();
  }
  /**
   * @type {GridSorterDefinition[]}
   * @protected
   */
  _getActiveSorters() {
    return this._sorters.filter((sorter) => sorter.direction && sorter.isConnected);
  }
  /**
   * @return {!Array<!GridSorterDefinition>}
   * @protected
   */
  _mapSorters() {
    return this._getActiveSorters().map((sorter) => {
      return {
        path: sorter.path,
        direction: sorter.direction
      };
    });
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-styling-mixin.js
var StylingMixin = (superClass) => class StylingMixin extends superClass {
  static get properties() {
    return {
      /**
       * A function that allows generating CSS class names for grid cells
       * based on their row and column. The return value should be the generated
       * class name as a string, or multiple class names separated by whitespace
       * characters.
       *
       * Receives two arguments:
       * - `column` The `<vaadin-grid-column>` element (`undefined` for details-cell).
       * - `model` The object with the properties related with
       *   the rendered item, contains:
       *   - `model.index` The index of the item.
       *   - `model.item` The item.
       *   - `model.expanded` Sublevel toggle state.
       *   - `model.level` Level of the tree represented with a horizontal offset of the toggle button.
       *   - `model.selected` Selected state.
       *
       * @type {GridCellClassNameGenerator | null | undefined}
       * @deprecated Use `cellPartNameGenerator` instead.
       */
      cellClassNameGenerator: {
        type: Function,
        sync: true
      },
      /**
       * A function that allows generating CSS `part` names for grid cells in Shadow DOM based
       * on their row and column, for styling from outside using the `::part()` selector.
       *
       * The return value should be the generated part name as a string, or multiple part names
       * separated by whitespace characters.
       *
       * Receives two arguments:
       * - `column` The `<vaadin-grid-column>` element (`undefined` for details-cell).
       * - `model` The object with the properties related with
       *   the rendered item, contains:
       *   - `model.index` The index of the item.
       *   - `model.item` The item.
       *   - `model.expanded` Sublevel toggle state.
       *   - `model.level` Level of the tree represented with a horizontal offset of the toggle button.
       *   - `model.selected` Selected state.
       *
       * @type {GridCellPartNameGenerator | null | undefined}
       */
      cellPartNameGenerator: {
        type: Function,
        sync: true
      }
    };
  }
  static get observers() {
    return [
      "__cellClassNameGeneratorChanged(cellClassNameGenerator)",
      "__cellPartNameGeneratorChanged(cellPartNameGenerator)"
    ];
  }
  /** @private */
  __cellClassNameGeneratorChanged() {
    this.generateCellClassNames();
  }
  /** @private */
  __cellPartNameGeneratorChanged() {
    this.generateCellPartNames();
  }
  /**
   * Runs the `cellClassNameGenerator` for the visible cells.
   * If the generator depends on varying conditions, you need to
   * call this function manually in order to update the styles when
   * the conditions change.
   *
   * @deprecated Use `cellPartNameGenerator` and `generateCellPartNames()` instead.
   */
  generateCellClassNames() {
    iterateChildren(this.$.items, (row) => {
      if (!row.hidden) {
        this._generateCellClassNames(row, this.__getRowModel(row));
      }
    });
  }
  /**
   * Runs the `cellPartNameGenerator` for the visible cells.
   * If the generator depends on varying conditions, you need to
   * call this function manually in order to update the styles when
   * the conditions change.
   */
  generateCellPartNames() {
    iterateChildren(this.$.items, (row) => {
      if (!row.hidden) {
        this._generateCellPartNames(row, this.__getRowModel(row));
      }
    });
  }
  /** @private */
  _generateCellClassNames(row, model) {
    iterateRowCells(row, (cell) => {
      if (cell.__generatedClasses) {
        cell.__generatedClasses.forEach((className) => cell.classList.remove(className));
      }
      if (this.cellClassNameGenerator && !row.hasAttribute("loading")) {
        const result = this.cellClassNameGenerator(cell._column, model);
        cell.__generatedClasses = result && result.split(" ").filter((className) => className.length > 0);
        if (cell.__generatedClasses) {
          cell.__generatedClasses.forEach((className) => cell.classList.add(className));
        }
      }
    });
  }
  /** @private */
  _generateCellPartNames(row, model) {
    iterateRowCells(row, (cell) => {
      if (cell.__generatedParts) {
        cell.__generatedParts.forEach((partName) => {
          updatePart(cell, null, partName);
        });
      }
      if (this.cellPartNameGenerator && !row.hasAttribute("loading")) {
        const result = this.cellPartNameGenerator(cell._column, model);
        cell.__generatedParts = result && result.split(" ").filter((partName) => partName.length > 0);
        if (cell.__generatedParts) {
          cell.__generatedParts.forEach((partName) => {
            updatePart(cell, true, partName);
          });
        }
      }
    });
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-mixin.js
var GridMixin = (superClass) => class extends ArrayDataProviderMixin(
  DataProviderMixin(
    DynamicColumnsMixin(
      ActiveItemMixin(
        ScrollMixin(
          SelectionMixin(
            SortMixin(
              RowDetailsMixin(
                KeyboardNavigationMixin(
                  A11yMixin(
                    FilterMixin(
                      ColumnReorderingMixin(
                        ColumnResizingMixin(
                          EventContextMixin(DragAndDropMixin(StylingMixin(TabindexMixin(superClass))))
                        )
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    )
  )
) {
  static get observers() {
    return ["_columnTreeChanged(_columnTree)", "_flatSizeChanged(_flatSize, __virtualizer, _hasData, _columnTree)"];
  }
  static get properties() {
    return {
      /** @private */
      _safari: {
        type: Boolean,
        value: isSafari
      },
      /** @private */
      _ios: {
        type: Boolean,
        value: isIOS
      },
      /** @private */
      _firefox: {
        type: Boolean,
        value: isFirefox
      },
      /** @private */
      _android: {
        type: Boolean,
        value: isAndroid
      },
      /** @private */
      _touchDevice: {
        type: Boolean,
        value: isTouch
      },
      /**
       * If true, the grid's height is defined by its rows.
       *
       * Effectively, this disables the grid's virtual scrolling so that all the rows are rendered in the DOM at once.
       * If the grid has a large number of items, using the feature is discouraged to avoid performance issues.
       * @attr {boolean} all-rows-visible
       * @type {boolean}
       */
      allRowsVisible: {
        type: Boolean,
        value: false,
        reflectToAttribute: true
      },
      /** @private */
      __pendingRecalculateColumnWidths: {
        type: Boolean,
        value: true
      },
      /** @private */
      isAttached: {
        value: false
      },
      /**
       * An internal property that is mainly used by `vaadin-template-renderer`
       * to identify grid elements.
       *
       * @private
       */
      __gridElement: {
        type: Boolean,
        value: true
      },
      /** @private */
      __hasEmptyStateContent: {
        type: Boolean,
        value: false
      },
      /** @private */
      __emptyState: {
        type: Boolean,
        computed: "__computeEmptyState(_flatSize, __hasEmptyStateContent)"
      }
    };
  }
  constructor() {
    super();
    this.addEventListener("animationend", this._onAnimationEnd);
  }
  /** @private */
  get _firstVisibleIndex() {
    const firstVisibleItem = this.__getFirstVisibleItem();
    return firstVisibleItem ? firstVisibleItem.index : void 0;
  }
  /** @private */
  get _lastVisibleIndex() {
    const lastVisibleItem = this.__getLastVisibleItem();
    return lastVisibleItem ? lastVisibleItem.index : void 0;
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    this.isAttached = true;
    if (this.__virtualizer) {
      this.__virtualizer.hostConnected();
    }
    this.recalculateColumnWidths();
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    this.isAttached = false;
    this._hideTooltip(true);
  }
  /** @private */
  __getFirstVisibleItem() {
    return this._getRenderedRows().find((row) => this._isInViewport(row));
  }
  /** @private */
  __getLastVisibleItem() {
    return this._getRenderedRows().reverse().find((row) => this._isInViewport(row));
  }
  /** @private */
  _isInViewport(item) {
    const scrollTargetRect = this.$.table.getBoundingClientRect();
    const itemRect = item.getBoundingClientRect();
    const headerHeight = this.$.header.getBoundingClientRect().height;
    const footerHeight = this.$.footer.getBoundingClientRect().height;
    return itemRect.bottom > scrollTargetRect.top + headerHeight && itemRect.top < scrollTargetRect.bottom - footerHeight;
  }
  /** @private */
  _getRenderedRows() {
    return Array.from(this.$.items.children).filter((item) => !item.hidden).sort((a17, b5) => a17.index - b5.index);
  }
  /** @protected */
  _getRowContainingNode(node) {
    const content = getClosestElement("vaadin-grid-cell-content", node);
    if (!content) {
      return;
    }
    const cell = content.assignedSlot.parentElement;
    return cell.parentElement;
  }
  /** @protected */
  _isItemAssignedToRow(item, row) {
    const model = this.__getRowModel(row);
    return this.getItemId(item) === this.getItemId(model.item);
  }
  /** @protected */
  ready() {
    super.ready();
    this.__virtualizer = new Virtualizer({
      createElements: this._createScrollerRows.bind(this),
      updateElement: this._updateScrollerItem.bind(this),
      scrollContainer: this.$.items,
      scrollTarget: this.$.table,
      reorderElements: true
    });
    new ResizeObserver(
      () => setTimeout(() => {
        this.__updateColumnsBodyContentHidden();
        this.__tryToRecalculateColumnWidthsIfPending();
      })
    ).observe(this.$.table);
    const minHeightObserver = new ResizeObserver(
      () => setTimeout(() => {
        this.__updateMinHeight();
      })
    );
    minHeightObserver.observe(this.$.header);
    minHeightObserver.observe(this.$.items);
    minHeightObserver.observe(this.$.footer);
    processTemplates(this);
    this._tooltipController = new TooltipController(this);
    this.addController(this._tooltipController);
    this._tooltipController.setManual(true);
    this.__emptyStateContentObserver = new SlotObserver(this.$.emptystateslot, ({ currentNodes }) => {
      this.$.emptystatecell._content = currentNodes[0];
      this.__hasEmptyStateContent = !!this.$.emptystatecell._content;
    });
  }
  /** @private */
  __getBodyCellCoordinates(cell) {
    if (this.$.items.contains(cell) && cell.localName === "td") {
      return {
        item: cell.parentElement._item,
        column: cell._column
      };
    }
  }
  /** @private */
  __focusBodyCell({ item, column }) {
    const row = this._getRenderedRows().find((row2) => row2._item === item);
    const cell = row && [...row.children].find((cell2) => cell2._column === column);
    if (cell) {
      cell.focus();
    }
  }
  /** @protected */
  _focusFirstVisibleRow() {
    const row = this.__getFirstVisibleItem();
    this.__rowFocusMode = true;
    row.focus();
  }
  /** @private */
  _flatSizeChanged(flatSize, virtualizer, hasData, columnTree) {
    if (virtualizer && hasData && columnTree) {
      const cell = this.shadowRoot.activeElement;
      const cellCoordinates = this.__getBodyCellCoordinates(cell);
      const previousSize = virtualizer.size || 0;
      virtualizer.size = flatSize;
      virtualizer.update(previousSize - 1, previousSize - 1);
      if (flatSize < previousSize) {
        virtualizer.update(flatSize - 1, flatSize - 1);
      }
      if (cellCoordinates && cell.parentElement.hidden) {
        this.__focusBodyCell(cellCoordinates);
      }
      this._resetKeyboardNavigation();
    }
  }
  /** @private */
  __getIntrinsicWidth(col) {
    if (!this.__intrinsicWidthCache.has(col)) {
      this.__calculateAndCacheIntrinsicWidths([col]);
    }
    return this.__intrinsicWidthCache.get(col);
  }
  /** @private */
  __getDistributedWidth(col, innerColumn) {
    if (col == null || col === this) {
      return 0;
    }
    const columnWidth = Math.max(
      this.__getIntrinsicWidth(col),
      this.__getDistributedWidth((col.assignedSlot || col).parentElement, col)
    );
    if (!innerColumn) {
      return columnWidth;
    }
    const columnGroup = col;
    const columnGroupWidth = columnWidth;
    const sumOfWidthOfAllChildColumns = columnGroup._visibleChildColumns.map((col2) => this.__getIntrinsicWidth(col2)).reduce((sum, curr) => sum + curr, 0);
    const extraNecessarySpaceForGridColumnGroup = Math.max(0, columnGroupWidth - sumOfWidthOfAllChildColumns);
    const proportionOfExtraSpace = this.__getIntrinsicWidth(innerColumn) / sumOfWidthOfAllChildColumns;
    const shareOfInnerColumnFromNecessaryExtraSpace = proportionOfExtraSpace * extraNecessarySpaceForGridColumnGroup;
    return this.__getIntrinsicWidth(innerColumn) + shareOfInnerColumnFromNecessaryExtraSpace;
  }
  /**
   * @param {!Array<!GridColumn>} cols the columns to auto size based on their content width
   * @private
   */
  _recalculateColumnWidths(cols) {
    this.__virtualizer.flush();
    [...this.$.header.children, ...this.$.footer.children].forEach((row) => {
      if (row.__debounceUpdateHeaderFooterRowVisibility) {
        row.__debounceUpdateHeaderFooterRowVisibility.flush();
      }
    });
    if (this._debouncerHiddenChanged) {
      this._debouncerHiddenChanged.flush();
    }
    if (this.__debounceUpdateFrozenColumn) {
      this.__debounceUpdateFrozenColumn.flush();
    }
    this.__intrinsicWidthCache = /* @__PURE__ */ new Map();
    const fvi = this._firstVisibleIndex;
    const lvi = this._lastVisibleIndex;
    this.__viewportRowsCache = this._getRenderedRows().filter((row) => row.index >= fvi && row.index <= lvi);
    this.__calculateAndCacheIntrinsicWidths(cols);
    cols.forEach((col) => {
      col.width = `${this.__getDistributedWidth(col)}px`;
    });
  }
  /**
   * Toggles the cell content for the given column to use or not use auto width.
   *
   * While content for all the column cells uses auto width (instead of the default 100%),
   * their offsetWidth can be used to calculate the collective intrinsic width of the column.
   *
   * @private
   */
  __setVisibleCellContentAutoWidth(col, autoWidth) {
    col._allCells.filter((cell) => {
      if (this.$.items.contains(cell)) {
        return this.__viewportRowsCache.includes(cell.parentElement);
      }
      return true;
    }).forEach((cell) => {
      cell.__measuringAutoWidth = autoWidth;
      if (cell.__measuringAutoWidth) {
        cell.__originalWidth = cell.style.width;
        cell.style.width = "auto";
        cell.style.position = "absolute";
      } else {
        cell.style.width = cell.__originalWidth;
        delete cell.__originalWidth;
        cell.style.position = "";
      }
    });
    if (autoWidth) {
      this.$.scroller.setAttribute("measuring-auto-width", "");
    } else {
      this.$.scroller.removeAttribute("measuring-auto-width");
    }
  }
  /**
   * Returns the maximum intrinsic width of the cell content in the given column.
   * Only cells which are marked for measuring auto width are considered.
   *
   * @private
   */
  __getAutoWidthCellsMaxWidth(col) {
    return col._allCells.reduce((width, cell) => {
      return cell.__measuringAutoWidth ? Math.max(width, cell.offsetWidth + 1) : width;
    }, 0);
  }
  /**
   * Calculates and caches the intrinsic width of each given column.
   *
   * @private
   */
  __calculateAndCacheIntrinsicWidths(cols) {
    cols.forEach((col) => this.__setVisibleCellContentAutoWidth(col, true));
    cols.forEach((col) => {
      const width = this.__getAutoWidthCellsMaxWidth(col);
      this.__intrinsicWidthCache.set(col, width);
    });
    cols.forEach((col) => this.__setVisibleCellContentAutoWidth(col, false));
  }
  /**
   * Updates the `width` of all columns which have `autoWidth` set to `true`.
   */
  recalculateColumnWidths() {
    if (!this._columnTree) {
      return;
    }
    if (isElementHidden(this) || this._dataProviderController.isLoading()) {
      this.__pendingRecalculateColumnWidths = true;
      return;
    }
    const cols = this._getColumns().filter((col) => !col.hidden && col.autoWidth);
    const undefinedCols = cols.filter((col) => !customElements.get(col.localName));
    if (undefinedCols.length) {
      Promise.all(undefinedCols.map((col) => customElements.whenDefined(col.localName))).then(() => {
        this._recalculateColumnWidths(cols);
      });
    } else {
      this._recalculateColumnWidths(cols);
    }
  }
  /** @private */
  __tryToRecalculateColumnWidthsIfPending() {
    if (!this.__pendingRecalculateColumnWidths || isElementHidden(this) || this._dataProviderController.isLoading()) {
      return;
    }
    const hasRowsWithUndefinedIndex = [...this.$.items.children].some((row) => row.index === void 0);
    if (hasRowsWithUndefinedIndex) {
      return;
    }
    const hasRowsWithClientHeight = [...this.$.items.children].some((row) => row.clientHeight > 0);
    if (hasRowsWithClientHeight) {
      this.__pendingRecalculateColumnWidths = false;
      this.recalculateColumnWidths();
    }
  }
  /**
   * @protected
   * @override
   */
  _onDataProviderPageLoaded() {
    super._onDataProviderPageLoaded();
    this.__tryToRecalculateColumnWidthsIfPending();
  }
  /** @private */
  _createScrollerRows(count) {
    const rows = [];
    for (let i11 = 0; i11 < count; i11++) {
      const row = document.createElement("tr");
      row.setAttribute("part", "row body-row");
      row.setAttribute("role", "row");
      row.setAttribute("tabindex", "-1");
      if (this._columnTree) {
        this._updateRow(row, this._columnTree[this._columnTree.length - 1], "body", false, true);
      }
      rows.push(row);
    }
    if (this._columnTree) {
      this._columnTree[this._columnTree.length - 1].forEach((c13) => {
        if (c13.isConnected && c13._cells) {
          c13._cells = [...c13._cells];
        }
      });
    }
    this.__afterCreateScrollerRowsDebouncer = Debouncer.debounce(
      this.__afterCreateScrollerRowsDebouncer,
      animationFrame,
      () => {
        this._afterScroll();
        this.__tryToRecalculateColumnWidthsIfPending();
      }
    );
    return rows;
  }
  /** @private */
  _createCell(tagName, column) {
    const contentId = this._contentIndex = this._contentIndex + 1 || 0;
    const slotName = `vaadin-grid-cell-content-${contentId}`;
    const cellContent = document.createElement("vaadin-grid-cell-content");
    cellContent.setAttribute("slot", slotName);
    const cell = document.createElement(tagName);
    cell.id = slotName.replace("-content-", "-");
    cell.setAttribute("role", tagName === "td" ? "gridcell" : "columnheader");
    if (!isAndroid && !isIOS) {
      cell.addEventListener("mouseenter", (event) => {
        if (!this.$.scroller.hasAttribute("scrolling")) {
          this._showTooltip(event);
        }
      });
      cell.addEventListener("mouseleave", () => {
        this._hideTooltip();
      });
      cell.addEventListener("mousedown", () => {
        this._hideTooltip(true);
      });
    }
    const slot = document.createElement("slot");
    slot.setAttribute("name", slotName);
    if (column && column._focusButtonMode) {
      const div = document.createElement("div");
      div.setAttribute("role", "button");
      div.setAttribute("tabindex", "-1");
      cell.appendChild(div);
      cell._focusButton = div;
      cell.focus = function(options) {
        cell._focusButton.focus(options);
      };
      div.appendChild(slot);
    } else {
      cell.setAttribute("tabindex", "-1");
      cell.appendChild(slot);
    }
    cell._content = cellContent;
    cellContent.addEventListener("mousedown", () => {
      if (isChrome) {
        const mouseUpListener = (event) => {
          const contentContainsFocusedElement = cellContent.contains(this.getRootNode().activeElement);
          const mouseUpWithinCell = event.composedPath().includes(cellContent);
          if (!contentContainsFocusedElement && mouseUpWithinCell) {
            cell.focus({ preventScroll: true });
          }
          document.removeEventListener("mouseup", mouseUpListener, true);
        };
        document.addEventListener("mouseup", mouseUpListener, true);
      } else {
        setTimeout(() => {
          if (!cellContent.contains(this.getRootNode().activeElement)) {
            cell.focus({ preventScroll: true });
          }
        });
      }
    });
    return cell;
  }
  /**
   * @param {!HTMLTableRowElement} row
   * @param {!Array<!GridColumn>} columns
   * @param {?string} section
   * @param {boolean} isColumnRow
   * @param {boolean} noNotify
   * @protected
   */
  _updateRow(row, columns, section = "body", isColumnRow = false, noNotify = false) {
    const contentsFragment = document.createDocumentFragment();
    iterateRowCells(row, (cell) => {
      cell._vacant = true;
    });
    row.innerHTML = "";
    if (section === "body") {
      row.__cells = [];
      row.__detailsCell = null;
    }
    columns.filter((column) => !column.hidden).forEach((column, index, cols) => {
      let cell;
      if (section === "body") {
        if (!column._cells) {
          column._cells = [];
        }
        cell = column._cells.find((cell2) => cell2._vacant);
        if (!cell) {
          cell = this._createCell("td", column);
          if (column._onCellKeyDown) {
            cell.addEventListener("keydown", column._onCellKeyDown.bind(column));
          }
          column._cells.push(cell);
        }
        cell.setAttribute("part", "cell body-cell");
        cell.__parentRow = row;
        row.__cells.push(cell);
        const isSizerRow = row === this.$.sizer;
        if (!column._bodyContentHidden || isSizerRow) {
          row.appendChild(cell);
        }
        if (isSizerRow) {
          column._sizerCell = cell;
        }
        if (index === cols.length - 1 && this.rowDetailsRenderer) {
          if (!this._detailsCells) {
            this._detailsCells = [];
          }
          const detailsCell = this._detailsCells.find((cell2) => cell2._vacant) || this._createCell("td");
          if (this._detailsCells.indexOf(detailsCell) === -1) {
            this._detailsCells.push(detailsCell);
          }
          if (!detailsCell._content.parentElement) {
            contentsFragment.appendChild(detailsCell._content);
          }
          this._configureDetailsCell(detailsCell);
          row.appendChild(detailsCell);
          row.__detailsCell = detailsCell;
          this._a11ySetRowDetailsCell(row, detailsCell);
          detailsCell._vacant = false;
        }
        if (!noNotify) {
          column._cells = [...column._cells];
        }
      } else {
        const tagName = section === "header" ? "th" : "td";
        if (isColumnRow || column.localName === "vaadin-grid-column-group") {
          cell = column[`_${section}Cell`];
          if (!cell) {
            cell = this._createCell(tagName);
            if (column._onCellKeyDown) {
              cell.addEventListener("keydown", column._onCellKeyDown.bind(column));
            }
          }
          cell._column = column;
          row.appendChild(cell);
          column[`_${section}Cell`] = cell;
        } else {
          if (!column._emptyCells) {
            column._emptyCells = [];
          }
          cell = column._emptyCells.find((cell2) => cell2._vacant) || this._createCell(tagName);
          cell._column = column;
          row.appendChild(cell);
          if (column._emptyCells.indexOf(cell) === -1) {
            column._emptyCells.push(cell);
          }
        }
        cell.part.add("cell", `${section}-cell`);
      }
      if (!cell._content.parentElement) {
        contentsFragment.appendChild(cell._content);
      }
      cell._vacant = false;
      cell._column = column;
    });
    if (section !== "body") {
      this.__debounceUpdateHeaderFooterRowVisibility(row);
    }
    this.appendChild(contentsFragment);
    this._frozenCellsChanged();
    this._updateFirstAndLastColumnForRow(row);
  }
  /**
   * @param {HTMLTableRowElement} row
   * @protected
   */
  __debounceUpdateHeaderFooterRowVisibility(row) {
    row.__debounceUpdateHeaderFooterRowVisibility = Debouncer.debounce(
      row.__debounceUpdateHeaderFooterRowVisibility,
      microTask2,
      () => this.__updateHeaderFooterRowVisibility(row)
    );
  }
  /**
   * @param {HTMLTableRowElement} row
   * @protected
   */
  __updateHeaderFooterRowVisibility(row) {
    if (!row) {
      return;
    }
    const visibleRowCells = Array.from(row.children).filter((cell) => {
      const column = cell._column;
      if (column._emptyCells && column._emptyCells.indexOf(cell) > -1) {
        return false;
      }
      if (row.parentElement === this.$.header) {
        if (column.headerRenderer) {
          return true;
        }
        if (column.header === null) {
          return false;
        }
        if (column.path || column.header !== void 0) {
          return true;
        }
      } else if (column.footerRenderer) {
        return true;
      }
      return false;
    });
    if (row.hidden !== !visibleRowCells.length) {
      row.hidden = !visibleRowCells.length;
    }
    this._resetKeyboardNavigation();
  }
  /** @private */
  _updateScrollerItem(row, index) {
    this._preventScrollerRotatingCellFocus(row, index);
    if (!this._columnTree) {
      return;
    }
    this._updateRowOrderParts(row, index);
    this._a11yUpdateRowRowindex(row, index);
    this._getItem(index, row);
  }
  /** @private */
  _columnTreeChanged(columnTree) {
    this._renderColumnTree(columnTree);
    this.recalculateColumnWidths();
    this.__updateColumnsBodyContentHidden();
  }
  /** @private */
  _updateRowOrderParts(row, index = row.index) {
    updateBooleanRowStates(row, {
      first: index === 0,
      last: index === this._flatSize - 1,
      odd: index % 2 !== 0,
      even: index % 2 === 0
    });
  }
  /** @private */
  _updateRowStateParts(row, { item, expanded, selected, detailsOpened }) {
    updateBooleanRowStates(row, {
      expanded,
      collapsed: this.__isRowExpandable(row),
      selected,
      nonselectable: this.__isItemSelectable(item) === false,
      "details-opened": detailsOpened
    });
  }
  /** @private */
  __computeEmptyState(flatSize, hasEmptyStateContent) {
    return flatSize === 0 && hasEmptyStateContent;
  }
  /**
   * @param {!Array<!GridColumn>} columnTree
   * @protected
   */
  _renderColumnTree(columnTree) {
    iterateChildren(this.$.items, (row) => {
      this._updateRow(row, columnTree[columnTree.length - 1], "body", false, true);
      const model = this.__getRowModel(row);
      this._updateRowOrderParts(row);
      this._updateRowStateParts(row, model);
      this._filterDragAndDrop(row, model);
    });
    while (this.$.header.children.length < columnTree.length) {
      const headerRow = document.createElement("tr");
      headerRow.setAttribute("part", "row");
      headerRow.setAttribute("role", "row");
      headerRow.setAttribute("tabindex", "-1");
      this.$.header.appendChild(headerRow);
      const footerRow = document.createElement("tr");
      footerRow.setAttribute("part", "row");
      footerRow.setAttribute("role", "row");
      footerRow.setAttribute("tabindex", "-1");
      this.$.footer.appendChild(footerRow);
    }
    while (this.$.header.children.length > columnTree.length) {
      this.$.header.removeChild(this.$.header.firstElementChild);
      this.$.footer.removeChild(this.$.footer.firstElementChild);
    }
    iterateChildren(this.$.header, (headerRow, index, rows) => {
      this._updateRow(headerRow, columnTree[index], "header", index === columnTree.length - 1);
      const cells = getBodyRowCells(headerRow);
      updateCellsPart(cells, "first-header-row-cell", index === 0);
      updateCellsPart(cells, "last-header-row-cell", index === rows.length - 1);
    });
    iterateChildren(this.$.footer, (footerRow, index, rows) => {
      this._updateRow(footerRow, columnTree[columnTree.length - 1 - index], "footer", index === 0);
      const cells = getBodyRowCells(footerRow);
      updateCellsPart(cells, "first-footer-row-cell", index === 0);
      updateCellsPart(cells, "last-footer-row-cell", index === rows.length - 1);
    });
    this._updateRow(this.$.sizer, columnTree[columnTree.length - 1]);
    this._resizeHandler();
    this._frozenCellsChanged();
    this._updateFirstAndLastColumn();
    this._resetKeyboardNavigation();
    this._a11yUpdateHeaderRows();
    this._a11yUpdateFooterRows();
    this.generateCellClassNames();
    this.generateCellPartNames();
    this.__updateHeaderAndFooter();
  }
  /**
   * @param {!HTMLElement} row
   * @param {GridItem} item
   * @protected
   */
  _updateItem(row, item) {
    row._item = item;
    const model = this.__getRowModel(row);
    this._toggleDetailsCell(row, model.detailsOpened);
    this._a11yUpdateRowLevel(row, model.level);
    this._a11yUpdateRowSelected(row, model.selected);
    this._updateRowStateParts(row, model);
    this._generateCellClassNames(row, model);
    this._generateCellPartNames(row, model);
    this._filterDragAndDrop(row, model);
    this.__updateDragSourceParts(row, model);
    iterateChildren(row, (cell) => {
      if (cell._column && !cell._column.isConnected) {
        return;
      }
      if (cell._renderer) {
        const owner = cell._column || this;
        cell._renderer.call(owner, cell._content, owner, model);
      }
    });
    this._updateDetailsCellHeight(row);
    this._a11yUpdateRowExpanded(row, model.expanded);
  }
  /** @private */
  _resizeHandler() {
    this._updateDetailsCellHeights();
    this.__updateHorizontalScrollPosition();
  }
  /** @private */
  _onAnimationEnd(e13) {
    if (e13.animationName.indexOf("vaadin-grid-appear") === 0) {
      e13.stopPropagation();
      this.__tryToRecalculateColumnWidthsIfPending();
      this._resetKeyboardNavigation();
      requestAnimationFrame(() => {
        this.__scrollToPendingIndexes();
      });
    }
  }
  /**
   * @param {!HTMLTableRowElement} row
   * @return {!GridItemModel}
   * @protected
   */
  __getRowModel(row) {
    return {
      index: row.index,
      item: row._item,
      level: this._getIndexLevel(row.index),
      expanded: this._isExpanded(row._item),
      selected: this._isSelected(row._item),
      detailsOpened: !!this.rowDetailsRenderer && this._isDetailsOpened(row._item)
    };
  }
  /**
   * @param {Event} event
   * @protected
   */
  _showTooltip(event) {
    const tooltip = this._tooltipController.node;
    if (tooltip && tooltip.isConnected) {
      const target = event.target;
      if (!this.__isCellFullyVisible(target)) {
        return;
      }
      this._tooltipController.setTarget(target);
      this._tooltipController.setContext(this.getEventContext(event));
      tooltip._stateController.open({
        focus: event.type === "focusin",
        hover: event.type === "mouseenter"
      });
    }
  }
  /** @private */
  __isCellFullyVisible(cell) {
    if (cell.hasAttribute("frozen") || cell.hasAttribute("frozen-to-end")) {
      return true;
    }
    let { left, right } = this.getBoundingClientRect();
    const frozen = [...cell.parentNode.children].find((cell2) => cell2.hasAttribute("last-frozen"));
    if (frozen) {
      const frozenRect = frozen.getBoundingClientRect();
      left = this.__isRTL ? left : frozenRect.right;
      right = this.__isRTL ? frozenRect.left : right;
    }
    const frozenToEnd = [...cell.parentNode.children].find((cell2) => cell2.hasAttribute("first-frozen-to-end"));
    if (frozenToEnd) {
      const frozenToEndRect = frozenToEnd.getBoundingClientRect();
      left = this.__isRTL ? frozenToEndRect.right : left;
      right = this.__isRTL ? right : frozenToEndRect.left;
    }
    const cellRect = cell.getBoundingClientRect();
    return cellRect.left >= left && cellRect.right <= right;
  }
  /** @protected */
  _hideTooltip(immediate) {
    const tooltip = this._tooltipController && this._tooltipController.node;
    if (tooltip) {
      tooltip._stateController.close(immediate);
    }
  }
  /**
   * Requests an update for the content of cells.
   *
   * While performing the update, the following renderers are invoked:
   * - `Grid.rowDetailsRenderer`
   * - `GridColumn.renderer`
   * - `GridColumn.headerRenderer`
   * - `GridColumn.footerRenderer`
   *
   * It is not guaranteed that the update happens immediately (synchronously) after it is requested.
   */
  requestContentUpdate() {
    this.__updateHeaderAndFooter();
    this.__updateVisibleRows();
  }
  /** @private */
  __updateHeaderAndFooter() {
    (this._columnTree || []).forEach((level) => {
      level.forEach((column) => {
        if (column._renderHeaderAndFooter) {
          column._renderHeaderAndFooter();
        }
      });
    });
  }
  /** @protected */
  __updateVisibleRows(start, end) {
    if (this.__virtualizer) {
      this.__virtualizer.update(start, end);
    }
  }
  /** @private */
  __updateMinHeight() {
    const rowHeight = 36;
    const headerHeight = this.$.header.clientHeight;
    const footerHeight = this.$.footer.clientHeight;
    const scrollbarHeight = this.$.table.offsetHeight - this.$.table.clientHeight;
    const minHeight = headerHeight + rowHeight + footerHeight + scrollbarHeight;
    if (!this.__minHeightStyleSheet && supportsAdoptingStyleSheets2) {
      this.__minHeightStyleSheet = new CSSStyleSheet();
      this.shadowRoot.adoptedStyleSheets = [...this.shadowRoot.adoptedStyleSheets, this.__minHeightStyleSheet];
    }
    if (this.__minHeightStyleSheet) {
      this.__minHeightStyleSheet.replaceSync(`:host { --_grid-min-height: ${minHeight}px; }`);
    } else {
      this.style.setProperty("--_grid-min-height", `${minHeight}px`);
    }
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-styles.js
var gridStyles = css`
  @keyframes vaadin-grid-appear {
    to {
      opacity: 1;
    }
  }

  :host {
    display: flex;
    flex-direction: column;
    animation: 1ms vaadin-grid-appear;
    height: 400px;
    min-height: var(--_grid-min-height, 0);
    flex: 1 1 auto;
    align-self: stretch;
    position: relative;
  }

  :host([hidden]) {
    display: none !important;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  #scroller {
    display: flex;
    flex-direction: column;
    min-height: 100%;
    transform: translateY(0);
    width: auto;
    height: auto;
    position: absolute;
    inset: 0;
  }

  :host([all-rows-visible]) {
    height: auto;
    align-self: flex-start;
    min-height: auto;
    flex-grow: 0;
    width: 100%;
  }

  :host([all-rows-visible]) #scroller {
    width: 100%;
    height: 100%;
    position: relative;
  }

  :host([all-rows-visible]) #items {
    min-height: 1px;
  }

  #table {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    overflow: auto;
    position: relative;
    outline: none;
    /* Workaround for a Desktop Safari bug: new stacking context here prevents the scrollbar from getting hidden */
    z-index: 0;
  }

  #header,
  #footer {
    display: block;
    position: -webkit-sticky;
    position: sticky;
    left: 0;
    overflow: visible;
    width: 100%;
    z-index: 1;
  }

  #header {
    top: 0;
  }

  th {
    text-align: inherit;
  }

  /* Safari doesn't work with "inherit" */
  [safari] th {
    text-align: initial;
  }

  #footer {
    bottom: 0;
  }

  #items {
    flex-grow: 1;
    flex-shrink: 0;
    display: block;
    position: -webkit-sticky;
    position: sticky;
    width: 100%;
    left: 0;
    overflow: visible;
  }

  [part~='row'] {
    display: flex;
    width: 100%;
    box-sizing: border-box;
    margin: 0;
  }

  [part~='row'][loading] [part~='body-cell'] ::slotted(vaadin-grid-cell-content) {
    visibility: hidden;
  }

  [column-rendering='lazy'] [part~='body-cell']:not([frozen]):not([frozen-to-end]) {
    transform: translateX(var(--_grid-lazy-columns-start));
  }

  #items [part~='row'] {
    position: absolute;
  }

  #items [part~='row']:empty {
    height: 100%;
  }

  [part~='cell']:not([part~='details-cell']) {
    flex-shrink: 0;
    flex-grow: 1;
    box-sizing: border-box;
    display: flex;
    width: 100%;
    position: relative;
    align-items: center;
    padding: 0;
    white-space: nowrap;
  }

  [part~='cell'] {
    outline: none;
  }

  [part~='cell'] > [tabindex] {
    display: flex;
    align-items: inherit;
    outline: none;
    position: absolute;
    inset: 0;
  }

  /* Switch the focusButtonMode wrapping element to "position: static" temporarily
     when measuring real width of the cells in the auto-width columns. */
  [measuring-auto-width] [part~='cell'] > [tabindex] {
    position: static;
  }

  [part~='details-cell'] {
    position: absolute;
    bottom: 0;
    width: 100%;
    box-sizing: border-box;
    padding: 0;
  }

  [part~='cell'] ::slotted(vaadin-grid-cell-content) {
    display: block;
    width: 100%;
    box-sizing: border-box;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  [hidden] {
    display: none !important;
  }

  [frozen],
  [frozen-to-end] {
    z-index: 2;
    will-change: transform;
  }

  [no-scrollbars][safari] #table,
  [no-scrollbars][firefox] #table {
    overflow: hidden;
  }

  /* Empty state */

  #scroller:not([empty-state]) #emptystatebody,
  #scroller[empty-state] #items {
    display: none;
  }

  #emptystatebody {
    display: flex;
    position: sticky;
    inset: 0;
    flex: 1;
    overflow: hidden;
  }

  #emptystaterow {
    display: flex;
    flex: 1;
  }

  #emptystatecell {
    display: block;
    flex: 1;
    overflow: auto;
  }

  /* Reordering styles */
  :host([reordering]) [part~='cell'] ::slotted(vaadin-grid-cell-content),
  :host([reordering]) [part~='resize-handle'],
  #scroller[no-content-pointer-events] [part~='cell'] ::slotted(vaadin-grid-cell-content) {
    pointer-events: none;
  }

  [part~='reorder-ghost'] {
    visibility: hidden;
    position: fixed;
    pointer-events: none;
    opacity: 0.5;

    /* Prevent overflowing the grid in Firefox */
    top: 0;
    left: 0;
  }

  :host([reordering]) {
    -moz-user-select: none;
    -webkit-user-select: none;
    user-select: none;
  }

  /* Resizing styles */
  [part~='resize-handle'] {
    position: absolute;
    top: 0;
    right: 0;
    height: 100%;
    cursor: col-resize;
    z-index: 1;
  }

  [part~='resize-handle']::before {
    position: absolute;
    content: '';
    height: 100%;
    width: 35px;
    transform: translateX(-50%);
  }

  [last-column] [part~='resize-handle']::before,
  [last-frozen] [part~='resize-handle']::before {
    width: 18px;
    transform: none;
    right: 0;
  }

  [frozen-to-end] [part~='resize-handle'] {
    left: 0;
    right: auto;
  }

  [frozen-to-end] [part~='resize-handle']::before {
    left: 0;
    right: auto;
  }

  [first-frozen-to-end] [part~='resize-handle']::before {
    width: 18px;
    transform: none;
  }

  [first-frozen-to-end] {
    margin-inline-start: auto;
  }

  /* Hide resize handle if scrolled to end */
  :host(:not([overflow~='end'])) [first-frozen-to-end] [part~='resize-handle'] {
    display: none;
  }

  #scroller[column-resizing] {
    -ms-user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
    user-select: none;
  }

  /* Sizer styles */
  #sizer {
    display: flex;
    position: absolute;
    visibility: hidden;
  }

  #sizer [part~='details-cell'] {
    display: none !important;
  }

  #sizer [part~='cell'][hidden] {
    display: none !important;
  }

  #sizer [part~='cell'] {
    display: block;
    flex-shrink: 0;
    line-height: 0;
    height: 0 !important;
    min-height: 0 !important;
    max-height: 0 !important;
    padding: 0 !important;
    border: none !important;
  }

  #sizer [part~='cell']::before {
    content: '-';
  }

  #sizer [part~='cell'] ::slotted(vaadin-grid-cell-content) {
    display: none !important;
  }

  /* RTL specific styles */

  :host([dir='rtl']) #items,
  :host([dir='rtl']) #header,
  :host([dir='rtl']) #footer {
    left: auto;
  }

  :host([dir='rtl']) [part~='reorder-ghost'] {
    left: auto;
    right: 0;
  }

  :host([dir='rtl']) [part~='resize-handle'] {
    left: 0;
    right: auto;
  }

  :host([dir='rtl']) [part~='resize-handle']::before {
    transform: translateX(50%);
  }

  :host([dir='rtl']) [last-column] [part~='resize-handle']::before,
  :host([dir='rtl']) [last-frozen] [part~='resize-handle']::before {
    left: 0;
    right: auto;
  }

  :host([dir='rtl']) [frozen-to-end] [part~='resize-handle'] {
    right: 0;
    left: auto;
  }

  :host([dir='rtl']) [frozen-to-end] [part~='resize-handle']::before {
    right: 0;
    left: auto;
  }

  @media (forced-colors: active) {
    [part~='selected-row'] [part~='first-column-cell']::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      border: 2px solid;
    }

    [part~='focused-cell']::before {
      outline: 2px solid !important;
      outline-offset: -1px;
    }
  }
`;

// node_modules/@vaadin/grid/src/vaadin-grid.js
registerStyles("vaadin-grid", gridStyles, { moduleId: "vaadin-grid-styles" });
var Grid = class extends GridMixin(ElementMixin2(ThemableMixin(ControllerMixin(PolymerElement)))) {
  static get template() {
    return html`
      <div
        id="scroller"
        safari$="[[_safari]]"
        ios$="[[_ios]]"
        loading$="[[loading]]"
        column-reordering-allowed$="[[columnReorderingAllowed]]"
        empty-state$="[[__emptyState]]"
      >
        <table id="table" role="treegrid" aria-multiselectable="true" tabindex="0" aria-label$="[[accessibleName]]">
          <caption id="sizer" part="row"></caption>
          <thead id="header" role="rowgroup"></thead>
          <tbody id="items" role="rowgroup"></tbody>
          <tbody id="emptystatebody">
            <tr id="emptystaterow">
              <td part="empty-state" id="emptystatecell" tabindex="0">
                <slot name="empty-state" id="emptystateslot"></slot>
              </td>
            </tr>
          </tbody>
          <tfoot id="footer" role="rowgroup"></tfoot>
        </table>

        <div part="reorder-ghost"></div>
      </div>

      <slot name="tooltip"></slot>

      <div id="focusexit" tabindex="0"></div>
    `;
  }
  static get is() {
    return "vaadin-grid";
  }
};
defineCustomElement(Grid);

// node_modules/@vaadin/grid/src/vaadin-grid-column-group-mixin.js
var GridColumnGroupMixin = (superClass) => class extends ColumnBaseMixin(superClass) {
  static get properties() {
    return {
      /** @private */
      _childColumns: {
        value() {
          return this._getChildColumns(this);
        }
      },
      /**
       * Flex grow ratio for the column group as the sum of the ratios of its child columns.
       * @attr {number} flex-grow
       */
      flexGrow: {
        type: Number,
        readOnly: true,
        sync: true
      },
      /**
       * Width of the column group as the sum of the widths of its child columns.
       */
      width: {
        type: String,
        readOnly: true
      },
      /** @private */
      _visibleChildColumns: Array,
      /** @private */
      _colSpan: Number,
      /** @private */
      _rootColumns: Array
    };
  }
  static get observers() {
    return [
      "_groupFrozenChanged(frozen, _rootColumns)",
      "_groupFrozenToEndChanged(frozenToEnd, _rootColumns)",
      "_groupHiddenChanged(hidden)",
      "_colSpanChanged(_colSpan, _headerCell, _footerCell)",
      "_groupOrderChanged(_order, _rootColumns)",
      "_groupReorderStatusChanged(_reorderStatus, _rootColumns)",
      "_groupResizableChanged(resizable, _rootColumns)"
    ];
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    this._addNodeObserver();
    this._updateFlexAndWidth();
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    if (this._observer) {
      this._observer.disconnect();
    }
  }
  /**
   * @param {string} path
   * @param {unknown=} value
   * @protected
   */
  _columnPropChanged(path, value) {
    if (path === "hidden") {
      this._preventHiddenSynchronization = true;
      this._updateVisibleChildColumns(this._childColumns);
      this._preventHiddenSynchronization = false;
    }
    if (/flexGrow|width|hidden|_childColumns/u.test(path)) {
      this._updateFlexAndWidth();
    }
    if (path === "frozen" && !this.frozen) {
      this.frozen = value;
    }
    if (path === "lastFrozen" && !this._lastFrozen) {
      this._lastFrozen = value;
    }
    if (path === "frozenToEnd" && !this.frozenToEnd) {
      this.frozenToEnd = value;
    }
    if (path === "firstFrozenToEnd" && !this._firstFrozenToEnd) {
      this._firstFrozenToEnd = value;
    }
  }
  /** @private */
  _groupOrderChanged(order, rootColumns) {
    if (rootColumns) {
      const _rootColumns = rootColumns.slice(0);
      if (!order) {
        _rootColumns.forEach((column) => {
          column._order = 0;
        });
        return;
      }
      const trailingZeros = /(0+)$/u.exec(order).pop().length;
      const childCountDigits = ~~(Math.log(rootColumns.length) / Math.LN10) + 1;
      const scope = 10 ** (trailingZeros - childCountDigits);
      if (_rootColumns[0] && _rootColumns[0]._order) {
        _rootColumns.sort((a17, b5) => a17._order - b5._order);
      }
      updateColumnOrders(_rootColumns, scope, order);
    }
  }
  /** @private */
  _groupReorderStatusChanged(reorderStatus, rootColumns) {
    if (reorderStatus === void 0 || rootColumns === void 0) {
      return;
    }
    rootColumns.forEach((column) => {
      column._reorderStatus = reorderStatus;
    });
  }
  /** @private */
  _groupResizableChanged(resizable, rootColumns) {
    if (resizable === void 0 || rootColumns === void 0) {
      return;
    }
    rootColumns.forEach((column) => {
      column.resizable = resizable;
    });
  }
  /** @private */
  _updateVisibleChildColumns(childColumns) {
    this._visibleChildColumns = Array.prototype.filter.call(childColumns, (col) => !col.hidden);
    this._colSpan = this._visibleChildColumns.length;
    this._updateAutoHidden();
  }
  /** @protected */
  _updateFlexAndWidth() {
    if (!this._visibleChildColumns) {
      return;
    }
    if (this._visibleChildColumns.length > 0) {
      const width = this._visibleChildColumns.reduce((prev, curr) => {
        prev += ` + ${(curr.width || "0px").replace("calc", "")}`;
        return prev;
      }, "").substring(3);
      this._setWidth(`calc(${width})`);
    } else {
      this._setWidth("0px");
    }
    this._setFlexGrow(
      Array.prototype.reduce.call(this._visibleChildColumns, (prev, curr) => prev + curr.flexGrow, 0)
    );
  }
  /**
   * This method is called before the group's frozen value is being propagated to the child columns.
   * In case some of the child columns are frozen, while others are not, the non-frozen ones
   * will get automatically frozen as well. As this may sometimes be unintended, this method
   * shows a warning in the console in such cases.
   * @private
   */
  __scheduleAutoFreezeWarning(columns, frozenProp) {
    if (this._grid) {
      const frozenAttr = frozenProp.replace(/([A-Z])/gu, "-$1").toLowerCase();
      const firstColumnFrozen = columns[0][frozenProp] || columns[0].hasAttribute(frozenAttr);
      const allSameFrozen = columns.every((column) => {
        return (column[frozenProp] || column.hasAttribute(frozenAttr)) === firstColumnFrozen;
      });
      if (!allSameFrozen) {
        this._grid.__autoFreezeWarningDebouncer = Debouncer.debounce(
          this._grid.__autoFreezeWarningDebouncer,
          animationFrame,
          () => {
            console.warn(
              `WARNING: Joining ${frozenProp} and non-${frozenProp} Grid columns inside the same column group! This will automatically freeze all the joined columns to avoid rendering issues. If this was intentional, consider marking each joined column explicitly as ${frozenProp}. Otherwise, exclude the ${frozenProp} columns from the joined group.`
            );
          }
        );
      }
    }
  }
  /** @private */
  _groupFrozenChanged(frozen, rootColumns) {
    if (rootColumns === void 0 || frozen === void 0) {
      return;
    }
    if (frozen !== false) {
      this.__scheduleAutoFreezeWarning(rootColumns, "frozen");
      Array.from(rootColumns).forEach((col) => {
        col.frozen = frozen;
      });
    }
  }
  /** @private */
  _groupFrozenToEndChanged(frozenToEnd, rootColumns) {
    if (rootColumns === void 0 || frozenToEnd === void 0) {
      return;
    }
    if (frozenToEnd !== false) {
      this.__scheduleAutoFreezeWarning(rootColumns, "frozenToEnd");
      Array.from(rootColumns).forEach((col) => {
        col.frozenToEnd = frozenToEnd;
      });
    }
  }
  /** @private */
  _groupHiddenChanged(hidden) {
    if (hidden || this.__groupHiddenInitialized) {
      this._synchronizeHidden();
    }
    this.__groupHiddenInitialized = true;
  }
  /** @private */
  _updateAutoHidden() {
    const wasAutoHidden = this._autoHidden;
    this._autoHidden = (this._visibleChildColumns || []).length === 0;
    if (wasAutoHidden || this._autoHidden) {
      this.hidden = this._autoHidden;
    }
  }
  /** @private */
  _synchronizeHidden() {
    if (this._childColumns && !this._preventHiddenSynchronization) {
      this._childColumns.forEach((column) => {
        column.hidden = this.hidden;
      });
    }
  }
  /** @private */
  _colSpanChanged(colSpan, headerCell, footerCell) {
    if (headerCell) {
      headerCell.setAttribute("colspan", colSpan);
      if (this._grid) {
        this._grid._a11yUpdateCellColspan(headerCell, colSpan);
      }
    }
    if (footerCell) {
      footerCell.setAttribute("colspan", colSpan);
      if (this._grid) {
        this._grid._a11yUpdateCellColspan(footerCell, colSpan);
      }
    }
  }
  /**
   * @param {!GridColumnGroup} el
   * @return {!Array<!GridColumn>}
   * @protected
   */
  _getChildColumns(el) {
    return ColumnObserver.getColumns(el);
  }
  /** @private */
  _addNodeObserver() {
    this._observer = new ColumnObserver(this, () => {
      this._preventHiddenSynchronization = true;
      this._rootColumns = this._getChildColumns(this);
      this._childColumns = this._rootColumns;
      this._updateVisibleChildColumns(this._childColumns);
      this._preventHiddenSynchronization = false;
      if (this._grid && this._grid._debounceUpdateColumnTree) {
        this._grid._debounceUpdateColumnTree();
      }
    });
    this._observer.flush();
  }
  /**
   * @param {!Node} node
   * @return {boolean}
   * @protected
   */
  _isColumnElement(node) {
    return node.nodeType === Node.ELEMENT_NODE && /\bcolumn\b/u.test(node.localName);
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-column-group.js
var GridColumnGroup = class extends GridColumnGroupMixin(PolymerElement) {
  static get is() {
    return "vaadin-grid-column-group";
  }
};
defineCustomElement(GridColumnGroup);

// node_modules/@vaadin/checkbox/theme/lumo/vaadin-checkbox-styles.js
registerStyles(
  "vaadin-checkbox",
  css`
    :host {
      color: var(--vaadin-checkbox-label-color, var(--lumo-body-text-color));
      font-size: var(--vaadin-checkbox-label-font-size, var(--lumo-font-size-m));
      font-family: var(--lumo-font-family);
      line-height: var(--lumo-line-height-s);
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-tap-highlight-color: transparent;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
      cursor: default;
      outline: none;
      --_checkbox-size: var(--vaadin-checkbox-size, calc(var(--lumo-size-m) / 2));
      --_focus-ring-color: var(--vaadin-focus-ring-color, var(--lumo-primary-color-50pct));
      --_focus-ring-width: var(--vaadin-focus-ring-width, 2px);
      --_selection-color: var(--vaadin-selection-color, var(--lumo-primary-color));
      --_invalid-background: var(--vaadin-input-field-invalid-background, var(--lumo-error-color-10pct));
      --_disabled-checkmark-color: var(--vaadin-checkbox-disabled-checkmark-color, var(--lumo-contrast-30pct));
    }

    [part='label'] {
      display: flex;
      position: relative;
      max-width: max-content;
    }

    :host([has-label]) ::slotted(label) {
      padding: var(
        --vaadin-checkbox-label-padding,
        var(--lumo-space-xs) var(--lumo-space-s) var(--lumo-space-xs) var(--lumo-space-xs)
      );
    }

    :host([dir='rtl'][has-label]) ::slotted(label) {
      padding: var(--lumo-space-xs) var(--lumo-space-xs) var(--lumo-space-xs) var(--lumo-space-s);
    }

    :host([has-label][required]) ::slotted(label) {
      padding-inline-end: var(--lumo-space-m);
    }

    [part='checkbox'] {
      width: var(--_checkbox-size);
      height: var(--_checkbox-size);
      margin: var(--lumo-space-xs);
      position: relative;
      border-radius: var(--vaadin-checkbox-border-radius, var(--lumo-border-radius-s));
      background: var(--vaadin-checkbox-background, var(--lumo-contrast-20pct));
      transition:
        transform 0.2s cubic-bezier(0.12, 0.32, 0.54, 2),
        background-color 0.15s;
      cursor: var(--lumo-clickable-cursor);
      /* Default field border color */
      --_input-border-color: var(--vaadin-input-field-border-color, var(--lumo-contrast-50pct));
    }

    :host([indeterminate]),
    :host([checked]) {
      --vaadin-input-field-border-color: transparent;
    }

    :host([indeterminate]) [part='checkbox'],
    :host([checked]) [part='checkbox'] {
      background-color: var(--_selection-color);
    }

    /* Checkmark */
    [part='checkbox']::after {
      pointer-events: none;
      font-family: 'lumo-icons';
      content: var(--vaadin-checkbox-checkmark-char, var(--lumo-icons-checkmark));
      color: var(--vaadin-checkbox-checkmark-color, var(--lumo-primary-contrast-color));
      font-size: var(--vaadin-checkbox-checkmark-size, calc(var(--_checkbox-size) + 2px));
      line-height: 1;
      position: absolute;
      top: -1px;
      left: -1px;
      contain: content;
      opacity: 0;
    }

    :host([checked]) [part='checkbox']::after {
      opacity: 1;
    }

    :host([readonly]:not([checked]):not([indeterminate])) {
      color: var(--lumo-secondary-text-color);
    }

    :host([readonly]:not([checked]):not([indeterminate])) [part='checkbox'] {
      background: transparent;
      box-shadow: none;
    }

    :host([readonly]:not([checked]):not([indeterminate])) [part='checkbox']::after {
      content: '';
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      border-radius: inherit;
      top: 0;
      left: 0;
      opacity: 1;
      border: var(--vaadin-input-field-readonly-border, 1px dashed var(--lumo-contrast-50pct));
    }

    /* Indeterminate checkmark */
    :host([indeterminate]) [part='checkbox']::after {
      content: var(--vaadin-checkbox-checkmark-char-indeterminate, '');
      opacity: 1;
      top: 45%;
      height: 10%;
      left: 22%;
      right: 22%;
      width: auto;
      border: 0;
      background-color: var(--lumo-primary-contrast-color);
    }

    /* Focus ring */
    :host([focus-ring]) [part='checkbox'] {
      box-shadow:
        0 0 0 1px var(--lumo-base-color),
        0 0 0 calc(var(--_focus-ring-width) + 1px) var(--_focus-ring-color),
        inset 0 0 0 var(--_input-border-width, 0) var(--_input-border-color);
    }

    :host([focus-ring][readonly]:not([checked]):not([indeterminate])) [part='checkbox'] {
      box-shadow:
        0 0 0 1px var(--lumo-base-color),
        0 0 0 calc(var(--_focus-ring-width) + 1px) var(--_focus-ring-color);
    }

    /* Disabled */
    :host([disabled]) {
      pointer-events: none;
      --vaadin-input-field-border-color: var(--lumo-contrast-20pct);
    }

    :host([disabled]) ::slotted(label) {
      color: inherit;
    }

    :host([disabled]) [part='checkbox'] {
      background-color: var(--vaadin-checkbox-disabled-background, var(--lumo-contrast-10pct));
    }

    :host([disabled]) [part='checkbox']::after {
      color: var(--_disabled-checkmark-color);
    }

    :host([disabled]) [part='label'],
    :host([disabled]) [part='helper-text'] {
      color: var(--lumo-disabled-text-color);
      -webkit-text-fill-color: var(--lumo-disabled-text-color);
    }

    :host([indeterminate][disabled]) [part='checkbox']::after {
      background-color: var(--_disabled-checkmark-color);
    }

    :host([readonly][checked]:not([disabled])) [part='checkbox'],
    :host([readonly][indeterminate]:not([disabled])) [part='checkbox'] {
      background-color: var(--vaadin-checkbox-readonly-checked-background, var(--lumo-contrast-70pct));
    }

    /* Used for activation "halo" */
    [part='checkbox']::before {
      pointer-events: none;
      color: transparent;
      width: 100%;
      height: 100%;
      line-height: var(--_checkbox-size);
      border-radius: inherit;
      background-color: inherit;
      transform: scale(1.4);
      opacity: 0;
      transition:
        transform 0.1s,
        opacity 0.8s;
    }

    /* Hover */
    :host(:not([checked]):not([indeterminate]):not([disabled]):not([readonly]):not([invalid]):hover) [part='checkbox'] {
      background: var(--vaadin-checkbox-background-hover, var(--lumo-contrast-30pct));
    }

    /* Disable hover for touch devices */
    @media (pointer: coarse) {
      /* prettier-ignore */
      :host(:not([checked]):not([indeterminate]):not([disabled]):not([readonly]):not([invalid]):hover) [part='checkbox'] {
        background: var(--vaadin-checkbox-background, var(--lumo-contrast-20pct));
      }
    }

    /* Active */
    :host([active]) [part='checkbox'] {
      transform: scale(0.9);
      transition-duration: 0.05s;
    }

    :host([active][checked]) [part='checkbox'] {
      transform: scale(1.1);
    }

    :host([active]:not([checked])) [part='checkbox']::before {
      transition-duration: 0.01s, 0.01s;
      transform: scale(0);
      opacity: 0.4;
    }

    /* Required */
    :host([required]) [part='required-indicator'] {
      position: absolute;
      top: var(--lumo-space-xs);
      right: var(--lumo-space-xs);
    }

    :host([required][dir='rtl']) [part='required-indicator'] {
      right: auto;
      left: var(--lumo-space-xs);
    }

    :host([required]) [part='required-indicator']::after {
      content: var(--lumo-required-field-indicator, '\\2022');
      transition: opacity 0.2s;
      color: var(--lumo-required-field-indicator-color, var(--lumo-primary-text-color));
      width: 1em;
      text-align: center;
    }

    :host(:not([has-label])) [part='required-indicator'] {
      display: none;
    }

    /* Invalid */
    :host([invalid]) {
      --vaadin-input-field-border-color: var(--lumo-error-color);
    }

    :host([invalid]) [part='checkbox'] {
      background: var(--_invalid-background);
      background-image: linear-gradient(var(--_invalid-background) 0%, var(--_invalid-background) 100%);
    }

    :host([invalid]:hover) [part='checkbox'] {
      background-image: linear-gradient(var(--_invalid-background) 0%, var(--_invalid-background) 100%),
        linear-gradient(var(--_invalid-background) 0%, var(--_invalid-background) 100%);
    }

    :host([invalid][focus-ring]) {
      --_focus-ring-color: var(--lumo-error-color-50pct);
    }

    :host([invalid]) [part='required-indicator']::after {
      color: var(--lumo-required-field-indicator-color, var(--lumo-error-text-color));
    }

    /* Error message */
    [part='error-message'] {
      font-size: var(--vaadin-input-field-error-font-size, var(--lumo-font-size-xs));
      line-height: var(--lumo-line-height-xs);
      font-weight: var(--vaadin-input-field-error-font-weight, 400);
      color: var(--vaadin-input-field-error-color, var(--lumo-error-text-color));
      will-change: max-height;
      transition: 0.4s max-height;
      max-height: 5em;
      padding-inline-start: var(--lumo-space-xs);
    }

    :host([has-error-message]) [part='error-message']::after,
    :host([has-helper]) [part='helper-text']::after {
      content: '';
      display: block;
      height: 0.4em;
    }

    :host(:not([invalid])) [part='error-message'] {
      max-height: 0;
      overflow: hidden;
    }

    /* Helper */
    [part='helper-text'] {
      display: block;
      color: var(--vaadin-input-field-helper-color, var(--lumo-secondary-text-color));
      font-size: var(--vaadin-input-field-helper-font-size, var(--lumo-font-size-xs));
      line-height: var(--lumo-line-height-xs);
      font-weight: var(--vaadin-input-field-helper-font-weight, 400);
      margin-left: calc(var(--lumo-border-radius-m) / 4);
      transition: color 0.2s;
      padding-inline-start: var(--lumo-space-xs);
    }

    :host(:hover:not([readonly])) [part='helper-text'] {
      color: var(--lumo-body-text-color);
    }

    :host([has-error-message]) ::slotted(label),
    :host([has-helper]) ::slotted(label) {
      padding-bottom: 0;
    }
  `,
  { moduleId: "lumo-checkbox" }
);

// node_modules/@vaadin/component-base/src/slot-styles-mixin.js
var stylesMap = /* @__PURE__ */ new WeakMap();
function getRootStyles(root2) {
  if (!stylesMap.has(root2)) {
    stylesMap.set(root2, /* @__PURE__ */ new Set());
  }
  return stylesMap.get(root2);
}
function insertStyles(styles, root2) {
  const style2 = document.createElement("style");
  style2.textContent = styles;
  if (root2 === document) {
    document.head.appendChild(style2);
  } else {
    root2.insertBefore(style2, root2.firstChild);
  }
}
var SlotStylesMixin = dedupingMixin(
  (superclass) => class SlotStylesMixinClass extends superclass {
    /**
     * List of styles to insert into root.
     * @protected
     */
    get slotStyles() {
      return [];
    }
    /** @protected */
    connectedCallback() {
      super.connectedCallback();
      this.__applySlotStyles();
    }
    /** @private */
    __applySlotStyles() {
      const root2 = this.getRootNode();
      const rootStyles = getRootStyles(root2);
      this.slotStyles.forEach((styles) => {
        if (!rootStyles.has(styles)) {
          insertStyles(styles, root2);
          rootStyles.add(styles);
        }
      });
    }
  }
);

// node_modules/@vaadin/component-base/src/delegate-state-mixin.js
var DelegateStateMixin = dedupingMixin(
  (superclass) => class DelegateStateMixinClass extends superclass {
    static get properties() {
      return {
        /**
         * A target element to which attributes and properties are delegated.
         * @protected
         */
        stateTarget: {
          type: Object,
          observer: "_stateTargetChanged"
        }
      };
    }
    /**
     * An array of the host attributes to delegate to the target element.
     */
    static get delegateAttrs() {
      return [];
    }
    /**
     * An array of the host properties to delegate to the target element.
     */
    static get delegateProps() {
      return [];
    }
    /** @protected */
    ready() {
      super.ready();
      this._createDelegateAttrsObserver();
      this._createDelegatePropsObserver();
    }
    /** @protected */
    _stateTargetChanged(target) {
      if (target) {
        this._ensureAttrsDelegated();
        this._ensurePropsDelegated();
      }
    }
    /** @protected */
    _createDelegateAttrsObserver() {
      this._createMethodObserver(`_delegateAttrsChanged(${this.constructor.delegateAttrs.join(", ")})`);
    }
    /** @protected */
    _createDelegatePropsObserver() {
      this._createMethodObserver(`_delegatePropsChanged(${this.constructor.delegateProps.join(", ")})`);
    }
    /** @protected */
    _ensureAttrsDelegated() {
      this.constructor.delegateAttrs.forEach((name) => {
        this._delegateAttribute(name, this[name]);
      });
    }
    /** @protected */
    _ensurePropsDelegated() {
      this.constructor.delegateProps.forEach((name) => {
        this._delegateProperty(name, this[name]);
      });
    }
    /** @protected */
    _delegateAttrsChanged(...values) {
      this.constructor.delegateAttrs.forEach((name, index) => {
        this._delegateAttribute(name, values[index]);
      });
    }
    /** @protected */
    _delegatePropsChanged(...values) {
      this.constructor.delegateProps.forEach((name, index) => {
        this._delegateProperty(name, values[index]);
      });
    }
    /** @protected */
    _delegateAttribute(name, value) {
      if (!this.stateTarget) {
        return;
      }
      if (name === "invalid") {
        this._delegateAttribute("aria-invalid", value ? "true" : false);
      }
      if (typeof value === "boolean") {
        this.stateTarget.toggleAttribute(name, value);
      } else if (value) {
        this.stateTarget.setAttribute(name, value);
      } else {
        this.stateTarget.removeAttribute(name);
      }
    }
    /** @protected */
    _delegateProperty(name, value) {
      if (!this.stateTarget) {
        return;
      }
      this.stateTarget[name] = value;
    }
  }
);

// node_modules/@vaadin/field-base/src/input-mixin.js
var InputMixin = dedupingMixin(
  (superclass) => class InputMixinClass extends superclass {
    static get properties() {
      return {
        /**
         * A reference to the input element controlled by the mixin.
         * Any component implementing this mixin is expected to provide it
         * by using `this._setInputElement(input)` Polymer API.
         *
         * A typical case is using `InputController` that does this automatically.
         * However, the input element does not have to always be native <input>:
         * as an example, <vaadin-combo-box-light> accepts other components.
         *
         * @protected
         * @type {!HTMLElement}
         */
        inputElement: {
          type: Object,
          readOnly: true,
          observer: "_inputElementChanged"
        },
        /**
         * String used to define input type.
         * @protected
         */
        type: {
          type: String,
          readOnly: true
        },
        /**
         * The value of the field.
         */
        value: {
          type: String,
          value: "",
          observer: "_valueChanged",
          notify: true,
          sync: true
        },
        /**
         * Whether the input element has a non-empty value.
         *
         * @protected
         */
        _hasInputValue: {
          type: Boolean,
          value: false,
          observer: "_hasInputValueChanged"
        }
      };
    }
    constructor() {
      super();
      this._boundOnInput = this.__onInput.bind(this);
      this._boundOnChange = this._onChange.bind(this);
    }
    /**
     * Indicates whether the value is different from the default one.
     * Override if the `value` property has a type other than `string`.
     *
     * @protected
     */
    get _hasValue() {
      return this.value != null && this.value !== "";
    }
    /**
     * A property for accessing the input element's value.
     *
     * Override this getter if the property is different from the default `value` one.
     *
     * @protected
     * @return {string}
     */
    get _inputElementValueProperty() {
      return "value";
    }
    /**
     * The input element's value.
     *
     * @protected
     * @return {string}
     */
    get _inputElementValue() {
      return this.inputElement ? this.inputElement[this._inputElementValueProperty] : void 0;
    }
    /**
     * The input element's value.
     *
     * @protected
     */
    set _inputElementValue(value) {
      if (this.inputElement) {
        this.inputElement[this._inputElementValueProperty] = value;
      }
      this._hasInputValue = value && value.length > 0;
    }
    /**
     * Clear the value of the field.
     */
    clear() {
      this._hasInputValue = false;
      this.value = "";
      this._inputElementValue = "";
    }
    /**
     * Add event listeners to the input element instance.
     * Override this method to add custom listeners.
     * @param {!HTMLElement} input
     * @protected
     */
    _addInputListeners(input) {
      input.addEventListener("input", this._boundOnInput);
      input.addEventListener("change", this._boundOnChange);
    }
    /**
     * Remove event listeners from the input element instance.
     * @param {!HTMLElement} input
     * @protected
     */
    _removeInputListeners(input) {
      input.removeEventListener("input", this._boundOnInput);
      input.removeEventListener("change", this._boundOnChange);
    }
    /**
     * A method to forward the value property set on the field
     * programmatically back to the input element value.
     * Override this method to perform additional checks,
     * for example to skip this in certain conditions.
     * @param {string} value
     * @protected
     */
    _forwardInputValue(value) {
      if (!this.inputElement) {
        return;
      }
      this._inputElementValue = value != null ? value : "";
    }
    /**
     * @param {HTMLElement | undefined} input
     * @param {HTMLElement | undefined} oldInput
     * @protected
     */
    _inputElementChanged(input, oldInput) {
      if (input) {
        this._addInputListeners(input);
      } else if (oldInput) {
        this._removeInputListeners(oldInput);
      }
    }
    /**
     * Observer to notify about the change of private property.
     *
     * @private
     */
    _hasInputValueChanged(hasValue, oldHasValue) {
      if (hasValue || oldHasValue) {
        this.dispatchEvent(new CustomEvent("has-input-value-changed"));
      }
    }
    /**
     * An input event listener used to update `_hasInputValue` property.
     * Do not override this method.
     *
     * @param {Event} event
     * @private
     */
    __onInput(event) {
      this._setHasInputValue(event);
      this._onInput(event);
    }
    /**
     * An input event listener used to update the field value.
     *
     * @param {Event} event
     * @protected
     */
    _onInput(event) {
      const target = event.composedPath()[0];
      this.__userInput = event.isTrusted;
      this.value = target.value;
      this.__userInput = false;
    }
    /**
     * A change event listener.
     * Override this method with an actual implementation.
     * @param {Event} _event
     * @protected
     */
    _onChange(_event) {
    }
    /**
     * Toggle the has-value attribute based on the value property.
     *
     * @param {boolean} hasValue
     * @protected
     */
    _toggleHasValue(hasValue) {
      this.toggleAttribute("has-value", hasValue);
    }
    /**
     * Observer called when a value property changes.
     * @param {string | undefined} newVal
     * @param {string | undefined} oldVal
     * @protected
     */
    _valueChanged(newVal, oldVal) {
      this._toggleHasValue(this._hasValue);
      if (newVal === "" && oldVal === void 0) {
        return;
      }
      if (this.__userInput) {
        return;
      }
      this._forwardInputValue(newVal);
    }
    /**
     * Sets the `_hasInputValue` property based on the `input` event.
     *
     * @param {InputEvent} event
     * @protected
     */
    _setHasInputValue(event) {
      const target = event.composedPath()[0];
      this._hasInputValue = target.value.length > 0;
    }
  }
);

// node_modules/@vaadin/field-base/src/checked-mixin.js
var CheckedMixin = dedupingMixin(
  (superclass) => class CheckedMixinClass extends DelegateStateMixin(DisabledMixin(InputMixin(superclass))) {
    static get properties() {
      return {
        /**
         * True if the element is checked.
         * @type {boolean}
         */
        checked: {
          type: Boolean,
          value: false,
          notify: true,
          reflectToAttribute: true,
          sync: true
        }
      };
    }
    static get delegateProps() {
      return [...super.delegateProps, "checked"];
    }
    /**
     * @param {Event} event
     * @protected
     * @override
     */
    _onChange(event) {
      const input = event.target;
      this._toggleChecked(input.checked);
    }
    /** @protected */
    _toggleChecked(checked) {
      this.checked = checked;
    }
  }
);

// node_modules/@vaadin/component-base/src/slot-child-observe-controller.js
var SlotChildObserveController = class extends SlotController {
  constructor(host, slot, tagName, config = {}) {
    super(host, slot, tagName, __spreadProps(__spreadValues({}, config), { useUniqueId: true }));
  }
  /**
   * Override to initialize the newly added custom node.
   *
   * @param {Node} node
   * @protected
   * @override
   */
  initCustomNode(node) {
    this.__updateNodeId(node);
    this.__notifyChange(node);
  }
  /**
   * Override to notify the controller host about removal of
   * the custom node, and to apply the default one if needed.
   *
   * @param {Node} _node
   * @protected
   * @override
   */
  teardownNode(_node) {
    const node = this.getSlotChild();
    if (node && node !== this.defaultNode) {
      this.__notifyChange(node);
    } else {
      this.restoreDefaultNode();
      this.updateDefaultNode(this.node);
    }
  }
  /**
   * Override method inherited from `SlotMixin`
   * to set ID attribute on the default node.
   *
   * @return {Node}
   * @protected
   * @override
   */
  attachDefaultNode() {
    const node = super.attachDefaultNode();
    if (node) {
      this.__updateNodeId(node);
    }
    return node;
  }
  /**
   * Override to restore default node when a custom one is removed.
   *
   * @protected
   */
  restoreDefaultNode() {
  }
  /**
   * Override to update default node text on property change.
   *
   * @param {Node} node
   * @protected
   */
  updateDefaultNode(node) {
    this.__notifyChange(node);
  }
  /**
   * Setup the mutation observer on the node to update ID and notify host.
   * Node doesn't get observed automatically until this method is called.
   *
   * @param {Node} node
   * @protected
   */
  observeNode(node) {
    if (this.__nodeObserver) {
      this.__nodeObserver.disconnect();
    }
    this.__nodeObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        const target = mutation.target;
        const isCurrentNodeMutation = target === this.node;
        if (mutation.type === "attributes") {
          if (isCurrentNodeMutation) {
            this.__updateNodeId(target);
          }
        } else if (isCurrentNodeMutation || target.parentElement === this.node) {
          this.__notifyChange(this.node);
        }
      });
    });
    this.__nodeObserver.observe(node, {
      attributes: true,
      attributeFilter: ["id"],
      childList: true,
      subtree: true,
      characterData: true
    });
  }
  /**
   * Returns true if a node is an HTML element with children,
   * or is a defined custom element, or has non-empty text.
   *
   * @param {Node} node
   * @return {boolean}
   * @private
   */
  __hasContent(node) {
    if (!node) {
      return false;
    }
    return node.nodeType === Node.ELEMENT_NODE && (customElements.get(node.localName) || node.children.length > 0) || node.textContent && node.textContent.trim() !== "";
  }
  /**
   * Fire an event to notify the controller host about node changes.
   *
   * @param {Node} node
   * @private
   */
  __notifyChange(node) {
    this.dispatchEvent(
      new CustomEvent("slot-content-changed", {
        detail: { hasContent: this.__hasContent(node), node }
      })
    );
  }
  /**
   * Set default ID on the node in case it is an HTML element.
   *
   * @param {Node} node
   * @private
   */
  __updateNodeId(node) {
    const isFirstNode = !this.nodes || node === this.nodes[0];
    if (node.nodeType === Node.ELEMENT_NODE && (!this.multiple || isFirstNode) && !node.id) {
      node.id = this.defaultId;
    }
  }
};

// node_modules/@vaadin/field-base/src/error-controller.js
var ErrorController = class extends SlotChildObserveController {
  constructor(host) {
    super(host, "error-message", "div");
  }
  /**
   * Set the error message element text content.
   *
   * @param {string} errorMessage
   */
  setErrorMessage(errorMessage) {
    this.errorMessage = errorMessage;
    this.updateDefaultNode(this.node);
  }
  /**
   * Set invalid state for detecting whether to show error message.
   *
   * @param {boolean} invalid
   */
  setInvalid(invalid) {
    this.invalid = invalid;
    this.updateDefaultNode(this.node);
  }
  /**
   * Override method inherited from `SlotController` to not run
   * initializer on the custom slotted node unnecessarily.
   *
   * @param {Node} node
   * @protected
   * @override
   */
  initAddedNode(node) {
    if (node !== this.defaultNode) {
      this.initCustomNode(node);
    }
  }
  /**
   * Override to initialize the newly added default error message.
   *
   * @param {Node} errorNode
   * @protected
   * @override
   */
  initNode(errorNode) {
    this.updateDefaultNode(errorNode);
  }
  /**
   * Override to initialize the newly added custom error message.
   *
   * @param {Node} errorNode
   * @protected
   * @override
   */
  initCustomNode(errorNode) {
    if (errorNode.textContent && !this.errorMessage) {
      this.errorMessage = errorNode.textContent.trim();
    }
    super.initCustomNode(errorNode);
  }
  /**
   * Override method inherited from `SlotChildObserveController`
   * to restore the default error message element.
   *
   * @protected
   * @override
   */
  restoreDefaultNode() {
    this.attachDefaultNode();
  }
  /**
   * Override method inherited from `SlotChildObserveController`
   * to update the error message text and hidden state.
   *
   * Note: unlike with other controllers, this method is
   * called for both default and custom error message.
   *
   * @param {Node | undefined} node
   * @protected
   * @override
   */
  updateDefaultNode(errorNode) {
    const { errorMessage, invalid } = this;
    const hasError = Boolean(invalid && errorMessage && errorMessage.trim() !== "");
    if (errorNode) {
      errorNode.textContent = hasError ? errorMessage : "";
      errorNode.hidden = !hasError;
      if (hasError) {
        announce(errorMessage, { mode: "assertive" });
      }
    }
    super.updateDefaultNode(errorNode);
  }
};

// node_modules/@vaadin/field-base/src/helper-controller.js
var HelperController = class extends SlotChildObserveController {
  constructor(host) {
    super(host, "helper", null);
  }
  /**
   * Set helper text based on corresponding host property.
   *
   * @param {string} helperText
   */
  setHelperText(helperText) {
    this.helperText = helperText;
    const helperNode = this.getSlotChild();
    if (!helperNode) {
      this.restoreDefaultNode();
    }
    if (this.node === this.defaultNode) {
      this.updateDefaultNode(this.node);
    }
  }
  /**
   * Override method inherited from `SlotChildObserveController`
   * to create the default helper element lazily as needed.
   *
   * @param {Node | undefined} node
   * @protected
   * @override
   */
  restoreDefaultNode() {
    const { helperText } = this;
    if (helperText && helperText.trim() !== "") {
      this.tagName = "div";
      const helperNode = this.attachDefaultNode();
      this.observeNode(helperNode);
    }
  }
  /**
   * Override method inherited from `SlotChildObserveController`
   * to update the default helper element text content.
   *
   * @param {Node | undefined} node
   * @protected
   * @override
   */
  updateDefaultNode(node) {
    if (node) {
      node.textContent = this.helperText;
    }
    super.updateDefaultNode(node);
  }
  /**
   * Override to observe the newly added custom node.
   *
   * @param {Node} node
   * @protected
   * @override
   */
  initCustomNode(node) {
    super.initCustomNode(node);
    this.observeNode(node);
  }
};

// node_modules/@vaadin/field-base/src/label-controller.js
var LabelController = class extends SlotChildObserveController {
  constructor(host) {
    super(host, "label", "label");
  }
  /**
   * Set label based on corresponding host property.
   *
   * @param {string} label
   */
  setLabel(label) {
    this.label = label;
    const labelNode = this.getSlotChild();
    if (!labelNode) {
      this.restoreDefaultNode();
    }
    if (this.node === this.defaultNode) {
      this.updateDefaultNode(this.node);
    }
  }
  /**
   * Override method inherited from `SlotChildObserveController`
   * to restore and observe the default label element.
   *
   * @protected
   * @override
   */
  restoreDefaultNode() {
    const { label } = this;
    if (label && label.trim() !== "") {
      const labelNode = this.attachDefaultNode();
      this.observeNode(labelNode);
    }
  }
  /**
   * Override method inherited from `SlotChildObserveController`
   * to update the default label element text content.
   *
   * @param {Node | undefined} node
   * @protected
   * @override
   */
  updateDefaultNode(node) {
    if (node) {
      node.textContent = this.label;
    }
    super.updateDefaultNode(node);
  }
  /**
   * Override to observe the newly added custom node.
   *
   * @param {Node} node
   * @protected
   * @override
   */
  initCustomNode(node) {
    super.initCustomNode(node);
    this.observeNode(node);
  }
};

// node_modules/@vaadin/field-base/src/label-mixin.js
var LabelMixin = dedupingMixin(
  (superclass) => class LabelMixinClass extends ControllerMixin(superclass) {
    static get properties() {
      return {
        /**
         * The label text for the input node.
         * When no light dom defined via [slot=label], this value will be used.
         */
        label: {
          type: String,
          observer: "_labelChanged"
        }
      };
    }
    constructor() {
      super();
      this._labelController = new LabelController(this);
      this._labelController.addEventListener("slot-content-changed", (event) => {
        this.toggleAttribute("has-label", event.detail.hasContent);
      });
    }
    /** @protected */
    get _labelId() {
      const node = this._labelNode;
      return node && node.id;
    }
    /** @protected */
    get _labelNode() {
      return this._labelController.node;
    }
    /** @protected */
    ready() {
      super.ready();
      this.addController(this._labelController);
    }
    /** @protected */
    _labelChanged(label) {
      this._labelController.setLabel(label);
    }
  }
);

// node_modules/@vaadin/field-base/src/validate-mixin.js
var ValidateMixin = dedupingMixin(
  (superclass) => class ValidateMixinClass extends superclass {
    static get properties() {
      return {
        /**
         * Set to true when the field is invalid.
         */
        invalid: {
          type: Boolean,
          reflectToAttribute: true,
          notify: true,
          value: false
        },
        /**
         * Set to true to enable manual validation mode. This mode disables automatic
         * constraint validation, allowing you to control the validation process yourself.
         * You can still trigger constraint validation manually with the `validate()` method
         * or use `checkValidity()` to assess the component's validity without affecting
         * the invalid state. In manual validation mode, you can also manipulate
         * the `invalid` property directly through your application logic without conflicts
         * with the component's internal validation.
         *
         * @attr {boolean} manual-validation
         */
        manualValidation: {
          type: Boolean,
          value: false
        },
        /**
         * Specifies that the user must fill in a value.
         */
        required: {
          type: Boolean,
          reflectToAttribute: true
        }
      };
    }
    /**
     * Validates the field and sets the `invalid` property based on the result.
     *
     * The method fires a `validated` event with the result of the validation.
     *
     * @return {boolean} True if the value is valid.
     */
    validate() {
      const isValid = this.checkValidity();
      this._setInvalid(!isValid);
      this.dispatchEvent(new CustomEvent("validated", { detail: { valid: isValid } }));
      return isValid;
    }
    /**
     * Returns true if the field value satisfies all constraints (if any).
     *
     * @return {boolean}
     */
    checkValidity() {
      return !this.required || !!this.value;
    }
    /**
     * @param {boolean} invalid
     * @protected
     */
    _setInvalid(invalid) {
      if (this._shouldSetInvalid(invalid)) {
        this.invalid = invalid;
      }
    }
    /**
     * Override this method to define whether the given `invalid` state should be set.
     *
     * @param {boolean} _invalid
     * @return {boolean}
     * @protected
     */
    _shouldSetInvalid(_invalid) {
      return true;
    }
    /** @protected */
    _requestValidation() {
      if (!this.manualValidation) {
        this.validate();
      }
    }
    /**
     * Fired whenever the field is validated.
     *
     * @event validated
     * @param {Object} detail
     * @param {boolean} detail.valid the result of the validation.
     */
  }
);

// node_modules/@vaadin/field-base/src/field-mixin.js
var FieldMixin = (superclass) => class FieldMixinClass extends ValidateMixin(LabelMixin(ControllerMixin(superclass))) {
  static get properties() {
    return {
      /**
       * A target element to which ARIA attributes are set.
       * @protected
       */
      ariaTarget: {
        type: Object,
        observer: "_ariaTargetChanged"
      },
      /**
       * Error to show when the field is invalid.
       *
       * @attr {string} error-message
       */
      errorMessage: {
        type: String,
        observer: "_errorMessageChanged"
      },
      /**
       * String used for the helper text.
       * @attr {string} helper-text
       */
      helperText: {
        type: String,
        observer: "_helperTextChanged"
      },
      /**
       * String used to label the component to screen reader users.
       * @attr {string} accessible-name
       */
      accessibleName: {
        type: String,
        observer: "_accessibleNameChanged"
      },
      /**
       * Id of the element used as label of the component to screen reader users.
       * @attr {string} accessible-name-ref
       */
      accessibleNameRef: {
        type: String,
        observer: "_accessibleNameRefChanged"
      }
    };
  }
  static get observers() {
    return ["_invalidChanged(invalid)", "_requiredChanged(required)"];
  }
  constructor() {
    super();
    this._fieldAriaController = new FieldAriaController(this);
    this._helperController = new HelperController(this);
    this._errorController = new ErrorController(this);
    this._errorController.addEventListener("slot-content-changed", (event) => {
      this.toggleAttribute("has-error-message", event.detail.hasContent);
    });
    this._labelController.addEventListener("slot-content-changed", (event) => {
      const { hasContent, node } = event.detail;
      this.__labelChanged(hasContent, node);
    });
    this._helperController.addEventListener("slot-content-changed", (event) => {
      const { hasContent, node } = event.detail;
      this.toggleAttribute("has-helper", hasContent);
      this.__helperChanged(hasContent, node);
    });
  }
  /**
   * @protected
   * @return {HTMLElement}
   */
  get _errorNode() {
    return this._errorController.node;
  }
  /**
   * @protected
   * @return {HTMLElement}
   */
  get _helperNode() {
    return this._helperController.node;
  }
  /** @protected */
  ready() {
    super.ready();
    this.addController(this._fieldAriaController);
    this.addController(this._helperController);
    this.addController(this._errorController);
  }
  /** @private */
  __helperChanged(hasHelper, helperNode) {
    if (hasHelper) {
      this._fieldAriaController.setHelperId(helperNode.id);
    } else {
      this._fieldAriaController.setHelperId(null);
    }
  }
  /** @protected */
  _accessibleNameChanged(accessibleName) {
    this._fieldAriaController.setAriaLabel(accessibleName);
  }
  /** @protected */
  _accessibleNameRefChanged(accessibleNameRef) {
    this._fieldAriaController.setLabelId(accessibleNameRef, true);
  }
  /** @private */
  __labelChanged(hasLabel, labelNode) {
    if (hasLabel) {
      this._fieldAriaController.setLabelId(labelNode.id);
    } else {
      this._fieldAriaController.setLabelId(null);
    }
  }
  /**
   * @param {string | null | undefined} errorMessage
   * @protected
   */
  _errorMessageChanged(errorMessage) {
    this._errorController.setErrorMessage(errorMessage);
  }
  /**
   * @param {string} helperText
   * @protected
   */
  _helperTextChanged(helperText) {
    this._helperController.setHelperText(helperText);
  }
  /**
   * @param {HTMLElement | null | undefined} target
   * @protected
   */
  _ariaTargetChanged(target) {
    if (target) {
      this._fieldAriaController.setTarget(target);
    }
  }
  /**
   * @param {boolean} required
   * @protected
   */
  _requiredChanged(required) {
    this._fieldAriaController.setRequired(required);
  }
  /**
   * @param {boolean} invalid
   * @protected
   */
  _invalidChanged(invalid) {
    this._errorController.setInvalid(invalid);
    setTimeout(() => {
      if (invalid) {
        const node = this._errorNode;
        this._fieldAriaController.setErrorId(node && node.id);
      } else {
        this._fieldAriaController.setErrorId(null);
      }
    });
  }
};

// node_modules/@vaadin/field-base/src/input-controller.js
var InputController = class extends SlotController {
  constructor(host, callback, options = {}) {
    const { uniqueIdPrefix } = options;
    super(host, "input", "input", {
      initializer: (node, host2) => {
        if (host2.value) {
          node.value = host2.value;
        }
        if (host2.type) {
          node.setAttribute("type", host2.type);
        }
        node.id = this.defaultId;
        if (typeof callback === "function") {
          callback(node);
        }
      },
      useUniqueId: true,
      uniqueIdPrefix
    });
  }
};

// node_modules/@vaadin/field-base/src/labelled-input-controller.js
var LabelledInputController = class {
  constructor(input, labelController) {
    this.input = input;
    this.__preventDuplicateLabelClick = this.__preventDuplicateLabelClick.bind(this);
    labelController.addEventListener("slot-content-changed", (event) => {
      this.__initLabel(event.detail.node);
    });
    this.__initLabel(labelController.node);
  }
  /**
   * @param {HTMLElement} label
   * @private
   */
  __initLabel(label) {
    if (label) {
      label.addEventListener("click", this.__preventDuplicateLabelClick);
      if (this.input) {
        label.setAttribute("for", this.input.id);
      }
    }
  }
  /**
   * The native platform fires an event for both the click on the label, and also
   * the subsequent click on the native input element caused by label click.
   * This results in two click events arriving at the host, but we only want one.
   * This method prevents the duplicate click and ensures the correct isTrusted event
   * with the correct event.target arrives at the host.
   * @private
   */
  __preventDuplicateLabelClick() {
    const inputClickHandler = (e13) => {
      e13.stopImmediatePropagation();
      this.input.removeEventListener("click", inputClickHandler);
    };
    this.input.addEventListener("click", inputClickHandler);
  }
};

// node_modules/@vaadin/checkbox/src/vaadin-checkbox-mixin.js
var CheckboxMixin = (superclass) => class CheckboxMixinClass extends SlotStylesMixin(
  FieldMixin(CheckedMixin(DelegateFocusMixin(ActiveMixin(superclass))))
) {
  static get properties() {
    return {
      /**
       * True if the checkbox is in the indeterminate state which means
       * it is not possible to say whether it is checked or unchecked.
       * The state is reset once the user switches the checkbox by hand.
       *
       * https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/checkbox#Indeterminate_state_checkboxes
       *
       * @type {boolean}
       */
      indeterminate: {
        type: Boolean,
        notify: true,
        value: false,
        reflectToAttribute: true
      },
      /**
       * The name of the checkbox.
       *
       * @type {string}
       */
      name: {
        type: String,
        value: ""
      },
      /**
       * When true, the user cannot modify the value of the checkbox.
       * The difference between `disabled` and `readonly` is that the
       * read-only checkbox remains focusable, is announced by screen
       * readers and its value can be submitted as part of the form.
       */
      readonly: {
        type: Boolean,
        value: false,
        reflectToAttribute: true
      },
      /**
       * Indicates whether the element can be focused and where it participates in sequential keyboard navigation.
       *
       * @override
       * @protected
       */
      tabindex: {
        type: Number,
        value: 0,
        reflectToAttribute: true
      }
    };
  }
  static get observers() {
    return ["__readonlyChanged(readonly, inputElement)"];
  }
  /** @override */
  static get delegateProps() {
    return [...super.delegateProps, "indeterminate"];
  }
  /** @override */
  static get delegateAttrs() {
    return [...super.delegateAttrs, "name", "invalid", "required"];
  }
  constructor() {
    super();
    this._setType("checkbox");
    this._boundOnInputClick = this._onInputClick.bind(this);
    this.value = "on";
  }
  /** @protected */
  get slotStyles() {
    const tag = this.localName;
    return [
      `
          ${tag} > input[slot='input'] {
            opacity: 0;
          }
        `
    ];
  }
  /** @protected */
  ready() {
    super.ready();
    this.addController(
      new InputController(this, (input) => {
        this._setInputElement(input);
        this._setFocusElement(input);
        this.stateTarget = input;
        this.ariaTarget = input;
      })
    );
    this.addController(new LabelledInputController(this.inputElement, this._labelController));
    this._createMethodObserver("_checkedChanged(checked)");
  }
  /**
   * Override method inherited from `ActiveMixin` to prevent setting `active`
   * attribute when readonly, or when clicking a link placed inside the label,
   * or when clicking slotted helper or error message element.
   *
   * @param {Event} event
   * @return {boolean}
   * @protected
   * @override
   */
  _shouldSetActive(event) {
    if (this.readonly || event.target.localName === "a" || event.target === this._helperNode || event.target === this._errorNode) {
      return false;
    }
    return super._shouldSetActive(event);
  }
  /**
   * Override method inherited from `InputMixin`.
   * @param {!HTMLElement} input
   * @protected
   * @override
   */
  _addInputListeners(input) {
    super._addInputListeners(input);
    input.addEventListener("click", this._boundOnInputClick);
  }
  /**
   * Override method inherited from `InputMixin`.
   * @param {!HTMLElement} input
   * @protected
   * @override
   */
  _removeInputListeners(input) {
    super._removeInputListeners(input);
    input.removeEventListener("click", this._boundOnInputClick);
  }
  /** @private */
  _onInputClick(event) {
    if (this.readonly) {
      event.preventDefault();
    }
  }
  /** @private */
  __readonlyChanged(readonly, inputElement) {
    if (!inputElement) {
      return;
    }
    if (readonly) {
      inputElement.setAttribute("aria-readonly", "true");
    } else {
      inputElement.removeAttribute("aria-readonly");
    }
  }
  /**
   * Override method inherited from `CheckedMixin` to reset
   * `indeterminate` state checkbox is toggled by the user.
   *
   * @param {boolean} checked
   * @protected
   * @override
   */
  _toggleChecked(checked) {
    if (this.indeterminate) {
      this.indeterminate = false;
    }
    super._toggleChecked(checked);
  }
  /**
   * @override
   * @return {boolean}
   */
  checkValidity() {
    return !this.required || !!this.checked;
  }
  /**
   * Override method inherited from `FocusMixin` to validate on blur.
   * @param {boolean} focused
   * @protected
   */
  _setFocused(focused) {
    super._setFocused(focused);
    if (!focused && document.hasFocus()) {
      this._requestValidation();
    }
  }
  /** @private */
  _checkedChanged(checked) {
    if (checked || this.__oldChecked) {
      this._requestValidation();
    }
    this.__oldChecked = checked;
  }
  /**
   * Override an observer from `FieldMixin`
   * to validate when required is removed.
   *
   * @protected
   * @override
   */
  _requiredChanged(required) {
    super._requiredChanged(required);
    if (required === false) {
      this._requestValidation();
    }
  }
  /** @private */
  _onRequiredIndicatorClick() {
    this._labelNode.click();
  }
  /**
   * Fired when the checkbox is checked or unchecked by the user.
   *
   * @event change
   */
};

// node_modules/@vaadin/checkbox/src/vaadin-checkbox-styles.js
var checkboxStyles = css`
  :host {
    display: inline-block;
  }

  :host([hidden]) {
    display: none !important;
  }

  :host([disabled]) {
    -webkit-tap-highlight-color: transparent;
  }

  .vaadin-checkbox-container {
    display: grid;
    grid-template-columns: auto 1fr;
    align-items: baseline;
  }

  [part='checkbox'],
  ::slotted(input),
  [part='label'] {
    grid-row: 1;
  }

  [part='checkbox'],
  ::slotted(input) {
    grid-column: 1;
  }

  [part='helper-text'],
  [part='error-message'] {
    grid-column: 2;
  }

  :host(:not([has-helper])) [part='helper-text'],
  :host(:not([has-error-message])) [part='error-message'] {
    display: none;
  }

  [part='checkbox'] {
    width: var(--vaadin-checkbox-size, 1em);
    height: var(--vaadin-checkbox-size, 1em);
    --_input-border-width: var(--vaadin-input-field-border-width, 0);
    --_input-border-color: var(--vaadin-input-field-border-color, transparent);
    box-shadow: inset 0 0 0 var(--_input-border-width, 0) var(--_input-border-color);
  }

  [part='checkbox']::before {
    display: block;
    content: '\\202F';
    line-height: var(--vaadin-checkbox-size, 1em);
    contain: paint;
  }

  /* visually hidden */
  ::slotted(input) {
    cursor: inherit;
    margin: 0;
    align-self: stretch;
    -webkit-appearance: none;
    width: initial;
    height: initial;
  }

  @media (forced-colors: active) {
    [part='checkbox'] {
      outline: 1px solid;
      outline-offset: -1px;
    }

    :host([disabled]) [part='checkbox'],
    :host([disabled]) [part='checkbox']::after {
      outline-color: GrayText;
    }

    :host(:is([checked], [indeterminate])) [part='checkbox']::after {
      outline: 1px solid;
      outline-offset: -1px;
      border-radius: inherit;
    }

    :host([focused]) [part='checkbox'],
    :host([focused]) [part='checkbox']::after {
      outline-width: 2px;
    }
  }
`;

// node_modules/@vaadin/checkbox/src/vaadin-checkbox.js
registerStyles("vaadin-checkbox", checkboxStyles, { moduleId: "vaadin-checkbox-styles" });
var Checkbox = class extends CheckboxMixin(ElementMixin2(ThemableMixin(PolymerElement))) {
  static get is() {
    return "vaadin-checkbox";
  }
  static get template() {
    return html`
      <div class="vaadin-checkbox-container">
        <div part="checkbox" aria-hidden="true"></div>
        <slot name="input"></slot>
        <div part="label">
          <slot name="label"></slot>
          <div part="required-indicator" on-click="_onRequiredIndicatorClick"></div>
        </div>
        <div part="helper-text">
          <slot name="helper"></slot>
        </div>
        <div part="error-message">
          <slot name="error-message"></slot>
        </div>
      </div>
      <slot name="tooltip"></slot>
    `;
  }
  /** @protected */
  ready() {
    super.ready();
    this._tooltipController = new TooltipController(this);
    this._tooltipController.setAriaTarget(this.inputElement);
    this.addController(this._tooltipController);
  }
};
defineCustomElement(Checkbox);

// node_modules/@vaadin/grid/src/vaadin-grid-selection-column-base-mixin.js
var GridSelectionColumnBaseMixin = (superClass) => class GridSelectionColumnBaseMixin extends superClass {
  static get properties() {
    return {
      /**
       * Width of the cells for this column.
       */
      width: {
        type: String,
        value: "58px",
        sync: true
      },
      /**
       * Override `autoWidth` to enable auto-width
       */
      autoWidth: {
        type: Boolean,
        value: true
      },
      /**
       * Flex grow ratio for the cell widths. When set to 0, cell width is fixed.
       * @attr {number} flex-grow
       * @type {number}
       */
      flexGrow: {
        type: Number,
        value: 0,
        sync: true
      },
      /**
       * When true, all the items are selected.
       * @attr {boolean} select-all
       * @type {boolean}
       */
      selectAll: {
        type: Boolean,
        value: false,
        notify: true,
        sync: true
      },
      /**
       * When true, the active gets automatically selected.
       * @attr {boolean} auto-select
       * @type {boolean}
       */
      autoSelect: {
        type: Boolean,
        value: false,
        sync: true
      },
      /**
       * When true, rows can be selected by dragging over the selection column.
       * @attr {boolean} drag-select
       * @type {boolean}
       */
      dragSelect: {
        type: Boolean,
        value: false,
        sync: true
      },
      /** @protected */
      _indeterminate: {
        type: Boolean,
        sync: true
      },
      /** @protected */
      _selectAllHidden: Boolean
    };
  }
  static get observers() {
    return [
      "_onHeaderRendererOrBindingChanged(_headerRenderer, _headerCell, path, header, selectAll, _indeterminate, _selectAllHidden)"
    ];
  }
  constructor() {
    super();
    this.__onCellTrack = this.__onCellTrack.bind(this);
    this.__onCellClick = this.__onCellClick.bind(this);
    this.__onCellMouseDown = this.__onCellMouseDown.bind(this);
    this.__onActiveItemChanged = this.__onActiveItemChanged.bind(this);
    this.__onSelectRowCheckboxChange = this.__onSelectRowCheckboxChange.bind(this);
    this.__onSelectAllCheckboxChange = this.__onSelectAllCheckboxChange.bind(this);
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    if (this._grid) {
      this._grid.addEventListener("active-item-changed", this.__onActiveItemChanged);
    }
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    if (this._grid) {
      this._grid.removeEventListener("active-item-changed", this.__onActiveItemChanged);
    }
  }
  /**
   * Renders the Select All checkbox to the header cell.
   *
   * @override
   */
  _defaultHeaderRenderer(root2, _column) {
    let checkbox = root2.firstElementChild;
    if (!checkbox) {
      checkbox = document.createElement("vaadin-checkbox");
      checkbox.setAttribute("aria-label", "Select All");
      checkbox.classList.add("vaadin-grid-select-all-checkbox");
      checkbox.addEventListener("change", this.__onSelectAllCheckboxChange);
      root2.appendChild(checkbox);
    }
    const checked = this.__isChecked(this.selectAll, this._indeterminate);
    checkbox.checked = checked;
    checkbox.hidden = this._selectAllHidden;
    checkbox.indeterminate = this._indeterminate;
  }
  /**
   * Renders the Select Row checkbox to the body cell.
   *
   * @override
   */
  _defaultRenderer(root2, _column, { item, selected }) {
    let checkbox = root2.firstElementChild;
    if (!checkbox) {
      checkbox = document.createElement("vaadin-checkbox");
      checkbox.setAttribute("aria-label", "Select Row");
      checkbox.addEventListener("change", this.__onSelectRowCheckboxChange);
      root2.appendChild(checkbox);
      addListener(root2, "track", this.__onCellTrack);
      root2.addEventListener("mousedown", this.__onCellMouseDown);
      root2.addEventListener("click", this.__onCellClick);
    }
    checkbox.__item = item;
    checkbox.checked = selected;
    const isSelectable = this._grid.__isItemSelectable(item);
    checkbox.readonly = !isSelectable;
    checkbox.hidden = !isSelectable && !selected;
  }
  /**
   * Updates the select all state when the Select All checkbox is switched.
   * The listener handles only user-fired events.
   *
   * @private
   */
  __onSelectAllCheckboxChange(e13) {
    if (this._indeterminate || e13.currentTarget.checked) {
      this._selectAll();
    } else {
      this._deselectAll();
    }
  }
  /**
   * Selects or deselects the row when the Select Row checkbox is switched.
   * The listener handles only user-fired events.
   *
   * @private
   */
  __onSelectRowCheckboxChange(e13) {
    this.__toggleItem(e13.currentTarget.__item, e13.currentTarget.checked);
  }
  /** @private */
  __onCellTrack(event) {
    if (!this.dragSelect) {
      return;
    }
    this.__dragCurrentY = event.detail.y;
    this.__dragDy = event.detail.dy;
    if (event.detail.state === "start") {
      const renderedRows = this._grid._getRenderedRows();
      const dragStartRow = renderedRows.find((row) => row.contains(event.currentTarget.assignedSlot));
      this.__selectOnDrag = !this._grid._isSelected(dragStartRow._item);
      this.__dragStartIndex = dragStartRow.index;
      this.__dragStartItem = dragStartRow._item;
      this.__dragAutoScroller();
    } else if (event.detail.state === "end") {
      if (this.__dragStartItem) {
        this.__toggleItem(this.__dragStartItem, this.__selectOnDrag);
      }
      setTimeout(() => {
        this.__dragStartIndex = void 0;
      });
    }
  }
  /** @private */
  __onCellMouseDown(e13) {
    if (this.dragSelect) {
      e13.preventDefault();
    }
  }
  /** @private */
  __onCellClick(e13) {
    if (this.__dragStartIndex !== void 0) {
      e13.preventDefault();
    }
  }
  /** @private */
  _onCellKeyDown(e13) {
    const target = e13.composedPath()[0];
    if (e13.keyCode !== 32) {
      return;
    }
    if (target === this._headerCell) {
      if (this.selectAll) {
        this._deselectAll();
      } else {
        this._selectAll();
      }
    } else if (this._cells.includes(target) && !this.autoSelect) {
      const checkbox = target._content.firstElementChild;
      this.__toggleItem(checkbox.__item);
    }
  }
  /** @private */
  __onActiveItemChanged(e13) {
    const activeItem = e13.detail.value;
    if (this.autoSelect) {
      const item = activeItem || this.__previousActiveItem;
      if (item) {
        this.__toggleItem(item);
      }
    }
    this.__previousActiveItem = activeItem;
  }
  /** @private */
  __dragAutoScroller() {
    if (this.__dragStartIndex === void 0) {
      return;
    }
    const renderedRows = this._grid._getRenderedRows();
    const hoveredRow = renderedRows.find((row) => {
      const rowRect = row.getBoundingClientRect();
      return this.__dragCurrentY >= rowRect.top && this.__dragCurrentY <= rowRect.bottom;
    });
    let hoveredIndex = hoveredRow ? hoveredRow.index : void 0;
    const scrollableArea = this.__getScrollableArea();
    if (this.__dragCurrentY < scrollableArea.top) {
      hoveredIndex = this._grid._firstVisibleIndex;
    } else if (this.__dragCurrentY > scrollableArea.bottom) {
      hoveredIndex = this._grid._lastVisibleIndex;
    }
    if (hoveredIndex !== void 0) {
      renderedRows.forEach((row) => {
        if (hoveredIndex > this.__dragStartIndex && row.index >= this.__dragStartIndex && row.index <= hoveredIndex || hoveredIndex < this.__dragStartIndex && row.index <= this.__dragStartIndex && row.index >= hoveredIndex) {
          this.__toggleItem(row._item, this.__selectOnDrag);
          this.__dragStartItem = void 0;
        }
      });
    }
    const scrollTriggerArea = scrollableArea.height * 0.15;
    const maxScrollAmount = 10;
    if (this.__dragDy < 0 && this.__dragCurrentY < scrollableArea.top + scrollTriggerArea) {
      const dy = scrollableArea.top + scrollTriggerArea - this.__dragCurrentY;
      const percentage = Math.min(1, dy / scrollTriggerArea);
      this._grid.$.table.scrollTop -= percentage * maxScrollAmount;
    }
    if (this.__dragDy > 0 && this.__dragCurrentY > scrollableArea.bottom - scrollTriggerArea) {
      const dy = this.__dragCurrentY - (scrollableArea.bottom - scrollTriggerArea);
      const percentage = Math.min(1, dy / scrollTriggerArea);
      this._grid.$.table.scrollTop += percentage * maxScrollAmount;
    }
    setTimeout(() => this.__dragAutoScroller(), 10);
  }
  /**
   * Gets the scrollable area of the grid as a bounding client rect. The
   * scrollable area is the bounding rect of the grid minus the header and
   * footer.
   *
   * @private
   */
  __getScrollableArea() {
    const gridRect = this._grid.$.table.getBoundingClientRect();
    const headerRect = this._grid.$.header.getBoundingClientRect();
    const footerRect = this._grid.$.footer.getBoundingClientRect();
    return {
      top: gridRect.top + headerRect.height,
      bottom: gridRect.bottom - footerRect.height,
      left: gridRect.left,
      right: gridRect.right,
      height: gridRect.height - headerRect.height - footerRect.height,
      width: gridRect.width
    };
  }
  /**
   * Override to handle the user selecting all items.
   * @protected
   */
  _selectAll() {
  }
  /**
   * Override to handle the user deselecting all items.
   * @protected
   */
  _deselectAll() {
  }
  /**
   * Override to handle the user selecting an item.
   * @param {Object} item the item to select
   * @protected
   */
  _selectItem(_item) {
  }
  /**
   * Override to handle the user deselecting an item.
   * @param {Object} item the item to deselect
   * @protected
   */
  _deselectItem(_item) {
  }
  /**
   * Toggles the selected state of the given item.
   *
   * @param item the item to toggle
   * @param {boolean} [selected] whether to select or deselect the item
   * @private
   */
  __toggleItem(item, selected = !this._grid._isSelected(item)) {
    if (selected === this._grid._isSelected(item)) {
      return;
    }
    if (selected) {
      this._selectItem(item);
    } else {
      this._deselectItem(item);
    }
  }
  /**
   * IOS needs indeterminate + checked at the same time
   * @private
   */
  __isChecked(selectAll, indeterminate) {
    return indeterminate || selectAll;
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-selection-column-mixin.js
var GridSelectionColumnMixin = (superClass) => class extends GridSelectionColumnBaseMixin(superClass) {
  static get properties() {
    return {
      /**
       * The previous state of activeItem. When activeItem turns to `null`,
       * previousActiveItem will have an Object with just unselected activeItem
       * @private
       */
      __previousActiveItem: Object
    };
  }
  static get observers() {
    return ["__onSelectAllChanged(selectAll)"];
  }
  constructor() {
    super();
    this.__boundUpdateSelectAllVisibility = this.__updateSelectAllVisibility.bind(this);
    this.__boundOnSelectedItemsChanged = this.__onSelectedItemsChanged.bind(this);
  }
  /** @protected */
  disconnectedCallback() {
    this._grid.removeEventListener("data-provider-changed", this.__boundUpdateSelectAllVisibility);
    this._grid.removeEventListener("is-item-selectable-changed", this.__boundUpdateSelectAllVisibility);
    this._grid.removeEventListener("filter-changed", this.__boundOnSelectedItemsChanged);
    this._grid.removeEventListener("selected-items-changed", this.__boundOnSelectedItemsChanged);
    super.disconnectedCallback();
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    if (this._grid) {
      this._grid.addEventListener("data-provider-changed", this.__boundUpdateSelectAllVisibility);
      this._grid.addEventListener("is-item-selectable-changed", this.__boundUpdateSelectAllVisibility);
      this._grid.addEventListener("filter-changed", this.__boundOnSelectedItemsChanged);
      this._grid.addEventListener("selected-items-changed", this.__boundOnSelectedItemsChanged);
      this.__updateSelectAllVisibility();
    }
  }
  /** @private */
  __onSelectAllChanged(selectAll) {
    if (selectAll === void 0 || !this._grid) {
      return;
    }
    if (!this.__selectAllInitialized) {
      this.__selectAllInitialized = true;
      return;
    }
    if (this._selectAllChangeLock) {
      return;
    }
    if (selectAll && this.__hasArrayDataProvider()) {
      this.__withFilteredItemsArray((items) => {
        this._grid.selectedItems = items;
      });
    } else {
      this._grid.selectedItems = [];
    }
  }
  /**
   * Override a method from `GridSelectionColumnBaseMixin` to handle the user
   * selecting all items.
   *
   * @protected
   * @override
   */
  _selectAll() {
    this.selectAll = true;
  }
  /**
   * Override a method from `GridSelectionColumnBaseMixin` to handle the user
   * deselecting all items.
   *
   * @protected
   * @override
   */
  _deselectAll() {
    this.selectAll = false;
  }
  /**
   * Override a method from `GridSelectionColumnBaseMixin` to handle the user
   * selecting an item.
   *
   * @param {Object} item the item to select
   * @protected
   * @override
   */
  _selectItem(item) {
    if (this._grid.__isItemSelectable(item)) {
      this._grid.selectItem(item);
    }
  }
  /**
   * Override a method from `GridSelectionColumnBaseMixin` to handle the user
   * deselecting an item.
   *
   * @param {Object} item the item to deselect
   * @protected
   * @override
   */
  _deselectItem(item) {
    if (this._grid.__isItemSelectable(item)) {
      this._grid.deselectItem(item);
    }
  }
  /** @private */
  __hasArrayDataProvider() {
    return Array.isArray(this._grid.items) && !!this._grid.dataProvider;
  }
  /** @private */
  __onSelectedItemsChanged() {
    this._selectAllChangeLock = true;
    if (this.__hasArrayDataProvider()) {
      this.__withFilteredItemsArray((items) => {
        if (!this._grid.selectedItems.length) {
          this.selectAll = false;
          this._indeterminate = false;
        } else if (items.every((item) => this._grid._isSelected(item))) {
          this.selectAll = true;
          this._indeterminate = false;
        } else {
          this.selectAll = false;
          this._indeterminate = true;
        }
      });
    }
    this._selectAllChangeLock = false;
  }
  /** @private */
  __updateSelectAllVisibility() {
    this._selectAllHidden = !Array.isArray(this._grid.items) || !!this._grid.isItemSelectable;
  }
  /**
   * Assuming the grid uses an items array data provider, fetches all the filtered items
   * from the data provider and invokes the callback with the resulting array.
   *
   * @private
   */
  __withFilteredItemsArray(callback) {
    const params = {
      page: 0,
      pageSize: Infinity,
      sortOrders: [],
      filters: this._grid._mapFilters()
    };
    this._grid.dataProvider(params, (items) => callback(items));
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-selection-column.js
var GridSelectionColumn = class extends GridSelectionColumnMixin(GridColumn) {
  static get is() {
    return "vaadin-grid-selection-column";
  }
};
defineCustomElement(GridSelectionColumn);

// node_modules/@vaadin/grid/theme/lumo/vaadin-grid-sorter-styles.js
registerStyles(
  "vaadin-grid-sorter",
  css`
    :host {
      justify-content: flex-start;
      align-items: baseline;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
      cursor: var(--lumo-clickable-cursor);
    }

    [part='content'] {
      display: inline-block;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    [part='indicators'] {
      margin-left: var(--lumo-space-s);
    }

    [part='indicators']::before {
      transform: scale(0.8);
    }

    :host(:not([direction]):not(:hover)) [part='indicators'] {
      color: var(--lumo-tertiary-text-color);
    }

    :host([direction]) {
      color: var(--vaadin-selection-color-text, var(--lumo-primary-text-color));
    }

    [part='order'] {
      font-size: var(--lumo-font-size-xxs);
      line-height: 1;
    }

    /* RTL specific styles */

    :host([dir='rtl']) [part='indicators'] {
      margin-right: var(--lumo-space-s);
      margin-left: 0;
    }
  `,
  { moduleId: "lumo-grid-sorter" }
);

// node_modules/@vaadin/grid/src/vaadin-grid-sorter-mixin.js
var template = document.createElement("template");
template.innerHTML = `
  <style>
    @font-face {
      font-family: 'vaadin-grid-sorter-icons';
      src: url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAQwAA0AAAAABuwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAEFAAAABkAAAAcfep+mUdERUYAAAP4AAAAHAAAAB4AJwAOT1MvMgAAAZgAAAA/AAAAYA8TBPpjbWFwAAAB7AAAAFUAAAFeF1fZ4mdhc3AAAAPwAAAACAAAAAgAAAAQZ2x5ZgAAAlgAAABcAAAAnMvguMloZWFkAAABMAAAAC8AAAA2C5Ap72hoZWEAAAFgAAAAHQAAACQGbQPHaG10eAAAAdgAAAAUAAAAHAoAAABsb2NhAAACRAAAABIAAAASAIwAYG1heHAAAAGAAAAAFgAAACAACwAKbmFtZQAAArQAAAECAAACZxWCgKhwb3N0AAADuAAAADUAAABZCrApUXicY2BkYGAA4rDECVrx/DZfGbhZGEDgyqNPOxH0/wNMq5kPALkcDEwgUQBWRA0dAHicY2BkYGA+8P8AAwMLAwgwrWZgZEAFbABY4QM8AAAAeJxjYGRgYOAAQiYGEICQSAAAAi8AFgAAeJxjYGY6yziBgZWBgWkm0xkGBoZ+CM34msGYkZMBFTAKoAkwODAwvmRiPvD/AIMDMxCD1CDJKjAwAgBktQsXAHicY2GAAMZQCM0EwqshbAALxAEKeJxjYGBgZoBgGQZGBhCIAPIYwXwWBhsgzcXAwcAEhIwMCi+Z/v/9/x+sSuElA4T9/4k4K1gHFwMMMILMY2QDYmaoABOQYGJABUA7WBiGNwAAJd4NIQAAAAAAAAAACAAIABAAGAAmAEAATgAAeJyNjLENgDAMBP9tIURJwQCMQccSZgk2i5fIYBDAidJjycXr7x5EPwE2wY8si7jmyBNXGo/bNBerxJNrpxhbO3/fEFpx8ZICpV+ghxJ74fAMe+h7Ox14AbrsHB14nK2QQWrDMBRER4mTkhQK3ZRQKOgCNk7oGQqhhEIX2WSlWEI1BAlkJ5CDdNsj5Ey9Rncdi38ES+jzNJo/HwTgATcoDEthhY3wBHc4CE+pfwsX5F/hGe7Vo/AcK/UhvMSz+mGXKhZU6pww8ISz3oWn1BvhgnwTnuEJf8Jz1OpFeIlX9YULDLdFi4ASHolkSR0iuYdjLak1vAequBhj21D61Nqyi6l3qWybGPjySbPHGScGJl6dP58MYcQRI0bts7mjebBqrFENH7t3qWtj0OuqHnXcW7b0HOTZFnKryRGW2hFX1m0O2vEM3opNMfTau+CS6Z3Vx6veNnEXY6jwDxhsc2gAAHicY2BiwA84GBgYmRiYGJkZmBlZGFkZ2djScyoLMgzZS/MyDQwMwLSrpYEBlIbxjQDrzgsuAAAAAAEAAf//AA94nGNgZGBg4AFiMSBmYmAEQnYgZgHzGAAD6wA2eJxjYGBgZACCKyoz1cD0o087YTQATOcIewAAAA==) format('woff');
      font-weight: normal;
      font-style: normal;
    }
  </style>
`;
document.head.appendChild(template.content);
registerStyles(
  "vaadin-grid-sorter",
  css`
    :host {
      display: inline-flex;
      cursor: pointer;
      max-width: 100%;
    }

    [part='content'] {
      flex: 1 1 auto;
    }

    [part='indicators'] {
      position: relative;
      align-self: center;
      flex: none;
    }

    [part='order'] {
      display: inline;
      vertical-align: super;
    }

    [part='indicators']::before {
      font-family: 'vaadin-grid-sorter-icons';
      display: inline-block;
    }

    :host(:not([direction])) [part='indicators']::before {
      content: '\\e901';
    }

    :host([direction='asc']) [part='indicators']::before {
      content: '\\e900';
    }

    :host([direction='desc']) [part='indicators']::before {
      content: '\\e902';
    }
  `,
  { moduleId: "vaadin-grid-sorter-styles" }
);
var GridSorterMixin = (superClass) => class GridSorterMixinClass extends superClass {
  static get properties() {
    return {
      /**
       * JS Path of the property in the item used for sorting the data.
       */
      path: String,
      /**
       * How to sort the data.
       * Possible values are `asc` to use an ascending algorithm, `desc` to sort the data in
       * descending direction, or `null` for not sorting the data.
       * @type {GridSorterDirection | undefined}
       */
      direction: {
        type: String,
        reflectToAttribute: true,
        notify: true,
        value: null,
        sync: true
      },
      /**
       * @type {number | null}
       * @protected
       */
      _order: {
        type: Number,
        value: null,
        sync: true
      }
    };
  }
  static get observers() {
    return ["_pathOrDirectionChanged(path, direction)"];
  }
  /** @protected */
  ready() {
    super.ready();
    this.addEventListener("click", this._onClick.bind(this));
  }
  /** @protected */
  connectedCallback() {
    super.connectedCallback();
    if (this._grid) {
      this._grid.__applySorters();
    } else {
      this.__dispatchSorterChangedEvenIfPossible();
    }
  }
  /** @protected */
  disconnectedCallback() {
    super.disconnectedCallback();
    if (!this.parentNode && this._grid) {
      this._grid.__removeSorters([this]);
    } else if (this._grid) {
      this._grid.__applySorters();
    }
  }
  /** @private */
  _pathOrDirectionChanged() {
    this.__dispatchSorterChangedEvenIfPossible();
  }
  /** @private */
  __dispatchSorterChangedEvenIfPossible() {
    if (this.path === void 0 || this.direction === void 0 || !this.isConnected) {
      return;
    }
    this.dispatchEvent(
      new CustomEvent("sorter-changed", {
        detail: { shiftClick: Boolean(this._shiftClick), fromSorterClick: Boolean(this._fromSorterClick) },
        bubbles: true,
        composed: true
      })
    );
    this._fromSorterClick = false;
    this._shiftClick = false;
  }
  /** @private */
  _getDisplayOrder(order) {
    return order === null ? "" : order + 1;
  }
  /** @private */
  _onClick(e13) {
    if (e13.defaultPrevented) {
      return;
    }
    const activeElement = this.getRootNode().activeElement;
    if (this !== activeElement && this.contains(activeElement)) {
      return;
    }
    e13.preventDefault();
    this._shiftClick = e13.shiftKey;
    this._fromSorterClick = true;
    if (this.direction === "asc") {
      this.direction = "desc";
    } else if (this.direction === "desc") {
      this.direction = null;
    } else {
      this.direction = "asc";
    }
  }
};

// node_modules/@vaadin/grid/src/vaadin-grid-sorter.js
var GridSorter = class extends GridSorterMixin(ThemableMixin(DirMixin(PolymerElement))) {
  static get template() {
    return html`
      <div part="content">
        <slot></slot>
      </div>
      <div part="indicators">
        <span part="order">[[_getDisplayOrder(_order)]]</span>
      </div>
    `;
  }
  static get is() {
    return "vaadin-grid-sorter";
  }
};
defineCustomElement(GridSorter);

// node_modules/@arcgis/core/widgets/FeatureTable/Grid/GridViewModel.js
var a12 = class extends i2.EventedAccessor {
  constructor(t3) {
    super(t3), this.cellPartNameGenerator = (t4, e13) => {
      let o5 = "";
      e13?.item && this.rowHighlightIds.includes(e13.item.objectId) && (o5 += " highlight");
      const i11 = this.findColumn(t4?.path);
      return i11 ? (i11.invalid && (o5 += " invalid"), i11.textWrap && (o5 += " text-wrap"), "editInfo" in i11 && i11.editInfo && i11.editInfo.rowData?.index === e13.index && (o5 += " editing"), o5) : o5;
    }, this.columnPerformanceModeEnabled = true, this.columnReorderingEnabled = true, this.columns = new V(), this.dataProvider = (t4, e13) => __async(this, null, function* () {
      const { store: o5 } = this;
      if (!e13) return;
      if (!o5) return void (e13 && e13([]));
      e13(yield o5.fetchItems(t4));
    }), this.maxSize = null, this.multipleSelectionEnabled = true, this.multiSortEnabled = false, this.paginationEnabled = false, this.rowDetailsRenderer = null, this.store = null;
  }
  get actionColumn() {
    return this.allColumns.find((t3) => t3.fieldName === n12.action);
  }
  get allColumns() {
    return this.columns.toArray().flatMap((t3) => [t3, ...e11(t3) && t3.columns?.length ? t3.columns : []]);
  }
  get allVisibleColumns() {
    return this.allColumns.filter((t3) => !t3.hidden);
  }
  get columnMenuIsOpen() {
    return this.allColumns.some((t3) => t3.menuIsOpen);
  }
  get editing() {
    return this.editableColumns.some((t3) => t3.editInfo);
  }
  get editableColumns() {
    return this.allColumns.filter((t3) => "editable" in t3);
  }
  get effectiveSize() {
    const { filterBySelectionEnabled: t3, highlightIds: e13, objectIds: o5, pageSize: i11, size: l10 } = this;
    if (this.paginationEnabled) {
      const n17 = this.pageCount === this.pageIndex + 1 ? l10 % i11 : i11;
      return t3 ? Math.min(e13.length, n17) : o5.length ? Math.min(o5.length, n17) : n17;
    }
    return t3 ? e13.length : o5.length ? o5.length : l10;
  }
  get fieldColumns() {
    return this.allColumns.filter((t3) => t2(t3));
  }
  get filterBySelectionEnabled() {
    return !!this._get("filterBySelectionEnabled");
  }
  set filterBySelectionEnabled(t3) {
    this._set("filterBySelectionEnabled", t3);
  }
  get groupColumns() {
    return this.columns.toArray().filter((t3) => e11(t3));
  }
  get hasInvalidColumnConfiguration() {
    return this.visibleColumns.every((t3) => t3.frozen || t3.frozenToEnd);
  }
  get highlightIds() {
    return this._get("highlightIds") || new V();
  }
  set highlightIds(t3) {
    const i11 = Array.isArray(t3) ? new V(t3) : t3;
    this.multipleSelectionEnabled || i11.splice(1, i11.length - 1), this._set("highlightIds", n6(i11, this._get("highlightIds"), V));
  }
  get objectIds() {
    return this._get("objectIds") ?? new V();
  }
  set objectIds(t3) {
    this._set("objectIds", n6(t3, this._get("objectIds"), V));
  }
  get pageCount() {
    const { pageSize: t3, size: e13 } = this;
    return 0 === e13 || 0 === t3 ? 1 : Math.ceil(e13 / t3);
  }
  get pageIndex() {
    return this._get("pageIndex") || 0;
  }
  set pageIndex(t3) {
    const { pageCount: e13 } = this;
    f4(t3, e13) && this._set("pageIndex", t3);
  }
  get pageSize() {
    return this._get("pageSize") ?? 50;
  }
  set pageSize(t3) {
    this.store?.set("pageSize", t3), this._set("pageSize", t3);
  }
  get relationshipColumns() {
    return this.allColumns.filter((t3) => i6(t3));
  }
  get rowHighlightIds() {
    return this._get("rowHighlightIds") || new V();
  }
  set rowHighlightIds(t3) {
    this._set("rowHighlightIds", n6(t3, this._get("rowHighlightIds"), V));
  }
  get size() {
    const t3 = this.store?.count ?? 0, { maxSize: e13 } = this;
    return null != t3 && null != e13 ? Math.min(e13, t3) : t3;
  }
  get state() {
    return this.store?.state ?? "disabled";
  }
  get visibleColumns() {
    return this.columns.toArray().filter((t3) => !t3.hidden);
  }
  closeColumnMenus() {
    this.allColumns.forEach((t3) => t3.closeMenu());
  }
  sortColumn(t3, e13) {
    if (!t3) return;
    const o5 = this.findColumn(t3);
    o5 && (o5.direction = e13);
  }
  hideColumn(t3) {
    const e13 = this.findColumn(t3);
    false === e13?.hidden && (e13.hidden = true);
  }
  showColumn(t3) {
    const e13 = this.findColumn(t3);
    e13?.hidden && (e13.hidden = false);
  }
  showAllColumns() {
    this.allColumns.forEach((t3) => {
      t3.hidden && (t3.hidden = false);
    });
  }
  findColumn(t3) {
    return this.allColumns.find((e13) => e13.fieldName === t3);
  }
  refresh() {
    this.store && (this.store.reset(), this.store.load());
  }
  toggleColumnVisibility(t3) {
    const e13 = this.findColumn(t3);
    e13 && (e13.hidden = !e13.hidden);
  }
};
r([m()], a12.prototype, "actionColumn", null), r([m()], a12.prototype, "allColumns", null), r([m()], a12.prototype, "allVisibleColumns", null), r([m()], a12.prototype, "cellPartNameGenerator", void 0), r([m()], a12.prototype, "columnMenuIsOpen", null), r([m()], a12.prototype, "columnPerformanceModeEnabled", void 0), r([m()], a12.prototype, "columnReorderingEnabled", void 0), r([m()], a12.prototype, "columns", void 0), r([m()], a12.prototype, "dataProvider", void 0), r([m()], a12.prototype, "editing", null), r([m()], a12.prototype, "editableColumns", null), r([m()], a12.prototype, "effectiveSize", null), r([m()], a12.prototype, "fieldColumns", null), r([m()], a12.prototype, "filterBySelectionEnabled", null), r([m()], a12.prototype, "groupColumns", null), r([m()], a12.prototype, "hasInvalidColumnConfiguration", null), r([m()], a12.prototype, "highlightIds", null), r([m()], a12.prototype, "maxSize", void 0), r([m()], a12.prototype, "multipleSelectionEnabled", void 0), r([m()], a12.prototype, "multiSortEnabled", void 0), r([m()], a12.prototype, "objectIds", null), r([m()], a12.prototype, "pageCount", null), r([m()], a12.prototype, "pageIndex", null), r([m()], a12.prototype, "pageSize", null), r([m()], a12.prototype, "paginationEnabled", void 0), r([m()], a12.prototype, "relationshipColumns", null), r([m()], a12.prototype, "rowHighlightIds", null), r([m()], a12.prototype, "rowDetailsRenderer", void 0), r([m({ readOnly: true })], a12.prototype, "size", null), r([m()], a12.prototype, "store", void 0), r([m({ readOnly: true })], a12.prototype, "state", null), r([m()], a12.prototype, "visibleColumns", null), a12 = r([a2("esri.widgets.FeatureTable.Grid.GridViewModel")], a12);
var p8 = a12;

// node_modules/@arcgis/core/widgets/FeatureTable/Grid/Grid.js
var g5 = "esri-grid";
var m6 = "compact column-borders";
var p9 = { base: g5, content: `${g5}__content`, grid: `${g5}__grid` };
var _ = { sort: ["Enter", " "] };
var f5 = class extends O {
  constructor(e13, t3) {
    super(e13, t3), this._columnElements = [], this._grid = null, this._temporaryHighlightId = null, this.itemIdPath = null, this.messages = null, this.selectionColumnEnabled = true, this.viewModel = new p8(), this._onSelectedItemsChange = this._onSelectedItemsChange.bind(this);
  }
  initialize() {
    this.addHandles([this.columns.on("before-changes", () => this.renderNow()), this.columns.on("change", () => this.onColumnChange()), v(() => this.highlightIds, "before-add", ({ target: e13 }) => {
      !this.multipleSelectionEnabled && e13.length && e13.removeAll();
    }), this.rowHighlightIds.on("change", () => this.generateCellPartNames()), d2(() => this.effectiveSize, () => this._updateGridSize()), d2(() => this.viewModel.editing, () => {
      this.generateCellPartNames(), this.requestContentUpdate();
    }), d2(() => this.store?.state, (e13, t3) => {
      "ready" !== e13 || "loaded" !== t3 && "error" !== t3 || this.refreshPageCache();
    }), v(() => this._table, "scroll", () => this.viewModel.closeColumnMenus()), v(() => this._table, "scrollend", () => {
      this.paginationEnabled || (this.pageIndex = this.getVirtualPageIndex());
    }), d2(() => this.multipleSelectionEnabled, (e13) => {
      !e13 && this.highlightIds.length > 1 && this.highlightIds.removeAll();
    })]);
  }
  destroy() {
    this.resetColumns(), this.columns.destroyed || this.columns.destroy();
  }
  resetColumns() {
    this.columns.drain((e13) => !e13.destroyed && e13.destroy());
  }
  get _editInfos() {
    return this.viewModel.editableColumns.map((e13) => e13.editInfo).filter(G);
  }
  get _columnRendering() {
    return this.columnPerformanceModeEnabled ? "lazy" : "eager";
  }
  get _selectedItems() {
    const { highlightIds: e13, store: t3 } = this;
    return e13.toArray().map((e14) => t3?.getItemByObjectId(e14) ?? { objectId: e14 });
  }
  get _table() {
    return this._grid?.$?.table;
  }
  get cellPartNameGenerator() {
    return this.viewModel.cellPartNameGenerator;
  }
  set cellPartNameGenerator(e13) {
    this.viewModel.cellPartNameGenerator = e13;
  }
  get columns() {
    return this.viewModel.columns;
  }
  set columns(e13) {
    this.viewModel.columns = e13;
  }
  get columnPerformanceModeEnabled() {
    return this.viewModel.columnPerformanceModeEnabled;
  }
  set columnPerformanceModeEnabled(e13) {
    this.viewModel.columnPerformanceModeEnabled = e13;
  }
  get columnReorderingEnabled() {
    return this.viewModel.columnReorderingEnabled;
  }
  set columnReorderingEnabled(e13) {
    this.viewModel.columnReorderingEnabled = e13;
  }
  get pageIndex() {
    return this.viewModel.pageIndex;
  }
  set pageIndex(e13) {
    this.viewModel.pageIndex = e13;
  }
  get dataProvider() {
    return this.viewModel.dataProvider;
  }
  set dataProvider(e13) {
    this.viewModel.dataProvider = e13;
  }
  get effectiveSize() {
    return this.viewModel.effectiveSize;
  }
  get hasInvalidColumnConfiguration() {
    return this.viewModel.hasInvalidColumnConfiguration;
  }
  get highlightIds() {
    return this.viewModel.highlightIds;
  }
  set highlightIds(e13) {
    this.viewModel.highlightIds = e13;
  }
  get temporaryHighlightId() {
    return this._temporaryHighlightId;
  }
  get isEditingActive() {
    return !!this._editInfos.length;
  }
  get isReady() {
    return !!this._grid;
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e13) {
    this._overrideIfSome("label", e13);
  }
  get multipleSelectionEnabled() {
    return this.viewModel.multipleSelectionEnabled;
  }
  set multipleSelectionEnabled(e13) {
    this.viewModel.multipleSelectionEnabled = e13;
  }
  get multiSortEnabled() {
    return this.viewModel.multiSortEnabled;
  }
  set multiSortEnabled(e13) {
    this.viewModel.multiSortEnabled = e13;
  }
  get pageSize() {
    return this.viewModel.pageSize;
  }
  set pageSize(e13) {
    this.viewModel.pageSize = e13;
  }
  get paginationEnabled() {
    return this.viewModel.paginationEnabled;
  }
  set paginationEnabled(e13) {
    this.viewModel.paginationEnabled = e13;
  }
  get rowDetailsRenderer() {
    return this.viewModel.rowDetailsRenderer;
  }
  set rowDetailsRenderer(e13) {
    this.viewModel.rowDetailsRenderer = e13;
  }
  get rowHighlightIds() {
    return this.viewModel.rowHighlightIds;
  }
  set rowHighlightIds(e13) {
    this.viewModel.rowHighlightIds = e13;
  }
  get size() {
    return this.viewModel.size;
  }
  get sortOrders() {
    return this._grid?._sorters ? this._grid._sorters.filter((e13) => !!e13 && e13.path).map(({ direction: e13, path: t3 }) => ({ direction: e13, path: t3 })) : [];
  }
  get store() {
    return this.viewModel.store;
  }
  set store(e13) {
    this.viewModel.store = e13;
  }
  addSorter(e13) {
    this._grid?.__updateSorter(e13, false, false), this.notifyChange("sortOrders");
  }
  getColumnProps(e13, t3) {
    const { id: i11 } = this, { autoWidth: r10, direction: n17, fieldName: o5, flexGrow: l10, frozen: s18, frozenToEnd: d6, hidden: a17, label: h8, resizable: u5, textAlign: c13, width: g6 } = e13, m8 = `${i11}_${o5}_${t3}`, { renderFunction: p14, footerRenderFunction: _2, headerRenderFunction: f7 } = e13, v3 = _2 ? (e14, t4) => _2({ root: e14, column: t4 }) : void 0, C5 = f7 ? (e14, t4) => f7({ root: e14, column: t4 }) : void 0, y5 = p14 ? (e14, t4, i12) => p14({ root: e14, column: t4, rowData: i12 }) : void 0;
    let w5 = "";
    return e13.direction && (w5 += " direction"), e13.invalid && (w5 += " invalid"), { footerRenderer: v3, headerRenderer: C5, renderer: y5, autoWidth: r10, direction: n17, flexGrow: l10, frozen: s18, frozenToEnd: d6, headerPartName: w5, key: m8, resizable: u5, bind: this, "data-fieldName": o5, header: h8, hidden: this.hasInvalidColumnConfiguration || a17, path: o5, "text-align": c13, width: "number" == typeof g6 ? `${g6}px` : g6, afterCreate: this._afterColumnCreate, afterRemoved: this._afterColumnRemoved };
  }
  clearSelection() {
    this._clearSelection(), this.scheduleRender();
  }
  clearSort() {
    let e13 = false;
    if (this._grid) {
      if (this._grid._sorters?.length && (this._grid._sorters.forEach((e14) => {
        e14._order = null, e14.direction = null;
      }), e13 = true), this.columns.length) {
        this.columns.some((e14) => !!e14.direction) && (this.columns.forEach((e14) => e14.direction = null), e13 = true);
      }
      e13 && (this.notifyChange("sortOrders"), this.scheduleRender());
    }
  }
  findColumn(e13) {
    return this.viewModel.findColumn(e13);
  }
  generateCellPartNames() {
    this._grid?.generateCellPartNames();
  }
  getFirstVisibleRowIndex() {
    return this._grid?._firstVisibleIndex || 0;
  }
  getVirtualPageIndex() {
    return Math.floor(this.getFirstVisibleRowIndex() / this.pageSize);
  }
  getLastVisibleRowIndex() {
    return this._grid?._lastVisibleIndex || 0;
  }
  getVisibleItemsCount() {
    return this._grid?._visibleItemsCount || 0;
  }
  getRowContainingNode(e13) {
    try {
      return this._grid?._getRowContainingNode(e13);
    } catch {
      return null;
    }
  }
  getSlotElementByName(e13) {
    return this._grid?.shadowRoot?.querySelector(`slot[name='${e13}']`) ?? null;
  }
  hasSorter(e13) {
    return this._grid?._sorters?.includes(e13) || false;
  }
  hideColumn(e13) {
    this.viewModel.hideColumn(e13);
  }
  recalculateColumnWidths() {
    this._grid?.recalculateColumnWidths();
  }
  reset() {
    return __async(this, null, function* () {
      this._clearSelection(), yield this.store?.reset(), this.scrollToTop();
    });
  }
  refreshPageCache() {
    this._grid?.clearCache(), this._temporaryHighlightId = null;
  }
  requestContentUpdate() {
    this._grid?.requestContentUpdate(), this._temporaryHighlightId = null;
  }
  selectRows(e13) {
    const { itemIdPath: t3 } = this, i11 = e13?.filter((e14) => !this.highlightIds.includes(e14[t3])), r10 = i11.map((e14) => e14[t3]);
    r10.length && (this.multipleSelectionEnabled || (this.highlightIds.removeAll(), r10.splice(1)), this.highlightIds.addMany(r10));
  }
  deselectRows(e13) {
    const { itemIdPath: t3 } = this, i11 = e13?.map((e14) => e14[t3]) || [];
    i11.length && this.highlightIds.removeMany(i11);
  }
  showColumn(e13) {
    this.viewModel.showColumn(e13);
  }
  sort({ path: e13, direction: t3 }) {
    this.viewModel.sortColumn(e13, t3), this.notifyChange("sortOrders");
  }
  scrollToIndex(e13) {
    this._grid?.isConnected && this._grid?.scrollToIndex(e13), this._temporaryHighlightId = null;
  }
  scrollToTop() {
    this.scrollToIndex(0);
  }
  scrollToBottom() {
    this.scrollToIndex(1 / 0);
  }
  scrollLeft(e13) {
    const { _table: t3 } = this;
    t3 && (t3.scrollLeft = e13);
  }
  toggleColumnVisibility(e13) {
    this.viewModel.toggleColumnVisibility(e13);
  }
  onColumnChange() {
    this._columnElements.forEach((e13) => {
      this._applyRenderersToColumnElement(e13);
    }), this.requestContentUpdate();
  }
  render() {
    return n3("div", { bind: this, class: this.classes(p9.base, e5.widget) }, n3("div", { bind: this, class: p9.content }, this._renderGrid()));
  }
  _renderGrid() {
    return n3("vaadin-grid", { afterCreate: this._afterGridCreate, afterUpdate: this._afterGridUpdate, bind: this, cellPartNameGenerator: this.cellPartNameGenerator, class: p9.grid, columnRendering: this._columnRendering, columnReorderingAllowed: this.columnReorderingEnabled, dataProvider: this.dataProvider, id: `${this.id}_grid`, itemIdPath: this.itemIdPath, multiSort: this.multiSortEnabled, pageSize: this.pageSize, ref: "grid", rowDetailsRenderer: this.rowDetailsRenderer, selectedItems: this._selectedItems, size: this.effectiveSize }, this._renderAllColumns());
  }
  _renderAllColumns() {
    return "disabled" !== this.viewModel.state && this.columns.length ? [this._renderSelectionColumn(), this._renderColumns()] : null;
  }
  _renderSelectionColumn() {
    return n3("vaadin-grid-selection-column", { _selectAllHidden: true, autoWidth: false, bind: this, dragSelect: true, frozen: true, hidden: this.hasInvalidColumnConfiguration || !this.selectionColumnEnabled, selectAll: false, sortable: false, textAlign: "center" });
  }
  _renderColumns() {
    return Array.from(this.columns, (e13, t3) => "columns" in e13 ? this._renderGroupColumn(e13, t3) : n3("vaadin-grid-column", __spreadValues({}, this.getColumnProps(e13, t3)))).filter(G);
  }
  _renderGroupColumn(e13, t3) {
    const i11 = this.getColumnProps(e13, t3);
    if (i11.hidden || !e13.columns) return null;
    const r10 = e13.columns.filter(({ hidden: e14 }) => !e14);
    return r10.length ? n3("vaadin-grid-column-group", __spreadValues({}, i11), r10.map((e14) => n3("vaadin-grid-column", __spreadValues({}, this.getColumnProps(e14, t3))))) : null;
  }
  _afterGridCreate(e13) {
    const t3 = this._grid = e13;
    t3.setAttribute("theme", m6), customElements.whenDefined("vaadin-grid").then(() => {
      this._appendStyles(), this._addGridEventListeners();
    }), t3.__updateSorter = (e14, i11, r10) => {
      const n17 = t3._sorters, o5 = !n17.includes(e14);
      if (!e14.direction && o5) return;
      e14._order = null;
      const { multiSort: l10, multiSortOnShiftClick: s18, multiSortPriority: d6 } = t3, a17 = n17.filter((t4) => t4 !== e14);
      l10 && (!s18 || !r10) || s18 && i11 ? null != e14._initialOrder ? (o5 ? n17[e14._initialOrder] = e14 : n17.splice(e14._initialOrder, 0, e14), e14._initialOrder = null) : t3._sorters = "append" === d6 ? [...a17, e14] : [e14, ...a17] : (e14.direction || s18) && (t3._sorters = e14.direction ? [e14] : [], a17.forEach((e15) => {
        e15._order = null, e15.direction = null;
      }));
    }, t3.__removeSorters = (e14) => {
      if (0 === e14.length) return;
      const i11 = new Set(e14.filter((e15) => !e15.direction));
      t3._sorters = t3._sorters.filter((e15) => !i11.has(e15)), t3.__applySorters();
    };
  }
  _appendStyles() {
    const e13 = this._grid?.shadowRoot, t3 = document.createElement("style");
    e13 && (t3.textContent = `
      #items [part~="row"][editing],
      #items [part~="row"][editing][selected] {
        z-index: 2;
      }

      #items [part~="editing"],
      #items [part~="editing"][selected] {
        z-index: 3;
      }

      [frozen], [frozen-to-end] {
        z-index: 4;
      }

      [last-frozen] {
        overflow: visible;
      }

      [part~='cell'] ::slotted(vaadin-grid-cell-content) {
        align-items: center;
        box-sizing: border-box !important;
        height: 100%;
        line-height: 2em;
        min-height: 40px;
      }

      #items [part~="text-wrap"] {
        text-wrap: wrap;
      }
    `, e13.appendChild(t3));
  }
  _afterGridUpdate(e13) {
    this._grid || (this._grid = e13);
  }
  _afterColumnCreate(e13) {
    this._columnElements.push(e13);
  }
  _afterColumnRemoved(e13) {
    const t3 = this._columnElements.indexOf(e13, 0);
    t3 > -1 && this._columnElements.splice(t3, 1);
  }
  _updateGridSize() {
    this._grid && (this._grid.size = this.effectiveSize, this.scheduleRender());
  }
  _addGridEventListeners() {
    const e13 = this._grid;
    n2(e13), this.addHandles([o(e13, ["click", "dblclick", "keydown", "pointerover", "pointerout"], (e14) => this._onGridInteraction(e14)), o(e13, ["pointerover", "pointerout", "cell-focus"], (e14) => this._onTransientGridInteraction(e14)), o(e13, "selected-items-changed", this._onSelectedItemsChange), o(e13, "sorter-changed", () => this.notifyChange("sortOrders")), o(e13, "column-resize", (e14) => {
      const t3 = e14.detail.resizedColumn, i11 = t3.getAttribute("data-fieldName"), r10 = this.findColumn(i11);
      r10?.set({ width: t3.width });
    }), o(e13, "column-reorder", () => this._onColumnOrderChange())]);
  }
  _onGridInteraction(e13) {
    const t3 = this._grid;
    if (n2(t3), ("pointerover" === e13.type || "pointerout" === e13.type) && e13.relatedTarget !== t3) {
      const { target: t4, relatedTarget: i12 } = e13;
      if (!this._isGridCellContentNode(t4) || !this._isGridCellContentNode(i12)) return;
    }
    let i11 = null;
    try {
      i11 = t3.getEventContext(e13);
    } catch (a17) {
    }
    if (!i11) return;
    const { column: n17, index: o5, item: l10, section: s18 } = i11;
    if (!s18) return;
    if ("header" === s18 && "keydown" === e13.type && n17?.path) {
      const t4 = e13.key;
      _.sort.includes(t4) && this.findColumn(n17.path)?.sort();
    }
    const d6 = `cell-${e13.type}`;
    this.emit(d6, { type: d6, context: i11, index: o5, item: l10, native: e13, path: n17?.path ?? void 0 });
  }
  _onTransientGridInteraction(e13) {
    if ("pointerout" === e13.type) return void (this._temporaryHighlightId = null);
    const t3 = this._grid;
    if (t3) try {
      const { item: i11 } = t3.getEventContext(e13);
      this._temporaryHighlightId = i11?.objectId;
    } catch {
      this._temporaryHighlightId = null;
    }
  }
  _isGridCellContentNode(e13) {
    return !!(e13 && e13 instanceof HTMLElement && "vaadin-grid-cell-content" === e13.localName);
  }
  _onColumnOrderChange() {
    const e13 = this._grid;
    n2(e13);
    const t3 = e13._getColumnsInOrder(0), i11 = [], n17 = (this.viewModel.groupColumns.length ? e13._getColumnsInOrder(1) : t3).map((e14) => e14.getAttribute("data-fieldName"));
    t3?.forEach((e14) => {
      const t4 = e14.getAttribute("data-fieldName");
      if (null != t4) {
        const e15 = this.findColumn(t4);
        i11.push(t4), e15 && "columns" in e15 && e15.columns?.length && e15.columns.sort((e16, t5) => n17.indexOf(e16.fieldName) > n17.indexOf(t5.fieldName) ? 1 : -1);
      }
    }), this.columns.sort((e14, t4) => i11.indexOf(e14.fieldName) > i11.indexOf(t4.fieldName) ? 1 : -1), this.notifyChange("sortOrders"), this.emit("column-reorder", { type: "column-reorder" });
  }
  _clearSelection() {
    this.highlightIds.removeAll(), this._temporaryHighlightId = null;
  }
  _onSelectedItemsChange(e13) {
    const { highlightIds: t3, itemIdPath: i11 } = this, r10 = e13.detail.value.map((e14) => e14[i11]), n17 = r10.filter((e14) => !t3.includes(e14));
    if (!this.multipleSelectionEnabled && n17.length && t3.length) t3.removeAll(), t3.add(n17[0]);
    else {
      const e14 = t3.filter((e15) => !r10.includes(e15));
      t3.removeMany(e14), t3.addMany(n17);
    }
  }
  _applyRenderersToColumnElement(e13) {
    const t3 = e13?.path, i11 = null != t3 ? this.findColumn(t3) : void 0;
    if (i11) try {
      const { renderFunction: t4, footerRenderFunction: r10, headerRenderFunction: n17 } = i11;
      t4 && "renderer" in e13 && (e13.renderer = (e14, i12, r11) => t4({ root: e14, column: i12, rowData: r11 })), r10 && (e13.footerRenderer = (e14, t5) => r10({ root: e14, column: t5 })), n17 && (e13.headerRenderer = (e14, t5) => n17({ root: e14, column: t5 }));
    } catch (r10) {
    }
  }
};
r([m()], f5.prototype, "_editInfos", null), r([m()], f5.prototype, "_columnElements", void 0), r([m()], f5.prototype, "_columnRendering", null), r([m()], f5.prototype, "_selectedItems", null), r([m()], f5.prototype, "_grid", void 0), r([m()], f5.prototype, "_table", null), r([m()], f5.prototype, "_temporaryHighlightId", void 0), r([m()], f5.prototype, "cellPartNameGenerator", null), r([m()], f5.prototype, "columns", null), r([m()], f5.prototype, "columnPerformanceModeEnabled", null), r([m()], f5.prototype, "columnReorderingEnabled", null), r([m()], f5.prototype, "pageIndex", null), r([m()], f5.prototype, "dataProvider", null), r([m()], f5.prototype, "effectiveSize", null), r([m()], f5.prototype, "hasInvalidColumnConfiguration", null), r([m()], f5.prototype, "highlightIds", null), r([m()], f5.prototype, "temporaryHighlightId", null), r([m()], f5.prototype, "isEditingActive", null), r([m()], f5.prototype, "isReady", null), r([m()], f5.prototype, "itemIdPath", void 0), r([m()], f5.prototype, "label", null), r([m(), e3("esri/widgets/FeatureTable/t9n/FeatureTable")], f5.prototype, "messages", void 0), r([m()], f5.prototype, "multipleSelectionEnabled", null), r([m()], f5.prototype, "multiSortEnabled", null), r([m()], f5.prototype, "pageSize", null), r([m()], f5.prototype, "paginationEnabled", null), r([m()], f5.prototype, "rowDetailsRenderer", null), r([m()], f5.prototype, "rowHighlightIds", null), r([m()], f5.prototype, "selectionColumnEnabled", void 0), r([m()], f5.prototype, "size", null), r([m({ readOnly: true })], f5.prototype, "sortOrders", null), r([m()], f5.prototype, "store", null), r([m()], f5.prototype, "viewModel", void 0), f5 = r([a2("esri.widgets.FeatureTable.Grid.Grid")], f5);
var v2 = f5;

// node_modules/@arcgis/core/widgets/FeatureTable/Grid/GroupColumn.js
var e12 = class extends m4 {
  constructor(o5) {
    super(o5), this.columns = null, this.sortable = false;
  }
  initialize() {
    this._set("fieldName", `group:${this.label}`);
  }
  destroy() {
    this.columns?.forEach((o5) => !o5.destroyed && o5.destroy());
  }
};
r([m()], e12.prototype, "columns", void 0), r([m({ readOnly: true })], e12.prototype, "sortable", void 0), e12 = r([a2("esri.widgets.FeatureTable.Grid.GroupColumn")], e12);
var i8 = e12;

// node_modules/@arcgis/core/widgets/FeatureTable/support/ColumnTemplateBase.js
var r6 = class extends S {
  constructor(o5) {
    super(o5), this.autoWidth = false, this.description = null, this.direction = null, this.flexGrow = 1, this.fieldName = null, this.formatFunction = null, this.frozen = false, this.frozenToEnd = false, this.icon = null, this.iconText = null, this.initialSortPriority = null, this.invalid = false, this.label = null, this.menuConfig = null, this.resizable = true, this.sortable = false, this.textAlign = "start", this.textWrap = false, this.timeZone = null, this.type = null, this.visible = true, this.width = 200;
  }
};
r([m()], r6.prototype, "autoWidth", void 0), r([m()], r6.prototype, "description", void 0), r([m()], r6.prototype, "direction", void 0), r([m()], r6.prototype, "flexGrow", void 0), r([m({ type: String })], r6.prototype, "fieldName", void 0), r([m()], r6.prototype, "formatFunction", void 0), r([m()], r6.prototype, "frozen", void 0), r([m()], r6.prototype, "frozenToEnd", void 0), r([m()], r6.prototype, "icon", void 0), r([m()], r6.prototype, "iconText", void 0), r([m()], r6.prototype, "initialSortPriority", void 0), r([m()], r6.prototype, "invalid", void 0), r([m()], r6.prototype, "label", void 0), r([m()], r6.prototype, "menuConfig", void 0), r([m()], r6.prototype, "resizable", void 0), r([m()], r6.prototype, "sortable", void 0), r([m()], r6.prototype, "textAlign", void 0), r([m()], r6.prototype, "textWrap", void 0), r([m()], r6.prototype, "timeZone", void 0), r([m({ type: String, json: { read: false, write: true } })], r6.prototype, "type", void 0), r([m()], r6.prototype, "visible", void 0), r([m()], r6.prototype, "width", void 0), r6 = r([a2("esri.widgets.FeatureTable.support.ColumnTemplateBase")], r6);
var p10 = r6;

// node_modules/@arcgis/core/widgets/FeatureTable/support/AttachmentsColumnTemplate.js
var s13 = class extends p10 {
  constructor(t3) {
    super(t3), this.attachmentsViewEnabled = true, this.icon = "attachment", this.sortable = false, this.textAlign = "center", this.thumbnailAppearance = "image", this.thumbnailCount = 8, this.thumbnailsEnabled = true, this.thumbnailIconScale = "m", this.type = "attachment";
  }
};
r([m()], s13.prototype, "attachmentsViewEnabled", void 0), r([m()], s13.prototype, "icon", void 0), r([m()], s13.prototype, "sortable", void 0), r([m()], s13.prototype, "textAlign", void 0), r([m()], s13.prototype, "thumbnailAppearance", void 0), r([m()], s13.prototype, "thumbnailCount", void 0), r([m()], s13.prototype, "thumbnailsEnabled", void 0), r([m()], s13.prototype, "thumbnailIconScale", void 0), r([m({ type: String, json: { read: false, write: true } })], s13.prototype, "type", void 0), s13 = r([a2("esri.widgets.FeatureTable.support.AttachmentsColumnTemplate")], s13);
var a13 = s13;

// node_modules/@arcgis/core/widgets/FeatureTable/support/AttachmentsViewOptions.js
var i9 = class extends g {
  constructor(t3) {
    super(t3), this.attachmentId = null, this.attachmentInfos = [], this.candidates = null, this.error = null, this.form = null, this.mode = "list", this.objectId = null;
  }
  initialize() {
    this.addHandles([d2(() => this.objectId, () => this.reset()), d2(() => this.candidates, () => {
      this.error = null;
    }), d2(() => this.attachmentInfos.length, (t3) => {
      0 === t3 && (this.mode = "file");
    })]);
  }
  onEditComplete() {
    this.attachmentId = null, this.candidates = null, this.mode = "list";
  }
  reset() {
    this.attachmentId = null, this.candidates = null, this.error = null;
  }
};
r([m()], i9.prototype, "attachmentId", void 0), r([m()], i9.prototype, "attachmentInfos", void 0), r([m()], i9.prototype, "candidates", void 0), r([m()], i9.prototype, "error", void 0), r([m()], i9.prototype, "form", void 0), r([m()], i9.prototype, "mode", void 0), r([m()], i9.prototype, "objectId", void 0), i9 = r([a2("esri.widgets.FeatureTable.support.AttachmentsViewOptions")], i9);
var a14 = i9;

// node_modules/@arcgis/core/exports/csv.js
function n14(e13) {
  return Object.keys(e13.attributes).map((n17) => {
    const i11 = e13.attributes[n17];
    return "objectid" === n17.toLowerCase() || "fid" === n17.toLowerCase() ? new y3({ name: n17, alias: n17, type: "oid" }) : new y3("number" == typeof i11 ? { name: n17, alias: n17, type: "double" } : { name: n17, alias: n17, type: "string" });
  });
}
function i10(e13) {
  if (!e13.fields) {
    const t3 = e13.features[0];
    if (t3.layer) {
      e13.fields = t3.layer.fields;
      const n17 = Object.keys(t3.attributes), i11 = e13.fields.filter((e14) => n17.includes(e14.name));
      e13.fields = i11;
    } else e13.fields = n14(t3);
  }
  return e13;
}
function o4(e13) {
  return e13.map(({ attributes: e14 }) => e14);
}
function r7(e13) {
  const { delimiter: t3, fields: n17 = [], outFields: i11 = [] } = e13, o5 = t3 || ",", r10 = n17.map((e14) => e14.name);
  return (e14) => {
    let t4 = "";
    return r10.filter((e15) => i11.includes(e15)).forEach((i12) => {
      const r11 = n17.find(({ name: e15 }) => e15 === i12);
      let a17 = e14[i12] || "";
      if ("date" === r11?.type && (a17 = new Date(a17).toString()), r11?.domain && "coded-value" === r11.domain.type) {
        const e15 = r11.domain.codedValues.find((e16) => a17 === e16.code);
        e15 && (a17 = e15.name);
      }
      "string" == typeof a17 && a17.includes(o5) && (a17 = `"${a17}"`), t4 += `${a17}${o5}`;
    }), `${t4}\r
`;
  };
}
function a15(_0) {
  return __async(this, arguments, function* (n17, { includeGeometry: a17 = true, delimiter: l10 = ",", outFields: s18 = ["*"] } = {}) {
    n17 = i10(n17), a17 && "point" !== n17.geometryType && n.getLogger("esri.exports.csv").warn(`The input geometry ${n17.geometryType} is not supported. Geometry will be excluded from export.`);
    const { features: d6 } = n17;
    if (!d6.length) return null;
    let u5 = n17.fields;
    const [m8] = s18;
    "*" === m8 && (s18 = u5.map((e13) => e13.name)), a17 && "point" === n17.geometryType && (u5.some((e13) => "x" === e13.name || "y" === e13.name) || (u5 = [...u5, new y3({ name: "lon", alias: "Longitude", type: "double" }), new y3({ name: "lat", alias: "Latitude", type: "double" })], s18 = [...s18, "lon", "lat"]), d6.forEach(({ attributes: e13, geometry: t3 }) => {
      e13.lon = "point" === t3?.type ? t3.longitude : null, e13.lat = "point" === t3?.type ? t3.latitude : null;
    })), u5 = u5.filter((e13) => s18.includes(e13.name));
    const p14 = l10 || ",", c13 = o4(d6), f7 = u5.map((e13) => e13.name).join(p14), y5 = r7({ delimiter: p14, outFields: s18 || u5.map((e13) => e13.name), fields: u5 });
    let g6 = `${f7}${p14}\r
`;
    c13.forEach((e13) => {
      g6 += y5(e13);
    });
    const b5 = new RegExp(`${p14}\r
\\s*$`, "g");
    return g6.replace(b5, "");
  });
}

// node_modules/@arcgis/core/widgets/FeatureTable/support/exportUtils.js
function s14() {
  return "showSaveFilePicker" in window && (() => {
    try {
      return window.self === window.top;
    } catch {
      return false;
    }
  })();
}
function a16(r10) {
  return __async(this, null, function* () {
    const { layer: a17, includeGeometry: n17, objectIds: c13, outFields: l10 } = r10, u5 = l10 ?? a17.outFields ?? ["*"], w5 = a17.createQuery();
    w5.objectIds = c13, w5.outFields = u5;
    const p14 = yield a17.queryFeatures(w5), d6 = yield a15(p14, { includeGeometry: !a17.isTable && (n17 || "point" === p14.geometryType), outFields: u5 });
    if (!d6) throw new s2("export-csv:no-output", "Unable to generate a valid export string");
    const m8 = new Blob([d6], { type: "text/csv" }), f7 = A2.sanitize(a17.title);
    if (s14()) try {
      const t3 = yield showSaveFilePicker({ suggestedName: f7, types: [{ accept: { "text/csv": [".csv"] } }] }), e13 = yield t3.createWritable();
      yield e13.write(m8), yield e13.close();
    } catch (y5) {
      if (y5 instanceof s2 && "AbortError" !== y5.name) throw y5;
    }
    else ct(m8, `${f7}.csv`);
  });
}
function n15(t3) {
  return __async(this, null, function* () {
    if (!t3?.url) return;
    const o5 = yield st(`${t3.url}`);
    ct(o5, t3.name);
  });
}

// node_modules/@arcgis/core/widgets/FeatureTable/support/FeatureStore.js
var C4 = class extends g {
  constructor(e13) {
    super(e13), this._attachmentsOperationQueue = new V(), this._defaultOutFields = ["*"], this._editOperationQueue = new V(), this._loaded = false, this._loadError = false, this._loading = false, this._objectIdCache = new V(), this._queryOperationQueue = new V(), this.attachmentsEnabled = false, this.count = 0, this.failures = new V(), this.filterGeometry = null, this.initialSize = null, this.layer = null, this.objectIds = null, this.outFields = null, this.pageCache = new s6(), this.pageSize = 50, this.relationshipConfig = null, this.relatedRecordsEnabled = false, this.returnGeometry = false, this.returnZ = false, this.returnM = false, this.sortOrders = [], this.timeExtent = null, this.view = null, this.where = null;
  }
  initialize() {
    this.addHandles([d2(() => [this.filterGeometry, this.layer, this.objectIds, this.outFields, this.pageSize, this.relationshipConfig, this.returnGeometry, this.returnM, this.returnZ, this.timeExtent, this.where], () => this._reset()), d2(() => this.orderByFields, () => this._clearCaches(), { equals: s }), p(() => this.attachmentsEnabled, () => this._reset()), p(() => this.relatedRecordsEnabled, () => this._reset())]);
  }
  destroy() {
    this.layer = null, this.itemCache?.destroy(), this.failures?.destroy();
  }
  get _capabilities() {
    const { layer: e13 } = this;
    return e13?.effectiveCapabilities ?? e13?.capabilities;
  }
  get _effectiveReturnZ() {
    return this.returnZ && this.supportsZ;
  }
  get _effectiveReturnM() {
    return this.returnM && this.supportsM;
  }
  get _layerWithAttachments() {
    const { layer: e13 } = this;
    return e13 && this._capabilities && this.attachmentsEnabled && this.supportsAttachments && s10(e13) ? e13 : null;
  }
  get _layerWithAttachmentsEditing() {
    const { _layerWithAttachments: e13 } = this;
    return e13 && a8(e13) && this.supportsEditing ? e13 : null;
  }
  get _layerWithEditing() {
    const e13 = this.layer;
    return l5(e13) && this.supportsEditing ? e13 : null;
  }
  get _layerWithRelationships() {
    const e13 = this.layer;
    return p6(e13) && this.supportsQueryRelated ? e13 : null;
  }
  get _relatedLayer() {
    return this.relationshipConfig?.relatedLayer;
  }
  get _relatedLayerCapabilities() {
    const { _relatedLayer: e13 } = this;
    return e13?.effectiveCapabilities ?? e13?.capabilities;
  }
  get _relatedLayerSupportsCacheHint() {
    return !!this._relatedLayerCapabilities?.queryRelated?.supportsCacheHint;
  }
  get _relatedLayerSupportsQuery() {
    return !!this._relatedLayerCapabilities?.operations.supportsQuery;
  }
  get _relatedLayerSupportsQueryRelated() {
    const { _relatedLayerCapabilities: e13 } = this;
    return !!e13?.queryRelated?.supportsCount && !!e13?.queryRelated?.supportsPagination;
  }
  get _sortedFieldNames() {
    return this.sortOrders.map(({ fieldName: e13 }) => e13);
  }
  get _subtypeCode() {
    return this.layer?.subtypeCode ?? null;
  }
  get _subtypeField() {
    const { layer: e13 } = this;
    return c2(e13?.parent) ? e13.subtypeField : null;
  }
  get _canUseRelatedLayer() {
    return !(!this._relatedLayerSupportsQuery || !this._relatedLayerSupportsQueryRelated);
  }
  get canAddRelatedFeature() {
    const { state: e13, relationship: t3, supportsAdd: r10, supportsEditing: s18 } = this;
    if ("loaded" !== e13 || !t3 || !r10 || !s18) return false;
    const { count: i11 } = this, { cardinality: a17, role: o5 } = t3, n17 = i11 > 0;
    return ("one-to-one" !== a17 || !n17) && ("one-to-many" !== a17 || "origin" !== o5 || !n17);
  }
  get effectiveOutFields() {
    const { layer: e13, outFields: t3 } = this;
    if (!e13 || !t3?.length) return this._defaultOutFields;
    const r10 = [];
    t3.forEach((t4) => {
      const s19 = e13.fieldsIndex.normalizeFieldName(t4);
      s19 && r10.push(s19);
    });
    const { objectIdField: s18 } = e13, i11 = e13.fieldsIndex.normalizeFieldName(s18) ?? s18;
    return i11 && !r10.includes(i11) && r10.unshift(i11), r10;
  }
  get effectiveTimeExtent() {
    const { layer: e13, timeExtent: t3 } = this;
    return t3 || e13 && "timeExtent" in e13 && e13.timeExtent || null;
  }
  get effectiveWhere() {
    return this.where || this.layer?.definitionExpression || "1=1";
  }
  get itemCache() {
    return new V({ items: [...this.pageCache.values()].flat() });
  }
  get layerView() {
    const { layer: e13, view: t3 } = this;
    if (!e13 || !t3) return null;
    const r10 = "sublayer" === e13.type || l3(e13) ? e13.parent : e13;
    return t3.allLayerViews.find((e14) => e14.layer === r10);
  }
  get orderByFields() {
    const { _sortedFieldNames: e13, layer: t3, sortOrders: r10 } = this, s18 = r10.filter(({ fieldName: t4, direction: r11 }, s19) => e13.indexOf(t4) === s19 && null != r11).map(({ fieldName: e14, direction: t4 }) => `${e14} ${t4?.toUpperCase()}`);
    if (t3 && !s18.length && !t3.objectIdField && t3.fields?.length) {
      const e14 = t3.fields.find((e15) => e15.name);
      if (e14) {
        const r11 = t3.fieldsIndex.normalizeFieldName(e14.name);
        r11 && s18.push(`${r11} ASC`);
      }
    }
    return s18;
  }
  get querying() {
    return this._queryOperationQueue.length > 0;
  }
  get relationship() {
    const { relationshipConfig: e13 } = this;
    return null == e13?.relationshipId ? null : this.relationships?.find((t3) => t3.id === e13.relationshipId);
  }
  get relationshipIds() {
    return this.relationships?.map((e13) => e13.id) ?? [];
  }
  get relationshipInfos() {
    const { _layerWithRelationships: e13, relatedRecordsEnabled: t3, relationships: r10, view: s18 } = this, i11 = [];
    return t3 && e13?.loaded && s18?.map && r10?.length ? (r10.forEach((t4) => {
      const r11 = m3(e13, s18, t4);
      r11 && (r11.load(), i11.push({ layer: e13, relatedLayer: r11, relationshipId: t4.id }));
    }), i11) : i11;
  }
  get relationships() {
    return this._layerWithRelationships?.relationships;
  }
  get state() {
    const { layer: e13, _loaded: t3, _loadError: r10, _loading: s18 } = this;
    return !e13 || e13.destroyed ? "disabled" : r10 || e13.loadError ? "error" : "loaded" === e13.loadStatus && t3 ? "loaded" : s18 ? "loading" : "ready";
  }
  get supportsAdd() {
    return !!this._capabilities?.operations.supportsAdd;
  }
  get supportsAddingAttachments() {
    return !(!this._layerWithAttachmentsEditing || !this.supportsAdd);
  }
  get supportsAttachments() {
    const { _capabilities: e13 } = this;
    return !(!e13?.data?.supportsAttachment || !e13?.operations.supportsQueryAttachments);
  }
  get supportsCacheHint() {
    return !!this._capabilities?.query?.supportsCacheHint;
  }
  get supportsCacheHintQueryRelated() {
    return !!this._capabilities?.queryRelated?.supportsCacheHint;
  }
  get supportsDelete() {
    return !!this._capabilities?.operations.supportsDelete;
  }
  get supportsDeletingAttachments() {
    return !(!this._layerWithAttachmentsEditing || !this.supportsDelete);
  }
  get supportsEditing() {
    return !!this._capabilities?.operations.supportsEditing;
  }
  get supportsM() {
    return !!this.layer?.hasM && !!this._capabilities?.data?.supportsM;
  }
  get supportsOrderBy() {
    return !!this._capabilities?.query?.supportsOrderBy;
  }
  get supportsPagination() {
    return !!this._capabilities?.query?.supportsPagination;
  }
  get supportsQuery() {
    return !!this._capabilities?.operations.supportsQuery;
  }
  get supportsQueryRelated() {
    const { _capabilities: e13 } = this;
    return !!e13?.queryRelated?.supportsCount && !!e13?.queryRelated?.supportsPagination;
  }
  get supportsResizeAttachments() {
    const { _capabilities: e13 } = this;
    return !(!this.supportsAttachments || !e13?.attachment?.supportsResize);
  }
  get supportsUpdate() {
    return !!this._capabilities?.operations.supportsUpdate;
  }
  get supportsUpdateAttachments() {
    return !(!this._layerWithAttachmentsEditing || !this.supportsUpdate);
  }
  get supportsZ() {
    return !!this.layer?.hasZ && !!this._capabilities?.data?.supportsZ;
  }
  get syncing() {
    return this.syncingFeatureEdits || this.syncingAttachmentEdits;
  }
  get syncingAttachmentEdits() {
    return this._attachmentsOperationQueue.length > 0;
  }
  get syncingFeatureEdits() {
    return this._editOperationQueue.length > 0;
  }
  addAttachment(e13, t3) {
    return __async(this, null, function* () {
      const { _layerWithAttachmentsEditing: r10 } = this;
      if (!r10 || !this.supportsAddingAttachments) return {};
      const s18 = yield this._queueAttachmentsOperation(e13, () => r10.addAttachment(this._createBaseGraphic(r10, e13), t3));
      return this._ensureArrayContent(s18);
    });
  }
  deleteAttachments(e13, t3) {
    return __async(this, null, function* () {
      const { _layerWithAttachmentsEditing: r10 } = this;
      if (!r10 || !this.supportsDeletingAttachments || !t3.length) return [];
      const s18 = yield this._queueAttachmentsOperation(e13, () => r10.deleteAttachments(this._createBaseGraphic(r10, e13), t3));
      return this._ensureArray(s18);
    });
  }
  deleteRowsByObjectId(e13) {
    return __async(this, null, function* () {
      const { _layerWithEditing: t3 } = this;
      if (!this.supportsDelete || !t3) throw new s2("store:delete-error", "Delete is not supported.");
      const r10 = e13.map((e14) => this.getItemByObjectId(e14)?.feature).filter(G);
      return this._queueEditOperation(() => t3.applyEdits({ deleteFeatures: r10 }));
    });
  }
  fetchItems(e13) {
    return __async(this, null, function* () {
      const { page: t3 } = e13, { pageSize: r10 } = this, s18 = t3 * r10, i11 = s18 + r10, { layer: a17, state: o5 } = this;
      return a17 && "loaded" === o5 ? this._query({ layer: a17, start: s18, num: i11, page: t3, pageSize: r10 }) : [];
    });
  }
  getAttachmentsByObjectId(e13, t3) {
    return __async(this, null, function* () {
      const r10 = this.getItemByObjectId(e13)?.attachments ?? [];
      if (!r10.length && t3) {
        return (yield this._queryAttachments([e13]))[e13] ?? [];
      }
      return r10;
    });
  }
  getItemByObjectId(e13) {
    for (const t3 of this.pageCache.values()) for (const r10 of t3) if (r10.objectId === e13) return r10;
  }
  getItemIndexByObjectId(e13) {
    const { pageCache: t3, pageSize: r10 } = this, s18 = t3.entries();
    let i11 = -1;
    for (const [a17, o5] of s18) if (o5.some((t4, s19) => {
      const o6 = t4.objectId === e13;
      return o6 && (i11 = a17 * r10 + s19), o6;
    }), i11 > -1) break;
    return i11;
  }
  load() {
    return __async(this, null, function* () {
      const { layer: e13 } = this;
      if (!this._loading && !this._loaded && e13) {
        this._reset(), this._loading = true;
        try {
          yield e13.load(), e13.parent && c2(e13.parent) && (yield e13.parent.loadAll()), yield e13.when();
          const t3 = this.initialSize;
          this.initialSize = null, yield this.refresh(t3), this._loaded = true, this._loading = false;
        } catch (t3) {
          throw this._reset(), this._loadError = true, this._logError("store:load-error", "An error occurred."), t3;
        }
      }
    });
  }
  query(e13) {
    return __async(this, null, function* () {
      const { state: t3 } = this;
      return this.supportsQuery && "loaded" === t3 ? this._query(e13) : [];
    });
  }
  refresh(e13) {
    return __async(this, null, function* () {
      this._clearCaches(), yield this._syncCount(e13), yield this._syncObjectIdCache();
    });
  }
  reset() {
    return __async(this, null, function* () {
      this._reset();
    });
  }
  updateAttachment(e13, t3, r10) {
    return __async(this, null, function* () {
      const { _layerWithAttachmentsEditing: s18 } = this;
      if (!s18 || !this.supportsUpdateAttachments) return {};
      const i11 = yield this._queueAttachmentsOperation(e13, () => s18.updateAttachment(this._createBaseGraphic(s18, e13), t3, r10));
      return this._ensureArrayContent(i11);
    });
  }
  updateItem(e13) {
    return __async(this, null, function* () {
      const { _sortedFieldNames: t3 } = this, r10 = e13.updates.map(({ fieldName: e14 }) => e14), s18 = yield this._update(e13);
      return !s18.updateFeatureResults.find((e14) => e14.error) && r10.some((e14) => t3.includes(e14)) && this._clearCaches(), s18;
    });
  }
  verifyFeaturesByObjectId(e13) {
    return __async(this, null, function* () {
      const { layer: t3, state: r10 } = this;
      if (!t3 || "loaded" !== r10) return [];
      const { objectIdField: s18 } = t3, i11 = yield this._verifyFeaturesByObjectId(e13);
      return e13.map((e14) => i11.some((t4) => {
        const r11 = t4.getObjectId() ?? t4.attributes[s18];
        return e14 === r11;
      }));
    });
  }
  _clearCaches() {
    this.pageCache.clear(), this._objectIdCache.removeAll();
  }
  _createBaseGraphic(e13, r10) {
    const s18 = new b({ attributes: { [e13.objectIdField]: r10 } });
    return this._subtypeField && null != this._subtypeCode && (s18.attributes[this._subtypeField] = this._subtypeCode), s18;
  }
  _ensureArray(e13) {
    return Array.isArray(e13) ? e13 : [e13];
  }
  _ensureArrayContent(e13) {
    return Array.isArray(e13) ? e13[0] : e13;
  }
  _getObjectIdsForPage(e13, t3) {
    const r10 = this._objectIdCache.toArray();
    return r10.length >= e13 + t3 ? r10.slice(e13, e13 + t3) : r10.slice(e13);
  }
  _logError(e13, t3) {
    n.getLogger(this).error(e13, t3);
  }
  _reset() {
    this._clearCaches(), this.failures.removeAll(), this._attachmentsOperationQueue.removeAll(), this._editOperationQueue.removeAll(), this._queryOperationQueue.removeAll(), this._loading = false, this._loaded = false, this._loadError = false, this._set("count", 0);
  }
  _syncCount(e13) {
    return __async(this, null, function* () {
      null == e13 ? yield this._queryCount().then((e14) => this._set("count", e14)) : this._set("count", e13);
    });
  }
  _syncObjectIdCache() {
    return __async(this, null, function* () {
      if (this.supportsPagination) return;
      const e13 = yield this._queryObjectIds();
      this._objectIdCache.removeAll(), this._objectIdCache.addMany(e13);
    });
  }
  _verifyFeaturesByObjectId(e13) {
    return __async(this, null, function* () {
      const { layer: t3 } = this;
      if (!t3 || !this.supportsQuery) throw new s2("store:query-error", "Layer does not support query operation.");
      const { effectiveTimeExtent: r10, effectiveWhere: s18, orderByFields: i11, supportsCacheHint: a17, supportsOrderBy: n17 } = this, u5 = t3.createQuery();
      u5.where = s18, u5.timeExtent = r10, u5.returnGeometry = false, u5.objectIds = e13.length ? e13 : void 0, u5.outFields = [t3.objectIdField], n17 && (u5.orderByFields = i11), a17 && (u5.cacheHint = true);
      return (yield t3.queryFeatures(u5)).features;
    });
  }
  _update(e13) {
    return __async(this, null, function* () {
      const { objectId: r10, updates: s18 } = e13, { _layerWithEditing: i11 } = this;
      if (!this.supportsUpdate || !i11) throw new s2("store:update-error", "Update is not supported.");
      const a17 = this.getItemByObjectId(r10)?.feature;
      if (!a17) throw new s2("store:update-error", "Feature with provided 'objectId' not found.");
      const u5 = a(a17.attributes);
      s18.forEach(({ fieldName: e14, value: t3 }) => u5[e14] = t3);
      const p14 = new b({ attributes: u5 }), l10 = i11.applyEdits({ updateFeatures: [p14] }).then((e14) => {
        const { updateFeatureResults: t3 } = e14, r11 = t3.find((e15) => !!e15.error);
        if (r11) throw r11.error;
        return t3.length && (a17.attributes = u5), e14;
      });
      return this._queueEditOperation(() => l10);
    });
  }
  _prepareFeatureData(e13) {
    const { attachments: t3, features: r10, layer: s18, relatedRecords: i11 } = e13, a17 = s18.objectIdField;
    return r10.map((e14) => {
      const r11 = e14.getObjectId() ?? e14.attributes[a17], o5 = [];
      return e14.layer || e14.sourceLayer || (e14.layer = s18, e14.sourceLayer = s18), i11.forEach((e15, t4) => {
        o5.push({ relationshipId: t4, count: e15[r11] ?? 0 });
      }), { objectId: r11, feature: e14, attachments: t3[r11] ?? null, relatedRecords: o5 };
    });
  }
  _query(e13) {
    return __async(this, null, function* () {
      const { page: t3, refresh: r10 } = e13;
      true === r10 && (yield this.refresh());
      const s18 = this.pageCache.get(t3);
      if (s18) return s18;
      const i11 = yield this._queryPage(e13);
      return this.pageCache.set(t3, i11), i11;
    });
  }
  _queryAttachments(e13) {
    const { _layerWithAttachments: t3, effectiveWhere: r10 } = this;
    return t3 ? e13.some((e14) => "number" != typeof e14) ? Promise.reject(new s2("invalid-object-id", "Only numeric object ids are valid to query attachments")) : t3.queryAttachments(new c4({ objectIds: e13, where: r10, returnMetadata: true })) : Promise.resolve({});
  }
  _queryCount() {
    return __async(this, null, function* () {
      const { _relatedLayerSupportsCacheHint: e13, layer: t3, relationshipConfig: r10, supportsCacheHint: s18 } = this;
      if (!t3) return 0;
      if (r10 && this._canUseRelatedLayer) {
        const { objectId: t4, relatedLayer: s19, relationshipId: i12 } = r10;
        return (yield s19.queryRelatedFeaturesCount(new d3({ cacheHint: e13, relationshipId: i12, objectIds: [t4] })))[t4] ?? 0;
      }
      const { effectiveTimeExtent: i11, effectiveWhere: a17, filterGeometry: o5, objectIds: n17 } = this, u5 = t3.createQuery();
      return u5.geometry = o5, u5.returnGeometry = false, u5.where = a17, u5.timeExtent = i11, u5.objectIds = n17?.length ? n17 : void 0, s18 && (u5.cacheHint = true), t3.queryFeatureCount(u5);
    });
  }
  _queryFeatures(e13) {
    return __async(this, null, function* () {
      const { relationshipConfig: t3 } = this;
      if (t3 && this._canUseRelatedLayer) return this._queryRelatedFeatures(e13, t3);
      const { _effectiveReturnM: r10, _effectiveReturnZ: s18, effectiveOutFields: i11, effectiveTimeExtent: a17, effectiveWhere: o5, filterGeometry: n17, objectIds: u5, orderByFields: p14, pageSize: l10, returnGeometry: h8, supportsCacheHint: d6, supportsOrderBy: c13, supportsPagination: y5 } = this, { layer: m8, start: _2 } = e13, f7 = u5?.length, g6 = m8.createQuery();
      g6.returnGeometry = h8, g6.outFields = i11, g6.returnM = r10, g6.returnZ = s18, y5 ? (g6.start = _2, g6.num = l10, g6.where = o5, g6.timeExtent = a17, g6.objectIds = f7 ? u5 : void 0) : g6.objectIds = f7 ? u5 : this._getObjectIdsForPage(_2, l10 ?? 0), c13 && (g6.orderByFields = p14), n17 && (g6.geometry = n17), d6 && (g6.cacheHint = true);
      return (yield m8.queryFeatures(g6)).features;
    });
  }
  _queryObjectIds() {
    const { effectiveTimeExtent: e13, effectiveWhere: t3, filterGeometry: r10, layer: s18, objectIds: i11, orderByFields: a17, supportsCacheHint: o5, supportsOrderBy: n17 } = this;
    if (!s18) return Promise.resolve([]);
    const u5 = s18.createQuery();
    return u5.geometry = r10, u5.outFields = [s18.objectIdField], u5.returnGeometry = false, u5.where = t3, u5.timeExtent = e13, u5.objectIds = i11?.length ? i11 : void 0, n17 && (u5.orderByFields = a17), o5 && (u5.cacheHint = true), s18.queryObjectIds(u5);
  }
  _queryPage(e13) {
    return __async(this, null, function* () {
      const { layer: t3 } = e13;
      return this._queueQueryOperation(() => __async(this, null, function* () {
        const r10 = yield this._queryFeatures(e13), s18 = r10.map((e14) => e14.getObjectId() ?? e14.attributes[t3.objectIdField]), i11 = yield this._queryAttachments(s18), a17 = yield this._queryRelatedCounts(s18);
        return this._prepareFeatureData({ layer: t3, features: r10, attachments: i11, relatedRecords: a17 }) || [];
      }));
    });
  }
  _queryRelatedCounts(e13) {
    return __async(this, null, function* () {
      const { _layerWithRelationships: t3, relationshipIds: r10, supportsCacheHintQueryRelated: s18 } = this, i11 = /* @__PURE__ */ new Map();
      return t3 && e13?.length && r10.length ? (yield Promise.allSettled(r10.map((r11) => __async(this, null, function* () {
        const a17 = yield t3.queryRelatedFeaturesCount(new d3({ cacheHint: s18, relationshipId: r11, objectIds: e13 }));
        i11.set(r11, a17);
      }))), i11) : i11;
    });
  }
  _queryRelatedFeatures(e13, t3) {
    return __async(this, null, function* () {
      const { _defaultOutFields: r10, _effectiveReturnM: s18, _effectiveReturnZ: i11, orderByFields: a17, pageSize: o5, returnGeometry: n17, supportsCacheHint: u5 } = this, { layer: p14, start: l10 } = e13, { objectId: h8, relatedLayer: d6, relationshipId: c13 } = t3, y5 = p14.createQuery(), m8 = new d3({ cacheHint: u5, num: o5, objectIds: [h8], orderByFields: a17, outFields: r10, relationshipId: c13, returnGeometry: n17, returnM: s18, returnZ: i11, start: l10, where: y5.where ?? void 0 }), _2 = yield d6.queryRelatedFeatures(m8);
      return _2[h8]?.features || [];
    });
  }
  _queueAttachmentsOperation(e13, t3) {
    return this._attachmentsOperationQueue.push(t3), t3().then((r10) => __async(this, null, function* () {
      this._attachmentsOperationQueue.remove(t3);
      const s18 = this._ensureArray(r10), i11 = s18.some((e14) => e14.error), a17 = this.getItemByObjectId(e13);
      if (a17 && (!i11 || s18.length > 1)) {
        const t4 = yield this._queryAttachments([e13]);
        a17.attachments = t4[e13];
      }
      return r10;
    })).catch((r10) => __async(this, null, function* () {
      this._logError("store:attachment-error", "An error occurred.");
      const s18 = { error: r10, retry: () => {
        this.failures.remove(s18), this._queueAttachmentsOperation(e13, t3);
      }, cancel: () => this.failures.remove(s18) };
      throw this.failures.add(s18), this._attachmentsOperationQueue.remove(t3), r10;
    }));
  }
  _queueEditOperation(e13) {
    return this._editOperationQueue.push(e13), e13().then((t3) => (this._editOperationQueue.remove(e13), t3)).catch((t3) => {
      this._logError("store:edit-error", "An error occurred.");
      const r10 = { error: t3, retry: () => {
        this.failures.remove(r10), this._queueEditOperation(e13);
      }, cancel: () => this.failures.remove(r10) };
      throw this.failures.add(r10), this._editOperationQueue.remove(e13), t3;
    });
  }
  _queueQueryOperation(e13) {
    return this._queryOperationQueue.push(e13), e13().then((t3) => this._queryOperationQueue.includes(e13) ? t3 : []).catch((t3) => {
      this._logError("store:query-error", "An error occurred.");
      const r10 = { error: t3, retry: () => {
        this.failures.remove(r10), this._queueQueryOperation(e13);
      }, cancel: () => this.failures.remove(r10) };
      return this.failures.add(r10), [];
    }).then((t3) => (this._queryOperationQueue.remove(e13), t3));
  }
};
r([m()], C4.prototype, "_attachmentsOperationQueue", void 0), r([m({ readOnly: true })], C4.prototype, "_capabilities", null), r([m()], C4.prototype, "_defaultOutFields", void 0), r([m()], C4.prototype, "_editOperationQueue", void 0), r([m()], C4.prototype, "_effectiveReturnZ", null), r([m()], C4.prototype, "_effectiveReturnM", null), r([m({ readOnly: true })], C4.prototype, "_layerWithAttachments", null), r([m({ readOnly: true })], C4.prototype, "_layerWithAttachmentsEditing", null), r([m({ readOnly: true })], C4.prototype, "_layerWithEditing", null), r([m({ readOnly: true })], C4.prototype, "_layerWithRelationships", null), r([m()], C4.prototype, "_loaded", void 0), r([m()], C4.prototype, "_loadError", void 0), r([m()], C4.prototype, "_loading", void 0), r([m()], C4.prototype, "_objectIdCache", void 0), r([m()], C4.prototype, "_queryOperationQueue", void 0), r([m({ readOnly: true })], C4.prototype, "_relatedLayer", null), r([m({ readOnly: true })], C4.prototype, "_relatedLayerCapabilities", null), r([m({ readOnly: true })], C4.prototype, "_relatedLayerSupportsCacheHint", null), r([m()], C4.prototype, "_relatedLayerSupportsQuery", null), r([m()], C4.prototype, "_relatedLayerSupportsQueryRelated", null), r([m()], C4.prototype, "_sortedFieldNames", null), r([m()], C4.prototype, "_subtypeCode", null), r([m()], C4.prototype, "_subtypeField", null), r([m()], C4.prototype, "_canUseRelatedLayer", null), r([m()], C4.prototype, "attachmentsEnabled", void 0), r([m()], C4.prototype, "canAddRelatedFeature", null), r([m({ readOnly: true })], C4.prototype, "count", void 0), r([m()], C4.prototype, "effectiveOutFields", null), r([m()], C4.prototype, "effectiveTimeExtent", null), r([m()], C4.prototype, "effectiveWhere", null), r([m({ readOnly: true })], C4.prototype, "failures", void 0), r([m({ types: l2 })], C4.prototype, "filterGeometry", void 0), r([m()], C4.prototype, "initialSize", void 0), r([m({ readOnly: true })], C4.prototype, "itemCache", null), r([m()], C4.prototype, "layer", void 0), r([m()], C4.prototype, "layerView", null), r([m()], C4.prototype, "objectIds", void 0), r([m()], C4.prototype, "orderByFields", null), r([m()], C4.prototype, "outFields", void 0), r([m({ readOnly: true })], C4.prototype, "pageCache", void 0), r([m()], C4.prototype, "pageSize", void 0), r([m({ readOnly: true })], C4.prototype, "querying", null), r([m()], C4.prototype, "relationship", null), r([m()], C4.prototype, "relationshipConfig", void 0), r([m()], C4.prototype, "relationshipIds", null), r([m()], C4.prototype, "relationshipInfos", null), r([m()], C4.prototype, "relationships", null), r([m()], C4.prototype, "relatedRecordsEnabled", void 0), r([m()], C4.prototype, "returnGeometry", void 0), r([m()], C4.prototype, "returnZ", void 0), r([m()], C4.prototype, "returnM", void 0), r([m()], C4.prototype, "sortOrders", void 0), r([m({ readOnly: true })], C4.prototype, "state", null), r([m()], C4.prototype, "supportsAdd", null), r([m()], C4.prototype, "supportsAddingAttachments", null), r([m()], C4.prototype, "supportsAttachments", null), r([m()], C4.prototype, "supportsCacheHint", null), r([m()], C4.prototype, "supportsCacheHintQueryRelated", null), r([m()], C4.prototype, "supportsDelete", null), r([m()], C4.prototype, "supportsDeletingAttachments", null), r([m()], C4.prototype, "supportsEditing", null), r([m()], C4.prototype, "supportsM", null), r([m()], C4.prototype, "supportsOrderBy", null), r([m()], C4.prototype, "supportsPagination", null), r([m()], C4.prototype, "supportsQuery", null), r([m()], C4.prototype, "supportsQueryRelated", null), r([m()], C4.prototype, "supportsResizeAttachments", null), r([m()], C4.prototype, "supportsUpdate", null), r([m()], C4.prototype, "supportsUpdateAttachments", null), r([m()], C4.prototype, "supportsZ", null), r([m({ readOnly: true })], C4.prototype, "syncing", null), r([m({ readOnly: true })], C4.prototype, "syncingAttachmentEdits", null), r([m({ readOnly: true })], C4.prototype, "syncingFeatureEdits", null), r([m({ type: p2 })], C4.prototype, "timeExtent", void 0), r([m()], C4.prototype, "view", void 0), r([m()], C4.prototype, "where", void 0), C4 = r([a2("esri.widgets.FeatureTable.support.FeatureStore")], C4);
var w4 = C4;

// node_modules/@arcgis/core/widgets/FeatureTable/support/EditableColumnTemplateMixin.js
var s15 = (s18) => {
  let i11 = class extends s18 {
    constructor() {
      super(...arguments), this.editable = true, this.hint = null, this.input = null, this.required = false;
    }
  };
  return r([m({ type: Boolean, json: { write: true } })], i11.prototype, "editable", void 0), r([m({ type: String, json: { write: true } })], i11.prototype, "hint", void 0), r([m({ types: c3, json: { read: { source: "inputType" }, write: { target: "inputType" } } })], i11.prototype, "input", void 0), r([m()], i11.prototype, "required", void 0), i11 = r([a2("esri.widgets.FeatureTable.support.EditableColumnTemplateMixin")], i11), i11;
};

// node_modules/@arcgis/core/widgets/FeatureTable/support/FieldColumnTemplate.js
var n16 = class extends s15(p10) {
  constructor(o5) {
    super(o5), this.domain = null, this.editableExpression = null, this.format = null, this.formatFunction = null, this.requiredExpression = null, this.sortable = true, this.type = "field", this.valueExpression = null, this.visibilityExpression = null;
  }
};
r([m({ types: n5, json: { read: { reader: i4 }, write: true } })], n16.prototype, "domain", void 0), r([m({ type: String, json: { write: true } }), m()], n16.prototype, "editableExpression", void 0), r([m()], n16.prototype, "format", void 0), r([m()], n16.prototype, "formatFunction", void 0), r([m({ type: String, json: { write: true } })], n16.prototype, "requiredExpression", void 0), r([m()], n16.prototype, "sortable", void 0), r([m({ type: String, json: { read: false, write: true } })], n16.prototype, "type", void 0), r([m({ type: String, json: { write: true } })], n16.prototype, "valueExpression", void 0), r([m({ type: String, json: { write: true } })], n16.prototype, "visibilityExpression", void 0), n16 = r([a2("esri.widgets.FeatureTable.support.FieldColumnTemplate")], n16);
var l9 = n16;

// node_modules/@arcgis/core/widgets/FeatureTable/support/RelationshipColumnTemplate.js
var s16 = class extends p10 {
  constructor(o5) {
    super(o5), this.collapsed = false, this.icon = "link", this.relationshipId = null, this.sortable = false, this.textAlign = "center", this.type = "relationship";
  }
};
r([m()], s16.prototype, "collapsed", void 0), r([m()], s16.prototype, "icon", void 0), r([m()], s16.prototype, "relationshipId", void 0), r([m()], s16.prototype, "sortable", void 0), r([m()], s16.prototype, "textAlign", void 0), r([m({ type: String, json: { read: false, write: true } })], s16.prototype, "type", void 0), s16 = r([a2("esri.widgets.FeatureTable.support.RelationshipColumnTemplate")], s16);
var p11 = s16;

// node_modules/@arcgis/core/widgets/FeatureTable/support/ColumnTemplate.js
var p12 = class extends s15(p10) {
  constructor(o5) {
    super(o5), this.type = "column";
  }
};
r([m({ type: String, json: { read: false, write: true } })], p12.prototype, "type", void 0), p12 = r([a2("esri.widgets.FeatureTable.support.ColumnTemplate")], p12);
var m7 = p12;

// node_modules/@arcgis/core/widgets/FeatureTable/support/GroupColumnTemplate.js
var u4 = class extends p10 {
  constructor(e13) {
    super(e13), this.columnTemplates = null, this.type = "group";
  }
  castColumnTemplates(e13) {
    if (!e13 || !Array.isArray(e13)) return [];
    const t3 = [];
    return e13.forEach((e14) => {
      if (e14 instanceof l9 || e14 instanceof m7 || e14 instanceof a13 || e14 instanceof p11) t3.push(e14);
      else if (n11(e14)) {
        const r10 = e14.type;
        "field" === r10 ? t3.push(new l9(e14)) : "group" === r10 ? n.getLogger(this).warn("A GroupColumnTemplate cannot contain other GroupColumn templates. Template removed from 'GroupColumnTemplate.columnTemplates'.") : "column" === r10 ? t3.push(new m7(e14)) : "attachment" === r10 ? t3.push(new a13(e14)) : "relationship" === r10 && t3.push(new p11(e14));
      } else n.getLogger(this).warn("Property 'type' is missing from the provided template. Template removed from 'tableTemplate.columnTemplates'.");
    }), t3;
  }
};
r([m({ json: { write: true } })], u4.prototype, "columnTemplates", void 0), r([s5("columnTemplates")], u4.prototype, "castColumnTemplates", null), r([m({ type: String, json: { read: false, write: true } })], u4.prototype, "type", void 0), u4 = r([a2("esri.widgets.FeatureTable.support.GroupColumnTemplate")], u4);
var c12 = u4;

// node_modules/@arcgis/core/widgets/FeatureTable/support/TableTemplate.js
var f6;
var T4 = f6 = class extends S {
  constructor(e13) {
    super(e13), this.columnTemplates = [];
  }
  castColumnTemplates(e13) {
    if (!e13 || !Array.isArray(e13)) return [];
    const o5 = [];
    return e13.forEach((e14) => {
      if (e14 instanceof l9 || e14 instanceof c12 || e14 instanceof m7 || e14 instanceof a13 || e14 instanceof p11) o5.push(e14);
      else if (n11(e14)) {
        const t3 = e14.type;
        "field" === t3 ? o5.push(new l9(e14)) : "group" === t3 ? o5.push(new c12(e14)) : "column" === t3 ? o5.push(new m7(e14)) : "attachment" === t3 ? o5.push(new a13(e14)) : "relationship" === t3 && o5.push(new p11(e14));
      } else n.getLogger(this).warn("Property 'type' is missing from the provided template. Template removed from 'tableTemplate.columnTemplates'.");
    }), o5;
  }
  clone() {
    return new f6({ columnTemplates: a(this.columnTemplates) });
  }
};
r([m()], T4.prototype, "columnTemplates", void 0), r([s5("columnTemplates")], T4.prototype, "castColumnTemplates", null), T4 = f6 = r([a2("esri.widgets.FeatureTable.support.TableTemplate")], T4);
var h6 = T4;

// node_modules/@arcgis/core/widgets/FeatureTable/support/templateUtils.js
function b4(t3) {
  const i11 = [];
  return t3.forEach((t4) => {
    const { description: r10, label: l10, hidden: s18 } = t4;
    if (e11(t4)) {
      if (s18) return;
      const o5 = t4.columns?.map((e13) => h7(e13)).filter(G);
      if (!o5?.length) return;
      i11.push(new j2({ description: r10, elements: o5, label: l10 }));
    } else {
      const e13 = h7(t4);
      if (!e13) return;
      i11.push(e13);
    }
  }), i11;
}
function h7(e13) {
  const { fieldName: n17, description: l10, hidden: o5, label: p14 } = e13;
  if (t2(e13)) {
    if (!o5) return new p3({ description: l10, fieldName: n17, label: p14 });
  } else if (i6(e13)) {
    if (!o5) return new p4({ description: l10, label: p14, relationshipId: e13.relationshipId });
  } else if (o2(e13) && !o5) return new a3({ description: l10, label: p14 });
}

// node_modules/@arcgis/core/widgets/FeatureTable/FeatureTableViewModel.js
var re = "80px";
var ae = class extends p8 {
  constructor(e13) {
    super(e13), this._debounceRefresh = k(() => this._refresh()), this._temporaryHighlightAbortController = null, this._currentTemporaryHighlight = null, this._highlights = new r2(), this.actionColumnConfig = null, this.attachmentsViewOptions = new a14(), this.attributeTableTemplate = null, this.autoRefreshEnabled = true, this.columns = new V(), this.dataProvider = (e14, t3) => __async(this, null, function* () {
      const { layer: i11, store: s18 } = this;
      if (!t3) return;
      if (!i11 || !s18) return void (t3 && t3([]));
      yield i11.load();
      const { objectIds: l10 } = this;
      if (this.filterBySelectionEnabled && !this.highlightIds.length || 1 === l10.length && -1 === l10.items[0]) return void t3([]);
      "loaded" !== s18.state && "loading" !== s18.state && (yield s18.load());
      const o5 = this.paginationEnabled ? this.pageIndex : e14.page, n17 = yield s18.fetchItems(__spreadProps(__spreadValues({}, e14), { page: o5 }));
      t3 && t3(n17);
    }), this.editingEnabled = false, this.grid = null, this.highlightEnabled = true, this.itemIdPath = "objectId", this.layers = null, this.messages = null, this.messagesCommon = null, this.messagesUnits = null, this.messagesURIUtils = null, this.prompt = null, this.relatedTables = new V(), this.relationshipColumnConfigs = null, this.selectionSource = "table", this.showRelatedTableCallback = null, this.store = null, this.syncTemplateOnChangesEnabled = true, this.tableController = null, this.tableParent = null, this.tableTemplate = null, this.tableTemplateOverride = null, this._onLayerRefresh = this._onLayerRefresh.bind(this), this._onShowPromptCallback = this._onShowPromptCallback.bind(this), this._set("store", new w4()), this._set("grid", new v2({ itemIdPath: this.itemIdPath, viewModel: this }));
  }
  initialize() {
    const e13 = () => __async(this, null, function* () {
      this.messages = yield f("esri/widgets/FeatureTable/t9n/FeatureTable"), this.messagesCommon = yield f("esri/t9n/common"), this.messagesUnits = yield f("esri/core/t9n/Units"), this.messagesURIUtils = yield f("esri/widgets/support/t9n/uriUtils");
    });
    e13(), this.addHandles([h(() => {
      e13(), this._generateColumns();
    }), d2(() => [this.messages, this.messagesCommon, this.messagesURIUtils], () => {
      const e14 = this.messages;
      this.grid && (this.grid.messages = e14), this.allColumns.forEach((t3) => {
        t3.messages = e14, t3.messagesCommon = this.messagesCommon, t3.messagesURIUtils = this.messagesURIUtils;
      }), this.refreshCellContent();
    }, P), v(() => this.highlightIds, "change", (e14) => this._onHighlightIdsChange(e14), { onListenerAdd: () => this._syncSelection(), onListenerRemove: () => this._highlights.removeAll() }), d2(() => this.grid?.temporaryHighlightId, (e14) => {
      this._temporaryHighlightAbortController?.abort(), this._temporaryHighlightAbortController = new AbortController(), d(this._syncTemporaryHighlight(e14, this._temporaryHighlightAbortController.signal));
    }), d2(() => this.attachmentsEnabled, () => this.layer?.loaded && this._generateColumns()), d2(() => this._viewSelection, () => {
      this._viewSelectionReady && (this.highlightIds.items = this._viewSelection);
    }), d2(() => [this._tableHighlightsReady, this._viewSelectionReady], () => this._syncSelection()), d2(() => this.layer, (e14, t3) => __async(this, null, function* () {
      const i11 = this.grid;
      i11 && (i11.clearSort(), e14 && t3 && (yield this.reset())), this.goToPage(0), this._drainColumns(), this.store.layer = e14, e14 && (e14.loaded ? this._onLayerLoad() : e14.load().catch(() => {
      }));
    })), d2(() => this.layer?.loaded, (e14) => e14 && this._onLayerLoad()), d2(() => this.store.state, (e14) => {
      "loaded" === e14 && (this.scrollToTop(), this.refreshCellContent());
    }), d2(() => this._effectiveTableTemplate, () => {
      this.scrollLeft(), this.layer?.loaded && this._generateColumns();
    }), d2(() => this.editingEnabled, (e14) => {
      this.editableColumns.forEach((t3) => t3.tableEditingEnabled = e14), this.refreshCellContent();
    }), d2(() => this.timeZone ?? this.view?.timeZone, () => this.refreshCellContent()), d2(() => this.layer?.definitionExpression, (e14, t3) => (e14 || t3) && "loaded" === this.store.state && this.reset()), d2(() => this.layer?.timeExtent, (e14, t3) => (e14 || t3) && !this.timeExtent && "loaded" === this.store.state && this.reset()), v(() => this.layer, "refresh", (e14) => this._onLayerRefresh(e14)), v(() => this.grid, ["cell-click", "cell-dblclick", "cell-pointerover", "cell-pointerout", "cell-keydown", "column-reorder"], ({ index: e14, item: t3, native: i11, path: s18, type: l10 }) => {
      const o5 = t3?.feature, n17 = o5?.getObjectId(), r10 = "cell-keydown" === l10 && i11 && i11 instanceof KeyboardEvent && "Enter" === i11.key;
      this.emit(l10, { feature: o5, index: e14, native: i11, type: l10, fieldName: s18 ?? void 0, objectId: n17 }), (r10 || "cell-click" === l10) && this._onCellInteraction(n17);
    }), d2(() => this.actionColumnConfig, (e14) => {
      const { actionColumn: t3, columns: i11 } = this;
      t3 ? e14 ? t3.set(e14) : i11.remove(t3) : e14 && i11.length && i11.add(this._generateActionColumn(), false !== e14.frozenToEnd ? void 0 : this._getIndexOfFirstFrozenToEndColumn());
    }), d2(() => this.relatedRecordsEnabled, () => this.layer?.loaded && this._generateColumns()), v(() => this.objectIds, "change", () => this._onObjectIdsChange(), { onListenerAdd: () => this._onObjectIdsChange() }), d2(() => [this.paginationEnabled, this.pageIndex], () => this.refreshPageCache()), d2(() => this.activeSortOrders, (e14) => {
      this.store.sortOrders = e14, this._syncAttributeTableTemplate();
    }), d2(() => this.allVisibleColumns, () => this._syncAttributeTableTemplate()), d2(() => this.pageCount, () => {
      this.pageIndex >= this.pageCount && this.goToPage(0);
    }), d2(() => this.state, (e14) => {
      "disabled" === e14 && this.relatedTables.length && this.drainRelatedTables();
    }), v(() => this.tableParent?.highlightIds, "change", ({ added: e14 }) => {
      const { relationshipConfig: t3 } = this, i11 = e14[0];
      if (null == i11 || !t3) return;
      const { relatedLayer: s18, relationshipId: l10 } = t3;
      this.relationshipConfig = { objectId: i11, relatedLayer: s18, relationshipId: l10 };
    }), v(() => this.tableParent, "cell-click", (e14) => {
      const { tableParent: t3 } = this, { objectId: i11 } = e14;
      t3 && null != i11 && t3.highlightIds.add(i11);
    }), d2(() => this.attachmentsViewOptions.objectId, (e14, t3) => {
      null != e14 ? null == t3 && this.showAttachmentsView({ objectId: e14 }) : this.hideAttachmentsView();
    })]);
  }
  destroy() {
    this._drainColumns(), this._highlights.removeAll(), this._highlights.destroy(), this._currentTemporaryHighlight?.handle.remove(), this._temporaryHighlightAbortController = e(this._temporaryHighlightAbortController), this.grid?.destroy(), this.columns.destroyed || this.columns.destroy(), this.layer = null, this.view = null;
  }
  get _defaultHiddenFields() {
    return B(this.layer);
  }
  get _effectiveTableTemplate() {
    return this.tableTemplateOverride || this.tableTemplate;
  }
  get _effectiveAttributeTableTemplate() {
    return this.attributeTableTemplate || this.layer?.attributeTableTemplate;
  }
  get _highlightableLayerView() {
    const e13 = this.layerView;
    return n7(e13) ? e13 : null;
  }
  get _selectionManager() {
    const { view: e13 } = this;
    return !e13 || e13.destroyed ? null : e13.selectionManager?.sources?.length ? e13.selectionManager : null;
  }
  get _selectableLayer() {
    const { layer: e13 } = this;
    if (e9(e13) || l3(e13)) {
      const t3 = e13;
      return this._selectionManager?.sources?.includes(t3) ? t3 : null;
    }
    return null;
  }
  get _subtypes() {
    return P2(this.layer);
  }
  get _tableHighlightsReady() {
    return !("table" !== this.selectionSource || !this.highlightEnabled || !this._highlightableLayerView);
  }
  get _viewSelection() {
    const { _selectableLayer: e13 } = this;
    return e13 ? this._selectionManager?.getSelection(e13) ?? [] : [];
  }
  get _viewSelectionReady() {
    return !(!this.layer || "view" !== this.selectionSource || !this._selectionManager);
  }
  get allRelatedTablesVisible() {
    return !!(this.relatedRecordsEnabled && this.relatedTables.length && this.showAllRelatedTables);
  }
  get activeFilters() {
    const { filterGeometry: e13, objectIds: t3, filterBySelectionEnabled: s18, highlightIds: l10 } = this, o5 = new V();
    return e13 && o5.push({ type: "geometry", geometry: e13 }), s18 ? o5.push({ type: "selection", objectIds: l10.toArray() }) : t3.length && o5.push({ type: "objectId", objectIds: t3.toArray() }), o5;
  }
  get activeSortOrders() {
    return this.grid?.sortOrders ? this.grid.sortOrders.map(({ path: e13, direction: t3 }) => ({ fieldName: e13, direction: t3 })).filter((e13) => e13.fieldName && e13.direction) : [];
  }
  get attachmentsEnabled() {
    return this.store.attachmentsEnabled;
  }
  set attachmentsEnabled(e13) {
    this.store.attachmentsEnabled = e13;
  }
  get clearPrompt() {
    return () => this.prompt = null;
  }
  set clearPrompt(e13) {
    this._overrideIfSome("clearPrompt", e13);
  }
  get filterGeometry() {
    return this.store.filterGeometry;
  }
  set filterGeometry(e13) {
    this.store.filterGeometry = e13;
  }
  get filterBySelectionEnabled() {
    return !!this._get("filterBySelectionEnabled");
  }
  set filterBySelectionEnabled(e13) {
    const { objectIds: t3 } = this, i11 = t3.length;
    e13 ? (i11 && (t3.removeAll(), this._logWarning("Selection filter has been applied with an objectID filter. Object ID filter has been removed.")), this.filterGeometry && this._logWarning("Selection filter has been applied with a geometry filter. Results may appear inconsistent"), this._syncObjectIdsWithStore(this.highlightIds.toArray())) : i11 || this._syncObjectIdsWithStore(null), this._set("filterBySelectionEnabled", e13);
  }
  get hiddenFields() {
    return this._get("hiddenFields") ?? new V();
  }
  set hiddenFields(e13) {
    this._set("hiddenFields", n6(e13, this._get("hiddenFields"), V));
  }
  get initialSize() {
    return this.store.initialSize;
  }
  set initialSize(e13) {
    this.store.initialSize = e13;
  }
  get isQueryingOrSyncing() {
    const { store: e13 } = this;
    return e13?.syncing || e13?.querying || this.relatedTables.some((e14) => !!e14.isQueryingOrSyncing);
  }
  get isSyncingAttachments() {
    return this.store.syncingAttachmentEdits || this.relatedTables.some((e13) => !!e13.isSyncingAttachments);
  }
  get layer() {
    return this._get("layer");
  }
  set layer(e13) {
    this._highlights.removeAll(), this.drainRelatedTables(), this._set("layer", e13);
  }
  get layerView() {
    return this.store.layerView;
  }
  get outFields() {
    return this.store.outFields;
  }
  set outFields(e13) {
    this.store.outFields = e13;
  }
  get relatedRecordsEnabled() {
    return this.store.relatedRecordsEnabled;
  }
  set relatedRecordsEnabled(e13) {
    this.store.relatedRecordsEnabled = e13;
  }
  get relatedTable() {
    return this.relatedTables.at(-1);
  }
  get relationship() {
    const e13 = this.relationshipConfig?.relationshipId;
    return null == e13 ? null : this.relationships?.find(({ id: t3 }) => t3 === e13);
  }
  get relationshipConfig() {
    return this.store.relationshipConfig;
  }
  set relationshipConfig(e13) {
    this.highlightIds.removeAll(), this.objectIds.removeAll(), this.filterBySelectionEnabled = false, this.store.relationshipConfig = e13;
  }
  get relationshipInfos() {
    const { layer: e13, layers: t3, relationships: i11, tableController: s18 } = this, l10 = this.store.relationshipInfos;
    if (l10.length || !p6(e13) || !i11?.length) return l10;
    const o5 = [], n17 = s18?.layers || t3 || [];
    return i11.forEach((t4) => {
      const i12 = d4(e13, n17, t4);
      i12 && (i12.load(), o5.push({ layer: e13, relatedLayer: i12, relationshipId: t4.id }));
    }), o5;
  }
  get relationships() {
    return this.store.relationships;
  }
  get returnGeometryEnabled() {
    return this.store.returnGeometry;
  }
  set returnGeometryEnabled(e13) {
    this.store.returnGeometry = e13;
  }
  get returnMEnabled() {
    return this.store.returnM;
  }
  set returnMEnabled(e13) {
    this.store.returnM = e13;
  }
  get returnZEnabled() {
    return this.store.returnZ;
  }
  set returnZEnabled(e13) {
    this.store.returnZ = e13;
  }
  get showAllRelatedTables() {
    return this._get("showAllRelatedTables");
  }
  set showAllRelatedTables(e13) {
    const { relatedTable: t3 } = this;
    this._set("showAllRelatedTables", e13), t3 && (e13 ? this._showAllRelatedTables(t3) : this._hideAllRelatedTables(t3));
  }
  get showPrompt() {
    return (e13) => {
      this.prompt?.cancel?.(), this.prompt = e13;
    };
  }
  set showPrompt(e13) {
    this._overrideIfSome("showPrompt", e13);
  }
  get supportsAttachments() {
    return this.store.supportsAttachments;
  }
  get supportsAddAttachments() {
    const { store: { supportsAddingAttachments: e13, supportsEditing: t3 } } = this;
    return this.editingEnabled && t3 && e13;
  }
  get supportsDeleteAttachments() {
    const { store: { supportsDeletingAttachments: e13, supportsEditing: t3 } } = this;
    return this.editingEnabled && t3 && e13;
  }
  get supportsResizeAttachments() {
    return this.store.supportsResizeAttachments;
  }
  get supportsUpdateAttachments() {
    const { store: { supportsUpdateAttachments: e13, supportsEditing: t3 } } = this;
    return this.editingEnabled && t3 && e13;
  }
  get timeExtent() {
    return this.store.timeExtent;
  }
  set timeExtent(e13) {
    this.store.timeExtent = e13;
  }
  get timeZone() {
    return this._get("timeZone");
  }
  set timeZone(e13) {
    this.allColumns.forEach((t3) => t3.tableTimeZone = e13), this._set("timeZone", e13);
  }
  get view() {
    return this.store.view;
  }
  set view(e13) {
    this.store.view = e13, this.fieldColumns.forEach((t3) => t3.view = e13), this.refreshCellContent();
  }
  addAttachment(e13, t3) {
    return __async(this, null, function* () {
      const { attachmentsViewOptions: i11, store: s18 } = this, l10 = i11.objectId === e13;
      yield s18.addAttachment(e13, t3).catch((e14) => {
        l10 && e14 && "object" == typeof e14 && "error" in e14 && e14.error instanceof s2 && (this._logWarning(`Unable to add attachment. ${e14.error.name} ${e14.error.message}`), i11.error = e14.error);
      }), l10 && !i11.error && (i11.onEditComplete(), i11.attachmentInfos = yield s18.getAttachmentsByObjectId(e13, true)), this.refreshCellContent();
    });
  }
  deleteAttachments(e13, t3) {
    return __async(this, null, function* () {
      const { attachmentsViewOptions: i11, store: s18 } = this, l10 = i11.objectId === e13;
      yield s18.deleteAttachments(e13, t3).catch((e14) => {
        l10 && e14 && "object" == typeof e14 && "error" in e14 && e14.error instanceof s2 && (this._logWarning(`Unable to delete attachment(s). ${e14.error.name} ${e14.error.message}`), i11.error = e14.error);
      }), l10 && !i11.error && (i11.onEditComplete(), i11.attachmentInfos = yield s18.getAttachmentsByObjectId(e13, true)), this.refreshCellContent();
    });
  }
  collapseRelatedTable(e13, t3) {
    const { relatedLayer: s18, objectId: l10, relationshipId: o5 } = t3, { objectIdField: n17 } = s18, r10 = h4(s18, o5), a17 = s18.displayField || r10?.keyField || n17;
    e13.set({ highlightIds: new V([l10]), multipleSelectionEnabled: false, tableTemplateOverride: this._getTableTemplateForRelatedTableView(e13, a17, o5) });
    const h8 = e13.hiddenFields;
    h8.includes(n12.action) || h8.add(n12.action), h8.includes(n12.attachments) || h8.add(n12.attachments), e13.scrollLeft();
  }
  deleteSelection() {
    return __async(this, null, function* () {
      const e13 = this.highlightIds.toArray();
      if (!e13?.length) return;
      const { deleteFeatureResults: t3 } = yield this.store.deleteRowsByObjectId(e13), i11 = t3.filter((e14) => !e14.error).map((e14) => e14.objectId);
      i11.length && (this.highlightIds.removeMany(i11), yield this.refresh());
    });
  }
  downloadAttachmentById(e13, t3) {
    return __async(this, null, function* () {
      const i11 = (yield this.store.getAttachmentsByObjectId(e13, true)).find((e14) => e14.id === t3);
      n15(i11);
    });
  }
  drainRelatedTables() {
    this.relatedTables.drain((e13) => e13.destroy()), this.set({ multipleSelectionEnabled: true, relationshipColumnConfigs: null, showAllRelatedTables: false, tableTemplateOverride: null }), this.hiddenFields.removeMany([n12.action, n12.attachments]);
  }
  drainRelatedTablesAboveIndex(e13) {
    const { relatedTables: t3 } = this, i11 = t3.slice(e13 + 1);
    t3.removeMany(i11).forEach((e14) => e14.destroy());
    const s18 = t3.at(-1);
    s18 && (s18.attachmentsViewOptions.objectId = null, this.allRelatedTablesVisible ? this._showAllRelatedTables(s18) : this._hideAllRelatedTables(s18));
  }
  exportSelectionToCSV(e13) {
    return __async(this, null, function* () {
      const { highlightIds: t3, layer: i11, outFields: s18 } = this;
      i11 && t3.length ? yield a16({ layer: i11, objectIds: t3.toArray(), outFields: s18, includeGeometry: e13 }) : this._logWarning("Export failed.");
    });
  }
  filterBySelection() {
    this.filterBySelectionEnabled ? this._logWarning("Property 'filterBySelectionEnabled' is already 'true'. This method has no effect.") : (i(n.getLogger(this), "`FeatureTable.filterBySelection` is deprecated in favor of 'filterBySelectionEnabled' and 'objectIds'", { replacement: "FeatureTable.filterBySelectionEnabled or FeatureTable.objectIds", version: "4.30", warnOnce: true }), this.objectIds.addMany(this.highlightIds.toArray()));
  }
  getObjectIdIndex(e13) {
    return this.store.getItemIndexByObjectId(e13);
  }
  getValue(e13, t3) {
    const i11 = this.store.getItemByObjectId(e13);
    return i11?.feature?.attributes[t3];
  }
  getVirtualPageIndex() {
    return this.grid?.getVirtualPageIndex() ?? 0;
  }
  goToPage(e13) {
    if (null == e13 || !Number.isInteger(e13)) return void this._logWarning("Invalid 'page' parameter provided to 'goToPage()'. Current page will remain the same.");
    const { pageCount: t3 } = this;
    (e13 >= t3 || -1 === e13) && (e13 = t3 - 1), e13 < -1 && (e13 = 0), e13 !== this.pageIndex && (this.pageIndex = e13), this.paginationEnabled || this.scrollToIndex(e13 * this.pageSize);
  }
  hideAttachmentsView() {
    this.attachmentsViewOptions.objectId = null, this.set({ relationshipColumnConfigs: null, multipleSelectionEnabled: true, tableTemplateOverride: null }), this.hiddenFields.remove(n12.action);
  }
  nextPage() {
    const e13 = this.paginationEnabled ? this.pageIndex : this.getVirtualPageIndex();
    this.goToPage(e13 + 1);
  }
  previousPage() {
    const e13 = this.paginationEnabled ? this.pageIndex : this.getVirtualPageIndex();
    this.goToPage(e13 - 1);
  }
  refresh() {
    return __async(this, null, function* () {
      return this.relatedTables.forEach((e13) => __async(this, null, function* () {
        return yield e13.refresh();
      })), d(this._debounceRefresh());
    });
  }
  refreshCellContent() {
    this.grid?.requestContentUpdate();
  }
  refreshPageCache() {
    this.grid?.refreshPageCache();
  }
  reset() {
    return __async(this, null, function* () {
      this.goToPage(0), yield this.grid?.reset();
    });
  }
  scrollLeft() {
    this.grid?.scrollLeft(0);
  }
  scrollToBottom() {
    this.grid?.scrollToBottom();
  }
  scrollToIndex(e13) {
    this.grid?.scrollToIndex(e13);
  }
  scrollToRow(e13) {
    const t3 = this.store.getItemIndexByObjectId(e13);
    t3 > -1 ? this.grid?.scrollToIndex(t3) : this._logWarning("Row not found. Associated data may not be loaded yet.");
  }
  scrollToTop() {
    this.grid?.scrollToTop();
  }
  saveAttachmentsViewForm() {
    return __async(this, null, function* () {
      const { attachmentId: e13, form: t3, objectId: i11 } = this.attachmentsViewOptions;
      null != i11 && t3 && (null != e13 ? yield this.updateAttachment(i11, e13, t3) : yield this.addAttachment(i11, t3));
    });
  }
  showAttachmentsView(_0) {
    return __async(this, arguments, function* ({ objectId: e13 }) {
      const { attachmentsViewOptions: t3, hiddenFields: s18, layer: l10 } = this;
      if (!this.attachmentsEnabled || !l10) return void this._logWarning("The 'attachmentsEnabled' property is currently false.");
      yield l10.load();
      const o5 = this._getDefaultLayerDisplayField(l10), n17 = yield this.store.getAttachmentsByObjectId(e13, true), r10 = this.store.getItemIndexByObjectId(e13);
      t3.set({ attachmentInfos: n17, mode: n17.length ? "list" : "file", objectId: e13 }), this.set({ highlightIds: new V([e13]), multipleSelectionEnabled: false, relationshipColumnConfigs: [], tableTemplateOverride: this._getTableTemplateForAttachmentsView(o5) }), s18.includes(n12.action) || s18.add(n12.action), null != r10 && this.scrollToIndex(r10);
    });
  }
  syncAttributeTableTemplate() {
    this._syncAttributeTableTemplate(true);
  }
  clearSelectionFilter() {
    i(n.getLogger(this), "`FeatureTable.clearSelectionFilter` is deprecated in favor of 'filterBySelectionEnabled' and 'objectIds'", { replacement: "FeatureTable.filterBySelectionEnabled or FeatureTable.objectIds", version: "4.30", warnOnce: true }), this.objectIds.removeAll();
  }
  updateAttachment(e13, t3, i11) {
    return __async(this, null, function* () {
      const { attachmentsViewOptions: s18, store: l10 } = this, n17 = s18.objectId === e13;
      yield l10.updateAttachment(e13, t3, i11).catch((e14) => {
        n17 && e14 && "object" == typeof e14 && "error" in e14 && e14.error instanceof s2 && (this._logWarning(`Unable to update attachment. ${e14.error.name} ${e14.error.message}`), s18.error = e14.error);
      }), n17 && !s18.error && (s18.onEditComplete(), s18.attachmentInfos = yield l10.getAttachmentsByObjectId(e13, true)), this.refreshCellContent();
    });
  }
  zoomToSelection() {
    return __async(this, null, function* () {
      const { layer: e13, view: t3 } = this, i11 = this.highlightIds.toArray();
      if (!e13 || !t3 || !i11.length) return;
      const s18 = e13.createQuery();
      s18.objectIds = i11, s18.returnGeometry = true;
      const l10 = yield e13.queryFeatures(s18);
      try {
        yield t3.goTo(l10.features);
      } catch (o5) {
        "AbortError" !== o5.name && console.error(o5);
      }
    });
  }
  _syncAttributeTableTemplate(e13 = false) {
    const { _effectiveAttributeTableTemplate: t3, layer: i11, tableTemplateOverride: s18, syncTemplateOnChangesEnabled: l10 } = this;
    if (!i11 || !t3 || !l10 && !e13 || s18 || this.tableParent || this.relatedTable || null !== this.attachmentsViewOptions.objectId) return;
    const { activeSortOrders: o5, allColumns: n17, columns: r10 } = this, a17 = [], h8 = b4(r10.toArray());
    o5.forEach(({ fieldName: e14, direction: t4 }) => {
      e14 && t4 && a17.push({ field: e14, order: t4 });
    }), n17.forEach(({ fieldName: e14, direction: t4 }) => {
      t4 && !a17.some((t5) => t5.field === e14) && a17.push({ field: e14, order: t4 });
    }), t3.elements = h8, t3.orderByFields = a17;
  }
  _refresh() {
    return __async(this, null, function* () {
      yield this.store.refresh();
      const e13 = this.highlightIds.toArray();
      if (e13.length) {
        (yield this.store.verifyFeaturesByObjectId(e13)).forEach((t4, i11) => {
          t4 || this.highlightIds.remove(e13[i11]);
        });
      }
      this.refreshPageCache();
      const t3 = this.attachmentsViewOptions;
      null != t3?.objectId && (t3.attachmentInfos = yield this.store.getAttachmentsByObjectId(t3.objectId, true));
    });
  }
  _onLayerLoad() {
    return __async(this, null, function* () {
      const { layer: e13, pageSize: t3 } = this;
      if (!e13) return;
      e13.parent && c2(e13.parent) && (yield e13.parent.loadAll());
      const i11 = e13.capabilities.query?.maxRecordCount, s18 = i11 && i11 < t3, l10 = s18 ? i11 : t3;
      s18 && (this._logWarning("The value for 'pageSize' has been adjusted due to the provided layer's max record count."), this.pageSize = l10), this.grid?.set("pageSize", l10), this.store.load(), this._generateColumns();
    });
  }
  _onLayerRefresh(e13) {
    this.autoRefreshEnabled && e13.dataChanged && this.refresh();
  }
  _generateColumns() {
    this._drainColumns();
    const { _effectiveTableTemplate: e13, _effectiveAttributeTableTemplate: t3 } = this, i11 = e13?.columnTemplates, s18 = this._generateColumnsFromColumnTemplates(i11) ?? this._generateColumnsFromAttributeTableTemplate(t3) ?? this._generateDefaultFieldColumns();
    s18.length && (this.attachmentsEnabled && !s18.some((e14) => o2(e14)) && s18.push(this._generateDefaultAttachmentsColumn()), this.relatedRecordsEnabled && this.relationshipInfos.length && !s18.some((e14) => i6(e14)) && s18.push(...this._generateDefaultRelationshipColumns()), this.actionColumnConfig && s18.push(this._generateActionColumn()), s18.sort((e14, t4) => e14.frozen && t4.frozen || e14.frozenToEnd && t4.frozenToEnd ? 0 : e14.frozen || t4.frozenToEnd ? -1 : 0), this.columns.addMany(s18));
  }
  _generateColumnsFromAttributeTableTemplate(e13) {
    const { layer: i11 } = this;
    if (!e13 || !i11) return null;
    const { elements: s18, orderByFields: l10 } = e13, o5 = g2(i11), n17 = [];
    n17.push(...this._generateColumnsFromAttributeTableElements(s18, l10));
    const r10 = o5.map((e14) => {
      if (!e14.fieldName || g4(e14.fieldName, n17)) return null;
      const { fieldName: t3 } = e14, s19 = w3(i11, t3);
      return s19 ? this._generateDefaultFieldColumn(s19, { hidden: true, orderByFields: l10 }) : (this._logTemplateWarning("A valid 'field' could not be found for the provided template."), null);
    }).filter(G);
    return n17.push(...r10), this.attachmentsEnabled && s10(i11) && !n17.some((e14) => o2(e14)) && n17.push(this._generateDefaultAttachmentsColumn({ hidden: true })), this.relatedRecordsEnabled && p6(i11) && i11.relationships?.forEach(({ id: e14 }, t3) => {
      const i12 = this.relationshipInfos.find((t4) => t4.relationshipId === e14);
      i12 && !n17.some((t4) => i6(t4) && t4.relationshipId === e14) && n17.push(this._generateDefaultRelationshipColumn({ hidden: true, info: i12, index: t3 }));
    }), n17.length ? n17 : null;
  }
  _generateColumnsFromAttributeTableElements(e13, t3) {
    const { layer: i11 } = this;
    return i11 ? e13?.map((e14, i12) => {
      switch (e14.type) {
        case "field":
          return this._createFieldColumnFromElement({ element: e14, orderByFields: t3 });
        case "group":
          return this._createGroupColumnFromElement({ element: e14, orderByFields: t3 });
        case "attachment":
          return this._createAttachmentColumnFromElement({ element: e14, index: i12 });
        case "relationship":
          return this._createRelationshipColumnFromElement({ element: e14, index: i12 });
      }
    }).filter((e14) => !!e14) ?? [] : [];
  }
  _createFieldColumnFromElement(e13) {
    const { layer: t3 } = this;
    if (!t3) return null;
    const { element: i11, orderByFields: s18 } = e13, { fieldName: l10 } = i11;
    if (null == l10) return this._logTemplateWarning("A valid 'fieldName' must be provided."), null;
    const o5 = w3(t3, l10);
    if (!o5) return this._logTemplateWarning("A valid 'field' could not be found for the provided template."), null;
    const { description: n17, label: r10 } = i11, a17 = s18?.findIndex(({ field: e14 }) => e14 && e14 === l10) ?? -1, h8 = a17 > -1 ? s18?.at(a17)?.order : void 0, d6 = a17 > -1 ? a17 : void 0, { editingEnabled: m8, grid: c13, messages: p14, messagesCommon: g6, messagesURIUtils: u5, store: b5, timeZone: f7, view: y5 } = this;
    return new B2({ description: n17, direction: h8, field: o5, fieldName: l10, grid: c13, initialSortPriority: d6, label: r10, layer: t3, messages: p14, messagesCommon: g6, messagesURIUtils: u5, store: b5, tableEditingEnabled: m8, tableTimeZone: f7, view: y5, onShowPromptCallback: this._onShowPromptCallback });
  }
  _createGroupColumnFromElement(e13) {
    const { element: t3, orderByFields: i11 } = e13, { description: s18, label: l10 } = t3;
    if (!l10) return this._logTemplateWarning("Group columns require a label."), null;
    if (!t3.elements.length) return this._logTemplateWarning("Group columns require child columns."), null;
    const { grid: o5, messages: n17, messagesCommon: r10, messagesURIUtils: a17, store: h8, timeZone: d6 } = this;
    return new i8({ columns: this._generateColumnsFromAttributeTableElements(t3.elements, i11), description: s18, grid: o5, label: l10, messages: n17, messagesCommon: r10, messagesURIUtils: a17, store: h8, tableTimeZone: d6 });
  }
  _createAttachmentColumnFromElement(e13) {
    if (!this.attachmentsEnabled) return void this._logTemplateWarning("The 'attachmentsEnabled' property is currently false.");
    const { element: t3, index: i11 } = e13, { description: s18, label: l10 } = t3, { grid: o5, layer: n17, messages: r10, messagesCommon: a17, messagesURIUtils: h8, store: d6, timeZone: m8 } = this;
    return new u3({ description: s18, fieldName: `${n12.attachments}-${i11}`, grid: o5, label: l10, layer: n17, messages: r10, messagesCommon: a17, messagesURIUtils: h8, store: d6, tableTimeZone: m8, onShowAttachments: (e14) => this._onShowAttachments(e14) });
  }
  _createRelationshipColumnFromElement(e13) {
    if (!this.relatedRecordsEnabled) return void this._logTemplateWarning("Relationship columns require related records to be enabled on the table.");
    const { element: t3, index: i11 } = e13, { description: s18, label: l10, relationshipId: o5 } = t3, n17 = this.relationshipInfos.find((e14) => e14.relationshipId === o5);
    if (!n17) return this._logTemplateWarning("Unable to find valid related layer target based on the provided relationship id."), null;
    const { grid: r10, messages: a17, messagesCommon: h8, messagesURIUtils: d6, store: m8, timeZone: c13 } = this;
    return new c11({ description: s18, fieldName: `${n12.relationship}-${o5}-${i11}`, grid: r10, label: l10, messages: a17, messagesCommon: h8, messagesURIUtils: d6, relationshipId: o5, store: m8, tableTimeZone: c13, layer: n17.relatedLayer, relatedLayer: n17.layer, showRelatedTableCallback: (e14) => this._onShowRelatedTable(e14) });
  }
  _generateColumnsFromColumnTemplates(e13) {
    const { editingEnabled: t3, grid: i11, layer: s18, messages: l10, messagesCommon: o5, messagesURIUtils: n17, store: r10, timeZone: a17, view: h8 } = this;
    if (!e13?.length || !s18) return null;
    const d6 = [];
    return e13.forEach((e14, m8) => {
      const { autoWidth: c13, description: p14, direction: g6, flexGrow: u5, fieldName: b5, formatFunction: f7, frozen: y5, frozenToEnd: T5, icon: _2, iconText: w5, initialSortPriority: C5, invalid: I2, label: v3, menuConfig: E2, resizable: A4, sortable: F, textAlign: j4, textWrap: S3, timeZone: R2, type: U3, width: V3 } = e14;
      if (!U3) return void this._logTemplateWarning("Property 'type' is missing from the provided template.");
      if (y5 && T5) return void this._logTemplateWarning("Properties 'frozen' and 'frozenToEnd' cannot both be true for the same column.");
      const P3 = false === e14.visible;
      if ("group" === U3) {
        if (!e14.columnTemplates?.length) return void this._logTemplateWarning("Group columns must contain column templates.");
        if (!e14.label) return void this._logTemplateWarning("Group columns require a label.");
        const t4 = this._generateColumnsFromColumnTemplates(e14.columnTemplates), s19 = P3 || this._isFieldHidden(e14.label);
        d6.push(new i8({ autoWidth: c13, columns: t4, description: p14, flexGrow: u5, frozen: y5, frozenToEnd: T5, grid: i11, hidden: s19, icon: _2, iconText: w5, invalid: I2, label: v3, menuConfig: E2, messages: l10, messagesCommon: o5, messagesURIUtils: n17, resizable: A4, tableTimeZone: a17, textAlign: j4, textWrap: S3, timeZone: R2, width: V3 }));
      } else if ("attachment" === U3) {
        if (!this.attachmentsEnabled) return void this._logTemplateWarning("Attachment columns require attachments to be enabled on the table.");
        d6.push(this._generateAttachmentsColumnFromTemplate(e14, m8));
      } else if ("relationship" === U3) {
        if (!this.relatedRecordsEnabled) return void this._logTemplateWarning("Relationship columns require related records to be enabled on the table.");
        const { relationshipId: t4 } = e14;
        if (null == t4) return void this._logTemplateWarning("Property 'relationshipId' is missing from the provided template.");
        const i12 = this.relationshipInfos.find((e15) => e15.relationshipId === t4);
        if (!i12) return void this._logTemplateWarning("Unable to find valid related layer target based on the provided relationship id.");
        d6.push(this._generateRelationshipColumnFromTemplate(i12, e14, m8));
      } else if (!b5) return void this._logTemplateWarning("Value for 'fieldName' property was missing from the provided template.");
      const z3 = P3 || this._isFieldHidden(b5);
      if ("column" === U3) d6.push(new m4({ autoWidth: c13, description: p14, direction: g6, fieldName: b5, flexGrow: u5, formatFunction: f7, frozen: y5, frozenToEnd: T5, grid: i11, hidden: z3, icon: _2, iconText: w5, initialSortPriority: C5, invalid: I2, label: v3, menuConfig: E2, messages: l10, messagesCommon: o5, messagesURIUtils: n17, resizable: A4, sortable: F, tableTimeZone: a17, textAlign: j4, textWrap: S3, timeZone: R2, width: V3 }));
      else if ("field" === U3) {
        const m9 = w3(s18, e14.fieldName);
        if (!m9) return void this._logTemplateWarning("A valid 'field' could not be found for the provided template.");
        const { editable: b6, required: U4 } = e14;
        d6.push(new B2({ autoWidth: c13, description: p14, direction: g6, editable: b6, field: m9, fieldName: m9.name, flexGrow: u5, formatFunction: f7, frozen: y5, frozenToEnd: T5, grid: i11, hidden: z3, icon: _2, iconText: w5, initialSortPriority: C5, invalid: I2, label: v3, layer: s18, messages: l10, messagesCommon: o5, messagesURIUtils: n17, menuConfig: E2, required: U4, resizable: A4, sortable: F, store: r10, tableEditingEnabled: t3, tableTimeZone: a17, template: e14, textAlign: j4, textWrap: S3, timeZone: R2, width: V3, view: h8, onShowPromptCallback: this._onShowPromptCallback }));
      }
    }), d6.length ? d6 : null;
  }
  _generateDefaultFieldColumns() {
    return this.layer?.fields?.map((e13) => this._generateDefaultFieldColumn(e13)).filter(G) ?? [];
  }
  _generateDefaultFieldColumn(e13, t3) {
    const { editingEnabled: i11, grid: s18, layer: l10, messages: o5, messagesCommon: n17, messagesURIUtils: r10, store: a17, timeZone: h8, view: d6 } = this, m8 = t3?.orderByFields;
    if (!e13.visible || "geometry" === e13.type) return null;
    const c13 = e13.name, p14 = m8?.findIndex(({ field: e14 }) => e14 && e14 === c13) ?? -1, g6 = p14 > -1 ? m8?.at(p14)?.order : void 0, u5 = p14 > -1 ? p14 : void 0;
    return new B2({ direction: g6, field: e13, fieldName: c13, grid: s18, hidden: t3?.hidden || this._isFieldHidden(c13), initialSortPriority: u5, layer: l10, messages: o5, messagesCommon: n17, messagesURIUtils: r10, store: a17, tableEditingEnabled: i11, tableTimeZone: h8, view: d6, onShowPromptCallback: this._onShowPromptCallback });
  }
  _generateAttachmentsColumnFromTemplate(e13, t3) {
    const { grid: i11, layer: s18, messages: l10, messagesCommon: o5, messagesURIUtils: n17, store: r10, timeZone: a17 } = this, { attachmentsViewEnabled: h8, autoWidth: d6, description: m8, flexGrow: c13, fieldName: p14, formatFunction: g6, frozen: u5, frozenToEnd: b5, icon: f7, iconText: y5, invalid: T5, label: _2, menuConfig: w5, resizable: C5, textAlign: I2, textWrap: v3, thumbnailAppearance: E2, thumbnailCount: A4, thumbnailIconScale: F, thumbnailsEnabled: j4, timeZone: S3, width: x2 } = e13;
    return new u3({ attachmentsViewEnabled: h8, autoWidth: d6, description: m8, fieldName: `${n12.attachments}-${t3}`, flexGrow: c13, formatFunction: g6, frozen: u5, frozenToEnd: b5, grid: i11, hidden: false === e13.visible || this._isFieldHidden(_2) || this._isFieldHidden(p14), icon: f7, iconText: y5, invalid: T5, label: _2, layer: s18, menuConfig: w5, messages: l10, messagesCommon: o5, messagesURIUtils: n17, resizable: C5, store: r10, tableTimeZone: a17, textAlign: I2, textWrap: v3, thumbnailAppearance: E2, thumbnailCount: A4, thumbnailIconScale: F, thumbnailsEnabled: j4, timeZone: S3, width: x2, onShowAttachments: (e14) => this._onShowAttachments(e14) });
  }
  _generateDefaultAttachmentsColumn(e13) {
    const { grid: t3, layer: i11, messages: s18, messagesCommon: l10, messagesURIUtils: o5, store: n17, timeZone: r10 } = this, a17 = n12.attachments;
    return new u3({ fieldName: a17, grid: t3, hidden: e13?.hidden || this._isFieldHidden(a17), layer: i11, messages: s18, messagesCommon: l10, messagesURIUtils: o5, store: n17, tableTimeZone: r10, onShowAttachments: (e14) => this._onShowAttachments(e14) });
  }
  _generateRelationshipColumnFromTemplate(e13, t3, i11) {
    const { grid: s18, messages: l10, messagesCommon: o5, messagesURIUtils: n17, store: r10, timeZone: a17 } = this, { autoWidth: h8, collapsed: d6, description: m8, flexGrow: c13, fieldName: p14, formatFunction: g6, frozen: u5, frozenToEnd: b5, icon: f7, iconText: y5, invalid: T5, label: _2, menuConfig: w5, relationshipId: C5, resizable: I2, textAlign: v3, textWrap: E2, timeZone: A4, width: F } = t3;
    return new c11({ autoWidth: h8, collapsed: d6, description: m8, fieldName: `${n12.relationship}-${C5}-${i11}`, flexGrow: c13, formatFunction: g6, frozen: u5, frozenToEnd: b5, grid: s18, hidden: false === t3.visible || this._isFieldHidden(_2) || this._isFieldHidden(p14), icon: f7, iconText: y5, invalid: T5, label: _2, menuConfig: w5, messages: l10, messagesCommon: o5, messagesURIUtils: n17, relationshipId: C5, resizable: I2, store: r10, tableTimeZone: a17, textAlign: v3, textWrap: E2, timeZone: A4, width: F, layer: e13.relatedLayer, relatedLayer: e13.layer, showRelatedTableCallback: (e14) => this._onShowRelatedTable(e14) });
  }
  _generateDefaultRelationshipColumns() {
    const { relationshipInfos: e13, relationshipColumnConfigs: t3 } = this, i11 = [];
    return e13?.length ? (t3 ? t3.forEach((t4, s18) => {
      const { relationshipId: l10 } = t4, o5 = e13.find((e14) => e14.relationshipId === l10);
      o5 && i11.push(this._generateDefaultRelationshipColumn({ config: t4, index: s18, info: o5 }));
    }) : e13.forEach((e14, t4) => i11.push(this._generateDefaultRelationshipColumn({ index: t4, info: e14 }))), i11) : i11;
  }
  _generateDefaultRelationshipColumn(e13) {
    const { config: t3, hidden: i11, index: s18, info: l10 } = e13, { grid: o5, messages: n17, messagesCommon: r10, messagesURIUtils: a17 } = this, { relationshipId: h8 } = l10;
    return new c11(__spreadProps(__spreadValues({}, t3), { fieldName: `${n12.relationship}-${h8}-${s18}`, grid: o5, hidden: i11, messages: n17, messagesCommon: r10, messagesURIUtils: a17, layer: l10.relatedLayer, relatedLayer: l10.layer, relationshipId: h8, showRelatedTableCallback: (e14) => this._onShowRelatedTable(e14) }));
  }
  _generateActionColumn() {
    return new d5(__spreadValues({ hidden: this._isFieldHidden(n12.action) }, this.actionColumnConfig));
  }
  _isFieldHidden(e13) {
    const t3 = e13?.toLowerCase();
    return (this.hiddenFields ?? this._defaultHiddenFields).some((e14) => e14.toLowerCase() === t3);
  }
  _addTableHighlight(e13) {
    if (!this.highlightEnabled) return;
    const { _highlightableLayerView: t3, layer: i11 } = this;
    if (t3 && i11) {
      const s18 = this.store.getItemByObjectId(e13), l10 = s18?.feature ?? e13;
      this._highlights.add(t3.highlight(l10, { name: c5 }), C3(i11, e13));
    }
  }
  _removeTableHighlight(e13) {
    const { layer: t3 } = this;
    t3 && this._highlights.remove(C3(t3, e13));
  }
  _syncTemporaryHighlight(e13, t3) {
    return __async(this, null, function* () {
      if (!this.highlightEnabled) return this._currentTemporaryHighlight?.handle.remove(), void (this._currentTemporaryHighlight = null);
      if (yield A(25), s3(t3), !this._currentTemporaryHighlight && !e13) return;
      const { id: i11 } = this._currentTemporaryHighlight ?? {};
      if (i11 === e13) return;
      this._currentTemporaryHighlight?.handle?.remove(), this._currentTemporaryHighlight = null;
      const { _highlightableLayerView: s18, layer: l10, highlightEnabled: o5 } = this;
      e13 && s18 && l10 && o5 && (this._currentTemporaryHighlight = { id: e13, handle: s18.highlight(e13, { name: m2 }) });
    });
  }
  _syncSelection() {
    this._highlights.removeAll(), this._tableHighlightsReady ? this.highlightIds.forEach((e13) => this._addTableHighlight(e13)) : this._viewSelectionReady && (this.highlightIds.items = this._viewSelection);
  }
  _appendToViewSelection(e13) {
    const { _selectableLayer: t3 } = this;
    t3 && this._selectionManager?.appendToSelection(t3, e13);
  }
  _removeFromViewSelection(e13) {
    const { _selectableLayer: t3 } = this;
    t3 && this._selectionManager?.removeFromSelection(t3, e13);
  }
  _onHighlightIdsChange(e13) {
    return __async(this, null, function* () {
      const { added: t3, removed: i11 } = e13, { attachmentsViewOptions: s18 } = this;
      if (this._tableHighlightsReady ? (i11.forEach((e14) => this._removeTableHighlight(e14)), t3.forEach((e14) => this._addTableHighlight(e14))) : this._viewSelectionReady && (this._removeFromViewSelection(i11), this._appendToViewSelection(t3)), this.filterBySelectionEnabled && this._syncObjectIdsWithStore(this.highlightIds.toArray()), null != s18.objectId) {
        const e14 = this.highlightIds.at(0);
        if (null != e14) {
          const t4 = yield this.store.getAttachmentsByObjectId(e14, true);
          s18.set({ attachmentInfos: t4, objectId: e14, mode: t4.length ? "list" : "file" });
        }
      }
    });
  }
  _onShowRelatedTable(e13) {
    const { highlightIds: t3 } = this, { objectId: i11 } = e13;
    t3.removeAll(), t3.add(i11), this.showRelatedTableCallback ? this.showRelatedTableCallback(e13) : this.emit("show-related-table", e13);
  }
  _onObjectIdsChange() {
    const e13 = this.objectIds.toArray();
    e13.length && this.filterBySelectionEnabled && (this.filterBySelectionEnabled = false, this._logWarning("Object ID filter was applied while a selection filter was applied. Selection filter has been removed.")), this._syncObjectIdsWithStore(e13);
  }
  _syncObjectIdsWithStore(e13) {
    this.store.objectIds = e13, this.refreshPageCache();
  }
  _drainColumns() {
    this.columns.drain((e13) => !e13.destroyed && e13.destroy());
  }
  _showAllRelatedTables(e13) {
    const t3 = e13.layer;
    if (!t3) return;
    const i11 = this._getDefaultLayerDisplayField(t3);
    e13.set({ relationshipColumnConfigs: [], tableTemplateOverride: this._getTableTemplateForShowAllTablesView(e13, i11) });
    const s18 = e13.hiddenFields;
    s18.includes(n12.action) || s18.add(n12.action), s18.includes(n12.attachments) || s18.add(n12.attachments);
  }
  _hideAllRelatedTables(e13) {
    const { layer: t3, relationship: i11 } = e13;
    if (t3 && null != i11?.id) if (null != e13.attachmentsViewOptions.objectId) {
      const i12 = this._getDefaultLayerDisplayField(t3);
      e13.set({ multipleSelectionEnabled: false, relationshipColumnConfigs: [], showAllRelatedTables: false, tableTemplateOverride: this._getTableTemplateForAttachmentsView(i12) });
    } else e13.set({ multipleSelectionEnabled: true, relationshipColumnConfigs: b3(t3, i11.id), showAllRelatedTables: false, tableTemplateOverride: null }), e13.hiddenFields.removeMany([n12.action, n12.attachments]);
  }
  _getTableTemplateForRelatedTableView(e13, t3, i11) {
    return new h6({ columnTemplates: [new l9({ fieldName: t3, editable: false, menuConfig: { selectionMode: "single", icon: "chevron-down", items: this._extractFieldColumnInfosFromTableTemplate(e13.viewModel).map(([s18, l10]) => ({ selected: s18 === t3, label: l10 || s18, clickFunction: () => {
      e13.tableTemplateOverride = this._getTableTemplateForRelatedTableView(e13, s18, i11);
    } })) }, resizable: false }), new p11({ autoWidth: false, collapsed: true, flexGrow: 0, label: "", resizable: false, relationshipId: i11, width: re })] });
  }
  _getTableTemplateForShowAllTablesView(e13, t3) {
    const i11 = [new l9({ fieldName: t3, editable: false, menuConfig: { selectionMode: "single", icon: "chevron-down", items: this._extractFieldColumnInfosFromTableTemplate(e13.viewModel).map(([i12, s18]) => ({ selected: i12 === t3, label: s18 || i12, clickFunction: () => {
      e13.tableTemplateOverride = this._getTableTemplateForShowAllTablesView(e13, i12);
    } })) }, resizable: false })];
    return null != e13.attachmentsViewOptions.objectId && i11.push(new a13({ attachmentsViewEnabled: false, autoWidth: false, flexGrow: 0, label: "", resizable: false, thumbnailsEnabled: false, width: re })), new h6({ columnTemplates: i11 });
  }
  _onShowPromptCallback(e13) {
    return __async(this, null, function* () {
      const { column: t3, objectId: i11, oldValue: s18, value: l10 } = e13, { _subtypes: o5, layer: n17 } = this;
      if (!n17 || !o5.length) return void t3.cancel();
      const r10 = o5.find((e14) => e14.code === l10);
      if (!r10) return void t3.cancel();
      const a17 = L(), h8 = this._createSubtypeEditPrompt(s18, r10, a17), d6 = !!n17.parent;
      try {
        this.showPrompt(h8);
        const e14 = yield a17.promise, s19 = [{ fieldName: t3.fieldName, value: l10 }];
        switch (e14) {
          case "update-fields":
            for (const [e15, t4] of Object.entries(r10.defaultValues)) null != t4 && s19.push({ fieldName: e15, value: t4 });
            yield t3.updateItems({ objectId: i11, updates: s19 }), d6 && this.refresh();
            break;
          case "keep-existing":
            yield t3.updateItems({ objectId: i11, updates: s19 }), d6 && this.refresh();
            break;
          case "undo":
            t3.cancel();
        }
      } finally {
        this.clearPrompt();
      }
    });
  }
  _createSubtypeEditPrompt(e13, t3, i11) {
    const { _subtypes: s18, messages: l10, messagesCommon: o5 } = this, n17 = s18.find((t4) => t4.code === e13)?.name ?? `${e13}`;
    let r10 = "update-fields";
    const a17 = [{ label: l10.subtypes.useDefaultValuesOption, value: "update-fields" }, { label: l10.subtypes.keepCurrentValuesOption, value: "keep-existing" }];
    return { context: "info", title: l10.subtypes.changeWarningTitle, message: s4(l10.subtypes.changeWarning, { originalType: n17, newType: t3.name }), radios: a17, defaultRadioSelection: "update-fields", onRadioSelection: (e14) => {
      r10 = e14;
    }, actions: { primary: { label: o5.apply, action: () => i11.resolve(r10), type: "positive" }, secondary: { label: o5.cancel, type: "neutral", action: () => i11.resolve("undo") } }, cancel: () => i11.reject() };
  }
  _onShowAttachments({ objectId: e13 }) {
    this.attachmentsViewOptions.objectId = e13;
  }
  _getTableTemplateForAttachmentsView(e13) {
    return new h6({ columnTemplates: [new l9({ fieldName: e13, editable: false, menuConfig: { selectionMode: "single", icon: "chevron-down", items: this._extractFieldColumnInfosFromTableTemplate(this).map(([t3, i11]) => ({ selected: t3 === e13, label: i11 || t3, clickFunction: () => {
      this.tableTemplateOverride = this._getTableTemplateForAttachmentsView(t3);
    } })) }, resizable: false }), new a13({ attachmentsViewEnabled: false, autoWidth: false, flexGrow: 0, label: "", resizable: false, thumbnailsEnabled: false, width: re })] });
  }
  _extractFieldColumnInfosFromTableTemplate(e13) {
    const t3 = e13 ?? this, { layer: i11, tableTemplate: s18 } = t3;
    return s18 ? s18.columnTemplates.filter(({ type: e14 }) => "field" === e14 || "column" === e14).map(({ fieldName: e14, label: t4 }) => [e14, t4]) : i11?.fields.map((e14) => [e14.name, e14.alias]) ?? [];
  }
  _getDefaultLayerDisplayField(e13) {
    const { displayField: t3, objectIdField: i11 } = e13;
    return t3 && "" !== t3.trim() ? t3 : i11 || (e13.fields.length ? e13.fields[0].name : "");
  }
  _getIndexOfFirstFrozenToEndColumn() {
    const e13 = this.columns.findIndex((e14) => e14.frozenToEnd);
    return e13 > -1 ? e13 : void 0;
  }
  _logWarning(e13, t3) {
    t3 ? n.getLogger(this).warnOnce(e13) : n.getLogger(this).warn(e13);
  }
  _logTemplateWarning(e13) {
    this._logWarning(`${e13} Skipped generating a column using the provided template.`, true);
  }
  _onCellInteraction(e13) {
    null != e13 && null != this.attachmentsViewOptions.objectId && this.highlightIds.add(e13);
  }
};
r([m()], ae.prototype, "_defaultHiddenFields", null), r([m()], ae.prototype, "_effectiveTableTemplate", null), r([m()], ae.prototype, "_effectiveAttributeTableTemplate", null), r([m()], ae.prototype, "_highlights", void 0), r([m()], ae.prototype, "_highlightableLayerView", null), r([m()], ae.prototype, "_selectionManager", null), r([m()], ae.prototype, "_selectableLayer", null), r([m()], ae.prototype, "_subtypes", null), r([m()], ae.prototype, "_tableHighlightsReady", null), r([m()], ae.prototype, "_viewSelection", null), r([m()], ae.prototype, "_viewSelectionReady", null), r([m()], ae.prototype, "actionColumnConfig", void 0), r([m()], ae.prototype, "allRelatedTablesVisible", null), r([m()], ae.prototype, "activeFilters", null), r([m({ readOnly: true })], ae.prototype, "activeSortOrders", null), r([m()], ae.prototype, "attachmentsEnabled", null), r([m()], ae.prototype, "attachmentsViewOptions", void 0), r([m({ type: f3 })], ae.prototype, "attributeTableTemplate", void 0), r([m()], ae.prototype, "autoRefreshEnabled", void 0), r([m()], ae.prototype, "clearPrompt", null), r([m({ readOnly: true })], ae.prototype, "columns", void 0), r([m()], ae.prototype, "dataProvider", void 0), r([m()], ae.prototype, "editingEnabled", void 0), r([m()], ae.prototype, "filterGeometry", null), r([m()], ae.prototype, "filterBySelectionEnabled", null), r([m({ readOnly: true })], ae.prototype, "grid", void 0), r([m()], ae.prototype, "hiddenFields", null), r([m()], ae.prototype, "highlightEnabled", void 0), r([m()], ae.prototype, "initialSize", null), r([m()], ae.prototype, "isQueryingOrSyncing", null), r([m()], ae.prototype, "isSyncingAttachments", null), r([m({ readOnly: true })], ae.prototype, "itemIdPath", void 0), r([m()], ae.prototype, "layer", null), r([m()], ae.prototype, "layers", void 0), r([m()], ae.prototype, "layerView", null), r([m()], ae.prototype, "messages", void 0), r([m(), e3("esri/t9n/common")], ae.prototype, "messagesCommon", void 0), r([m(), e3("esri/core/t9n/Units")], ae.prototype, "messagesUnits", void 0), r([m(), e3("esri/widgets/support/t9n/uriUtils")], ae.prototype, "messagesURIUtils", void 0), r([m()], ae.prototype, "outFields", null), r([m()], ae.prototype, "prompt", void 0), r([m()], ae.prototype, "relatedRecordsEnabled", null), r([m()], ae.prototype, "relatedTable", null), r([m()], ae.prototype, "relatedTables", void 0), r([m()], ae.prototype, "relationship", null), r([m()], ae.prototype, "relationshipColumnConfigs", void 0), r([m()], ae.prototype, "relationshipConfig", null), r([m()], ae.prototype, "relationshipInfos", null), r([m()], ae.prototype, "relationships", null), r([m()], ae.prototype, "returnGeometryEnabled", null), r([m()], ae.prototype, "returnMEnabled", null), r([m()], ae.prototype, "returnZEnabled", null), r([m()], ae.prototype, "selectionSource", void 0), r([m()], ae.prototype, "showAllRelatedTables", null), r([m()], ae.prototype, "showPrompt", null), r([m()], ae.prototype, "showRelatedTableCallback", void 0), r([m({ readOnly: true, type: w4 })], ae.prototype, "store", void 0), r([m()], ae.prototype, "supportsAttachments", null), r([m()], ae.prototype, "supportsAddAttachments", null), r([m()], ae.prototype, "supportsDeleteAttachments", null), r([m()], ae.prototype, "supportsResizeAttachments", null), r([m()], ae.prototype, "supportsUpdateAttachments", null), r([m()], ae.prototype, "syncTemplateOnChangesEnabled", void 0), r([m()], ae.prototype, "tableController", void 0), r([m()], ae.prototype, "tableParent", void 0), r([m({ type: h6 })], ae.prototype, "tableTemplate", void 0), r([m()], ae.prototype, "tableTemplateOverride", void 0), r([m()], ae.prototype, "timeExtent", null), r([m()], ae.prototype, "timeZone", null), r([m()], ae.prototype, "view", null), ae = r([a2("esri.widgets.FeatureTable.FeatureTableViewModel")], ae);
var he = ae;

// node_modules/@arcgis/core/widgets/FeatureTable/TableMenuVisibleElements.js
var r8 = class extends g {
  constructor(e13) {
    super(e13), this.clearSelection = true, this.deleteSelection = true, this.exportSelectionToCSV = true, this.refreshData = true, this.selectedRecordsShowAllToggle = true, this.selectedRecordsShowSelectedToggle = true, this.toggleColumns = true, this.zoomToSelection = true;
  }
};
r([m({ type: Boolean, nonNullable: true })], r8.prototype, "clearSelection", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "deleteSelection", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "exportSelectionToCSV", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "refreshData", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "selectedRecordsShowAllToggle", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "selectedRecordsShowSelectedToggle", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "toggleColumns", void 0), r([m({ type: Boolean, nonNullable: true })], r8.prototype, "zoomToSelection", void 0), r8 = r([a2("esri.widgets.FeatureTable.TableMenuVisibleElements")], r8);
var s17 = r8;

// node_modules/@arcgis/core/widgets/FeatureTable/VisibleElements.js
var r9 = class extends g {
  constructor(o5) {
    super(o5), this.columnDescriptions = true, this.columnMenus = true, this.columnMenuItems = new c8(), this.close = false, this.header = true, this.layerDropdown = false, this.layerDropdownIcons = true, this.menu = true, this.menuItems = new s17(), this.progress = true, this.selectionColumn = true, this.tooltips = true;
  }
};
r([m({ type: Boolean, nonNullable: true })], r9.prototype, "columnDescriptions", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "columnMenus", void 0), r([m({ type: c8, nonNullable: true })], r9.prototype, "columnMenuItems", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "close", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "header", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "layerDropdown", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "layerDropdownIcons", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "menu", void 0), r([m({ type: s17, nonNullable: true })], r9.prototype, "menuItems", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "progress", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "selectionColumn", void 0), r([m({ type: Boolean, nonNullable: true })], r9.prototype, "tooltips", void 0), r9 = r([a2("esri.widgets.FeatureTable.VisibleElements")], r9);
var p13 = r9;

// node_modules/@arcgis/core/widgets/FeatureTable.js
var j3;
var O4 = "esri-feature-table";
var z2 = `${O4}__prompt`;
var $3 = `${O4}__attachments-view`;
var U2 = { base: O4, content: `${O4}__content`, menuPopover: `${O4}__menu-popover`, layerDropdownMenu: `${O4}__layer-switcher-menu`, tableContainer: `${O4}__table-container`, tableContainerWithAttachments: `${O4}__table-container--attachments`, tableNavigation: `${O4}__table-navigation`, attachmentsView: $3, attachmentsViewContent: `${$3}__content`, attachmentsViewDropArea: `${$3}__drop-area`, attachmentsViewIcon: `${$3}__icon`, attachmentsViewInformation: `${$3}__information`, attachmentsViewList: `${$3}__list`, attachmentsViewListFileSize: `${$3}__list__filesize`, attachmentsViewListItemDelete: `${$3}__list-item--delete`, attachmentsViewListThumbnail: `${$3}__list__thumbnail`, expanded: `${O4}__expanded`, collapsed: `${O4}__collapsed`, promptContainer: z2, promptHeader: `${z2}__header`, promptHeading: `${z2}__header__heading`, promptMessage: `${z2}__message`, promptDivider: `${z2}__divider`, promptActions: `${z2}__actions` };
var B3 = { attachment: "attachment", chevronDown: "chevron-down", chevronLeft: "chevron-left", chevronRight: "chevron-right", clearSelection: "clear-selection", downloadTo: "download-to", exclamationMarkTriangle: "exclamation-mark-triangle", exportToCSV: "file-csv", folderOpen: "folder-open", delete: "trash", launch: "launch", layers: "layers", moveUp: "move-up", plus: "plus", refresh: "refresh", replaceImage: "replace-image", save: "save", showAll: "selection-x", showColumn: "show-column", showSelected: "selection-filter", upload: "upload", zoomToSelection: "zoom-to-object" };
var H3 = j3 = class extends O {
  constructor(e13, t3) {
    super(e13, t3), this._attachmentsInput = null, this._columnVisibilityActions = /* @__PURE__ */ new Map(), this.attachmentsList = null, this.description = null, this.disabled = false, this.menuConfig = null, this.title = null, this.viewModel = new he(), this.visibleElements = new p13(), this._showDeletePrompt = this._showDeletePrompt.bind(this), this._onDeleteSelectionClick = this._onDeleteSelectionClick.bind(this);
  }
  initialize() {
    this.addHandles([d2(() => [this.viewModel.store.querying, this.viewModel.store.syncing, this.editingEnabled], () => this.scheduleRender()), d2(() => [this._effectiveVisibleElements, this._effectiveVisibleElements.columnDescriptions, this._effectiveVisibleElements.columnMenus, this._effectiveVisibleElements.columnMenuItems, this.columns.length], () => {
      this.columns.forEach((e13) => e13.visibleElements = this._effectiveVisibleElements), this.refreshCellContent();
    }, C), d2(() => this._effectiveVisibleElements.selectionColumn, (e13) => {
      this.grid && (this.grid.selectionColumnEnabled = e13);
    }, P), v(() => this.viewModel, "show-related-table", (e13) => this._onShowRelatedTable(e13)), d2(() => this.editingEnabled, () => {
      const { attachmentsViewOptions: e13 } = this;
      this.clearPrompt(), e13 && (e13.form?.reset(), e13.candidates = null);
    })]);
  }
  loadDependencies() {
    return Promise.all([c({ action: () => import("./calcite-action-QPIDLQ7A.js"), alert: () => import("./calcite-alert-QWNFTEXL.js"), button: () => import("./calcite-button-FV2OB3GT.js"), chip: () => import("./calcite-chip-ECXAKG34.js"), dropdown: () => import("./calcite-dropdown-G3BRMDWP.js"), "dropdown-group": () => import("./calcite-dropdown-group-KHQP6LCC.js"), "dropdown-item": () => import("./calcite-dropdown-item-TAJST3BD.js"), icon: () => import("./calcite-icon-TH7JL242.js"), label: () => import("./calcite-label-MCJS3SWR.js"), list: () => import("./calcite-list-W42EHRHD.js"), "list-item": () => import("./calcite-list-item-6HCBKBPX.js"), pagination: () => import("./calcite-pagination-XUZUEY5A.js"), panel: () => import("./calcite-panel-BL4CNSS2.js"), popover: () => import("./calcite-popover-62MC4LJC.js"), progress: () => import("./calcite-progress-2CENXOS7.js"), switch: () => import("./calcite-switch-V7ZMWM3Q.js"), tooltip: () => import("./calcite-tooltip-ZEJ36TWO.js") }), s9(), r4()]);
  }
  destroy() {
    this.drainRelatedTables(), this.clearPrompt();
  }
  get _effectiveDescription() {
    const { description: e13 } = this;
    return null != e13 ? A2.sanitize("function" == typeof e13 ? e13() : e13) : void 0;
  }
  get _effectiveLayers() {
    const { layer: e13, layers: t3 } = this, i11 = t3?.length ? t3.filter(c9) : [], l10 = i11.length ? i11 : [...this._viewLayers];
    return e13 && !l10.includes(e13) && l10.push(e13), l10;
  }
  get _effectiveTitle() {
    const { layer: e13, messages: t3, state: i11, highlightIds: l10, title: o5, size: n17 } = this;
    if (o5) return A2.sanitize("function" == typeof o5 ? o5() : o5);
    if (!e13) return t3.noLayer;
    switch (i11) {
      case "disabled":
        return t3.errorLayer;
      case "ready":
      case "loading":
        return t3.loading;
      case "error":
        return t3.errorData;
    }
    return s4(t3.header, { title: A2.sanitize(e13.title), count: n17, selected: l10.length });
  }
  get _effectiveVisibleElements() {
    return this.visibleElementsOverride ?? this.visibleElements;
  }
  get _filteredTables() {
    const e13 = this.relatedTables.toArray(), t3 = 1 === e13.length;
    return this.allRelatedTablesVisible ? e13 : t3 ? [e13[0]] : this._shouldShowAttachmentsView ? e13.slice(-1) : e13.slice(-2);
  }
  get _hasAttachmentsViewError() {
    return null != this.attachmentsViewOptions.error;
  }
  get _hasCustomMenuItems() {
    return !!this.menuConfig?.items?.length;
  }
  get _hasDefaultMenuItems() {
    return !!(this._showClearSelectionAction || this._showDeleteSelectionAction || this._showExportSelectionToCSVAction || this._showRefreshDataAction || this._showZoomToSelectionAction || this._showSelectedRecordsShowSelectedAction || this._showSelectedRecordsShowAllAction || this._showColumnsVisibilityAction);
  }
  get _shouldShowGrid() {
    return this.allRelatedTablesVisible || 1 === this.relatedTables.length && !this._shouldShowAttachmentsView;
  }
  get _shouldShowMenu() {
    const { header: e13, menu: t3 } = this._effectiveVisibleElements;
    return !(!e13 || !t3 || !this._hasDefaultMenuItems && !this._hasCustomMenuItems);
  }
  get _shouldShowAttachmentsView() {
    return !(null == this.attachmentsViewOptions.objectId && !this.relatedTables.some((e13) => null != e13.attachmentsViewOptions.objectId));
  }
  get _showClearSelectionAction() {
    return !(!this.highlightIds.length || !this._effectiveVisibleElements.menuItems?.clearSelection || this.relatedTables.length);
  }
  get _showColumnsVisibilityAction() {
    const { header: e13, menu: t3, menuItems: i11 } = this._effectiveVisibleElements;
    return !(!(e13 && t3 && i11?.toggleColumns) || this.showRelatedTableCallback || this.allRelatedTablesVisible || this._shouldShowAttachmentsView);
  }
  get _showDeleteSelectionAction() {
    return !(!(this.editingEnabled && this.highlightIds.length && this._effectiveVisibleElements.menuItems?.deleteSelection && this.layer?.capabilities?.operations?.supportsDelete) || this.relatedTables.length);
  }
  get _showExportSelectionToCSVAction() {
    return !(!(this._effectiveVisibleElements.menuItems.exportSelectionToCSV && this.layer && this.highlightIds.length) || this.relatedTables.length);
  }
  get _showLayerDropdown() {
    return !(!this._effectiveLayers.length || !this._effectiveVisibleElements.layerDropdown);
  }
  get _shouldShowNavigationBar() {
    const e13 = !!this.relatedTable || this._shouldShowAttachmentsView;
    return !this.tableParent && e13;
  }
  get _showRefreshDataAction() {
    return !!this._effectiveVisibleElements.menuItems?.refreshData;
  }
  get _showSelectedRecordsShowSelectedAction() {
    const e13 = this.objectIds.length, t3 = this.highlightIds.length;
    return !(!t3 || !this._effectiveVisibleElements.menuItems?.selectedRecordsShowSelectedToggle || e13 && t3 === e13 || this.relatedTables.length);
  }
  get _showSelectedRecordsShowAllAction() {
    return !(!this._effectiveVisibleElements.menuItems?.selectedRecordsShowAllToggle || !this.objectIds.length || this.relatedTables.length);
  }
  get _showZoomToSelectionAction() {
    return !(!this.view || !this.highlightIds.length || this.effectiveTable.layer?.isTable || !this._effectiveVisibleElements.menuItems?.zoomToSelection);
  }
  get _viewLayers() {
    const e13 = this.view?.map;
    if (!e13) return [];
    const t3 = /* @__PURE__ */ new Set(), i11 = (e14) => {
      !c9(e14) || c2(e14) || t3.has(e14) || (e14.load(), t3.add(e14));
    }, l10 = (e14) => {
      a7(e14) || "catalog-footprint" === e14.type || (s7(e14) ? (e14.load(), e14.layers?.forEach(i11), e14.tables?.forEach(i11)) : u(e14) ? (e14.loadAll(), e14.sublayers?.forEach(i11), e14.subtables?.forEach(i11)) : c2(e14) ? (e14.loadAll(), e14.sublayers?.forEach(i11)) : i11(e14));
    };
    return e13.allLayers.forEach(l10), e13.allTables.forEach(l10), [...t3.values()];
  }
  get grid() {
    return this.viewModel.grid;
  }
  get actionColumnConfig() {
    return this.viewModel.actionColumnConfig;
  }
  set actionColumnConfig(e13) {
    this.viewModel.actionColumnConfig = e13;
  }
  get activeFilters() {
    return this.viewModel.activeFilters;
  }
  get activeSortOrders() {
    return this.viewModel.activeSortOrders;
  }
  get allColumns() {
    return this.viewModel.allColumns;
  }
  get allRelatedTablesVisible() {
    return this.viewModel.allRelatedTablesVisible;
  }
  get attachmentsEnabled() {
    return this.viewModel.attachmentsEnabled;
  }
  set attachmentsEnabled(e13) {
    this.viewModel.attachmentsEnabled = e13;
  }
  get attachmentsViewOptions() {
    return this.viewModel.attachmentsViewOptions;
  }
  set attachmentsViewOptions(e13) {
    this.viewModel.attachmentsViewOptions = e13;
  }
  get attributeTableTemplate() {
    return this.viewModel.attributeTableTemplate;
  }
  set attributeTableTemplate(e13) {
    this.viewModel.attributeTableTemplate = e13;
  }
  get autoRefreshEnabled() {
    return this.viewModel.autoRefreshEnabled;
  }
  set autoRefreshEnabled(e13) {
    this.viewModel.autoRefreshEnabled = e13;
  }
  get clearPrompt() {
    return this.viewModel.clearPrompt;
  }
  set clearPrompt(e13) {
    this.viewModel.clearPrompt = e13;
  }
  get columnPerformanceModeEnabled() {
    return this.viewModel.columnPerformanceModeEnabled;
  }
  set columnPerformanceModeEnabled(e13) {
    this.viewModel.columnPerformanceModeEnabled = e13;
  }
  get columnReorderingEnabled() {
    return this.viewModel.columnReorderingEnabled;
  }
  set columnReorderingEnabled(e13) {
    this.viewModel.columnReorderingEnabled = e13;
  }
  get columns() {
    return this.viewModel.columns;
  }
  get editingEnabled() {
    return this.viewModel.editingEnabled;
  }
  set editingEnabled(e13) {
    this.viewModel.editingEnabled = e13;
  }
  get effectiveSize() {
    return this.viewModel.effectiveSize;
  }
  get effectiveTable() {
    return this.relatedTable || this;
  }
  get filterGeometry() {
    return this.viewModel.filterGeometry;
  }
  set filterGeometry(e13) {
    this.viewModel.filterGeometry = e13;
  }
  get filterBySelectionEnabled() {
    return this.viewModel.filterBySelectionEnabled;
  }
  set filterBySelectionEnabled(e13) {
    this.viewModel.filterBySelectionEnabled = e13;
  }
  get hiddenFields() {
    return this.viewModel.hiddenFields;
  }
  set hiddenFields(e13) {
    this.viewModel.hiddenFields = e13;
  }
  get highlightEnabled() {
    return this.viewModel.highlightEnabled;
  }
  set highlightEnabled(e13) {
    this.viewModel.highlightEnabled = e13;
  }
  get highlightIds() {
    return this.viewModel.highlightIds;
  }
  set highlightIds(e13) {
    this.viewModel.highlightIds = e13;
  }
  get icon() {
    return "table";
  }
  set icon(e13) {
    this._overrideIfSome("icon", e13);
  }
  get initialSize() {
    return this.viewModel.initialSize;
  }
  set initialSize(e13) {
    this.viewModel.initialSize = e13;
  }
  get isQueryingOrSyncing() {
    return this.viewModel.isQueryingOrSyncing;
  }
  get isSyncingAttachments() {
    return this.viewModel.isSyncingAttachments;
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e13) {
    this._overrideIfSome("label", e13);
  }
  get layer() {
    return this.viewModel.layer;
  }
  set layer(e13) {
    this.viewModel.layer = e13;
  }
  get layers() {
    return this.viewModel.layers;
  }
  set layers(e13) {
    this.viewModel.layers = e13;
  }
  get layerView() {
    return this.viewModel.layerView;
  }
  get maxSize() {
    return this.viewModel.maxSize;
  }
  set maxSize(e13) {
    this.viewModel.maxSize = e13;
  }
  get messages() {
    return this.viewModel.messages;
  }
  set messages(e13) {
    this.viewModel.messages = e13;
  }
  get messagesCommon() {
    return this.viewModel.messagesCommon;
  }
  set messagesCommon(e13) {
    this.viewModel.messagesCommon = e13;
  }
  get messagesUnits() {
    return this.viewModel.messagesUnits;
  }
  set messagesUnits(e13) {
    this.viewModel.messagesUnits = e13;
  }
  get messagesURIUtils() {
    return this.viewModel.messagesURIUtils;
  }
  set messagesURIUtils(e13) {
    this.viewModel.messagesURIUtils = e13;
  }
  get multipleSelectionEnabled() {
    return this.viewModel.multipleSelectionEnabled;
  }
  set multipleSelectionEnabled(e13) {
    this.viewModel.multipleSelectionEnabled = e13;
  }
  get multiSortEnabled() {
    return this.viewModel.multiSortEnabled;
  }
  set multiSortEnabled(e13) {
    this.viewModel.multiSortEnabled = e13;
  }
  get objectIds() {
    return this.viewModel.objectIds;
  }
  set objectIds(e13) {
    this.viewModel.objectIds = e13;
  }
  get outFields() {
    return this.viewModel.outFields;
  }
  set outFields(e13) {
    this.viewModel.outFields = e13;
  }
  get pageCount() {
    return this.viewModel.pageCount;
  }
  get pageIndex() {
    return this.viewModel.pageIndex;
  }
  set pageIndex(e13) {
    this.viewModel.pageIndex = e13;
  }
  get pageSize() {
    return this.viewModel.pageSize;
  }
  set pageSize(e13) {
    this.viewModel.pageSize = e13;
  }
  get paginationEnabled() {
    return this.viewModel.paginationEnabled;
  }
  set paginationEnabled(e13) {
    this.viewModel.paginationEnabled = e13;
  }
  get prompt() {
    return this.viewModel.prompt;
  }
  set prompt(e13) {
    this.viewModel.prompt = e13;
  }
  get relatedRecordsEnabled() {
    return this.viewModel.relatedRecordsEnabled;
  }
  set relatedRecordsEnabled(e13) {
    this.viewModel.relatedRecordsEnabled = e13;
  }
  get relatedTable() {
    return this.viewModel.relatedTable;
  }
  get relatedTables() {
    return this.viewModel.relatedTables;
  }
  set relatedTables(e13) {
    this.viewModel.relatedTables = e13;
  }
  get relationship() {
    return this.viewModel.relationship;
  }
  get relationshipColumnConfigs() {
    return this.viewModel.relationshipColumnConfigs;
  }
  set relationshipColumnConfigs(e13) {
    this.viewModel.relationshipColumnConfigs = e13;
  }
  get relationshipConfig() {
    return this.viewModel.relationshipConfig;
  }
  set relationshipConfig(e13) {
    this.viewModel.relationshipConfig = e13;
  }
  get relationshipInfos() {
    return this.viewModel.relationshipInfos;
  }
  get returnGeometryEnabled() {
    return this.viewModel.returnGeometryEnabled;
  }
  set returnGeometryEnabled(e13) {
    this.viewModel.returnGeometryEnabled = e13;
  }
  get returnMEnabled() {
    return this.viewModel.returnMEnabled;
  }
  set returnMEnabled(e13) {
    this.viewModel.returnMEnabled = e13;
  }
  get returnZEnabled() {
    return this.viewModel.returnZEnabled;
  }
  set returnZEnabled(e13) {
    this.viewModel.returnZEnabled = e13;
  }
  get rowHighlightIds() {
    return this.viewModel.rowHighlightIds;
  }
  set rowHighlightIds(e13) {
    this.viewModel.rowHighlightIds = e13;
  }
  get selectionSource() {
    return this.viewModel.selectionSource;
  }
  set selectionSource(e13) {
    this.viewModel.selectionSource = e13;
  }
  get showAllRelatedTables() {
    return this.viewModel.showAllRelatedTables;
  }
  set showAllRelatedTables(e13) {
    this.viewModel.showAllRelatedTables = e13;
  }
  get showPrompt() {
    return this.viewModel.showPrompt;
  }
  set showPrompt(e13) {
    this.viewModel.showPrompt = e13;
  }
  get showRelatedTableCallback() {
    return this.viewModel.showRelatedTableCallback;
  }
  set showRelatedTableCallback(e13) {
    this.viewModel.showRelatedTableCallback = e13;
  }
  get size() {
    return this.viewModel.size;
  }
  get state() {
    return this.viewModel.state;
  }
  get tableController() {
    return this.viewModel.tableController;
  }
  set tableController(e13) {
    this.viewModel.tableController = e13;
  }
  get tableParent() {
    return this.viewModel.tableParent;
  }
  set tableParent(e13) {
    this.viewModel.tableParent = e13;
  }
  get tableTemplate() {
    return this.viewModel.tableTemplate;
  }
  set tableTemplate(e13) {
    this.viewModel.tableTemplate = e13;
  }
  get tableTemplateOverride() {
    return this.viewModel.tableTemplateOverride;
  }
  set tableTemplateOverride(e13) {
    this.viewModel.tableTemplateOverride = e13;
  }
  get timeExtent() {
    return this.viewModel.timeExtent;
  }
  set timeExtent(e13) {
    this.viewModel.timeExtent = e13;
  }
  get timeZone() {
    return this.viewModel.timeZone;
  }
  set timeZone(e13) {
    this.viewModel.timeZone = e13;
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e13) {
    this.viewModel.view = e13;
  }
  get visibleElementsOverride() {
    const { attachmentsViewOptions: e13, relatedTable: t3, tableController: i11, visibleElements: l10 } = this, { columnDescriptions: o5, columnMenus: n17, tooltips: s18 } = l10, a17 = null != e13.objectId;
    if (t3) return new p13({ columnDescriptions: o5, columnMenus: n17, tooltips: s18, close: l10.close, header: l10.header, layerDropdown: l10.layerDropdown, layerDropdownIcons: l10.layerDropdownIcons, menu: l10.menu, menuItems: l10.menuItems, progress: l10.progress, selectionColumn: false, columnMenuItems: new c8({ sortAscending: false, sortDescending: false }) });
    if (i11) {
      const e14 = i11.relatedTable === this, t4 = i11.allRelatedTablesVisible, r10 = e14 && l10.selectionColumn && !t4 && !a17, c13 = e14 && !t4 && !a17;
      return new p13({ columnDescriptions: o5, columnMenus: n17, tooltips: s18, selectionColumn: r10, close: false, header: false, layerDropdown: false, menu: false, progress: false, columnMenuItems: new c8({ sortAscending: c13, sortDescending: c13 }) });
    }
    return a17 ? new p13({ columnDescriptions: o5, columnMenus: n17, tooltips: s18, close: l10.close, header: l10.header, layerDropdown: l10.layerDropdown, layerDropdownIcons: l10.layerDropdownIcons, menu: l10.menu, menuItems: l10.menuItems, progress: l10.progress, selectionColumn: false, columnMenuItems: new c8({ sortAscending: false, sortDescending: false }) }) : null;
  }
  clearSelectionFilter() {
    this.viewModel.clearSelectionFilter();
  }
  deleteAttachments(e13, t3, i11) {
    return __async(this, null, function* () {
      null != e13 && t3?.length && (i11 ? this._showDeleteAttachmentPrompt(e13, t3) : yield this.viewModel.deleteAttachments(e13, t3));
    });
  }
  deleteSelection(e13) {
    return this.highlightIds.length ? e13 ? (this._showDeletePrompt(), this.scheduleRender(), Promise.resolve()) : this.viewModel.deleteSelection() : Promise.resolve();
  }
  downloadAttachmentById(e13, t3) {
    return __async(this, null, function* () {
      return this.viewModel.downloadAttachmentById(e13, t3);
    });
  }
  drainRelatedTables() {
    this.viewModel.drainRelatedTables();
  }
  exportSelectionToCSV(e13) {
    return this.viewModel.exportSelectionToCSV(e13);
  }
  filterBySelection() {
    this.viewModel.filterBySelection();
  }
  findColumn(e13) {
    return this.viewModel.findColumn(e13);
  }
  goToPage(e13) {
    this.viewModel.goToPage(e13);
  }
  hideColumn(e13) {
    this.grid?.hideColumn(e13);
  }
  nextPage() {
    this.viewModel.nextPage();
  }
  previousPage() {
    this.viewModel.previousPage();
  }
  refresh() {
    return __async(this, null, function* () {
      yield this.viewModel.refresh();
    });
  }
  refreshCellContent() {
    this.viewModel.refreshCellContent();
  }
  saveAttachmentsViewForm() {
    return __async(this, null, function* () {
      yield this.viewModel.saveAttachmentsViewForm();
    });
  }
  showAllColumns() {
    this.viewModel.showAllColumns();
  }
  showColumn(e13) {
    this.grid?.showColumn(e13);
  }
  sortColumn(e13, t3) {
    this.viewModel.sortColumn(e13, t3);
  }
  scrollLeft() {
    this.viewModel.scrollLeft();
  }
  scrollToBottom() {
    this.viewModel.scrollToBottom();
  }
  scrollToIndex(e13) {
    this.viewModel.scrollToIndex(e13);
  }
  scrollToRow(e13) {
    this.viewModel.scrollToRow(e13);
  }
  scrollToTop() {
    this.viewModel.scrollToTop();
  }
  toggleColumnVisibility(e13) {
    this.viewModel.toggleColumnVisibility(e13);
  }
  zoomToSelection() {
    this.effectiveTable.viewModel.zoomToSelection();
  }
  render() {
    const { _effectiveVisibleElements: e13, isQueryingOrSyncing: t3, menuConfig: i11, state: l10 } = this;
    return n3("div", { bind: this, class: this.classes(U2.base, e5.widget) }, n3("calcite-panel", { bind: this, class: U2.content, closable: e13.close, description: this._effectiveDescription, disabled: this.disabled || "disabled" === l10 && !this._effectiveLayers?.length, heading: e13.header ? this._effectiveTitle : void 0, loading: "loading" === l10, menuOpen: !!i11?.open, overlayPositioning: "fixed", onCalcitePanelClose: (e14) => {
      e14.currentTarget.closed = false, this.emit("close");
    } }, e13.progress ? n3("calcite-progress", { type: t3 ? "indeterminate" : "determinate" }) : null, this._showLayerDropdown ? this._renderLayerDropdown() : null, this._renderColumnVisibilityAction(), this._renderHeaderMenuActions(), this._renderNavigationBar(), this._renderTables(), this._renderError()), this._renderColumnVisibilityPopover(), this._renderPrompt());
  }
  _renderTables() {
    const { grid: e13, relatedTables: t3 } = this, i11 = this.classes(U2.tableContainer);
    if (t3.length) {
      const l10 = this.classes(U2.base, this.allRelatedTablesVisible ? U2.expanded : U2.collapsed, this._shouldShowAttachmentsView ? U2.tableContainerWithAttachments : void 0);
      return n3("div", { class: i11 }, n3("calcite-panel", { overlayPositioning: "fixed" }, n3("div", null, [this._shouldShowGrid ? n3("div", { class: l10 }, e13?.render(), this._renderPagination()) : void 0, ...this._filteredTables.map((e14) => {
        const i12 = t3.indexOf(e14);
        return n3("div", { class: l10, key: `related-${i12}` }, e14.render());
      }), ,])));
    }
    return null != this.attachmentsViewOptions.objectId ? n3("div", { class: i11 }, n3("calcite-panel", { overlayPositioning: "fixed" }, n3("div", null, [n3("div", { class: this.classes(U2.base, U2.collapsed) }, e13?.render(), this._renderPagination()), this._renderAttachmentsView()]))) : [n3("div", { class: i11 }, e13?.render()), this._renderPagination()];
  }
  _renderPagination() {
    if (this.paginationEnabled) return n3("calcite-pagination", { pageSize: 1, startItem: this.pageIndex + 1, totalItems: this.pageCount, onCalcitePaginationChange: (e13) => this.goToPage(e13.currentTarget.startItem - 1) });
  }
  _renderError() {
    const { messages: e13 } = this;
    return n3("calcite-alert", { autoClose: true, autoCloseDuration: "fast", icon: B3.exclamationMarkTriangle, kind: "danger", label: e13.errorOccured, open: this._hasAttachmentsViewError, slot: "alerts", onCalciteAlertClose: () => {
      this.attachmentsViewOptions.error = null;
    } }, n3("span", { slot: "message" }, e13.errorOccured));
  }
  _renderPrompt() {
    return this.prompt ? n3(r3, __spreadProps(__spreadValues({}, this.prompt), { headingLevel: 2 })) : void 0;
  }
  _showDeletePrompt() {
    const { messages: e13, messagesCommon: t3 } = this, i11 = s4(e13.deleteSelectionCount, { count: this.highlightIds.length });
    this.showPrompt({ title: i11, message: e13.deleteRecordsRemoved, context: "danger", actions: { primary: { label: t3.delete, action: this._onDeleteSelectionClick }, secondary: { label: e13.keepRecords, action: () => this.clearPrompt() } } });
  }
  _showDeleteAttachmentPrompt(e13, t3) {
    const { messages: i11, messagesCommon: l10 } = this, o5 = s4(i11.deleteAttachmentCount, { count: t3.length });
    this.showPrompt({ title: o5, message: i11.deleteAttachmentConfirmation, context: "danger", actions: { primary: { label: l10.delete, action: () => __async(this, null, function* () {
      try {
        yield this.deleteAttachments(e13, t3, false);
      } finally {
        this.clearPrompt();
      }
    }) }, secondary: { label: l10.cancel, action: () => this.clearPrompt() } } });
  }
  _onDeleteSelectionClick() {
    return __async(this, null, function* () {
      try {
        yield this.viewModel.deleteSelection();
      } finally {
        this.clearPrompt();
      }
    });
  }
  _renderHeaderMenuAction(e13) {
    const { disabled: t3, hidden: i11, icon: l10, text: o5, clickFunction: n17 } = e13;
    if (!i11) return n3("calcite-action", { disabled: t3 ?? this.menuConfig?.disabled, icon: l10 ?? void 0, key: o5, onclick: () => n17(), slot: "header-menu-actions", text: o5, textEnabled: true, title: o5 });
  }
  _renderHeaderMenuActions() {
    return this._shouldShowMenu ? [this._renderDefaultHeaderMenuActions(), this._renderCustomHeaderMenuActions()] : [];
  }
  _renderDefaultHeaderMenuActions() {
    if (!this._hasDefaultMenuItems) return [];
    const { messages: e13 } = this;
    return [this._showRefreshDataAction && { icon: B3.refresh, text: e13.refreshData, clickFunction: () => this.refresh() }, this._showDeleteSelectionAction && { icon: B3.delete, text: e13.deleteSelection, clickFunction: () => this.deleteSelection(true) }, this._showClearSelectionAction && { icon: B3.clearSelection, text: e13.clearSelection, clickFunction: () => this.highlightIds?.removeAll() }, this._showZoomToSelectionAction && { icon: B3.zoomToSelection, text: e13.zoomToSelection, clickFunction: () => this.zoomToSelection() }, this._showSelectedRecordsShowSelectedAction && { icon: B3.showSelected, text: e13.showSelected, clickFunction: () => {
      const { objectIds: e14 } = this;
      e14.removeAll(), e14.addMany(this.highlightIds.toArray());
    } }, this._showSelectedRecordsShowAllAction && { icon: B3.showAll, text: e13.showAllRecords, clickFunction: () => this.objectIds.removeAll() }, this._showExportSelectionToCSVAction && { icon: B3.exportToCSV, text: e13.exportSelectionCSV, clickFunction: () => this.exportSelectionToCSV() }].filter(G).map((e14) => e14 && this._renderHeaderMenuAction(e14));
  }
  _renderCustomHeaderMenuActions() {
    return this.menuConfig?.items?.map(({ disabled: e13, hidden: t3, icon: i11, label: l10, clickFunction: o5 }) => this._renderHeaderMenuAction({ hidden: "function" == typeof t3 ? t3() : t3, icon: i11, text: l10, disabled: e13, clickFunction: (e14) => o5(e14) })) ?? [];
  }
  _renderColumnVisibilityAction() {
    if (!this._showColumnsVisibilityAction) return [];
    const { _columnVisibilityActions: e13, effectiveTable: t3, id: i11 } = this, l10 = this.messages.toggleColumns;
    return n3("calcite-action", { afterCreate: (t4) => e13.set(i11, t4), afterRemoved: () => e13.delete(i11), appearance: "transparent", bind: this, disabled: t3.menuConfig?.disabled, icon: B3.showColumn, id: `${i11}__toggle-columns-action`, slot: "header-actions-end", text: l10 }, this._effectiveVisibleElements.tooltips ? n3("calcite-tooltip", { closeOnClick: true, overlayPositioning: "fixed", placement: "bottom-end", slot: "tooltip" }, l10) : null);
  }
  _renderColumnVisibilityPopover() {
    if (!this._showColumnsVisibilityAction || this.effectiveTable.menuConfig?.disabled) return;
    const { effectiveTable: e13 } = this, t3 = this.messages.toggleColumns;
    return n3("calcite-popover", { autoClose: true, class: U2.menuPopover, label: t3, overlayPositioning: "fixed", placement: "top-end", pointerDisabled: true, referenceElement: this._columnVisibilityActions.get(this.id) }, n3("calcite-list", { displayMode: "nested", filterEnabled: true, filterPlaceholder: t3, label: t3, selectionMode: "multiple" }, e13.columns.toArray().map((t4) => {
      const i11 = e11(t4) ? t4.columns?.map((t5) => this._renderColumnListItem({ column: t5, table: e13, ignoreSelect: true })) : void 0;
      return this._renderColumnListItem({ column: t4, table: e13, items: i11 });
    })));
  }
  _renderColumnListItem(e13) {
    const { column: t3, table: i11, items: l10, ignoreSelect: o5 } = e13, { effectiveLabel: n17, fieldName: s18, hidden: a17 } = t3;
    return n3("calcite-list-item", { key: `toggle-columns__item-${s18}`, label: n17, open: !(!l10?.length || a17) || void 0, selected: !a17, value: s18, onCalciteListItemSelect: (e14) => {
      o5 && e14.stopPropagation(), i11.toggleColumnVisibility(e14.currentTarget.value);
    } }, l10);
  }
  _renderLayerDropdown() {
    const e13 = this.messages.selectALayer;
    return n3("div", { class: U2.layerDropdownMenu, key: `${this.id}-layerDropdown`, slot: "header-actions-start" }, n3("calcite-dropdown", { bind: this, maxItems: 5, overlayPositioning: "fixed", placement: "bottom-start" }, n3("calcite-action", { icon: B3.layers, slot: "trigger", text: e13, title: e13 }), n3("calcite-dropdown-group", { selectionMode: "single" }, this._effectiveLayers.map((e14, t3) => this._renderLayerDropdownItem(e14, t3)) ?? null)));
  }
  _renderLayerDropdownItem(e13, t3) {
    const i11 = this.visibleElements.layerDropdownIcons;
    return n3("calcite-dropdown-item", { iconStart: i11 ? I(e13) : void 0, key: `dropdown-item-${t3}`, label: e13.title ?? "", selected: e13 === this.layer, value: e13.id, onCalciteDropdownItemSelect: () => {
      this.layer = e13;
    } }, e13.title);
  }
  _onRelatedNavigationItemClick(e13) {
    this.viewModel.drainRelatedTablesAboveIndex(e13);
  }
  _collapseRelatedTable(e13) {
    this.viewModel.collapseRelatedTable(this.effectiveTable, e13);
  }
  _onShowRelatedTable(e13) {
    this.showRelatedTableCallback || (this._collapseRelatedTable(e13), this._createRelatedTable(e13));
  }
  _createRelatedTable(e13) {
    return __async(this, null, function* () {
      const { editingEnabled: t3, effectiveTable: i11, paginationEnabled: l10, pageSize: o5, view: n17, viewModel: s18 } = this, { layer: a17, objectId: r10, relatedLayer: c13, relationshipId: d6 } = e13;
      yield a17.load();
      const h8 = this.attachmentsEnabled && s10(a17), m8 = new j3({ layer: a17, attachmentsEnabled: h8, editingEnabled: t3, paginationEnabled: l10, pageSize: o5, relatedRecordsEnabled: true, relationshipConfig: { objectId: r10, relatedLayer: c13, relationshipId: d6 }, relationshipColumnConfigs: b3(a17, d6), tableController: this, tableParent: i11, view: n17, showRelatedTableCallback: (e14) => s18.emit("show-related-table", e14) });
      this.relatedTables.add(m8), this.scheduleRender();
    });
  }
  _renderAttachmentsView() {
    const { attachmentInfos: e13, mode: t3, objectId: i11 } = this.attachmentsViewOptions;
    return "file" !== t3 && e13.length && null != i11 ? this._renderAttachmentsViewList() : this._renderAttachmentsViewFilePane();
  }
  _renderAttachmentsViewFilePane() {
    const { attachmentsViewOptions: e13, isSyncingAttachments: t3, messages: i11, messagesUnits: l10, viewModel: { supportsAddAttachments: o5 } } = this, { attachmentId: n17, attachmentInfos: a17, candidates: r10, objectId: c13 } = e13, d6 = a17.find((e14) => e14.id === n17), h8 = a17.length, m8 = r10?.length, p14 = d6 ? n3("calcite-label", { alignment: "center", key: "replace-file-node", scale: "l" }, i11.replaceFile) : void 0, u5 = m8 ? void 0 : n3("calcite-label", { alignment: "center", key: "message-node", scale: "m" }, o5 ? null == c13 ? i11.noFeature : i11.dragAndDropToUpload : i11.editingRestricted), g6 = Array.from(r10 ?? []).pop(), b5 = g6 ? n3("calcite-label", { key: "filename-node" }, g6.name) : void 0, w5 = o5 && null != c13, v3 = w5 && m8, y5 = n3("input", { afterCreate: y, afterRemoved: w, afterUpdate: y, bind: this, "data-node-ref": "_attachmentsInput", files: r10, hidden: true, name: "attachment", onchange: (e14) => this._onAttachmentsViewCandidateChange(e14), type: "file" }), f7 = w5 ? n3("calcite-button", { appearance: "outline-fill", bind: this, disabled: t3, iconStart: B3.folderOpen, key: "select-node", loading: false, onclick: () => {
      this._attachmentsInput?.click();
    }, width: "full" }, i11.selectFile) : void 0, _2 = v3 ? n3("calcite-button", { appearance: "outline-fill", bind: this, disabled: t3, iconStart: B3.save, key: "save-node", loading: t3, onclick: () => {
      this.saveAttachmentsViewForm();
    }, width: "full" }, d6 ? i11.updateAttachment : i11.addAttachment) : void 0, M3 = h8 || m8 ? n3("calcite-button", { appearance: "transparent", bind: this, disabled: t3, key: "cancel-node", onclick: () => {
      this._attachmentsInput && (this._attachmentsInput.value = ""), e13.reset(), e13.attachmentInfos?.length && (e13.mode = "list");
    }, width: "full" }, this.messagesCommon.cancel) : void 0;
    return [n3("div", { class: U2.attachmentsView, key: "attachments-view" }, n3("div", { class: U2.attachmentsViewContent, key: "attachments-view-content" }, n3("div", { bind: this, class: U2.attachmentsViewDropArea, ondragover: (e14) => e14.preventDefault(), ondrop: this._onAttachmentsViewDrop }, n3("calcite-icon", { class: U2.attachmentsViewIcon, icon: B3.upload, scale: "l" }), p14, u5, n3("form", { afterCreate: (t4) => e13.form = t4, afterRemoved: () => e13.form = null, bind: this, key: "attachments-form" }, n3("fieldset", null, b5, y5, f7, _2, M3)))), null != c13 && null != d6 ? n3("div", { class: U2.attachmentsViewInformation, key: "information" }, this._renderAttachmentsViewThumbnail(d6, 200), n3("label", { key: "file-label" }, i11.fileName), n3("span", { key: "file-span" }, d6.name), n3("label", { key: "size-label" }, i11.size), n3("span", { key: "size-span" }, T2(l10, d6.size ?? 0))) : void 0)];
  }
  _renderAttachmentsViewList() {
    const { attachmentsViewOptions: e13, messages: t3, messagesUnits: i11, viewModel: { store: { syncingAttachmentEdits: l10 }, supportsDeleteAttachments: o5, supportsUpdateAttachments: n17 } } = this, { attachmentInfos: a17, objectId: r10 } = e13;
    return n3("calcite-list", { afterCreate: y, afterRemoved: w, afterUpdate: y, bind: this, class: U2.attachmentsViewList, "data-node-ref": "attachmentsList", key: `attachments-list-${r10}`, label: t3?.attachments, loading: l10, ondragover: (e14) => e14.preventDefault(), ondrop: this._onAttachmentsViewDrop, selectionMode: "multiple", onCalciteListChange: () => this.scheduleRender() }, ...a17?.map((l11) => {
      const { id: a18, name: c13, size: d6, url: h8 } = l11, m8 = T2(i11, d6 ?? 0);
      return n3("calcite-list-item", { afterRemoved: () => this.scheduleRender(), key: `attachment-${a18}`, label: c13, value: a18 }, this._renderAttachmentsViewListThumbnail(l11), n3("span", { class: U2.attachmentsViewListFileSize, slot: "actions-end", title: m8 }, m8), n3("calcite-action", { appearance: "transparent", icon: B3.downloadTo, key: `download-attachment-${a18}`, label: `${c13}`, onclick: (e14) => {
        e14.preventDefault(), this.downloadAttachmentById(r10 ?? -1, a18);
      }, slot: "actions-end", text: t3.downloadAttachment, title: t3.downloadAttachment }), n17 && null != r10 ? n3("calcite-action", { appearance: "transparent", disabled: !n17, icon: B3.replaceImage, key: `replace-attachment-${a18}`, label: `${c13}`, onclick: () => {
        e13.mode = "file", e13.attachmentId = a18;
      }, slot: "actions-end", text: t3.updateAttachment, title: t3.updateAttachment }) : void 0, n3("calcite-action", { appearance: "transparent", icon: B3.launch, key: `launch-attachment-${a18}`, label: `${c13}`, onclick: () => {
        h8 && window.open(h8, "_blank");
      }, slot: "actions-end", text: t3.viewAttachment, title: t3.viewAttachment }), o5 && null != r10 ? n3("calcite-action", { appearance: "transparent", class: U2.attachmentsViewListItemDelete, disabled: !o5, icon: B3.delete, key: `delete-attachment-${a18}`, label: `${c13}`, onclick: () => {
        this.deleteAttachments(r10, [a18], true);
      }, slot: "actions-end", text: t3.deleteAttachment, title: t3.deleteAttachment }) : void 0);
    }));
  }
  _renderAttachmentsViewListThumbnail(e13) {
    return n3("div", { class: U2.attachmentsViewListThumbnail, slot: "content-start" }, n3("a", { href: e13.url ?? "", rel: "noreferrer", target: "_blank" }, this._renderAttachmentsViewThumbnail(e13)));
  }
  _renderAttachmentsViewThumbnail(e13, t3 = 64) {
    const { contentType: i11, name: l10, size: o5, url: n17 } = e13, s18 = `${n17}${n17?.includes("?") ? "&" : "?"}w=${t3}&s=${o5}`;
    return this.viewModel.supportsResizeAttachments && e4(i11) ? n3("img", { alt: l10, key: `thumbnail-image-${l10}`, src: s18, title: l10 }) : n3("calcite-icon", { icon: a4(i11), key: `thumbnail-icon-${l10}`, scale: "l", textLabel: l10, title: l10 });
  }
  _onAttachmentsViewCandidateChange({ target: e13 }) {
    this.attachmentsViewOptions.candidates = e13?.files;
  }
  _onAttachmentsViewDrop(e13) {
    const { viewModel: t3 } = this;
    e13.preventDefault(), (t3.supportsAddAttachments || t3.supportsUpdateAttachments) && this.attachmentsViewOptions.set({ mode: "file", candidates: e13.dataTransfer?.files });
  }
  _renderNavigationBar() {
    const { effectiveTable: e13, messages: t3, messagesCommon: i11, relatedTable: l10, relatedTables: o5 } = this;
    if (!this._shouldShowNavigationBar) return;
    const { attachmentsList: n17, attachmentsViewOptions: s18, layer: a17, viewModel: { supportsAddAttachments: r10, supportsDeleteAttachments: c13 } } = e13;
    if (!a17) return;
    const { attachmentInfos: d6, objectId: h8 } = s18, m8 = null != h8, p14 = d6.length, u5 = n17?.selectedItems?.length ?? 0, g6 = `${a17.objectIdField}: ${h8}`, b5 = s4(t3.selectedCount, { count: u5 }), w5 = s4(t3.attachmentsCount, { count: p14 }), v3 = m8 ? n3("calcite-action", { bind: this, icon: B3.chevronRight, iconFlipRtl: true, key: "navigation-feature", onclick: () => e13.scrollToRow(h8), text: g6, textEnabled: true, title: g6 }) : void 0, y5 = m8 ? n3("calcite-action", { icon: B3.chevronRight, iconFlipRtl: true, key: "navigation-attachments-label", label: w5, onclick: () => {
      p14 > 0 && (s18.mode = "list");
    }, text: w5, textEnabled: true, title: w5 }) : void 0, f7 = m8 ? n3("calcite-chip", { closable: true, closed: 0 === u5, key: "navigation-chip", kind: "inverse", label: b5, selected: true, title: b5, value: "selected", onCalciteChipClose: () => n17?.selectedItems?.forEach((e14) => e14.selected = false) }, b5) : void 0, _2 = l10 ? n3("calcite-label", { layout: "inline" }, t3.showAllTables, n3("calcite-switch", { checked: this.allRelatedTablesVisible, onCalciteSwitchChange: (e14) => this.showAllRelatedTables = !!e14.currentTarget.checked })) : void 0, M3 = m8 && "list" === s18.mode && null != h8 && u5 && c13 ? n3("calcite-action", { icon: B3.delete, iconFlipRtl: true, key: "attachments-trash-all", onclick: () => {
      e13.deleteAttachments(h8, n17?.selectedItems?.map((e14) => e14.value) ?? [], true);
    }, text: i11.delete, textEnabled: true, title: s4(t3.deleteAttachmentCount, { count: u5 }) }) : void 0, C5 = m8 && "list" === s18.mode && r10 ? n3("calcite-action", { bind: this, icon: B3.plus, iconFlipRtl: true, key: "attachments-add", onclick: () => {
      s18.attachmentId = null, s18.mode = "file";
    }, text: t3.addAttachment, textEnabled: true, title: t3.addAttachment }) : void 0;
    return n3("div", { class: U2.tableNavigation, key: "table-nav" }, n3("calcite-action", { icon: B3.moveUp, iconFlipRtl: true, key: "go-back", onclick: () => {
      l10 && this.drainRelatedTables(), e13.attachmentsViewOptions.objectId = null;
    }, text: this.layer?.title ?? "", textEnabled: false, title: l10 ? t3.exitRelatedRecords : t3.exitAttachments }), o5.toArray().map((e14, t4) => this._renderRelatedTableNavigationAction(e14, t4)), v3, y5, n3("div", null, f7, _2, M3, C5));
  }
  _renderRelatedTableNavigationAction(e13, t3) {
    const i11 = this._getLabelForRelatedTableNavigationAction(e13);
    return n3("calcite-action", { icon: B3.chevronRight, iconFlipRtl: true, key: t3, onclick: () => this._onRelatedNavigationItemClick(t3), text: i11, textEnabled: true, title: e13.layer?.title || "" });
  }
  _getLabelForRelatedTableNavigationAction(e13) {
    const t3 = e13.layer?.title;
    if (!t3) return "";
    const { relatedTables: i11 } = this;
    if (i11.length <= 1) return t3;
    return i11.indexOf(e13) !== i11.length - 1 && t3.length > 20 ? `${t3.slice(0, 20)}...` : t3;
  }
};
r([m()], H3.prototype, "_attachmentsInput", void 0), r([m()], H3.prototype, "_columnVisibilityActions", void 0), r([m()], H3.prototype, "_effectiveDescription", null), r([m()], H3.prototype, "_effectiveLayers", null), r([m()], H3.prototype, "_effectiveTitle", null), r([m()], H3.prototype, "_effectiveVisibleElements", null), r([m()], H3.prototype, "_filteredTables", null), r([m()], H3.prototype, "_hasAttachmentsViewError", null), r([m()], H3.prototype, "_hasCustomMenuItems", null), r([m()], H3.prototype, "_hasDefaultMenuItems", null), r([m()], H3.prototype, "_shouldShowGrid", null), r([m()], H3.prototype, "_shouldShowMenu", null), r([m()], H3.prototype, "_shouldShowAttachmentsView", null), r([m()], H3.prototype, "_showClearSelectionAction", null), r([m()], H3.prototype, "_showColumnsVisibilityAction", null), r([m()], H3.prototype, "_showDeleteSelectionAction", null), r([m()], H3.prototype, "_showExportSelectionToCSVAction", null), r([m()], H3.prototype, "_showLayerDropdown", null), r([m()], H3.prototype, "_shouldShowNavigationBar", null), r([m()], H3.prototype, "_showRefreshDataAction", null), r([m()], H3.prototype, "_showSelectedRecordsShowSelectedAction", null), r([m()], H3.prototype, "_showSelectedRecordsShowAllAction", null), r([m()], H3.prototype, "_showZoomToSelectionAction", null), r([m()], H3.prototype, "_viewLayers", null), r([m()], H3.prototype, "attachmentsList", void 0), r([m({ readOnly: true })], H3.prototype, "grid", null), r([m()], H3.prototype, "actionColumnConfig", null), r([m({ readOnly: true })], H3.prototype, "activeFilters", null), r([m({ readOnly: true })], H3.prototype, "activeSortOrders", null), r([m()], H3.prototype, "allColumns", null), r([m({ readOnly: true })], H3.prototype, "allRelatedTablesVisible", null), r([m()], H3.prototype, "attachmentsEnabled", null), r([m()], H3.prototype, "attachmentsViewOptions", null), r([m({ type: f3 })], H3.prototype, "attributeTableTemplate", null), r([m()], H3.prototype, "autoRefreshEnabled", null), r([m()], H3.prototype, "clearPrompt", null), r([m()], H3.prototype, "columnPerformanceModeEnabled", null), r([m()], H3.prototype, "columnReorderingEnabled", null), r([m({ readOnly: true })], H3.prototype, "columns", null), r([m()], H3.prototype, "description", void 0), r([m()], H3.prototype, "disabled", void 0), r([m()], H3.prototype, "editingEnabled", null), r([m()], H3.prototype, "effectiveSize", null), r([m()], H3.prototype, "effectiveTable", null), r([m()], H3.prototype, "filterGeometry", null), r([m()], H3.prototype, "filterBySelectionEnabled", null), r([m()], H3.prototype, "hiddenFields", null), r([m()], H3.prototype, "highlightEnabled", null), r([m()], H3.prototype, "highlightIds", null), r([m()], H3.prototype, "icon", null), r([m()], H3.prototype, "initialSize", null), r([m()], H3.prototype, "isQueryingOrSyncing", null), r([m()], H3.prototype, "isSyncingAttachments", null), r([m()], H3.prototype, "label", null), r([m()], H3.prototype, "layer", null), r([m()], H3.prototype, "layers", null), r([m()], H3.prototype, "layerView", null), r([m()], H3.prototype, "maxSize", null), r([m(), e3("esri/widgets/FeatureTable/t9n/FeatureTable")], H3.prototype, "messages", null), r([m(), e3("esri/t9n/common")], H3.prototype, "messagesCommon", null), r([m(), e3("esri/core/t9n/Units")], H3.prototype, "messagesUnits", null), r([m(), e3("esri/widgets/support/t9n/uriUtils")], H3.prototype, "messagesURIUtils", null), r([m()], H3.prototype, "menuConfig", void 0), r([m()], H3.prototype, "multipleSelectionEnabled", null), r([m()], H3.prototype, "multiSortEnabled", null), r([m()], H3.prototype, "objectIds", null), r([m()], H3.prototype, "outFields", null), r([m()], H3.prototype, "pageCount", null), r([m()], H3.prototype, "pageIndex", null), r([m()], H3.prototype, "pageSize", null), r([m()], H3.prototype, "paginationEnabled", null), r([m()], H3.prototype, "prompt", null), r([m()], H3.prototype, "relatedRecordsEnabled", null), r([m()], H3.prototype, "relatedTable", null), r([m()], H3.prototype, "relatedTables", null), r([m()], H3.prototype, "relationship", null), r([m()], H3.prototype, "relationshipColumnConfigs", null), r([m()], H3.prototype, "relationshipConfig", null), r([m()], H3.prototype, "relationshipInfos", null), r([m()], H3.prototype, "returnGeometryEnabled", null), r([m()], H3.prototype, "returnMEnabled", null), r([m()], H3.prototype, "returnZEnabled", null), r([m()], H3.prototype, "rowHighlightIds", null), r([m()], H3.prototype, "selectionSource", null), r([m()], H3.prototype, "showAllRelatedTables", null), r([m()], H3.prototype, "showPrompt", null), r([m()], H3.prototype, "showRelatedTableCallback", null), r([m()], H3.prototype, "size", null), r([m({ readOnly: true })], H3.prototype, "state", null), r([m({ constructOnly: true })], H3.prototype, "tableController", null), r([m({ constructOnly: true })], H3.prototype, "tableParent", null), r([m()], H3.prototype, "tableTemplate", null), r([m()], H3.prototype, "tableTemplateOverride", null), r([m()], H3.prototype, "title", void 0), r([m()], H3.prototype, "timeExtent", null), r([m()], H3.prototype, "timeZone", null), r([m()], H3.prototype, "view", null), r([m({ type: he }), e7(["cell-click", "cell-dblclick", "cell-pointerover", "cell-pointerout", "cell-keydown", "column-reorder", "show-related-table"])], H3.prototype, "viewModel", void 0), r([m({ type: p13, nonNullable: true })], H3.prototype, "visibleElements", void 0), r([m({ type: p13 })], H3.prototype, "visibleElementsOverride", null), H3 = j3 = r([a2("esri.widgets.FeatureTable")], H3);
var N3 = H3;
export {
  N3 as default
};
/*! Bundled license information:

@vaadin/component-base/src/define.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/version.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-themable-mixin/vaadin-theme-property-mixin.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-themable-mixin/vaadin-themable-mixin.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-themable-mixin/register-styles.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/color.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/font-icons.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/sizing.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/spacing.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/style.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-lumo-styles/typography.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@polymer/polymer/lib/utils/boot.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/resolve-url.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/settings.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/mixin.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/elements/dom-module.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/style-gather.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/wrap.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/path.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/case-map.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/utils/async.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/mixins/properties-changed.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/mixins/property-accessors.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/mixins/template-stamp.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/mixins/property-effects.js:
  (**
   * @fileoverview
   * @suppress {checkPrototypalTypes}
   * @license Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt The complete set of authors may be found
   * at http://polymer.github.io/AUTHORS.txt The complete set of contributors may
   * be found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by
   * Google as part of the polymer project is also subject to an additional IP
   * rights grant found at http://polymer.github.io/PATENTS.txt
   *)

@polymer/polymer/lib/utils/telemetry.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/mixins/properties-mixin.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/lib/mixins/element-mixin.js:
  (**
   * @fileoverview
   * @suppress {checkPrototypalTypes}
   * @license Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt The complete set of authors may be found
   * at http://polymer.github.io/AUTHORS.txt The complete set of contributors may
   * be found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by
   * Google as part of the polymer project is also subject to an additional IP
   * rights grant found at http://polymer.github.io/PATENTS.txt
   *)

@polymer/polymer/lib/utils/html-tag.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@polymer/polymer/polymer-element.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@vaadin/component-base/src/async.js:
  (**
   * @license
   * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   *)

@vaadin/component-base/src/debounce.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@vaadin/component-base/src/dir-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/path-utils.js:
  (**
   * @license
   * Copyright (c) 2023 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/templates.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/dom-utils.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-helpers.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-column-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-column.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/controller-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/vaadin-usage-statistics/vaadin-usage-statistics-collect.js:
  (*! vaadin-dev-mode:start
    (function () {
  'use strict';
  
  var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  };
  
  var classCallCheck = function (instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  };
  
  var createClass = function () {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
  
    return function (Constructor, protoProps, staticProps) {
      if (protoProps) defineProperties(Constructor.prototype, protoProps);
      if (staticProps) defineProperties(Constructor, staticProps);
      return Constructor;
    };
  }();
  
  var getPolymerVersion = function getPolymerVersion() {
    return window.Polymer && window.Polymer.version;
  };
  
  var StatisticsGatherer = function () {
    function StatisticsGatherer(logger) {
      classCallCheck(this, StatisticsGatherer);
  
      this.now = new Date().getTime();
      this.logger = logger;
    }
  
    createClass(StatisticsGatherer, [{
      key: 'frameworkVersionDetectors',
      value: function frameworkVersionDetectors() {
        return {
          'Flow': function Flow() {
            if (window.Vaadin && window.Vaadin.Flow && window.Vaadin.Flow.clients) {
              var flowVersions = Object.keys(window.Vaadin.Flow.clients).map(function (key) {
                return window.Vaadin.Flow.clients[key];
              }).filter(function (client) {
                return client.getVersionInfo;
              }).map(function (client) {
                return client.getVersionInfo().flow;
              });
              if (flowVersions.length > 0) {
                return flowVersions[0];
              }
            }
          },
          'Vaadin Framework': function VaadinFramework() {
            if (window.vaadin && window.vaadin.clients) {
              var frameworkVersions = Object.values(window.vaadin.clients).filter(function (client) {
                return client.getVersionInfo;
              }).map(function (client) {
                return client.getVersionInfo().vaadinVersion;
              });
              if (frameworkVersions.length > 0) {
                return frameworkVersions[0];
              }
            }
          },
          'AngularJs': function AngularJs() {
            if (window.angular && window.angular.version && window.angular.version) {
              return window.angular.version.full;
            }
          },
          'Angular': function Angular() {
            if (window.ng) {
              var tags = document.querySelectorAll("[ng-version]");
              if (tags.length > 0) {
                return tags[0].getAttribute("ng-version");
              }
              return "Unknown";
            }
          },
          'Backbone.js': function BackboneJs() {
            if (window.Backbone) {
              return window.Backbone.VERSION;
            }
          },
          'React': function React() {
            var reactSelector = '[data-reactroot], [data-reactid]';
            if (!!document.querySelector(reactSelector)) {
              // React does not publish the version by default
              return "unknown";
            }
          },
          'Ember': function Ember() {
            if (window.Em && window.Em.VERSION) {
              return window.Em.VERSION;
            } else if (window.Ember && window.Ember.VERSION) {
              return window.Ember.VERSION;
            }
          },
          'jQuery': function (_jQuery) {
            function jQuery() {
              return _jQuery.apply(this, arguments);
            }
  
            jQuery.toString = function () {
              return _jQuery.toString();
            };
  
            return jQuery;
          }(function () {
            if (typeof jQuery === 'function' && jQuery.prototype.jquery !== undefined) {
              return jQuery.prototype.jquery;
            }
          }),
          'Polymer': function Polymer() {
            var version = getPolymerVersion();
            if (version) {
              return version;
            }
          },
          'LitElement': function LitElement() {
            var version = window.litElementVersions && window.litElementVersions[0];
            if (version) {
              return version;
            }
          },
          'LitHtml': function LitHtml() {
            var version = window.litHtmlVersions && window.litHtmlVersions[0];
            if (version) {
              return version;
            }
          },
          'Vue.js': function VueJs() {
            if (window.Vue) {
              return window.Vue.version;
            }
          }
        };
      }
    }, {
      key: 'getUsedVaadinElements',
      value: function getUsedVaadinElements(elements) {
        var version = getPolymerVersion();
        var elementClasses = void 0;
        // NOTE: In case you edit the code here, YOU MUST UPDATE any statistics reporting code in Flow.
        // Check all locations calling the method getEntries() in
        // https://github.com/vaadin/flow/blob/master/flow-server/src/main/java/com/vaadin/flow/internal/UsageStatistics.java#L106
        // Currently it is only used by BootstrapHandler.
        if (version && version.indexOf('2') === 0) {
          // Polymer 2: components classes are stored in window.Vaadin
          elementClasses = Object.keys(window.Vaadin).map(function (c) {
            return window.Vaadin[c];
          }).filter(function (c) {
            return c.is;
          });
        } else {
          // Polymer 3: components classes are stored in window.Vaadin.registrations
          elementClasses = window.Vaadin.registrations || [];
        }
        elementClasses.forEach(function (klass) {
          var version = klass.version ? klass.version : "0.0.0";
          elements[klass.is] = { version: version };
        });
      }
    }, {
      key: 'getUsedVaadinThemes',
      value: function getUsedVaadinThemes(themes) {
        ['Lumo', 'Material'].forEach(function (themeName) {
          var theme;
          var version = getPolymerVersion();
          if (version && version.indexOf('2') === 0) {
            // Polymer 2: themes are stored in window.Vaadin
            theme = window.Vaadin[themeName];
          } else {
            // Polymer 3: themes are stored in custom element registry
            theme = customElements.get('vaadin-' + themeName.toLowerCase() + '-styles');
          }
          if (theme && theme.version) {
            themes[themeName] = { version: theme.version };
          }
        });
      }
    }, {
      key: 'getFrameworks',
      value: function getFrameworks(frameworks) {
        var detectors = this.frameworkVersionDetectors();
        Object.keys(detectors).forEach(function (framework) {
          var detector = detectors[framework];
          try {
            var version = detector();
            if (version) {
              frameworks[framework] = { version: version };
            }
          } catch (e) {}
        });
      }
    }, {
      key: 'gather',
      value: function gather(storage) {
        var storedStats = storage.read();
        var gatheredStats = {};
        var types = ["elements", "frameworks", "themes"];
  
        types.forEach(function (type) {
          gatheredStats[type] = {};
          if (!storedStats[type]) {
            storedStats[type] = {};
          }
        });
  
        var previousStats = JSON.stringify(storedStats);
  
        this.getUsedVaadinElements(gatheredStats.elements);
        this.getFrameworks(gatheredStats.frameworks);
        this.getUsedVaadinThemes(gatheredStats.themes);
  
        var now = this.now;
        types.forEach(function (type) {
          var keys = Object.keys(gatheredStats[type]);
          keys.forEach(function (key) {
            if (!storedStats[type][key] || _typeof(storedStats[type][key]) != _typeof({})) {
              storedStats[type][key] = { firstUsed: now };
            }
            // Discards any previously logged version number
            storedStats[type][key].version = gatheredStats[type][key].version;
            storedStats[type][key].lastUsed = now;
          });
        });
  
        var newStats = JSON.stringify(storedStats);
        storage.write(newStats);
        if (newStats != previousStats && Object.keys(storedStats).length > 0) {
          this.logger.debug("New stats: " + newStats);
        }
      }
    }]);
    return StatisticsGatherer;
  }();
  
  var StatisticsStorage = function () {
    function StatisticsStorage(key) {
      classCallCheck(this, StatisticsStorage);
  
      this.key = key;
    }
  
    createClass(StatisticsStorage, [{
      key: 'read',
      value: function read() {
        var localStorageStatsString = localStorage.getItem(this.key);
        try {
          return JSON.parse(localStorageStatsString ? localStorageStatsString : '{}');
        } catch (e) {
          return {};
        }
      }
    }, {
      key: 'write',
      value: function write(data) {
        localStorage.setItem(this.key, data);
      }
    }, {
      key: 'clear',
      value: function clear() {
        localStorage.removeItem(this.key);
      }
    }, {
      key: 'isEmpty',
      value: function isEmpty() {
        var storedStats = this.read();
        var empty = true;
        Object.keys(storedStats).forEach(function (key) {
          if (Object.keys(storedStats[key]).length > 0) {
            empty = false;
          }
        });
  
        return empty;
      }
    }]);
    return StatisticsStorage;
  }();
  
  var StatisticsSender = function () {
    function StatisticsSender(url, logger) {
      classCallCheck(this, StatisticsSender);
  
      this.url = url;
      this.logger = logger;
    }
  
    createClass(StatisticsSender, [{
      key: 'send',
      value: function send(data, errorHandler) {
        var logger = this.logger;
  
        if (navigator.onLine === false) {
          logger.debug("Offline, can't send");
          errorHandler();
          return;
        }
        logger.debug("Sending data to " + this.url);
  
        var req = new XMLHttpRequest();
        req.withCredentials = true;
        req.addEventListener("load", function () {
          // Stats sent, nothing more to do
          logger.debug("Response: " + req.responseText);
        });
        req.addEventListener("error", function () {
          logger.debug("Send failed");
          errorHandler();
        });
        req.addEventListener("abort", function () {
          logger.debug("Send aborted");
          errorHandler();
        });
        req.open("POST", this.url);
        req.setRequestHeader("Content-Type", "application/json");
        req.send(data);
      }
    }]);
    return StatisticsSender;
  }();
  
  var StatisticsLogger = function () {
    function StatisticsLogger(id) {
      classCallCheck(this, StatisticsLogger);
  
      this.id = id;
    }
  
    createClass(StatisticsLogger, [{
      key: '_isDebug',
      value: function _isDebug() {
        return localStorage.getItem("vaadin." + this.id + ".debug");
      }
    }, {
      key: 'debug',
      value: function debug(msg) {
        if (this._isDebug()) {
          console.info(this.id + ": " + msg);
        }
      }
    }]);
    return StatisticsLogger;
  }();
  
  var UsageStatistics = function () {
    function UsageStatistics() {
      classCallCheck(this, UsageStatistics);
  
      this.now = new Date();
      this.timeNow = this.now.getTime();
      this.gatherDelay = 10; // Delay between loading this file and gathering stats
      this.initialDelay = 24 * 60 * 60;
  
      this.logger = new StatisticsLogger("statistics");
      this.storage = new StatisticsStorage("vaadin.statistics.basket");
      this.gatherer = new StatisticsGatherer(this.logger);
      this.sender = new StatisticsSender("https://tools.vaadin.com/usage-stats/submit", this.logger);
    }
  
    createClass(UsageStatistics, [{
      key: 'maybeGatherAndSend',
      value: function maybeGatherAndSend() {
        var _this = this;
  
        if (localStorage.getItem(UsageStatistics.optOutKey)) {
          return;
        }
        this.gatherer.gather(this.storage);
        setTimeout(function () {
          _this.maybeSend();
        }, this.gatherDelay * 1000);
      }
    }, {
      key: 'lottery',
      value: function lottery() {
        return true;
      }
    }, {
      key: 'currentMonth',
      value: function currentMonth() {
        return this.now.getYear() * 12 + this.now.getMonth();
      }
    }, {
      key: 'maybeSend',
      value: function maybeSend() {
        var firstUse = Number(localStorage.getItem(UsageStatistics.firstUseKey));
        var monthProcessed = Number(localStorage.getItem(UsageStatistics.monthProcessedKey));
  
        if (!firstUse) {
          // Use a grace period to avoid interfering with tests, incognito mode etc
          firstUse = this.timeNow;
          localStorage.setItem(UsageStatistics.firstUseKey, firstUse);
        }
  
        if (this.timeNow < firstUse + this.initialDelay * 1000) {
          this.logger.debug("No statistics will be sent until the initial delay of " + this.initialDelay + "s has passed");
          return;
        }
        if (this.currentMonth() <= monthProcessed) {
          this.logger.debug("This month has already been processed");
          return;
        }
        localStorage.setItem(UsageStatistics.monthProcessedKey, this.currentMonth());
        // Use random sampling
        if (this.lottery()) {
          this.logger.debug("Congratulations, we have a winner!");
        } else {
          this.logger.debug("Sorry, no stats from you this time");
          return;
        }
  
        this.send();
      }
    }, {
      key: 'send',
      value: function send() {
        // Ensure we have the latest data
        this.gatherer.gather(this.storage);
  
        // Read, send and clean up
        var data = this.storage.read();
        data["firstUse"] = Number(localStorage.getItem(UsageStatistics.firstUseKey));
        data["usageStatisticsVersion"] = UsageStatistics.version;
        var info = 'This request contains usage statistics gathered from the application running in development mode. \n\nStatistics gathering is automatically disabled and excluded from production builds.\n\nFor details and to opt-out, see https://github.com/vaadin/vaadin-usage-statistics.\n\n\n\n';
        var self = this;
        this.sender.send(info + JSON.stringify(data), function () {
          // Revert the 'month processed' flag
          localStorage.setItem(UsageStatistics.monthProcessedKey, self.currentMonth() - 1);
        });
      }
    }], [{
      key: 'version',
      get: function get$1() {
        return '2.1.2';
      }
    }, {
      key: 'firstUseKey',
      get: function get$1() {
        return 'vaadin.statistics.firstuse';
      }
    }, {
      key: 'monthProcessedKey',
      get: function get$1() {
        return 'vaadin.statistics.monthProcessed';
      }
    }, {
      key: 'optOutKey',
      get: function get$1() {
        return 'vaadin.statistics.optout';
      }
    }]);
    return UsageStatistics;
  }();
  
  try {
    window.Vaadin = window.Vaadin || {};
    window.Vaadin.usageStatsChecker = window.Vaadin.usageStatsChecker || new UsageStatistics();
    window.Vaadin.usageStatsChecker.maybeGatherAndSend();
  } catch (e) {
    // Intentionally ignored as this is not a problem in the app being developed
  }
  
  }());
  
    vaadin-dev-mode:end **)

@vaadin/component-base/src/element-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/focus-utils.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/disabled-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/tabindex-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/browser-utils.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/slot-observer.js:
  (**
   * @license
   * Copyright (c) 2023 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/unique-id-utils.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/slot-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/tooltip-controller.js:
  (**
   * @license
   * Copyright (c) 2022 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/iron-list-core.js:
  (**
   * @license
   * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
   *)

@vaadin/component-base/src/virtualizer-iron-list-adapter.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-a11y-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-active-item-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-array-data-provider-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/gestures.js:
  (**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  *)

@vaadin/grid/src/vaadin-grid-column-reordering-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-column-resizing-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/data-provider-controller/helpers.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/data-provider-controller/cache.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/data-provider-controller/data-provider-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-data-provider-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-drag-and-drop-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-dynamic-columns-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-event-context-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-filter-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-keyboard-navigation-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-row-details-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/announce.js:
  (**
   * @license
   * Copyright (c) 2022 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/keyboard-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/active-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/focus-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/delegate-focus-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/aria-id-reference.js:
  (**
   * @license
   * Copyright (c) 2023 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/field-aria-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/focus-trap-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/focus-restoration-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/keyboard-direction-mixin.js:
  (**
   * @license
   * Copyright (c) 2022 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/dir-utils.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/a11y-base/src/list-mixin.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/resize-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-scroll-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-selection-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-sort-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-styling-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-styles.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-column-group-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-column-group.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/slot-styles-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/delegate-state-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/input-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/checked-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/component-base/src/slot-child-observe-controller.js:
  (**
   * @license
   * Copyright (c) 2022 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/error-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/helper-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/label-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/label-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/validate-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/field-mixin.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/input-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/field-base/src/labelled-input-controller.js:
  (**
   * @license
   * Copyright (c) 2021 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/checkbox/src/vaadin-checkbox-mixin.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/checkbox/src/vaadin-checkbox-styles.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/checkbox/src/vaadin-checkbox.js:
  (**
   * @license
   * Copyright (c) 2017 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-selection-column-base-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-selection-column-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-selection-column.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-sorter-mixin.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)

@vaadin/grid/src/vaadin-grid-sorter.js:
  (**
   * @license
   * Copyright (c) 2016 - 2024 Vaadin Ltd.
   * This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
   *)
*/
//# sourceMappingURL=@arcgis_core_widgets_FeatureTable.js.map
