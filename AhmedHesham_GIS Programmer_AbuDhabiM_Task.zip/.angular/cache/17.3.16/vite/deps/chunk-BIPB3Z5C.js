import {
  e as e2
} from "./chunk-JIF4AME4.js";
import {
  o2 as o
} from "./chunk-5CGYJOAB.js";
import {
  p as p2
} from "./chunk-XIGOQU7Q.js";
import {
  l
} from "./chunk-FUQQIRGM.js";
import {
  e as e4
} from "./chunk-YQI2KKR2.js";
import {
  d,
  e as e5
} from "./chunk-NM7OQTHS.js";
import {
  p
} from "./chunk-F3P6QAAR.js";
import {
  f
} from "./chunk-E4LVZZZC.js";
import {
  e as e3
} from "./chunk-AXAIOHJG.js";
import {
  i
} from "./chunk-J27IB6CR.js";
import {
  n
} from "./chunk-R3GS33FH.js";
import {
  e
} from "./chunk-7G5T4GB6.js";

// node_modules/@arcgis/core/chunks/ColorMaterial.glsl.js
function c(c2) {
  const m2 = new i(), { vertex: u, fragment: w, attributes: p3, varyings: f2 } = m2, { vvColor: h, hasVertexColors: C } = c2;
  return f(u, c2), m2.include(o, c2), m2.include(e2, c2), m2.include(l, c2), m2.include(e4, c2), w.include(p, c2), m2.include(p2, c2), m2.include(d, c2), p3.add(e.POSITION, "vec3"), h && p3.add(e.COLORFEATUREATTRIBUTE, "float"), C || f2.add("vColor", "vec4"), f2.add("vpos", "vec3"), u.uniforms.add(new e3("uColor", (e6) => e6.color)), u.main.add(n`
      vpos = position;
      forwardNormalizedVertexColor();
      forwardObjectAndLayerIdColor();

      ${C ? "vColor *= uColor;" : h ? "vColor = uColor * interpolateVVColor(colorFeatureAttribute);" : "vColor = uColor;"}
      forwardViewPosDepth((view * vec4(vpos, 1.0)).xyz);
      gl_Position = transformPosition(proj, view, vpos);`), w.include(e5), w.main.add(n`discardBySlice(vpos);
discardByTerrainDepth();
outputColorHighlightOID(vColor, vpos);`), m2;
}
var m = Object.freeze(Object.defineProperty({ __proto__: null, build: c }, Symbol.toStringTag, { value: "Module" }));

export {
  c,
  m
};
//# sourceMappingURL=chunk-BIPB3Z5C.js.map
