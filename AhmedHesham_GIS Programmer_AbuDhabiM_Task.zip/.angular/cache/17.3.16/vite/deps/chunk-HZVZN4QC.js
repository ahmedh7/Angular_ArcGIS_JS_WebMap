// node_modules/@arcgis/core/core/accessorSupport/layerContainerType.js
var a = /* @__PURE__ */ ((a2) => a2)(["operational-layers", "basemap", "ground"]);

export {
  a
};
//# sourceMappingURL=chunk-HZVZN4QC.js.map
