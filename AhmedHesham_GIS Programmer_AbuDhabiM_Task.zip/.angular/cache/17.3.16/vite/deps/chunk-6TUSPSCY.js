import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/Float4BindUniform.js
var o = class extends i {
  constructor(e, o2) {
    super(e, "vec4", a.Bind, (r, s) => r.setUniform4fv(e, o2(s)));
  }
};

export {
  o
};
//# sourceMappingURL=chunk-6TUSPSCY.js.map
