import {
  m
} from "./chunk-S7C6FBSD.js";
import {
  F
} from "./chunk-D5RIMQ7U.js";

// node_modules/@arcgis/core/symbols/support/unitConversionUtils.js
function e(r) {
  return !!r && null != m[r];
}
function n(r) {
  return 1 / (m[r] || 1);
}
function o() {
  const e2 = Object.keys(m);
  return F(e2, "decimal-degrees"), e2.sort(), e2;
}
var s = o();

export {
  e,
  n,
  s
};
//# sourceMappingURL=chunk-DEBJAVLQ.js.map
