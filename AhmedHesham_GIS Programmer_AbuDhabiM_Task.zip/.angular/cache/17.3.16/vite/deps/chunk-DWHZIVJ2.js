import {
  n
} from "./chunk-IHXPJZKB.js";
import {
  i
} from "./chunk-4VQUNH2Z.js";
import {
  a as a2
} from "./chunk-J3AJBXLW.js";
import {
  o
} from "./chunk-4JUCUHPE.js";
import {
  r as r2
} from "./chunk-P5ELECBN.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";

// node_modules/@arcgis/core/layers/support/FeatureType.js
var n2 = class extends a2.ClonableMixin(S) {
  constructor(o2) {
    super(o2), this.id = null, this.name = null, this.domains = null, this.templates = null;
  }
  readDomains(o2) {
    const r3 = {};
    for (const t of Object.keys(o2)) r3[t] = i(o2[t]);
    return r3;
  }
  writeDomains(o2, r3) {
    const t = {};
    for (const s of Object.keys(o2)) o2[s] && (t[s] = o2[s]?.toJSON());
    r3.domains = t;
  }
};
r([m({ json: { write: true } })], n2.prototype, "id", void 0), r([m({ json: { write: true } })], n2.prototype, "name", void 0), r([m({ json: { write: true } })], n2.prototype, "domains", void 0), r([o("domains")], n2.prototype, "readDomains", null), r([r2("domains")], n2.prototype, "writeDomains", null), r([m({ type: [n], json: { write: true } })], n2.prototype, "templates", void 0), n2 = r([a("esri.layers.support.FeatureType")], n2);
var c = n2;

export {
  c
};
//# sourceMappingURL=chunk-DWHZIVJ2.js.map
