import {
  i
} from "./chunk-LPID7LVC.js";
import {
  LitElement2 as LitElement,
  S,
  css,
  html,
  safeClassMap,
  setAttribute
} from "./chunk-NMBGL4CC.js";
import "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/components/calcite-carousel-item/customElement.js
var e = {
  container: "container",
  selected: "selected"
};
var r = css`:host{display:flex}.container{display:none;inline-size:var(--calcite-container-size-content-fluid)}:host([selected]) .container{display:block}:host([hidden]){display:none}[hidden]{display:none}`;
var d = class extends LitElement {
  constructor() {
    super(...arguments), this.guid = `calcite-carousel-item-${i()}`, this.selected = false;
  }
  static {
    this.properties = { label: 1, selected: 7 };
  }
  static {
    this.styles = r;
  }
  // #endregion
  // #region Rendering
  render() {
    const t = this.el.id || this.guid;
    return setAttribute(this.el, "id", t), html`<div .ariaLabel=${this.label} class=${safeClassMap({ [e.container]: true, [e.selected]: this.selected })} role=tabpanel><slot></slot></div>`;
  }
};
S("calcite-carousel-item", d);
export {
  d as CarouselItem
};
/*! Bundled license information:

@esri/calcite-components/dist/components/calcite-carousel-item/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=calcite-carousel-item-MHMMJZNJ.js.map
