import {
  i
} from "./chunk-L36PJSOJ.js";
import {
  E,
  R,
  g
} from "./chunk-LYJYKR5U.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";

// node_modules/@arcgis/core/views/2d/layers/graphics/HighlightGraphicContainer.js
var a2 = class extends i {
  get hasHighlight() {
    return this.children.some((r2) => r2.hasData);
  }
  renderChildren(r2) {
    this.attributeView.update(), r2.drawPhase === E.HIGHLIGHT && this.children.some((r3) => r3.hasData) && (super.renderChildren(r2), r2.context.setColorMask(true, true, true, true), g(r2, false, (r3) => {
      this._renderChildren(r3, R.Highlight);
    }));
  }
};
a2 = r([a("esri.views.2d.layers.graphics.HighlightGraphicContainer")], a2);
var h = a2;

export {
  h
};
//# sourceMappingURL=chunk-2HI3SSBI.js.map
