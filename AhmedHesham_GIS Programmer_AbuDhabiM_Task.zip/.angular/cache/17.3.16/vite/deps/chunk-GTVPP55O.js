import {
  n as n2,
  t
} from "./chunk-OFAEEHL4.js";
import {
  O,
  c
} from "./chunk-PPAPRIQT.js";
import {
  n2 as n
} from "./chunk-L7IGKLK6.js";
import {
  T
} from "./chunk-2NHACHL3.js";
import {
  a as a2,
  i
} from "./chunk-723TUEOK.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";

// node_modules/@arcgis/core/widgets/LayerList/support/layerListUtils.js
var n3 = { hide: "hide", hideChildren: "hide-children" };
var i2 = 10;
var e = 2;
function t2({ exclusive: n4, visible: i3, visibilityAppearance: e2 }) {
  const t4 = "checkbox" === e2;
  return i3 ? n4 ? "circle-f" : t4 ? "check-square-f" : "view-visible" : n4 ? "circle" : t4 ? "square" : "view-hide";
}
function r2({ connectionStatus: n4, publishing: i3 }) {
  return n4 ? "connected" === n4 ? "beacon" : "offline" : i3 ? "square" : "bullet-point";
}
function l(i3) {
  return i3?.listMode === n3.hideChildren;
}
function u(n4) {
  return n4?.listMode ?? void 0;
}
function o(n4) {
  return null != n4 && "minScale" in n4 && null != n4.minScale ? n4.minScale : void 0;
}
function c2(n4) {
  return null != n4 && "maxScale" in n4 && null != n4.maxScale ? n4.maxScale : void 0;
}
function a3(n4) {
  if (!n4) return "inherited";
  const i3 = S(x(n4) ? n4.layer : n4);
  return null != i3 ? i3 ? "independent" : "inherited" : "visibilityMode" in n4 && null != n4.visibilityMode ? n4.visibilityMode : "independent";
}
function s(n4) {
  n4?.removeMany(n4.filter((n5) => n5?.destroyed));
}
function d(n4) {
  if (n4 && (!("type" in n4) || "wmts" !== n4.type)) return "sublayers" in n4 ? "sublayers" : "layers" in n4 ? "layers" : void 0;
}
function f(n4, i3) {
  n4 && (n4.filterPredicate = i3 ? (n5) => i3(N(n5)) : void 0);
}
function y(n4) {
  const i3 = (n4?.layer && x(n4.layer) ? n4.layer.layer : void 0) ?? n4?.layer;
  return !!i3 && ("catalog" !== i3.type && (M(i3) ?? true));
}
function p(i3) {
  return u(i3) !== n3.hide;
}
function b(n4, i3) {
  if (!n4 || null == i3 || isNaN(i3)) return false;
  const e2 = o(n4), t4 = c2(n4), r3 = null != e2 && !isNaN(e2) && e2 > 0 && i3 > e2, l2 = null != t4 && !isNaN(t4) && t4 > 0 && i3 < t4;
  return r3 || l2;
}
function v(n4, i3) {
  n4?.sort((n5, e2) => {
    const t4 = "uid" in n5 ? i3.indexOf(n5.uid) : -1, r3 = "uid" in e2 ? i3.indexOf(e2.uid) : -1;
    return t4 > r3 ? -1 : t4 < r3 ? 1 : 0;
  });
}
function h(n4, i3) {
  const e2 = n4?.layer;
  if (!e2) return;
  const t4 = d(e2);
  if (!t4) return;
  let r3;
  "layers" === t4 && "layers" in e2 ? r3 = e2.layers : "sublayers" === t4 && "sublayers" in e2 && (r3 = e2.sublayers), v(r3, i3);
}
function m2(n4) {
  const i3 = n4?.layer;
  return i3 && "layers" in i3 ? i3.layers : null;
}
function x(n4) {
  return null != n4 && "layer" in n4 && null != n4.layer;
}
function S(n4) {
  const i3 = g(n4);
  return null != i3 && "supportsSublayerVisibility" in i3 ? i3.supportsSublayerVisibility : void 0;
}
function M(n4) {
  const i3 = g(n4);
  return null != i3 && "supportsDynamicLayers" in i3 ? i3.supportsDynamicLayers : void 0;
}
function g(n4) {
  return n4 && "capabilities" in n4 && null != n4.capabilities && "exportMap" in n4.capabilities ? n4.capabilities.exportMap : void 0;
}
function N(n4) {
  return n4?.["data-item"];
}
function q(n4) {
  return n4?.getAttribute("data-layer-type");
}
function w(n4) {
  const { children: i3, error: e2 } = n4, t4 = "incompatible" in n4 && n4.incompatible;
  return !!i3?.filter((n5) => !n5.hidden).length && !e2 && !t4;
}
function k(n4) {
  for (const i3 of n4) for (const n5 of i3) if ("button" === n5.type || "toggle" === n5.type) return n5;
}

// node_modules/@arcgis/core/widgets/LayerList/LayerListItem.js
var v2;
var _ = v2 = class extends O {
  constructor(e2) {
    super(e2), this.dragEnabled = false, this.listModeDisabled = false, this.parent = null, this.parentTitles = null, this.viewModel = null, this._onActionMenuOpen = (e3) => {
      this.item.actionsOpen = e3.currentTarget.open;
    }, this._setTooltipReference = (e3) => {
      this.onTooltipReferenceChange?.(this.item.layer?.uid, e3);
    }, this._removeTooltipReference = () => {
      this.onTooltipReferenceChange?.(this.item.layer?.uid, null);
    };
  }
  loadDependencies() {
    return c({ "action-group": () => import("./calcite-action-group-Z7FZK5L5.js"), "action-menu": () => import("./calcite-action-menu-JX2YQ753.js"), action: () => import("./calcite-action-QPIDLQ7A.js"), icon: () => import("./calcite-icon-TH7JL242.js"), "list-item": () => import("./calcite-list-item-6HCBKBPX.js"), list: () => import("./calcite-list-W42EHRHD.js"), notice: () => import("./calcite-notice-X7K5RWS6.js") });
  }
  render() {
    const e2 = this.parentTitles ?? [], { _title: t4, item: i3, activeItem: n4, selectionMode: o2, selectedItems: s2, messages: l2, parent: a4, css: r3 } = this, c3 = "visibleAtCurrentTimeExtent" in i3 && "layerInvisibleAtTime" in l2 && !i3.visibleAtCurrentTimeExtent ? `${t4} (${l2.layerInvisibleAtTime})` : "visibleAtCurrentScale" in i3 && "layerInvisibleAtScale" in l2 && !i3.visibleAtCurrentScale ? `${t4} (${l2.layerInvisibleAtScale})` : t4, d2 = "parent" in i3 && "catalog" === i3.parent?.layer?.type, { layer: p2 } = i3, m3 = "visibleAtCurrentScale" in i3 && !i3.visibleAtCurrentScale || "visibleAtCurrentTimeExtent" in i3 && !i3.visibleAtCurrentTimeExtent;
    return n("calcite-list-item", { afterCreate: (e3) => this._focusSelectedDragEl(e3, i3), afterUpdate: (e3) => this._focusSelectedDragEl(e3, i3), class: this.classes(r3.item, "itemActive" in r3 && { [r3.itemActive]: n4 === i3 }), "data-item": i3, "data-layer-id": p2?.id, dragDisabled: !i3.sortable || d2, id: p2?.uid, key: `list-item-${p2?.uid}`, label: t4, metadata: { parentTitles: e2, _title: t4 }, open: "open" in i3 && i3.open, selected: "none" !== o2 && s2.includes(i3), title: c3, unavailable: m3, value: p2?.uid, onCalciteListItemSelect: (e3) => "visible" in i3 && this._handleCalciteListItemSelect(e3, i3, a4), onCalciteListItemToggle: (e3) => "open" in i3 && this._handleCalciteListItemToggle(e3, i3) }, this._renderedCatalogFootprintIcon, this._renderedCatalogDynamicIcon, this._renderedItemStatus, this._renderedItemToggle, this._renderedCatalogSelectNode, this._renderedItemTemporaryIcon, this._renderedChildList, this._renderedItemMessage, this._renderedPanel, this._renderedPanelAction, this._renderedActions);
  }
  get _title() {
    const { messages: e2 } = this;
    return this.item.title || ("untitledTable" in e2 ? e2.untitledTable : e2.untitledLayer);
  }
  get _renderedItemStatus() {
    const { item: e2, parent: t4, visibleElements: i3, css: n4 } = this;
    if (!i3.statusIndicators) return null;
    const { publishing: o2 } = e2, s2 = "updating" in e2 && e2.updating && !t4, l2 = "connectionStatus" in e2 ? e2.connectionStatus : void 0, a4 = !!l2;
    return n("calcite-icon", { class: this.classes(n4.statusIndicator, { [n4.publishing]: o2 }, "updating" in n4 && { [n4.updating]: s2 }, "connectionStatus" in n4 && { [n4.connectionStatus]: a4 }, "connectionStatusConnected" in n4 && { [n4.connectionStatusConnected]: a4 && "connected" === l2 }), icon: r2({ connectionStatus: l2, publishing: o2 }), key: "layer-item-status", scale: "s", slot: "content-end" });
  }
  get _renderedItemTemporaryIcon() {
    const { item: e2, visibleElements: t4, css: i3 } = this, { layer: o2 } = e2, s2 = "temporaryLayerIndicators" in t4 && t4.temporaryLayerIndicators, l2 = "temporaryTableIndicators" in t4 && t4.temporaryTableIndicators, a4 = o2 && "persistenceEnabled" in o2 && (a2(o2) || !o2.persistenceEnabled);
    return (s2 || l2) && a4 ? n("calcite-icon", { class: i3.itemTemporaryIcon, icon: "temporary", key: "temporary-icon", scale: "s", slot: "content-start", title: this.messages.temporary }) : null;
  }
  get _renderedItemToggle() {
    const { item: e2, parent: t4, messages: i3, visibilityAppearance: n4, css: o2 } = this;
    if (!("visible" in e2 && "layerVisibility" in i3 && "visibleToggle" in o2 && n4)) return null;
    const { visible: s2 } = e2, l2 = this._getParentVisibilityMode(t4);
    if ("inherited" === l2) return null;
    const a4 = t2({ visible: s2, exclusive: "exclusive" === l2, visibilityAppearance: n4 }), r3 = "checkbox" === n4, d2 = i3.layerVisibility;
    return n("calcite-action", { appearance: "transparent", class: o2.visibleToggle, icon: r3 ? a4 : void 0, key: "visibility-toggle", onclick: () => this._toggleVisibility(e2, t4), scale: "s", slot: r3 ? "actions-start" : "actions-end", text: d2, title: d2 }, r3 ? null : n("calcite-icon", { class: this.classes({ [o2.visibleIcon]: "exclusive" !== l2 && s2 }), icon: a4, scale: "s" }));
  }
  get _renderedPanel() {
    const { panel: e2 } = this.item;
    return !e2?.open || e2.disabled || e2.flowEnabled ? null : n("div", { class: this.css.itemContentBottom, key: `content-panel-${e2.uid}`, slot: "content-bottom" }, e2.render());
  }
  get _renderedPanelAction() {
    const { panel: e2 } = this.item;
    if (!e2?.visible) return null;
    const { open: t4, title: i3, disabled: n4 } = e2;
    return n("calcite-action", { active: t4, appearance: "transparent", disabled: n4, icon: t(e2), key: `action-${e2.uid}`, onclick: () => this._togglePanel(e2), scale: "s", slot: "actions-end", text: i3 ?? "", title: i3 ?? void 0 }, this._renderFallbackIcon(e2));
  }
  get _renderedActions() {
    switch (this._actionsCount) {
      case 0:
        return null;
      case 1:
        return this._singleAction;
      default:
        return this._renderedActionMenu;
    }
  }
  get _renderedActionMenu() {
    const { item: e2, messagesCommon: t4 } = this, i3 = t4.options;
    return n("calcite-action-menu", { appearance: "transparent", key: "item-action-menu", label: t4.menu, open: e2.actionsOpen, overlayPositioning: "fixed", placement: "bottom-end", scale: "s", slot: "actions-end", onCalciteActionMenuOpen: this._onActionMenuOpen }, n("calcite-action", { appearance: "transparent", icon: "ellipsis", scale: "s", slot: "trigger", text: i3, title: i3 }), this._renderedActionMenuContent);
  }
  get _renderedActionMenuContent() {
    return this._filteredSections.toArray().map((e2) => n("calcite-action-group", { key: `action-section-${e2.uid}` }, e2.toArray().map((e3) => this._renderAction({ action: e3, textEnabled: true }))));
  }
  get _renderedCatalogFootprintIcon() {
    const { css: e2 } = this, t4 = this.item.layer, i3 = "catalog-footprint" === t4?.type, n4 = "sublayer" === t4?.type && i(t4, "footprints");
    return "itemCatalogIcon" in e2 && (i3 || n4) ? n("calcite-icon", { class: e2.itemCatalogIcon, icon: "footprint", key: "footprint", scale: "s", slot: "content-start" }) : null;
  }
  get _renderedCatalogDynamicIcon() {
    const { css: e2 } = this, t4 = this.item.layer, i3 = "catalog-dynamic-group" === t4?.type, n4 = "sublayer" === t4?.type && i(t4, "layers-in-view");
    return "itemCatalogIcon" in e2 && (i3 || n4) ? n("calcite-icon", { class: e2.itemCatalogIcon, icon: "catalog-dataset", key: "catalog-dataset", scale: "s", slot: "content-start" }) : null;
  }
  get _renderedCatalogSelectNode() {
    const { _title: e2, item: t4, visibleElements: i3 } = this;
    if (!("visible" in t4)) return;
    const { layer: n4 } = t4, o2 = "catalog-dynamic-group" === n4?.type;
    return "catalogLayerList" in i3 && i3.catalogLayerList && o2 ? n("calcite-action", { appearance: "transparent", disabled: !n4.visible, icon: "chevron-right", iconFlipRtl: true, onclick: () => this._triggerOnCatalogOpen(t4), scale: "s", slot: "actions-end", text: e2 }) : null;
  }
  get _renderedChildList() {
    const { dragEnabled: e2, item: t4, rootGroupUid: i3, listModeDisabled: n4, selectionMode: o2, displayMode: s2 } = this;
    if (!("children" in t4)) return;
    const l2 = [...this.parentTitles ?? [], t4.title], { children: a4, layer: r3 } = t4, c3 = "catalog-dynamic-group" !== r3?.type && w(t4), u2 = !n4 && l(r3), g2 = "group" === r3?.type, y2 = !u2 && !c3 && e2 && g2, b2 = !!e2 && ("childrenSortable" in t4 && t4.childrenSortable && y(t4));
    return c3 || y2 ? n("calcite-list", { canPull: (e3) => !!this.canMove && this.canMove(e3, "pull"), canPut: (e3) => !!this.canMove && this.canMove(e3, "put"), "data-item": t4, "data-layer-type": i3, displayMode: s2, dragEnabled: b2, group: g2 ? i3 : `${i3}-${r3?.uid}`, key: `child-list-${r3?.uid}`, label: t4.title, selectionAppearance: "border", selectionMode: o2 }, a4?.filter((e3) => !e3.hidden && (this.visibleElements.errors || !e3.error)).toArray().map((e3) => this._renderItem(e3, t4, l2)), this._renderedTablesItem) : null;
  }
  get _hasTables() {
    const { layerTablesEnabled: e2 } = this, t4 = this.item.layer;
    if (!e2 || !t4) return false;
    switch (t4.type) {
      case "knowledge-graph":
        return e2.includes(t4.type) && "tables" in t4 && !!t4.tables?.length;
      case "map-image":
      case "tile":
        return e2.includes(t4.type) && "subtables" in t4 && !!t4.subtables?.length;
      default:
        return false;
    }
  }
  get _renderedTablesItem() {
    const { item: e2, messages: t4, css: i3 } = this, { layer: n4 } = e2;
    return "itemTableIcon" in i3 && "visible" in e2 && "tables" in t4 && this._hasTables ? n("calcite-list-item", { class: i3.item, "data-layer-id": n4?.id, dragDisabled: true, key: `list-item-table-list-tables-${n4?.uid}`, label: t4.tables, title: t4.tables, onCalciteListItemSelect: () => this._triggerOnTablesOpen(e2) }, n("calcite-icon", { class: i3.itemTableIcon, icon: "table", scale: "s", slot: "content-start" }), n("calcite-icon", { flipRtl: true, icon: "chevron-right", scale: "s", slot: "content-end" })) : null;
  }
  get _renderedItemMessage() {
    const { item: e2, messages: t4, css: i3 } = this;
    return e2.error ? n("div", { class: i3.itemMessage, key: "esri-layer-list__error", slot: "content-bottom" }, n("calcite-notice", { icon: "exclamation-mark-triangle", kind: "warning", open: true, scale: "s", width: "full" }, n("div", { slot: "message" }, "tableError" in t4 ? t4.tableError : t4.layerError))) : "incompatible" in e2 && e2.incompatible && "layerIncompatible" in t4 ? n("div", { class: i3.itemMessage, key: "esri-layer-list__incompatible", slot: "content-bottom" }, n("calcite-notice", { afterCreate: this._setTooltipReference, afterRemoved: this._removeTooltipReference, bind: this, icon: "exclamation-mark-triangle", kind: "warning", open: true, scale: "s", tabIndex: 0, width: "full" }, n("div", { slot: "message" }, t4.layerIncompatible))) : null;
  }
  get _singleAction() {
    return this._renderAction({ action: k(this._filteredSections), textEnabled: false });
  }
  get _filteredSections() {
    return this.item.actionsSections.map((e2) => e2.filter((e3) => e3.visible));
  }
  get _actionsCount() {
    return this.item.actionsSections.reduce((e2, t4) => e2 + t4.length, 0);
  }
  _renderAction(e2) {
    const { item: t4 } = this, { action: i3, textEnabled: n4 } = e2;
    if (!i3) return null;
    const { active: o2, disabled: l2, title: a4, type: r3, indicator: c3 } = i3;
    return n("calcite-action", { active: "toggle" === r3 && i3.value, appearance: "transparent", "data-action-id": i3.id, disabled: l2, icon: t(i3), indicator: c3, key: `action-${i3.uid}`, loading: o2, onclick: () => this._triggerAction(t4, i3), scale: "s", slot: n4 ? void 0 : "actions-end", text: a4 ?? "", textEnabled: n4, title: a4 ?? void 0 }, this._renderFallbackIcon(i3));
  }
  _renderFallbackIcon(e2) {
    const { css: t4 } = this, { className: i3, icon: n4 } = e2;
    if (n4) return null;
    const o2 = "image" in e2 ? e2.image : void 0, s2 = { [t4.itemActionIcon]: !!i3, [t4.itemActionImage]: !!o2 };
    return i3 && (s2[i3] = true), o2 || i3 ? n("span", { "aria-hidden": "true", class: this.classes(t4.itemActionIcon, s2), key: "icon", styles: n2(o2) }) : null;
  }
  _renderItem(e2, t4, i3 = []) {
    return n(v2, { activeItem: this.activeItem, canMove: this.canMove, css: this.css, displayMode: this.displayMode, dragEnabled: this.dragEnabled, item: e2, key: `layerListItem-${e2.layer?.uid}`, layerTablesEnabled: this.layerTablesEnabled, listModeDisabled: this.listModeDisabled, messages: this.messages, messagesCommon: this.messagesCommon, parent: t4, parentTitles: i3, rootGroupUid: this.rootGroupUid, selectedDragItemLayerUid: this.selectedDragItemLayerUid, selectedItems: this.selectedItems, selectionMode: this.selectionMode, visibilityAppearance: this.visibilityAppearance, visibleElements: this.visibleElements, onAction: this.onAction, onCatalogOpen: this.onCatalogOpen, onPanelOpen: this.onPanelOpen, onSelectedDragItemLayerUidChange: this.onSelectedDragItemLayerUidChange, onTablesOpen: this.onTablesOpen, onTooltipReferenceChange: this.onTooltipReferenceChange });
  }
  _triggerAction(e2, t4) {
    t4 && e2 && ("toggle" === t4.type && (t4.value = !t4.value), this.onAction(t4, e2));
  }
  _triggerOnTablesOpen(e2) {
    e2 && this.onTablesOpen && this.onTablesOpen(e2);
  }
  _triggerOnCatalogOpen(e2) {
    e2 && this.onCatalogOpen?.(e2);
  }
  _focusSelectedDragEl(e2, t4) {
    this.selectedDragItemLayerUid === t4.layer?.uid && (T(e2), this.onSelectedDragItemLayerUidChange?.(null));
  }
  _handleCalciteListItemToggle(e2, t4) {
    e2.stopPropagation(), t4.open = e2.target.open;
  }
  _getParentVisibilityMode(e2) {
    return e2 && "visibilityMode" in e2 ? e2.visibilityMode : null;
  }
  _handleCalciteListItemSelect(e2, t4, i3) {
    if (N(e2.target) !== t4) return;
    const n4 = this._getParentVisibilityMode(i3);
    "none" === this.selectionMode && "inherited" !== n4 && this._toggleVisibility(t4, i3);
  }
  _togglePanel(e2) {
    e2.open = !e2.open, e2.open && this.onPanelOpen();
  }
  _toggleVisibility(e2, t4) {
    if (!e2 || !("visible" in e2)) return;
    "exclusive" === this._getParentVisibilityMode(t4) && e2.visible || (e2.visible = !e2.visible);
  }
};
_.vnodeSelector = "calcite-list-item", r([m()], _.prototype, "activeItem", void 0), r([m()], _.prototype, "canMove", void 0), r([m()], _.prototype, "css", void 0), r([m()], _.prototype, "displayMode", void 0), r([m()], _.prototype, "dragEnabled", void 0), r([m()], _.prototype, "item", void 0), r([m()], _.prototype, "layerTablesEnabled", void 0), r([m()], _.prototype, "listModeDisabled", void 0), r([m()], _.prototype, "messages", void 0), r([m()], _.prototype, "messagesCommon", void 0), r([m()], _.prototype, "onAction", void 0), r([m()], _.prototype, "onPanelOpen", void 0), r([m()], _.prototype, "onCatalogOpen", void 0), r([m()], _.prototype, "onTablesOpen", void 0), r([m()], _.prototype, "onSelectedDragItemLayerUidChange", void 0), r([m()], _.prototype, "onTooltipReferenceChange", void 0), r([m()], _.prototype, "parent", void 0), r([m()], _.prototype, "parentTitles", void 0), r([m()], _.prototype, "rootGroupUid", void 0), r([m()], _.prototype, "selectionMode", void 0), r([m()], _.prototype, "selectedItems", void 0), r([m()], _.prototype, "selectedDragItemLayerUid", void 0), r([m()], _.prototype, "visibleElements", void 0), r([m()], _.prototype, "visibilityAppearance", void 0), r([m()], _.prototype, "_title", null), r([m()], _.prototype, "_renderedItemStatus", null), r([m()], _.prototype, "_renderedItemTemporaryIcon", null), r([m()], _.prototype, "_renderedItemToggle", null), r([m()], _.prototype, "_renderedPanel", null), r([m()], _.prototype, "_renderedPanelAction", null), r([m()], _.prototype, "_renderedActions", null), r([m()], _.prototype, "_renderedActionMenu", null), r([m()], _.prototype, "_renderedActionMenuContent", null), r([m()], _.prototype, "_renderedCatalogFootprintIcon", null), r([m()], _.prototype, "_renderedCatalogDynamicIcon", null), r([m()], _.prototype, "_renderedCatalogSelectNode", null), r([m()], _.prototype, "_renderedChildList", null), r([m()], _.prototype, "_hasTables", null), r([m()], _.prototype, "_renderedTablesItem", null), r([m()], _.prototype, "_renderedItemMessage", null), r([m()], _.prototype, "_singleAction", null), r([m()], _.prototype, "_filteredSections", null), r([m()], _.prototype, "_actionsCount", null), _ = v2 = r([a("esri.widgets.LayerList.LayerListItem")], _);
var I = _;

// node_modules/@arcgis/core/widgets/support/listUtils.js
var t3 = ["label", "description", "metadata"];

export {
  i2 as i,
  e,
  u,
  a3 as a,
  s,
  d,
  f,
  p,
  b,
  v,
  h,
  m2 as m,
  x,
  N,
  q,
  I,
  t3 as t
};
//# sourceMappingURL=chunk-GTVPP55O.js.map
