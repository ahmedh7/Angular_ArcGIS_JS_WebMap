import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/Float4PassUniform.js
var e = class extends i {
  constructor(s, e2) {
    super(s, "vec4", a.Pass, (r, o, t) => r.setUniform4fv(s, e2(o, t)));
  }
};

export {
  e
};
//# sourceMappingURL=chunk-AXAIOHJG.js.map
