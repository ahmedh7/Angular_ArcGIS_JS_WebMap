// node_modules/@arcgis/core/symbols/support/webStyleAcceptedFormats.js
var e = ["web-gltf", "web", "cim"];

export {
  e
};
//# sourceMappingURL=chunk-EQ7BFYDM.js.map
