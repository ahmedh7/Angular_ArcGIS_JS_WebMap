import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";

// node_modules/@arcgis/core/views/support/debugFlags.js
var e = class extends g {
  constructor() {
    super(...arguments), this.SCHEDULER_LOG_SLOW_TASKS = false, this.FEATURE_SERVICE_SNAPPING_SOURCE_TILE_TREE_SHOW_TILES = false;
  }
};
r([m()], e.prototype, "SCHEDULER_LOG_SLOW_TASKS", void 0), r([m()], e.prototype, "FEATURE_SERVICE_SNAPPING_SOURCE_TILE_TREE_SHOW_TILES", void 0), e = r([a("esri.views.support.debugFlags")], e);
var E = new e();

export {
  E
};
//# sourceMappingURL=chunk-3UR6P3OM.js.map
