// node_modules/@arcgis/core/views/3d/webgl-engine/lib/VertexAttribute.js
var e;
function E(E2) {
  return E2 === e.POSITION;
}
!function(e2) {
  e2.POSITION = "position", e2.NORMAL = "normal", e2.NORMALCOMPRESSED = "normalCompressed", e2.UV0 = "uv0", e2.COLOR = "color", e2.SYMBOLCOLOR = "symbolColor", e2.SIZE = "size", e2.ROTATION = "rotation", e2.TANGENT = "tangent", e2.OFFSET = "offset", e2.PERSPECTIVEDIVIDE = "perspectiveDivide", e2.CENTEROFFSETANDDISTANCE = "centerOffsetAndDistance", e2.LENGTH = "length", e2.PREVPOSITION = "prevPosition", e2.NEXTPOSITION = "nextPosition", e2.SUBDIVISIONFACTOR = "subdivisionFactor", e2.COLORFEATUREATTRIBUTE = "colorFeatureAttribute", e2.SIZEFEATUREATTRIBUTE = "sizeFeatureAttribute", e2.OPACITYFEATUREATTRIBUTE = "opacityFeatureAttribute", e2.DISTANCETOSTART = "distanceToStart", e2.UVMAPSPACE = "uvMapSpace", e2.BOUNDINGRECT = "boundingRect", e2.UVREGION = "uvRegion", e2.PROFILERIGHT = "profileRight", e2.PROFILEUP = "profileUp", e2.PROFILEVERTEXANDNORMAL = "profileVertexAndNormal", e2.FEATUREVALUE = "featureValue", e2.INSTANCEMODELORIGINHI = "instanceModelOriginHi", e2.INSTANCEMODELORIGINLO = "instanceModelOriginLo", e2.INSTANCEMODEL = "instanceModel", e2.INSTANCEMODELNORMAL = "instanceModelNormal", e2.INSTANCECOLOR = "instanceColor", e2.INSTANCEFEATUREATTRIBUTE = "instanceFeatureAttribute", e2.LOCALTRANSFORM = "localTransform", e2.GLOBALTRANSFORM = "globalTransform", e2.BOUNDINGSPHERE = "boundingSphere", e2.MODELORIGIN = "modelOrigin", e2.MODELSCALEFACTORS = "modelScaleFactors", e2.FEATUREATTRIBUTE = "featureAttribute", e2.STATE = "state", e2.LODLEVEL = "lodLevel", e2.POSITION0 = "position0", e2.POSITION1 = "position1", e2.NORMAL2COMPRESSED = "normal2Compressed", e2.COMPONENTINDEX = "componentIndex", e2.VARIANTOFFSET = "variantOffset", e2.VARIANTSTROKE = "variantStroke", e2.VARIANTEXTENSION = "variantExtension", e2.SIDENESS = "sideness", e2.START = "start", e2.END = "end", e2.UP = "up", e2.START_UP = "startUp", e2.END_UP = "endUp", e2.EXTRUDE = "extrude", e2.OBJECTANDLAYERIDCOLOR = "objectAndLayerIdColor", e2.INSTANCEOBJECTANDLAYERIDCOLOR = "instanceObjectAndLayerIdColor";
}(e || (e = {}));

export {
  e,
  E
};
//# sourceMappingURL=chunk-7G5T4GB6.js.map
