import {
  p
} from "./chunk-FFDJVTNW.js";
import {
  n3 as n
} from "./chunk-O4NL4QZF.js";
import {
  E
} from "./chunk-LYJYKR5U.js";

// node_modules/@arcgis/core/views/2d/engine/BitmapContainer.js
var r = class extends n {
  constructor() {
    super(...arguments), this._hasCrossfade = false, this._bitmapTechnique = null;
  }
  get requiresDedicatedFBO() {
    return super.requiresDedicatedFBO || this._hasCrossfade;
  }
  beforeRender(e) {
    super.beforeRender(e), this._manageFade();
  }
  onAttach() {
    super.onAttach(), this._bitmapTechnique = new p();
  }
  onDetach() {
    super.onDetach(), this._bitmapTechnique?.shutdown(), this._bitmapTechnique = null;
  }
  renderChildren(i) {
    super.renderChildren(i), this.visible && i.drawPhase === E.MAP && null != this._bitmapTechnique && this._bitmapTechnique.render(i, { bitmaps: this.children });
  }
  _manageFade() {
    this.children.reduce((e, i) => e + (i.inFadeTransition ? 1 : 0), 0) >= 2 ? (this.children.forEach((e) => e.blendFunction = "additive"), this._hasCrossfade = true) : (this.children.forEach((e) => e.blendFunction = "standard"), this._hasCrossfade = false);
  }
};

export {
  r
};
//# sourceMappingURL=chunk-GV6HQUWZ.js.map
