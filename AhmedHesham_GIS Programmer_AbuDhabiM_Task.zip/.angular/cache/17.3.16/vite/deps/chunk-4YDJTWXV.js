import {
  C
} from "./chunk-YKYNKOQZ.js";

// node_modules/@arcgis/core/arcade/ArcadePortal.js
var t = class extends C {
  constructor(s) {
    super(), this.declaredClass = "esri.arcade.Portal", this.immutable = false, this.setField("url", s), this.immutable = true;
  }
};

export {
  t
};
//# sourceMappingURL=chunk-4YDJTWXV.js.map
