import {
  n
} from "./chunk-QWGWNAMQ.js";
import {
  e
} from "./chunk-RBWHFXAQ.js";
import "./chunk-TZZB63K4.js";
import "./chunk-GFDFTTQ5.js";
import "./chunk-FQS4PHWP.js";
import "./chunk-IXY5PUGT.js";
import "./chunk-K6AAVT2T.js";
import {
  debounce_default
} from "./chunk-YANRGXVA.js";
import "./chunk-DK4MBEKC.js";
import "./chunk-7BYAEWQF.js";
import "./chunk-6EA7357B.js";
import "./chunk-ZNGJTAZC.js";
import "./chunk-GYMHVFJE.js";
import "./chunk-JP6NVURN.js";
import {
  m
} from "./chunk-JNDPOHLO.js";
import "./chunk-3EHTPQND.js";
import "./chunk-4OCBID5S.js";
import {
  ref
} from "./chunk-LPETJQKI.js";
import "./chunk-EJFZYJAF.js";
import {
  s
} from "./chunk-FJ5QMW6O.js";
import {
  b
} from "./chunk-U3H4S3UY.js";
import {
  gt,
  mt,
  ot,
  ut
} from "./chunk-67TGT3ZY.js";
import "./chunk-LPID7LVC.js";
import {
  LitElement2 as LitElement,
  M,
  S,
  createEvent,
  css,
  html,
  nothing,
  safeClassMap
} from "./chunk-NMBGL4CC.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/chunks/ExpandToggle.js
var I = 2;
var g = (t) => t.reduce((o, e2) => o + e2, 0) / t.length;
var D = (t) => {
  const o = t.filter((n2) => n2.slot !== n.menuActions), e2 = o?.length;
  return {
    actionWidth: e2 ? g(o.map((n2) => n2.clientWidth || 0)) : 0,
    actionHeight: e2 ? g(o.map((n2) => n2.clientHeight || 0)) : 0
  };
};
var N = ({
  width: t,
  actionWidth: o,
  layout: e2,
  height: n2,
  actionHeight: i,
  groupCount: r
}) => {
  const c = e2 === "horizontal" ? t : n2, s2 = e2 === "horizontal" ? o : i;
  return Math.floor((c - r * I) / s2);
};
var H = ({
  layout: t,
  actionCount: o,
  actionWidth: e2,
  width: n2,
  actionHeight: i,
  height: r,
  groupCount: c
}) => Math.max(o - N({ width: n2, actionWidth: e2, layout: t, height: r, actionHeight: i, groupCount: c }), 0);
var A = (t) => Array.from(t.querySelectorAll("calcite-action")).filter(
  (o) => o.closest("calcite-action-menu") ? o.slot === e.trigger : true
);
var k = ({
  actionGroups: t,
  expanded: o,
  overflowCount: e2
}) => {
  let n2 = e2;
  t.reverse().forEach((i) => {
    let r = 0;
    const c = A(i).reverse();
    c.forEach((s2) => {
      s2.slot === n.menuActions && (s2.removeAttribute("slot"), s2.textEnabled = o);
    }), n2 > 0 && c.some((s2) => (c.filter((f) => !f.slot).length > 1 && c.length > 2 && !s2.closest("calcite-action-menu") && (s2.textEnabled = true, s2.setAttribute("slot", n.menuActions), r++, r > 1 && n2--), n2 < 1)), i.manager.component.requestUpdate();
  });
};
var v = {
  chevronsLeft: "chevrons-left",
  chevronsRight: "chevrons-right"
};
function O(t, o) {
  return t || o.closest("calcite-shell-panel")?.position || "start";
}
function B({ el: t, expanded: o }) {
  A(t).filter((e2) => e2.slot !== n.menuActions).forEach((e2) => e2.textEnabled = o), t.querySelectorAll("calcite-action-group, calcite-action-menu").forEach((e2) => e2.expanded = o);
}
var P = ({ tooltip: t, referenceElement: o, expanded: e2, ref: n2 }) => (t && (t.referenceElement = !e2 && o ? o : null), n2 && n2(o), o);
var G = ({ expanded: t, expandText: o, collapseText: e2, expandLabel: n2, collapseLabel: i, toggle: r, el: c, position: s2, tooltip: u, ref: f, scale: d }) => {
  const x = gt(c) === "rtl", h2 = t ? e2 : o, S2 = t ? i : n2, l = [v.chevronsLeft, v.chevronsRight];
  x && l.reverse();
  const m2 = O(s2, c) === "end", p = m2 ? l[1] : l[0], E = m2 ? l[0] : l[1];
  return html`<calcite-action .icon=${t ? p : E} id=expand-toggle .label=${S2} @click=${r} .scale=${d} .text=${h2} .textEnabled=${t} title=${(!t && !u ? h2 : null) ?? nothing} ${ref(($) => P({ tooltip: u, referenceElement: $, expanded: t, ref: f }))}></calcite-action>`;
};

// node_modules/@esri/calcite-components/dist/components/calcite-action-bar/customElement.js
var k2 = {
  actionGroupEnd: "action-group--end"
};
var h = {
  actionsEnd: "actions-end",
  bottomActions: "bottom-actions",
  expandTooltip: "expand-tooltip"
};
var P2 = css`:host{box-sizing:border-box;background-color:var(--calcite-color-foreground-1);color:var(--calcite-color-text-2);font-size:var(--calcite-font-size--1)}:host *{box-sizing:border-box}:host{pointer-events:auto;display:inline-flex;align-self:stretch;gap:var(--calcite-action-bar-items-space, 0)}:host([layout=vertical]){flex-direction:column}:host([layout=vertical]):host([overflow-actions-disabled]){overflow-y:auto}:host([layout=vertical]):host([expanded]){max-inline-size:var(--calcite-action-bar-expanded-max-width, auto)}:host([layout=vertical]) .action-group--end{margin-block-start:auto}:host([layout=vertical]) ::slotted(calcite-action-group:not(:last-of-type)){border-block-end-width:var(--calcite-border-width-sm)}:host([layout=horizontal]){flex-direction:row}:host([layout=horizontal]):host([overflow-actions-disabled]){overflow-x:auto}:host([layout=horizontal]) .action-group--end{margin-inline-start:auto}:host([layout=horizontal]) ::slotted(calcite-action-group:not(:last-of-type)){border-inline-end-width:var(--calcite-border-width-sm)}.action-group--end{justify-content:flex-end}:host([hidden]){display:none}[hidden]{display:none}`;
var U = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.mutationObserver = b("mutation", () => this.mutationObserverHandler()), this.resize = debounce_default(({ width: t, height: o }) => {
      const { el: e2, expanded: l, expandDisabled: n2, layout: i, overflowActionsDisabled: r, actionGroups: s2 } = this;
      if (r || i === "vertical" && !o || i === "horizontal" && !t)
        return;
      const a = A(e2), c = n2 ? a.length : a.length + 1;
      this.updateGroups();
      const d = this.hasActionsEnd || this.hasBottomActions || !n2 ? s2.length + 1 : s2.length, { actionHeight: b2, actionWidth: m2 } = D(a), g2 = H({
        layout: i,
        actionCount: c,
        actionHeight: b2,
        actionWidth: m2,
        height: o,
        width: t,
        groupCount: d
      });
      k({
        actionGroups: s2,
        expanded: l,
        overflowCount: g2
      });
    }, M.resize), this.resizeHandler = (t) => {
      const { width: o, height: e2 } = t.contentRect;
      this.resize({ width: o, height: e2 });
    }, this.resizeObserver = b("resize", (t) => this.resizeHandlerEntries(t)), this.toggleExpand = () => {
      this.expanded = !this.expanded, this.calciteActionBarToggle.emit();
    }, this.hasActionsEnd = false, this.hasBottomActions = false, this.expandDisabled = false, this.expanded = false, this.layout = "vertical", this.messages = s(), this.overflowActionsDisabled = false, this.overlayPositioning = "absolute", this.scale = "m", this.calciteActionBarToggle = createEvent({ cancelable: false }), this.listen("calciteActionMenuOpen", this.actionMenuOpenHandler);
  }
  static {
    this.properties = { expandTooltip: 16, hasActionsEnd: 16, hasBottomActions: 16, actionsEndGroupLabel: 1, expandDisabled: 7, expanded: 7, layout: 3, messageOverrides: 0, overflowActionsDisabled: 7, overlayPositioning: 3, position: 3, scale: 3 };
  }
  static {
    this.styles = P2;
  }
  // #endregion
  // #region Public Methods
  /**
   * Overflows actions that won't fit into menus.
   *
   * @private
   */
  overflowActions() {
    return __async(this, null, function* () {
      this.resize({ width: this.el.clientWidth, height: this.el.clientHeight });
    });
  }
  /** Sets focus on the component's first focusable element. */
  setFocus() {
    return __async(this, null, function* () {
      yield m(this), mt(this.el);
    });
  }
  connectedCallback() {
    super.connectedCallback(), this.updateGroups(), this.overflowActions(), this.mutationObserver?.observe(this.el, { childList: true, subtree: true }), this.overflowActionsDisabledHandler(this.overflowActionsDisabled);
  }
  willUpdate(t) {
    t.has("expandDisabled") && (this.hasUpdated || this.expandDisabled !== false) && this.overflowActions(), t.has("expanded") && this.hasUpdated && this.expandedHandler(), t.has("layout") && (this.hasUpdated || this.layout !== "vertical") && this.updateGroups(), t.has("overflowActionsDisabled") && (this.hasUpdated || this.overflowActionsDisabled !== false) && this.overflowActionsDisabledHandler(this.overflowActionsDisabled);
  }
  loaded() {
    this.overflowActions();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.mutationObserver?.disconnect(), this.resizeObserver?.disconnect();
  }
  // #endregion
  // #region Private Methods
  expandedHandler() {
    const { el: t, expanded: o } = this;
    B({ el: t, expanded: o }), this.overflowActions();
  }
  overflowActionsDisabledHandler(t) {
    if (t) {
      this.resizeObserver?.disconnect();
      return;
    }
    this.resizeObserver?.observe(this.el), this.overflowActions();
  }
  actionMenuOpenHandler(t) {
    if (t.target.menuOpen) {
      const o = t.composedPath();
      this.actionGroups?.forEach((e2) => {
        o.includes(e2) || (e2.menuOpen = false);
      });
    }
  }
  mutationObserverHandler() {
    this.updateGroups(), this.overflowActions();
  }
  resizeHandlerEntries(t) {
    t.forEach(this.resizeHandler);
  }
  updateGroups() {
    const t = Array.from(this.el.querySelectorAll("calcite-action-group"));
    this.actionGroups = t, this.setGroupLayout(t);
  }
  setGroupLayout(t) {
    t.forEach((o) => o.layout = this.layout);
  }
  handleDefaultSlotChange() {
    this.updateGroups();
  }
  handleActionsEndSlotChange(t) {
    this.hasActionsEnd = ot(t);
  }
  handleBottomActionsSlotChange(t) {
    this.hasBottomActions = ot(t);
  }
  handleTooltipSlotChange(t) {
    const o = ut(t).filter((e2) => e2?.matches("calcite-tooltip"));
    this.expandTooltip = o[0];
  }
  // #endregion
  // #region Rendering
  renderBottomActionGroup() {
    const { expanded: t, expandDisabled: o, el: e2, position: l, toggleExpand: n2, scale: i, layout: r, messages: s2, actionsEndGroupLabel: a, overlayPositioning: c } = this, d = o ? null : G({ collapseLabel: s2.collapseLabel, collapseText: s2.collapse, el: e2, expandLabel: s2.expandLabel, expandText: s2.expand, expanded: t, position: l, scale: i, toggle: n2, tooltip: this.expandTooltip });
    return html`<calcite-action-group class=${safeClassMap(k2.actionGroupEnd)} .hidden=${this.expandDisabled && !(this.hasActionsEnd || this.hasBottomActions)} .label=${a} .layout=${r} .overlayPositioning=${c} .scale=${i}><slot name=${h.actionsEnd} @slotchange=${this.handleActionsEndSlotChange}></slot><slot name=${h.bottomActions} @slotchange=${this.handleBottomActionsSlotChange}></slot><slot name=${h.expandTooltip} @slotchange=${this.handleTooltipSlotChange}></slot>${d}</calcite-action-group>`;
  }
  render() {
    return html`<slot @slotchange=${this.handleDefaultSlotChange}></slot>${this.renderBottomActionGroup()}`;
  }
};
S("calcite-action-bar", U);
export {
  U as ActionBar
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/ExpandToggle.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)

@esri/calcite-components/dist/components/calcite-action-bar/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=calcite-action-bar-ENGXQHJA.js.map
