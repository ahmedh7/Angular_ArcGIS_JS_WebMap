import {
  e,
  n,
  o,
  t
} from "./chunk-7PVOLFAH.js";
import {
  DateTime
} from "./chunk-S3UZ5KFQ.js";
import {
  p,
  r
} from "./chunk-KVMARQAF.js";
import {
  i
} from "./chunk-TAT7XC7M.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/intl/date.js
var s2 = { year: void 0, month: void 0, day: void 0, weekday: void 0 };
var l = { hour: void 0, minute: void 0, second: void 0 };
var y = { timeZone: n };
var d = { year: "numeric", month: "numeric", day: "numeric" };
var g = { year: "numeric", month: "long", day: "numeric" };
var u = { year: "numeric", month: "short", day: "numeric" };
var c = { year: "numeric", month: "long", weekday: "long", day: "numeric" };
var D = { hour: "numeric", minute: "numeric" };
var T = __spreadProps(__spreadValues({}, D), { second: "numeric" });
var f = { hourCycle: "h23" };
var S = __spreadValues(__spreadValues({}, D), f);
var L = __spreadValues(__spreadValues({}, T), f);
var M = { "short-date": d, "short-date-short-time": __spreadValues(__spreadValues({}, d), D), "short-date-short-time-24": __spreadValues(__spreadValues({}, d), S), "short-date-long-time": __spreadValues(__spreadValues({}, d), T), "short-date-long-time-24": __spreadValues(__spreadValues({}, d), L), "short-date-le": d, "short-date-le-short-time": __spreadValues(__spreadValues({}, d), D), "short-date-le-short-time-24": __spreadValues(__spreadValues({}, d), S), "short-date-le-long-time": __spreadValues(__spreadValues({}, d), T), "short-date-le-long-time-24": __spreadValues(__spreadValues({}, d), L), "long-month-day-year": g, "long-month-day-year-short-time": __spreadValues(__spreadValues({}, g), D), "long-month-day-year-short-time-24": __spreadValues(__spreadValues({}, g), S), "long-month-day-year-long-time": __spreadValues(__spreadValues({}, g), T), "long-month-day-year-long-time-24": __spreadValues(__spreadValues({}, g), L), "day-short-month-year": u, "day-short-month-year-short-time": __spreadValues(__spreadValues({}, u), D), "day-short-month-year-short-time-24": __spreadValues(__spreadValues({}, u), S), "day-short-month-year-long-time": __spreadValues(__spreadValues({}, u), T), "day-short-month-year-long-time-24": __spreadValues(__spreadValues({}, u), L), "long-date": c, "long-date-short-time": __spreadValues(__spreadValues({}, c), D), "long-date-short-time-24": __spreadValues(__spreadValues({}, c), S), "long-date-long-time": __spreadValues(__spreadValues({}, c), T), "long-date-long-time-24": __spreadValues(__spreadValues({}, c), L), "long-month-year": { month: "long", year: "numeric" }, "short-month-year": { month: "short", year: "numeric" }, year: { year: "numeric" }, "short-time": D, "long-time": T };
var Y = i()({ shortDate: "short-date", shortDateShortTime: "short-date-short-time", shortDateShortTime24: "short-date-short-time-24", shortDateLongTime: "short-date-long-time", shortDateLongTime24: "short-date-long-time-24", shortDateLE: "short-date-le", shortDateLEShortTime: "short-date-le-short-time", shortDateLEShortTime24: "short-date-le-short-time-24", shortDateLELongTime: "short-date-le-long-time", shortDateLELongTime24: "short-date-le-long-time-24", longMonthDayYear: "long-month-day-year", longMonthDayYearShortTime: "long-month-day-year-short-time", longMonthDayYearShortTime24: "long-month-day-year-short-time-24", longMonthDayYearLongTime: "long-month-day-year-long-time", longMonthDayYearLongTime24: "long-month-day-year-long-time-24", dayShortMonthYear: "day-short-month-year", dayShortMonthYearShortTime: "day-short-month-year-short-time", dayShortMonthYearShortTime24: "day-short-month-year-short-time-24", dayShortMonthYearLongTime: "day-short-month-year-long-time", dayShortMonthYearLongTime24: "day-short-month-year-long-time-24", longDate: "long-date", longDateShortTime: "long-date-short-time", longDateShortTime24: "long-date-short-time-24", longDateLongTime: "long-date-long-time", longDateLongTime24: "long-date-long-time-24", longMonthYear: "long-month-year", shortMonthYear: "short-month-year", year: "year" });
var Z = { ar: "ar-u-nu-latn-ca-gregory" };
var w = /* @__PURE__ */ new WeakMap();
var p2 = M["short-date-short-time"];
function v(t2) {
  let e2 = w.get(t2);
  if (!e2) {
    const n2 = r(), a = Z[n2] || n2, m = F(t2.timeZone ?? e), h = __spreadProps(__spreadValues({}, t2), { timeZone: m });
    e2 = new Intl.DateTimeFormat(a, h), w.set(t2, e2);
  }
  return e2;
}
function j(t2) {
  return M[t2];
}
function E(t2, e2 = p2) {
  return v(e2).format(t2);
}
function k(t2, e2 = p2) {
  return E(new Date(t2), __spreadValues(__spreadValues(__spreadValues({}, e2), y), l));
}
function I(t2, e2 = p2) {
  return E(/* @__PURE__ */ new Date(`1970-01-01T${t2}Z`), __spreadValues(__spreadValues(__spreadValues({}, e2), y), s2));
}
function x(t2, e2 = p2) {
  if (e2.timeZone) return E(new Date(t2), e2);
  const r2 = DateTime.fromISO(t2, { setZone: true }), a = r(), m = Z[a] ?? a, h = 0 === r2.offset ? n : e2.timeZone, s3 = __spreadProps(__spreadValues({}, e2), { timeZone: h });
  return r2.toLocaleString(s3, { locale: m });
}
function F(t2) {
  switch (t2) {
    case e:
      return o;
    case t:
      return n;
    default:
      return t2;
  }
}
p(() => {
  w = /* @__PURE__ */ new WeakMap();
});

export {
  Y,
  j,
  E,
  k,
  I,
  x,
  F
};
//# sourceMappingURL=chunk-EHGO3SHH.js.map
