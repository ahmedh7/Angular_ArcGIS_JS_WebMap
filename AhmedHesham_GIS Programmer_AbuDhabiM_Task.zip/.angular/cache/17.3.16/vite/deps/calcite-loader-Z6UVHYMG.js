import {
  w
} from "./chunk-EJFZYJAF.js";
import "./chunk-FJ5QMW6O.js";
import "./chunk-LPID7LVC.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-HZUW4HM7.js";
export {
  w as Loader
};
//# sourceMappingURL=calcite-loader-Z6UVHYMG.js.map
