import {
  P2 as P,
  s
} from "./chunk-ADRG7ORV.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/layers/support/layerUtils.js
function n(e) {
  return f(e) || o(e);
}
function r(e) {
  return null != e && "object" == typeof e && "type" in e && "feature" === e.type;
}
function s2(e) {
  return null != e && "object" == typeof e && "type" in e && "knowledge-graph" === e.type && "layers" in e;
}
function o(e) {
  return "scene" === e?.type;
}
function c(e) {
  return null != e && "object" == typeof e && "type" in e && "subtype-group" === e.type && "sublayers" in e;
}
function l(e) {
  return "subtype-sublayer" === e?.type;
}
function f(e) {
  const t = e?.type;
  return "imagery-tile" === t || "tile" === t || "open-street-map" === t || "vector-tile" === t || "web-tile" === t || "wmts" === t;
}
function y(e) {
  const t = e?.type;
  return "base-tile" === t || "tile" === t || "elevation" === t || "imagery-tile" === t || "base-elevation" === t || "open-street-map" === t || "wcs" === t || "web-tile" === t || "wmts" === t || "vector-tile" === t;
}
var g = { Point: "SceneLayer", "3DObject": "SceneLayer", IntegratedMesh: "IntegratedMeshLayer", PointCloud: "PointCloudLayer", Building: "BuildingSceneLayer" };
function b(e) {
  const t = e?.type;
  return "building-scene" === t || "integrated-mesh" === t || "point-cloud" === t || "scene" === t;
}
function m(e) {
  return "integrated-mesh" === e || "integrated-mesh-3dtiles" === e;
}
function w(e) {
  return "feature" === e?.type && !e.url && "memory" === e.source?.type;
}
function L(e) {
  const t = e?.type;
  return ("feature" === t || "subtype-group" === t || "oriented-imagery" === t) && "feature-layer" === e?.source?.type;
}
function M(e) {
  if (e.activeLayer) {
    const t = e.activeLayer.tileMatrixSet;
    if (t) return t;
    const n2 = e.activeLayer.tileMatrixSets;
    if (n2) return n2;
  }
  return null;
}
function x(n2, r2) {
  return __async(this, null, function* () {
    const i = s?.findServerInfo(n2);
    if (null != i?.currentVersion) return i.owningSystemUrl || null;
    const u = n2.toLowerCase().indexOf("/rest/services");
    if (-1 === u) return null;
    const s3 = `${n2.slice(0, u)}/rest/info`, a = null != r2 ? r2.signal : null, { data: o2 } = yield P(s3, { query: { f: "json" }, responseType: "json", signal: a });
    return o2?.owningSystemUrl || null;
  });
}
function I(e) {
  if (!("capabilities" in e)) return false;
  switch (e.type) {
    case "catalog":
    case "catalog-footprint":
    case "csv":
    case "feature":
    case "geojson":
    case "imagery":
    case "knowledge-graph-sublayer":
    case "ogc-feature":
    case "oriented-imagery":
    case "scene":
    case "sublayer":
    case "subtype-group":
    case "subtype-sublayer":
    case "wfs":
      return true;
    default:
      return false;
  }
}
function O(e) {
  return I(e) ? "effectiveCapabilities" in e ? e.effectiveCapabilities : e.capabilities : null;
}
function T(e) {
  if (!("editingEnabled" in e)) return false;
  switch (e.type) {
    case "csv":
    case "feature":
    case "geojson":
    case "oriented-imagery":
    case "scene":
    case "subtype-group":
    case "subtype-sublayer":
      return true;
    default:
      return false;
  }
}
function B(e) {
  return !!T(e) && ("effectiveEditingEnabled" in e ? e.effectiveEditingEnabled : e.editingEnabled);
}
function P2(e) {
  if (!e) return [];
  return ("subtypes" in e ? e.subtypes : c(e.parent) ? e.parent.subtypes : []) ?? [];
}

export {
  n,
  r,
  s2 as s,
  c,
  l,
  f,
  y,
  g,
  b,
  m,
  w,
  L,
  M,
  x,
  I,
  O,
  B,
  P2 as P
};
//# sourceMappingURL=chunk-2K433C2G.js.map
