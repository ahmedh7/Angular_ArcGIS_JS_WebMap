import {
  s as s5
} from "./chunk-ANBDVZMM.js";
import {
  e as e7
} from "./chunk-WA3XXJQ5.js";
import {
  a as a3
} from "./chunk-5BGQWKMP.js";
import {
  I as I2,
  b as b2,
  d as d3,
  h as h3
} from "./chunk-BX7BJ5NO.js";
import {
  L,
  S as S2,
  V as V3,
  i as i4,
  k as k2,
  u as u5,
  w as w2
} from "./chunk-772TINXM.js";
import {
  r as r4
} from "./chunk-S5Z7N22V.js";
import "./chunk-Y5L35WW6.js";
import {
  V as V2,
  l as l3
} from "./chunk-J3L36IWC.js";
import {
  t as t3
} from "./chunk-TTSQRO2X.js";
import {
  a as a2,
  i as i3,
  r as r3,
  u as u4
} from "./chunk-6GSAP6QO.js";
import {
  c as c3,
  d as d2,
  l2,
  o as o3,
  p as p3,
  s as s4,
  u2 as u3
} from "./chunk-TSBOMUHP.js";
import {
  y as y3
} from "./chunk-W2WZBWB6.js";
import "./chunk-DZRJWV5H.js";
import "./chunk-TSP7HBRK.js";
import {
  s as s3
} from "./chunk-SJT55WSC.js";
import {
  M,
  y2
} from "./chunk-AXAMTBE6.js";
import {
  I
} from "./chunk-JJKWU2YC.js";
import "./chunk-C6AVJYMI.js";
import "./chunk-OFPE7L24.js";
import "./chunk-EQ7BFYDM.js";
import "./chunk-FVSDB4JC.js";
import "./chunk-5V6LISMP.js";
import "./chunk-4VNKTESB.js";
import "./chunk-KVZR5ILN.js";
import {
  t as t2
} from "./chunk-SHZ6V3A6.js";
import {
  u as u2
} from "./chunk-G72JIG3C.js";
import "./chunk-QUH6IF3C.js";
import "./chunk-6JLNBB4A.js";
import "./chunk-B6TLVNFQ.js";
import "./chunk-HCOIDKPJ.js";
import "./chunk-RI3APACQ.js";
import "./chunk-DNKL4VLK.js";
import "./chunk-JA6WVUX5.js";
import "./chunk-HLUCHGW6.js";
import "./chunk-5ZLWOYXQ.js";
import "./chunk-LMKW53EF.js";
import {
  i as i2
} from "./chunk-245OSL56.js";
import "./chunk-V6AHEXFE.js";
import "./chunk-WJF6G6DB.js";
import "./chunk-VDBD7USS.js";
import "./chunk-G4JWBWXC.js";
import "./chunk-TX7HQE3N.js";
import {
  b,
  p3 as p2
} from "./chunk-O4PT2W5W.js";
import "./chunk-VDUPOWSD.js";
import "./chunk-PCY7U2ND.js";
import "./chunk-WFMHAEPG.js";
import "./chunk-JTVRCNJE.js";
import "./chunk-KD5GWDMJ.js";
import "./chunk-AV2MJVRY.js";
import "./chunk-S7C6FBSD.js";
import "./chunk-5MM6JTK5.js";
import "./chunk-EMGBZTFR.js";
import "./chunk-TOIEWZTN.js";
import "./chunk-LSWPUEJP.js";
import "./chunk-JHB4QD5T.js";
import "./chunk-XWFSWJ3K.js";
import "./chunk-RQIC5Q3A.js";
import "./chunk-RWBMMFSQ.js";
import "./chunk-Y37JFXZA.js";
import "./chunk-PAB5IPLG.js";
import "./chunk-GSLWE7BD.js";
import {
  S,
  y
} from "./chunk-BNLIASJH.js";
import "./chunk-UAZV56SS.js";
import "./chunk-ACRU4UL2.js";
import {
  qe
} from "./chunk-3SPX7DOW.js";
import {
  e as e4
} from "./chunk-7F6XPLMG.js";
import "./chunk-ULISRLN2.js";
import "./chunk-R4NJFVU4.js";
import "./chunk-B7JTGB74.js";
import "./chunk-YHKJPCKF.js";
import "./chunk-P6BYIY4S.js";
import "./chunk-EXKRZGS6.js";
import "./chunk-J3AJBXLW.js";
import {
  e as e6,
  n as n3
} from "./chunk-OWFGHE2Q.js";
import "./chunk-ECG7JDDX.js";
import {
  e as e5
} from "./chunk-7WLHD3F5.js";
import {
  O,
  c as c2,
  e as e2
} from "./chunk-PPAPRIQT.js";
import {
  i,
  n2
} from "./chunk-L7IGKLK6.js";
import {
  g as g2
} from "./chunk-2NHACHL3.js";
import "./chunk-NMBGL4CC.js";
import "./chunk-S4BA7TJA.js";
import {
  h as h2
} from "./chunk-4LHIE7NG.js";
import "./chunk-MWWEB6NO.js";
import "./chunk-LWSJP2M5.js";
import "./chunk-Y4JUMKSA.js";
import "./chunk-JCECTBEZ.js";
import "./chunk-YFQQ5MRE.js";
import "./chunk-QWS2NSQP.js";
import "./chunk-YRA46JOQ.js";
import "./chunk-FHAIN2FL.js";
import "./chunk-7NHDAECT.js";
import {
  e as e3,
  u
} from "./chunk-XOZHLW5F.js";
import "./chunk-3OMNVZX2.js";
import {
  r as r2
} from "./chunk-2K433C2G.js";
import "./chunk-EOJGN7NW.js";
import "./chunk-DZ57YO2M.js";
import "./chunk-UJIBBVDV.js";
import "./chunk-PLXIETOO.js";
import {
  s
} from "./chunk-4MEW2QUW.js";
import {
  l
} from "./chunk-GMGPROHW.js";
import {
  f
} from "./chunk-35TO2ECR.js";
import "./chunk-XYTETMU6.js";
import {
  P,
  d,
  p,
  v,
  w
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import "./chunk-JEGE7NFK.js";
import "./chunk-TZVX7A54.js";
import "./chunk-3XI2MKAT.js";
import "./chunk-EHGO3SHH.js";
import "./chunk-7PVOLFAH.js";
import "./chunk-S3UZ5KFQ.js";
import {
  h
} from "./chunk-KVMARQAF.js";
import "./chunk-TN5VWI6D.js";
import "./chunk-GMDCM6PU.js";
import "./chunk-55ETTKLO.js";
import "./chunk-ZIR7ORWU.js";
import "./chunk-3X4RHLTI.js";
import "./chunk-FMVDY4TM.js";
import "./chunk-K2TU6MD2.js";
import "./chunk-4JUCUHPE.js";
import "./chunk-P5ELECBN.js";
import "./chunk-HJWYGMG7.js";
import "./chunk-HPCWTJIY.js";
import "./chunk-DBSWFGJK.js";
import {
  s as s2
} from "./chunk-REZDV4AU.js";
import {
  o as o2
} from "./chunk-TAT7XC7M.js";
import "./chunk-3T5L5WXD.js";
import {
  P2,
  t
} from "./chunk-ADRG7ORV.js";
import {
  Et
} from "./chunk-4LJTFP6V.js";
import "./chunk-XIZ4X35L.js";
import {
  e,
  g,
  m,
  o
} from "./chunk-UNFSMTII.js";
import {
  a3 as a
} from "./chunk-QYUZVPLR.js";
import "./chunk-VOA3KUT6.js";
import "./chunk-EXBMPISM.js";
import "./chunk-PRABXD46.js";
import "./chunk-ZBG4VLBC.js";
import "./chunk-QWN6HSVJ.js";
import {
  k
} from "./chunk-VT56RVNM.js";
import "./chunk-DWCD4SQQ.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  c,
  n2 as n
} from "./chunk-JB56QM27.js";
import {
  G,
  has
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __objRest,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/widgets/Legend/support/clusterUtils.js
function l4(l9, i7, s8) {
  const a10 = l9.effectiveClusterRenderer;
  if (!a10 || !("visualVariables" in a10) || !a10.visualVariables) return null;
  const n7 = a10.visualVariables.find((e10) => "size" === e10.type);
  if (!("stops" in n7) || !n7.stops) return null;
  const t4 = n7.stops.find((e10) => e10.useMinValue), u11 = n7.stops.find((e10) => e10.useMaxValue);
  if (null == t4 || null == u11) return null;
  const r8 = s8.featuresTilingScheme.getClosestInfoForScale(s8.scale).level, f7 = n7.field, o5 = i7.getDisplayStatistics(r8, f7);
  return o5 ? new b({ field: n7.field, minSize: l9.clusterMinSize, minDataValue: o5.minValue, maxSize: l9.clusterMaxSize, maxDataValue: o5.maxValue }) : null;
}

// node_modules/@arcgis/core/widgets/smartMapping/support/utils.js
function s6(t4) {
  const n7 = 2, o5 = Math.floor(Math.log10(Math.abs(t4))) + 1, e10 = o5 < 4 || o5 > 6 ? 4 : o5, r8 = 1e6, s8 = Math.abs(t4) >= r8 ? "compact" : "standard";
  return l(t4, { notation: s8, minimumSignificantDigits: n7, maximumSignificantDigits: e10 });
}

// node_modules/@arcgis/core/widgets/Legend/support/ActiveLayerInfo.js
var ue = 16;
var ce = "https://utility.arcgis.com/sharing/tools/legend";
var de = "esri.layers.ImageryLayer";
var ye = "esri.layers.ImageryTileLayer";
var he = "esri.layers.WCSLayer";
var me = /^\s*(return\s+)?\$view\.scale\s*(;)?\s*$/i;
var pe = new o2({ esriGeometryPoint: "point", esriGeometryMultipoint: "multipoint", esriGeometryPolyline: "polyline", esriGeometryPolygon: "polygon", esriGeometryMultiPatch: "multipatch" });
var fe = new y({ size: 6, outline: { color: [128, 128, 128, 0.5], width: 0.5 } });
var ge = new S({ style: "solid" });
function be(e10) {
  return "flow" === e10.type;
}
function Se(e10) {
  return "vector-field" === e10.type;
}
function _e(e10) {
  return "raster-colormap" === e10.type;
}
function we(e10) {
  return "raster-stretch" === e10.type;
}
function ve(e10) {
  return "raster-shaded-relief" === e10.type;
}
function Le(e10) {
  return "esri.renderers.SimpleRenderer" === e10.declaredClass;
}
function Ee(e10) {
  return "esri.renderers.ClassBreaksRenderer" === e10.declaredClass;
}
function Ce(e10) {
  return "esri.renderers.UniqueValueRenderer" === e10.declaredClass;
}
function Ie(e10) {
  return "esri.renderers.HeatmapRenderer" === e10.declaredClass;
}
function Fe(e10) {
  return Ve(e10) || De(e10) || xe(e10) || Re(e10);
}
function Re(e10) {
  return "esri.renderers.PointCloudRGBRenderer" === e10.declaredClass;
}
function Ve(e10) {
  return "esri.renderers.PointCloudClassBreaksRenderer" === e10.declaredClass;
}
function De(e10) {
  return "esri.renderers.PointCloudStretchRenderer" === e10.declaredClass;
}
function xe(e10) {
  return "esri.renderers.PointCloudUniqueValueRenderer" === e10.declaredClass;
}
function ze(e10) {
  return "esri.renderers.DotDensityRenderer" === e10.declaredClass;
}
function Te(e10) {
  return "esri.renderers.PieChartRenderer" === e10.declaredClass;
}
function je(e10, t4) {
  return Le(e10) || Ee(e10) || Ce(e10) || Ie(e10) || ze(e10) || Te(e10) ? "2d" === t4.type || s5(e10) : we(e10) || _e(e10) || ve(e10) || Ve(e10) || De(e10) || xe(e10) || Se(e10) || be(e10);
}
function Oe(e10) {
  return "esri.layers.BuildingSceneLayer" === e10.declaredClass;
}
function Pe(e10) {
  return "esri.layers.SubtypeGroupLayer" === e10.declaredClass;
}
function Ae(e10) {
  return "esri.layers.VoxelLayer" === e10.declaredClass;
}
function Me(e10) {
  return "esri.layers.WMSLayer" === e10.declaredClass;
}
function Ue(e10) {
  return "esri.layers.WMTSLayer" === e10.declaredClass;
}
function ke(e10) {
  return "esri.layers.MapImageLayer" === e10.declaredClass;
}
function Be(e10) {
  return "esri.layers.TileLayer" === e10.declaredClass;
}
function Ne(e10) {
  return e10.declaredClass === de;
}
function qe2(e10) {
  return e10.declaredClass === ye;
}
function He(e10) {
  return e10.declaredClass === he;
}
function $e(e10) {
  return "stretch-ramp" === e10.type;
}
function We(e10) {
  const t4 = "authoringInfo" in e10 ? e10?.authoringInfo : null;
  return "univariate-color-size" === t4?.type;
}
function Ge(e10) {
  const t4 = "authoringInfo" in e10 ? e10?.authoringInfo : null;
  return "univariate-color-size" === t4?.type && "above-and-below" === t4?.univariateTheme;
}
function Je(e10) {
  return "sublayers" in e10;
}
function Qe(e10, t4) {
  return __async(this, null, function* () {
    const s8 = yield f("esri/widgets/Legend/t9n/Legend");
    return "previewTemplateAriaLabel" !== e10 || t4 || (e10 = "previewAriaLabel"), s(s8[e10], { label: t4 });
  });
}
function Ze(e10, t4) {
  const { field: s8, field2: i7, field3: l9, fieldDelimiter: r8, valueExpression: n7 } = e10;
  if (!s8) return null;
  const a10 = !(!s8 && !n7 || !i7 && !l9) ? t4?.toString().split(r8 || "") : [t4], o5 = s8 ? { [s8]: a10?.[0] } : null;
  return o5 && (i7 && (o5[i7] = a10?.[1]), l9 && (o5[l9] = a10?.[2])), o5;
}
var Ke = new y({ style: "path", path: "M10,5 L5,0 0,5 M5,0 L5,15", size: 15, outline: { width: 1, color: [85, 85, 85, 1] } });
var Xe = {};
var Ye = class extends g {
  constructor(e10) {
    super(e10), this._hasColorRamp = false, this._hasOpacityRamp = false, this._hasSizeRamp = false, this._webStyleSymbolCache = /* @__PURE__ */ new Map(), this._dotDensityUrlCache = /* @__PURE__ */ new Map(), this._scaleDrivenSizeVariable = null, this._hasClusterSizeVariable = false, this._layerDefinitionExpression = null, this._layerDefinitionExpressionClause = null, this._layerDisplayFilterId = null, this._layerDisplayFilterClause = null, this.children = new V(), this.layerView = null, this.layer = null, this.legendElements = [], this.parent = null, this.hideLayersNotInCurrentView = false, this.keepCacheOnDestroy = false, this.respectLayerDefinitionExpression = false, this.respectLayerVisibility = true, this.sublayerIds = [], this.title = null, this.view = null;
  }
  initialize() {
    const e10 = () => this.notifyChange("ready");
    this.addHandles([v(() => this.children, "change", (t4) => {
      const { added: s8, removed: i7 } = t4;
      s8.forEach((t5) => {
        const s9 = `activeLayerInfo-ready-watcher-${t5.layer.uid}`;
        this.addHandles(d(() => t5.ready, e10, P), s9);
      }), i7.forEach((e11) => this.removeHandles(e11.layer.uid)), e10();
    })]), this.keepCacheOnDestroy || (Xe = {});
  }
  destroy() {
    this._webStyleSymbolCache = null, this._dotDensityUrlCache = null, this._scaleDrivenSizeVariable = null, this.keepCacheOnDestroy || (Xe = null), this._layerDefinitionExpressionClause = null;
  }
  get effectList() {
    const e10 = this.layer;
    let t4 = null;
    return "effect" in e10 && e10.effect && (t4 = new a3(), t4.effect = e10.effect, t4.endTransition(), t4.scale = this.scale), t4;
  }
  get opacity() {
    const e10 = this.layer.opacity, t4 = this.parent?.opacity, s8 = this.layer.parent, i7 = s8 && "uid" in s8 ? this._getParentLayerOpacity(s8) : null;
    return null != t4 ? t4 * e10 : null != i7 ? i7 * e10 : e10;
  }
  get ready() {
    return null === this.layer || (this.children.length > 0 ? this._isGroupActive() : this.legendElements.length > 0);
  }
  get scale() {
    return this.view?.scale ?? 0;
  }
  get isScaleDriven() {
    const e10 = this.layer;
    if (null === e10) return false;
    if ("effect" in e10 && e10.effect && Array.isArray(e10.effect)) return true;
    if ("featureReduction" in e10 && e10.featureReduction) {
      if ("cluster" === e10.featureReduction.type) return true;
      if ("binning" === e10.featureReduction.type && "renderer" in e10.featureReduction && e10.featureReduction.renderer) return this._isRendererScaleDriven(e10.featureReduction.renderer);
    }
    return "renderer" in e10 && e10.renderer ? !!("displayFilterInfo" in e10 && e10.displayFilterInfo && Ce(e10.renderer)) || this._isRendererScaleDriven(e10.renderer) : this._isLayerScaleDriven(this.layer);
  }
  get version() {
    return this._get("version") + 1;
  }
  buildLegendElementsForFeatureCollections(e10) {
    return __async(this, null, function* () {
      if (!(!this.hideLayersNotInCurrentView || (yield this._isLayerInCurrentView()))) return this.legendElements = [], void this.notifyChange("ready");
      const t4 = Array.from(e10, (e11) => {
        if (r2(e11)) return this._getRendererLegendElements(e11.renderer, { title: e11.title });
        if (e11.featureSet?.features.length) {
          const t5 = e11.layerDefinition, s8 = t5?.drawingInfo, i7 = s8 && t2(s8.renderer), l9 = pe.read(t5.geometryType);
          return i7 ? this._getRendererLegendElements(i7, { title: e11.name, geometryType: l9 }) : (n.getLogger(this).warn("drawingInfo not available!"), null);
        }
        return null;
      });
      try {
        const e11 = [], s8 = yield Promise.allSettled(t4);
        for (const t5 of s8) if ("fulfilled" === t5.status) for (const s9 of t5.value ?? []) e11.push(s9);
        this.legendElements = e11, this.notifyChange("ready");
      } catch (s8) {
        n.getLogger(this).warn("error while building legend for layer!", s8);
      }
    });
  }
  buildLegendElementsForRenderer(e10) {
    return __async(this, null, function* () {
      try {
        const t4 = !this.hideLayersNotInCurrentView || (yield this._isLayerInCurrentView());
        this.legendElements = t4 ? yield this._getRendererLegendElements(e10) : [], this.notifyChange("ready");
      } catch (t4) {
        n.getLogger(this).warn("error while building legend for layer!", t4);
      }
    });
  }
  buildLegendElementsForFeatureReduction(e10) {
    return __async(this, null, function* () {
      try {
        const t4 = !this.hideLayersNotInCurrentView || (yield this._isLayerInCurrentView());
        this.legendElements = t4 ? yield this._getLegendElementsForFeatureReduction(e10) : [], this.notifyChange("ready");
      } catch (t4) {
        n.getLogger(this).warn("error while building legend for layer!", t4);
      }
    });
  }
  buildLegendElementsForTools() {
    return __async(this, null, function* () {
      const e10 = this.layer;
      if (Ae(e10)) this._constructLegendElementsForVoxelLayer();
      else if (Ue(e10)) this._constructLegendElementsForWMTSlayer();
      else if (Me(e10)) yield this._constructLegendElementsForWMSSublayers();
      else if (Oe(e10)) yield this._constructLegendElementsForBuildingSceneLayer();
      else if (ke(e10) || Be(e10) || Pe(e10)) yield this._constructLegendElementsForSublayers();
      else {
        this.removeHandles("imageryLayers-watcher");
        let t4 = "default";
        if (Ne(e10)) {
          const s8 = e10;
          t4 = (s8?.rasterFunction?.functionName || "default") + "_" + (e10.bandIds?.length ? e10.bandIds.join("") : "###");
        }
        if (qe2(e10) || "link-chart" === e10.type) return;
        yield this._getLegendLayers(`${e10.uid}-${t4}`).then((t5) => __async(this, null, function* () {
          this.legendElements = [], this.notifyChange("ready");
          const s8 = t5.map((t6) => __async(this, null, function* () {
            if (Ne(e10)) {
              const t7 = d(() => [e10.rasterFunction, e10.bandIds], () => k(() => __async(this, null, function* () {
                Xe.default = null, e10.renderer ? yield this.buildLegendElementsForRenderer(e10.renderer) : yield this.buildLegendElementsForTools();
              }))());
              this.addHandles(t7, "imageryLayers-watcher");
            }
            const s9 = this._generateSymbolTableElementForLegendLayer(t6);
            s9?.infos.length && (Ne(e10) && (s9.title = e10.title), this.legendElements.push(s9)), this.notifyChange("ready");
          }));
          yield Promise.allSettled(s8);
        })).catch((e11) => {
          n.getLogger(this).warn("Request to server for legend has failed!", e11);
        });
      }
    });
  }
  _isLayerInCurrentView() {
    return __async(this, null, function* () {
      const e10 = this.layer, t4 = this.layerView, s8 = t4 && "createQuery" in t4 && "queryFeatureCount" in t4;
      if (!s8 && !(t4 && "createQuery" in e10 && "queryFeatureCount" in e10)) return true;
      yield w(() => !t4.updating);
      const i7 = s8 ? "createQuery" in t4 && t4.createQuery() : "createQuery" in e10 && e10.createQuery();
      if (!i7) return true;
      i7.geometry = this.view.extent;
      return 0 !== (s8 ? "queryFeatureCount" in t4 && (yield t4.queryFeatureCount(i7)) : "queryFeatureCount" in e10 && (yield e10.queryFeatureCount(i7)));
    });
  }
  _getParentLayerOpacity(e10) {
    let t4 = 1;
    const s8 = e10.parent;
    return s8 && "uid" in s8 && (t4 = this._getParentLayerOpacity(s8)), e10.opacity * t4;
  }
  _isGroupActive() {
    return this.children.some((e10) => e10.ready);
  }
  _isRendererScaleDriven(e10) {
    if ("dot-density" === e10.type) return true;
    const t4 = "valueExpression" in e10 ? e10.valueExpression : null;
    if (me.test(t4)) return true;
    const s8 = "visualVariables" in e10 ? e10.visualVariables : null;
    return !!s8?.some((e11) => this._isScaleDrivenSizeVariable(e11)) || this._hasScaleDrivenSymbols(e10);
  }
  _hasScaleDrivenSymbols(e10) {
    switch (e10.type) {
      case "simple":
        return this._isScaleDrivenSymbol(e10.symbol);
      case "class-breaks":
        return this._isScaleDrivenSymbol(e10.defaultSymbol) || e10.classBreakInfos.some((e11) => this._isScaleDrivenSymbol(e11.symbol));
      case "unique-value":
        return this._isScaleDrivenSymbol(e10.defaultSymbol) || !!e10.uniqueValueInfos?.some((e11) => this._isScaleDrivenSymbol(e11.symbol));
    }
    return false;
  }
  _isScaleDrivenSymbol(e10) {
    if ("cim" === e10?.type) {
      const { primitiveOverrides: t4, minScale: s8, maxScale: i7 } = e10.data, l9 = t4?.some((e11) => /\$view\.scale/.test(e11.valueExpressionInfo?.expression || "")) ?? false;
      return null != s8 || null != i7 || l9;
    }
    return false;
  }
  _isScaleDrivenSizeVariable(e10) {
    if (e10 && "size" !== e10.type) return false;
    const t4 = e10, s8 = t4.minSize, i7 = t4.maxSize;
    return !("object" != typeof s8 || !s8 || !this._isScaleDrivenSizeVariable(s8)) || (!("object" != typeof i7 || !i7 || !this._isScaleDrivenSizeVariable(i7)) || me.test(t4.valueExpression));
  }
  _isLayerScaleDriven(e10) {
    if ("minScale" in e10 && e10.minScale > 0 || "maxScale" in e10 && e10.maxScale > 0) return true;
    if ("sublayers" in e10 && e10.sublayers) return e10.sublayers.some((e11) => this._isLayerScaleDriven(e11));
    const t4 = e10.parent;
    if (false === e10.loaded && t4 && ke(t4) && "source" in e10 && e10.source && "map-layer" === e10.source.type) {
      for (const s8 of t4.sourceJSON.layers ?? []) if (s8.id === e10.source.mapLayerId && (s8.minScale > 0 || s8.maxScale > 0)) return true;
    }
    return false;
  }
  _constructLegendElementsForVoxelLayer() {
    return __async(this, null, function* () {
      this.legendElements = [], this.removeHandles("voxel-style-watcher"), this.removeHandles("voxel-current-variable");
      const e10 = this.layer;
      this.addHandles(d(() => e10.currentVariableId, () => this._constructLegendElementsForVoxelLayer()), "voxel-current-variable"), this.addHandles(d(() => e10.getVariableStyles(), () => this._constructLegendElementsForVoxelLayer()), "voxel-style-watcher");
      const t4 = e10.getVariableStyle(null), s8 = [];
      if (t4) {
        if (t4.uniqueValues?.length) {
          const e11 = [];
          t4.uniqueValues.forEach((t5) => {
            t5.enabled && e11.push({ label: t5.label || `${t5.value}`, value: t5.value, symbol: new S({ color: t5.color, outline: null }) });
          }), e11.length && s8.push({ type: "symbol-table", title: t4.label, infos: e11 });
        } else if (t4.transferFunction) {
          const { colorStops: e11, stretchRange: i8 } = t4.transferFunction, l10 = e11.toArray().reverse(), r8 = i8.map((e12, t5) => `${0 === t5 ? o3 : l2} ${s6(e12)}`).reverse(), n7 = l10.map((e12) => ({ color: e12.color, value: null, label: null }));
          n7[0].label = r8[0], n7[n7.length - 1].label = r8[1], s8.push({ type: "color-ramp", title: t4.label, infos: n7, preview: V3(l10.map((e12) => e12.color), { ariaLabel: yield Qe("previewColorRampAriaLabel") }) });
        }
      }
      const i7 = e10.opacity, l9 = s8.reduce((e11, t5) => [...e11, ...this._getAllInfos(t5)], []).filter((e11) => !!e11?.symbol).map((e11) => this._getSymbolPreview(e11, i7));
      yield Promise.allSettled(l9), this.legendElements = s8, this.notifyChange("ready");
    });
  }
  _constructLegendElementsForWMTSlayer() {
    this.legendElements = [], this.removeHandles("wmts-activeLayer-watcher");
    const e10 = this.layer.activeLayer;
    this.addHandles(d(() => {
      const { layer: e11 } = this;
      return e11 && "activeLayer" in e11 && e11.activeLayer;
    }, () => this._constructLegendElementsForWMTSlayer()), "wmts-activeLayer-watcher");
    const t4 = e10.styleId ? e10.styles?.find(({ id: t5 }) => t5 === e10.styleId)?.legendUrl : void 0;
    t4 && (this.legendElements = [{ type: "symbol-table", title: e10.title, infos: [{ src: t4, opacity: this.opacity }] }]), this.notifyChange("ready");
  }
  _constructLegendElementsForWMSSublayers() {
    return __async(this, null, function* () {
      this.legendElements = [], this.removeHandles("wms-sublayers-watcher");
      const e10 = this.layer;
      let t4 = null;
      (e10.customParameters || e10.customLayerParameters) && (t4 = __spreadValues(__spreadValues({}, e10.customParameters), e10.customLayerParameters)), this.addHandles(d(() => {
        const { layer: e11 } = this;
        return e11 && "sublayers" in e11 && e11.sublayers;
      }, () => this._constructLegendElementsForWMSSublayers()), "wms-sublayers-watcher"), this.legendElements = yield this._generateLegendElementsForWMSSublayers(e10.sublayers, t4), this.notifyChange("ready");
    });
  }
  _generateLegendElementsForWMSSublayers(e10, t4) {
    return __async(this, null, function* () {
      const s8 = this.layer, i7 = [];
      this.addHandles(e10.on("change", () => this._constructLegendElementsForWMSSublayers()), "wms-sublayers-watcher");
      const l9 = this.sublayerIds?.map((e11) => s8.findSublayerById(e11))?.filter(G) ?? [], n7 = l9.length ? l9 : e10.toArray();
      for (const r8 of n7) {
        const e11 = d(() => [r8.title, r8.visible, r8.legendEnabled], () => this._constructLegendElementsForWMSSublayers());
        if (this.addHandles(e11, "wms-sublayers-watcher"), !this.respectLayerVisibility || r8.visible && r8.legendEnabled) {
          const e12 = yield this._generateSymbolTableElementForWMSSublayer(r8, t4);
          e12?.infos.length && i7.unshift(e12);
        }
      }
      return i7;
    });
  }
  _generateSymbolTableElementForWMSSublayer(e10, t4) {
    return __async(this, null, function* () {
      if (!e10.legendUrl && e10.sublayers) {
        const s8 = (yield this._generateLegendElementsForWMSSublayers(e10.sublayers, t4)).filter((e11) => e11);
        return { type: "symbol-table", title: e10.title, infos: s8 };
      }
      return this._generateSymbolTableElementForLegendUrl(e10, t4);
    });
  }
  _generateSymbolTableElementForLegendUrl(e10, t4) {
    return __async(this, null, function* () {
      let s8 = e10.legendUrl;
      if (!s8) return;
      const l9 = { type: "symbol-table", title: e10.title || e10.name || String(e10.id ?? ""), infos: [] };
      t4 && (s8 = Et(s8, t4));
      let r8 = null;
      const n7 = e10.layer?.opacity;
      try {
        r8 = (yield P2(s8, { responseType: "image" })).data, r8 && (r8.style.opacity = n7);
      } catch {
      }
      return l9.infos.push({ src: s8, preview: r8, opacity: n7 }), l9;
    });
  }
  _getLegendLayers(e10, t4) {
    const s8 = Xe && Xe[e10];
    return s8 ? Promise.resolve(s8) : this._legendRequest(t4).then((t5) => {
      const s9 = t5.layers;
      return Xe[e10] = s9, s9;
    });
  }
  _legendRequest(e10) {
    const t4 = this.layer;
    let s8 = { f: "json", dynamicLayers: e10 };
    if (Ne(t4)) {
      const e11 = t4.exportImageServiceParameters.rasterFunction;
      if (e11 && (s8.renderingRule = JSON.stringify(e11.functionDefinition?.toJSON() || e11.toJSON())), t4.bandIds && (s8.bandIds = t4.bandIds.join()), t4.raster || t4.viewId || t4.customParameters) {
        const { raster: e12, viewId: i7, customParameters: l10 } = t4;
        s8 = __spreadValues(__spreadValues({ raster: e12, viewId: i7 }, s8), l10);
      }
    }
    let l9 = t4.url.replace(/(\/)+$/, "");
    if ("version" in t4 && +t4.version >= 10.01) {
      const e11 = l9.indexOf("?");
      e11 > -1 ? l9 = l9.slice(0, e11) + "/legend" + l9.slice(e11) : l9 += "/legend";
    } else {
      const e11 = l9.toLowerCase().indexOf("/rest/"), t5 = -1 === e11 ? l9 : l9.slice(0, e11) + l9.slice(e11 + 5);
      l9 = ce + "?soapUrl=" + encodeURI(t5) + "&returnbytes=true";
    }
    return P2(l9, { query: s8 }).then((e11) => e11.data);
  }
  _constructLegendElementsForBuildingSceneLayer() {
    return __async(this, null, function* () {
      this.legendElements = [], this.removeHandles("sublayers-watcher");
      const e10 = this.layer;
      this.addHandles(d(() => e10.sublayers, () => this._constructLegendElementsForBuildingSceneLayer()), "sublayers-watcher");
      try {
        this.legendElements = yield this._generateLegendElementsForBuildingSublayers(e10.sublayers, this.opacity), this.notifyChange("ready");
      } catch (t4) {
        n.getLogger(this).warn("Request to server for legend has failed!", t4);
      }
    });
  }
  _generateLegendElementsForBuildingSublayers(e10, t4) {
    return __async(this, null, function* () {
      let s8 = [];
      this.addHandles(e10.on("change", () => this._constructLegendElementsForBuildingSceneLayer()), "sublayers-watcher");
      const i7 = e10.toArray();
      for (const l9 of i7) {
        const e11 = d(() => ["renderer" in l9 && l9.renderer, l9.opacity, l9.title, l9.visible], () => this._constructLegendElementsForBuildingSceneLayer());
        if (this.addHandles(e11, "sublayers-watcher"), !this.respectLayerVisibility || l9.visible) {
          const e12 = null != l9?.opacity ? l9.opacity : null, i8 = null != e12 ? e12 * t4 : t4;
          if ("building-group" === l9.type) {
            const e13 = { type: "symbol-table", title: l9.title, infos: [] }, t5 = yield this._generateLegendElementsForBuildingSublayers(l9.sublayers, i8);
            e13.infos.push(...t5), s8 = [e13, ...s8];
          } else if (l9.renderer) {
            s8 = [...yield this._getRendererLegendElements(l9.renderer, { title: l9.title, opacity: i8, sublayer: l9 }), ...s8];
          }
        }
      }
      return s8.filter((e11) => !!e11 && (!("infos" in e11) || !e11.infos || e11.infos.length > 0));
    });
  }
  _constructLegendElementsForSublayers() {
    return __async(this, null, function* () {
      this.legendElements = [], this.removeHandles("sublayers-watcher");
      const e10 = this.layer;
      if (ke(e10) || Be(e10) || Pe(e10)) {
        this.addHandles(d(() => e10.sublayers, () => this._constructLegendElementsForSublayers), "sublayers-watcher");
        try {
          this.legendElements = yield this._generateLegendElementsForSublayers(e10.sublayers, this.opacity), this.notifyChange("ready");
        } catch (t4) {
          n.getLogger(this).warn("Request to server for legend has failed!", t4);
        }
      }
    });
  }
  _generateLegendElementsForSublayers(e10, t4, s8) {
    return __async(this, null, function* () {
      const i7 = this.layer;
      let l9 = [];
      this.addHandles(e10.on("change", () => this._constructLegendElementsForSublayers()), "sublayers-watcher");
      let n7 = e10.toArray();
      !s8 && this.sublayerIds && this.sublayerIds.length && (n7 = Pe(i7) ? this.sublayerIds.map((e11) => i7.findSublayerForSubtypeCode(e11)).filter(G) : this.sublayerIds.map((e11) => i7.findSublayerById(e11)).filter(G));
      for (const r8 of n7) {
        const e11 = d(() => [r8.renderer, r8.opacity, r8.title, r8.visible, r8.legendEnabled], () => this._constructLegendElementsForSublayers());
        if (this.addHandles(e11, "sublayers-watcher"), !this.respectLayerVisibility || r8.visible && r8.legendEnabled && this._isSublayerInScale(r8)) {
          const e12 = null != r8?.opacity ? r8.opacity : null, i8 = null != e12 ? e12 * t4 : t4, n8 = !Je(r8) || r8.originIdOf("renderer") > e.SERVICE && !r8.sublayers;
          if (r8.renderer && n8) {
            yield r8.load();
            l9 = [...yield this._getRendererLegendElements(r8.renderer, { title: r8.title, opacity: i8, sublayer: r8 }), ...l9];
          } else if (Je(r8)) {
            const e13 = yield this._generateSymbolTableElementForSublayer(r8, i8, s8);
            e13 && l9.unshift(e13);
          }
        }
      }
      return l9.filter((e11) => !!e11 && (!("infos" in e11) || !e11.infos || e11.infos.length > 0));
    });
  }
  _generateSymbolTableElementForSublayer(e10, t4, s8) {
    return __async(this, null, function* () {
      if (!s8) {
        s8 = /* @__PURE__ */ new Map();
        const t5 = this.layer, i8 = e10.source;
        let l9 = null;
        if (!(!i8 || "map-layer" === i8.type && i8.mapLayerId === e10.id && (!i8.gdbVersion || i8.gdbVersion === ("gdbVersion" in t5 && t5.gdbVersion))) || e10.originIdOf("renderer") > e.SERVICE || e10.originIdOf("labelingInfo") > e.SERVICE || e10.originIdOf("labelsVisible") > e.SERVICE) {
          const e11 = new y3({ layer: this.layer });
          l9 = e11.hasDynamicLayers ? e11.dynamicLayers : null, e11.destroy();
        }
        const r8 = l9 || `${t5.uid}-default`;
        (yield this._getLegendLayers(r8, l9)).forEach((e11) => s8.set(e11.layerId, e11));
      }
      const i7 = s8.get(e10.id);
      if ((!i7 || i7?.subLayerIds && i7.defaultVisibility) && e10.sublayers) {
        const i8 = yield this._generateLegendElementsForSublayers(e10.sublayers, t4, s8);
        return { type: "symbol-table", title: e10.title, infos: i8 };
      }
      return this._generateSymbolTableElementForLegendLayer(i7, e10, t4);
    });
  }
  _generateSymbolTableElementForLegendLayer(e10, t4, s8) {
    if (!e10?.legend || this.respectLayerVisibility && !this._isLegendLayerInScale(e10, t4)) return null;
    const i7 = t4?.renderer;
    let l9 = t4?.title || e10.layerName;
    if (i7 && (!t4 || t4?.originIdOf("renderer") > e.SERVICE)) {
      const e11 = t4?.title || this._getRendererTitle(i7, t4);
      e11 && (l9 && "string" != typeof e11 && "title" in e11 && (e11.title = l9), l9 = e11);
    }
    const r8 = { type: "symbol-table", title: l9, legendType: e10.legendType || null, infos: [] }, n7 = t4 ? this._sanitizeLegendForSublayer(e10.legend.slice(), t4) : e10.legend;
    return e10.legendGroups && e10.legendGroups.length > 0 ? e10.legendGroups.forEach((t5) => {
      const i8 = { type: "symbol-table", title: t5.heading, legendType: e10.legendType || null, infos: this._generateSymbolTableElementInfosForLegendLayer(n7.filter((e11) => e11.groupId === t5.id), e10.layerId, s8) };
      i8.infos?.length > 0 && r8.infos.push(i8);
    }) : r8.infos = this._generateSymbolTableElementInfosForLegendLayer(n7, e10.layerId, s8), r8.infos.length > 0 ? r8 : null;
  }
  _generateSymbolTableElementInfosForLegendLayer(e10, t4, i7) {
    return e10.map((e11) => {
      let l9 = e11.url;
      if (e11.imageData && e11.imageData.length > 0) l9 = `data:image/png;base64,${e11.imageData}`;
      else {
        if (0 === l9.indexOf("http")) return null;
        l9 = t(`${this.layer.url}/${t4}/images/${l9}`);
      }
      return { label: e11.label, src: l9, opacity: i7 ?? this.opacity, width: e11.width, height: e11.height };
    }).filter(G);
  }
  _isSublayerInScale(e10) {
    const t4 = e10.minScale || 0, s8 = e10.maxScale || 0;
    return !(t4 > 0 && t4 < this.scale || s8 > this.scale);
  }
  _isLegendLayerInScale(e10, t4) {
    const s8 = t4 || this.layer;
    let i7 = null, l9 = null, r8 = true;
    return !s8.minScale && 0 !== s8.minScale || !s8.maxScale && 0 !== s8.maxScale ? (0 === e10.minScale && s8.tileInfo && (i7 = s8.tileInfo.lods[0].scale), 0 === e10.maxScale && s8.tileInfo && (l9 = s8.tileInfo.lods[s8.tileInfo.lods.length - 1].scale)) : (i7 = Math.min(s8.minScale, e10.minScale) || s8.minScale || e10.minScale, l9 = Math.max(s8.maxScale, e10.maxScale)), (i7 > 0 && i7 < this.scale || l9 > this.scale) && (r8 = false), r8;
  }
  _sanitizeLegendForSublayer(e10, t4) {
    if ("version" in this.layer && +this.layer.version < 10.1 || 0 === e10.length) return e10;
    const s8 = t4.renderer, i7 = e10.some((e11) => e11.values);
    let l9 = 0, r8 = null;
    return i7 && e10.some((e11, t5) => (e11.values || (l9 = t5, r8 = e11, r8.label || (r8.label = "others")), null != r8)), s8 ? "unique-value" === s8.type ? r8 && (e10.splice(l9, 1), e10.push(r8)) : "class-breaks" === s8.type && (r8 && e10.splice(l9, 1), s8.legendOptions?.order || e10.reverse(), r8 && e10.push(r8)) : r8 && (e10.splice(l9, 1), e10.push(r8)), e10;
  }
  _getRendererLegendElements(_0) {
    return __async(this, arguments, function* (e10, t4 = {}) {
      if (!je(e10, this.view)) return n.getLogger(this).warn(`Renderer of type '${e10.type}' not supported!`), [];
      if (Fe(e10)) return this._constructPointCloudRendererLegendElements(e10, t4);
      if (ze(e10)) return this._constructDotDensityRendererLegendElements(e10);
      const s8 = yield this._loadRenderer(e10);
      return Te(s8) ? this._constructPieChartRendererLegendElements(s8) : this._constructRendererLegendElements(s8, t4);
    });
  }
  _getLegendElementsForFeatureReduction(e10) {
    return __async(this, null, function* () {
      let t4 = null;
      return "binning" === e10.type ? t4 = e10.renderer : "cluster" === e10.type && (t4 = this._getClusterRenderer(e10)), t4 ? this._getRendererLegendElements(t4) : [];
    });
  }
  _getPointCloudRendererTitle(e10) {
    return (e10.legendOptions?.title || e10.field) ?? "";
  }
  _constructPointCloudRendererLegendElements(_0) {
    return __async(this, arguments, function* (e10, t4 = {}) {
      const s8 = t4.title, i7 = [];
      let l9 = null, r8 = null;
      if (Ve(e10)) l9 = { type: "symbol-table", title: s8 || this._getPointCloudRendererTitle(e10), infos: [] }, e10.colorClassBreakInfos.forEach((e11) => {
        l9.infos.unshift({ label: e11.label || e11.minValue + " - " + e11.maxValue, value: [e11.minValue, e11.maxValue], symbol: this._getAppliedCloneSymbol(fe, e11.color) });
      });
      else if (De(e10)) {
        const t5 = e10.stops;
        let i8 = null;
        if (t5?.length && (1 === t5.length && (i8 = t5[0].color), !i8)) {
          const e11 = t5[0].value, s9 = t5[t5.length - 1].value;
          if (null != e11 && null != s9) {
            i8 = u4(e11 + (s9 - e11) / 2, t5);
          }
        }
        l9 = { type: "symbol-table", title: null, infos: [{ label: null, value: null, symbol: this._getAppliedCloneSymbol(fe, i8 || fe.color) }] };
        const n8 = a2(e10.stops ?? []) ?? [];
        r8 = { type: "color-ramp", title: s8 || this._getPointCloudRendererTitle(e10), infos: n8, preview: V3(n8.map((e11) => e11.color), { ariaLabel: yield Qe("previewColorRampAriaLabel") }) };
      } else xe(e10) && (l9 = { type: "symbol-table", title: s8 || this._getPointCloudRendererTitle(e10), infos: [] }, e10.colorUniqueValueInfos?.forEach((e11) => {
        l9.infos.push({ label: e11.label || e11.values.join(", "), value: e11.values.join(", "), symbol: this._getAppliedCloneSymbol(fe, e11.color) });
      }));
      l9?.infos.length && i7.push(l9), r8?.infos.length && i7.push(r8);
      const n7 = i7.reduce((e11, t5) => [...e11, ...t5.infos ?? []], []).filter((e11) => !!e11.symbol).map((t5) => this._getSymbolPreview(t5, this.opacity, { symbolConfig: { applyColorModulation: !!e10.colorModulation } }));
      return yield Promise.allSettled(n7), i7;
    });
  }
  _getElementInfoForDotDensity(e10, t4) {
    return __async(this, null, function* () {
      const { color: s8, label: i7, valueExpressionTitle: l9 } = t4, { backgroundColor: r8, outline: n7, dotSize: a10 } = e10, o5 = this.effectList, u11 = o5?.effects.map((e11) => e11.toJSON()), c9 = i2(u11), d10 = yield Qe("previewTemplateAriaLabel", i7 || l9), y9 = a10 + "-" + s8 + "-" + r8 + "-" + (n7 && JSON.stringify(n7.toJSON())) + "-" + c9, h7 = this._dotDensityUrlCache, m7 = h7.has(y9) ? h7.get(y9) : w2(e10, s8, { ariaLabel: d10 });
      h7.set(y9, m7);
      const p8 = { shape: { type: "image", x: 0, y: 0, width: m7.width, height: m7.height, src: m7.src }, fill: null, stroke: null, offset: [0, 0] }, f7 = l3([[p8]], [m7.width, m7.height], { effectView: this.effectList, ariaLabel: d10 });
      return { opacity: 1, src: m7.src, preview: f7, width: m7.width, height: m7.height };
    });
  }
  _constructDotDensityRendererLegendElements(e10) {
    return __async(this, null, function* () {
      const t4 = e10.calculateDotValue(this.view.scale), s8 = e10.legendOptions?.unit, i7 = { type: "symbol-table", title: { value: t4 && Math.round(t4), unit: s8 || "" }, infos: [] };
      for (const l9 of e10.attributes) {
        const t5 = yield this._getElementInfoForDotDensity(e10, l9);
        t5.label = l9.label || l9.valueExpressionTitle || l9.field, i7.infos.push(t5);
      }
      return [i7];
    });
  }
  _constructPieChartRendererLegendElements(e10) {
    return __async(this, null, function* () {
      const t4 = this.layer.opacity, s8 = [];
      let i7 = null;
      const l9 = e10.outline;
      e10.attributes.forEach((e11) => {
        const t5 = new y({ color: e11.color, outline: l9 }), i8 = e11.label || e11.valueExpressionTitle || e11.field;
        s8.push({ label: i8, symbol: t5 });
      });
      const r8 = s8.length ? [...s8] : [];
      if (e10.othersCategory?.color && 0 !== e10.othersCategory?.threshold) {
        const t5 = new y({ color: e10.othersCategory.color, outline: l9 });
        i7 = e10.othersCategory.label || "Other", s8.push({ label: i7, symbol: t5 });
      }
      if (e10.defaultColor?.a) {
        const t5 = new y({ color: e10.defaultColor, outline: l9 });
        s8.push({ label: e10.defaultLabel, symbol: t5 });
      }
      const n7 = (yield this._getVisualVariableLegendElements(e10, this.layer)) || [];
      if (s8.length) {
        n7.unshift({ type: "symbol-table", title: null, infos: s8 });
        const t5 = r8.filter((e11) => e11.label !== i7).map((e11) => e11.symbol.color).filter(Boolean), a11 = S2(t5, { holePercentage: e10.holePercentage, backgroundColor: e10.backgroundFillSymbol?.color, effectList: this.effectList, outline: l9, ariaLabel: yield Qe("previewPieChartAriaLabel") });
        n7.unshift({ type: "pie-chart-ramp", title: this._getRendererTitle(e10, this.layer), infos: s8, preview: a11 });
      }
      const a10 = n7.reduce((e11, t5) => [...e11, ...this._getAllInfos(t5)], []).filter((e11) => !!e11?.symbol && !e11?.preview).map((e11) => this._getSymbolPreview(e11, t4, { effectList: this.effectList }));
      return yield Promise.allSettled(a10), n7;
    });
  }
  _getWhereClause(e10, t4, s8) {
    return __async(this, null, function* () {
      const i7 = yield e4(e10, s8), l9 = yield qe(t4, s8), r8 = new Set(l9.map((e11) => e11.toLowerCase())), n7 = i7?.fieldNames.map((e11) => e11.toLowerCase());
      return n7?.some((e11) => !r8.has(e11)) ? null : i7;
    });
  }
  _processDefinitionExpression(e10, t4) {
    return __async(this, null, function* () {
      if (!("definitionExpression" in e10)) return;
      const s8 = e10.definitionExpression;
      s8 && this.respectLayerDefinitionExpression ? this._layerDefinitionExpression !== s8 && (this._layerDefinitionExpressionClause = yield this._getWhereClause(s8, t4, e10.fieldsIndex)) : this._layerDefinitionExpressionClause = null, this._layerDefinitionExpression = s8;
    });
  }
  _processDisplayFilter(e10, t4) {
    return __async(this, null, function* () {
      if (!("displayFilterInfo" in e10)) return;
      const s8 = e10.displayFilterInfo ? u2(e10.displayFilterInfo, this.view) : null;
      return s8?.where ? this._layerDisplayFilterId !== s8?.id && (this._layerDisplayFilterClause = yield this._getWhereClause(s8.where, t4, e10.fieldsIndex)) : this._layerDisplayFilterClause = null, this._layerDisplayFilterId = s8?.id, s8;
    });
  }
  _constructRendererLegendElements(_0) {
    return __async(this, arguments, function* (e10, t4 = {}) {
      const { title: s8, sublayer: i7 } = t4, l9 = i7 || this.layer, r8 = c3(e10);
      let n7 = null;
      Ce(e10) && (yield this._processDefinitionExpression(l9, e10), n7 = yield this._processDisplayFilter(l9, e10)), this._hasColorRamp = false, this._hasOpacityRamp = false, this._hasSizeRamp = false, this._scaleDrivenSizeVariable = null;
      const a10 = (yield this._getVisualVariableLegendElements(e10, l9)) || [], o5 = { type: "symbol-table", title: s8 || this._getRendererTitle(e10, l9), infos: [] };
      let u11 = null, c9 = false;
      const d10 = /* @__PURE__ */ new Set();
      if (be(e10) && !this._hasSizeRamp) {
        const t5 = yield p3(e10);
        o5.infos.push({ label: null, symbol: t5 });
      } else if (We(e10)) {
        let t5 = s8;
        const i8 = Ge(e10) ? "univariate-above-and-below-ramp" : "univariate-color-size-ramp", l10 = a10.findIndex((e11) => "color-ramp" === e11.type), r9 = -1 !== l10 ? a10.splice(l10, 1)[0] : null, n8 = a10.findIndex((e11) => "size-ramp" === e11.type), o6 = -1 !== n8 ? a10.splice(n8, 1)[0] : null, u12 = [];
        r9 && (t5 = r9.title, u12.push(r9)), o6 && (t5 = o6.title, u12.push(o6)), u12.length > 0 && a10.push({ type: i8, title: t5, infos: u12 });
      } else if (Ie(e10)) {
        const t5 = r4(e10);
        a10.push({ type: "heatmap-ramp", title: s8 || this._getRendererTitle(e10, l9), infos: t5, preview: V3(t5.map((e11) => e11.color), { effectList: this.effectList, ariaLabel: yield Qe("previewColorRampAriaLabel") }) });
      } else if (Ce(e10)) {
        const t5 = e10.authoringInfo;
        if (t5 && "relationship" === t5.type) {
          const { numClasses: s9, field1: i8, field2: r9 } = t5, n8 = t5.focus;
          if (s9 && i8 && r9) {
            const t6 = [i8, r9];
            let u12 = u5(n8) || 0;
            for (const e11 of t6) {
              const { field: t7, normalizationField: s10, label: i9 } = e11, r10 = i9 || { field: this._getFieldAlias(t7, l9), normField: s10 && this._getFieldAlias(s10, l9) }, n9 = Ke.clone();
              n9.angle = u12, o5.infos.push({ label: r10, symbol: n9 }), d10.add(n9), u12 += 90;
            }
            const c10 = i4({ focus: n8, numClasses: s9, infos: e10.uniqueValueInfos ?? [] });
            a10.unshift(c10);
          }
        } else if (Ne(this.layer) || qe2(this.layer)) e10.uniqueValueInfos?.forEach((t6) => {
          t6.symbol && this._checkClausesForUVR(e10, t6.value) && o5.infos.push({ label: t6.label || t6.value, value: t6.value, symbol: t6.symbol });
        });
        else {
          const { field: t6, field2: i8, field3: a11, fieldDelimiter: u12, valueExpression: d11, defaultSymbol: y10 } = e10, h8 = !(!t6 && !d11 || !i8 && !a11), m8 = this._layerDisplayFilterClause ? n7?.title : null, p9 = [];
          if (e10.uniqueValueGroups?.forEach((s9) => {
            const n8 = { type: "symbol-table", title: m8 || s9.heading, infos: [] };
            s9.classes?.forEach((s10) => {
              const { symbol: o6, values: c10 } = s10;
              if (o6) {
                const y11 = [], m9 = [];
                for (const e11 of c10 ?? []) {
                  const { value: s11, value2: r9, value3: n9 } = e11, o7 = [], c11 = [];
                  (t6 || d11) && (o7.push(s11), c11.push(this._getDomainName(t6, s11, l9))), i8 && (o7.push(r9), c11.push(this._getDomainName(i8, r9, l9))), a11 && (o7.push(n9), c11.push(this._getDomainName(a11, n9, l9))), y11.push(h8 ? o7.join(u12 || "") : o7[0]), m9.push(c11.join(" - "));
                }
                const p10 = y11.join(", ");
                let f8 = s10.label;
                if (!f8) {
                  const e11 = m9.filter(Boolean);
                  f8 = e11.length ? e11.join(", ") : p10;
                }
                const g7 = o6.clone();
                "cim" === g7.type && r8 && d3(g7, { innerDotSize: 0.5 * ue, outerRingSize: ue }), y11.some((t7) => this._checkClausesForUVR(e10, t7)) && n8.infos.push({ label: f8, value: p10, symbol: g7 });
              }
            }), n8.infos.length && p9.push(n8);
          }), p9.length) {
            const t7 = p9[0];
            1 === p9.length && "title" in t7 && !t7.title ? o5.infos.push(...t7.infos ?? []) : (y10 && (p9.push({ type: "symbol-table", infos: [{ label: e10.defaultLabel || "others", symbol: y10 }] }), c9 = true), o5.infos.push(...p9)), s8 || e10.legendOptions?.title || e10.valueExpressionTitle || (o5.title = null);
          }
        }
        e10.defaultSymbol && !c9 && (o5.infos.push({ label: e10.defaultLabel || "others", symbol: e10.defaultSymbol }), c9 = true);
      } else if (Ee(e10)) {
        if (!r8) {
          u11 = this._isUnclassedRenderer(e10);
          if (!u11 || !this._hasSizeRamp) {
            const t5 = e10.classBreakInfos.filter(({ symbol: e11 }) => e11), s9 = "ascending-values" === e10.legendOptions?.order;
            for (const { label: e11, minValue: i8, maxValue: l10, symbol: r9 } of t5) {
              const t6 = { label: e11 || (u11 ? null : `${i8} - ${l10}`), value: [i8, l10], symbol: r9 };
              s9 ? o5.infos.push(t6) : o5.infos.unshift(t6);
            }
            u11 && (o5.title = null), this._updateInfosForClassedSizeRenderer(e10, o5.infos);
          }
          e10.defaultSymbol && !u11 && (o5.infos.push({ label: e10.defaultLabel || "others", symbol: e10.defaultSymbol }), c9 = true);
        }
      } else if (we(e10)) if (qe2(this.layer) || He(this.layer)) {
        const t5 = yield this._constructTileImageryStretchRendererElements(e10);
        $e(t5) ? a10.push(t5) : o5.infos = t5;
      } else {
        const t5 = this.layer;
        let s9, i8;
        e10.customStatistics?.length && ({ min: s9, max: i8 } = e10.customStatistics[0]);
        let l10 = [], r9 = t5.serviceRasterInfo;
        if (t5.rasterFunction) try {
          r9 = yield t5.generateRasterInfo(t5.rasterFunction);
        } catch {
        }
        const n8 = s3(r9.pixelType);
        if (1 === r9.bandCount) {
          const l11 = t5.bandIds?.[0] || 0;
          s9 = null != s9 ? s9 : r9.statistics ? r9.statistics[l11].min : n8[0], i8 = null != i8 ? i8 : r9.statistics ? r9.statistics[l11].max : n8[1], s9 || i8 ? a10.push(yield this._getStretchLegendElements(e10, { min: s9, max: i8 })) : this._getServerSideLegend();
        } else if (t5.bandIds && 1 === t5.bandIds.length) s9 = null != s9 ? s9 : r9.statistics ? r9.statistics[t5.bandIds[0]].min : n8[0], i8 = null != i8 ? i8 : r9.statistics ? r9.statistics[t5.bandIds[0]].max : n8[1], s9 || i8 ? a10.push(yield this._getStretchLegendElements(e10, { min: s9, max: i8 })) : this._getServerSideLegend();
        else if (r9.bandCount >= 3) {
          const { bandInfos: e11 } = r9, { bandIds: s10 } = t5;
          e11.length >= r9.bandCount ? 3 === s10?.length ? (l10 = s10.map((t6) => e11[t6].name), o5.infos = this._createSymbolTableElementMultiBand(l10)) : "lerc" === t5.format ? (l10 = [0, 1, 2].map((t6) => e11[t6].name), o5.infos = this._createSymbolTableElementMultiBand(l10)) : this._getServerSideLegend() : "lerc" === t5.format ? (l10 = ["band1", "band2", "band3"], o5.infos = this._createSymbolTableElementMultiBand(l10)) : this._getServerSideLegend();
        } else this._getServerSideLegend();
      }
      else if (_e(e10)) e10.colormapInfos.forEach((e11) => {
        o5.infos.push({ label: e11.label, value: e11.value, symbol: this._getAppliedCloneSymbol(ge, e11.color) });
      });
      else if (Le(e10)) {
        let s9 = e10.symbol;
        switch (t4.geometryType) {
          case "point":
            s9 = "pointSymbol" in l9 ? l9.pointSymbol : null;
            break;
          case "polyline":
            s9 = "lineSymbol" in l9 ? l9.lineSymbol : null;
            break;
          case "polygon":
            s9 = "polygonSymbol" in l9 ? l9.polygonSymbol : null;
        }
        const i8 = this._hasClusterSizeVariable && this._getClusterSymbol() || !this._hasSizeRamp;
        e10.symbol && i8 && o5.infos.push({ label: e10.label, symbol: s9 });
      } else if (Se(e10)) {
        e10.outputUnit && (this.title = "(" + e10.toJSON().outputUnit + ")"), o5.title = e10.attributeField;
        const t5 = e10.getClassBreakInfos();
        t5?.length ? t5.forEach((e11) => {
          o5.infos.push({ label: e11.minValue + " - " + e11.maxValue, symbol: e11.symbol });
        }) : o5.infos.push({ label: e10.attributeField, symbol: e10.getDefaultSymbol() });
      } else ve(e10) && a10.push(yield this._getStretchLegendElements(e10, { min: 0, max: 255 }));
      const y9 = e10.defaultSymbol;
      !y9 || c9 || Le(e10) || u11 && !this._hasColorRamp && !this._hasSizeRamp && !this._hasOpacityRamp || a10.push({ type: "symbol-table", infos: [{ label: e10.defaultLabel || "others", symbol: y9 }] }), o5.infos.length && a10.unshift(o5);
      const h7 = null == t4.opacity ? this.opacity : t4.opacity, m7 = this._isTallSymbol("visualVariables" in e10 ? e10.visualVariables : null), p8 = Ne(this.layer) || qe2(this.layer), f7 = a10.reduce((e11, t5) => [...e11, ...this._getAllInfos(t5)], []).filter((e11) => !!e11?.symbol).filter((e11) => {
        if ("cim" === e11.symbol.type) {
          const { minScale: t5, maxScale: s9 } = e11.symbol.data;
          if (t5 && t5 < this.scale || s9 && s9 > this.scale) return false;
        }
        return true;
      }).map((e11) => this._getSymbolPreview(e11, h7, { isDefault: e11.symbol === y9, applyScaleDrivenSize: !d10.has(e11.symbol), symbolConfig: { isTall: m7, isSquareFill: p8 }, effectList: d10.has(e11.symbol) ? null : this.effectList }));
      return e10 = null, yield Promise.allSettled(f7), a10;
    });
  }
  _checkClausesForUVR(e10, t4) {
    const s8 = Ze(e10, t4);
    return !s8 || (!this._layerDefinitionExpressionClause || this._layerDefinitionExpressionClause.testFeature(s8)) && (!this._layerDisplayFilterClause || this._layerDisplayFilterClause.testFeature(s8));
  }
  _getServerSideLegend() {
    setTimeout(() => this.buildLegendElementsForTools(), 0);
  }
  _getAllInfos(e10) {
    const t4 = e10?.infos;
    return t4 ? t4.reduce((e11, t5) => e11.concat(this._getAllInfos(t5)), []) : [e10];
  }
  _constructTileImageryStretchRendererElements(e10) {
    return __async(this, null, function* () {
      const t4 = this.layer, s8 = t4.symbolizer.rasterInfo ?? t4.raster.rasterInfo;
      let i7, l9;
      const r8 = e10?.customStatistics?.length ? e10.customStatistics : s8?.statistics;
      if (r8) ({ min: i7, max: l9 } = r8[0]);
      else {
        const e11 = s3(s8.pixelType);
        i7 = e11[0], l9 = e11[1];
      }
      if (t4.hasStandardTime() && (i7 = t4.getStandardTimeValue(i7), l9 = t4.getStandardTimeValue(l9)), 1 === s8.bandCount || 1 === t4.bandIds?.length) return this._getStretchLegendElements(e10, { min: i7, max: l9 });
      const n7 = (t4?.bandIds?.length ? t4.bandIds : Array.from(Array(Math.min(s8.bandCount, 3)).keys())).map((e11) => s8.bandInfos[e11].name);
      return n7.length < 3 ? n7.push(n7[1]) : n7.length > 3 && n7.splice(3), this._createSymbolTableElementMultiBand(n7);
    });
  }
  _getStretchLegendElements(e10, t4) {
    return __async(this, null, function* () {
      const s8 = e10.colorRamp, i7 = i3(s8, t4);
      return { type: "stretch-ramp", title: "", infos: i7, preview: V3(i7.map((e11) => e11.color), { ariaLabel: yield Qe("previewColorRampAriaLabel") }) };
    });
  }
  _getClusterSymbol() {
    const e10 = this.layer, t4 = "featureReduction" in e10 && e10.featureReduction, s8 = t4 && "symbol" in t4 && t4.renderer;
    return s8 && true !== s8?.authoringInfo?.isAutoGenerated ? null : t4 && "symbol" in t4 ? t4.symbol : null;
  }
  _getSizeLegendElement(e10, t4, s8, i7) {
    return __async(this, null, function* () {
      return { type: "size-ramp", title: this._hasClusterSizeVariable ? this._getClusterTitle(t4) : e10, infos: yield I2(s8, t4, yield u3(s8), this.scale, this.view, i7, this._hasClusterSizeVariable ? this._getClusterSymbol() : null) };
    });
  }
  _createSymbolTableElementMultiBand(e10) {
    const t4 = [], s8 = ["red", "green", "blue"];
    return e10.forEach((e11, i7) => {
      t4.push({ label: { colorName: s8[i7], bandName: e11 }, src: s4[i7], opacity: this.opacity ?? 1 });
    }), t4;
  }
  _updateInfosForClassedSizeRenderer(e10, t4) {
    const s8 = e10.authoringInfo && "class-breaks-size" === e10.authoringInfo.type, i7 = e10.classBreakInfos.some((e11) => y2(e11.symbol));
    if (s8 && i7) {
      const s9 = b2, i8 = h3, l9 = e10.classBreakInfos.length, r8 = (s9 - i8) / (l9 > 1 ? l9 - 1 : l9);
      t4.forEach((e11, t5) => {
        e11.size = s9 - r8 * t5;
      });
    }
  }
  _isTallSymbol(e10) {
    let t4 = false, s8 = false;
    if (e10) for (let i7 = 0; i7 < e10.length && (!t4 || !s8); i7++) {
      const l9 = e10[i7];
      "size" === l9.type && ("height" === l9.axis && (t4 = true), "width-and-depth" === l9.axis && (s8 = true));
    }
    return t4 && s8;
  }
  _getSymbolPreview(e10, t4, s8) {
    return __async(this, null, function* () {
      let i7 = !s8?.isDefault && null == e10.size && this._hasSizeRamp ? e3(t3.size) : e10.size;
      if (this._scaleDrivenSizeVariable && s8?.applyScaleDrivenSize) {
        const { getSize: t5 } = yield import("./visualVariableUtils-56TFSNIY.js");
        i7 = t5(this._scaleDrivenSizeVariable, null, { view: this.view.type, scale: this.scale, shape: "simple-marker" === e10.symbol.type ? e10.symbol.style : null });
      }
      const l9 = !s8?.isDefault && this._hasSizeRamp || !(!this._scaleDrivenSizeVariable || !s8?.applyScaleDrivenSize);
      return L(e10.symbol, { size: i7, opacity: t4, scale: false, symbolConfig: s8?.symbolConfig, effectView: s8?.effectList, style: "legend", cimOptions: { allowScalingUp: l9, viewParams: this.isScaleDriven ? { viewingMode: "2d" === this.view?.type ? "map" : this.view?.viewingMode, scale: this.view?.scale } : null }, ariaLabel: e10.label && "string" != typeof e10.label ? null : yield Qe("previewTemplateAriaLabel", e10.label) }).then((t5) => (e10.preview = t5, e10)).catch(() => (e10.preview = null, e10));
    });
  }
  _getClusterRenderer(e10) {
    this._hasClusterSizeVariable = false;
    const t4 = "renderer" in this.layer ? this.layer.renderer : null, s8 = e10.renderer?.clone() || t4?.clone(), i7 = l4(e10, this.layerView, this.view);
    if (i7 && null != s8 && "visualVariables" in s8) {
      const t5 = s8.visualVariables?.some((e11) => "size" === e11.type && "outline" !== e11.target && !me.test(e11.valueExpression));
      if (!t5) {
        if ("clusterMinSize" in e10 && "clusterMaxSize" in e10) {
          const { clusterMinSize: t7, clusterMaxSize: s9 } = e10;
          i7.legendOptions = new p2({ showLegend: t7 !== s9 });
        }
        const t6 = s8.visualVariables || [];
        s8.visualVariables = t6.concat([i7]), this._hasClusterSizeVariable = true;
      }
    }
    return s8;
  }
  _loadRenderer(e10) {
    return __async(this, null, function* () {
      const t4 = [], s8 = e10.clone(), i7 = yield u3(s8);
      if (Ee(s8) || Ce(s8)) {
        const e11 = (s8.classBreakInfos || s8.uniqueValueInfos).map((e12) => this._fetchSymbol(e12.symbol, i7).then((t5) => {
          e12.symbol = t5;
        }).catch(() => {
          e12.symbol = null;
        }));
        Array.prototype.push.apply(t4, e11);
      }
      return t4.push(this._fetchSymbol(s8.symbol || s8.defaultSymbol, s8.defaultSymbol ? null : i7).then((e11) => {
        this._applySymbolToRenderer(s8, e11, Le(s8));
      }).catch(() => {
        this._applySymbolToRenderer(s8, null, Le(s8));
      })), yield Promise.allSettled(t4), s8;
    });
  }
  _applySymbolToRenderer(e10, t4, s8) {
    s8 ? e10.symbol = t4 : e10.defaultSymbol = t4;
  }
  _fetchSymbol(e10, t4) {
    return __async(this, null, function* () {
      if (!e10) throw new Error();
      if ("web-style" === e10.type) {
        const s8 = this._webStyleSymbolCache;
        try {
          const i7 = yield "2d" === this.view.type ? e10.fetchCIMSymbol({ cache: s8 }) : e10.fetchSymbol({ cache: s8 });
          return this._getAppliedCloneSymbol(i7, t4);
        } catch {
          throw n.getLogger(this).warn("Fetching web-style failed!"), new Error();
        }
      }
      return this._getAppliedCloneSymbol(e10, t4);
    });
  }
  _getAppliedCloneSymbol(e10, s8) {
    if (!e10 || !s8) return e10;
    const i7 = e10.clone(), l9 = s8 && s8.toRgba();
    return i7.type.includes("3d") ? this._applyColorTo3dSymbol(i7, l9) : "cim" === i7.type ? I(i7, s8) : i7.color && (i7.color = new h2(l9 || i7.color)), i7;
  }
  _applyColorTo3dSymbol(e10, s8) {
    s8 && e10.symbolLayers.forEach((e11) => {
      e11 && (e11.material || (e11.material = {}), e11.material.color = new h2(s8));
    });
  }
  _getVisualVariableLegendElements(e10, t4) {
    return __async(this, null, function* () {
      if (!("visualVariables" in e10) || "vector-field" === e10.type) return null;
      const s8 = e10.visualVariables ?? [], i7 = [], l9 = [], n7 = [], a10 = c3(e10);
      if (2 === a10?.sizeStops?.length && (Ee(e10) || Ce(e10))) {
        const [e11, t5] = a10.sizeStops;
        l9.push(new b({ field: a10.field ?? void 0, normalizationField: a10.normalizationField, minSize: e11.size, maxSize: t5.size, minDataValue: e11.value, maxDataValue: t5.value }));
      }
      for (const r8 of s8) "color" === r8.type ? i7.push(r8) : "size" === r8.type ? l9.push(r8) : "opacity" === r8.type && n7.push(r8);
      const o5 = [...i7, ...l9, ...n7];
      let u11, c9;
      if (0 === i7.length && Ee(e10) && e10.classBreakInfos && 1 === e10.classBreakInfos.length) {
        const t5 = e10.classBreakInfos[0];
        u11 = t5 && t5.symbol;
      }
      if (0 === i7.length && Le(e10) && (u11 = e10.symbol), u11) if (u11.type.includes("3d")) {
        const e11 = u11.symbolLayers.at(0);
        "water" === e11.type ? null != e11.color && (c9 = e11.color) : null != e11.material?.color && (c9 = e11.material.color);
      } else u11.url || (c9 = u11.color);
      const d10 = this.effectList;
      return (yield Promise.all(o5.map((s9) => __async(this, null, function* () {
        if (!s9.legendOptions || false !== s9.legendOptions.showLegend) {
          const i8 = be(e10) ? s9.field : this._getRampTitle(s9, t4);
          let l10 = null;
          const r8 = d2(t4, s9, this.view.timeZone);
          if ("color" === s9.type) {
            const e11 = (yield r3(s9, null, r8)) ?? [];
            l10 = { type: "color-ramp", title: i8, infos: e11, preview: V3(e11.map((e12) => e12.color), { effectList: d10, ariaLabel: yield Qe("previewColorRampAriaLabel") }) }, this._hasColorRamp || (this._hasColorRamp = e11.length > 0);
          } else if ("size" === s9.type && "outline" !== s9.target) me.test(s9.valueExpression) ? this._hasClusterSizeVariable || (this._scaleDrivenSizeVariable = s9) : (l10 = yield this._getSizeLegendElement(i8, s9, e10, r8), this._hasSizeRamp || (this._hasSizeRamp = !(null == l10.infos || !l10.infos.length)));
          else if ("opacity" === s9.type) {
            const e11 = (yield r3(s9, c9, r8)) ?? [];
            l10 = { type: "opacity-ramp", title: i8, infos: e11, preview: V3(e11.map((e12) => e12.color), { effectList: d10, ariaLabel: yield Qe("previewColorRampAriaLabel") }) }, this._hasOpacityRamp || (this._hasOpacityRamp = e11.length > 0);
          }
          return l10?.infos ? l10 : null;
        }
      })))).filter(G);
    });
  }
  _getDomainName(e10, t4, s8) {
    if (e10 && "function" != typeof e10) {
      const i7 = "getField" in s8 && s8.getField?.(e10), l9 = i7 && "getFieldDomain" in s8 && s8.getFieldDomain ? s8.getFieldDomain(i7.name, { excludeImpliedDomains: has("esri-widget-legacy-field-domain-calculation") }) : null;
      return "coded-value" === l9?.type ? l9.getName(t4) : null;
    }
    return null;
  }
  _getClusterTitle(e10) {
    const t4 = this.layer, s8 = e10.field;
    if ("featureReduction" in t4 && t4.featureReduction && "cluster" === t4.featureReduction.type) {
      const e11 = t4.featureReduction, i7 = "popupTemplate" in e11 && e11.popupTemplate, l9 = i7 && i7.fieldInfos;
      if (l9) {
        for (const t5 of l9) if (t5.fieldName === s8) return "cluster_count" === s8 ? t5.label || { showCount: true } : t5.label;
      }
    }
    return { showCount: true };
  }
  _getRampTitle(e10, t4) {
    let s8 = e10.field, i7 = e10.normalizationField, l9 = false, r8 = false, n7 = false, a10 = null;
    s8 = "function" == typeof s8 ? null : s8, i7 = "function" == typeof i7 ? null : i7;
    const o5 = e10.legendOptions?.title;
    if (null != o5) a10 = o5;
    else if (e10.valueExpressionTitle) a10 = e10.valueExpressionTitle;
    else {
      if ("renderer" in t4 && t4.renderer && "authoringInfo" in t4.renderer && t4.renderer.authoringInfo?.visualVariables) {
        const e11 = t4.renderer.authoringInfo.visualVariables;
        for (let t5 = 0; t5 < e11.length; t5++) {
          const s9 = e11[t5];
          if ("color" === s9.type) {
            if ("ratio" === s9.style) {
              l9 = true;
              break;
            }
            if ("percent" === s9.style) {
              r8 = true;
              break;
            }
            if ("percent-of-total" === s9.style) {
              n7 = true;
              break;
            }
          }
        }
      }
      a10 = { field: s8 && this._getFieldAlias(s8, t4), normField: i7 && this._getFieldAlias(i7, t4), ratio: l9, ratioPercent: r8, ratioPercentTotal: n7 };
    }
    return a10;
  }
  _getRendererTitle(e10, t4) {
    const s8 = e10;
    if (s8.legendOptions?.title) return s8.legendOptions.title;
    if (s8.valueExpressionTitle) return s8.valueExpressionTitle;
    let i7 = s8.field, l9 = null, r8 = null;
    if (Ee(s8) && (l9 = s8.normalizationField, r8 = "percent-of-total" === s8.normalizationType), i7 = "function" == typeof i7 ? null : i7, l9 = "function" == typeof l9 ? null : l9, Ce(s8)) {
      const { field2: e11, field3: l10, fieldDelimiter: r9 } = s8;
      let n8 = i7 && this._getFieldAlias(i7, t4);
      return e11 && (n8 = `<${n8}>${r9}<${this._getFieldAlias(e11, t4)}>`, l10 && (n8 = `${n8}${r9}<${this._getFieldAlias(l10, t4)}>`)), n8;
    }
    let n7 = null;
    return (i7 || l9) && (n7 = { field: i7 && this._getFieldAlias(i7, t4), normField: l9 && this._getFieldAlias(l9, t4), normByPct: r8 }), n7;
  }
  _getFieldAlias(e10, t4) {
    const s8 = "popupTemplate" in t4 ? t4.popupTemplate : null, i7 = s8?.fieldInfos;
    let l9 = i7?.find((t5) => e10 === t5.fieldName), r8 = null;
    "getField" in t4 && t4.getField ? r8 = t4.getField(e10) : "fieldsIndex" in t4 && t4.fieldsIndex && (r8 = t4.fieldsIndex.get(e10));
    let n7 = null;
    const a10 = "featureReduction" in t4 && t4.featureReduction;
    a10 && (l9 ??= "popupTemplate" in a10 ? a10.popupTemplate?.fieldInfos?.find((t5) => e10?.toLowerCase() === t5.fieldName?.toLowerCase()) : void 0, "fields" in a10 && a10.fields && (n7 = a10.fields.find((t5) => t5.name?.toLowerCase() === e10?.toLowerCase())));
    const o5 = l9 || r8 || n7;
    let u11 = null;
    return o5 && (u11 = l9?.label || r8?.alias || n7?.alias || "name" in o5 && o5.name || "fieldName" in o5 && o5.fieldName || null), u11;
  }
  _isUnclassedRenderer(e10) {
    const t4 = e10.visualVariables;
    let s8 = false;
    return Ee(e10) && e10.classBreakInfos && 1 === e10.classBreakInfos.length && t4 && (s8 = e10.field ? t4.some((t5) => !(!t5 || e10.field !== t5.field || (e10.normalizationField || t5.normalizationField) && e10.normalizationField !== t5.normalizationField)) : !!t4.length), s8;
  }
};
r([m()], Ye.prototype, "children", void 0), r([m({ readOnly: true })], Ye.prototype, "effectList", null), r([m()], Ye.prototype, "layerView", void 0), r([m()], Ye.prototype, "layer", void 0), r([m()], Ye.prototype, "legendElements", void 0), r([m({ readOnly: true })], Ye.prototype, "opacity", null), r([m()], Ye.prototype, "parent", void 0), r([m({ readOnly: true, dependsOn: [] })], Ye.prototype, "ready", null), r([m()], Ye.prototype, "hideLayersNotInCurrentView", void 0), r([m()], Ye.prototype, "keepCacheOnDestroy", void 0), r([m()], Ye.prototype, "respectLayerDefinitionExpression", void 0), r([m()], Ye.prototype, "respectLayerVisibility", void 0), r([m({ readOnly: true })], Ye.prototype, "scale", null), r([m()], Ye.prototype, "sublayerIds", void 0), r([m({ readOnly: true })], Ye.prototype, "isScaleDriven", null), r([m()], Ye.prototype, "title", void 0), r([m({ readOnly: true, dependsOn: ["ready"], value: 0 })], Ye.prototype, "version", null), r([m()], Ye.prototype, "view", void 0), Ye = r([a("esri.widgets.Legend.support.ActiveLayerInfo")], Ye);
var et = Ye;

// node_modules/@arcgis/core/widgets/Legend/LegendViewModel.js
var c4 = { state: "state", view: "view", allLayerViews: "all-layer-views", legendProperties: "legend-properties" };
var L2 = V.ofType(et);
var p4 = /* @__PURE__ */ new Set(["esri.layers.BuildingSceneLayer", "esri.layers.CatalogLayer", "esri.layers.CSVLayer", "esri.layers.FeatureLayer", "esri.layers.GeoJSONLayer", "esri.layers.GeoRSSLayer", "esri.layers.GroupLayer", "esri.layers.HeatmapLayer", "esri.layers.ImageryLayer", "esri.layers.ImageryTileLayer", "esri.layers.MapImageLayer", "esri.layers.OGCFeatureLayer", "esri.layers.OrientedImageryLayer", "esri.layers.ParquetLayer", "esri.layers.PointCloudLayer", "esri.layers.StreamLayer", "esri.layers.SceneLayer", "esri.layers.SubtypeGroupLayer", "esri.layers.TileLayer", "esri.layers.VoxelLayer", "esri.layers.WFSLayer", "esri.layers.WMSLayer", "esri.layers.WMTSLayer", "esri.layers.WCSLayer", "esri.layers.LinkChartLayer", "esri.layers.catalog.CatalogFootprintLayer", "esri.layers.catalog.CatalogDynamicGroupLayer", "esri.layers.knowledgeGraph.KnowledgeGraphSublayer", "esri.layers.KnowledgeGraphLayer"]);
var u6 = "view.basemapView.baseLayerViews";
var f2 = "view.groundView.layerViews";
var v3 = "view.basemapView.referenceLayerViews";
var _ = [u6, f2, "view.layerViews", v3];
var w3 = class extends g {
  constructor(e10) {
    super(e10), this._layerViewByLayerId = {}, this._layerInfosByLayerViewId = {}, this._activeLayerInfosByLayerViewId = {}, this._activeLayerInfosWithNoParent = new V(), this.activeLayerInfos = new L2(), this.basemapLegendVisible = false, this.groundLegendVisible = false, this.hideLayersNotInCurrentView = false, this.keepCacheOnDestroy = false, this.respectLayerDefinitionExpression = false, this.respectLayerVisibility = true, this.layerInfos = [], this.view = null;
  }
  initialize() {
    this.addHandles(d(() => this.view, () => this._viewHandles(), P), c4.view), this.addHandles(h(() => this._refresh()));
  }
  destroy() {
    this._destroyViewActiveLayerInfos(), this.view = null;
  }
  get state() {
    return this.view?.ready ? "ready" : "disabled";
  }
  _viewHandles() {
    this.removeHandles(c4.state), this.view && this.addHandles(d(() => this.state, () => this._stateHandles(), P), c4.state);
  }
  _stateHandles() {
    this._resetAll(), "ready" === this.state && this._watchPropertiesAndAllLayerViews();
  }
  _resetAll() {
    this.removeHandles([c4.allLayerViews, c4.legendProperties]), this._destroyViewActiveLayerInfos(), this.activeLayerInfos.removeAll();
  }
  _destroyViewActiveLayerInfos() {
    Object.keys(this._activeLayerInfosByLayerViewId).forEach(this._destroyViewActiveLayerInfo, this);
  }
  _destroyViewActiveLayerInfo(e10) {
    this.removeHandles(e10);
    const i7 = this._activeLayerInfosByLayerViewId[e10];
    delete this._activeLayerInfosByLayerViewId[e10], i7?.parent && i7.parent.children.remove(i7);
  }
  _watchPropertiesAndAllLayerViews() {
    const { view: e10 } = this;
    if (!e10) return;
    const { allLayerViews: i7 } = e10;
    i7.length && this._refresh(), this.addHandles(i7.on("change", (e11) => this._allLayerViewsChangeHandle(e11)), c4.allLayerViews), this.addHandles(d(() => [this.layerInfos, this.basemapLegendVisible, this.groundLegendVisible], () => this._propertiesChangeHandle()), c4.legendProperties);
  }
  _allLayerViewsChangeHandle(e10) {
    e10.moved.length ? this._propertiesChangeHandle() : (e10.removed.forEach((e11) => this._destroyViewActiveLayerInfo(e11.uid)), this._refresh());
  }
  _propertiesChangeHandle() {
    this._destroyViewActiveLayerInfos(), this._refresh();
  }
  _refresh() {
    this._layerInfosByLayerViewId = {}, this.activeLayerInfos.removeAll(), this._generateLayerViews().filter(this._filterLayerViewsByLayerInfos, this).filter(this._isLayerViewSupported, this).forEach(this._generateActiveLayerInfo, this), this._sortActiveLayerInfos(this.activeLayerInfos);
  }
  _sortActiveLayerInfos(e10) {
    const i7 = this.view;
    if (e10.length < 2 || !i7) return;
    const r8 = [];
    e10.forEach((i8) => {
      if (!i8.parent) {
        const t5 = i8.layer.parent, s8 = t5 && "uid" in t5 && this._layerViewByLayerId[t5.uid], a10 = s8 && this._activeLayerInfosByLayerViewId[s8.uid];
        a10 && e10.includes(a10) && (r8.push(i8), i8.parent = a10, a10.children.add(i8), this._sortActiveLayerInfos(a10.children));
      }
    }), e10.removeMany(r8);
    const t4 = {};
    i7.allLayerViews.forEach((e11, i8) => t4[e11.layer.uid] = i8), e10.sort((e11, i8) => {
      const r9 = t4[e11.layer.uid] || 0;
      return (t4[i8.layer.uid] || 0) - r9;
    });
  }
  _generateLayerViews() {
    const e10 = [];
    return _.filter(this._filterLayerViews, this).map((e11) => o(this, e11)).filter((e11) => null != e11).forEach(this._collectLayerViews("layerViews", e10)), e10;
  }
  _filterLayerViews(e10) {
    const i7 = !this.basemapLegendVisible && (e10 === u6 || e10 === v3), r8 = !this.groundLegendVisible && e10 === f2;
    return !i7 && !r8;
  }
  _collectLayerViews(e10, i7) {
    const r8 = (t4) => (t4 && t4.forEach((t5) => {
      i7.push(t5), r8(t5[e10]);
    }), i7);
    return r8;
  }
  _filterLayerViewsByLayerInfos(e10) {
    const i7 = this.layerInfos;
    return !i7 || !i7.length || i7.some((i8) => this._hasLayerInfo(i8, e10));
  }
  _hasLayerInfo(e10, i7) {
    const r8 = this._isLayerUIDMatching(e10.layer, i7.layer.uid);
    return r8 && (this._layerInfosByLayerViewId[i7.uid] = e10), r8;
  }
  _isLayerUIDMatching(e10, i7) {
    return e10 && (e10.uid === i7 || this._hasLayerUID(e10.layers, i7));
  }
  _hasLayerUID(e10, i7) {
    return e10 && e10.some((e11) => this._isLayerUIDMatching(e11, i7));
  }
  _isLayerViewSupported(e10) {
    return !!p4.has(e10.layer.declaredClass) && (this._layerViewByLayerId[e10.layer.uid] = e10, true);
  }
  _generateActiveLayerInfo(e10) {
    this._isLayerActive(e10) ? this._buildActiveLayerInfo(e10) : (this.removeHandles(e10.uid), this.addHandles(d(() => [e10.legendEnabled, e10.layer?.legendEnabled], () => this._layerActiveHandle(e10)), e10.uid));
  }
  _layerActiveHandle(e10) {
    this._isLayerActive(e10) && (this.removeHandles(e10.uid), this._buildActiveLayerInfo(e10));
  }
  _isLayerActive(e10) {
    return !this.respectLayerVisibility || e10.legendEnabled && e10.layer?.legendEnabled;
  }
  _buildActiveLayerInfo(e10) {
    const i7 = e10.layer, r8 = e10.uid, n7 = this._layerInfosByLayerViewId[r8];
    let o5 = this._activeLayerInfosByLayerViewId[r8];
    if (!o5) {
      const t4 = void 0 !== n7?.title && n7.layer.uid === i7.uid;
      o5 = new et({ layer: i7, layerView: e10, title: t4 ? n7.title : i7.title, view: this.view ?? void 0, respectLayerDefinitionExpression: this.respectLayerDefinitionExpression, respectLayerVisibility: this.respectLayerVisibility, hideLayersNotInCurrentView: this.hideLayersNotInCurrentView, keepCacheOnDestroy: this.keepCacheOnDestroy, sublayerIds: n7?.sublayerIds || [] }), this._activeLayerInfosByLayerViewId[r8] = o5;
    }
    const l9 = i7.parent && "uid" in i7.parent ? this._layerViewByLayerId[i7.parent?.uid] : null;
    if (o5.parent = this._activeLayerInfosByLayerViewId[l9?.uid], !this.hasHandles(r8)) {
      const n8 = [d(() => i7.title, (e11) => this._titleHandle(e11, o5)), d(() => [i7.opacity, "renderer" in i7 && i7.renderer, "pointSymbol" in i7 && i7.pointSymbol, "lineSymbol" in i7 && i7.lineSymbol, "polygonSymbol" in i7 && i7.polygonSymbol], () => this._constructLegendElements(o5)), p(() => true === this.view?.stationary, () => this._scaleHandle(o5), P), d(() => e10.layer ? e7(e10.layer, e10.view) : null, () => this._constructLegendElements(o5)), d(() => e10.updating, () => {
        if (null == e10.layer) return;
        null != e7(e10.layer, e10.view) && this._constructLegendElements(o5);
      }), d(() => "effect" in i7 && i7.effect, () => this._constructLegendElements(o5)), p(() => this.view?.timeZone, () => this._constructLegendElements(o5), P)];
      if (this.respectLayerVisibility) {
        const r9 = d(() => e10.legendEnabled, (e11) => this._legendEnabledHandle(e11, o5)), s8 = d(() => i7.legendEnabled, (e11) => this._legendEnabledHandle(e11, o5));
        n8.push(r9, s8);
      }
      if (this.respectLayerDefinitionExpression && "definitionExpression" in i7) {
        const e11 = d(() => [i7.definitionExpression, this.respectLayerDefinitionExpression], () => {
          o5.respectLayerDefinitionExpression = this.respectLayerDefinitionExpression, this._constructLegendElements(o5);
        });
        n8.push(e11);
      }
      this.addHandles(n8, r8);
    }
    o5.isScaleDriven || this._constructLegendElements(o5), this._addActiveLayerInfo(o5);
  }
  _titleHandle(e10, i7) {
    i7.title = e10, this._constructLegendElements(i7);
  }
  _legendEnabledHandle(e10, i7) {
    e10 ? this._addActiveLayerInfo(i7) : this._removeActiveLayerInfo(i7);
  }
  _scaleHandle(e10) {
    (e10.isScaleDriven || e10.hideLayersNotInCurrentView) && this._constructLegendElements(e10);
  }
  _addActiveLayerInfo(e10) {
    const { layerView: i7, layer: r8 } = e10;
    if (this._isLayerActive(i7) && !this.activeLayerInfos.includes(e10)) {
      const i8 = e10.parent;
      if (i8) i8.children.includes(e10) || i8.children.push(e10), this._sortActiveLayerInfos(i8.children);
      else {
        const i9 = this.layerInfos?.some((e11) => e11.layer.uid === r8.uid), t4 = r8.parent;
        (t4 && "uid" in t4 ? this._layerViewByLayerId[t4.uid] : null) && !i9 ? this._activeLayerInfosWithNoParent.add(e10) : (this.activeLayerInfos.add(e10), this._sortActiveLayerInfos(this.activeLayerInfos));
      }
      if (this._activeLayerInfosWithNoParent.length) {
        const e11 = [];
        this._activeLayerInfosWithNoParent.forEach((i9) => {
          const r9 = i9.layer.parent, t4 = r9 && "uid" in r9 ? this._layerViewByLayerId[r9?.uid] : null, s8 = this._activeLayerInfosByLayerViewId[t4?.uid];
          s8 && (e11.push(i9), i9.parent = s8);
        }), e11.length && (this._activeLayerInfosWithNoParent.removeMany(e11), e11.forEach((e12) => this._addActiveLayerInfo(e12)));
      }
    }
  }
  _removeActiveLayerInfo(e10) {
    const i7 = e10.parent;
    i7 ? i7.children.remove(e10) : this.activeLayerInfos.remove(e10);
  }
  _constructLegendElements(e10) {
    const i7 = e10.layer;
    "featureCollections" in i7 && i7.featureCollections ? e10.buildLegendElementsForFeatureCollections(i7.featureCollections) : "featureReduction" in i7 && i7.featureReduction && "renderer" in i7.featureReduction && ("binning" === i7.featureReduction.type || "cluster" === i7.featureReduction.type) && (!this.view || i7.featureReduction.maxScale <= this.view.scale) ? e10.buildLegendElementsForFeatureReduction(i7.featureReduction) : "renderer" in i7 && i7.renderer && !("sublayers" in i7) ? e10.buildLegendElementsForRenderer(i7.renderer) : "url" in i7 && i7.url && "catalog" !== i7.type && "knowledge-graph" !== i7.type ? e10.buildLegendElementsForTools() : e10.children.forEach((e11) => this._constructLegendElements(e11));
  }
};
r([m({ type: L2 })], w3.prototype, "activeLayerInfos", void 0), r([m()], w3.prototype, "basemapLegendVisible", void 0), r([m()], w3.prototype, "groundLegendVisible", void 0), r([m()], w3.prototype, "hideLayersNotInCurrentView", void 0), r([m()], w3.prototype, "keepCacheOnDestroy", void 0), r([m()], w3.prototype, "respectLayerDefinitionExpression", void 0), r([m()], w3.prototype, "respectLayerVisibility", void 0), r([m()], w3.prototype, "layerInfos", void 0), r([m({ readOnly: true })], w3.prototype, "state", null), r([m()], w3.prototype, "view", void 0), w3 = r([a("esri.widgets.Legend.LegendViewModel")], w3);
var I3 = w3;

// node_modules/@arcgis/core/widgets/Legend/styles/card/css.js
var e8 = "esri-legend--card";
var a4 = "esri-legend";
var r5 = { activated: `${e8}__carousel-indicator--activated`, base: e8, stacked: `${a4}--stacked`, carouselTitle: `${e8}__carousel-title`, indicator: `${e8}__carousel-indicator`, intervalSeparator: `${e8}__interval-separator`, imageryLayerStretchedImage: `${e8}__imagery-layer-image--stretched`, imageLabel: `${e8}__image-label`, layerCaption: `${e8}__layer-caption`, labelElement: `${e8}__label-element`, layerRow: `${e8}__layer-row`, labelCell: `${e8}__label-cell`, message: `${e8}__message`, rampLabel: `${e8}__ramp-label`, section: `${e8}__section`, relationshipSection: `${e8}__relationship-section`, serviceCaptionText: `${e8}__service-caption-text`, serviceContent: `${e8}__service-content`, service: `${e8}__service`, groupLayer: `${e8}__group-layer`, groupLayerChild: `${e8}__group-layer-child`, symbol: `${e8}__symbol`, sizeRampRow: `${e8}__size-ramp-row`, symbolRow: `${e8}__symbol-row`, symbolCell: `${e8}__symbol-cell`, carousel: `${e8}__carousel`, carouselItem: `${e8}__carousel-item`, indicatorContainer: `${e8}__carousel-indicator-container`, intervalSeparatorsContainer: `${e8}__interval-separators-container`, relationshipLabelContainer: `${e8}__relationship-label-container`, labelContainer: `${e8}__label-container`, serviceCaptionContainer: `${e8}__service-caption-container`, symbolContainer: `${e8}__symbol-container`, colorRampContainer: `${e8}__color-ramp-container`, sizeRampContainer: `${e8}__size-ramp-container`, sizeRampPreview: `${e8}__size-ramp-preview`, pieChartRampPreview: `${e8}__pie-chart-ramp-preview`, rampContainer: `${a4}__ramps`, sizeRampHorizontal: `${a4}__size-ramp--horizontal`, rampLabelsContainer: `${a4}__ramp-labels`, layerInfo: `${a4}__layer-cell ${a4}__layer-cell--info`, univariateAboveAndBelowColorRamp: "esri-univariate-above-and-below-ramp__color--card" };

// node_modules/@arcgis/core/widgets/Legend/support/styleUtils.js
function r6(e10, t4) {
  return t4;
}
function i5(e10) {
  const t4 = this;
  e10.appendChild(t4);
}
function o4(n7, i7, o5) {
  if (!i7) return;
  if ("number" == typeof i7) return i7;
  if ("string" == typeof i7) return c(i7);
  if ("value" in i7 || "unit" in i7) return s(n7.dotValue, i7);
  if ("colorName" in i7 && "bandName" in i7) return n7[i7.colorName] + ": " + (n7[i7.bandName] || i7.bandName);
  if ("showCount" in i7) return i7.showCount ? n7.clusterCountTitle : void 0;
  let u11 = null;
  return r6(i7, o5) ? u11 = i7.ratioPercentTotal ? "showRatioPercentTotal" : i7.ratioPercent ? "showRatioPercent" : i7.ratio ? "showRatio" : i7.normField ? "showNormField" : i7.field ? "showField" : null : l5(i7, o5) && (u11 = i7.normField ? "showNormField" : i7.normByPct ? "showNormPct" : i7.field ? "showField" : null), u11 ? s("showField" === u11 ? "{field}" : n7[u11], { field: i7.field, normField: i7.normField }) : void 0;
}
function l5(e10, t4) {
  return !t4;
}
function u7(e10, t4) {
  return !!(t4 && "Stretched" === t4 && "version" in e10 && "number" == typeof e10.version && e10.version >= 10.3 && "esri.layers.ImageryLayer" === e10.declaredClass);
}
function a5(e10, t4) {
  return e10.label ? t4[e10.label] + ": " + ("string" == typeof e10.value ? e10.value : l(e10.value ?? 0, { style: "decimal", notation: e10.value?.toString().toLowerCase().includes("e") ? "scientific" : "standard" })) : "";
}

// node_modules/@arcgis/core/widgets/Legend/styles/support/utils.js
function l6(e10, r8, l9) {
  switch (r8) {
    case "heatmap-ramp":
      return l9[e10.label] || e10.label;
    case "stretch-ramp":
      return a5(e10, l9);
    default:
      return e10.label;
  }
}
function i6(t4, l9) {
  if (!t4.title || "string" == typeof t4.title) return t4.title;
  const i7 = "color-ramp" === t4.type || "opacity-ramp" === t4.type, a10 = t4.title, p8 = o4(l9, a10, i7);
  return l5(a10, i7) && a10.title ? `${a10.title} (${p8})` : p8;
}

// node_modules/@arcgis/core/widgets/Legend/styles/card/ColorRamp.js
var n4 = 25;
var c5 = 25;
var m2 = 100;
var d4 = class extends O {
  constructor(e10, t4) {
    super(e10, t4), this.effectList = null, this.legendElement = null, this.opacity = 1;
  }
  render() {
    const e10 = this.legendElement.infos.slice().reverse();
    return n2("div", { class: this.classes(r5.layerRow, r5.colorRampContainer) }, this._renderRampLabel(e10[0]), n2("div", { class: r5.symbolContainer }, this._renderPreview(e10), this._renderMiddleStopRampLabel(e10)), this._renderRampLabel(e10.at(-1)));
  }
  _renderPreview(e10) {
    const { opacity: t4 } = this, r8 = "heatmap-ramp" === this.legendElement.type, i7 = e10.length - 1, l9 = c5, p8 = i7 > 2 && !r8 ? n4 * i7 : m2, d10 = p8 + 20, h7 = 10, y9 = [[{ shape: { type: "path", path: `M0 ${l9 / 2} L${h7} 0 L${h7} ${l9} Z` }, fill: e10[0].color, stroke: { width: 0 } }, { shape: { type: "rect", x: h7, y: 0, width: p8, height: l9 }, fill: { type: "linear", x1: h7, y1: 0, x2: p8 + h7, y2: 0, colors: e10.map((e11, t5) => ({ color: e11.color, offset: r8 && "ratio" in e11 ? e11.ratio : t5 / i7 })) }, stroke: { width: 0 } }, { shape: { type: "path", path: `M${p8 + h7} 0 L${d10} ${l9 / 2} L${p8 + h7} ${l9} Z` }, fill: e10[e10.length - 1].color, stroke: { width: 0 } }]], f7 = V2(y9, d10, l9), u11 = { filter: M(this.effectList) ?? void 0, opacity: null == t4 ? void 0 : `${t4}` };
    return n2("div", { styles: u11 }, f7);
  }
  _renderMiddleStopRampLabel(e10) {
    const t4 = e10.length % 2 != 0 ? e10[e10.length / 2 | 0] : null;
    return t4 ? n2("div", { class: r5.intervalSeparatorsContainer }, n2("div", { class: r5.intervalSeparator }, "|"), this._renderRampLabel(t4)) : null;
  }
  _renderRampLabel(e10) {
    return n2("div", { class: r5.rampLabel }, l6(e10, this.legendElement.type, this.messages));
  }
};
r([m()], d4.prototype, "effectList", void 0), r([m()], d4.prototype, "legendElement", void 0), r([m()], d4.prototype, "messages", void 0), r([m()], d4.prototype, "opacity", void 0), d4 = r([a("esri.widgets.Legend.styles.card.ColorRamp")], d4);
var h4 = d4;

// node_modules/@arcgis/core/widgets/Legend/styles/card/SizeRamp.js
var l7 = "#ddd";
var c6 = window.devicePixelRatio;
function p5(e10) {
  if (!e10) return;
  if (e10.type.includes("3d")) {
    if (!e10.symbolLayers?.length) return;
    const t5 = e10.symbolLayers.at(-1), s8 = t5.resource?.primitive;
    return "circle" === s8 || "cross" === s8 || "kite" === s8 || "sphere" === s8 || "cube" === s8 || "diamond" === s8;
  }
  const t4 = e10.style;
  return "circle" === t4 || "diamond" === t4 || "cross" === t4;
}
function d5(e10) {
  if (e10) {
    if (e10.type.includes("3d")) {
      if (!e10.symbolLayers?.length) return;
      const t4 = e10.symbolLayers.at(-1), s8 = t4?.resource?.primitive;
      return "triangle" === s8 || "cone" === s8 || "tetrahedron" === s8;
    }
    return "triangle" === e10.style;
  }
}
var m3 = class extends O {
  constructor(e10, t4) {
    super(e10, t4), this.hasIndicators = false, this.legendElement = null, this.opacity = 1;
  }
  render() {
    const { legendElement: e10, hasIndicators: t4, opacity: s8 } = this, o5 = e10.infos, _a = o5.at(0), { label: r8 } = _a, l9 = __objRest(_a, ["label"]), _b = o5.at(-1), { label: c9 } = _b, p8 = __objRest(_b, ["label"]);
    let d10 = l9.preview, m7 = p8.preview;
    const y9 = { "flex-direction": t4 ? "column" : "row-reverse" };
    d10 && (d10 = d10.cloneNode(true), d10.style.display = "flex"), m7 && (m7 = m7.cloneNode(true), m7.style.display = "flex");
    const u11 = { opacity: null != s8 ? `${s8}` : "" };
    return n2("div", { class: this.classes(r5.layerRow, { [r5.sizeRampRow]: t4 }) }, n2("div", { class: r5.rampLabel }, t4 ? r8 : c9), n2("div", { class: r5.sizeRampContainer, styles: y9 }, n2("div", { afterCreate: i5, bind: d10, class: r5.sizeRampPreview, styles: u11 }), this._renderSizeRampLines(e10), n2("div", { afterCreate: i5, bind: m7, class: r5.sizeRampContainer, styles: u11 })), n2("div", { class: r5.rampLabel }, t4 ? c9 : r8));
  }
  _renderSizeRampLines(e10) {
    const s8 = e10.infos, o5 = s8[0], r8 = s8.at(-1), i7 = o5.symbol, m7 = this.hasIndicators, y9 = u(o5.size + o5.outlineSize) * c6, u11 = u(r8.size + r8.outlineSize) * c6, f7 = m7 ? y9 : y9 + 50 * c6, h7 = m7 ? y9 / 2 + 50 * c6 : y9, g7 = d5(i7), v7 = p5(i7), b6 = document.createElement("canvas");
    b6.width = f7, b6.height = h7, b6.style.width = b6.width / c6 + "px", b6.style.height = b6.height / c6 + "px";
    const x = b6.getContext("2d");
    if (m7) {
      x.beginPath();
      const e11 = 0, t4 = 0, s9 = f7 / 2 - u11 / 2, o6 = h7;
      x.moveTo(e11, t4), x.lineTo(s9, o6);
      const r9 = f7, i8 = 0, n7 = f7 / 2 + u11 / 2, a10 = h7;
      x.moveTo(r9, i8), x.lineTo(n7, a10);
    } else {
      x.beginPath();
      const e11 = 0, t4 = h7 / 2 - u11 / 2, s9 = f7, o6 = 0;
      x.moveTo(e11, t4), x.lineTo(s9, o6);
      const r9 = 0, i8 = h7 / 2 + u11 / 2, n7 = f7, a10 = h7;
      x.moveTo(r9, i8), x.lineTo(n7, a10);
    }
    return x.strokeStyle = l7, x.stroke(), n2("div", { afterCreate: i5, bind: b6, styles: m7 ? { display: "flex", marginTop: `-${g7 ? 0 : v7 ? y9 / 2 : 0}px`, marginBottom: `-${g7 ? u11 : v7 ? u11 / 2 : 0}px` } : { display: "flex", marginRight: `-${g7 ? 0 : v7 ? y9 / 2 : 0}px`, marginLeft: `-${g7 ? 0 : v7 ? u11 / 2 : 0}px` } });
  }
};
r([m()], m3.prototype, "hasIndicators", void 0), r([m()], m3.prototype, "legendElement", void 0), r([m()], m3.prototype, "messages", void 0), r([m()], m3.prototype, "opacity", void 0), m3 = r([a("esri.widgets.Legend.styles.card.SizeRamp")], m3);
var y4 = m3;

// node_modules/@arcgis/core/widgets/Legend/styles/support/univariateUtils.js
var l8 = i();
var n5 = 10;
var r7 = 20;
var s7 = 10;
var a6 = 20;
var c7 = { univariateAboveAndBelowSymbol: "esri-univariate-above-and-below-ramp__symbol", colorRamp: "esri-legend__color-ramp" };
function f3(e10 = "vertical") {
  const t4 = "stroke:rgb(200, 200, 200);stroke-width:1";
  return "vertical" === e10 ? n2("svg", { height: "4", width: "10" }, n2("line", { style: t4, x1: "0", x2: "10", y1: "2", y2: "2" })) : n2("svg", { height: "10", width: "10" }, n2("line", { style: t4, x1: "5", x2: "5", y1: "0", y2: "10" }));
}
function p6(e10, t4 = "vertical") {
  const i7 = document.createElement("div");
  return i7.style.height = `${r7}px`, i7.className = c7.univariateAboveAndBelowSymbol, null != e10 && (i7.style.opacity = e10.toString()), l8.append(i7, f3.bind(null, t4)), i7;
}
function m4(t4, i7, o5 = "vertical", l9) {
  t4.infos.forEach((t5, n7) => {
    if (l9 && 2 === n7) t5.preview = p6(i7, o5);
    else {
      const i8 = u(t5.size) + ("horizontal" === o5 ? a6 : s7), l10 = t5.preview, n8 = "div" === l10?.tagName.toLowerCase(), r8 = n8 ? l10 : document.createElement("div");
      r8.className = c7.univariateAboveAndBelowSymbol, "horizontal" === o5 ? r8.style.width = `${i8}px` : r8.style.height = `${i8}px`, !n8 && l10 && r8.appendChild(l10), t5.preview = r8;
    }
  });
}
function u8(t4, i7 = "classic") {
  const o5 = t4.infos;
  return "classic" === i7 ? (u(o5[0].size) + s7) / 2 : (u(o5[0].size) - u(o5[o5.length - 1].size)) / 2;
}
function h5(e10, t4) {
  if (!e10) return null;
  const o5 = e10.infos.map((e11) => e11.color), l9 = V3("full" === t4.type ? o5 : "above" === t4.type ? o5.slice(0, 3) : o5.slice(2, 5), { width: t4.width, height: t4.height, align: t4.rampAlignment, effectList: t4.effectList, ariaLabel: t4.ariaLabel });
  return l9.className = c7.colorRamp, null != t4.opacity && (l9.style.opacity = t4.opacity.toString()), l9;
}
function v4(t4, i7, o5, l9 = "vertical") {
  let c9 = 0;
  const f7 = t4.infos, p8 = Math.floor(f7.length / 2), m7 = "full" === i7 || "above" === i7 ? 0 : p8, u11 = "full" === i7 || "below" === i7 ? f7.length - 1 : p8;
  for (let h7 = m7; h7 <= u11; h7++) if (o5 && h7 === p8) c9 += "horizontal" === l9 ? n5 : r7;
  else {
    c9 += u(f7[h7].size) + ("horizontal" === l9 ? a6 : s7);
  }
  return Math.round(c9);
}
function d6(t4, i7, o5, l9 = "vertical") {
  const c9 = v4(t4, i7, o5, l9), f7 = t4.infos, p8 = Math.floor(f7.length / 2), m7 = "full" === i7 || "above" === i7 ? 0 : p8, u11 = "full" === i7 || "below" === i7 ? f7.length - 1 : p8, h7 = "full" === i7 ? f7[m7].size + f7[u11].size : "above" === i7 ? f7[m7].size : f7[u11].size, d10 = o5 ? "vertical" === l9 ? r7 : n5 : 0, y9 = "vertical" === l9 ? s7 * ("full" === i7 ? 2 : 1) : a6 * ("full" === i7 ? 2 : 1);
  return Math.round(c9 - (u(h7) / 2 + d10 / 2 + y9 / 2));
}
function y5(e10, t4, i7 = "vertical") {
  const o5 = e10.infos;
  let l9 = o5.find(({ type: e11 }) => "size-ramp" === e11), n7 = o5.find(({ type: e11 }) => "color-ramp" === e11);
  return l9 && (l9 = __spreadValues({}, l9), l9.infos = [...l9.infos], m4(l9, t4, i7, true)), n7 && (n7 = __spreadValues({}, n7), n7.infos = [...n7.infos]), "horizontal" === i7 && (l9?.infos.reverse(), n7?.infos.reverse()), { sizeRampElement: l9, colorRampElement: n7 };
}
function b3(e10, t4 = "vertical") {
  const i7 = e10.infos;
  let o5 = i7.find(({ type: e11 }) => "size-ramp" === e11), l9 = i7.find(({ type: e11 }) => "color-ramp" === e11);
  return o5 && (o5 = __spreadValues({}, o5), o5.infos = [...o5.infos], m4(o5, null, t4, false)), l9 && (l9 = __spreadValues({}, l9), l9.infos = [...l9.infos]), "horizontal" === t4 && (o5?.infos.reverse(), l9?.infos.reverse()), { sizeRampElement: o5, colorRampElement: l9 };
}
var g3 = { marginLeft: "3px" };
var z = { display: "table-cell", verticalAlign: "middle" };
var w4 = { display: "flex", alignItems: "flex-start" };

// node_modules/@arcgis/core/widgets/Legend/styles/card/UnivariateAboveAndBelowRamp.js
var f4 = class extends O {
  constructor(e10, t4) {
    super(e10, t4), this.effectList = null, this.legendElement = null, this.opacity = 1;
  }
  render() {
    const { legendElement: e10, opacity: t4, effectList: o5, key: s8 } = this, { sizeRampElement: f7, colorRampElement: y9 } = y5(e10, t4, "horizontal");
    if (!f7) return null;
    const h7 = v4(f7, "full", true, "horizontal"), u11 = d6(f7, "above", true, "horizontal"), v7 = d6(f7, "below", true, "horizontal"), g7 = 12, b6 = this.messages?.previewColorRampAriaLabel, w6 = h5(y9, { width: u11, height: g7, rampAlignment: "horizontal", opacity: t4, type: "above", effectList: o5, ariaLabel: b6 }), j = h5(y9, { width: v7, height: g7, rampAlignment: "horizontal", opacity: t4, type: "below", effectList: o5, ariaLabel: b6 }), x = u8(f7, "card"), L4 = f7.infos.map((e11) => e11.label), z2 = L4.length - 1, C = L4.map((e11, t5) => 0 === t5 || t5 === z2 ? n2("div", { key: t5 }, e11) : null), R = { display: "flex", flexDirection: "column" }, A = { display: "flex", flexDirection: "row" }, k3 = { marginTop: "3px", display: "flex" };
    g2(this.container) ? k3.marginRight = `${x}px` : k3.marginLeft = `${x}px`;
    const E2 = { width: `${h7}px`, display: "flex", flexDirection: "row", justifyContent: "space-between" };
    return n2("div", { class: r5.layerRow, key: `${s8}-container`, styles: R }, n2("div", { class: this.classes(r5.symbolContainer, r5.sizeRampHorizontal), styles: A }, f7.infos.map((e11, t5) => n2("div", { afterCreate: i5, bind: e11.preview, class: r5.symbol, key: t5 }))), w6 ? n2("div", { class: r5.univariateAboveAndBelowColorRamp, key: "color-ramp-preview", styles: k3 }, n2("div", { afterCreate: i5, bind: w6 }), n2("div", { afterCreate: i5, bind: j })) : null, n2("div", { class: r5.layerInfo }, n2("div", { class: r5.rampLabelsContainer, styles: E2 }, C)));
  }
};
r([m()], f4.prototype, "effectList", void 0), r([m()], f4.prototype, "legendElement", void 0), r([m()], f4.prototype, "messages", void 0), r([m()], f4.prototype, "opacity", void 0), f4 = r([a("esri.widgets.Legend.styles.card.UnivariateAboveAndBelowRamp")], f4);
var y6 = f4;

// node_modules/@arcgis/core/widgets/Legend/styles/card/UnivariateColorSizeRamp.js
var d7 = class extends O {
  constructor(e10, t4) {
    super(e10, t4), this.effectList = null, this.legendElement = null, this.opacity = 1;
  }
  render() {
    const { legendElement: e10, opacity: t4, effectList: o5, key: s8 } = this, { sizeRampElement: d10, colorRampElement: y9 } = b3(e10, "horizontal");
    if (!d10) return null;
    const u11 = v4(d10, "full", false, "horizontal"), h7 = d6(d10, "full", false, "horizontal"), v7 = h5(y9, { width: h7, height: 12, rampAlignment: "horizontal", opacity: t4, type: "full", effectList: o5, ariaLabel: this.messages?.previewColorRampAriaLabel }), g7 = u8(d10, "card"), j = d10.infos.length - 1, x = d10.infos.map((e11, t5) => 0 === t5 || t5 === j ? n2("div", { key: t5 }, e11.label) : null), b6 = { display: "flex", flexDirection: "column" }, w6 = { display: "flex", flexDirection: "row" }, L4 = { marginTop: "3px", display: "flex" };
    g2(this.container) ? L4.marginRight = `${g7}px` : L4.marginLeft = `${g7}px`;
    const C = { width: `${u11}px`, display: "flex", flexDirection: "row", justifyContent: "space-between" };
    return n2("div", { class: r5.layerRow, key: `${s8}-container`, styles: b6 }, n2("div", { class: this.classes(r5.symbolContainer, r5.sizeRampHorizontal), styles: w6 }, d10.infos.map((e11, t5) => n2("div", { afterCreate: i5, bind: e11.preview, class: r5.symbol, key: t5 }))), n2("div", { class: r5.univariateAboveAndBelowColorRamp, key: "color-ramp-preview", styles: L4 }, n2("div", { afterCreate: i5, bind: v7 })), n2("div", { class: r5.layerInfo }, n2("div", { class: r5.rampLabelsContainer, styles: C }, x)));
  }
};
r([m()], d7.prototype, "effectList", void 0), r([m()], d7.prototype, "legendElement", void 0), r([m()], d7.prototype, "messages", void 0), r([m()], d7.prototype, "opacity", void 0), d7 = r([a("esri.widgets.Legend.styles.card.UnivariateColorSizeRamp")], d7);
var y7 = d7;

// node_modules/@arcgis/core/widgets/Legend/styles/card/LegendElement.js
var b4;
var L3 = b4 = class extends O {
  constructor(e10, s8) {
    super(e10, s8), this.effectList = null, this.hasIndicators = false, this.headingLevel = 3, this.isChild = false, this.legendElement = null;
  }
  render() {
    const e10 = this._renderLegendElement(), s8 = i6(this.legendElement, this.messages), t4 = this.hasIndicators && !this.isChild ? n2("div", null, n2(e6, { class: r5.carouselTitle, level: this.headingLevel }, this.activeLayerInfo.title), n2(e6, { class: r5.layerCaption, level: n3(this.headingLevel) }, s8)) : s8 ? n2(e6, { class: r5.layerCaption, level: this.headingLevel }, s8) : null;
    return n2("section", { "aria-labelledby": this.key, class: r5.section, id: `${this.key}-panel`, key: this.key, role: "tabpanel", tabIndex: 0 }, t4, e10);
  }
  _renderLegendElement() {
    switch (this.legendElement.type) {
      case "symbol-table":
        return this._renderSymbolTable(this.legendElement);
      case "size-ramp":
        return n2(y4, { hasIndicators: this.hasIndicators, key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      case "color-ramp":
      case "opacity-ramp":
      case "heatmap-ramp":
      case "stretch-ramp":
        return n2(h4, { effectList: this.effectList, key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      case "relationship-ramp":
        return k2(this.legendElement, this.id, { opacity: this.layer.opacity, effectList: this.effectList, ariaLabel: this.messages.previewRelationshipRampAriaLabel, key: this.key });
      case "pie-chart-ramp":
        return n2("div", { afterCreate: i5, bind: this.legendElement.preview, class: r5.pieChartRampPreview, key: `${this.key}-preview` });
      case "univariate-above-and-below-ramp":
        return n2(y6, { effectList: this.effectList, key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      case "univariate-color-size-ramp":
        return n2(y7, { effectList: this.effectList, key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      default:
        return null;
    }
  }
  _renderSymbolTable(e10) {
    const s8 = e10.infos.map((s9) => this._renderElementInfo(s9, e10.legendType)).filter(Boolean);
    if (!s8.length) return null;
    const t4 = this.activeLayerInfo.legendElements.some(({ type: e11 }) => "relationship-ramp" === e11), i7 = s8[0]?.properties?.classes?.[r5.symbolRow], r8 = { [r5.labelContainer]: !i7 && !t4, [r5.relationshipLabelContainer]: t4 };
    return n2("div", { class: this.classes(r8) }, s8);
  }
  _renderElementInfo(e10, s8) {
    const { layer: t4 } = this, i7 = "label" in e10 ? e10.label : null, r8 = `${this.key}-${i7}`;
    if ("type" in e10 && e10.type) return n2(b4, { activeLayerInfo: this.activeLayerInfo, effectList: this.effectList, hasIndicators: this.hasIndicators, headingLevel: this.headingLevel, isChild: true, key: r8, layer: t4, legendElement: e10, messages: this.messages });
    if (!("preview" in e10 && e10.preview || "src" in e10 && e10.src)) return null;
    const a10 = u7(t4, s8), o5 = o4(this.messages, i7, false) || "";
    if ("src" in e10 && e10.src) return n2("div", { class: r5.layerRow, key: `${r8}-row` }, this._renderImage(e10, t4, a10), n2("div", { class: r5.imageLabel }, o5));
    if ("symbol" in e10 && e10.preview) {
      if (!e10.symbol?.type.includes("simple-fill")) {
        if (!e10.label) return n2("div", { afterCreate: i5, bind: e10.preview, key: `${r8}-row` });
        const s9 = { [r5.symbolCell]: this.hasIndicators };
        return n2("div", { class: this.classes(r5.layerRow, { [r5.symbolRow]: this.hasIndicators }), key: `${r8}-row` }, n2("div", { afterCreate: i5, bind: e10.preview, class: this.classes(s9) }), n2("div", { class: this.classes(r5.imageLabel, { [r5.labelCell]: this.hasIndicators }) }, o5));
      }
      return n2("div", { class: r5.layerRow, key: `${r8}-row` }, n2("div", { class: r5.labelElement, styles: this._getBackgroundStyles(e10) }, o5));
    }
    return null;
  }
  _getBackgroundStyles(e10) {
    const t4 = e10.symbol, i7 = t4.color, a10 = !!i7?.a, o5 = "outline" in t4 ? t4.outline : null, l9 = !!o5?.color?.a, n7 = new h2(a10 && i7 ? [i7.r, i7.g, i7.b, i7.a * this.layer.opacity] : [255, 255, 255, 0]), c9 = l9 && o5.color ? new h2([o5.color.r, o5.color.g, o5.color.b, o5.color.a * this.layer.opacity]) : new h2([255, 255, 255, 0]), p8 = e10.symbol.color?.isBright ?? true, h7 = p8 ? "black" : "white", m7 = p8 ? "rgba(255, 255, 255, .6)" : "rgba(0, 0, 0, .6)";
    return { background: a10 ? n7.toCss(true) : "none", color: h7, textShadow: `-1px -1px 0 ${m7},
                  1px -1px 0 ${m7},
                  -1px 1px 0 ${m7},
                  1px 1px 0 ${m7}`, border: l9 ? `1px solid ${c9.toCss(true)}` : "none", filter: M(this.effectList) ?? void 0 };
  }
  _renderImage(e10, s8, t4) {
    const { label: i7, src: r8, opacity: a10 } = e10, o5 = { [r5.imageryLayerStretchedImage]: t4, [r5.symbol]: !t4 }, n7 = { opacity: `${a10 ?? s8.opacity}` }, c9 = o4(this.messages, i7, false);
    return n2("img", { alt: c9, "aria-label": c9, border: 0, class: this.classes(o5), height: e10.height, src: r8, styles: n7, width: e10.width });
  }
};
r([m()], L3.prototype, "activeLayerInfo", void 0), r([m()], L3.prototype, "effectList", void 0), r([m()], L3.prototype, "hasIndicators", void 0), r([m()], L3.prototype, "headingLevel", void 0), r([m()], L3.prototype, "isChild", void 0), r([m()], L3.prototype, "layer", void 0), r([m()], L3.prototype, "legendElement", void 0), r([m()], L3.prototype, "messages", void 0), L3 = b4 = r([a("esri.widgets.Legend.styles.card.LegendElement")], L3);
var w5 = L3;

// node_modules/@arcgis/core/widgets/Legend/styles/card/CardView.js
var d8 = 768;
var p7 = class extends O {
  constructor(e10, s8) {
    super(e10, s8), this._hasIndicators = false, this.activeLayerInfos = null, this.headingLevel = 3, this.layout = "stack", this.messages = null, this.messagesCommon = null, this.type = "card", this.view = null;
  }
  loadDependencies() {
    return c2({ carousel: () => import("./calcite-carousel-6CMJDHVA.js"), "carousel-item": () => import("./calcite-carousel-item-MHMMJZNJ.js") });
  }
  render() {
    this._hasIndicators = "auto" === this.layout && this.view && this.view.container.clientWidth <= d8 || "stack" === this.layout;
    const e10 = this._hasIndicators ? this._renderCarousel() : this._renderLayers(), s8 = { [r5.stacked]: this._hasIndicators };
    return n2("div", { class: this.classes(r5.base, s8) }, e10 || n2("div", { class: r5.message }, this.messages.noLegend));
  }
  _renderCarousel() {
    const e10 = [], s8 = this.activeLayerInfos;
    if (s8) for (const t4 of s8) this._renderSections(t4, e10);
    return e10?.length ? n2("calcite-carousel", { class: r5.carousel, label: this.messages.carousel }, e10.map((s9, t4) => n2("calcite-carousel-item", { class: r5.carouselItem, key: t4, label: s(this.messagesCommon.pagination.pageText, { index: t4 + 1, total: e10.length }) }, s9))) : null;
  }
  _renderLayers() {
    const e10 = this.activeLayerInfos, s8 = e10?.toArray()?.map((e11) => this._renderLegendForLayer(e11)).filter(Boolean);
    return s8?.length ? s8 : null;
  }
  _renderLegendForLayer(e10) {
    if (!e10.ready) return null;
    if (e10.children.length) {
      const s8 = e10.children.toArray().map(this._renderLegendForLayer, this);
      return n2("section", { class: this.classes(r5.service, r5.groupLayer), key: e10.layer.uid }, n2("div", { class: r5.serviceCaptionContainer }, e10.title), s8);
    }
    return this._renderLegendElementsForLayer(e10);
  }
  _renderLegendElementsForLayer(e10) {
    const s8 = e10.legendElements?.filter(Boolean);
    if (!s8?.length) return null;
    const t4 = s8.map((s9) => n2(w5, { activeLayerInfo: e10, effectList: e10.effectList, hasIndicators: this._hasIndicators, headingLevel: this.headingLevel, isChild: false, key: `${e10.layer.uid}-${s9.type}`, layer: e10.layer, legendElement: s9, messages: this.messages })), r8 = { [r5.groupLayerChild]: !!e10.parent };
    return n2("section", { class: this.classes(r5.service, r8), key: e10.layer.uid }, n2("div", { class: r5.serviceCaptionContainer }, n2("div", { class: r5.serviceCaptionText }, e10.title)), n2("div", { class: r5.serviceContent }, t4));
  }
  _renderSections(e10, s8) {
    if (!e10.ready) return;
    if (e10.children.length) for (const r8 of e10.children) this._renderSections(r8, s8);
    const t4 = e10.legendElements;
    if (t4?.length) for (const r8 of t4) {
      const t5 = n2(w5, { activeLayerInfo: e10, effectList: e10.effectList, hasIndicators: this._hasIndicators, headingLevel: this.headingLevel, isChild: false, key: `${e10.layer.uid}-${r8.type}`, layer: e10.layer, legendElement: r8, messages: this.messages });
      t5 && s8.push(t5);
    }
  }
};
r([m()], p7.prototype, "activeLayerInfos", void 0), r([m()], p7.prototype, "headingLevel", void 0), r([m()], p7.prototype, "layout", void 0), r([m(), e2("esri/widgets/Legend/t9n/Legend")], p7.prototype, "messages", void 0), r([m(), e2("esri/t9n/common")], p7.prototype, "messagesCommon", void 0), r([m({ readOnly: true })], p7.prototype, "type", void 0), r([m()], p7.prototype, "view", void 0), p7 = r([a("esri.widgets.Legend.styles.card.CardView")], p7);
var h6 = p7;

// node_modules/@arcgis/core/widgets/Legend/styles/classic/css.js
var e9 = "esri-legend";
var a7 = { service: `${e9}__service`, label: `${e9}__service-label`, layer: `${e9}__layer`, groupLayer: `${e9}__group-layer`, groupLayerChild: `${e9}__group-layer-child`, layerTable: `${e9}__layer-table`, layerTableSizeRamp: `${e9}__layer-table--size-ramp`, layerChildTable: `${e9}__layer-child-table`, layerCaption: `${e9}__layer-caption`, layerBody: `${e9}__layer-body`, layerRow: `${e9}__layer-row`, layerCell: `${e9}__layer-cell`, layerInfo: `${e9}__layer-cell ${e9}__layer-cell--info`, imageryLayerStretchedImage: `${e9}__imagery-layer-image--stretched`, imageryLayerCellStretched: `${e9}__imagery-layer-cell--stretched`, imageryLayerInfoStretched: `${e9}__imagery-layer-info--stretched`, symbolContainer: `${e9}__layer-cell ${e9}__layer-cell--symbols`, symbol: `${e9}__symbol`, rampContainer: `${e9}__ramps`, sizeRamp: `${e9}__size-ramp`, colorRamp: `${e9}__color-ramp`, opacityRamp: `${e9}__opacity-ramp`, borderlessRamp: `${e9}__borderless-ramp`, rampTick: `${e9}__ramp-tick`, rampFirstTick: `${e9}__ramp-tick-first`, rampLastTick: `${e9}__ramp-tick-last`, rampLabelsContainer: `${e9}__ramp-labels`, rampLabel: `${e9}__ramp-label`, message: `${e9}__message`, univariateAboveAndBelowLabel: "esri-univariate-above-and-below-ramp__label" };

// node_modules/@arcgis/core/widgets/Legend/styles/classic/ColorRamp.js
var a8 = 24;
var n6 = class extends O {
  constructor(e10, t4) {
    super(e10, t4), this.legendElement = null, this.opacity = 1;
  }
  get _preview() {
    const e10 = this.legendElement.preview;
    if (!e10) return null;
    const t4 = "opacity-ramp" === this.legendElement.type ? a7.opacityRamp : "";
    return e10.className = `${a7.colorRamp} ${t4}`, null != this.opacity && (e10.style.opacity = this.opacity.toString()), e10;
  }
  render() {
    const { legendElement: e10, _preview: t4 } = this;
    if (!t4) return null;
    const s8 = { width: `${a8}px` }, r8 = { height: t4.style.height };
    return n2("div", { class: a7.layerRow, key: `${this.key}-row` }, n2("div", { class: a7.symbolContainer, styles: s8 }, n2("div", { afterCreate: i5, bind: t4, class: a7.rampContainer })), n2("div", { class: a7.layerInfo }, n2("div", { class: a7.rampLabelsContainer, styles: r8 }, e10.infos.map((t5, s9) => this._renderRampLabel(t5, s9, e10.type)))));
  }
  _renderRampLabel(e10, t4, s8) {
    return n2("div", { class: e10.label ? a7.rampLabel : void 0, key: `${this.key}-stop-${e10.label ?? t4}-label` }, l6(e10, s8, this.messages));
  }
};
r([m()], n6.prototype, "_preview", null), r([m()], n6.prototype, "legendElement", void 0), r([m()], n6.prototype, "messages", void 0), r([m()], n6.prototype, "opacity", void 0), n6 = r([a("esri.widgets.Legend.styles.classic.ColorRamp")], n6);
var c8 = n6;

// node_modules/@arcgis/core/widgets/Legend/styles/classic/SizeRamp.js
var a9 = class extends O {
  constructor(s8, e10) {
    super(s8, e10), this.legendElement = null;
  }
  render() {
    const s8 = this.legendElement.infos.map((s9) => this._renderRow(s9)).filter(Boolean);
    return s8.length ? n2("div", { class: a7.layerBody }, s8) : null;
  }
  _renderRow(s8) {
    return s8.preview ? n2("div", { class: a7.layerRow, key: `${this.key}-${s8.label}-row` }, n2("div", { class: this.classes(a7.symbolContainer, a7.sizeRamp) }, n2("div", { afterCreate: i5, bind: s8.preview, class: a7.symbol })), n2("div", { class: a7.layerInfo }, o4(this.messages, s8.label, false) || "")) : null;
  }
};
r([m()], a9.prototype, "legendElement", void 0), r([m()], a9.prototype, "messages", void 0), a9 = r([a("esri.widgets.Legend.styles.classic.SizeRamp")], a9);
var m5 = a9;

// node_modules/@arcgis/core/widgets/Legend/styles/classic/UnivariateAboveAndBelowRamp.js
var y8 = class extends O {
  constructor(e10, s8) {
    super(e10, s8), this.effectList = null, this.legendElement = null, this.opacity = 1;
  }
  render() {
    const { legendElement: e10, opacity: s8, effectList: t4, key: i7 } = this, { sizeRampElement: y9, colorRampElement: b6 } = y5(e10, s8);
    if (!y9) return null;
    const f7 = this.messages.previewColorRampAriaLabel, u11 = d6(y9, "above", true), g7 = d6(y9, "below", true), h7 = 12, L4 = h5(b6, { width: h7, height: u11, rampAlignment: "vertical", opacity: s8, type: "above", effectList: t4, ariaLabel: f7 }), w6 = h5(b6, { width: h7, height: g7, rampAlignment: "vertical", opacity: s8, type: "below", effectList: t4, ariaLabel: f7 }), j = u8(y9), A = y9.infos.map((e11) => e11.label), $ = A.map((e11, s9) => {
      const t5 = 2 === s9;
      return 0 === s9 ? n2("div", { class: e11 ? L4 ? a7.univariateAboveAndBelowLabel : a7.rampLabel : void 0, key: `${i7}-color-ramp-above-label-${e11 ?? s9}` }, e11) : t5 ? n2("div", null) : null;
    }), C = A.length - 1, R = Math.floor(A.length / 2), k3 = A.map((e11, s9) => s9 === R || s9 === C ? n2("div", { class: e11 ? L4 ? a7.univariateAboveAndBelowLabel : a7.rampLabel : void 0, key: `${i7}-color-ramp-below-label-${e11 ?? s9}` }, e11) : null), x = { display: "table-cell", verticalAlign: "middle" }, E2 = { marginTop: `${j}px` }, B = { height: `${u11}px` }, U = { height: `${g7}px` };
    return n2("div", { key: `${i7}-container`, styles: w4 }, n2("div", { class: a7.layerBody }, y9.infos.map((e11, s9) => n2("div", { class: this.classes(a7.layerRow, a7.sizeRamp), key: `${i7}-row-${s9}` }, n2("div", { afterCreate: i5, bind: e11.preview, class: a7.symbol, styles: x }), L4 || s9 % 2 != 0 ? null : n2("div", { class: a7.layerInfo }, A[s9])))), L4 ? n2("div", { styles: E2 }, n2("div", { styles: g3 }, n2("div", { styles: z }, n2("div", { afterCreate: i5, bind: L4, class: a7.rampContainer })), n2("div", { styles: z }, n2("div", { class: a7.rampLabelsContainer, styles: B }, $))), n2("div", { styles: g3 }, n2("div", { styles: z }, n2("div", { afterCreate: i5, bind: w6, class: a7.rampContainer })), n2("div", { styles: z }, n2("div", { class: a7.rampLabelsContainer, styles: U }, k3)))) : null);
  }
};
r([m()], y8.prototype, "effectList", void 0), r([m()], y8.prototype, "legendElement", void 0), r([m()], y8.prototype, "messages", void 0), r([m()], y8.prototype, "opacity", void 0), y8 = r([a("esri.widgets.Legend.styles.classic.UnivariateAboveAndBelowRamp")], y8);
var b5 = y8;

// node_modules/@arcgis/core/widgets/Legend/styles/classic/UnivariateColorSizeRamp.js
var f5 = class extends O {
  constructor(e10, s8) {
    super(e10, s8), this.effectList = null, this.legendElement = null, this.opacity = 1;
  }
  render() {
    const { legendElement: e10, opacity: s8, effectList: t4, key: o5 } = this, { sizeRampElement: f7, colorRampElement: v7 } = b3(e10);
    if (!f7) return null;
    const u11 = u8(f7), g7 = 12, b6 = d6(f7, "full", false), h7 = h5(v7, { width: g7, height: b6, rampAlignment: "vertical", opacity: s8, type: "full", effectList: t4, ariaLabel: this.messages?.previewColorRampAriaLabel }), j = f7.infos.length - 1, L4 = f7.infos.map((e11, s9) => 0 === s9 || s9 === j ? n2("div", { class: e11.label ? v7 ? a7.univariateAboveAndBelowLabel : a7.rampLabel : void 0, key: `${o5}-color-ramp-label-${e11.label ?? s9}` }, e11.label) : null), w6 = { display: "table-cell", verticalAlign: "middle" }, C = { marginTop: `${u11}px` }, R = { height: `${b6}px` };
    return n2("div", { key: `${o5}-container`, styles: w4 }, n2("div", { class: a7.layerBody }, f7.infos.map((e11, s9) => n2("div", { class: this.classes(a7.layerRow, a7.sizeRamp), key: `${o5}-row-${s9}` }, n2("div", { afterCreate: i5, bind: e11.preview, class: a7.symbol, styles: w6 })))), n2("div", { styles: C }, n2("div", { styles: g3 }, n2("div", { styles: z }, n2("div", { afterCreate: i5, bind: h7, class: a7.rampContainer })), n2("div", { styles: z }, n2("div", { class: a7.rampLabelsContainer, styles: R }, L4)))));
  }
};
r([m()], f5.prototype, "effectList", void 0), r([m()], f5.prototype, "legendElement", void 0), r([m()], f5.prototype, "messages", void 0), r([m()], f5.prototype, "opacity", void 0), f5 = r([a("esri.widgets.Legend.styles.classic.UnivariateColorSizeRamp")], f5);
var v5 = f5;

// node_modules/@arcgis/core/widgets/Legend/styles/classic/LegendElement.js
var g4;
var f6 = g4 = class extends O {
  constructor(e10, s8) {
    super(e10, s8), this.effectList = null, this.isChild = false, this.legendElement = null;
  }
  render() {
    const e10 = this._renderLegendElement(), s8 = i6(this.legendElement, this.messages), t4 = this.isChild ? a7.layerChildTable : a7.layerTable, r8 = s8 ? n2("div", { class: a7.layerCaption }, s8) : null, i7 = { [a7.layerTableSizeRamp]: "size-ramp" === this.legendElement.type || !this.isChild };
    return n2("section", { class: this.classes(t4, i7), key: `${this.key}-table` }, r8, e10);
  }
  _renderLegendElement() {
    switch (this.legendElement.type) {
      case "symbol-table":
        return this._renderSymbolTable(this.legendElement);
      case "size-ramp":
        return n2(m5, { key: this.key, legendElement: this.legendElement, messages: this.messages });
      case "color-ramp":
      case "opacity-ramp":
      case "heatmap-ramp":
      case "stretch-ramp":
        return n2(c8, { key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      case "relationship-ramp":
        return k2(this.legendElement, this.id, { opacity: this.layer.opacity, effectList: this.effectList, ariaLabel: this.messages.previewRelationshipRampAriaLabel, key: this.key });
      case "pie-chart-ramp":
        return n2("div", { afterCreate: i5, bind: this.legendElement.preview, key: `${this.key}-preview` });
      case "univariate-above-and-below-ramp":
        return n2(b5, { effectList: this.effectList, key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      case "univariate-color-size-ramp":
        return n2(v5, { effectList: this.effectList, key: this.key, legendElement: this.legendElement, messages: this.messages, opacity: this.layer.opacity });
      default:
        return null;
    }
  }
  _renderSymbolTable(e10) {
    const s8 = e10.infos.map((s9) => this._renderElementInfo(s9, e10.legendType)).filter(Boolean);
    return s8.length ? n2("div", { class: a7.layerBody }, s8) : null;
  }
  _renderElementInfo(e10, s8) {
    const { layer: t4 } = this, r8 = "label" in e10 ? e10.label : null, i7 = `${this.key}-${r8}`;
    if ("type" in e10 && e10.type) return n2(g4, { effectList: this.effectList, isChild: true, key: i7, layer: t4, legendElement: e10, messages: this.messages });
    if (!("preview" in e10 && e10.preview || "src" in e10 && e10.src)) return null;
    const l9 = u7(t4, s8), o5 = { [a7.imageryLayerInfoStretched]: l9 }, n7 = { [a7.imageryLayerInfoStretched]: l9 };
    return n2("div", { class: a7.layerRow, key: `${i7}-row` }, n2("div", { class: this.classes(a7.symbolContainer, n7) }, this._renderPreview(e10, l9)), n2("div", { class: this.classes(a7.layerInfo, o5) }, o4(this.messages, r8, false) || ""));
  }
  _renderPreview(e10, s8) {
    const { layer: t4 } = this;
    return "preview" in e10 && e10.preview ? n2("div", { afterCreate: i5, bind: e10.preview, class: a7.symbol }) : "src" in e10 && e10.src ? this._renderImage(e10, t4, s8) : null;
  }
  _renderImage(e10, s8, t4) {
    const { label: r8, src: i7, opacity: l9 } = e10, o5 = { [a7.imageryLayerStretchedImage]: t4, [a7.symbol]: !t4 }, n7 = { opacity: `${l9 ?? s8.opacity}` }, m7 = o4(this.messages, r8, false);
    return n2("img", { alt: m7, "aria-label": m7, border: 0, class: this.classes(o5), height: e10.height, src: i7, styles: n7, width: e10.width });
  }
};
r([m()], f6.prototype, "effectList", void 0), r([m()], f6.prototype, "isChild", void 0), r([m()], f6.prototype, "layer", void 0), r([m()], f6.prototype, "legendElement", void 0), r([m()], f6.prototype, "messages", void 0), f6 = g4 = r([a("esri.widgets.Legend.styles.classic.LegendElement")], f6);
var u9 = f6;

// node_modules/@arcgis/core/widgets/Legend/styles/classic/ClassicView.js
var d9 = `${e9}__`;
var m6 = class extends O {
  constructor(e10, s8) {
    super(e10, s8), this.activeLayerInfos = null, this.headingLevel = 3, this.messages = null, this.type = "classic";
  }
  render() {
    const e10 = this.activeLayerInfos, s8 = e10?.toArray().map((e11) => this._renderLegendForLayer(e11)).filter(Boolean);
    return s8?.length ? n2("section", null, s8) : n2("div", { class: a7.message, key: "no-legend" }, this.messages.noLegend);
  }
  _renderLegendForLayer(e10, s8) {
    if (!e10.ready) return null;
    const r8 = `${e10.layer.uid}-version-${e10.version}`, t4 = `${d9}${s8 ? `${s8}-` : ""}${r8}`, i7 = e10.title ? e6({ level: this.headingLevel, class: this.classes(e5.heading, a7.label) }, e10.title) : null;
    if (e10.children.length) {
      const s9 = e10.children.toArray().map((e11) => this._renderLegendForLayer(e11, r8));
      return n2("section", { class: this.classes(a7.service, a7.groupLayer), key: t4 }, i7, s9);
    }
    return this._renderLegendElementsForLayer(e10, i7, t4);
  }
  _renderLegendElementsForLayer(e10, s8, r8) {
    const t4 = e10.legendElements?.filter(Boolean);
    if (!t4?.length) return null;
    const i7 = t4.map((s9) => n2(u9, { effectList: e10.effectList, isChild: false, key: `${r8}-${s9.type}`, layer: e10.layer, legendElement: s9, messages: this.messages })), l9 = { [a7.groupLayerChild]: !!e10.parent };
    return n2("section", { class: this.classes(a7.service, l9), key: r8 }, s8, n2("div", { class: a7.layer }, i7));
  }
};
r([m()], m6.prototype, "activeLayerInfos", void 0), r([m()], m6.prototype, "headingLevel", void 0), r([m(), e2("esri/widgets/Legend/t9n/Legend")], m6.prototype, "messages", void 0), r([m({ readOnly: true })], m6.prototype, "type", void 0), m6 = r([a("esri.widgets.Legend.styles.classic.ClassicView")], m6);
var g5 = m6;

// node_modules/@arcgis/core/widgets/Legend.js
var v6 = { base: "esri-legend" };
var g6 = class extends O {
  constructor(e10, t4) {
    super(e10, t4), this.headingLevel = 3, this.messages = null, this.style = new g5(), this.viewModel = new I3();
  }
  initialize() {
    this.addHandles([v(() => this.view, "resize", () => this.scheduleRender()), v(() => this.activeLayerInfos, "change", () => this._refreshActiveLayerInfos(this.activeLayerInfos)), d(() => this.headingLevel, (e10) => {
      const { style: t4 } = this;
      t4 && (t4.headingLevel = e10);
    }), d(() => this.style, (e10, t4) => {
      t4 && e10 !== t4 && t4.destroy(), e10 && (e10.activeLayerInfos = this.activeLayerInfos, "card" === e10.type && (e10.view = this.view), e10.headingLevel = this.headingLevel);
    }, P)]);
  }
  get activeLayerInfos() {
    return this.viewModel.activeLayerInfos;
  }
  set activeLayerInfos(e10) {
    this.viewModel.activeLayerInfos = e10;
  }
  get basemapLegendVisible() {
    return this.viewModel.basemapLegendVisible;
  }
  set basemapLegendVisible(e10) {
    this.viewModel.basemapLegendVisible = e10;
  }
  get groundLegendVisible() {
    return this.viewModel.groundLegendVisible;
  }
  set groundLegendVisible(e10) {
    this.viewModel.groundLegendVisible = e10;
  }
  get hideLayersNotInCurrentView() {
    return this.viewModel.hideLayersNotInCurrentView;
  }
  set hideLayersNotInCurrentView(e10) {
    this.viewModel.hideLayersNotInCurrentView = e10;
  }
  get keepCacheOnDestroy() {
    return this.viewModel.keepCacheOnDestroy;
  }
  set keepCacheOnDestroy(e10) {
    this.viewModel.keepCacheOnDestroy = e10;
  }
  get respectLayerDefinitionExpression() {
    return this.viewModel.respectLayerDefinitionExpression;
  }
  set respectLayerDefinitionExpression(e10) {
    this.viewModel.respectLayerDefinitionExpression = e10;
  }
  get respectLayerVisibility() {
    return this.viewModel.respectLayerVisibility;
  }
  set respectLayerVisibility(e10) {
    this.viewModel.respectLayerVisibility = e10;
  }
  get icon() {
    return "legend";
  }
  set icon(e10) {
    this._overrideIfSome("icon", e10);
  }
  get label() {
    return this.messages?.widgetLabel ?? "";
  }
  set label(e10) {
    this._overrideIfSome("label", e10);
  }
  get layerInfos() {
    return this.viewModel.layerInfos;
  }
  set layerInfos(e10) {
    this.viewModel.layerInfos = e10;
  }
  castStyle(e10) {
    if (e10 instanceof h6 || e10 instanceof g5) return e10;
    if ("string" == typeof e10) return "card" === e10 ? new h6() : new g5();
    if (e10 && "string" == typeof e10.type) {
      const t4 = __spreadValues({}, e10);
      return delete t4.type, "card" === e10.type ? new h6(t4) : new g5(t4);
    }
    return new g5();
  }
  get view() {
    return this.viewModel.view;
  }
  set view(e10) {
    this.viewModel.view = e10;
  }
  render() {
    return n2("div", { class: this.classes(v6.base, e5.widget, this.style instanceof g5 ? e5.panel : null) }, this.style.render());
  }
  _refreshActiveLayerInfos(e10) {
    e10.forEach((e11) => {
      this.removeHandles(`version_${e11.layer.uid}`), this._renderOnActiveLayerInfoChange(e11);
    }), this.scheduleRender();
  }
  _renderOnActiveLayerInfoChange(e10) {
    const r8 = d(() => e10.version, () => this.scheduleRender());
    this.addHandles(r8, `version_${e10.layer.uid}`);
    const o5 = v(() => e10.children, "change", () => e10.children.forEach((e11) => this._renderOnActiveLayerInfoChange(e11)), P);
    this.addHandles(o5, `version_${e10.layer.uid}`), e10.children.forEach((e11) => this._renderOnActiveLayerInfoChange(e11));
  }
};
r([m()], g6.prototype, "activeLayerInfos", null), r([m()], g6.prototype, "basemapLegendVisible", null), r([m()], g6.prototype, "groundLegendVisible", null), r([m()], g6.prototype, "headingLevel", void 0), r([m()], g6.prototype, "hideLayersNotInCurrentView", null), r([m()], g6.prototype, "keepCacheOnDestroy", null), r([m()], g6.prototype, "respectLayerDefinitionExpression", null), r([m()], g6.prototype, "respectLayerVisibility", null), r([m()], g6.prototype, "icon", null), r([m()], g6.prototype, "label", null), r([m()], g6.prototype, "layerInfos", null), r([m(), e2("esri/widgets/Legend/t9n/Legend")], g6.prototype, "messages", void 0), r([m()], g6.prototype, "style", void 0), r([s2("style")], g6.prototype, "castStyle", null), r([m()], g6.prototype, "view", null), r([m()], g6.prototype, "viewModel", void 0), g6 = r([a("esri.widgets.Legend")], g6);
var u10 = g6;
export {
  u10 as default
};
//# sourceMappingURL=@arcgis_core_widgets_Legend.js.map
