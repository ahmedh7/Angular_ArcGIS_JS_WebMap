import {
  b
} from "./chunk-U3H4S3UY.js";
import {
  LitElement2 as LitElement,
  S,
  createEvent,
  css,
  html
} from "./chunk-NMBGL4CC.js";

// node_modules/@esri/calcite-components/dist/components/calcite-option/customElement.js
var c = css`:host{display:block}:host([hidden]){display:none}[hidden]{display:none}`;
var u = class extends LitElement {
  constructor() {
    super(...arguments), this.mutationObserver = b("mutation", () => {
      this.ensureTextContentDependentProps(), this.calciteInternalOptionChange.emit();
    }), this.disabled = false, this.calciteInternalOptionChange = createEvent({ cancelable: false });
  }
  static {
    this.properties = { disabled: 7, label: 1, selected: 7, value: 1 };
  }
  static {
    this.styles = c;
  }
  // #endregion
  // #region Lifecycle
  connectedCallback() {
    super.connectedCallback(), this.ensureTextContentDependentProps(), this.mutationObserver?.observe(this.el, {
      attributeFilter: ["label", "value"],
      characterData: true,
      childList: true,
      subtree: true
    });
  }
  willUpdate(e) {
    e.has("disabled") && (this.hasUpdated || this.disabled !== false) && this.handlePropChange(this.disabled, e.get("disabled"), "disabled"), e.has("label") && this.handlePropChange(this.label, e.get("label"), "label"), e.has("selected") && this.handlePropChange(this.selected, e.get("selected"), "selected"), e.has("value") && this.handlePropChange(this.value, e.get("value"), "value");
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.mutationObserver?.disconnect();
  }
  // #endregion
  // #region Private Methods
  handlePropChange(e, l, t) {
    (t === "label" || t === "value") && this.ensureTextContentDependentProps(), this.calciteInternalOptionChange.emit();
  }
  ensureTextContentDependentProps() {
    const { el: { textContent: e }, internallySetLabel: l, internallySetValue: t, label: s, value: a } = this;
    (!s || s === l) && (this.label = e, this.internallySetLabel = e), (a == null || a === t) && (this.value = e, this.internallySetValue = e);
  }
  // #endregion
  // #region Rendering
  render() {
    return html`<slot>${this.label}</slot>`;
  }
};
S("calcite-option", u);

export {
  u
};
/*! Bundled license information:

@esri/calcite-components/dist/components/calcite-option/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-ASAOK2ML.js.map
