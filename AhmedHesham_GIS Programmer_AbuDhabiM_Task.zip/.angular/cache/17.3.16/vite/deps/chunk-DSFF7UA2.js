// node_modules/@arcgis/core/linkChart/utils.js
function e(e2) {
  return null != e2 && "object" == typeof e2 && "2d" === e2.type && "linkchart" === e2.view2dType;
}

export {
  e
};
//# sourceMappingURL=chunk-DSFF7UA2.js.map
