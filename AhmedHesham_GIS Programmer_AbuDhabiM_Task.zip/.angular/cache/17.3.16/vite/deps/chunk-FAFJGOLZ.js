import {
  i
} from "./chunk-M4WZN4EH.js";
import {
  a
} from "./chunk-P7U5GMBX.js";

// node_modules/@arcgis/core/views/3d/webgl-engine/core/shaderModules/Matrix4PassUniform.js
var o = class extends i {
  constructor(s, o2) {
    super(s, "mat4", a.Pass, (r, t, e) => r.setUniformMatrix4fv(s, o2(t, e)));
  }
};

export {
  o
};
//# sourceMappingURL=chunk-FAFJGOLZ.js.map
