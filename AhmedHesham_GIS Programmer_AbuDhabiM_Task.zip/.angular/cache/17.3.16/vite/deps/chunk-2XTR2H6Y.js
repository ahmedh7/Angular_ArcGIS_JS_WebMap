import {
  n as n2
} from "./chunk-NHQG7442.js";
import {
  Nt,
  h
} from "./chunk-DE32Y63I.js";
import {
  n
} from "./chunk-DKRE5NM4.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/views/interactive/snapping/candidates/DrapedEdgeSnappingCandidate.js
var r = class extends n2 {
  constructor(n3) {
    super(__spreadProps(__spreadValues({}, n3), { isDraped: true, constraint: new Nt(n3.edgeStart, n3.edgeEnd, n3.getGroundElevation) }));
  }
  get hints() {
    return [new n(h.REFERENCE, this.constraint.start, this.constraint.end, this.isDraped, this.domain)];
  }
};

export {
  r
};
//# sourceMappingURL=chunk-2XTR2H6Y.js.map
