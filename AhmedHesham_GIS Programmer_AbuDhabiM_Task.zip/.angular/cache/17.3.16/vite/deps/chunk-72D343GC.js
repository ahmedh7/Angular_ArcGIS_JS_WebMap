import {
  o as o3
} from "./chunk-55OIOK5X.js";
import {
  n,
  p as p2
} from "./chunk-CLYBQCLI.js";
import {
  n as n2
} from "./chunk-DZRJWV5H.js";
import {
  i as i3
} from "./chunk-TSP7HBRK.js";
import {
  R
} from "./chunk-CVMQJ2BZ.js";
import {
  f as f2,
  i as i2,
  s as s3
} from "./chunk-ZFPFQ4J4.js";
import {
  i,
  u
} from "./chunk-QUH6IF3C.js";
import {
  b
} from "./chunk-XWFSWJ3K.js";
import {
  y
} from "./chunk-BNLIASJH.js";
import {
  x
} from "./chunk-3SPX7DOW.js";
import {
  r as r4
} from "./chunk-7F6XPLMG.js";
import {
  o as o2
} from "./chunk-ULISRLN2.js";
import {
  l,
  m as m2
} from "./chunk-P6BYIY4S.js";
import {
  f,
  v as v2
} from "./chunk-EXKRZGS6.js";
import {
  p
} from "./chunk-TAW5EJHA.js";
import {
  v
} from "./chunk-VYI6FOKY.js";
import {
  V
} from "./chunk-EC2O3UFA.js";
import {
  w
} from "./chunk-FMVDY4TM.js";
import {
  o
} from "./chunk-4JUCUHPE.js";
import {
  g as g2,
  r as r3
} from "./chunk-P5ELECBN.js";
import {
  Q,
  c
} from "./chunk-HPCWTJIY.js";
import {
  P2 as P
} from "./chunk-ADRG7ORV.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  g,
  m
} from "./chunk-UNFSMTII.js";
import {
  a3 as a,
  h,
  r as r2
} from "./chunk-QYUZVPLR.js";
import {
  k,
  s as s2
} from "./chunk-VT56RVNM.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  s2 as s
} from "./chunk-JB56QM27.js";
import {
  G,
  has
} from "./chunk-D5RIMQ7U.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-HZUW4HM7.js";

// node_modules/@arcgis/core/rest/operations/identify.js
function o4(e, r5) {
  const { dpi: n3, gdbVersion: s4, geometry: o5, geometryPrecision: a4, height: m5, historicMoment: p4, layerOption: f4, mapExtent: y2, maxAllowableOffset: u4, returnFieldName: c3, returnGeometry: d2, returnUnformattedValues: g3, returnZ: x2, spatialReference: h2, timeExtent: b2, tolerance: E, width: O } = e.toJSON(), { dynamicLayers: S3, layerDefs: j, layerIds: N } = l2(e), $ = null != r5?.geometry ? r5.geometry : null, I = { historicMoment: p4, geometryPrecision: a4, maxAllowableOffset: u4, returnFieldName: c3, returnGeometry: d2, returnUnformattedValues: g3, returnZ: x2, tolerance: E }, R3 = $?.toJSON() || o5;
  I.imageDisplay = `${O},${m5},${n3}`, s4 && (I.gdbVersion = s4), R3 && (delete R3.spatialReference, I.geometry = JSON.stringify(R3), I.geometryType = v2(R3));
  const U2 = h2 ?? R3?.spatialReference ?? y2?.spatialReference;
  if (U2 && (I.sr = c(U2)), I.time = b2 ? [b2.start, b2.end].join(",") : null, y2) {
    const { xmin: e2, ymin: t, xmax: r6, ymax: i4 } = y2;
    I.mapExtent = `${e2},${t},${r6},${i4}`;
  }
  return j && (I.layerDefs = j), S3 && !j && (I.dynamicLayers = S3), I.layers = "popup" === f4 ? "visible" : f4, N && !S3 && (I.layers += `:${N.join(",")}`), I;
}
function l2(e) {
  const { mapExtent: t, floors: i4, width: o5, sublayers: l3, layerIds: m5, layerOption: p4, gdbVersion: f4 } = e, y2 = l3?.find((e2) => null != e2.layer)?.layer?.serviceSublayers, u4 = "popup" === p4, c3 = {}, d2 = i({ extent: t, width: o5, spatialReference: t?.spatialReference }), g3 = [], x2 = (e2) => {
    const t2 = 0 === d2, r5 = 0 === e2.minScale || d2 <= e2.minScale, i5 = 0 === e2.maxScale || d2 >= e2.maxScale;
    if (e2.visible && (t2 || r5 && i5)) if (e2.sublayers) e2.sublayers.forEach(x2);
    else {
      if (false === m5?.includes(e2.id) || u4 && (!e2.popupTemplate || !e2.popupEnabled)) return;
      g3.unshift(e2);
    }
  };
  if (l3?.forEach(x2), l3 && !g3.length) c3.layerIds = [];
  else {
    const e2 = i3(g3, y2, f4), t2 = g3.map((e3) => {
      const t3 = n2(i4, e3);
      return e3.toExportImageJSON(t3);
    });
    if (e2) c3.dynamicLayers = JSON.stringify(t2);
    else {
      if (l3) {
        let e4 = g3.map(({ id: e5 }) => e5);
        m5 && (e4 = e4.filter((e5) => m5.includes(e5))), c3.layerIds = e4;
      } else m5?.length && (c3.layerIds = m5);
      const e3 = a2(i4, g3);
      if (null != e3 && e3.length) {
        const t3 = {};
        for (const r5 of e3) r5.definitionExpression && (t3[r5.id] = r5.definitionExpression);
        Object.keys(t3).length && (c3.layerDefs = JSON.stringify(t3));
      }
    }
  }
  return c3;
}
function a2(t, r5) {
  const i4 = !!t?.length, s4 = r5.filter((e) => null != e.definitionExpression || i4 && null != e.floorInfo);
  return s4.length ? s4.map((r6) => {
    const i5 = n2(t, r6), s5 = r4(i5, r6.definitionExpression);
    return { id: r6.id, definitionExpression: s5 ?? void 0 };
  }) : null;
}

// node_modules/@arcgis/core/rest/support/IdentifyParameters.js
var u2;
var d = u2 = class extends S {
  static from(t) {
    return h(u2, t);
  }
  constructor(t) {
    super(t), this.dpi = 96, this.floors = null, this.gdbVersion = null, this.geometry = null, this.geometryPrecision = null, this.height = 400, this.historicMoment = null, this.layerIds = null, this.layerOption = "top", this.mapExtent = null, this.maxAllowableOffset = null, this.returnFieldName = true, this.returnGeometry = false, this.returnM = false, this.returnUnformattedValues = true, this.returnZ = false, this.spatialReference = null, this.sublayers = null, this.timeExtent = null, this.tolerance = null, this.width = 400;
  }
  writeHistoricMoment(t, e) {
    e.historicMoment = t && t.getTime();
  }
};
r([m({ type: Number, json: { write: true } })], d.prototype, "dpi", void 0), r([m()], d.prototype, "floors", void 0), r([m({ type: String, json: { write: true } })], d.prototype, "gdbVersion", void 0), r([m({ types: l, json: { read: f, write: true } })], d.prototype, "geometry", void 0), r([m({ type: Number, json: { write: true } })], d.prototype, "geometryPrecision", void 0), r([m({ type: Number, json: { write: true } })], d.prototype, "height", void 0), r([m({ type: Date })], d.prototype, "historicMoment", void 0), r([r3("historicMoment")], d.prototype, "writeHistoricMoment", null), r([m({ type: [Number], json: { write: true } })], d.prototype, "layerIds", void 0), r([m({ type: ["top", "visible", "all", "popup"], json: { write: true } })], d.prototype, "layerOption", void 0), r([m({ type: w, json: { write: true } })], d.prototype, "mapExtent", void 0), r([m({ type: Number, json: { write: true } })], d.prototype, "maxAllowableOffset", void 0), r([m({ type: Boolean, json: { write: true } })], d.prototype, "returnFieldName", void 0), r([m({ type: Boolean, json: { write: true } })], d.prototype, "returnGeometry", void 0), r([m({ type: Boolean, json: { write: true } })], d.prototype, "returnM", void 0), r([m({ type: Boolean, json: { write: true } })], d.prototype, "returnUnformattedValues", void 0), r([m({ type: Boolean, json: { write: true } })], d.prototype, "returnZ", void 0), r([m({ type: g2, json: { write: true } })], d.prototype, "spatialReference", void 0), r([m({ type: V })], d.prototype, "sublayers", void 0), r([m({ type: p, json: { write: true } })], d.prototype, "timeExtent", void 0), r([m({ type: Number, json: { write: true } })], d.prototype, "tolerance", void 0), r([m({ type: Number, json: { write: true } })], d.prototype, "width", void 0), d = u2 = r([a("esri.rest.support.IdentifyParameters")], d);
var c2 = d;

// node_modules/@arcgis/core/rest/support/IdentifyResult.js
var u3 = class extends S {
  constructor(r5) {
    super(r5), this.displayFieldName = null, this.feature = null, this.layerId = null, this.layerName = null;
  }
  readFeature(r5, t) {
    return b.fromJSON({ attributes: __spreadValues({}, t.attributes), geometry: __spreadValues({}, t.geometry) });
  }
  writeFeature(r5, e) {
    if (!r5) return;
    const { attributes: t, geometry: o5 } = r5;
    t && (e.attributes = __spreadValues({}, t)), null != o5 && (e.geometry = o5.toJSON(), e.geometryType = m2.toJSON(o5.type));
  }
};
r([m({ type: String, json: { write: true } })], u3.prototype, "displayFieldName", void 0), r([m({ type: b })], u3.prototype, "feature", void 0), r([o("feature", ["attributes", "geometry"])], u3.prototype, "readFeature", null), r([r3("feature")], u3.prototype, "writeFeature", null), r([m({ type: Number, json: { write: true } })], u3.prototype, "layerId", void 0), r([m({ type: String, json: { write: true } })], u3.prototype, "layerName", void 0), u3 = r([a("esri.rest.support.IdentifyResult")], u3);
var m3 = u3;

// node_modules/@arcgis/core/rest/identify.js
function f3(u4, i4, f4) {
  return __async(this, null, function* () {
    const c3 = (i4 = a3(i4)).geometry ? [i4.geometry] : [], l3 = f2(u4);
    return l3.path += "/identify", R(c3).then((e) => {
      const t = o4(i4, { geometry: e?.[0] }), u5 = s3(__spreadValues(__spreadProps(__spreadValues({}, l3.query), { f: "json" }), t)), a4 = i2(u5, f4);
      return P(l3.path, a4).then(m4).then((r5) => p3(r5, i4.sublayers));
    });
  });
}
function m4(r5) {
  const e = r5.data;
  return e.results = e.results || [], e.exceededTransferLimit = Boolean(e.exceededTransferLimit), e.results = e.results.map((r6) => m3.fromJSON(r6)), e;
}
function a3(r5) {
  return r5 = c2.from(r5);
}
function p3(r5, e) {
  if (!e?.length) return r5;
  const t = /* @__PURE__ */ new Map();
  function o5(r6) {
    t.set(r6.id, r6), r6.sublayers && r6.sublayers.forEach(o5);
  }
  e.forEach(o5);
  for (const s4 of r5.results) s4.feature.sourceLayer = t.get(s4.layerId);
  return r5;
}

// node_modules/@arcgis/core/views/layers/support/MapServiceLayerViewHelper.js
var F = null;
function P2(e, t) {
  return "tile" === t.type || "map-image" === t.type;
}
var S2 = class extends g {
  constructor(e) {
    super(e), this._featuresResolutions = /* @__PURE__ */ new WeakMap(), this.highlightGraphics = null, this.highlightGraphicUpdated = null, this.updateHighlightedFeatures = k((e2) => __async(this, null, function* () {
      this.destroyed || this.updatingHandles.addPromise(this._updateHighlightedFeaturesGeometries(e2).catch(() => {
      }));
    }));
  }
  initialize() {
    const e = (e2) => {
      for (const t of e2) {
        const { sourceLayer: e3 } = t;
        null != e3 && "geometryType" in e3 && "point" === e3.geometryType && (t.visible = false);
      }
      this.updatingHandles.addPromise(this._updateHighlightedFeaturesSymbols(e2).catch(() => {
      })), this.updateHighlightedFeatures(this._highlightGeometriesResolution);
    };
    this.addHandles([v(() => this.highlightGraphics, "change", (t) => e(t.added), { onListenerAdd: (t) => e(t) })]);
  }
  fetchPopupFeaturesAtLocation(e, t) {
    return __async(this, null, function* () {
      const { layerView: { layer: r5, view: { scale: i4 } } } = this;
      if (!e) throw new s("fetchPopupFeatures:invalid-area", "Nothing to fetch without area", { layer: r5 });
      const o5 = U(r5.sublayers, i4, t);
      if (!o5.length) return [];
      const a4 = yield G2(r5, o5);
      if (!((r5.capabilities?.operations?.supportsIdentify ?? true) && r5.version >= 10.5) && !a4) throw new s("fetchPopupFeatures:not-supported", "query operation is disabled for this service", { layer: r5 });
      return a4 ? this._fetchPopupFeaturesUsingQueries(e, o5, t) : this._fetchPopupFeaturesUsingIdentify(e, o5, t);
    });
  }
  clearHighlights() {
    this.highlightGraphics?.removeAll();
  }
  _updateHighlightedFeaturesSymbols(e) {
    return __async(this, null, function* () {
      const { layerView: { view: t }, highlightGraphics: r5, highlightGraphicUpdated: s4 } = this;
      if (r5 && s4) for (const i4 of e) {
        const e2 = i4.sourceLayer && "renderer" in i4.sourceLayer && i4.sourceLayer.renderer;
        i4.sourceLayer && "geometryType" in i4.sourceLayer && "point" === i4.sourceLayer.geometryType && e2 && "getSymbolAsync" in e2 && e2.getSymbolAsync(i4).then((o5) => __async(this, null, function* () {
          o5 ||= new y();
          let a4 = null;
          const n3 = "visualVariables" in e2 ? e2.visualVariables?.find((e3) => "size" === e3.type) : void 0;
          n3 && (F || (F = (yield import("./visualVariableUtils-56TFSNIY.js")).getSize), a4 = F(n3, i4, { view: t.type, scale: t.scale, shape: "simple-marker" === o5.type ? o5.style : null })), a4 ||= "width" in o5 && "height" in o5 && null != o5.width && null != o5.height ? Math.max(o5.width, o5.height) : "size" in o5 ? o5.size : 16, r5.includes(i4) && (i4.symbol = new y({ style: "square", size: a4, xoffset: "xoffset" in o5 ? o5.xoffset : 0, yoffset: "yoffset" in o5 ? o5.yoffset : 0 }), s4(i4, "symbol"), i4.visible = true);
        }));
      }
    });
  }
  _updateHighlightedFeaturesGeometries(e) {
    return __async(this, null, function* () {
      const { layerView: { layer: t, view: r5 }, highlightGraphics: s4, highlightGraphicUpdated: o5 } = this;
      if (this._highlightGeometriesResolution = e, !o5 || !s4?.length || !t.capabilities.operations.supportsQuery) return;
      const a4 = this._getTargetResolution(e), n3 = /* @__PURE__ */ new Map();
      for (const c3 of s4) if (!this._featuresResolutions.has(c3) || this._featuresResolutions.get(c3) > a4) {
        const e2 = c3.sourceLayer;
        r2(n3, e2, () => /* @__PURE__ */ new Map()).set(c3.getObjectId(), c3);
      }
      const l3 = Array.from(n3, ([e2, t2]) => {
        const s5 = e2.createQuery();
        return s5.objectIds = [...t2.keys()], s5.outFields = [e2.objectIdField], s5.returnGeometry = true, s5.maxAllowableOffset = a4, s5.outSpatialReference = r5.spatialReference, e2.queryFeatures(s5);
      }), p4 = yield Promise.all(l3);
      if (!this.destroyed) for (const { features: i4 } of p4) for (const e2 of i4) {
        const t2 = e2.sourceLayer, r6 = n3.get(t2).get(e2.getObjectId());
        r6 && s4.includes(r6) && (r6.geometry = e2.geometry, o5(r6, "geometry"), this._featuresResolutions.set(r6, a4));
      }
    });
  }
  _getTargetResolution(e) {
    const t = e * Q(this.layerView.view.spatialReference), r5 = t / 16;
    return r5 <= 10 ? 0 : e / t * r5;
  }
  _fetchPopupFeaturesUsingIdentify(e, t, r5) {
    return __async(this, null, function* () {
      const s4 = yield this._createIdentifyParameters(e, t, r5);
      if (null == s4) return [];
      const { results: i4 } = yield f3(this.layerView.layer.parsedUrl, s4, r5);
      return i4.map((e2) => e2.feature);
    });
  }
  _createIdentifyParameters(e, t, r5) {
    return __async(this, null, function* () {
      const { floors: s4, layer: i4, timeExtent: o5, view: { spatialReference: a4, scale: n3 } } = this.layerView;
      if (!t.length) return null;
      yield Promise.all(t.map(({ sublayer: e2 }) => e2.load(r5).catch(() => {
      })));
      const l3 = Math.min(has("mapservice-popup-identify-max-tolerance"), i4.allSublayers.reduce((e2, t2) => t2.renderer ? o3({ renderer: t2.renderer, pointerType: r5?.pointerType }) : e2, 2)), p4 = this.createFetchPopupFeaturesQueryGeometry(e, l3), c3 = u(n3, a4), u4 = Math.round(p4.width / c3), m5 = new w({ xmin: p4.center.x - c3 * u4, ymin: p4.center.y - c3 * u4, xmax: p4.center.x + c3 * u4, ymax: p4.center.y + c3 * u4, spatialReference: p4.spatialReference });
      return new c2({ floors: s4, gdbVersion: "gdbVersion" in i4 ? i4.gdbVersion : void 0, geometry: e, height: u4, layerOption: "popup", mapExtent: m5, returnGeometry: true, spatialReference: a4, sublayers: i4.sublayers, timeExtent: o5, tolerance: l3, width: u4 });
    });
  }
  _fetchPopupFeaturesUsingQueries(e, t, s4) {
    return __async(this, null, function* () {
      const { layerView: { floors: i4, timeExtent: o5 } } = this, n3 = t.map((_0) => __async(this, [_0], function* ({ sublayer: t2, popupTemplate: r5 }) {
        if (yield t2.load(s4).catch(() => {
        }), t2.capabilities && !t2.capabilities.operations.supportsQuery) return [];
        const n4 = t2.createQuery(), p4 = o3({ renderer: t2.renderer, pointerType: s4?.pointerType }), c3 = this.createFetchPopupFeaturesQueryGeometry(e, p4), u4 = /* @__PURE__ */ new Set(), [y2] = yield Promise.all([n(t2, r5), t2.renderer?.collectRequiredFields(u4, t2.fieldsIndex)]);
        s2(s4), x(u4, t2.fieldsIndex, y2);
        const h2 = Array.from(u4).sort();
        n4.geometry = c3, n4.outFields = h2, n4.timeExtent = o5;
        const g3 = n2(i4, t2);
        if (n4.where = r4(n4.where, g3), t2.capabilities?.query.supportsOrderBy && t2.orderBy?.[0]) {
          const e2 = t2.orderBy[0], r6 = !e2.valueExpression && e2.field, s5 = "ascending" === e2.order ? "asc" : "desc";
          r6 && (n4.orderByFields = [`${r6} ${s5}`]);
        }
        const w2 = this._getTargetResolution(c3.width / p4), b2 = yield _(r5);
        s2(s4);
        const v3 = "point" === t2.geometryType || b2 && b2.arcadeUtils.hasGeometryOperations(r5);
        v3 || (n4.maxAllowableOffset = w2);
        let { features: j } = yield t2.queryFeatures(n4, s4);
        const F2 = v3 ? 0 : w2;
        j = yield R2(t2, j, s4);
        for (const e2 of j) this._featuresResolutions.set(e2, F2);
        return j;
      }));
      return (yield Promise.allSettled(n3)).reduce((e2, t2) => "fulfilled" === t2.status ? [...e2, ...t2.value] : e2, []).filter(G);
    });
  }
};
function U(e, t, r5) {
  const s4 = [];
  if (!e) return s4;
  const i4 = (e2) => {
    const o5 = 0 === e2.minScale || t <= e2.minScale, a4 = 0 === e2.maxScale || t >= e2.maxScale;
    if (e2.visible && o5 && a4) {
      if (e2.sublayers) e2.sublayers.forEach(i4);
      else if (e2.popupEnabled) {
        const t2 = p2(e2, __spreadProps(__spreadValues({}, r5), { defaultPopupTemplateEnabled: false }));
        null != t2 && s4.unshift({ sublayer: e2, popupTemplate: t2 });
      }
    }
  };
  return e.map(i4), s4;
}
function _(e) {
  return e.expressionInfos?.length || Array.isArray(e.content) && e.content.some((e2) => "expression" === e2.type) ? o2() : Promise.resolve();
}
function G2(e, t) {
  return __async(this, null, function* () {
    if (e.capabilities?.operations?.supportsQuery) return true;
    try {
      return yield Promise.any(t.map(({ sublayer: e2 }) => e2.load().then(() => e2.capabilities.operations.supportsQuery)));
    } catch {
      return false;
    }
  });
}
function R2(e, t, r5) {
  return __async(this, null, function* () {
    const s4 = e.renderer;
    return s4 && "defaultSymbol" in s4 && !s4.defaultSymbol && (t = s4.valueExpression ? yield Promise.all(t.map((e2) => s4.getSymbolAsync(e2, r5).then((t2) => t2 ? e2 : null))).then((e2) => e2.filter((e3) => null != e3)) : t.filter((e2) => null != s4.getSymbol(e2))), t;
  });
}
r([m({ constructOnly: true })], S2.prototype, "createFetchPopupFeaturesQueryGeometry", void 0), r([m({ constructOnly: true })], S2.prototype, "layerView", void 0), r([m({ constructOnly: true })], S2.prototype, "highlightGraphics", void 0), r([m({ constructOnly: true })], S2.prototype, "highlightGraphicUpdated", void 0), r([m({ constructOnly: true })], S2.prototype, "updatingHandles", void 0), S2 = r([a("esri.views.layers.support.MapServiceLayerViewHelper")], S2);

export {
  P2 as P,
  S2 as S
};
//# sourceMappingURL=chunk-72D343GC.js.map
