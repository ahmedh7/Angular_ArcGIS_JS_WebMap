import {
  r
} from "./chunk-JHB4QD5T.js";

// node_modules/@arcgis/core/webmap/Version.js
var s = class extends r {
  constructor(r3, s2) {
    super(r3, s2, "webmap");
  }
};

// node_modules/@arcgis/core/webmap/utils.js
function r2(e) {
  return null != e && "object" == typeof e && "declaredClass" in e && "esri.WebMap" === e.declaredClass;
}
var n = new s(2, 33);

export {
  r2 as r
};
//# sourceMappingURL=chunk-ILKILLWA.js.map
