// node_modules/@esri/calcite-components/dist/chunks/resources6.js
var n = {
  container: "container",
  containerNone: "container--none-selection",
  icon: "dropdown-item-icon",
  iconEnd: "dropdown-item-icon--end",
  iconStart: "dropdown-item-icon--start",
  itemContent: "dropdown-item-content",
  link: "dropdown-link"
};

export {
  n
};
/*! Bundled license information:

@esri/calcite-components/dist/chunks/resources6.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=chunk-GGHSCUSN.js.map
