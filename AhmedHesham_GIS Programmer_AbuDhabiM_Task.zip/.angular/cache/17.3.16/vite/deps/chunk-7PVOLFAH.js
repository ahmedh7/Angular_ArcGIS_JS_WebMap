import {
  DateTime,
  FixedOffsetZone
} from "./chunk-S3UZ5KFQ.js";

// node_modules/@arcgis/core/time/constants.js
var e = "system";
var t = "unknown";
var n = "UTC";
var o = Intl.DateTimeFormat().resolvedOptions().timeZone;

// node_modules/@arcgis/core/time/legacyTimeZoneMap.js
var a = /* @__PURE__ */ new Map([["AUS Central Standard Time", "Australia/Darwin"], ["AUS Eastern Standard Time", "Australia/Sydney"], ["Afghanistan Standard Time", "Asia/Kabul"], ["Alaskan Standard Time", "America/Anchorage"], ["Aleutian Standard Time", "America/Adak"], ["Altai Standard Time", "Asia/Barnaul"], ["Arab Standard Time", "Asia/Riyadh"], ["Arabian Standard Time", "Asia/Dubai"], ["Arabic Standard Time", "Asia/Baghdad"], ["Argentina Standard Time", "America/Buenos_Aires"], ["Astrakhan Standard Time", "Europe/Astrakhan"], ["Atlantic Standard Time", "America/Halifax"], ["Aus Central W. Standard Time", "Australia/Eucla"], ["Azerbaijan Standard Time", "Asia/Baku"], ["Azores Standard Time", "Atlantic/Azores"], ["Bahia Standard Time", "America/Bahia"], ["Bangladesh Standard Time", "Asia/Dhaka"], ["Belarus Standard Time", "Europe/Minsk"], ["Bougainville Standard Time", "Pacific/Bougainville"], ["Canada Central Standard Time", "America/Regina"], ["Cape Verde Standard Time", "Atlantic/Cape_Verde"], ["Caucasus Standard Time", "Asia/Yerevan"], ["Cen. Australia Standard Time", "Australia/Adelaide"], ["Central America Standard Time", "America/Guatemala"], ["Central Asia Standard Time", "Asia/Bishkek"], ["Central Brazilian Standard Time", "America/Cuiaba"], ["Central Europe Standard Time", "Europe/Budapest"], ["Central European Standard Time", "Europe/Warsaw"], ["Central Pacific Standard Time", "Pacific/Guadalcanal"], ["Central Standard Time", "America/Chicago"], ["Central Standard Time (Mexico)", "America/Mexico_City"], ["Chatham Islands Standard Time", "Pacific/Chatham"], ["China Standard Time", "Asia/Shanghai"], ["Cuba Standard Time", "America/Havana"], ["Dateline Standard Time", "Etc/GMT+12"], ["E. Africa Standard Time", "Africa/Nairobi"], ["E. Australia Standard Time", "Australia/Brisbane"], ["E. Europe Standard Time", "Europe/Chisinau"], ["E. South America Standard Time", "America/Sao_Paulo"], ["Easter Island Standard Time", "Pacific/Easter"], ["Eastern Standard Time", "America/New_York"], ["Eastern Standard Time (Mexico)", "America/Cancun"], ["Egypt Standard Time", "Africa/Cairo"], ["Ekaterinburg Standard Time", "Asia/Yekaterinburg"], ["FLE Standard Time", "Europe/Kiev"], ["Fiji Standard Time", "Pacific/Fiji"], ["GMT Standard Time", "Europe/London"], ["GTB Standard Time", "Europe/Bucharest"], ["Georgian Standard Time", "Asia/Tbilisi"], ["Greenland Standard Time", "America/Godthab"], ["Greenwich Standard Time", "Atlantic/Reykjavik"], ["Haiti Standard Time", "America/Port-au-Prince"], ["Hawaiian Standard Time", "Pacific/Honolulu"], ["India Standard Time", "Asia/Calcutta"], ["Iran Standard Time", "Asia/Tehran"], ["Israel Standard Time", "Asia/Jerusalem"], ["Jordan Standard Time", "Asia/Amman"], ["Kaliningrad Standard Time", "Europe/Kaliningrad"], ["Korea Standard Time", "Asia/Seoul"], ["Libya Standard Time", "Africa/Tripoli"], ["Line Islands Standard Time", "Pacific/Kiritimati"], ["Lord Howe Standard Time", "Australia/Lord_Howe"], ["Magadan Standard Time", "Asia/Magadan"], ["Magallanes Standard Time", "America/Punta_Arenas"], ["Marquesas Standard Time", "Pacific/Marquesas"], ["Mauritius Standard Time", "Indian/Mauritius"], ["Middle East Standard Time", "Asia/Beirut"], ["Montevideo Standard Time", "America/Montevideo"], ["Morocco Standard Time", "Africa/Casablanca"], ["Mountain Standard Time", "America/Denver"], ["Mountain Standard Time (Mexico)", "America/Mazatlan"], ["Myanmar Standard Time", "Asia/Rangoon"], ["N. Central Asia Standard Time", "Asia/Novosibirsk"], ["Namibia Standard Time", "Africa/Windhoek"], ["Nepal Standard Time", "Asia/Katmandu"], ["New Zealand Standard Time", "Pacific/Auckland"], ["Newfoundland Standard Time", "America/St_Johns"], ["Norfolk Standard Time", "Pacific/Norfolk"], ["North Asia East Standard Time", "Asia/Irkutsk"], ["North Asia Standard Time", "Asia/Krasnoyarsk"], ["North Korea Standard Time", "Asia/Pyongyang"], ["Omsk Standard Time", "Asia/Omsk"], ["Pacific SA Standard Time", "America/Santiago"], ["Pacific Standard Time", "America/Los_Angeles"], ["Pacific Standard Time (Mexico)", "America/Tijuana"], ["Pakistan Standard Time", "Asia/Karachi"], ["Paraguay Standard Time", "America/Asuncion"], ["Qyzylorda Standard Time", "Asia/Qyzylorda"], ["Romance Standard Time", "Europe/Paris"], ["Russia Time Zone 10", "Asia/Srednekolymsk"], ["Russia Time Zone 11", "Asia/Kamchatka"], ["Russia Time Zone 3", "Europe/Samara"], ["Russian Standard Time", "Europe/Moscow"], ["SA Eastern Standard Time", "America/Cayenne"], ["SA Pacific Standard Time", "America/Bogota"], ["SA Western Standard Time", "America/La_Paz"], ["SE Asia Standard Time", "Asia/Bangkok"], ["Saint Pierre Standard Time", "America/Miquelon"], ["Sakhalin Standard Time", "Asia/Sakhalin"], ["Samoa Standard Time", "Pacific/Apia"], ["Sao Tome Standard Time", "Africa/Sao_Tome"], ["Saratov Standard Time", "Europe/Saratov"], ["Singapore Standard Time", "Asia/Singapore"], ["South Africa Standard Time", "Africa/Johannesburg"], ["South Sudan Standard Time", "Africa/Juba"], ["Sri Lanka Standard Time", "Asia/Colombo"], ["Sudan Standard Time", "Africa/Khartoum"], ["Syria Standard Time", "Asia/Damascus"], ["Taipei Standard Time", "Asia/Taipei"], ["Tasmania Standard Time", "Australia/Hobart"], ["Tocantins Standard Time", "America/Araguaina"], ["Tokyo Standard Time", "Asia/Tokyo"], ["Tomsk Standard Time", "Asia/Tomsk"], ["Tonga Standard Time", "Pacific/Tongatapu"], ["Transbaikal Standard Time", "Asia/Chita"], ["Turkey Standard Time", "Europe/Istanbul"], ["Turks And Caicos Standard Time", "America/Grand_Turk"], ["US Eastern Standard Time", "America/Indianapolis"], ["US Mountain Standard Time", "America/Phoenix"], ["UTC", "Etc/GMT"], ["UTC+01", "Etc/GMT-1"], ["UTC+02", "Etc/GMT-2"], ["UTC+03", "Etc/GMT-3"], ["UTC+04", "Etc/GMT-4"], ["UTC+05", "Etc/GMT-5"], ["UTC+06", "Etc/GMT-6"], ["UTC+07", "Etc/GMT-7"], ["UTC+08", "Etc/GMT-8"], ["UTC+09", "Etc/GMT-9"], ["UTC+10", "Etc/GMT-10"], ["UTC+11", "Etc/GMT-11"], ["UTC+12", "Etc/GMT-12"], ["UTC+13", "Etc/GMT-13"], ["UTC+14", "Etc/GMT-14"], ["UTC-01", "Etc/GMT+1"], ["UTC-02", "Etc/GMT+2"], ["UTC-03", "Etc/GMT+3"], ["UTC-04", "Etc/GMT+4"], ["UTC-05", "Etc/GMT+5"], ["UTC-06", "Etc/GMT+6"], ["UTC-07", "Etc/GMT+7"], ["UTC-08", "Etc/GMT+8"], ["UTC-09", "Etc/GMT+9"], ["UTC-10", "Etc/GMT+10"], ["UTC-11", "Etc/GMT+11"], ["UTC-12", "Etc/GMT+12"], ["Ulaanbaatar Standard Time", "Asia/Ulaanbaatar"], ["Venezuela Standard Time", "America/Caracas"], ["Vladivostok Standard Time", "Asia/Vladivostok"], ["Volgograd Standard Time", "Europe/Volgograd"], ["W. Australia Standard Time", "Australia/Perth"], ["W. Central Africa Standard Time", "Africa/Lagos"], ["W. Europe Standard Time", "Europe/Berlin"], ["W. Mongolia Standard Time", "Asia/Hovd"], ["West Asia Standard Time", "Asia/Tashkent"], ["West Bank Standard Time", "Asia/Hebron"], ["West Pacific Standard Time", "Pacific/Port_Moresby"], ["Yakutsk Standard Time", "Asia/Yakutsk"], ["Yukon Standard Time", "America/Whitehorse"]]);

// node_modules/@arcgis/core/time/timeZoneUtils.js
var s = "shortOffset";
function m(t2) {
  return "timeZoneIANA" in t2;
}
function u(t2) {
  return t2.startsWith("UTC");
}
function a2(t2, e2 = false) {
  return { json: { read: { source: t2, reader: (e3, n2) => n2[t2] ? f(n2[t2]) : null }, write: !!e2 && { allowNull: true, writer(e3, n2) {
    n2[t2] = e3 ? c(e3) : null;
  } } } };
}
function f(e2, n2 = e) {
  return e2 ? m(e2) ? e2.timeZoneIANA : l(e2, n2) : n2;
}
function c(t2) {
  return { timeZoneIANA: t2 };
}
function l(e2, n2 = e) {
  if (!e2 || !a.has(e2.timeZone)) return n2;
  const r = a.get(e2.timeZone);
  return u(e2.timeZone) || e2.respectsDaylightSaving ? r : Z(r);
}
function Z(t2) {
  const e2 = DateTime.local().setZone(t2), n2 = Math.min(e2.set({ month: 1, day: 1 }).offset, e2.set({ month: 5 }).offset);
  if (0 === n2) return "Etc/UTC";
  return `Etc/GMT${FixedOffsetZone.instance(-n2).formatOffset(0, "narrow")}`;
}
function h(t2, o2, r, i, m2) {
  if (o2 && "date" === m2) return { timeZone: n, timeZoneName: void 0 };
  const u2 = i.timeStyle || i.hour, a3 = r === t;
  return { timeZone: a3 ? "timestamp-offset" === m2 ? void 0 : t2 ?? n : r, timeZoneName: a3 && u2 ? s : void 0 };
}
function p(e2) {
  const o2 = /* @__PURE__ */ new Set(["etc/utc", "etc/gmt", "gmt"]), r = new Set(Intl.supportedValuesOf("timeZone").map((t2) => t2.toLowerCase()));
  return e2 === e || e2 === t || o2.has(e2.toLowerCase()) || r.has(e2.toLowerCase());
}

export {
  e,
  t,
  n,
  o,
  a2 as a,
  f,
  h,
  p
};
//# sourceMappingURL=chunk-7PVOLFAH.js.map
