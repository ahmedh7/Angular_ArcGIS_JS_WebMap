import {
  c2 as c,
  i2
} from "./chunk-RQIC5Q3A.js";
import {
  i,
  n
} from "./chunk-4VQUNH2Z.js";
import {
  a as a3
} from "./chunk-J3AJBXLW.js";
import {
  o
} from "./chunk-4JUCUHPE.js";
import {
  r as r2
} from "./chunk-P5ELECBN.js";
import {
  s
} from "./chunk-REZDV4AU.js";
import {
  S
} from "./chunk-XIZ4X35L.js";
import {
  m
} from "./chunk-UNFSMTII.js";
import {
  N,
  a3 as a2
} from "./chunk-QYUZVPLR.js";
import {
  r
} from "./chunk-DPYVIPSF.js";
import {
  a
} from "./chunk-JB56QM27.js";

// node_modules/@arcgis/core/form/elements/Element.js
var e = class extends S {
  constructor(t) {
    super(t), this.description = null, this.label = null, this.type = null, this.visibilityExpression = null;
  }
};
r([m({ type: String, json: { write: true } })], e.prototype, "description", void 0), r([m({ type: String, json: { write: true } })], e.prototype, "label", void 0), r([m()], e.prototype, "type", void 0), r([m({ type: String, json: { write: true } })], e.prototype, "visibilityExpression", void 0), e = r([a2("esri.form.elements.Element")], e);
var i3 = e;

// node_modules/@arcgis/core/form/elements/inputs/attachments/Input.js
var p = class extends a3.ClonableMixin(S) {
  constructor(o2) {
    super(o2), this.type = null;
  }
};
r([m()], p.prototype, "type", void 0), p = r([a2("esri.form.elements.inputs.attachments.Input")], p);
var c2 = p;

// node_modules/@arcgis/core/form/elements/inputs/attachments/support/utils.js
var a4 = ["any", "capture", "upload"];

// node_modules/@arcgis/core/form/elements/inputs/attachments/AudioInput.js
var p2 = class extends c2 {
  constructor(o2) {
    super(o2), this.type = "audio", this.inputMethod = "any", this.maxDuration = null;
  }
};
r([m({ type: ["audio"], readOnly: true, json: { write: true } })], p2.prototype, "type", void 0), r([m({ type: a4, json: { write: true } })], p2.prototype, "inputMethod", void 0), r([m({ type: Number, json: { write: true } })], p2.prototype, "maxDuration", void 0), p2 = r([a2("esri.form.elements.inputs.attachments.AudioInput")], p2);
var i4 = p2;

// node_modules/@arcgis/core/form/elements/inputs/attachments/DocumentInput.js
var s2 = class extends c2 {
  constructor(o2) {
    super(o2), this.type = "document", this.maxFileSize = null;
  }
};
r([m({ type: ["document"], readOnly: true, json: { write: true } })], s2.prototype, "type", void 0), r([m({ type: Number, json: { write: true } })], s2.prototype, "maxFileSize", void 0), s2 = r([a2("esri.form.elements.inputs.attachments.DocumentInput")], s2);
var p3 = s2;

// node_modules/@arcgis/core/form/elements/inputs/attachments/ImageInput.js
var p4 = class extends c2 {
  constructor(t) {
    super(t), this.type = "image", this.inputMethod = "any", this.maxImageSize = null;
  }
};
r([m({ type: ["image"], readOnly: true, json: { write: true } })], p4.prototype, "type", void 0), r([m({ type: a4, json: { write: true } })], p4.prototype, "inputMethod", void 0), r([m({ type: Number, json: { write: true } })], p4.prototype, "maxImageSize", void 0), p4 = r([a2("esri.form.elements.inputs.attachments.ImageInput")], p4);
var i5 = p4;

// node_modules/@arcgis/core/form/elements/inputs/attachments/SignatureInput.js
var p5 = class extends c2 {
  constructor(t) {
    super(t), this.type = "signature", this.inputMethod = "any";
  }
};
r([m({ type: ["signature"], readOnly: true, json: { write: true } })], p5.prototype, "type", void 0), r([m({ type: a4, json: { write: true } })], p5.prototype, "inputMethod", void 0), p5 = r([a2("esri.form.elements.inputs.attachments.SignatureInput")], p5);
var i6 = p5;

// node_modules/@arcgis/core/form/elements/inputs/attachments/VideoInput.js
var p6 = class extends c2 {
  constructor(o2) {
    super(o2), this.type = "video", this.inputMethod = "any", this.maxDuration = null;
  }
};
r([m({ type: ["video"], readOnly: true, json: { write: true } })], p6.prototype, "type", void 0), r([m({ type: a4, json: { write: true } })], p6.prototype, "inputMethod", void 0), r([m({ type: Number, json: { write: true } })], p6.prototype, "maxDuration", void 0), p6 = r([a2("esri.form.elements.inputs.attachments.VideoInput")], p6);
var i7 = p6;

// node_modules/@arcgis/core/form/elements/inputs/attachments/support/inputs.js
function u(e3) {
  return { nestableTypes: { base: c2, key: "type", typeMap: { audio: i4, document: p3, image: i5, signature: i6, video: i7 } }, allTypes: { base: c2, key: "type", typeMap: { attachment: e3, audio: i4, document: p3, image: i5, signature: i6, video: i7 } } };
}
function s3(t, p22, n7) {
  return t ? t.map((t2) => N(n7 ? p22.nestableTypes : p22.allTypes, t2)) : null;
}
function i8(e3, t, p22) {
  if (!e3) return null;
  const n7 = p22 ? t.nestableTypes.typeMap : t.allTypes.typeMap;
  return e3.filter((e4) => n7[e4.type]).map((e4) => n7[e4.type].fromJSON(e4));
}
function m2(e3, t, p22) {
  if (!e3) return null;
  const n7 = p22 ? t.nestableTypes.typeMap : t.allTypes.typeMap;
  return e3.filter((e4) => n7[e4.type]).map((e4) => e4.toJSON());
}

// node_modules/@arcgis/core/form/elements/inputs/attachments/AttachmentInput.js
var m3 = class extends c2 {
  constructor(t) {
    super(t), this.type = "attachment", this.attachmentAssociationType = "exact", this.inputTypes = null;
  }
  castInputs(t) {
    return s3(t, y, true);
  }
  readInputs(t, r4) {
    return i8(r4.inputTypes, y, true);
  }
  writeInputs(t, r4) {
    r4.inputTypes = m2(t, y, true);
  }
};
r([m({ type: ["attachment"], readOnly: true, json: { write: true } })], m3.prototype, "type", void 0), r([m({ type: ["any", "exact", "exactOrNone"], json: { write: true } })], m3.prototype, "attachmentAssociationType", void 0), r([m({ json: { write: { isRequired: true } } })], m3.prototype, "inputTypes", void 0), r([s("inputTypes")], m3.prototype, "castInputs", null), r([o("inputTypes")], m3.prototype, "readInputs", null), r([r2("inputTypes")], m3.prototype, "writeInputs", null), m3 = r([a2("esri.form.elements.inputs.attachments.AttachmentInput")], m3);
var y = u(m3);
var d = m3;

// node_modules/@arcgis/core/form/elements/AttachmentElement.js
var r3;
var a5 = u(d);
var p7 = r3 = class extends i3 {
  constructor(t) {
    super(t), this.allowUserRename = true, this.attachmentKeyword = null, this.displayFilename = false, this.editableExpression = null, this.filenameExpression = "{attachmentKeyword}_{now}", this.input = null, this.maxAttachmentCount = null, this.minAttachmentCount = null, this.type = "attachment", this.useOriginalFilename = true;
  }
  clone() {
    return new r3({ allowUserRename: this.allowUserRename, attachmentKeyword: this.attachmentKeyword, description: this.description, displayFilename: this.displayFilename, editableExpression: this.editableExpression, filenameExpression: this.filenameExpression, input: this.input?.clone(), label: this.label, maxAttachmentCount: this.maxAttachmentCount, minAttachmentCount: this.minAttachmentCount, useOriginalFilename: this.useOriginalFilename, visibilityExpression: this.visibilityExpression });
  }
};
r([m({ type: Boolean, json: { write: true } })], p7.prototype, "allowUserRename", void 0), r([m({ type: String, json: { write: { isRequired: true } } })], p7.prototype, "attachmentKeyword", void 0), r([m({ type: Boolean, json: { write: true } })], p7.prototype, "displayFilename", void 0), r([m({ type: String, json: { write: true } })], p7.prototype, "editableExpression", void 0), r([m({ type: String, json: { write: true } })], p7.prototype, "filenameExpression", void 0), r([m({ types: a5.allTypes, json: { read: { source: "inputType" }, write: { target: "inputType", isRequired: true } } })], p7.prototype, "input", void 0), r([m({ type: Number, json: { write: true } })], p7.prototype, "maxAttachmentCount", void 0), r([m({ type: Number, json: { write: true } })], p7.prototype, "minAttachmentCount", void 0), r([m({ type: ["attachment"], readOnly: true, json: { read: false, write: true } })], p7.prototype, "type", void 0), r([m({ type: Boolean, json: { write: true } })], p7.prototype, "useOriginalFilename", void 0), p7 = r3 = r([a2("esri.form.elements.AttachmentElement")], p7);
var m4 = p7;

// node_modules/@arcgis/core/form/elements/inputs/Input.js
var e2 = class extends S {
  constructor(o2) {
    super(o2), this.type = null;
  }
};
r([m()], e2.prototype, "type", void 0), e2 = r([a2("esri.form.elements.inputs.Input")], e2);
var p8 = e2;

// node_modules/@arcgis/core/form/elements/inputs/TextInput.js
var s4 = class extends p8 {
  constructor(o2) {
    super(o2), this.maxLength = null, this.minLength = 0;
  }
};
r([m({ type: Number, json: { write: true } })], s4.prototype, "maxLength", void 0), r([m({ type: Number, json: { write: true } })], s4.prototype, "minLength", void 0), s4 = r([a2("esri.form.elements.inputs.TextInput")], s4);
var p9 = s4;

// node_modules/@arcgis/core/form/elements/inputs/BarcodeScannerInput.js
var s5;
var n2 = s5 = class extends p9 {
  constructor(r4) {
    super(r4), this.type = "barcode-scanner";
  }
  clone() {
    return new s5({ maxLength: this.maxLength, minLength: this.minLength });
  }
};
r([m({ type: ["barcode-scanner"], json: { read: false, write: true } })], n2.prototype, "type", void 0), n2 = s5 = r([a2("esri.form.elements.inputs.BarcodeScannerInput")], n2);
var c3 = n2;

// node_modules/@arcgis/core/form/elements/inputs/ComboBoxInput.js
var s6;
var p10 = s6 = class extends p8 {
  constructor(o2) {
    super(o2), this.noValueOptionLabel = null, this.showNoValueOption = true, this.type = "combo-box";
  }
  clone() {
    return new s6({ showNoValueOption: this.showNoValueOption, noValueOptionLabel: this.noValueOptionLabel });
  }
};
r([m({ type: String, json: { write: true } })], p10.prototype, "noValueOptionLabel", void 0), r([m({ type: Boolean, json: { write: true } })], p10.prototype, "showNoValueOption", void 0), r([m({ type: ["combo-box"], json: { read: false, write: true } })], p10.prototype, "type", void 0), p10 = s6 = r([a2("esri.form.elements.inputs.ComboBoxInput")], p10);
var i9 = p10;

// node_modules/@arcgis/core/form/elements/inputs/DatePickerInput.js
var p11;
function s7(r4) {
  return null != r4 ? r4 : null;
}
function a6(r4) {
  return null != r4 ? r4 : null;
}
var m5 = p11 = class extends p8 {
  constructor(r4) {
    super(r4), this.max = null, this.min = null, this.type = "date-picker";
  }
  readMax(r4, t) {
    return s7(t.max);
  }
  writeMax(r4, t) {
    t.max = a6(r4);
  }
  readMin(r4, t) {
    return s7(t.min);
  }
  writeMin(r4, t) {
    t.min = a6(r4);
  }
  clone() {
    return new p11({ max: this.max, min: this.min });
  }
};
r([m({ type: String, json: { type: String, write: true } })], m5.prototype, "max", void 0), r([o("max")], m5.prototype, "readMax", null), r([r2("max")], m5.prototype, "writeMax", null), r([m({ type: String, json: { type: String, write: true } })], m5.prototype, "min", void 0), r([o("min")], m5.prototype, "readMin", null), r([r2("min")], m5.prototype, "writeMin", null), r([m({ type: ["date-picker"], json: { read: false, write: true } })], m5.prototype, "type", void 0), m5 = p11 = r([a2("esri.form.elements.inputs.DatePickerInput")], m5);
var c4 = m5;

// node_modules/@arcgis/core/form/elements/inputs/DateTimeOffsetPickerInput.js
var s8;
function p12(t) {
  return null != t ? t : null;
}
function m6(t) {
  return null != t ? t : null;
}
var u2 = s8 = class extends p8 {
  constructor(t) {
    super(t), this.includeTimeOffset = true, this.max = null, this.min = null, this.timeResolution = "minutes", this.type = "datetimeoffset-picker";
  }
  readMax(t, e3) {
    return p12(e3.max);
  }
  writeMax(t, e3) {
    e3.max = m6(t);
  }
  readMin(t, e3) {
    return p12(e3.min);
  }
  writeMin(t, e3) {
    e3.min = m6(t);
  }
  readTimeResolution(t, e3) {
    return p12(e3.timeResolution);
  }
  writeTimeResolution(t, e3) {
    e3.timeResolution = m6(t);
  }
  clone() {
    return new s8({ includeTimeOffset: this.includeTimeOffset, max: this.max, min: this.min, timeResolution: this.timeResolution });
  }
};
r([m({ type: Boolean, json: { write: true } })], u2.prototype, "includeTimeOffset", void 0), r([m({ type: String, json: { type: String, write: true } })], u2.prototype, "max", void 0), r([o("max")], u2.prototype, "readMax", null), r([r2("max")], u2.prototype, "writeMax", null), r([m({ type: String, json: { type: String, write: true } })], u2.prototype, "min", void 0), r([o("min")], u2.prototype, "readMin", null), r([r2("min")], u2.prototype, "writeMin", null), r([m({ type: String, json: { type: String, write: true } })], u2.prototype, "timeResolution", void 0), r([o("timeResolution")], u2.prototype, "readTimeResolution", null), r([r2("timeResolution")], u2.prototype, "writeTimeResolution", null), r([m({ type: ["datetimeoffset-picker"], json: { read: false, write: true } })], u2.prototype, "type", void 0), u2 = s8 = r([a2("esri.form.elements.inputs.DateTimeOffsetPickerInput")], u2);
var l = u2;

// node_modules/@arcgis/core/form/elements/inputs/DateTimePickerInput.js
var p13;
function s9(e3) {
  return null != e3 ? new Date(e3) : null;
}
function m7(e3) {
  return e3 ? e3.getTime() : null;
}
var a7 = p13 = class extends p8 {
  constructor(e3) {
    super(e3), this.includeTime = false, this.max = null, this.min = null, this.type = "datetime-picker";
  }
  readMax(e3, r4) {
    return s9(r4.max);
  }
  writeMax(e3, r4) {
    r4.max = m7(e3);
  }
  readMin(e3, r4) {
    return s9(r4.min);
  }
  writeMin(e3, r4) {
    r4.min = m7(e3);
  }
  clone() {
    return new p13({ includeTime: this.includeTime, max: this.max, min: this.min });
  }
};
r([m({ type: Boolean, json: { write: true } })], a7.prototype, "includeTime", void 0), r([m({ type: Date, json: { type: Number, write: true } })], a7.prototype, "max", void 0), r([o("max")], a7.prototype, "readMax", null), r([r2("max")], a7.prototype, "writeMax", null), r([m({ type: Date, json: { type: Number, write: true } })], a7.prototype, "min", void 0), r([o("min")], a7.prototype, "readMin", null), r([r2("min")], a7.prototype, "writeMin", null), r([m({ type: ["datetime-picker"], json: { read: false, write: true } })], a7.prototype, "type", void 0), a7 = p13 = r([a2("esri.form.elements.inputs.DateTimePickerInput")], a7);
var c5 = a7;

// node_modules/@arcgis/core/form/elements/inputs/RadioButtonsInput.js
var s10;
var p14 = s10 = class extends p8 {
  constructor(o2) {
    super(o2), this.noValueOptionLabel = null, this.showNoValueOption = true, this.type = "radio-buttons";
  }
  clone() {
    return new s10({ noValueOptionLabel: this.noValueOptionLabel, showNoValueOption: this.showNoValueOption });
  }
};
r([m({ type: String, json: { write: true } })], p14.prototype, "noValueOptionLabel", void 0), r([m({ type: Boolean, json: { write: true } })], p14.prototype, "showNoValueOption", void 0), r([m({ type: ["radio-buttons"], json: { read: false, write: true } })], p14.prototype, "type", void 0), p14 = s10 = r([a2("esri.form.elements.inputs.RadioButtonsInput")], p14);
var i10 = p14;

// node_modules/@arcgis/core/form/elements/inputs/SwitchInput.js
var s11;
var p15 = s11 = class extends p8 {
  constructor(o2) {
    super(o2), this.offValue = null, this.onValue = null, this.type = "switch";
  }
  clone() {
    return new s11({ offValue: this.offValue, onValue: this.onValue });
  }
};
r([m({ type: [String, Number], json: { write: true } })], p15.prototype, "offValue", void 0), r([m({ type: [String, Number], json: { write: true } })], p15.prototype, "onValue", void 0), r([m({ type: ["switch"], json: { read: false, write: true } })], p15.prototype, "type", void 0), p15 = s11 = r([a2("esri.form.elements.inputs.SwitchInput")], p15);
var i11 = p15;

// node_modules/@arcgis/core/form/elements/inputs/TextAreaInput.js
var s12;
var p16 = s12 = class extends p9 {
  constructor(t) {
    super(t), this.type = "text-area";
  }
  clone() {
    return new s12({ maxLength: this.maxLength, minLength: this.minLength });
  }
};
r([m({ type: ["text-area"], json: { read: false, write: true } })], p16.prototype, "type", void 0), p16 = s12 = r([a2("esri.form.elements.inputs.TextAreaInput")], p16);
var a8 = p16;

// node_modules/@arcgis/core/form/elements/inputs/TextBoxInput.js
var s13;
var p17 = s13 = class extends p9 {
  constructor(t) {
    super(t), this.type = "text-box";
  }
  clone() {
    return new s13({ maxLength: this.maxLength, minLength: this.minLength });
  }
};
r([m({ type: ["text-box"], json: { read: false, write: true } })], p17.prototype, "type", void 0), p17 = s13 = r([a2("esri.form.elements.inputs.TextBoxInput")], p17);
var n3 = p17;

// node_modules/@arcgis/core/form/elements/inputs/TimePickerInput.js
var s14;
function p18(t) {
  return null != t ? t : null;
}
function m8(t) {
  return null != t ? t : null;
}
var u3 = s14 = class extends p8 {
  constructor(t) {
    super(t), this.max = null, this.min = null, this.timeResolution = "minutes", this.type = "time-picker";
  }
  readMax(t, e3) {
    return p18(e3.max);
  }
  writeMax(t, e3) {
    e3.max = m8(t);
  }
  readMin(t, e3) {
    return p18(e3.min);
  }
  writeMin(t, e3) {
    e3.min = m8(t);
  }
  readTimeResolution(t, e3) {
    return p18(e3.timeResolution);
  }
  writeTimeResolution(t, e3) {
    e3.timeResolution = m8(t);
  }
  clone() {
    return new s14({ max: this.max, min: this.min, timeResolution: this.timeResolution });
  }
};
r([m({ type: String, json: { type: String, write: true } })], u3.prototype, "max", void 0), r([o("max")], u3.prototype, "readMax", null), r([r2("max")], u3.prototype, "writeMax", null), r([m({ type: String, json: { type: String, write: true } })], u3.prototype, "min", void 0), r([o("min")], u3.prototype, "readMin", null), r([r2("min")], u3.prototype, "writeMin", null), r([m({ type: String, json: { type: String, write: true } })], u3.prototype, "timeResolution", void 0), r([o("timeResolution")], u3.prototype, "readTimeResolution", null), r([r2("timeResolution")], u3.prototype, "writeTimeResolution", null), r([m({ type: ["time-picker"], json: { read: false, write: true } })], u3.prototype, "type", void 0), u3 = s14 = r([a2("esri.form.elements.inputs.TimePickerInput")], u3);
var l2 = u3;

// node_modules/@arcgis/core/form/elements/inputs.js
var c6 = { base: p8, key: "type", typeMap: { "barcode-scanner": c3, "combo-box": i9, "date-picker": c4, "datetime-picker": c5, "datetimeoffset-picker": l, "radio-buttons": i10, switch: i11, "text-area": a8, "text-box": n3, "time-picker": l2 } };

// node_modules/@arcgis/core/form/elements/FieldElement.js
var n4;
var l3 = n4 = class extends i3 {
  constructor(e3) {
    super(e3), this.domain = null, this.editable = null, this.editableExpression = null, this.fieldName = null, this.hint = null, this.input = null, this.requiredExpression = null, this.type = "field", this.valueExpression = null;
  }
  clone() {
    return new n4({ description: this.description, domain: this.domain, editable: this.editable, editableExpression: this.editableExpression, fieldName: this.fieldName, hint: this.hint, input: this.input, label: this.label, requiredExpression: this.requiredExpression, valueExpression: this.valueExpression, visibilityExpression: this.visibilityExpression });
  }
};
r([m({ types: n, json: { read: { reader: i }, write: true } })], l3.prototype, "domain", void 0), r([m({ type: Boolean, json: { write: true } })], l3.prototype, "editable", void 0), r([m({ type: String, json: { write: true } })], l3.prototype, "editableExpression", void 0), r([m({ type: String, json: { write: true } })], l3.prototype, "fieldName", void 0), r([m({ type: String, json: { write: true } })], l3.prototype, "hint", void 0), r([m({ types: c6, json: { read: { source: "inputType" }, write: { target: "inputType" } } })], l3.prototype, "input", void 0), r([m({ type: String, json: { write: true } })], l3.prototype, "requiredExpression", void 0), r([m({ type: String, json: { read: false, write: true } })], l3.prototype, "type", void 0), r([m({ type: String, json: { write: true } })], l3.prototype, "valueExpression", void 0), l3 = n4 = r([a2("esri.form.elements.FieldElement")], l3);
var a9 = l3;

// node_modules/@arcgis/core/form/elements/RelationshipElement.js
var p19;
var l4 = p19 = class extends i3 {
  constructor(e3) {
    super(e3), this.displayCount = null, this.displayType = "list", this.editableExpression = null, this.orderByFields = null, this.relationshipId = null, this.type = "relationship";
  }
  clone() {
    return new p19({ description: this.description, displayCount: this.displayCount, displayType: this.displayType, editableExpression: this.editableExpression, label: this.label, orderByFields: a(this.orderByFields), relationshipId: this.relationshipId, visibilityExpression: this.visibilityExpression });
  }
};
r([m({ type: Number, json: { write: true } })], l4.prototype, "displayCount", void 0), r([m({ type: ["list"], json: { write: true } })], l4.prototype, "displayType", void 0), r([m({ type: String, json: { write: true } })], l4.prototype, "editableExpression", void 0), r([m({ type: [i2], json: { write: true } })], l4.prototype, "orderByFields", void 0), r([m({ type: Number, json: { write: true } })], l4.prototype, "relationshipId", void 0), r([m({ type: ["relationship"], json: { read: false, write: true } })], l4.prototype, "type", void 0), l4 = p19 = r([a2("esri.form.elements.RelationshipElement")], l4);
var n5 = l4;

// node_modules/@arcgis/core/form/elements/TextElement.js
var s15;
var i12 = s15 = class extends i3 {
  constructor(t) {
    super(t), this.text = null, this.textFormat = "plain-text", this.type = "text";
  }
  clone() {
    return new s15({ text: this.text, textFormat: this.textFormat, visibilityExpression: this.visibilityExpression });
  }
};
r([m({ type: String, json: { write: true } })], i12.prototype, "text", void 0), r([m({ type: String, json: { write: true } })], i12.prototype, "textFormat", void 0), r([m({ type: ["text"], readOnly: true, json: { read: false, write: true } })], i12.prototype, "type", void 0), i12 = s15 = r([a2("esri.form.elements.TextElement")], i12);
var p20 = i12;

// node_modules/@arcgis/core/form/elements/UtilityNetworkAssociationsElement.js
var p21 = class extends a3.ClonableMixin(i3) {
  constructor(o2) {
    super(o2), this.associationTypes = null, this.editableExpression = null, this.type = "utilityNetworkAssociations";
  }
};
r([m({ type: [c], json: { write: { isRequired: true } } })], p21.prototype, "associationTypes", void 0), r([m({ type: String, json: { write: true } })], p21.prototype, "editableExpression", void 0), r([m({ type: ["utilityNetworkAssociations"], json: { read: false, write: true } })], p21.prototype, "type", void 0), p21 = r([a2("esri.form.elements.UtilityNetworkAssociationsElement")], p21);
var n6 = p21;

// node_modules/@arcgis/core/form/support/formUtils.js
var s16 = (t) => "field" === t.type;
var u4 = (t) => "group" === t.type;
var m9 = (t) => "text" === t.type;
function a10(t) {
  return f(t) || c7(t);
}
function f(t) {
  return "text-area" === t.type;
}
function c7(t) {
  return "text-box" === t.type;
}
function h(t) {
  return { typesWithGroup: { base: i3, key: "type", typeMap: { attachment: m4, field: a9, group: t, relationship: n5, text: p20, utilityNetworkAssociations: n6 } }, typesWithoutGroup: { base: i3, key: "type", typeMap: { attachment: m4, field: a9, relationship: n5, text: p20, utilityNetworkAssociations: n6 } } };
}
function x(t, e3, o2 = true) {
  if (!t) return null;
  const p22 = o2 ? e3.typesWithGroup.typeMap : e3.typesWithoutGroup.typeMap;
  return t.filter((t2) => p22[t2.type]).map((t2) => p22[t2.type].fromJSON(t2));
}
function G(t, e3, o2 = true) {
  if (!t) return null;
  const p22 = o2 ? e3.typesWithGroup.typeMap : e3.typesWithoutGroup.typeMap;
  return t.filter((t2) => p22[t2.type]).map((t2) => t2.toJSON());
}
function W(e3, o2, p22 = true) {
  return e3 ? e3.map((e4) => N(p22 ? o2.typesWithGroup : o2.typesWithoutGroup, e4)) : null;
}

export {
  i3 as i,
  c6 as c,
  s16 as s,
  u4 as u,
  m9 as m,
  a10 as a,
  h,
  x,
  G,
  W
};
//# sourceMappingURL=chunk-2MPRPDUR.js.map
