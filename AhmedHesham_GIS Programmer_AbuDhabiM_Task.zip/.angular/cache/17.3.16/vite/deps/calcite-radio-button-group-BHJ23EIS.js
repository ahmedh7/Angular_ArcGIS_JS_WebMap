import {
  m as m2
} from "./chunk-GEZ5ITZ2.js";
import "./chunk-47KWH5ND.js";
import {
  m
} from "./chunk-JNDPOHLO.js";
import "./chunk-3EHTPQND.js";
import "./chunk-4OCBID5S.js";
import {
  b
} from "./chunk-U3H4S3UY.js";
import {
  mt
} from "./chunk-67TGT3ZY.js";
import "./chunk-LPID7LVC.js";
import {
  LitElement2 as LitElement,
  S,
  createEvent,
  css,
  html,
  safeClassMap,
  stringOrBoolean
} from "./chunk-NMBGL4CC.js";
import {
  __async
} from "./chunk-HZUW4HM7.js";

// node_modules/@esri/calcite-components/dist/components/calcite-radio-button-group/customElement.js
var p = {
  itemWrapper: "item-wrapper"
};
var s = {
  validationMessage: "radioButtonGroupValidationMessage"
};
var m3 = css`:host{display:flex;flex-direction:column}:host>.item-wrapper{display:flex;max-inline-size:100vw}:host([layout=horizontal])>.item-wrapper{flex-direction:row;flex-wrap:wrap}:host([layout=horizontal][scale=s])>.item-wrapper{column-gap:1rem}:host([layout=horizontal][scale=m])>.item-wrapper{column-gap:1.25rem}:host([layout=horizontal][scale=l])>.item-wrapper{column-gap:1.5rem}:host([layout=vertical])>.item-wrapper{flex-direction:column;inline-size:fit-content}:host([scale=s]) calcite-input-message{--calcite-input-message-spacing-value: calc(var(--calcite-spacing-xxs) * -1)}:host([scale=m]) calcite-input-message{--calcite-input-message-spacing-value: calc(var(--calcite-spacing-sm) * -1)}:host([scale=l]) calcite-input-message{--calcite-input-message-spacing-value: calc(var(--calcite-spacing-md) * -1)}.validation-container{display:flex;flex-direction:column;align-items:flex-start;align-self:stretch}:host([scale=m]) .validation-container,:host([scale=l]) .validation-container{padding-block-start:.5rem}:host([scale=s]) .validation-container{padding-block-start:.25rem}:host([hidden]){display:none}[hidden]{display:none}`;
var g = class extends LitElement {
  // #endregion
  // #region Lifecycle
  constructor() {
    super(), this.mutationObserver = b("mutation", () => this.passPropsToRadioButtons()), this.radioButtons = [], this.disabled = false, this.layout = "horizontal", this.required = false, this.scale = "m", this.selectedItem = null, this.status = "idle", this.calciteRadioButtonGroupChange = createEvent({ cancelable: false }), this.listen("calciteRadioButtonChange", this.radioButtonChangeHandler);
  }
  static {
    this.properties = { radioButtons: 16, disabled: 7, layout: 3, name: 3, required: 7, scale: 3, selectedItem: 0, status: 3, validationIcon: [3, { converter: stringOrBoolean }], validationMessage: 1 };
  }
  static {
    this.styles = m3;
  }
  // #endregion
  // #region Public Methods
  /** Sets focus on the fist focusable `calcite-radio-button` element in the component. */
  setFocus() {
    return __async(this, null, function* () {
      yield m(this), this.selectedItem && !this.selectedItem.disabled && mt(this.selectedItem), this.radioButtons.length > 0 && mt(this.getFocusableRadioButton());
    });
  }
  connectedCallback() {
    super.connectedCallback(), this.passPropsToRadioButtons(), this.mutationObserver?.observe(this.el, { childList: true, subtree: true });
  }
  willUpdate(t) {
    (t.has("disabled") && (this.hasUpdated || this.disabled !== false) || t.has("layout") && (this.hasUpdated || this.layout !== "horizontal") || t.has("scale") && (this.hasUpdated || this.scale !== "m")) && this.passPropsToRadioButtons();
  }
  loaded() {
    this.passPropsToRadioButtons();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.mutationObserver?.disconnect();
  }
  // #endregion
  // #region Private Methods
  passPropsToRadioButtons() {
    this.radioButtons = Array.from(this.el.querySelectorAll("calcite-radio-button")), this.selectedItem = Array.from(this.radioButtons).reverse().find((t) => t.checked) || null, this.radioButtons.length > 0 && this.radioButtons.forEach((t) => {
      this.hasUpdated && (t.disabled = this.disabled || t.disabled), t.name = this.name, t.required = this.required, t.scale = this.scale;
    });
  }
  getFocusableRadioButton() {
    return this.radioButtons.find((t) => !t.disabled) ?? null;
  }
  radioButtonChangeHandler(t) {
    this.selectedItem = t.target, this.calciteRadioButtonGroupChange.emit();
  }
  // #endregion
  // #region Rendering
  render() {
    return this.el.role = "radiogroup", html`<div aria-errormessage=${s.validationMessage} .ariaInvalid=${this.status === "invalid"} class=${safeClassMap(p.itemWrapper)}><slot></slot></div>${this.validationMessage && this.status === "invalid" ? m2({ icon: this.validationIcon, id: s.validationMessage, message: this.validationMessage, scale: this.scale, status: this.status }) : null}`;
  }
};
S("calcite-radio-button-group", g);
export {
  g as RadioButtonGroup
};
/*! Bundled license information:

@esri/calcite-components/dist/components/calcite-radio-button-group/customElement.js:
  (*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
  See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
  v3.1.0 *)
*/
//# sourceMappingURL=calcite-radio-button-group-BHJ23EIS.js.map
