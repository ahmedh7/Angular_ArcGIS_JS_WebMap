import {
  Bm,
  Vr
} from "./chunk-RPGOD7HK.js";

// node_modules/@arcgis/core/chunks/OperatorWithin.js
var t = class extends Bm {
  getOperatorType() {
    return 7;
  }
  execute(r, t2, o, s) {
    return Vr(r, t2, o, 2, s);
  }
};

export {
  t
};
//# sourceMappingURL=chunk-G5Y7CFV6.js.map
