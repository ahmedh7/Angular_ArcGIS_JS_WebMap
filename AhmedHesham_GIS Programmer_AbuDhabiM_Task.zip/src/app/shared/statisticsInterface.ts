export interface TotalStatistics{
    allAdmin0Count: number;
    allAdmin1Count: number;
    allAdmin2Count: number;
}

export interface SelectedStatistics{
    selectedAdmin0Count: number;
    selectedAdmin1Count: number;
    selectedAdmin2Count: number;
}