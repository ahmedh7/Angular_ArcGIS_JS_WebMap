export interface SelectedCodes{
    selectedAdmin0Codes: string[];
    selectedAdmin1Codes: string[];
    selectedAdmin2Codes: string[];
}