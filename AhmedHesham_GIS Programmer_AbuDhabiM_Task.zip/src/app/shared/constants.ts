export const ADMIN_LAYER_URLS = {
    ADMIN0: 'https://services5.arcgis.com/sjP4Ugu5s0dZWLjd/ArcGIS/rest/services/Administrative_Boundaries_Reference_(view_layer)/FeatureServer/2',
    ADMIN1: 'https://services5.arcgis.com/sjP4Ugu5s0dZWLjd/ArcGIS/rest/services/Administrative_Boundaries_Reference_(view_layer)/FeatureServer/1',
    ADMIN2: 'https://services5.arcgis.com/sjP4Ugu5s0dZWLjd/ArcGIS/rest/services/Administrative_Boundaries_Reference_(view_layer)/FeatureServer/0',
  };